/**
 * Valeter Inbox – customer chats for live jobs, WhatsApp-style: search, filter chips and a chat list.
 */
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, ScrollView, RefreshControl } from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import Reanimated, { FadeInDown } from 'react-native-reanimated';
import ChatListRow, { ChatSearchBar } from '../../src/components/chat/ChatListRow';
import { ChromeGlyph as Ionicons } from '../../src/components/shared/ChromeGlyph';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { colors } from '../../src/constants/colors';
import { getServiceDisplayName } from '../../src/utils/serviceNameMapper';
import { formatDisplayName } from '../../src/utils/formatDisplayName';
import { getDeletedChatBookingIds, addMultipleDeletedChatBookingIds } from '../../src/services/DeletedChatsService';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import { VALETER_BG_FALLBACK } from '../../src/constants/accountThemes';
import ValeterScreenHeader from '../../src/components/valeter/ValeterScreenHeader';
import DefaultLoadingSkeleton from '../../src/components/shared/DefaultLoadingSkeleton';
import GlassSurface from '../../src/components/shared/GlassSurface';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import { themeBackgroundGradient } from '../../src/utils/themeGradient';
import { BreathingEmpty, PulseDot, SegmentedPills, useValeterFitInsets } from '../../src/components/shared/fit/FitKit';

const SKY = colors.SKY ?? '#38BDF8';

const INBOX_BOOKING_STATUSES: string[] = ['confirmed', 'en_route', 'arrived', 'in_progress'];

type InboxBookingRow = {
  id: string;
  user_id: string;
  service_type?: string | null;
  service_name?: string | null;
  status?: string | null;
  location_address?: string | null;
  updated_at?: string | null;
  created_at?: string | null;
};

type InboxThread = {
  id: string;
  bookingId: string;
  customerName: string;
  serviceDisplayName: string;
  status: string;
  address?: string | null;
  updatedAt: string;
};

type InboxFilter = 'all' | 'travel' | 'onsite';

const STATUS_META: Record<string, { label: string; color: string; live: boolean }> = {
  confirmed: { label: 'Paid', color: '#34D399', live: false },
  en_route: { label: 'On the way', color: '#60A5FA', live: true },
  arrived: { label: 'Arrived', color: '#FBBF24', live: true },
  in_progress: { label: 'Washing', color: '#A78BFA', live: true },
};

function filterFor(status: string): Exclude<InboxFilter, 'all'> {
  return status === 'arrived' || status === 'in_progress' ? 'onsite' : 'travel';
}

function formatRelativeDate(iso: string): string {
  const d = new Date(iso);
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / (24 * 60 * 60 * 1000));
  if (diffMins < 1) return 'now';
  if (diffMins < 60) return `${diffMins}m`;
  if (diffHours < 24) return `${diffHours}h`;
  if (diffDays === 1) return 'Yesterday';
  if (diffDays < 7) return `${diffDays}d`;
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
}

async function getCustomerName(userId: string): Promise<string> {
  try {
    const { data } = await supabase.from('profiles').select('full_name').eq('id', userId).maybeSingle();
    return (data?.full_name as string | undefined) || 'Customer';
  } catch {
    return 'Customer';
  }
}

function threadPreview(thread: InboxThread): string {
  return thread.address ? `${thread.serviceDisplayName} · ${thread.address}` : thread.serviceDisplayName;
}

export default function ValeterInboxScreen() {
  const { user } = useAuth();
  const { theme } = useAccountTheme();
  const accent = theme?.primary ?? SKY;
  const gradientBg = themeBackgroundGradient(theme?.background, VALETER_BG_FALLBACK);
  const fit = useValeterFitInsets(10);

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [threads, setThreads] = useState<InboxThread[]>([]);
  const [filter, setFilter] = useState<InboxFilter>('all');
  const [query, setQuery] = useState('');

  const loadThreads = useCallback(async () => {
    if (!user?.id) {
      setThreads([]);
      setLoading(false);
      return;
    }
    try {
      const [{ data: rows, error }, deletedIds] = await Promise.all([
        supabase
          .from('bookings')
          .select('id, user_id, service_type, service_name, status, location_address, updated_at, created_at')
          .eq('valeter_id', user.id)
          .in('status', INBOX_BOOKING_STATUSES)
          .order('updated_at', { ascending: false })
          .limit(50),
        getDeletedChatBookingIds(),
      ]);

      if (error) throw error;

      const kept = ((rows ?? []) as InboxBookingRow[]).filter((r) => !deletedIds.has(r.id));
      const names = await Promise.all(kept.map((r) => getCustomerName(r.user_id)));
      const list: InboxThread[] = kept.map((r, i) => ({
        id: r.id,
        bookingId: r.id,
        customerName: names[i],
        serviceDisplayName: getServiceDisplayName(r.service_type, r.service_name),
        status: r.status || 'scheduled',
        address: r.location_address,
        updatedAt: r.updated_at || r.created_at || new Date().toISOString(),
      }));
      setThreads(list);
    } catch (e) {
      console.error('[ValeterInbox] load error', e);
      setThreads([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [user?.id]);

  useEffect(() => {
    void loadThreads();
  }, [loadThreads]);

  const onRefresh = useCallback(() => {
    if (refreshing) return;
    setRefreshing(true);
    void loadThreads();
  }, [loadThreads, refreshing]);

  const openChat = useCallback((bookingId: string) => {
    router.push({ pathname: '/valeter/jobs/chat', params: { bookingId } });
  }, []);

  const hideThread = useCallback((thread: InboxThread) => {
    void hapticFeedback('medium');
    Alert.alert('Hide chat', `Hide your chat with ${formatDisplayName(thread.customerName)} from the inbox? You can still open it from the job.`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Hide',
        style: 'destructive',
        onPress: async () => {
          await addMultipleDeletedChatBookingIds([thread.id]);
          setThreads((prev) => prev.filter((t) => t.id !== thread.id));
        },
      },
    ]);
  }, []);

  const handleClearAll = useCallback(() => {
    if (threads.length === 0) return;
    void hapticFeedback('medium');
    Alert.alert(
      'Hide all chats',
      'Hide all conversations from your inbox? They will be removed from this list only (not deleted). You can still access chats from the job.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Hide all',
          style: 'destructive',
          onPress: async () => {
            const ids = threads.map((t) => t.id);
            await addMultipleDeletedChatBookingIds(ids);
            setThreads([]);
          },
        },
      ]
    );
  }, [threads]);

  const openJobs = useCallback(() => {
    void (async () => {
      let sheet: 'upcoming' | 'request' = 'upcoming';
      if (user?.id) {
        try {
          const nowIso = new Date().toISOString();
          const [scheduledRes, offersRes] = await Promise.all([
            supabase
              .from('bookings')
              .select('id', { count: 'exact', head: true })
              .eq('valeter_id', user.id)
              .gt('scheduled_at', nowIso)
              .not('status', 'in', '(completed,cancelled,valeter_timeout)'),
            supabase
              .from('bookings')
              .select('id', { count: 'exact', head: true })
              .eq('valeter_id', user.id)
              .eq('status', 'pending_valeter_acceptance'),
          ]);
          if ((scheduledRes.count ?? 0) === 0 && (offersRes.count ?? 0) > 0) sheet = 'request';
        } catch {
          // Fall through to Scheduled.
        }
      }
      router.push({ pathname: '/valeter/valeter-dashboard', params: { sheet } });
    })();
  }, [user?.id]);

  const counts = useMemo(() => {
    let travel = 0;
    let onsite = 0;
    for (const t of threads) {
      if (filterFor(t.status) === 'onsite') onsite += 1;
      else travel += 1;
    }
    return { all: threads.length, travel, onsite };
  }, [threads]);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return threads.filter((t) => {
      if (filter !== 'all' && filterFor(t.status) !== filter) return false;
      if (!q) return true;
      return [t.customerName, t.serviceDisplayName, t.address ?? ''].some((s) => s.toLowerCase().includes(q));
    });
  }, [filter, threads, query]);
  const liveCount = threads.filter((t) => STATUS_META[t.status]?.live).length;
  const showEmpty = !loading && threads.length === 0;
  const showList = !loading && threads.length > 0;

  return (
    <View style={styles.container}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <ValeterScreenHeader
        title="Messages"
        rightAction={
          threads.length > 0 ? (
            <TouchableOpacity onPress={handleClearAll} style={styles.headerBtn} hitSlop={12}>
              <Ionicons name="trash-outline" size={21} color={accent} />
            </TouchableOpacity>
          ) : null
        }
      />

      <View style={[styles.content, { paddingTop: fit.top, paddingBottom: fit.bottom }]}>
        {loading ? (
          <View style={styles.centered}>
            <DefaultLoadingSkeleton message="Loading inbox…" variant="rich" />
          </View>
        ) : null}
        {showEmpty ? (
          <BreathingEmpty
            accent={accent}
            sf="bubble.left.and.bubble.right.fill"
            ion="chatbubbles-outline"
            title="No messages yet"
            subtitle="Once a customer has paid for a job, you can chat with them here."
            actionLabel="View jobs"
            onAction={openJobs}
          />
        ) : null}
        {showList ? (
          <>
            <Reanimated.View entering={FadeInDown.springify().damping(18)} style={styles.topBlock}>
              <ChatSearchBar value={query} onChange={setQuery} placeholder="Search customers, services or streets" />
              <SegmentedPills
                accent={accent}
                value={filter}
                onChange={setFilter}
                style={styles.segments}
                segments={[
                  { key: 'all', label: 'All', count: counts.all },
                  { key: 'travel', label: 'Upcoming', icon: 'car-outline', count: counts.travel },
                  { key: 'onsite', label: 'On site', icon: 'water-outline', count: counts.onsite },
                ]}
              />
              {liveCount > 0 ? (
                <View style={styles.liveRow}>
                  <PulseDot color="#34D399" size={6} />
                  <Text style={styles.liveText}>{liveCount} live right now</Text>
                </View>
              ) : null}
            </Reanimated.View>

            <GlassSurface style={styles.listCard} fallbackColor="rgba(10,25,41,0.55)">
              <ScrollView
                showsVerticalScrollIndicator={false}
                keyboardDismissMode="on-drag"
                refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={accent} />}
              >
                {visible.length === 0 ? (
                  <View style={styles.filterEmpty}>
                    <Text style={styles.filterEmptyText}>{query ? 'No chats match your search' : 'Nothing in this filter'}</Text>
                  </View>
                ) : (
                  visible.map((t, i) => (
                    <Reanimated.View key={t.bookingId} entering={FadeInDown.delay(Math.min(i, 8) * 40).duration(260)}>
                      <ChatListRow
                        name={formatDisplayName(t.customerName)}
                        time={formatRelativeDate(t.updatedAt)}
                        preview={threadPreview(t)}
                        status={STATUS_META[t.status] ?? STATUS_META.confirmed}
                        accent={accent}
                        last={i === visible.length - 1}
                        onPress={() => openChat(t.bookingId)}
                        onLongPress={() => hideThread(t)}
                      />
                    </Reanimated.View>
                  ))
                )}
              </ScrollView>
            </GlassSurface>
            <Text style={styles.tip}>Hold a chat to hide it · Pull down to refresh</Text>
          </>
        ) : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { flex: 1, paddingHorizontal: 14 },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  headerBtn: { width: 44, height: 44, justifyContent: 'center', alignItems: 'center' },
  topBlock: { gap: 10, marginBottom: 10 },
  segments: {},
  liveRow: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 4 },
  liveText: { color: 'rgba(203,213,225,0.8)', fontSize: 12, fontWeight: '700' },
  listCard: { flex: 1, borderRadius: 22 },
  filterEmpty: { alignItems: 'center', justifyContent: 'center', paddingVertical: 48 },
  filterEmptyText: { color: 'rgba(203,213,225,0.7)', fontSize: 14, fontWeight: '600' },
  tip: { textAlign: 'center', color: 'rgba(203,213,225,0.45)', fontSize: 11, fontWeight: '600', marginTop: 8 },
});
