/**
 * Valeter Job History – completed jobs grouped by day, with a take-home summary.
 */
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert, RefreshControl, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import Reanimated, { FadeIn, FadeInDown, LinearTransition } from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { router, type Href } from 'expo-router';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import GlassSurface from '../../../src/components/shared/GlassSurface';
import InfoBottomSheet from '../../../src/components/shared/InfoBottomSheet';
import DefaultLoadingSkeleton from '../../../src/components/shared/DefaultLoadingSkeleton';
import {
  BreathingEmpty,
  CountUpText,
  PressableScale,
  SegmentedPills,
  SymbolGlyph,
  useValeterFitInsets,
} from '../../../src/components/shared/fit/FitKit';
import ValeterScreenHeader from '../../../src/components/valeter/ValeterScreenHeader';
import { VALETER_MAP_ROUTE } from '../../../src/components/valeter/ValeterNavSidebar';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { toast } from '../../../src/components/shared/ToastHost';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { colors } from '../../../src/constants/colors';
import { getServiceIcon } from '../../../src/constants/serviceIcons';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { themeBackgroundGradient } from '../../../src/utils/themeGradient';
import { takeHome, VALETER_PLATFORM_FEE_RATE } from '../../../src/utils/valeterEarnings';

const MONEY = '#34D399';
const STAR = '#FBBF24';
const TEXT_MAIN = '#F8FAFC';
const CHART_MONTHS = 6;
const CHART_H = 56;

type JobRow = {
  id: string;
  service_name: string | null;
  service_type: string | null;
  price: number;
  completed_at: string | null;
  created_at: string;
  location_address: string | null;
  rating: number | null;
  review: string | null;
};

type Range = 'month' | 'last' | 'all';

function toJobRow(r: any): JobRow {
  return {
    id: r.id,
    service_name: r.service_name ?? null,
    service_type: r.service_type ?? null,
    price: Number(r.price) || 0,
    completed_at: r.completed_at ?? null,
    created_at: r.created_at ?? '',
    location_address: r.location_address ?? null,
    rating: r.rating != null ? Number(r.rating) : null,
    review: typeof r.review === 'string' && r.review.trim() ? r.review.trim() : null,
  };
}

const jobDate = (o: JobRow) => new Date(o.completed_at || o.created_at);
const monthIndex = (d: Date) => d.getFullYear() * 12 + d.getMonth();

function formatMoney(n: number) {
  return `£${n.toFixed(2).replace(/\.00$/, '')}`;
}

function dayKey(d: Date) {
  return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
}

function dayLabel(d: Date) {
  const today = new Date();
  const yesterday = new Date();
  yesterday.setDate(today.getDate() - 1);
  if (dayKey(d) === dayKey(today)) return 'Today';
  if (dayKey(d) === dayKey(yesterday)) return 'Yesterday';
  return d.toLocaleDateString('en-GB', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    ...(d.getFullYear() === today.getFullYear() ? {} : { year: 'numeric' }),
  });
}

function timeLabel(d: Date) {
  return d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
}

function inRange(o: JobRow, range: Range) {
  if (range === 'all') return true;
  const diff = monthIndex(new Date()) - monthIndex(jobDate(o));
  return range === 'month' ? diff === 0 : diff === 1;
}

function Stars({ value, size = 12 }: Readonly<{ value: number; size?: number }>) {
  return (
    <View style={styles.stars}>
      {[1, 2, 3, 4, 5].map((i) => (
        <Ionicons key={i} name={i <= Math.round(value) ? 'star' : 'star-outline'} size={size} color={STAR} />
      ))}
    </View>
  );
}

function MonthBars({ orders, range, accent }: Readonly<{ orders: JobRow[]; range: Range; accent: string }>) {
  const months = useMemo(() => {
    const now = new Date();
    const current = monthIndex(now);
    const totals = new Map<number, number>();
    for (const o of orders) {
      const m = monthIndex(jobDate(o));
      if (current - m < CHART_MONTHS) totals.set(m, (totals.get(m) ?? 0) + takeHome(o.price));
    }
    return Array.from({ length: CHART_MONTHS }, (_, i) => {
      const m = current - (CHART_MONTHS - 1 - i);
      const d = new Date(Math.floor(m / 12), m % 12, 1);
      return {
        key: m,
        label: d.toLocaleDateString('en-GB', { month: 'short' }),
        total: totals.get(m) ?? 0,
        back: current - m,
      };
    });
  }, [orders]);
  const max = Math.max(...months.map((m) => m.total), 1);

  return (
    <View style={styles.chart}>
      {months.map((m) => {
        const lit = range === 'all' || (range === 'month' ? m.back === 0 : m.back === 1);
        return (
          <View key={m.key} style={styles.chartCol}>
            <View style={styles.chartTrack}>
              <Reanimated.View
                entering={FadeInDown.delay(80 + (CHART_MONTHS - m.back) * 40).springify().damping(16)}
                style={[
                  styles.chartBar,
                  {
                    height: Math.max(4, (m.total / max) * CHART_H),
                    backgroundColor: lit ? accent : 'rgba(148,163,184,0.28)',
                  },
                ]}
              />
            </View>
            <Text style={[styles.chartLabel, lit && { color: TEXT_MAIN }]}>{m.label}</Text>
          </View>
        );
      })}
    </View>
  );
}

function JobRowCard({
  job,
  accent,
  onPress,
  onLongPress,
}: Readonly<{ job: JobRow; accent: string; onPress: () => void; onLongPress: () => void }>) {
  const when = jobDate(job);
  const subtitle = [timeLabel(when), job.location_address].filter(Boolean).join(' · ');
  return (
    <PressableScale
      onPress={onPress}
      onLongPress={onLongPress}
      scaleTo={0.98}
      accessibilityLabel={`${getServiceDisplayName(job.service_type, job.service_name)}, ${formatMoney(takeHome(job.price))}`}
    >
      <GlassSurface style={styles.row} interactive fallbackColor="rgba(10,25,41,0.55)">
        <View style={[styles.rowIcon, { backgroundColor: `${accent}22`, borderColor: `${accent}44` }]}>
          <Ionicons name={getServiceIcon(job.service_type, job.service_name)} size={22} color={accent} />
        </View>
        <View style={styles.rowBody}>
          <Text style={styles.rowTitle} numberOfLines={1}>
            {getServiceDisplayName(job.service_type, job.service_name)}
          </Text>
          <Text style={styles.rowSub} numberOfLines={1}>
            {subtitle}
          </Text>
          {job.rating != null && job.rating > 0 ? (
            <View style={styles.rowRating}>
              <Stars value={job.rating} size={11} />
              {job.review ? <Ionicons name="chatbubble-ellipses-outline" size={12} color="rgba(203,213,225,0.7)" /> : null}
            </View>
          ) : null}
        </View>
        <View style={styles.rowRight}>
          <Text style={styles.rowAmount}>+{formatMoney(takeHome(job.price))}</Text>
          <Ionicons name="chevron-forward" size={14} color="rgba(203,213,225,0.5)" />
        </View>
      </GlassSurface>
    </PressableScale>
  );
}

function DetailRow({
  icon,
  label,
  value,
  valueColor,
  last = false,
}: Readonly<{ icon: React.ComponentProps<typeof Ionicons>['name']; label: string; value: string; valueColor?: string; last?: boolean }>) {
  return (
    <View style={[styles.detailRow, !last && styles.detailRowDivider]}>
      <Ionicons name={icon} size={16} color="rgba(203,213,225,0.75)" />
      <Text style={styles.detailLabel}>{label}</Text>
      <Text style={[styles.detailValue, valueColor ? { color: valueColor } : null]} numberOfLines={2}>
        {value}
      </Text>
    </View>
  );
}

const RANGE_LABEL: Record<Range, string> = { month: 'this month', last: 'last month', all: 'all time' };

const plural = (n: number, word: string) => `${n} ${word}${n === 1 ? '' : 's'}`;

function applyBookingChange(prev: JobRow[], eventType: string, row: any): JobRow[] {
  if (!row?.id) return prev;
  if (row.status === 'completed' && eventType === 'INSERT') {
    if (prev.some((o) => o.id === row.id)) return prev;
    return [toJobRow(row), ...prev].sort((a, b) => jobDate(b).getTime() - jobDate(a).getTime());
  }
  if (row.status !== 'completed' && eventType === 'UPDATE') return prev.filter((o) => o.id !== row.id);
  return prev;
}

function HeroStat({ value, label, star = false }: Readonly<{ value: string; label: string; star?: boolean }>) {
  return (
    <View style={styles.heroStat}>
      <View style={styles.heroRating}>
        {star ? <Ionicons name="star" size={14} color={STAR} /> : null}
        <Text style={styles.heroStatValue}>{value}</Text>
      </View>
      <Text style={styles.heroStatLabel}>{label}</Text>
    </View>
  );
}

function HistoryHero({ orders, visible, range }: Readonly<{ orders: JobRow[]; visible: JobRow[]; range: Range }>) {
  const stats = useMemo(() => {
    const earned = visible.reduce((sum, o) => sum + takeHome(o.price), 0);
    const rated = visible.filter((o) => o.rating != null && o.rating > 0);
    const avgRating = rated.length ? rated.reduce((s, o) => s + (o.rating ?? 0), 0) / rated.length : null;
    return { earned, avgJob: visible.length ? earned / visible.length : 0, avgRating };
  }, [visible]);

  return (
    <Reanimated.View entering={FadeInDown.springify().damping(18)}>
      <GlassSurface style={styles.hero} fallbackColor="rgba(10,25,41,0.55)">
        <LinearGradient
          colors={[`${MONEY}26`, 'transparent']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
        />
        <View style={styles.heroTop}>
          <View style={[styles.heroIcon, { backgroundColor: `${MONEY}22` }]}>
            <SymbolGlyph sf="sterlingsign.circle.fill" ion="wallet-outline" size={22} color={MONEY} />
          </View>
          <View style={styles.heroCopy}>
            <Text style={styles.heroLabel}>You earned {RANGE_LABEL[range]}</Text>
            <CountUpText value={stats.earned} format={formatMoney} style={styles.heroAmount} />
          </View>
        </View>

        <MonthBars orders={orders} range={range} accent={MONEY} />

        <View style={styles.heroStats}>
          <HeroStat value={String(visible.length)} label={visible.length === 1 ? 'job' : 'jobs'} />
          <View style={styles.heroDivider} />
          <HeroStat value={formatMoney(stats.avgJob)} label="avg per job" />
          <View style={styles.heroDivider} />
          <HeroStat value={stats.avgRating?.toFixed(1) ?? '–'} label="avg rating" star />
        </View>
      </GlassSurface>
    </Reanimated.View>
  );
}

function HistoryDays({
  visible,
  range,
  accent,
  onOpen,
  onRemove,
}: Readonly<{
  visible: JobRow[];
  range: Range;
  accent: string;
  onOpen: (job: JobRow) => void;
  onRemove: (job: JobRow) => void;
}>) {
  const days = useMemo(() => {
    const map = new Map<string, { label: string; total: number; jobs: JobRow[] }>();
    for (const o of visible) {
      const d = jobDate(o);
      const k = dayKey(d);
      const group = map.get(k) ?? { label: dayLabel(d), total: 0, jobs: [] };
      group.total += takeHome(o.price);
      group.jobs.push(o);
      map.set(k, group);
    }
    return Array.from(map, ([key, g]) => ({ key, ...g }));
  }, [visible]);

  if (days.length === 0) {
    return (
      <Reanimated.View key={`empty-${range}`} entering={FadeIn.duration(200)} style={styles.rangeEmpty}>
        <Ionicons name="calendar-clear-outline" size={20} color="rgba(203,213,225,0.7)" />
        <Text style={styles.rangeEmptyText}>No completed jobs {RANGE_LABEL[range]}</Text>
      </Reanimated.View>
    );
  }

  return (
    <Reanimated.View key={range} entering={FadeIn.duration(200)}>
      {days.map((day, di) => (
        <Reanimated.View
          key={day.key}
          entering={FadeInDown.delay(Math.min(di, 6) * 50).springify().damping(18)}
          layout={LinearTransition.springify().damping(20)}
          style={styles.day}
        >
          <View style={styles.dayHeader}>
            <Text style={styles.dayTitle}>{day.label.toUpperCase()}</Text>
            <Text style={styles.dayTotal}>
              {plural(day.jobs.length, 'job')} · {formatMoney(day.total)}
            </Text>
          </View>
          <View style={styles.dayRows}>
            {day.jobs.map((job) => (
              <JobRowCard
                key={job.id}
                job={job}
                accent={accent}
                onPress={() => onOpen(job)}
                onLongPress={() => onRemove(job)}
              />
            ))}
          </View>
        </Reanimated.View>
      ))}
      <Text style={styles.hint}>Press and hold a job to remove it</Text>
    </Reanimated.View>
  );
}

function JobDetailSheet({
  job,
  accent,
  onClose,
  onRemove,
}: Readonly<{ job: JobRow; accent: string; onClose: () => void; onRemove: (job: JobRow) => void }>) {
  const when = jobDate(job);
  const earned = takeHome(job.price);
  const rated = job.rating != null && job.rating > 0;

  return (
    <InfoBottomSheet
      visible
      onClose={onClose}
      title={getServiceDisplayName(job.service_type, job.service_name)}
      variant="header"
      accentColor={accent}
      footer={
        <View style={styles.sheetFooter}>
          <TouchableOpacity
            style={styles.sheetRemove}
            onPress={() => onRemove(job)}
            activeOpacity={0.8}
            accessibilityLabel="Remove from history"
          >
            <Ionicons name="trash-outline" size={16} color="#F87171" />
            <Text style={styles.sheetRemoveText}>Remove</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.sheetClose, { backgroundColor: accent }]} onPress={onClose} activeOpacity={0.85}>
            <Text style={styles.sheetCloseText}>Done</Text>
          </TouchableOpacity>
        </View>
      }
    >
      <View style={styles.sheetHero}>
        <View style={[styles.sheetIcon, { backgroundColor: `${accent}22`, borderColor: `${accent}55` }]}>
          <Ionicons name={getServiceIcon(job.service_type, job.service_name)} size={28} color={accent} />
        </View>
        <Text style={styles.sheetAmount}>+{formatMoney(earned)}</Text>
        <Text style={styles.sheetAmountLabel}>your take-home</Text>
      </View>

      <View style={styles.detailCard}>
        <DetailRow icon="pricetag-outline" label="Job price" value={formatMoney(job.price)} />
        <DetailRow
          icon="remove-circle-outline"
          label={`Platform fee (${Math.round(VALETER_PLATFORM_FEE_RATE * 100)}%)`}
          value={`−${formatMoney(job.price - earned)}`}
        />
        <DetailRow icon="wallet-outline" label="You earned" value={formatMoney(earned)} valueColor={MONEY} last />
      </View>

      <View style={styles.detailCard}>
        <DetailRow
          icon="calendar-outline"
          label="Completed"
          value={`${dayLabel(when)}, ${timeLabel(when)}`}
          last={!job.location_address}
        />
        {job.location_address ? (
          <DetailRow icon="location-outline" label="Address" value={job.location_address} last />
        ) : null}
      </View>

      {rated ? (
        <View style={styles.reviewCard}>
          <View style={styles.reviewTop}>
            <Text style={styles.reviewTitle}>Customer rating</Text>
            <Stars value={job.rating ?? 0} size={15} />
          </View>
          {job.review ? <Text style={styles.reviewText}>“{job.review}”</Text> : null}
        </View>
      ) : (
        <Text style={styles.noRating}>The customer hasn't rated this job yet.</Text>
      )}
    </InfoBottomSheet>
  );
}

export default function ValeterJobHistoryScreen() {
  const { user } = useAuth();
  const { theme } = useAccountTheme();
  const fit = useValeterFitInsets(10);
  const accent = theme?.primary ?? colors.SKY;
  const backgroundColors = themeBackgroundGradient(theme.background, [colors.BG, colors.headerBg ?? colors.BG]);

  const [orders, setOrders] = useState<JobRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [range, setRange] = useState<Range>('month');
  const [selected, setSelected] = useState<JobRow | null>(null);

  const loadOrders = useCallback(async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('id, service_name, service_type, price, completed_at, created_at, location_address, rating, review')
        .eq('valeter_id', user.id)
        .eq('status', 'completed')
        .order('completed_at', { ascending: false })
        .limit(1000);
      if (error) throw error;
      setOrders((data || []).map(toJobRow));
    } catch (e) {
      console.error('[ValeterJobHistory] load error', e);
      toast.error('Failed to load job history');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [user?.id]);

  useEffect(() => {
    void loadOrders();
  }, [loadOrders]);

  useEffect(() => {
    if (!user?.id) return;
    const channel = supabase
      .channel('job-history-completed')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'bookings', filter: `valeter_id=eq.${user.id}` },
        (payload) => {
          setOrders((prev) => applyBookingChange(prev, payload.eventType, payload.new ?? payload.old));
        }
      )
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [user?.id]);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    void loadOrders();
  }, [loadOrders]);

  const counts = useMemo(
    () => ({
      month: orders.filter((o) => inRange(o, 'month')).length,
      last: orders.filter((o) => inRange(o, 'last')).length,
      all: orders.length,
    }),
    [orders]
  );

  const visible = useMemo(() => orders.filter((o) => inRange(o, range)), [orders, range]);

  const removeJob = useCallback(
    (job: JobRow) => {
      if (!user?.id) return;
      void hapticFeedback('light');
      Alert.alert('Remove job', 'Permanently remove this job from your history?', [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: async () => {
            try {
              const { error } = await supabase.from('bookings').delete().eq('id', job.id).eq('valeter_id', user.id);
              if (error) throw error;
              setOrders((prev) => prev.filter((o) => o.id !== job.id));
              setSelected((cur) => (cur?.id === job.id ? null : cur));
            } catch (e: any) {
              console.error('[JobHistory] delete error', e);
              toast.error(e?.message ?? 'Could not remove job. It may be protected.');
            }
          },
        },
      ]);
    },
    [user?.id]
  );

  const clearAll = useCallback(() => {
    if (!user?.id || orders.length === 0) return;
    void hapticFeedback('light');
    const ids = orders.map((o) => o.id);
    Alert.alert('Delete all history', 'Permanently remove all these jobs from history? This cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete all',
        style: 'destructive',
        onPress: async () => {
          try {
            const { error } = await supabase.from('bookings').delete().eq('valeter_id', user.id).in('id', ids);
            if (error) throw error;
            setOrders([]);
            toast.success('All jobs have been removed from history.');
          } catch (e: any) {
            console.error('[JobHistory] delete all error', e);
            toast.error(e?.message ?? 'Some jobs could not be removed. Try removing them one by one.');
          }
        },
      },
    ]);
  }, [orders, user?.id]);

  const findWork = useCallback(() => {
    router.dismissTo({ pathname: VALETER_MAP_ROUTE, params: { sheet: 'request', sheetAt: String(Date.now()) } } as Href);
  }, []);

  let body: React.ReactNode;
  if (loading) {
    body = (
      <View style={[styles.loading, { paddingTop: fit.top }]}>
        <DefaultLoadingSkeleton message="Loading history…" variant="rich" />
      </View>
    );
  } else if (orders.length === 0) {
    body = (
      <View style={[styles.loading, { paddingTop: fit.top, paddingBottom: fit.bottom }]}>
        <BreathingEmpty
          accent={accent}
          sf="clock.arrow.circlepath"
          ion="time-outline"
          title="No completed jobs yet"
          subtitle="Finished jobs and what you earned from them will show up here."
          actionLabel="Find work"
          onAction={findWork}
        />
      </View>
    );
  } else {
    body = (
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={[styles.content, { paddingTop: fit.top, paddingBottom: fit.bottom }]}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={accent} />}
      >
        <HistoryHero orders={orders} visible={visible} range={range} />
        <SegmentedPills
          accent={accent}
          value={range}
          onChange={setRange}
          style={styles.segments}
          segments={[
            { key: 'month', label: 'This month', count: counts.month },
            { key: 'last', label: 'Last month', count: counts.last },
            { key: 'all', label: 'All', count: counts.all },
          ]}
        />
        <HistoryDays visible={visible} range={range} accent={accent} onOpen={setSelected} onRemove={removeJob} />
      </ScrollView>
    );
  }

  return (
    <View style={styles.container}>
      <LinearGradient colors={backgroundColors} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <ValeterScreenHeader
        title="Job history"
        rightAction={
          orders.length > 0 ? (
            <TouchableOpacity onPress={clearAll} style={styles.clearBtn} activeOpacity={0.7}>
              <Text style={[styles.clearText, { color: accent }]}>Clear all</Text>
            </TouchableOpacity>
          ) : null
        }
      />

      {body}

      {selected ? (
        <JobDetailSheet job={selected} accent={accent} onClose={() => setSelected(null)} onRemove={removeJob} />
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  loading: { flex: 1, paddingHorizontal: 16 },
  scroll: { flex: 1 },
  content: { paddingHorizontal: 16 },
  clearBtn: { paddingVertical: 8, paddingHorizontal: 12, justifyContent: 'center', alignItems: 'center' },
  clearText: { fontSize: 14, fontWeight: '700' },

  hero: { padding: 16, borderRadius: 24, gap: 14 },
  heroTop: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  heroIcon: { width: 46, height: 46, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  heroCopy: { flex: 1, minWidth: 0 },
  heroLabel: { color: 'rgba(203,213,225,0.85)', fontSize: 12, fontWeight: '700' },
  heroAmount: {
    color: TEXT_MAIN,
    fontSize: 32,
    fontWeight: '900',
    letterSpacing: -0.5,
    fontVariant: ['tabular-nums'],
  },
  heroStats: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: 12,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(255,255,255,0.14)',
  },
  heroStat: { flex: 1, alignItems: 'center', gap: 2 },
  heroStatValue: { color: TEXT_MAIN, fontSize: 16, fontWeight: '800', fontVariant: ['tabular-nums'] },
  heroStatLabel: { color: 'rgba(203,213,225,0.7)', fontSize: 11, fontWeight: '600' },
  heroRating: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  heroDivider: { width: 1, height: 26, backgroundColor: 'rgba(255,255,255,0.12)' },

  chart: { flexDirection: 'row', alignItems: 'flex-end', gap: 8 },
  chartCol: { flex: 1, alignItems: 'center', gap: 6 },
  chartTrack: { height: CHART_H, width: '100%', justifyContent: 'flex-end', alignItems: 'center' },
  chartBar: { width: '70%', maxWidth: 26, borderRadius: 6 },
  chartLabel: { color: 'rgba(203,213,225,0.55)', fontSize: 10, fontWeight: '700' },

  segments: { marginTop: 14, marginBottom: 18 },

  day: { marginBottom: 18 },
  dayHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 4,
    marginBottom: 8,
  },
  dayTitle: { color: 'rgba(203,213,225,0.75)', fontSize: 11, fontWeight: '800', letterSpacing: 0.9 },
  dayTotal: { color: 'rgba(203,213,225,0.75)', fontSize: 11, fontWeight: '700', fontVariant: ['tabular-nums'] },
  dayRows: { gap: 8 },

  row: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 12, borderRadius: 20 },
  rowIcon: {
    width: 44,
    height: 44,
    borderRadius: 14,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rowBody: { flex: 1, minWidth: 0, gap: 2 },
  rowTitle: { color: TEXT_MAIN, fontSize: 15, fontWeight: '800' },
  rowSub: { color: 'rgba(203,213,225,0.75)', fontSize: 12, fontWeight: '500' },
  rowRating: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 3 },
  rowRight: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  rowAmount: { color: MONEY, fontSize: 16, fontWeight: '900', fontVariant: ['tabular-nums'] },
  stars: { flexDirection: 'row', gap: 1 },

  rangeEmpty: { alignItems: 'center', gap: 8, paddingVertical: 36 },
  rangeEmptyText: { color: 'rgba(203,213,225,0.75)', fontSize: 14, fontWeight: '600' },
  hint: {
    color: 'rgba(203,213,225,0.45)',
    fontSize: 11,
    fontWeight: '600',
    textAlign: 'center',
    marginTop: 4,
  },

  sheetHero: { alignItems: 'center', paddingVertical: 8, marginBottom: 14 },
  sheetIcon: {
    width: 60,
    height: 60,
    borderRadius: 20,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
  },
  sheetAmount: { color: MONEY, fontSize: 34, fontWeight: '900', letterSpacing: -0.5, fontVariant: ['tabular-nums'] },
  sheetAmountLabel: { color: 'rgba(203,213,225,0.7)', fontSize: 12, fontWeight: '700', marginTop: 2 },
  detailCard: {
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
    paddingHorizontal: 14,
    marginBottom: 12,
  },
  detailRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 12 },
  detailRowDivider: { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: 'rgba(255,255,255,0.1)' },
  detailLabel: { color: 'rgba(203,213,225,0.8)', fontSize: 13, fontWeight: '600' },
  detailValue: {
    flex: 1,
    color: TEXT_MAIN,
    fontSize: 14,
    fontWeight: '700',
    textAlign: 'right',
    fontVariant: ['tabular-nums'],
  },
  reviewCard: {
    borderRadius: 16,
    padding: 14,
    gap: 10,
    backgroundColor: 'rgba(251,191,36,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(251,191,36,0.25)',
  },
  reviewTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  reviewTitle: { color: TEXT_MAIN, fontSize: 13, fontWeight: '800' },
  reviewText: { color: 'rgba(241,245,249,0.9)', fontSize: 14, lineHeight: 20, fontStyle: 'italic' },
  noRating: { color: 'rgba(203,213,225,0.6)', fontSize: 13, fontWeight: '600', textAlign: 'center', paddingVertical: 8 },

  sheetFooter: { flexDirection: 'row', gap: 10 },
  sheetRemove: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingHorizontal: 18,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(248,113,113,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(248,113,113,0.4)',
  },
  sheetRemoveText: { color: '#F87171', fontSize: 15, fontWeight: '800' },
  sheetClose: { flex: 1, height: 50, borderRadius: 25, alignItems: 'center', justifyContent: 'center' },
  sheetCloseText: { color: '#0A1929', fontSize: 16, fontWeight: '900' },
});
