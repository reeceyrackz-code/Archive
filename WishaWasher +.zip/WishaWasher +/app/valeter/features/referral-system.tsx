import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { View, Text, StyleSheet, Share, Platform, TextInput, Keyboard, ScrollView, useWindowDimensions } from 'react-native';
import * as Clipboard from 'expo-clipboard';
import { LinearGradient } from 'expo-linear-gradient';
import Reanimated, {
  FadeIn,
  FadeInUp,
  ZoomIn,
  useAnimatedStyle,
  useSharedValue,
  withSequence,
  withSpring,
} from 'react-native-reanimated';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import ValeterScreenHeader from '../../../src/components/valeter/ValeterScreenHeader';
import GlassSurface from '../../../src/components/shared/GlassSurface';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import InfoBottomSheet from '../../../src/components/shared/InfoBottomSheet';
import InlineToast, { type ToastState } from '../../../src/components/shared/InlineToast';
import MilestoneRoad, { roadPosition, type MilestoneStop } from '../../../src/components/valeter/MilestoneRoad';
import GlassOrb from '../../../src/components/valeter/road/GlassOrb';
import { colors } from '../../../src/constants/colors';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import type { IconGlyphName } from '../../../src/components/shared/iconGlyphTypes';
import { PressableScale, useValeterFitInsets } from '../../../src/components/shared/fit/FitKit';
import {
  getValeterReferralSummary,
  applyValeterReferralCode,
  generateValeterReferralCode,
  VALETER_REFERRAL_BONUS_POINTS,
  type ValeterReferralRow,
} from '../../../src/services/ValeterLoyaltyService';

const SKY = colors.SKY;
const BG = colors.BG;
const VALETER_BG_FALLBACK: [string, string] = ['#0A1929', '#2563EB'];
const GREEN = '#34D399';
const AMBER = '#FBBF24';
const VIOLET = '#A78BFA';
const PINK = '#F472B6';

const WEB_JOIN_BASE = 'https://wishawash.com/join';

const REFERRAL_RANKS: { count: number; name: string; blurb: string; icon: IconGlyphName; accent: string }[] = [
  { count: 0, name: 'Solo Pro', blurb: 'Share your code to bring your first Pro onboard.', icon: 'car', accent: SKY },
  { count: 1, name: 'Crew Starter', blurb: 'Your first Pro is on the road with you.', icon: 'person-add', accent: GREEN },
  { count: 3, name: 'Wash Crew', blurb: 'Three Pros earning thanks to you.', icon: 'people', accent: VIOLET },
  { count: 5, name: 'Crew Leader', blurb: 'Five Pros strong — a proper crew.', icon: 'ribbon', accent: AMBER },
  { count: 10, name: 'Fleet Captain', blurb: 'Ten Pros on the network from your code.', icon: 'trophy', accent: PINK },
  { count: 20, name: 'Valet Legend', blurb: 'Twenty Pros. The road is yours.', icon: 'diamond', accent: '#67E8F9' },
];
const THRESHOLDS = REFERRAL_RANKS.map((r) => r.count);

const HOW_IT_WORKS: { icon: IconGlyphName; title: string; body: string; accent: string }[] = [
  { icon: 'share-social', title: 'Share your code', body: 'Send your invite to another valeter.', accent: SKY },
  { icon: 'person-add', title: 'They sign up', body: 'They join as a Pro using your code.', accent: VIOLET },
  {
    icon: 'gift',
    title: 'You both earn',
    body: `They get £10 after their first job, you get +${VALETER_REFERRAL_BONUS_POINTS} pts.`,
    accent: GREEN,
  },
];

function joinLink(code: string) {
  return `${WEB_JOIN_BASE}?code=${encodeURIComponent(code)}`;
}

function buildShareMessage(code: string): string {
  return `Join me on Wish a Wash as a valeter! Use my referral code ${code} and earn £10 bonus when you complete your first job.\n\nSign up here: ${joinLink(code)}`;
}

function prosLabel(count: number): string {
  return `${count} Pro${count === 1 ? '' : 's'}`;
}

function rankStatus(reached: boolean, count: number, togo: number): string {
  if (!reached) return `${prosLabel(togo)} to go`;
  return count === 0 ? 'Your starting rank' : 'Rank unlocked';
}

export default function ValeterReferralSystem() {
  const { user } = useAuth();
  const { theme } = useAccountTheme();
  const gradientBg = (theme?.background || VALETER_BG_FALLBACK) as [string, string];
  const accent = theme?.primary ?? SKY;
  const fit = useValeterFitInsets(10);
  const { height: winH } = useWindowDimensions();
  const roadHeight = Math.round(Math.min(214, Math.max(184, winH * 0.23)));

  const [loading, setLoading] = useState(true);
  const [referralCode, setReferralCode] = useState(user?.id ? generateValeterReferralCode(user.id) : 'WAW-V-00000000');
  const [hasAppliedReferral, setHasAppliedReferral] = useState(false);
  const [referrals, setReferrals] = useState<ValeterReferralRow[]>([]);
  const [entryCode, setEntryCode] = useState('');
  const [applyingCode, setApplyingCode] = useState(false);
  const [copied, setCopied] = useState(false);
  const [crewOpen, setCrewOpen] = useState(false);
  const [codeOpen, setCodeOpen] = useState(false);
  const [toast, setToast] = useState<ToastState>(null);

  const codePop = useSharedValue(1);
  const codePopStyle = useAnimatedStyle(() => ({ transform: [{ scale: codePop.value }] }));

  const rewardedCount = useMemo(() => referrals.filter((r) => r.status === 'rewarded').length, [referrals]);

  const load = useCallback(async () => {
    if (!user?.id) {
      setLoading(false);
      return;
    }
    try {
      const summary = await getValeterReferralSummary(user.id);
      setReferralCode(summary.referralCode);
      setHasAppliedReferral(summary.referredBy);
      setReferrals(summary.referrals);
    } catch (e) {
      console.warn('[ValeterReferral] load failed:', e);
    } finally {
      setLoading(false);
    }
  }, [user?.id]);

  useEffect(() => {
    void load();
  }, [load]);

  const handleShare = useCallback(async () => {
    try {
      const message = buildShareMessage(referralCode);
      await Share.share(
        Platform.OS === 'ios' ? { message, url: joinLink(referralCode) } : { message, title: 'Join Wish a Wash' }
      );
    } catch {
      setToast({ kind: 'error', message: 'Unable to share referral code' });
    }
  }, [referralCode]);

  const handleCopy = () => {
    void Clipboard.setStringAsync(`${referralCode}\n${joinLink(referralCode)}`);
    void hapticFeedback('success');
    codePop.value = withSequence(withSpring(1.05, { damping: 8, stiffness: 400 }), withSpring(1));
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  };

  const handleApplyCode = async () => {
    if (!user?.id) return;
    const normalized = entryCode.trim().toUpperCase();
    if (!normalized) {
      setToast({ kind: 'error', message: 'Type or paste a referral code' });
      return;
    }
    if (normalized === referralCode) {
      setToast({ kind: 'error', message: "That's your own code" });
      return;
    }
    try {
      setApplyingCode(true);
      const applied = await applyValeterReferralCode(user.id, normalized);
      if (applied) {
        Keyboard.dismiss();
        await hapticFeedback('success');
        setHasAppliedReferral(true);
        setEntryCode('');
        setCodeOpen(false);
        setToast({ kind: 'success', message: 'Code applied — finish your first job to unlock it' });
        void load();
      } else {
        await hapticFeedback('error');
        setToast({ kind: 'error', message: "We couldn't find that code" });
      }
    } catch {
      setToast({ kind: 'error', message: 'Unable to apply referral code right now' });
    } finally {
      setApplyingCode(false);
    }
  };

  const stops = useMemo<MilestoneStop[]>(() => {
    const firstLocked = REFERRAL_RANKS.findIndex((r) => rewardedCount < r.count);
    return REFERRAL_RANKS.map((r, i): MilestoneStop => {
      const reached = rewardedCount >= r.count;
      const togo = r.count - rewardedCount;
      return {
        key: `rank-${r.count}`,
        label: r.count === 0 ? 'Start' : prosLabel(r.count),
        title: r.name,
        subtitle: r.count === 0 ? r.blurb : `${r.blurb} +${(r.count * VALETER_REFERRAL_BONUS_POINTS).toLocaleString()} pts in total.`,
        icon: r.icon,
        accent: r.accent,
        reached,
        status: rankStatus(reached, r.count, togo),
        action: i === firstLocked ? { label: 'Invite', icon: 'share-social', onPress: () => void handleShare() } : undefined,
      };
    });
  }, [handleShare, rewardedCount]);

  return (
    <View style={[styles.container, { backgroundColor: BG }]}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />
      <ValeterScreenHeader title="Referrals" />
      <InlineToast toast={toast} onHide={() => setToast(null)} />

      <ScrollView
        style={styles.flex}
        contentContainerStyle={[styles.content, { paddingTop: fit.top, paddingBottom: fit.bottom }]}
        showsVerticalScrollIndicator={false}
        alwaysBounceVertical={false}
        keyboardShouldPersistTaps="handled"
      >
        <MilestoneRoad
          kicker="REFERRAL ROAD"
          stops={stops}
          position={roadPosition(THRESHOLDS, rewardedCount)}
          ready={!loading}
          height={roadHeight}
        />

        <View style={styles.flex} />

        <Reanimated.View entering={FadeInUp.delay(120).springify().damping(18)}>
          <GlassSurface style={styles.ticket} fallbackColor="rgba(10,25,41,0.6)">
            <LinearGradient
              colors={[`${accent}33`, 'rgba(167,139,250,0.14)', 'transparent']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={StyleSheet.absoluteFill}
              pointerEvents="none"
            />
            <View style={styles.offerRow}>
              <GlassOrb icon="gift" accent={GREEN} size={34} glow={false} />
              <View style={styles.flex}>
                <Text style={styles.offerTitle}>Give £10, get +{VALETER_REFERRAL_BONUS_POINTS} pts</Text>
                <Text style={styles.offerSub} numberOfLines={1}>
                  Paid once your Pro finishes their first job
                </Text>
              </View>
            </View>

            <PressableScale onPress={handleCopy} haptic={false} accessibilityLabel="Copy referral code">
              <Reanimated.View style={[styles.codeBox, { borderColor: copied ? `${GREEN}99` : `${accent}55` }, codePopStyle]}>
                <View style={styles.flex}>
                  <Text style={styles.codeEyebrow}>YOUR CODE</Text>
                  <Text style={styles.codeText} numberOfLines={1} adjustsFontSizeToFit>
                    {referralCode}
                  </Text>
                </View>
                {copied ? (
                  <Reanimated.View key="copied" entering={ZoomIn.springify()} style={styles.copiedChip}>
                    <Ionicons name="checkmark" size={12} color="#06281D" />
                    <Text style={styles.copiedText}>Copied</Text>
                  </Reanimated.View>
                ) : (
                  <Reanimated.View key="copy" entering={FadeIn} style={styles.copyChip}>
                    <Ionicons name="copy-outline" size={13} color={accent} />
                    <Text style={[styles.copyText, { color: accent }]}>Copy</Text>
                  </Reanimated.View>
                )}
              </Reanimated.View>
            </PressableScale>

            <PressableScale onPress={() => void handleShare()} style={styles.shareBtn} accessibilityLabel="Share invite">
              <LinearGradient
                colors={['#34D399', '#10B981']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={StyleSheet.absoluteFill}
              />
              <Ionicons name="share-social" size={17} color="#04231A" />
              <Text style={styles.shareText}>Share invite</Text>
            </PressableScale>
          </GlassSurface>
        </Reanimated.View>

        <View style={styles.pillRow}>
          <PressableScale fill onPress={() => setCrewOpen(true)} style={styles.pillBtn} accessibilityLabel="Your crew and ranks">
            <Ionicons name="people" size={16} color={accent} />
            <Text style={styles.pillText}>Crew & ranks</Text>
            <View style={[styles.countBadge, { backgroundColor: `${accent}33` }]}>
              <Text style={[styles.countText, { color: accent }]}>{referrals.length}</Text>
            </View>
          </PressableScale>
          <PressableScale
            fill
            onPress={() => setCodeOpen(true)}
            style={styles.pillBtn}
            accessibilityLabel={hasAppliedReferral ? 'Referral code applied' : 'Have a code?'}
          >
            <Ionicons
              name={hasAppliedReferral ? 'checkmark-circle' : 'ticket-outline'}
              size={16}
              color={hasAppliedReferral ? GREEN : accent}
            />
            <Text style={styles.pillText}>{hasAppliedReferral ? 'Code applied' : 'Have a code?'}</Text>
          </PressableScale>
        </View>
      </ScrollView>

      <InfoBottomSheet
        visible={crewOpen}
        onClose={() => setCrewOpen(false)}
        title="Crew & ranks"
        accentColor={accent}
        sizeToContent
        contentMaxHeight="80%"
      >
        <Text style={styles.sheetSection}>HOW IT WORKS</Text>
        <View style={styles.howRow}>
          {HOW_IT_WORKS.map((h, i) => (
            <View key={h.title} style={styles.howTile}>
              <GlassOrb icon={h.icon} accent={h.accent} size={34} glow={false} />
              <Text style={styles.howTitle}>
                {i + 1}. {h.title}
              </Text>
              <Text style={styles.howBody}>{h.body}</Text>
            </View>
          ))}
        </View>

        <Text style={styles.sheetSection}>RANKS</Text>
        <View style={styles.sheetList}>
          {REFERRAL_RANKS.map((r) => {
            const reached = rewardedCount >= r.count;
            return (
              <View key={r.name} style={styles.rankRow}>
                <View style={reached ? null : styles.dim}>
                  <GlassOrb icon={r.icon} accent={r.accent} size={30} glow={false} />
                </View>
                <Text style={[styles.rankName, !reached && styles.dim]} numberOfLines={1}>
                  {r.name}
                </Text>
                <Text style={[styles.rankCount, { color: reached ? GREEN : 'rgba(203,213,225,0.6)' }]}>
                  {reached ? '✓' : `${r.count} Pros`}
                </Text>
              </View>
            );
          })}
        </View>

        <Text style={styles.sheetSection}>YOUR CREW</Text>
        <View style={styles.sheetList}>
          {referrals.length === 0 ? (
            <Text style={styles.emptyText}>{loading ? 'Loading…' : 'No invites yet — share your code to start your crew.'}</Text>
          ) : (
            referrals.map((r) => {
              const rewarded = r.status === 'rewarded';
              const c = rewarded ? GREEN : AMBER;
              return (
                <View key={r.id} style={styles.crewRow}>
                  <View style={[styles.avatar, { borderColor: c }]}>
                    <LinearGradient colors={[`${accent}55`, `${c}55`]} style={StyleSheet.absoluteFill} />
                    <Text style={styles.avatarText}>{r.refereeName.charAt(0).toUpperCase()}</Text>
                  </View>
                  <Text style={styles.crewName} numberOfLines={1}>
                    {r.refereeName}
                  </Text>
                  <View style={[styles.crewStatus, { backgroundColor: `${c}22` }]}>
                    <Ionicons name={rewarded ? 'checkmark-circle' : 'time'} size={12} color={c} />
                    <Text style={[styles.crewStatusText, { color: c }]}>
                      {rewarded ? `+${VALETER_REFERRAL_BONUS_POINTS} pts` : 'Pending'}
                    </Text>
                  </View>
                </View>
              );
            })
          )}
        </View>
      </InfoBottomSheet>

      <InfoBottomSheet
        visible={codeOpen}
        onClose={() => {
          Keyboard.dismiss();
          setCodeOpen(false);
        }}
        title="Have a code?"
        accentColor={accent}
        sizeToContent
        contentMaxHeight="60%"
      >
        {hasAppliedReferral ? (
          <View style={styles.appliedBox}>
            <GlassOrb icon="checkmark-circle" accent={GREEN} size={44} />
            <Text style={styles.appliedTitle}>Referral code applied</Text>
            <Text style={styles.appliedBody}>Your £10 bonus unlocks once you finish your first job.</Text>
          </View>
        ) : (
          <View style={styles.entryBlock}>
            <Text style={styles.entryHint}>Got a code from another Pro? Add it to get £10 after your first job.</Text>
            <TextInput
              value={entryCode}
              onChangeText={(t) => setEntryCode(t.toUpperCase())}
              placeholder="WAW-V-XXXXXXXX"
              placeholderTextColor="rgba(148,163,184,0.6)"
              autoCapitalize="characters"
              autoCorrect={false}
              autoFocus
              returnKeyType="done"
              onSubmitEditing={() => void handleApplyCode()}
              style={[styles.entryInput, { borderColor: `${accent}40` }]}
            />
            <PressableScale
              onPress={() => void handleApplyCode()}
              disabled={applyingCode || !entryCode.trim()}
              style={[styles.applyBtn, { backgroundColor: accent, opacity: entryCode.trim() ? 1 : 0.5 }]}
              accessibilityLabel="Apply code"
            >
              <Text style={styles.applyText}>{applyingCode ? 'Applying…' : 'Apply code'}</Text>
            </PressableScale>
          </View>
        )}
      </InfoBottomSheet>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { flexGrow: 1, paddingHorizontal: 18, gap: 10 },
  flex: { flex: 1 },
  dim: { opacity: 0.45 },

  ticket: { padding: 14, borderRadius: 22, gap: 12 },
  offerRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  offerTitle: { color: '#F8FAFC', fontSize: 15, fontWeight: '900' },
  offerSub: { color: 'rgba(203,213,225,0.75)', fontSize: 12, marginTop: 1 },
  codeBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 14,
    paddingVertical: 9,
    borderRadius: 16,
    borderWidth: 1,
    borderStyle: 'dashed',
    backgroundColor: 'rgba(0,0,0,0.22)',
  },
  codeEyebrow: { color: 'rgba(203,213,225,0.65)', fontSize: 9, fontWeight: '800', letterSpacing: 1 },
  codeText: { color: '#F8FAFC', fontSize: 19, fontWeight: '900', letterSpacing: 1.8, marginTop: 1 },
  copiedChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    height: 26,
    borderRadius: 13,
    backgroundColor: GREEN,
  },
  copiedText: { color: '#06281D', fontSize: 12, fontWeight: '900' },
  copyChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    height: 26,
    borderRadius: 13,
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  copyText: { fontSize: 12, fontWeight: '800' },
  shareBtn: {
    height: 48,
    borderRadius: 24,
    overflow: 'hidden',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  shareText: { color: '#04231A', fontSize: 15, fontWeight: '900' },

  pillRow: { flexDirection: 'row', gap: 10, height: 48 },
  pillBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 7,
    borderRadius: 24,
    backgroundColor: 'rgba(255,255,255,0.07)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  pillText: { color: '#F8FAFC', fontSize: 13.5, fontWeight: '800' },
  countBadge: { minWidth: 20, height: 20, borderRadius: 10, paddingHorizontal: 6, alignItems: 'center', justifyContent: 'center' },
  countText: { fontSize: 11, fontWeight: '900' },

  sheetSection: {
    color: 'rgba(186,230,253,0.8)',
    fontSize: 10.5,
    fontWeight: '800',
    letterSpacing: 1.2,
    marginTop: 4,
    marginBottom: 8,
  },
  howRow: { flexDirection: 'row', gap: 8, marginBottom: 14 },
  howTile: { flex: 1, gap: 5, padding: 10, borderRadius: 16, backgroundColor: 'rgba(255,255,255,0.05)' },
  howTitle: { color: '#F8FAFC', fontSize: 12, fontWeight: '800' },
  howBody: { color: 'rgba(203,213,225,0.75)', fontSize: 11, lineHeight: 15 },
  sheetList: { gap: 6, marginBottom: 14 },
  rankRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 4 },
  rankName: { flex: 1, color: '#F8FAFC', fontSize: 13.5, fontWeight: '800' },
  rankCount: { fontSize: 12, fontWeight: '800' },
  crewRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    padding: 10,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  avatar: {
    width: 34,
    height: 34,
    borderRadius: 17,
    borderWidth: 2,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: { color: '#F8FAFC', fontSize: 14, fontWeight: '900' },
  crewName: { flex: 1, color: '#F8FAFC', fontSize: 14, fontWeight: '700' },
  crewStatus: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 9, height: 24, borderRadius: 12 },
  crewStatusText: { fontSize: 11.5, fontWeight: '800' },
  emptyText: { color: 'rgba(203,213,225,0.75)', fontSize: 13, textAlign: 'center', paddingVertical: 14 },

  appliedBox: { alignItems: 'center', gap: 8, paddingVertical: 12 },
  appliedTitle: { color: '#F8FAFC', fontSize: 16, fontWeight: '900' },
  appliedBody: { color: 'rgba(203,213,225,0.8)', fontSize: 13, textAlign: 'center' },
  entryBlock: { gap: 12 },
  entryHint: { color: 'rgba(203,213,225,0.8)', fontSize: 13, lineHeight: 18 },
  entryInput: {
    color: '#F8FAFC',
    fontSize: 17,
    fontWeight: '800',
    letterSpacing: 1.2,
    paddingHorizontal: 14,
    paddingVertical: 13,
    borderRadius: 14,
    borderWidth: 1,
    backgroundColor: 'rgba(0,0,0,0.22)',
  },
  applyBtn: { height: 48, borderRadius: 24, alignItems: 'center', justifyContent: 'center' },
  applyText: { color: '#0A1929', fontSize: 15, fontWeight: '900' },
});
