import { Redirect } from 'expo-router';

export default function ValeterOnboarding() {
  return <Redirect href="/valeter/terms" />;
}
