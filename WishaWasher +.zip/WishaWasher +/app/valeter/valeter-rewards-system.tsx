import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { View, Text, StyleSheet, Alert, ScrollView, useWindowDimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import Reanimated, { Easing, FadeInDown, FadeInUp, useAnimatedStyle, useSharedValue, withTiming } from 'react-native-reanimated';
import { ChromeGlyph as Ionicons } from '../../src/components/shared/ChromeGlyph';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import ValeterScreenHeader from '../../src/components/valeter/ValeterScreenHeader';
import GlassSurface from '../../src/components/shared/GlassSurface';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import InfoBottomSheet from '../../src/components/shared/InfoBottomSheet';
import InlineToast, { type ToastState } from '../../src/components/shared/InlineToast';
import MilestoneRoad, { roadPosition, type MilestoneStop } from '../../src/components/valeter/MilestoneRoad';
import GlassOrb from '../../src/components/valeter/road/GlassOrb';
import { colors } from '../../src/constants/colors';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import type { IconGlyphName } from '../../src/components/shared/iconGlyphTypes';
import { CountUpText, PressableScale, SegmentedPills, useValeterFitInsets } from '../../src/components/shared/fit/FitKit';
import {
  getValeterLoyaltyBalance,
  getValeterLoyaltyActivity,
  redeemValeterReward,
  getValeterTierProgress,
  VALETER_REWARDS,
  VALETER_POINTS_PER_JOB,
  VALETER_POINTS_FIVE_STAR,
  VALETER_REFERRAL_BONUS_POINTS,
  formatRelativeDate,
  type ValeterReward,
} from '../../src/services/ValeterLoyaltyService';

const SKY = colors.SKY;
const BG = colors.BG;
const VALETER_BG_FALLBACK: [string, string] = ['#0A1929', '#2563EB'];
const GREEN = '#34D399';
const AMBER = '#FBBF24';
const VIOLET = '#A78BFA';
const PINK = '#F472B6';

const REWARD_ACCENTS = [SKY, VIOLET, AMBER, PINK, GREEN];
const THRESHOLDS = [0, ...VALETER_REWARDS.map((r) => r.points)];

type ActivityRow = { id: string; label: string; pointsLabel: string; date: string; kind: 'earn' | 'redeem' };
type SheetTab = 'rewards' | 'history';

function TierBar({ ratio, color }: Readonly<{ ratio: number; color: string }>) {
  const w = useSharedValue(0);
  useEffect(() => {
    w.value = withTiming(Math.max(0, Math.min(1, ratio)), { duration: 800, easing: Easing.out(Easing.cubic) });
  }, [w, ratio]);
  const style = useAnimatedStyle(() => ({ width: `${w.value * 100}%` }));
  return (
    <View style={styles.barTrack}>
      <Reanimated.View style={[styles.barFill, { backgroundColor: color }, style]} />
    </View>
  );
}

const EARN: { key: string; label: string; pts: number; icon: IconGlyphName; color: string }[] = [
  { key: 'job', label: 'Finish a job', pts: VALETER_POINTS_PER_JOB, icon: 'checkmark-circle', color: SKY },
  { key: 'star', label: 'Get 5★', pts: VALETER_POINTS_FIVE_STAR, icon: 'star', color: AMBER },
  { key: 'refer', label: 'Refer a Pro', pts: VALETER_REFERRAL_BONUS_POINTS, icon: 'people', color: VIOLET },
];

export default function ValeterRewardsSystem() {
  const { user, updateUser } = useAuth();
  const { theme } = useAccountTheme();
  const gradientBg = (theme?.background || VALETER_BG_FALLBACK) as [string, string];
  const accent = theme?.primary ?? SKY;
  const fit = useValeterFitInsets(10);
  const { height: winH } = useWindowDimensions();
  const roadHeight = Math.round(Math.min(214, Math.max(184, winH * 0.23)));

  const [loading, setLoading] = useState(true);
  const [redeemingId, setRedeemingId] = useState<string | null>(null);
  const [points, setPoints] = useState(0);
  const [completedJobs, setCompletedJobs] = useState(0);
  const [activity, setActivity] = useState<ActivityRow[]>([]);
  const [sheetOpen, setSheetOpen] = useState(false);
  const [sheetTab, setSheetTab] = useState<SheetTab>('rewards');
  const [toast, setToast] = useState<ToastState>(null);

  const load = useCallback(async () => {
    if (!user?.id) {
      setLoading(false);
      return;
    }
    try {
      const [balance, activityRows] = await Promise.all([
        getValeterLoyaltyBalance(user.id),
        getValeterLoyaltyActivity(user.id),
      ]);
      setPoints(balance.points);
      setCompletedJobs(balance.completedJobs);
      setActivity(activityRows);
    } catch (e) {
      console.warn('[ValeterRewards] load failed:', e);
    } finally {
      setLoading(false);
    }
  }, [user?.id]);

  useEffect(() => {
    void load();
  }, [load]);

  const handleRedeem = useCallback(
    (reward: ValeterReward) => {
      if (!user?.id || redeemingId || points < reward.points) return;
      Alert.alert('Redeem reward', `Spend ${reward.points.toLocaleString()} points to unlock "${reward.title}"?`, [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Redeem',
          onPress: () => {
            void (async () => {
              try {
                setRedeemingId(reward.id);
                const next = await redeemValeterReward(user.id, reward);
                if (updateUser) await updateUser({ tierPoints: next });
                setPoints(next);
                setActivity(await getValeterLoyaltyActivity(user.id));
                await hapticFeedback('success');
                setToast({ kind: 'success', message: `"${reward.title}" added to your account` });
              } catch (err: any) {
                await hapticFeedback('error');
                setToast({ kind: 'error', message: err?.message || 'Unable to redeem right now' });
              } finally {
                setRedeemingId(null);
              }
            })();
          },
        },
      ]);
    },
    [points, redeemingId, updateUser, user?.id]
  );

  const stops = useMemo<MilestoneStop[]>(() => {
    const start: MilestoneStop = {
      key: 'start',
      label: 'Start',
      title: 'Your rewards road',
      subtitle: `Every job, 5★ rating and referral moves the van forward.`,
      icon: 'flag',
      accent: SKY,
      reached: true,
      status: `${completedJobs} job${completedJobs === 1 ? '' : 's'} done`,
    };
    return [
      start,
      ...VALETER_REWARDS.map((r, i): MilestoneStop => {
        const reached = points >= r.points;
        return {
          key: r.id,
          label: `${r.points.toLocaleString()} pts`,
          title: r.title,
          subtitle: r.description,
          icon: r.icon as IconGlyphName,
          accent: REWARD_ACCENTS[i % REWARD_ACCENTS.length]!,
          reached,
          status: reached ? 'Ready to redeem' : `${(r.points - points).toLocaleString()} pts to go`,
          action: reached
            ? { label: 'Redeem', icon: 'gift', onPress: () => handleRedeem(r), busy: redeemingId === r.id }
            : undefined,
        };
      }),
    ];
  }, [completedJobs, handleRedeem, points, redeemingId]);

  const readyCount = VALETER_REWARDS.filter((r) => points >= r.points).length;
  const tierInfo = getValeterTierProgress(points);

  const openSheet = (tab: SheetTab) => {
    setSheetTab(tab);
    setSheetOpen(true);
  };

  return (
    <View style={[styles.container, { backgroundColor: BG }]}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />
      <ValeterScreenHeader title="Rewards" />
      <InlineToast toast={toast} onHide={() => setToast(null)} />

      <ScrollView
        style={styles.flex}
        contentContainerStyle={[styles.content, { paddingTop: fit.top, paddingBottom: fit.bottom }]}
        showsVerticalScrollIndicator={false}
        alwaysBounceVertical={false}
      >
        <Reanimated.View entering={FadeInDown.springify().damping(18)}>
          <GlassSurface style={styles.pointsCard} fallbackColor="rgba(10,25,41,0.6)">
            <LinearGradient
              colors={[`${tierInfo.color}33`, 'transparent']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={StyleSheet.absoluteFill}
              pointerEvents="none"
            />
            <View style={styles.pointsRow}>
              <CountUpText value={loading ? 0 : points} style={styles.points} />
              <Text style={styles.pointsUnit}>pts</Text>
              <View style={styles.flex} />
              <View style={[styles.tierChip, { borderColor: `${tierInfo.color}88`, backgroundColor: `${tierInfo.color}22` }]}>
                <Ionicons name="ribbon" size={13} color={tierInfo.color} />
                <Text style={[styles.tierChipText, { color: tierInfo.color }]}>{tierInfo.tier}</Text>
              </View>
            </View>
            <TierBar ratio={tierInfo.progress / 100} color={tierInfo.color} />
            <Text style={styles.tierHint} numberOfLines={1}>
              {tierInfo.nextTier ? `${tierInfo.pointsToNext.toLocaleString()} pts to ${tierInfo.nextTier}` : 'Top tier reached'}
            </Text>
          </GlassSurface>
        </Reanimated.View>

        <MilestoneRoad
          kicker="REWARDS ROAD"
          stops={stops}
          position={roadPosition(THRESHOLDS, points)}
          ready={!loading}
          height={roadHeight}
        />

        <View style={styles.flex} />

        <Reanimated.View entering={FadeInUp.delay(120).springify().damping(18)} style={styles.earnBlock}>
          <Text style={styles.sectionLabel}>EARN POINTS</Text>
          <View style={styles.earnRow}>
            {EARN.map((e) => (
              <PressableScale
                key={e.key}
                fill
                haptic={e.key === 'refer'}
                onPress={e.key === 'refer' ? () => router.push('/valeter/features/referral-system' as any) : undefined}
                style={styles.earnTile}
                accessibilityLabel={`${e.label}, plus ${e.pts} points`}
              >
                <GlassOrb icon={e.icon} accent={e.color} size={30} glow={false} />
                <Text style={[styles.earnPts, { color: e.color }]}>+{e.pts}</Text>
                <Text style={styles.earnLabel} numberOfLines={1}>
                  {e.label}
                </Text>
              </PressableScale>
            ))}
          </View>
        </Reanimated.View>

        <PressableScale
          onPress={() => openSheet('rewards')}
          style={[styles.allBtn, { borderColor: `${accent}44` }]}
          accessibilityLabel="All rewards and history"
        >
          <Ionicons name="gift-outline" size={16} color={accent} />
          <Text style={styles.allBtnText}>All rewards & history</Text>
          {readyCount > 0 ? (
            <View style={styles.readyBadge}>
              <Text style={styles.readyBadgeText}>{readyCount}</Text>
            </View>
          ) : null}
          <Ionicons name="chevron-forward" size={15} color="rgba(226,232,240,0.6)" />
        </PressableScale>
      </ScrollView>

      <InfoBottomSheet
        visible={sheetOpen}
        onClose={() => setSheetOpen(false)}
        title="Rewards"
        accentColor={accent}
        sizeToContent
        contentMaxHeight="78%"
      >
        <SegmentedPills
          segments={[
            { key: 'rewards', label: 'Rewards', count: readyCount || undefined },
            { key: 'history', label: 'History' },
          ]}
          value={sheetTab}
          onChange={(k) => setSheetTab(k as SheetTab)}
          accent={accent}
          height={36}
          style={styles.sheetTabs}
        />
        {sheetTab === 'rewards' ? (
          <View style={styles.sheetList}>
            {VALETER_REWARDS.map((r, i) => {
              const reached = points >= r.points;
              const c = REWARD_ACCENTS[i % REWARD_ACCENTS.length]!;
              return (
                <View key={r.id} style={styles.sheetRow}>
                  <View style={reached ? null : styles.dim}>
                    <GlassOrb icon={r.icon as IconGlyphName} accent={c} size={36} glow={false} />
                  </View>
                  <View style={styles.sheetRowText}>
                    <Text style={styles.sheetRowTitle} numberOfLines={1}>
                      {r.title}
                    </Text>
                    <Text style={styles.sheetRowSub} numberOfLines={1}>
                      {r.description}
                    </Text>
                    {!reached ? <TierBar ratio={points / r.points} color={c} /> : null}
                  </View>
                  {reached ? (
                    <PressableScale
                      onPress={() => handleRedeem(r)}
                      disabled={!!redeemingId}
                      style={[styles.redeemBtn, { backgroundColor: GREEN }]}
                      accessibilityLabel={`Redeem ${r.title}`}
                    >
                      <Text style={styles.redeemText}>{redeemingId === r.id ? '…' : 'Redeem'}</Text>
                    </PressableScale>
                  ) : (
                    <Text style={[styles.sheetRowPts, { color: c }]}>{r.points.toLocaleString()}</Text>
                  )}
                </View>
              );
            })}
          </View>
        ) : (
          <View style={styles.sheetList}>
            {activity.length === 0 ? (
              <Text style={styles.emptyText}>{loading ? 'Loading…' : 'No points activity yet — finish a job to start.'}</Text>
            ) : (
              activity.slice(0, 20).map((a) => {
                const earn = a.kind === 'earn';
                return (
                  <View key={a.id} style={styles.sheetRow}>
                    <GlassOrb icon={earn ? 'add' : 'gift'} accent={earn ? GREEN : PINK} size={32} glow={false} />
                    <View style={styles.sheetRowText}>
                      <Text style={styles.sheetRowTitle} numberOfLines={1}>
                        {a.label}
                      </Text>
                      <Text style={styles.sheetRowSub}>{formatRelativeDate(a.date)}</Text>
                    </View>
                    <Text style={[styles.sheetRowPts, { color: earn ? GREEN : PINK }]}>{a.pointsLabel}</Text>
                  </View>
                );
              })
            )}
          </View>
        )}
      </InfoBottomSheet>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { flexGrow: 1, paddingHorizontal: 18, gap: 10 },
  flex: { flex: 1 },
  dim: { opacity: 0.45 },

  pointsCard: { paddingHorizontal: 14, paddingVertical: 12, borderRadius: 22, gap: 8 },
  pointsRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  points: { color: '#F8FAFC', fontSize: 28, fontWeight: '900', letterSpacing: -0.5, fontVariant: ['tabular-nums'] },
  pointsUnit: { color: 'rgba(203,213,225,0.75)', fontSize: 13, fontWeight: '800', marginTop: 8 },
  tierChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 11,
    paddingVertical: 6,
    borderRadius: 999,
    borderWidth: 1,
  },
  tierChipText: { fontSize: 13, fontWeight: '900' },
  tierHint: { color: 'rgba(226,232,240,0.75)', fontSize: 11.5, fontWeight: '600' },
  barTrack: { height: 6, borderRadius: 3, backgroundColor: 'rgba(255,255,255,0.1)', overflow: 'hidden' },
  barFill: { height: '100%', borderRadius: 3 },

  earnBlock: { gap: 6 },
  sectionLabel: { color: 'rgba(186,230,253,0.8)', fontSize: 10.5, fontWeight: '800', letterSpacing: 1.2 },
  earnRow: { flexDirection: 'row', gap: 8, height: 84 },
  earnTile: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 3,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.06)',
    paddingHorizontal: 4,
  },
  earnPts: { fontSize: 15, fontWeight: '900' },
  earnLabel: { color: 'rgba(226,232,240,0.8)', fontSize: 11, fontWeight: '700' },

  allBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    height: 48,
    paddingHorizontal: 16,
    borderRadius: 24,
    borderWidth: 1,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  allBtnText: { flex: 1, color: '#F8FAFC', fontSize: 14, fontWeight: '800' },
  readyBadge: {
    minWidth: 20,
    height: 20,
    borderRadius: 10,
    paddingHorizontal: 6,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: GREEN,
  },
  readyBadgeText: { color: '#06281D', fontSize: 11, fontWeight: '900' },

  sheetTabs: { marginBottom: 12 },
  sheetList: { gap: 8 },
  sheetRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 10,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  sheetRowText: { flex: 1, minWidth: 0, gap: 3 },
  sheetRowTitle: { color: '#F8FAFC', fontSize: 14, fontWeight: '800' },
  sheetRowSub: { color: 'rgba(203,213,225,0.75)', fontSize: 12 },
  sheetRowPts: { fontSize: 13, fontWeight: '900' },
  redeemBtn: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 999 },
  redeemText: { color: '#06281D', fontSize: 13, fontWeight: '900' },
  emptyText: { color: 'rgba(203,213,225,0.75)', fontSize: 13, textAlign: 'center', paddingVertical: 18 },
});
