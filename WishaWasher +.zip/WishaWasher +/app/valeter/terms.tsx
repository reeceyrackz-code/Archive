import React from 'react';
import ProSetupWizard from '../../src/components/valeter/onboarding/ProSetupWizard';

export default function ValeterTermsScreen() {
  return (
    <ProSetupWizard
      version="v1.0"
      continuePath="/valeter/stripe-connect?mode=onboarding"
      blockedPath="/valeter/terms-blocked"
    />
  );
}
