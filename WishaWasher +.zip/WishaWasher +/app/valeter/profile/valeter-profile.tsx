// app/valeter/profile/valeter-profile.tsx
/**
 * Pro profile hub: identity card, quick stats, account health (payouts + documents),
 * then grouped settings (Work, Money, Growth, Account, Support).
 */
import React, { useState, useEffect, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Alert,
  Image,
  Switch,
  Platform,
  ActionSheetIOS,
  ScrollView,
  ActivityIndicator,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import Reanimated, { FadeIn, FadeInDown } from 'react-native-reanimated';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system/legacy';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import type { IconGlyphName } from '../../../src/components/shared/iconGlyphTypes';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { ValeterStatsService, ValeterPerformanceStats } from '../../../src/services/Valeterstatsservice';
import { fetchRadiusPreference } from '../../../src/utils/radiusPreference';
import { supabase } from '../../../src/lib/supabase';
import { VALETER_CONTENT_BOTTOM_PAD } from '../../../src/components/valeter/ValeterNavSidebar';
import ValeterScreenHeader from '../../../src/components/valeter/ValeterScreenHeader';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import GlassSurface from '../../../src/components/shared/GlassSurface';
import GlassOrb from '../../../src/components/valeter/road/GlassOrb';
import { PressableScale, useValeterFitInsets } from '../../../src/components/shared/fit/FitKit';
import { colors } from '../../../src/constants/colors';
import { VALETER_BG_FALLBACK, VALETER_PRIMARY_HEX } from '../../../src/constants/accountThemes';
import LoadingScreen from '../../../src/components/LoadingScreen';
import StripeStatusPill, { useValeterStripeStatus } from '../../../src/components/valeter/StripeStatusPill';
import { getServicesOfferedFromSettings, type ValeterServiceSettingsRow } from '../../../src/utils/valeterServicesOffered';
import { toast } from '../../../src/components/shared/ToastHost';

const SKY = colors.SKY ?? VALETER_PRIMARY_HEX;
const GOLD = '#E8C547';
const GREEN = '#34D399';
const AMBER = '#FBBF24';
const RED = '#F87171';
const VIOLET = '#A78BFA';
const PINK = '#F472B6';
const CYAN = '#22D3EE';
const AVATAR = 92;

interface ValeterProfileData {
  user_id: string;
  full_name: string;
  bio?: string;
  experience?: string;
  profile_photo_url?: string;
  vehicle_make?: string;
  vehicle_model?: string;
  vehicle_registration?: string;
  vehicle_photo_url?: string | null;
  verification_status: 'pending' | 'verified' | 'rejected';
  verification_badge: boolean;
  is_self_sufficient?: boolean;
  services_offered?: string[] | null;
}

type BookingRow = {
  id: string;
  valeter_id: string | null;
  status: string;
  price: number | string | null;
  scheduled_at: string;
  completed_at: string | null;
  updated_at: string;
};

type MenuRow = {
  key: string;
  icon: IconGlyphName;
  color: string;
  title: string;
  sub?: string;
  route?: string;
  onPress?: () => void;
  right?: React.ReactNode;
  value?: string;
};

const IMAGE_MEDIA_TYPES: any =
  (ImagePicker as any)?.MediaType?.Images ? [(ImagePicker as any).MediaType.Images] : undefined;

const getExtAndMimeFromUri = (uri: string) => {
  const clean = (uri || '').split('?')[0];
  const extRaw = (clean.split('.').pop() || 'jpg').toLowerCase();
  const ext = extRaw === 'jpg' ? 'jpeg' : extRaw;

  let mime = 'image/jpeg';
  if (ext === 'png') mime = 'image/png';
  else if (ext === 'webp') mime = 'image/webp';
  else if (ext === 'heic') mime = 'image/heic';
  else if (ext === 'heif') mime = 'image/heif';

  return { extRaw, ext, mime };
};

const VERIFICATION_META: Record<ValeterProfileData['verification_status'], { label: string; color: string; icon: IconGlyphName }> = {
  verified: { label: 'Verified', color: GREEN, icon: 'shield-checkmark' },
  pending: { label: 'In review', color: AMBER, icon: 'time' },
  rejected: { label: 'Action needed', color: RED, icon: 'alert-circle' },
};

function StatusChip({ label, color, icon }: Readonly<{ label: string; color: string; icon: IconGlyphName }>) {
  return (
    <View style={[styles.chip, { backgroundColor: `${color}22`, borderColor: `${color}77` }]}>
      <Ionicons name={icon} size={12} color={color} />
      <Text style={[styles.chipText, { color }]}>{label}</Text>
    </View>
  );
}

function MenuGroup({
  title,
  rows,
  textMain,
  textMuted,
  delay,
  onNavigate,
}: Readonly<{
  title: string;
  rows: MenuRow[];
  textMain: string;
  textMuted: string;
  delay: number;
  onNavigate: (route: string) => void;
}>) {
  return (
    <Reanimated.View entering={FadeInDown.delay(delay).springify().damping(18)}>
      <Text style={styles.groupLabel}>{title}</Text>
      <GlassSurface style={styles.group} fallbackColor="rgba(10,25,41,0.5)">
        {rows.map((row, i) => (
          <PressableScale
            key={row.key}
            scaleTo={0.98}
            onPress={row.onPress ?? (row.route ? () => onNavigate(row.route!) : undefined)}
            style={[styles.row, i < rows.length - 1 && styles.rowDivider]}
            accessibilityLabel={row.title}
          >
            <GlassOrb icon={row.icon} accent={row.color} size={36} glow={false} />
            <View style={styles.rowBody}>
              <Text style={[styles.rowTitle, { color: textMain }]} numberOfLines={1}>
                {row.title}
              </Text>
              {row.sub ? (
                <Text style={[styles.rowSub, { color: textMuted }]} numberOfLines={1}>
                  {row.sub}
                </Text>
              ) : null}
            </View>
            {row.value ? <Text style={[styles.rowValue, { color: textMuted }]}>{row.value}</Text> : null}
            {row.right ?? <Ionicons name="chevron-forward" size={16} color="rgba(226,232,240,0.45)" />}
          </PressableScale>
        ))}
      </GlassSurface>
    </Reanimated.View>
  );
}

function base64ToUint8Array(base64: string) {
  const binary = globalThis.atob ? globalThis.atob(base64) : Buffer.from(base64, 'base64').toString('binary');
  const len = binary.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) bytes[i] = binary.codePointAt(i) ?? 0;
  return bytes;
}

function profileUploadError(error: { message?: string }) {
  const msg = String(error?.message || '').toLowerCase();
  if (msg.includes('bucket') || msg.includes('not found')) {
    return new Error("Storage bucket 'valeter_documents' was not found or is not accessible.");
  }
  if (msg.includes('row-level security') || msg.includes('policy') || msg.includes('permission')) {
    return new Error('Upload blocked by storage policy. Please update Supabase Storage RLS for valeter uploads.');
  }
  return error;
}

function experienceLabelFor(experience: string | null | undefined, months: number) {
  if (experience) return `${experience} experience`;
  if (months >= 12) return `${Math.floor(months / 12)}+ yrs experience`;
  return null;
}

function radiusLabel(miles: number | null) {
  return miles == null ? null : `${miles} mi radius`;
}

function plural(n: number, word: string) {
  return `${n} ${word}${n === 1 ? '' : 's'}`;
}

function profileStatCards(
  today: { jobsCompleted: number; earnings: number },
  earningsThisMonth: number,
  stats: ValeterPerformanceStats
) {
  const rating = Number(stats.averageRating || 0);
  return [
    {
      key: 'today',
      label: 'Today',
      value: `£${Number(today.earnings || 0).toFixed(0)}`,
      sub: plural(today.jobsCompleted, 'job'),
      color: GREEN,
      route: '/valeter/features/job-history',
      starred: false,
    },
    {
      key: 'month',
      label: 'This month',
      value: `£${earningsThisMonth.toFixed(0)}`,
      sub: `${stats.jobsThisMonth} jobs`,
      color: GOLD,
      route: '/valeter/features/job-history',
      starred: false,
    },
    {
      key: 'rating',
      label: 'Rating',
      value: rating > 0 ? rating.toFixed(1) : '—',
      sub: plural(stats.customerReviews, 'review'),
      color: AMBER,
      route: '/valeter/valeter-analytics',
      starred: rating > 0,
    },
  ];
}

type PhotoSource = 'camera' | 'library';

const PHOTO_COPY: Record<PhotoSource, { denied: string; failed: string }> = {
  camera: { denied: 'Camera permission is required to take a photo.', failed: 'Failed to take photo. Please try again.' },
  library: { denied: 'Gallery permission is required to select a photo.', failed: 'Failed to select image. Please try again.' },
};

/** Asks for permission, opens the camera or gallery, and returns the square-cropped photo's uri (or null). */
async function pickProfilePhoto(source: PhotoSource): Promise<string | null> {
  const camera = source === 'camera';
  const perm = camera
    ? await ImagePicker.requestCameraPermissionsAsync()
    : await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (perm.status !== 'granted') {
    toast.error(PHOTO_COPY[source].denied, 'Permission Required');
    return null;
  }
  const options = { mediaTypes: IMAGE_MEDIA_TYPES, allowsEditing: true, aspect: [1, 1] as [number, number], quality: 0.8 };
  const result = camera ? await ImagePicker.launchCameraAsync(options) : await ImagePicker.launchImageLibraryAsync(options);
  if (result.canceled) return null;
  return result.assets?.[0]?.uri ?? null;
}

export default function ValeterProfile() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const fit = useValeterFitInsets(10);
  const { theme, mode, toggleMode } = useAccountTheme();
  const gradientBg = theme?.background ?? VALETER_BG_FALLBACK;
  const primaryColor = theme?.primary ?? SKY;
  const textMain = theme?.textPrimary ?? '#F9FAFB';
  const textMuted = theme?.textSecondary ?? 'rgba(249,250,251,0.7)';
  const { user, logout } = useAuth();
  const stripeStatus = useValeterStripeStatus(user?.id);

  const [profile, setProfile] = useState<ValeterProfileData | null>(null);
  const [profilePicture, setProfilePicture] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [uploadingPicture, setUploadingPicture] = useState(false);

  const [valeterStats, setValeterStats] = useState<ValeterPerformanceStats>({
    totalJobs: 0,
    experienceMonths: 1,
    averageRating: 0,
    totalEarnings: 0,
    jobsThisMonth: 0,
    customerReviews: 0,
    onTimePercentage: 100,
    cancellationRate: 0,
  });

  const [todayStats, setTodayStats] = useState({ jobsCompleted: 0, earnings: 0 });
  const [serviceRadiusMiles, setServiceRadiusMiles] = useState<number | null>(null);
  const [earningsThisMonth, setEarningsThisMonth] = useState<number>(0);
  const [serviceSettings, setServiceSettings] = useState<ValeterServiceSettingsRow | null>(null);

  const servicesOfferedDisplay = useMemo(() => getServicesOfferedFromSettings(serviceSettings), [serviceSettings]);

  const getDayRangeISO = () => {
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    const end = new Date(start);
    end.setDate(end.getDate() + 1);
    return { startISO: start.toISOString(), endISO: end.toISOString() };
  };

  const computeTodayOverviewFromSchema = async (userId: string) => {
    const { startISO, endISO } = getDayRangeISO();
    const { data, error } = await supabase
      .from('bookings')
      .select('id,valeter_id,status,price,scheduled_at,completed_at,updated_at')
      .eq('valeter_id', userId)
      .eq('status', 'completed')
      .gte('completed_at', startISO)
      .lt('completed_at', endISO);
    if (error) throw error;
    const rows = (data || []) as BookingRow[];
    const earnings = rows.reduce((sum, b) => {
      const n = Number(b.price ?? 0);
      return sum + (Number.isFinite(n) ? n : 0);
    }, 0);
    return { jobsCompleted: rows.length, earnings: Math.round(earnings * 100) / 100 };
  };

  useEffect(() => {
    const fetchStats = async () => {
      if (!user?.id) return;
      try {
        const [stats, today] = await Promise.all([
          ValeterStatsService.getValeterStats(user.id),
          computeTodayOverviewFromSchema(user.id),
        ]);
        setValeterStats(stats);
        setTodayStats(today);
      } catch (error) {
        console.error('Error fetching valeter stats:', error);
      }
    };
    void fetchStats();
  }, [user?.id]);

  useEffect(() => {
    if (user?.id) {
      void loadProfile();
      Promise.all([loadServiceRadiusAndEarnings(), loadServiceSettings()]).catch((error) => {
        console.error('Error loading secondary profile data:', error);
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const loadServiceRadiusAndEarnings = async () => {
    if (!user?.id) return;
    try {
      const { value: radiusMi } = await fetchRadiusPreference(user.id);
      setServiceRadiusMiles(radiusMi ?? null);
      const now = new Date();
      const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const { data } = await supabase
        .from('bookings')
        .select('price')
        .eq('valeter_id', user.id)
        .eq('status', 'completed')
        .gte('completed_at', firstDayOfMonth.toISOString());
      const total = (data || []).reduce((sum, b) => sum + (Number((b as any).price) || 0), 0);
      setEarningsThisMonth(total);
    } catch (e) {
      console.warn('Error loading radius/earnings:', e);
    }
  };

  const loadServiceSettings = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('valeter_service_settings')
        .select('tier_pricing, detailing_offered, detailing_menu')
        .eq('valeter_id', user.id)
        .maybeSingle();
      if (!error && data) setServiceSettings(data);
    } catch {
      // table may not exist yet
    }
  };

  const loadProfile = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase.from('valeter_profiles').select('*').eq('user_id', user!.id).maybeSingle();
      if (error && error.code !== 'PGRST116') throw error;

      if (data) {
        setProfile(data);
        setProfilePicture(data.profile_photo_url || null);
      } else {
        const newProfile: Partial<ValeterProfileData> = {
          user_id: user!.id,
          full_name: (user as any)?.name || 'Car Care Pro',
          bio: 'Professional mobile car care pro',
          experience: '0 years',
          verification_status: 'pending',
          verification_badge: false,
        };
        const { data: created, error: createError } = await supabase.from('valeter_profiles').insert(newProfile).select().single();
        if (createError) throw createError;
        setProfile(created);
      }
    } catch (error) {
      console.error('Error loading profile:', error);
      toast.error('Failed to load profile');
    } finally {
      setIsLoading(false);
    }
  };

  const BUCKET = 'valeter_documents';

  async function uploadUriToSupabase(uri: string, path: string, contentType = 'image/jpeg') {
    const base64 = await FileSystem.readAsStringAsync(uri, { encoding: 'base64' as any });
    const bytes = base64ToUint8Array(base64);
    const { data, error } = await supabase.storage.from(BUCKET).upload(path, bytes, { contentType, upsert: true });

    if (error) throw profileUploadError(error);

    const { data: pub } = supabase.storage.from(BUCKET).getPublicUrl(data?.path ?? path);
    return { path: data?.path ?? path, publicUrl: pub?.publicUrl ?? null };
  }

  const persistProfilePhotoUrl = async (publicUrl: string) => {
    if (!user?.id) throw new Error('No user');
    const profileUpsert = await supabase.from('valeter_profiles').upsert(
      {
        user_id: user.id,
        profile_photo_url: publicUrl,
        full_name: (profile?.full_name || user?.name || ' ').trim() || ' ',
      },
      { onConflict: 'user_id' }
    );
    if (profileUpsert.error) throw profileUpsert.error;
    await supabase.from('profiles').update({ profile_picture: publicUrl }).eq('id', user.id);
  };

  const uploadProfilePhoto = async (uri: string) => {
    try {
      if (!user?.id) throw new Error('No user');
      const { extRaw, mime } = getExtAndMimeFromUri(uri);
      const fileName = `profile_${user.id}_${Date.now()}.${extRaw || 'jpg'}`;
      const storagePath = `profiles/${user.id}/${fileName}`;
      const { publicUrl } = await uploadUriToSupabase(uri, storagePath, mime);
      if (!publicUrl) throw new Error('Upload succeeded but no public URL was returned.');
      await persistProfilePhotoUrl(publicUrl);
      setProfilePicture(publicUrl);
      setProfile((prev) => (prev ? { ...prev, profile_photo_url: publicUrl } : null));
      await hapticFeedback('medium');
      toast.success('Profile picture uploaded successfully!');
    } catch (error: any) {
      console.error('[ValeterProfile] uploadProfilePhoto failed:', error);
      toast.error(error?.message || 'Please try again.', 'Upload Failed');
    }
  };

  const choosePhoto = async (source: PhotoSource) => {
    if (uploadingPicture) return;
    try {
      setUploadingPicture(true);
      const uri = await pickProfilePhoto(source);
      if (uri) await uploadProfilePhoto(uri);
    } catch (error: any) {
      console.error(`[ValeterProfile] ${source} photo error:`, error);
      toast.error(error?.message || PHOTO_COPY[source].failed);
    } finally {
      setUploadingPicture(false);
    }
  };
  const takePhoto = () => choosePhoto('camera');
  const pickImage = () => choosePhoto('library');

  const handleUploadProfilePicture = async () => {
    try {
      await hapticFeedback('light');
      if (uploadingPicture) return;
      if (Platform.OS === 'ios') {
        ActionSheetIOS.showActionSheetWithOptions(
          {
            title: 'Profile photo',
            message: 'Customers see this when you accept their booking',
            options: ['Cancel', 'Take Photo', 'Choose from Gallery'],
            cancelButtonIndex: 0,
            userInterfaceStyle: 'dark',
          },
          async (buttonIndex) => {
            if (buttonIndex === 1) await takePhoto();
            if (buttonIndex === 2) await pickImage();
          }
        );
      } else {
        Alert.alert('Profile photo', 'Customers see this when you accept their booking', [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Take Photo', onPress: () => void takePhoto() },
          { text: 'Choose from Gallery', onPress: () => void pickImage() },
        ]);
      }
    } catch (e) {
      console.warn('[ValeterProfile] handleUploadProfilePicture error:', e);
    }
  };

  const handleLogout = async () => {
    try {
      await hapticFeedback('medium');
      Alert.alert('Log out', 'Are you sure you want to log out?', [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Log out',
          style: 'destructive',
          onPress: () => {
            void (async () => {
              try {
                await logout();
              } catch (error) {
                console.error('Logout error:', error);
                toast.error('Failed to logout. Please try again.', 'Logout Error');
              }
            })();
          },
        },
      ]);
    } catch {}
  };

  const go = (route: string) => router.push(route as any);

  if (isLoading) {
    return <LoadingScreen message="Loading profile…" />;
  }

  if (!profile) {
    return (
      <View style={styles.flex}>
        <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="valeter" />
        <View style={styles.center}>
          <Text style={[styles.rowTitle, { color: primaryColor }]}>Failed to load profile</Text>
        </View>
      </View>
    );
  }

  const verification = VERIFICATION_META[profile.verification_status] ?? VERIFICATION_META.pending;
  const isLight = mode === 'light';
  const experienceLabel = experienceLabelFor(profile.experience, valeterStats.experienceMonths);
  const metaParts = [experienceLabel, radiusLabel(serviceRadiusMiles)].filter(Boolean);
  const stats = profileStatCards(todayStats, earningsThisMonth, valeterStats);

  const groups: Array<{ title: string; rows: MenuRow[] }> = [
    {
      title: 'WORK',
      rows: [
        { key: 'services', icon: 'mci:car-wash', color: SKY, title: 'Services & pricing', sub: 'Wash tiers, detailing & repairs', route: '/valeter/profile/valeter-services' },
        { key: 'hours', icon: 'time', color: GREEN, title: 'Working hours', sub: 'When you take bookings', route: '/valeter/settings/working-hours' },
        {
          key: 'distance',
          icon: 'navigate',
          color: CYAN,
          title: 'Distance covering',
          sub: 'How far you travel',
          value: serviceRadiusMiles != null ? `${serviceRadiusMiles} mi` : undefined,
          route: '/valeter/settings/distance-covering',
        },
        { key: 'vehicle', icon: 'car-sport', color: AMBER, title: 'My garage', sub: 'Your van or car details', route: '/valeter/profile/valeter-vehicle-info' },
      ],
    },
    {
      title: 'MONEY',
      rows: [
        {
          key: 'stripe',
          icon: 'wallet',
          color: GREEN,
          title: 'Get paid',
          sub: 'Your Stripe payout account',
          route: '/valeter/stripe-connect',
          right: stripeStatus ? <StripeStatusPill status={stripeStatus} size="sm" /> : <ActivityIndicator size="small" color={textMuted} />,
        },
        {
          key: 'jobs',
          icon: 'receipt',
          color: SKY,
          title: 'Jobs & earnings',
          sub: `${valeterStats.totalJobs} completed · £${Number(valeterStats.totalEarnings || 0).toFixed(2)} earned`,
          route: '/valeter/features/job-history',
        },
      ],
    },
    {
      title: 'GROW',
      rows: [
        { key: 'referrals', icon: 'people', color: VIOLET, title: 'Refer a Pro', sub: 'Invite other valeters to join', route: '/valeter/features/referral-system' },
      ],
    },
    {
      title: 'ACCOUNT',
      rows: [
        { key: 'personal', icon: 'person', color: SKY, title: 'Personal info', sub: 'Name, bio & contact details', route: '/valeter/profile/valeter-personal-info' },
        {
          key: 'documents',
          icon: 'document-text',
          color: PINK,
          title: 'Documents',
          sub: 'Verification & uploads',
          route: '/valeter/profile/valeter-documents',
          right: <StatusChip label={verification.label} color={verification.color} icon={verification.icon} />,
        },
        { key: 'notifications', icon: 'notifications', color: PINK, title: 'Notifications', sub: 'Alerts & preferences', route: '/valeter/profile/valeter-notification-preferences' },
        {
          key: 'appearance',
          icon: isLight ? 'sunny' : 'moon',
          color: isLight ? GOLD : SKY,
          title: 'Appearance',
          sub: `${isLight ? 'Light' : 'Dark'} mode`,
          onPress: () => toggleMode(),
          right: (
            <Switch
              value={isLight}
              onValueChange={() => toggleMode()}
              trackColor={{ false: '#334155', true: `${primaryColor}99` }}
              thumbColor={isLight ? GOLD : '#94A3B8'}
            />
          ),
        },
      ],
    },
    {
      title: 'SUPPORT',
      rows: [
        { key: 'help', icon: 'help-circle', color: SKY, title: 'Help & support', sub: 'FAQs and contact', route: '/valeter/support/help-support' },
        { key: 'terms', icon: 'reader', color: 'rgba(148,163,184,1)', title: 'Terms and conditions', sub: 'Platform and account terms', route: '/terms-of-service' },
      ],
    },
  ];

  return (
    <View style={styles.flex}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <ValeterScreenHeader
        title="Profile"
        rightAction={
          <PressableScale
            onPress={() => go('/valeter/profile/valeter-personal-info')}
            style={[styles.headerBtn, { borderColor: `${primaryColor}40` }]}
            accessibilityLabel="Edit profile"
          >
            <Ionicons name="pencil" size={16} color={textMain} />
          </PressableScale>
        }
      />

      <ScrollView
        style={styles.flex}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.content,
          { paddingTop: fit.top, paddingBottom: VALETER_CONTENT_BOTTOM_PAD + insets.bottom + 24 },
        ]}
      >
        <Reanimated.View entering={FadeInDown.springify().damping(18)}>
          <GlassSurface style={styles.hero} fallbackColor="rgba(10,25,41,0.6)">
            <LinearGradient
              colors={[`${primaryColor}30`, 'transparent']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={StyleSheet.absoluteFill}
              pointerEvents="none"
            />
            <View style={styles.heroTop}>
              <PressableScale onPress={() => void handleUploadProfilePicture()} disabled={uploadingPicture} accessibilityLabel="Change profile photo">
                <View style={[styles.avatarRing, { borderColor: `${primaryColor}88` }]}>
                  {profilePicture ? (
                    <Image source={{ uri: profilePicture }} style={styles.avatar} />
                  ) : (
                    <View style={[styles.avatar, styles.avatarEmpty]}>
                      <Ionicons name="person" size={40} color={primaryColor} />
                    </View>
                  )}
                </View>
                <View style={[styles.cameraBadge, { backgroundColor: primaryColor }]}>
                  {uploadingPicture ? (
                    <ActivityIndicator size="small" color="#0A1929" />
                  ) : (
                    <Ionicons name="camera" size={14} color="#0A1929" />
                  )}
                </View>
              </PressableScale>

              <View style={styles.heroCopy}>
                <Text style={[styles.name, { color: textMain }]} numberOfLines={2}>
                  {profile.full_name || 'Car Care Pro'}
                </Text>
                <View style={styles.chipRow}>
                  <StatusChip label={verification.label} color={verification.color} icon={verification.icon} />
                </View>
                {metaParts.length ? (
                  <Text style={[styles.meta, { color: textMuted }]} numberOfLines={1}>
                    {metaParts.join(' · ')}
                  </Text>
                ) : null}
              </View>
            </View>

            {profile.bio?.trim() ? (
              <Text style={[styles.bio, { color: textMuted }]} numberOfLines={3}>
                {profile.bio}
              </Text>
            ) : (
              <PressableScale onPress={() => go('/valeter/profile/valeter-personal-info')} style={styles.addBio}>
                <Ionicons name="add-circle-outline" size={15} color={primaryColor} />
                <Text style={[styles.addBioText, { color: primaryColor }]}>Add a short bio customers will see</Text>
              </PressableScale>
            )}

            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.serviceChips}>
              {servicesOfferedDisplay.length > 0 ? (
                servicesOfferedDisplay.slice(0, 6).map((label) => (
                  <View key={label} style={styles.serviceChip}>
                    <Text style={[styles.serviceChipText, { color: textMain }]}>{label}</Text>
                  </View>
                ))
              ) : (
                <PressableScale onPress={() => go('/valeter/profile/valeter-services')} style={[styles.serviceChip, { borderColor: `${primaryColor}66` }]}>
                  <Text style={[styles.serviceChipText, { color: primaryColor }]}>+ Set your services & prices</Text>
                </PressableScale>
              )}
            </ScrollView>
          </GlassSurface>
        </Reanimated.View>

        <Reanimated.View entering={FadeInDown.delay(60).springify().damping(18)} style={styles.statsRow}>
          {stats.map((s) => (
            <PressableScale key={s.key} fill onPress={() => go(s.route)} style={styles.statTile} accessibilityLabel={`${s.label} ${s.value}`}>
              <Text style={styles.statLabel}>{s.label}</Text>
              <View style={styles.statValueRow}>
                {s.starred ? <Ionicons name="star" size={14} color={s.color} /> : null}
                <Text style={[styles.statValue, { color: s.color }]} numberOfLines={1} adjustsFontSizeToFit>
                  {s.value}
                </Text>
              </View>
              <Text style={styles.statSub} numberOfLines={1}>
                {s.sub}
              </Text>
            </PressableScale>
          ))}
        </Reanimated.View>

        {stripeStatus && stripeStatus !== 'completed' ? (
          <Reanimated.View entering={FadeIn.delay(120)}>
            <PressableScale
              onPress={() => go('/valeter/stripe-connect')}
              style={styles.alertCard}
              accessibilityLabel="Connect Stripe to get paid"
            >
              <GlassOrb icon="wallet" accent={RED} size={36} glow={false} />
              <View style={styles.rowBody}>
                <Text style={[styles.rowTitle, { color: textMain }]}>Connect Stripe to get paid</Text>
                <Text style={[styles.rowSub, { color: textMuted }]} numberOfLines={1}>
                  You can’t accept jobs until payouts are set up
                </Text>
              </View>
              <StripeStatusPill status={stripeStatus} size="sm" />
            </PressableScale>
          </Reanimated.View>
        ) : null}

        {groups.map((g, i) => (
          <MenuGroup
            key={g.title}
            title={g.title}
            rows={g.rows}
            textMain={textMain}
            textMuted={textMuted}
            delay={120 + i * 50}
            onNavigate={go}
          />
        ))}

        <Reanimated.View entering={FadeInDown.delay(420).springify().damping(18)}>
          <PressableScale onPress={() => void handleLogout()} style={styles.logout} accessibilityLabel="Log out">
            <Ionicons name="log-out-outline" size={18} color={RED} />
            <Text style={styles.logoutText}>Log out</Text>
          </PressableScale>
        </Reanimated.View>

        <Text style={[styles.appInfo, { color: textMuted }]}>Wish a Wash v1.0.0 · © 2026 Wish a Wash</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  content: { paddingHorizontal: 18, gap: 12 },

  headerBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
  },

  hero: { borderRadius: 26, padding: 16, gap: 12, overflow: 'hidden' },
  heroTop: { flexDirection: 'row', alignItems: 'center', gap: 16 },
  avatarRing: {
    width: AVATAR + 8,
    height: AVATAR + 8,
    borderRadius: (AVATAR + 8) / 2,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatar: { width: AVATAR, height: AVATAR, borderRadius: AVATAR / 2 },
  avatarEmpty: { backgroundColor: 'rgba(255,255,255,0.08)', alignItems: 'center', justifyContent: 'center' },
  cameraBadge: {
    position: 'absolute',
    right: 0,
    bottom: 2,
    width: 30,
    height: 30,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 3,
    borderColor: '#0B1E33',
  },
  heroCopy: { flex: 1, gap: 6 },
  name: { fontSize: 22, fontWeight: '900', letterSpacing: -0.4 },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  meta: { fontSize: 12, fontWeight: '700' },
  bio: { fontSize: 13, fontWeight: '600', lineHeight: 19 },
  addBio: { flexDirection: 'row', alignItems: 'center', gap: 6, alignSelf: 'flex-start' },
  addBioText: { fontSize: 13, fontWeight: '800' },
  serviceChips: { gap: 6, paddingRight: 4 },
  serviceChip: {
    paddingHorizontal: 11,
    paddingVertical: 6,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  serviceChipText: { fontSize: 12, fontWeight: '700' },

  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 999,
    borderWidth: 1,
  },
  chipText: { fontSize: 11, fontWeight: '900', letterSpacing: 0.2 },

  statsRow: { flexDirection: 'row', gap: 8 },
  statTile: {
    flex: 1,
    paddingHorizontal: 12,
    paddingVertical: 12,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    backgroundColor: 'rgba(10,25,41,0.42)',
    gap: 2,
  },
  statLabel: { color: 'rgba(226,232,240,0.6)', fontSize: 11, fontWeight: '800' },
  statValueRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  statValue: { fontSize: 20, fontWeight: '900', fontVariant: ['tabular-nums'], flexShrink: 1 },
  statSub: { color: 'rgba(226,232,240,0.55)', fontSize: 11, fontWeight: '700' },

  alertCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 12,
    paddingVertical: 12,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'rgba(248,113,113,0.45)',
    backgroundColor: 'rgba(248,113,113,0.1)',
  },

  groupLabel: {
    color: 'rgba(226,232,240,0.65)',
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 1.2,
    marginTop: 4,
    marginBottom: 6,
    paddingHorizontal: 4,
  },
  group: { borderRadius: 20, paddingHorizontal: 12, overflow: 'hidden' },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 11 },
  rowDivider: { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: 'rgba(248,250,252,0.1)' },
  rowBody: { flex: 1, minWidth: 0, gap: 1 },
  rowTitle: { fontSize: 15, fontWeight: '800' },
  rowSub: { fontSize: 12, fontWeight: '600' },
  rowValue: { fontSize: 13, fontWeight: '800', marginRight: 2 },

  logout: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 6,
    paddingVertical: 14,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'rgba(248,113,113,0.4)',
    backgroundColor: 'rgba(248,113,113,0.1)',
  },
  logoutText: { color: RED, fontSize: 15, fontWeight: '900' },
  appInfo: { textAlign: 'center', fontSize: 11, fontWeight: '600', opacity: 0.7, marginTop: 4 },
});
