/**
 * Valeter Notification Preferences – control how and when job alerts reach the Pro.
 */
import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, ScrollView, StyleSheet, Pressable, Switch, Linking, AppState } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import * as Notifications from 'expo-notifications';
import Reanimated, { FadeInDown } from 'react-native-reanimated';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import ValeterScreenHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/valeter/ValeterScreenHeader';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { colors } from '../../../src/constants/colors';
import { lightMistElevated } from '../../../src/constants/accountThemes';
import { VALETER_CONTENT_BOTTOM_PAD } from '../../../src/components/valeter/ValeterNavSidebar';
import LoadingScreen from '../../../src/components/LoadingScreen';
import { toast } from '../../../src/components/shared/ToastHost';
import { supabase } from '../../../src/lib/supabase';
import { themeBackgroundGradient } from '../../../src/utils/themeGradient';
import type { IconGlyphName } from '../../../src/components/shared/iconGlyphTypes';

const SKY = colors.SKY;
const LIGHT_TEXT = '#F9FAFB';
const MUTED_TEXT = 'rgba(249,250,251,0.65)';
const WARN_AMBER = '#FBBF24';
const VALETER_BG_FALLBACK: [string, string] = ['#0A1929', '#152238'];

interface NotificationPreferences {
  jobAlerts: boolean;
  sound: boolean;
  vibration: boolean;
  email: boolean;
}

const DEFAULT_NOTIFICATION_PREFS: NotificationPreferences = {
  jobAlerts: true,
  sound: true,
  vibration: true,
  email: false,
};

type AlertStyle = 'sound' | 'vibrate' | 'silent';

const ALERT_STYLES: { id: AlertStyle; label: string; icon: IconGlyphName; patch: Pick<NotificationPreferences, 'sound' | 'vibration'> }[] = [
  { id: 'sound', label: 'Sound', icon: 'volume-high', patch: { sound: true, vibration: true } },
  { id: 'vibrate', label: 'Vibrate', icon: 'mci:vibrate', patch: { sound: false, vibration: true } },
  { id: 'silent', label: 'Silent', icon: 'volume-mute', patch: { sound: false, vibration: false } },
];

function alertStyleOf(p: NotificationPreferences): AlertStyle {
  if (p.sound) return 'sound';
  return p.vibration ? 'vibrate' : 'silent';
}

type PermissionState = 'granted' | 'denied' | 'undetermined' | 'unknown';

const SWITCH_OFF_TRACK = 'rgba(148,163,184,0.35)';

export default function ValeterNotificationPreferences() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const gradientBg = themeBackgroundGradient(theme?.background, VALETER_BG_FALLBACK);
  const primary = theme.primary || SKY;
  const textMain = theme.textPrimary ?? LIGHT_TEXT;
  const textMuted = theme.textSecondary ?? MUTED_TEXT;
  const isLight = theme.mode === 'light';
  const surface = isLight ? lightMistElevated : 'rgba(15,23,42,0.42)';
  const hairline = isLight ? 'rgba(15,23,42,0.08)' : 'rgba(255,255,255,0.08)';

  const [loading, setLoading] = useState(true);
  const [prefs, setPrefs] = useState<NotificationPreferences>(DEFAULT_NOTIFICATION_PREFS);
  const [permission, setPermission] = useState<PermissionState>('unknown');

  const refreshPermission = useCallback(async () => {
    try {
      const { status } = await Notifications.getPermissionsAsync();
      setPermission(status as PermissionState);
    } catch {
      setPermission('unknown');
    }
  }, []);

  useEffect(() => {
    void refreshPermission();
    const sub = AppState.addEventListener('change', (s) => {
      if (s === 'active') void refreshPermission();
    });
    return () => sub.remove();
  }, [refreshPermission]);

  useEffect(() => {
    if (!user?.id) {
      setLoading(false);
      return;
    }
    let cancelled = false;
    void (async () => {
      try {
        const { data, error } = await supabase
          .from('valeter_profiles')
          .select('notification_preferences')
          .eq('user_id', user.id)
          .maybeSingle();
        if (error) throw error;
        if (!cancelled) {
          const saved = data?.notification_preferences as Partial<NotificationPreferences> | null;
          setPrefs({ ...DEFAULT_NOTIFICATION_PREFS, ...saved });
        }
      } catch (error) {
        console.error('Error loading notification preferences:', error);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  const savePrefs = async (next: NotificationPreferences) => {
    if (!user?.id) return;
    const { data: existing } = await supabase
      .from('valeter_profiles')
      .select('id')
      .eq('user_id', user.id)
      .maybeSingle();
    const { error } = existing
      ? await supabase.from('valeter_profiles').update({ notification_preferences: next }).eq('user_id', user.id)
      : await supabase
          .from('valeter_profiles')
          .insert({ user_id: user.id, notification_preferences: next, full_name: user.name || 'Car Care Pro' });
    if (error) throw error;
  };

  const applyPatch = async (patch: Partial<NotificationPreferences>) => {
    const previous = prefs;
    const next = { ...prefs, ...patch };
    setPrefs(next);
    void hapticFeedback('light');
    try {
      await savePrefs(next);
    } catch (error) {
      console.error('Error saving notification preferences:', error);
      setPrefs(previous);
      toast.error("Couldn't save that change. Try again.");
    }
  };

  const handlePermissionPress = async () => {
    void hapticFeedback('light');
    if (permission === 'undetermined') {
      try {
        const { status } = await Notifications.requestPermissionsAsync();
        setPermission(status as PermissionState);
      } catch {
        void Linking.openSettings();
      }
      return;
    }
    void Linking.openSettings();
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
        <ValeterScreenHeader title="Notifications" />
        <LoadingScreen message="Loading…" />
      </SafeAreaView>
    );
  }

  const jobsOn = prefs.jobAlerts;
  const style = alertStyleOf(prefs);
  const phoneBlocked = permission === 'denied' || permission === 'undetermined';

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <ValeterScreenHeader title="Notifications" />

      <ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingTop: HEADER_CONTENT_OFFSET + 4, paddingBottom: insets.bottom + VALETER_CONTENT_BOTTOM_PAD + 8 },
        ]}
      >
        {/* Master switch */}
        <Reanimated.View entering={FadeInDown.duration(300)}>
          <Pressable
            onPress={() => applyPatch({ jobAlerts: !jobsOn })}
            style={({ pressed }) => [
              styles.master,
              { backgroundColor: surface, borderColor: jobsOn ? `${primary}50` : hairline, opacity: pressed ? 0.92 : 1 },
            ]}
            accessibilityRole="switch"
            accessibilityState={{ checked: jobsOn }}
            accessibilityLabel="New job alerts"
          >
            {jobsOn ? (
              <LinearGradient
                colors={[`${primary}30`, `${primary}08`, 'transparent']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={StyleSheet.absoluteFill}
                pointerEvents="none"
              />
            ) : null}
            <View style={styles.masterRow}>
              <View
                style={[
                  styles.bell,
                  jobsOn
                    ? { backgroundColor: `${primary}26`, borderColor: `${primary}66` }
                    : { backgroundColor: 'rgba(148,163,184,0.14)', borderColor: 'rgba(148,163,184,0.25)' },
                ]}
              >
                <Ionicons
                  name={jobsOn ? 'notifications' : 'notifications-off'}
                  size={22}
                  color={jobsOn ? primary : textMuted}
                />
              </View>
              <View style={styles.flexCopy}>
                <Text style={[styles.masterTitle, { color: textMain }]}>New job alerts</Text>
                <Text style={[styles.masterSub, { color: textMuted }]} numberOfLines={2}>
                  {jobsOn ? 'Instant push when a nearby customer books' : 'Paused. Offers only show on the map'}
                </Text>
              </View>
              <Switch
                value={jobsOn}
                onValueChange={(v) => applyPatch({ jobAlerts: v })}
                trackColor={{ false: SWITCH_OFF_TRACK, true: `${primary}99` }}
                thumbColor={jobsOn ? primary : '#E2E8F0'}
                ios_backgroundColor={SWITCH_OFF_TRACK}
              />
            </View>

            {phoneBlocked ? (
              <Pressable
                onPress={handlePermissionPress}
                style={[styles.permission, { borderTopColor: hairline }]}
                accessibilityRole="button"
                accessibilityLabel="Allow notifications on this phone"
              >
                <View style={styles.permissionDot} />
                <Text style={[styles.permissionText, { color: textMain }]} numberOfLines={1}>
                  Blocked in phone settings
                </Text>
                <Text style={styles.permissionAction}>{permission === 'undetermined' ? 'Allow' : 'Fix'}</Text>
                <Ionicons name="chevron-forward" size={14} color={WARN_AMBER} />
              </Pressable>
            ) : null}
          </Pressable>
        </Reanimated.View>

        {/* Alert style */}
        <Reanimated.View entering={FadeInDown.duration(300).delay(60)} style={!jobsOn && styles.dimmed}>
          <Text style={[styles.groupLabel, { color: textMuted }]}>Alert style</Text>
          <View style={styles.styleRow}>
            {ALERT_STYLES.map((opt) => {
              const selected = style === opt.id;
              return (
                <Pressable
                  key={opt.id}
                  disabled={!jobsOn}
                  onPress={() => {
                    if (!selected) void applyPatch(opt.patch);
                  }}
                  style={({ pressed }) => [
                    styles.styleTile,
                    {
                      backgroundColor: selected ? `${primary}22` : surface,
                      borderColor: selected ? primary : hairline,
                      transform: [{ scale: pressed ? 0.97 : 1 }],
                    },
                  ]}
                  accessibilityRole="radio"
                  accessibilityState={{ selected, disabled: !jobsOn }}
                  accessibilityLabel={opt.label}
                >
                  <Ionicons name={opt.icon} size={22} color={selected ? primary : textMuted} />
                  <Text style={[styles.styleLabel, { color: selected ? textMain : textMuted }]}>{opt.label}</Text>
                  {selected ? (
                    <View style={[styles.styleCheck, { backgroundColor: primary }]}>
                      <Ionicons name="checkmark" size={10} color="#0B1220" />
                    </View>
                  ) : null}
                </Pressable>
              );
            })}
          </View>
        </Reanimated.View>

        {/* Email */}
        <Reanimated.View entering={FadeInDown.duration(300).delay(120)}>
          <Text style={[styles.groupLabel, { color: textMuted }]}>Email</Text>
          <Pressable
            onPress={() => applyPatch({ email: !prefs.email })}
            style={({ pressed }) => [
              styles.slimRow,
              { backgroundColor: surface, borderColor: hairline, opacity: pressed ? 0.92 : 1 },
            ]}
            accessibilityRole="switch"
            accessibilityState={{ checked: prefs.email }}
            accessibilityLabel="Email summaries"
          >
            <Ionicons name="mail" size={18} color={prefs.email ? primary : textMuted} />
            <View style={styles.flexCopy}>
              <Text style={[styles.slimTitle, { color: textMain }]}>Email summaries</Text>
              <Text style={[styles.slimSub, { color: textMuted }]} numberOfLines={1}>
                {user?.email ?? 'Your account email'}
              </Text>
            </View>
            <Switch
              value={prefs.email}
              onValueChange={(v) => applyPatch({ email: v })}
              trackColor={{ false: SWITCH_OFF_TRACK, true: `${primary}99` }}
              thumbColor={prefs.email ? primary : '#E2E8F0'}
              ios_backgroundColor={SWITCH_OFF_TRACK}
            />
          </Pressable>
        </Reanimated.View>

        <Text style={[styles.footnote, { color: textMuted }]}>
          Booking updates and customer messages always come through.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollView: { flex: 1 },
  scrollContent: { paddingHorizontal: 18 },
  flexCopy: { flex: 1, minWidth: 0 },
  dimmed: { opacity: 0.4 },

  master: {
    borderRadius: 24,
    borderWidth: 1,
    overflow: 'hidden',
    marginBottom: 26,
  },
  masterRow: { flexDirection: 'row', alignItems: 'center', gap: 14, padding: 16 },
  bell: {
    width: 48,
    height: 48,
    borderRadius: 24,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  masterTitle: { fontSize: 17, fontWeight: '800', letterSpacing: -0.3 },
  masterSub: { fontSize: 13, fontWeight: '500', marginTop: 3, lineHeight: 18 },

  permission: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderTopWidth: StyleSheet.hairlineWidth,
    backgroundColor: 'rgba(251,191,36,0.08)',
  },
  permissionDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: WARN_AMBER },
  permissionText: { flex: 1, fontSize: 13, fontWeight: '600' },
  permissionAction: { color: WARN_AMBER, fontSize: 13, fontWeight: '800' },

  groupLabel: { fontSize: 13, fontWeight: '600', marginBottom: 10, marginLeft: 4 },

  styleRow: { flexDirection: 'row', gap: 10, marginBottom: 26 },
  styleTile: {
    flex: 1,
    height: 88,
    borderRadius: 20,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  styleLabel: { fontSize: 13, fontWeight: '700' },
  styleCheck: {
    position: 'absolute',
    top: 8,
    right: 8,
    width: 16,
    height: 16,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },

  slimRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    borderRadius: 18,
    borderWidth: 1,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 18,
  },
  slimTitle: { fontSize: 15, fontWeight: '700' },
  slimSub: { fontSize: 12, fontWeight: '500', marginTop: 2 },

  footnote: { fontSize: 12, fontWeight: '500', textAlign: 'center', opacity: 0.8, paddingHorizontal: 24 },
});
