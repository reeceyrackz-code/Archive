import React, { useState, useEffect, useMemo } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Switch,
  KeyboardAvoidingView,
  Platform,
  Pressable,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useFocusEffect, useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { supabase } from '../../../src/lib/supabase';
import { themeBackgroundGradient } from '../../../src/utils/themeGradient';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import LoadingScreen from '../../../src/components/LoadingScreen';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import ValeterScreenHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/valeter/ValeterScreenHeader';
import { LocationStyleIconBox } from '../../../src/components/shared/GradientIconBox';
import { getServicesOfferedFromSettings, type ValeterServiceSettingsRow } from '../../../src/utils/valeterServicesOffered';
import { colors } from '../../../src/constants/colors';
import { VALETER_CONTENT_BOTTOM_PAD } from '../../../src/components/valeter/ValeterNavSidebar';
import { lightMistElevated, lightMistInput } from '../../../src/constants/accountThemes';
import ContinueCTAButton from '../../../src/components/ui/ContinueCTAButton';
import ValeterPickerSheet from '../../../src/components/valeter/ValeterPickerSheet';
import {
  ValeterExperienceWheelPicker,
  formatExperienceLabel,
  parseExperienceLabel,
} from '../../../src/components/valeter/ValeterWheelPicker';
import { toast } from '../../../src/components/shared/ToastHost';

const SKY = colors.SKY;
const LIGHT_TEXT = '#F9FAFB';
const MUTED_TEXT = 'rgba(249,250,251,0.65)';
const VALETER_BG_FALLBACK: [string, string] = ['#0A1929', '#152238'];
const DEFAULT_BIO = 'Professional mobile car care pro';
const BIO_MAX = 160;

function isDefaultBio(bio?: string | null): boolean {
  const t = (bio || '').trim().toLowerCase();
  return !t || t === DEFAULT_BIO.toLowerCase();
}

function isEmptyExperience(experience?: string | null): boolean {
  return !experience || /^0\s*years?$/i.test(experience.trim());
}

interface ValeterProfileData {
  user_id: string;
  full_name: string;
  business_name?: string;
  bio?: string;
  experience?: string;
  profile_photo_url?: string;
  is_self_sufficient?: boolean;
}

type AuthUser = NonNullable<ReturnType<typeof useAuth>['user']>;
type ScreenTheme = ReturnType<typeof useAccountTheme>['theme'];
type SetProfile = (profile: ValeterProfileData) => void;

type Palette = Readonly<{
  primary: string;
  glassBorder: string;
  textMain: string;
  textMuted: string;
  isLight: boolean;
  panelBg: string;
  hintColor?: string;
  inputColors: Readonly<{ borderColor: string; backgroundColor: string }>;
  inputBg: string;
  offPillBg: string;
  tagBg: string;
  saveBarBg: string;
  saveBarBorder: string;
}>;

function buildPalette(theme: ScreenTheme): Palette {
  const primary = theme.primary || SKY;
  const isLight = theme.mode === 'light';
  const inputBg = isLight ? lightMistInput : 'rgba(255,255,255,0.06)';
  return {
    primary,
    glassBorder: theme.glassBorder ?? `${primary}35`,
    textMain: theme.textPrimary ?? LIGHT_TEXT,
    textMuted: theme.textSecondary ?? MUTED_TEXT,
    isLight,
    panelBg: isLight ? lightMistElevated : 'rgba(15,23,42,0.42)',
    hintColor: isLight ? 'rgba(248,250,252,0.55)' : undefined,
    inputColors: {
      borderColor: isLight ? 'rgba(158,201,224,0.32)' : 'rgba(148,163,184,0.22)',
      backgroundColor: inputBg,
    },
    inputBg,
    offPillBg: isLight ? 'rgba(71,85,105,0.12)' : 'rgba(148,163,184,0.14)',
    tagBg: isLight ? 'rgba(158,201,224,0.12)' : 'rgba(255,255,255,0.05)',
    saveBarBg: isLight ? 'rgba(42,70,96,0.94)' : 'rgba(10,25,41,0.92)',
    saveBarBorder: isLight ? 'rgba(232,197,71,0.22)' : 'rgba(255,255,255,0.08)',
  };
}

async function fetchOrCreateProfile(user: AuthUser): Promise<ValeterProfileData> {
  const { data, error } = await supabase
    .from('valeter_profiles')
    .select('*')
    .eq('user_id', user.id)
    .maybeSingle();

  if (error && error.code !== 'PGRST116') {
    throw error;
  }

  if (data) return data;

  const newProfile: Partial<ValeterProfileData> = {
    user_id: user.id,
    full_name: user.name || 'Car Care Pro',
    bio: DEFAULT_BIO,
    experience: '0 years',
  };

  const { data: created, error: createError } = await supabase
    .from('valeter_profiles')
    .insert(newProfile)
    .select()
    .single();

  if (createError) throw createError;
  return created;
}

async function updateProfileRow(userId: string, profile: ValeterProfileData, name: string) {
  const { error } = await supabase
    .from('valeter_profiles')
    .update({
      full_name: name,
      business_name: profile.business_name ?? null,
      bio: (profile.bio || '').trim() || DEFAULT_BIO,
      experience: profile.experience,
      is_self_sufficient: profile.is_self_sufficient,
    })
    .eq('user_id', userId);

  if (error) throw error;
}

function useValeterPersonalInfo(user: AuthUser | null) {
  const [profile, setProfile] = useState<ValeterProfileData | null>(null);
  const [serviceSettings, setServiceSettings] = useState<ValeterServiceSettingsRow | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [experiencePickerOpen, setExperiencePickerOpen] = useState(false);
  const [experienceDraft, setExperienceDraft] = useState({ years: 1, months: 0 });

  const offeredServices = useMemo(
    () => getServicesOfferedFromSettings(serviceSettings),
    [serviceSettings]
  );

  useEffect(() => {
    if (user?.id) {
      void loadProfile();
      void loadServiceSettings();
    }
  }, [user?.id]);

  useFocusEffect(
    React.useCallback(() => {
      if (user?.id) void loadServiceSettings();
    }, [user?.id])
  );

  const loadProfile = async () => {
    try {
      setIsLoading(true);
      setProfile(await fetchOrCreateProfile(user!));
    } catch (error: any) {
      console.error('Error loading profile:', error);
      toast.error('Failed to load profile information');
    } finally {
      setIsLoading(false);
    }
  };

  const loadServiceSettings = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('valeter_service_settings')
        .select('tier_pricing, detailing_offered, detailing_menu')
        .eq('valeter_id', user.id)
        .maybeSingle();
      if (!error && data) setServiceSettings(data);
    } catch {
      // table may not exist
    }
  };

  const handleSaveProfile = async () => {
    if (!user?.id || !profile) return;
    const name = (profile.full_name || '').trim();
    if (!name) {
      toast.error('Add your name before saving.', 'Name required');
      return;
    }

    try {
      setIsSaving(true);
      await updateProfileRow(user.id, profile, name);

      setProfile({ ...profile, full_name: name });
      await hapticFeedback('success');
      toast.success('Your personal details were updated.');
      setIsEditing(false);
    } catch (error: any) {
      console.error('Error saving profile:', error);
      toast.error(error.message || 'Failed to save profile');
    } finally {
      setIsSaving(false);
    }
  };

  const handleCancelEdit = () => {
    void loadProfile();
    setIsEditing(false);
    setExperiencePickerOpen(false);
  };

  const openExperiencePicker = async () => {
    await hapticFeedback('light');
    const parsed = parseExperienceLabel(profile!.experience);
    setExperienceDraft(
      parsed.years === 0 && parsed.months === 0 ? { years: 1, months: 0 } : parsed
    );
    setExperiencePickerOpen(true);
  };

  const commitExperiencePicker = async () => {
    await hapticFeedback('light');
    setProfile({
      ...profile!,
      experience: formatExperienceLabel(experienceDraft.years, experienceDraft.months),
    });
    setExperiencePickerOpen(false);
  };

  const toggleSelfSufficient = async (value: boolean) => {
    if (!profile) return;
    await hapticFeedback('light');
    setProfile({ ...profile, is_self_sufficient: value });
    if (!isEditing || !user?.id) return;
    try {
      await supabase.from('valeter_profiles').update({ is_self_sufficient: value }).eq('user_id', user.id);
    } catch (e) {
      console.error('Error saving self-sufficiency:', e);
    }
  };

  return {
    profile,
    setProfile,
    offeredServices,
    isLoading,
    isEditing,
    setIsEditing,
    isSaving,
    experiencePickerOpen,
    setExperiencePickerOpen,
    experienceDraft,
    setExperienceDraft,
    handleSaveProfile,
    handleCancelEdit,
    openExperiencePicker,
    commitExperiencePicker,
    toggleSelfSufficient,
  };
}

type InfoRowProps = Readonly<{
  label: string;
  hint?: string;
  editing: boolean;
  children: React.ReactNode;
  last?: boolean;
  labelColor?: string;
  hintColor?: string;
}>;

function InfoRow({ label, hint, editing, children, last, labelColor, hintColor }: InfoRowProps) {
  return (
    <View style={[styles.infoRow, !last && styles.infoRowBorder]}>
      <View style={styles.infoRowLabelBlock}>
        <Text style={[styles.infoRowLabel, labelColor ? { color: labelColor } : null]}>{label}</Text>
        {hint ? <Text style={[styles.infoRowHint, hintColor ? { color: hintColor } : null]}>{hint}</Text> : null}
      </View>
      <View style={[styles.infoRowValueBlock, editing && styles.infoRowValueEditing]}>{children}</View>
    </View>
  );
}

type HeaderActionChipProps = Readonly<{
  isEditing: boolean;
  primary: string;
  onCancel: () => void;
  onEdit: () => void;
}>;

function HeaderActionChip({ isEditing, primary, onCancel, onEdit }: HeaderActionChipProps) {
  const chipStyle = [styles.headerChip, { borderColor: `${primary}40`, backgroundColor: `${primary}14` }];
  if (isEditing) {
    return (
      <TouchableOpacity
        onPress={async () => {
          await hapticFeedback('light');
          onCancel();
        }}
        style={chipStyle}
        hitSlop={8}
      >
        <Text style={[styles.headerChipText, { color: primary }]}>Cancel</Text>
      </TouchableOpacity>
    );
  }
  return (
    <TouchableOpacity
      onPress={async () => {
        await hapticFeedback('light');
        onEdit();
      }}
      style={chipStyle}
      hitSlop={8}
    >
      <Ionicons name="pencil" size={14} color={primary} />
      <Text style={[styles.headerChipText, { color: primary }]}>Edit</Text>
    </TouchableOpacity>
  );
}

type ProfileSectionProps = Readonly<{
  profile: ValeterProfileData;
  palette: Palette;
}>;

type EditableSectionProps = Readonly<{
  profile: ValeterProfileData;
  palette: Palette;
  isEditing: boolean;
  setProfile: SetProfile;
}>;

function ProfileHero({ profile, palette }: ProfileSectionProps) {
  const { primary, textMain, textMuted } = palette;
  return (
    <View style={styles.hero}>
      <Text style={[styles.heroEyebrow, { color: primary }]}>Customer-facing</Text>
      <Text style={[styles.heroTitle, { color: textMain }]} numberOfLines={1}>
        {profile.full_name || 'Your name'}
      </Text>
      <Text style={[styles.heroSub, { color: textMuted }]} numberOfLines={2}>
        {profile.business_name?.trim()
          ? profile.business_name
          : 'Add a business name so customers recognise you'}
      </Text>
    </View>
  );
}

function BusinessNameValue({ profile, palette }: ProfileSectionProps) {
  const hasBusinessName = !!profile.business_name?.trim();
  return (
    <Text style={[styles.value, { color: hasBusinessName ? palette.textMain : palette.textMuted }]}>
      {hasBusinessName ? profile.business_name : 'Not set'}
    </Text>
  );
}

function IdentityPanel({ profile, palette, isEditing, setProfile, email }: EditableSectionProps & Readonly<{ email?: string }>) {
  const { glassBorder, panelBg, textMain, textMuted, hintColor, inputColors } = palette;
  return (
    <>
      <Text style={[styles.sectionLabel, { color: textMuted }]}>Identity</Text>
      <View style={[styles.panel, { borderColor: glassBorder, backgroundColor: panelBg }]}>
        <InfoRow label="Name" hint="Shown on jobs and your profile" editing={isEditing} labelColor={textMuted} hintColor={hintColor}>
          {isEditing ? (
            <TextInput
              style={[styles.input, { color: textMain, ...inputColors }]}
              value={profile.full_name}
              onChangeText={(text) => setProfile({ ...profile, full_name: text })}
              placeholder="Your name"
              placeholderTextColor={textMuted}
              autoCapitalize="words"
            />
          ) : (
            <Text style={[styles.value, { color: textMain }]}>{profile.full_name}</Text>
          )}
        </InfoRow>

        <InfoRow label="Business name" hint="Optional trading name" editing={isEditing} labelColor={textMuted} hintColor={hintColor}>
          {isEditing ? (
            <TextInput
              style={[styles.input, { color: textMain, ...inputColors }]}
              value={profile.business_name ?? ''}
              onChangeText={(text) => setProfile({ ...profile, business_name: text || undefined })}
              placeholder="e.g. Joe's Mobile Valeting"
              placeholderTextColor={textMuted}
            />
          ) : (
            <BusinessNameValue profile={profile} palette={palette} />
          )}
        </InfoRow>

        <InfoRow label="Email" hint="Account login — not editable here" editing={false} last labelColor={textMuted} hintColor={hintColor}>
          <Text style={[styles.value, { color: textMain }]}>{email || '—'}</Text>
        </InfoRow>
      </View>
    </>
  );
}

function BioField({ profile, palette, isEditing, setProfile }: EditableSectionProps) {
  const { textMain, textMuted, inputColors } = palette;
  const bioIsDefault = isDefaultBio(profile.bio);
  if (!isEditing) {
    const displayBio = bioIsDefault ? DEFAULT_BIO : (profile.bio || DEFAULT_BIO);
    return <Text style={[styles.value, { color: textMain }]}>{displayBio}</Text>;
  }
  const bioDraft = bioIsDefault ? '' : profile.bio || '';
  return (
    <View>
      <TextInput
        style={[styles.input, styles.bioInput, { color: textMain, ...inputColors }]}
        value={bioDraft}
        onChangeText={(text) =>
          setProfile({ ...profile, bio: text.slice(0, BIO_MAX) })
        }
        placeholder={DEFAULT_BIO}
        placeholderTextColor={textMuted}
        multiline
        maxLength={BIO_MAX}
      />
      <Text style={[styles.charCount, { color: textMuted }]}>
        {bioDraft.length}/{BIO_MAX}
      </Text>
    </View>
  );
}

type ExperienceFieldProps = Readonly<{
  profile: ValeterProfileData;
  palette: Palette;
  isEditing: boolean;
  onOpenPicker: () => void;
}>;

function ExperienceField({ profile, palette, isEditing, onOpenPicker }: ExperienceFieldProps) {
  const { primary, textMain, textMuted, inputBg } = palette;
  const empty = isEmptyExperience(profile.experience);
  const experienceColor = empty ? textMuted : textMain;
  if (!isEditing) {
    const experienceDisplay = empty ? 'Not specified' : profile.experience!;
    return <Text style={[styles.value, { color: experienceColor }]}>{experienceDisplay}</Text>;
  }
  return (
    <Pressable
      onPress={onOpenPicker}
      style={({ pressed }) => [styles.pickerBtn, { borderColor: `${primary}40`, backgroundColor: inputBg, opacity: pressed ? 0.85 : 1 }]}
    >
      <Text
        style={[
          styles.pickerBtnText,
          { color: experienceColor },
        ]}
      >
        {empty ? 'Select experience' : profile.experience}
      </Text>
      <Ionicons name="chevron-expand" size={16} color={textMuted} />
    </Pressable>
  );
}

function AboutPanel({ profile, palette, isEditing, setProfile, onOpenPicker }: EditableSectionProps & Readonly<{ onOpenPicker: () => void }>) {
  const { glassBorder, panelBg, textMuted, hintColor } = palette;
  return (
    <>
      <Text style={[styles.sectionLabel, { color: textMuted }]}>About you</Text>
      <View style={[styles.panel, { borderColor: glassBorder, backgroundColor: panelBg }]}>
        <InfoRow label="Bio" hint="Short intro customers see" editing={isEditing} labelColor={textMuted} hintColor={hintColor}>
          <BioField profile={profile} palette={palette} isEditing={isEditing} setProfile={setProfile} />
        </InfoRow>

        <InfoRow label="Experience" hint="Years on the tools" editing={isEditing} last labelColor={textMuted} hintColor={hintColor}>
          <ExperienceField profile={profile} palette={palette} isEditing={isEditing} onOpenPicker={onOpenPicker} />
        </InfoRow>
      </View>
    </>
  );
}

function SelfSufficientPill({ enabled, palette }: Readonly<{ enabled: boolean; palette: Palette }>) {
  return (
    <View
      style={[
        styles.statusPill,
        {
          backgroundColor: enabled ? 'rgba(34,197,94,0.16)' : palette.offPillBg,
        },
      ]}
    >
      <Text
        style={[
          styles.statusPillText,
          { color: enabled ? '#059669' : palette.textMuted },
        ]}
      >
        {enabled ? 'Yes' : 'No'}
      </Text>
    </View>
  );
}

type SelfSufficientCardProps = Readonly<{
  profile: ValeterProfileData;
  palette: Palette;
  isEditing: boolean;
  onToggle: (value: boolean) => void;
}>;

function SelfSufficientCard({ profile, palette, isEditing, onToggle }: SelfSufficientCardProps) {
  const { primary, glassBorder, panelBg, textMain, textMuted } = palette;
  const enabled = !!profile.is_self_sufficient;
  return (
    <>
      <Text style={[styles.sectionLabel, { color: textMuted }]}>On the road</Text>
      <View style={[styles.capabilityCard, { borderColor: glassBorder, backgroundColor: panelBg }]}>
        <View style={styles.capabilityLeft}>
          <LocationStyleIconBox
            icon={enabled ? 'water' : 'water-outline'}
            preset={enabled ? 'cyan' : 'gray'}
          />
          <View style={styles.capabilityCopy}>
            <Text style={[styles.capabilityTitle, { color: textMain }]}>Self-sufficient</Text>
            <Text style={[styles.capabilitySub, { color: textMuted }]}>I bring my own water and power</Text>
          </View>
        </View>
        {isEditing ? (
          <Switch
            value={profile.is_self_sufficient ?? false}
            onValueChange={onToggle}
            trackColor={{ false: 'rgba(148,163,184,0.35)', true: `${primary}99` }}
            thumbColor={enabled ? primary : '#E2E8F0'}
          />
        ) : (
          <SelfSufficientPill enabled={enabled} palette={palette} />
        )}
      </View>
    </>
  );
}

type ServicesPanelProps = Readonly<{
  offeredServices: string[];
  palette: Palette;
  onManage: () => void;
}>;

function ServicesPanel({ offeredServices, palette, onManage }: ServicesPanelProps) {
  const { primary, glassBorder, panelBg, textMain, textMuted, tagBg } = palette;
  return (
    <>
      <Text style={[styles.sectionLabel, { color: textMuted }]}>Services</Text>
      <View style={[styles.panel, { borderColor: glassBorder, backgroundColor: panelBg }]}>
        <Text style={[styles.servicesLead, { color: textMuted }]}>
          Wash packages and add-ons from your Service Studio appear on your public profile.
        </Text>
        {offeredServices.length > 0 ? (
          <View style={styles.tagWrap}>
            {offeredServices.map((name) => (
              <View key={name} style={[styles.tag, { borderColor: `${primary}35`, backgroundColor: tagBg }]}>
                <Text style={[styles.tagText, { color: textMain }]}>{name}</Text>
              </View>
            ))}
          </View>
        ) : (
          <Text style={[styles.servicesEmpty, { color: textMuted }]}>No services set yet.</Text>
        )}
        <TouchableOpacity
          style={[styles.manageBtn, { borderColor: `${primary}40`, backgroundColor: `${primary}12` }]}
          onPress={async () => {
            await hapticFeedback('light');
            onManage();
          }}
          activeOpacity={0.85}
        >
          <LocationStyleIconBox icon="pricetag" preset="sky" />
          <View style={styles.manageBtnCopy}>
            <Text style={[styles.manageBtnTitle, { color: textMain }]}>Services & pricing</Text>
            <Text style={[styles.manageBtnSub, { color: textMuted }]}>Set wash tiers and add-ons</Text>
          </View>
          <Ionicons name="chevron-forward" size={18} color={primary} />
        </TouchableOpacity>
      </View>
    </>
  );
}

type SaveBarProps = Readonly<{
  palette: Palette;
  bottomInset: number;
  isSaving: boolean;
  onSave: () => void;
}>;

function SaveBar({ palette, bottomInset, isSaving, onSave }: SaveBarProps) {
  return (
    <View style={[styles.saveBar, { paddingBottom: Math.max(bottomInset, 16), backgroundColor: palette.saveBarBg, borderTopColor: palette.saveBarBorder }]}>
      <ContinueCTAButton
        title="Save changes"
        onPress={onSave}
        accentColor={palette.primary}
        disabled={isSaving}
        loading={isSaving}
      />
    </View>
  );
}

export default function ValeterPersonalInfo() {
  const router = useRouter();
  const { user } = useAuth();
  const { theme } = useAccountTheme();
  const gradientBg = themeBackgroundGradient(theme?.background, VALETER_BG_FALLBACK);
  const palette = buildPalette(theme);
  const { primary } = palette;
  const insets = useSafeAreaInsets();
  const {
    profile,
    setProfile,
    offeredServices,
    isLoading,
    isEditing,
    setIsEditing,
    isSaving,
    experiencePickerOpen,
    setExperiencePickerOpen,
    experienceDraft,
    setExperienceDraft,
    handleSaveProfile,
    handleCancelEdit,
    openExperiencePicker,
    commitExperiencePicker,
    toggleSelfSufficient,
  } = useValeterPersonalInfo(user);

  if (isLoading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
        <ValeterScreenHeader title="Personal information" />
        <LoadingScreen message="Loading…" />
      </SafeAreaView>
    );
  }

  if (!profile) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="valeter" />
        <ValeterScreenHeader title="Personal information" />
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Failed to load profile</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <ValeterScreenHeader
        title="Personal information"
        rightAction={
          <HeaderActionChip
            isEditing={isEditing}
            primary={primary}
            onCancel={handleCancelEdit}
            onEdit={() => setIsEditing(true)}
          />
        }
      />

      <KeyboardAvoidingView
        style={styles.keyboardView}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={[
            styles.scrollContent,
            { paddingTop: HEADER_CONTENT_OFFSET, paddingBottom: insets.bottom + VALETER_CONTENT_BOTTOM_PAD + (isEditing ? 100 : 8) },
          ]}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <ProfileHero profile={profile} palette={palette} />

          <IdentityPanel
            profile={profile}
            palette={palette}
            isEditing={isEditing}
            setProfile={setProfile}
            email={user?.email}
          />

          <AboutPanel
            profile={profile}
            palette={palette}
            isEditing={isEditing}
            setProfile={setProfile}
            onOpenPicker={openExperiencePicker}
          />

          <SelfSufficientCard
            profile={profile}
            palette={palette}
            isEditing={isEditing}
            onToggle={toggleSelfSufficient}
          />

          <ServicesPanel
            offeredServices={offeredServices}
            palette={palette}
            onManage={() => router.push('/valeter/profile/valeter-services')}
          />
        </ScrollView>

        {isEditing ? (
          <SaveBar
            palette={palette}
            bottomInset={insets.bottom}
            isSaving={isSaving}
            onSave={handleSaveProfile}
          />
        ) : null}
      </KeyboardAvoidingView>

      <ValeterPickerSheet
        visible={experiencePickerOpen}
        title="Experience"
        onClose={() => setExperiencePickerOpen(false)}
        onDone={commitExperiencePicker}
        accent={primary}
      >
        <ValeterExperienceWheelPicker
          years={experienceDraft.years}
          months={experienceDraft.months}
          onChange={setExperienceDraft}
          accent={primary}
        />
      </ValeterPickerSheet>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  keyboardView: { flex: 1 },
  scrollView: { flex: 1 },
  scrollContent: { paddingHorizontal: 20 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  loadingText: { color: LIGHT_TEXT, marginTop: 16, fontSize: 15 },

  headerChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 999,
    borderWidth: 1,
  },
  headerChipText: { fontSize: 13, fontWeight: '800' },

  hero: { marginBottom: 22 },
  heroEyebrow: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
    marginBottom: 6,
  },
  heroTitle: {
    color: LIGHT_TEXT,
    fontSize: 28,
    fontWeight: '900',
    letterSpacing: -0.5,
  },
  heroSub: {
    color: MUTED_TEXT,
    fontSize: 14,
    fontWeight: '600',
    marginTop: 6,
    lineHeight: 20,
  },

  sectionLabel: {
    color: 'rgba(249,250,251,0.42)',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.7,
    textTransform: 'uppercase',
    marginBottom: 8,
    marginTop: 4,
  },

  panel: {
    borderRadius: 18,
    borderWidth: 1,
    backgroundColor: 'rgba(15,23,42,0.42)',
    paddingHorizontal: 14,
    paddingVertical: 4,
    marginBottom: 20,
    overflow: 'hidden',
  },

  infoRow: {
    paddingVertical: 14,
  },
  infoRowBorder: {
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'rgba(255,255,255,0.08)',
  },
  infoRowLabelBlock: { marginBottom: 8 },
  infoRowLabel: {
    color: MUTED_TEXT,
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  infoRowHint: {
    color: 'rgba(249,250,251,0.4)',
    fontSize: 12,
    fontWeight: '500',
    marginTop: 2,
  },
  infoRowValueBlock: {},
  infoRowValueEditing: {},

  value: { color: LIGHT_TEXT, fontSize: 16, fontWeight: '700', lineHeight: 22 },

  input: {
    color: LIGHT_TEXT,
    fontSize: 16,
    fontWeight: '600',
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.22)',
  },
  bioInput: {
    minHeight: 88,
    textAlignVertical: 'top',
  },
  charCount: {
    color: 'rgba(249,250,251,0.35)',
    fontSize: 11,
    fontWeight: '600',
    textAlign: 'right',
    marginTop: 6,
  },

  pickerBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10,
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 12,
    borderWidth: 1,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  pickerBtnText: { color: LIGHT_TEXT, fontSize: 16, fontWeight: '700', flex: 1 },

  capabilityCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
    borderRadius: 18,
    borderWidth: 1,
    backgroundColor: 'rgba(15,23,42,0.42)',
    padding: 14,
    marginBottom: 20,
  },
  capabilityLeft: { flexDirection: 'row', alignItems: 'center', gap: 12, flex: 1, minWidth: 0 },
  capabilityCopy: { flex: 1, minWidth: 0 },
  capabilityTitle: { color: LIGHT_TEXT, fontSize: 15, fontWeight: '800' },
  capabilitySub: { color: MUTED_TEXT, fontSize: 12, fontWeight: '600', marginTop: 2 },
  statusPill: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 999,
  },
  statusPillText: { fontSize: 12, fontWeight: '800' },

  servicesLead: {
    color: MUTED_TEXT,
    fontSize: 13,
    fontWeight: '600',
    lineHeight: 18,
    paddingTop: 10,
    paddingBottom: 12,
  },
  tagWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 14 },
  tag: {
    borderWidth: 1,
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  tagText: { color: LIGHT_TEXT, fontSize: 12, fontWeight: '700' },
  servicesEmpty: {
    color: MUTED_TEXT,
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 14,
  },
  manageBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderWidth: 1,
    borderRadius: 14,
    padding: 12,
    marginBottom: 10,
  },
  manageBtnCopy: { flex: 1, minWidth: 0 },
  manageBtnTitle: { color: LIGHT_TEXT, fontSize: 14, fontWeight: '800' },
  manageBtnSub: { color: MUTED_TEXT, fontSize: 12, fontWeight: '600', marginTop: 2 },

  saveBar: {
    paddingHorizontal: 20,
    paddingTop: 10,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(255,255,255,0.08)',
    backgroundColor: 'rgba(10,25,41,0.92)',
  },
});
