import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
  Alert,
  Platform,
  Image,
} from 'react-native';
import Reanimated, {
  Easing,
  FadeIn,
  FadeInDown,
  FadeInUp,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withRepeat,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import InlineToast, { type ToastState } from '../../../src/components/shared/InlineToast';
import InfoBottomSheet from '../../../src/components/shared/InfoBottomSheet';
import GlassSurface from '../../../src/components/shared/GlassSurface';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import AnimatedProgress from '../../../src/components/booking/AnimatedProgress';
import GlassOrb from '../../../src/components/valeter/road/GlassOrb';
import { PressableScale, PulseDot, useValeterFitInsets } from '../../../src/components/shared/fit/FitKit';
import type { IconGlyphName } from '../../../src/components/shared/iconGlyphTypes';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system/legacy';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { DVLA_CONFIG } from '../../../src/config/dvla';
import { colors } from '../../../src/constants/colors';
import DefaultLoadingSkeleton from '../../../src/components/shared/DefaultLoadingSkeleton';
import ValeterScreenHeader, {
  useValeterHeaderContentOffset,
} from '../../../src/components/valeter/ValeterScreenHeader';
import { lightMistElevated, lightMistInput, VALETER_BG_FALLBACK } from '../../../src/constants/accountThemes';
import {
  valeterStripeConnectService,
  type StripeConnectStatus,
} from '../../../src/services/valeterStripeConnectService';
import { toast as appToast } from '../../../src/components/shared/ToastHost';

const BUCKET = 'valeter_documents';
const IMAGE_MEDIA_TYPES: any = (ImagePicker as any)?.MediaType?.Images ? [(ImagePicker as any).MediaType.Images] : undefined;

const getExtAndMimeFromUri = (uri: string) => {
  const clean = (uri || '').split('?')[0];
  const extRaw = (clean.split('.').pop() || 'jpg').toLowerCase();
  const ext = extRaw === 'jpg' ? 'jpeg' : extRaw;
  let mime = 'image/jpeg';
  if (ext === 'png') mime = 'image/png';
  else if (ext === 'webp') mime = 'image/webp';
  return { extRaw, ext, mime };
};

const base64ToUint8Array = (base64: string) => {
  const binary = globalThis.atob ? globalThis.atob(base64) : Buffer.from(base64, 'base64').toString('binary');
  const len = binary.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) bytes[i] = binary.codePointAt(i) ?? 0;
  return bytes;
};

const SKY = colors.SKY ?? '#38BDF8';
const GREEN = '#34D399';

const CARD_BG = 'rgba(255,255,255,0.06)';
const CARD_BORDER = 'rgba(255,255,255,0.08)';
const LABEL_MUTED = 'rgba(255,255,255,0.5)';
const VALUE_WHITE = '#F8FAFC';

interface ValeterProfileData {
  user_id: string;
  vehicle_make?: string;
  vehicle_model?: string;
  vehicle_registration?: string;
  vehicle_photo_url?: string | null;
  tax_status?: string;
  tax_due_date?: string;
  mot_status?: string;
  mot_expiry_date?: string;
}

const formatUkReg = (reg: string) => {
  const r = (reg || '').replace(/\s/g, '').toUpperCase();
  if (!r) return 'NO REG';
  if (r.length <= 4) return r;
  return `${r.slice(0, 4)} ${r.slice(4)}`;
};

type ComplianceTone = 'ok' | 'soon' | 'bad' | 'unknown';

const THREE_MONTHS_MS = 1000 * 60 * 60 * 24 * 92;

function parseComplianceDate(raw?: string | null): Date | null {
  if (!raw?.trim()) return null;
  const parsed = new Date(raw);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

function getExpiryTone(expiry?: string | null): ComplianceTone | null {
  const date = parseComplianceDate(expiry);
  if (!date) return null;
  const end = new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
  const today = new Date();
  const start = new Date(today.getFullYear(), today.getMonth(), today.getDate()).getTime();
  const delta = end - start;
  if (delta < 0) return 'bad';
  if (delta <= THREE_MONTHS_MS) return 'soon';
  return 'ok';
}

function getTaxTone(status?: string | null, dueDate?: string | null): ComplianceTone {
  const s = (status || '').trim().toLowerCase();
  if (s.includes('untaxed') || s === 'sorn' || s.includes('not taxed')) return 'bad';
  const byDate = getExpiryTone(dueDate);
  if (byDate === 'bad') return 'bad';
  if (byDate === 'soon') return 'soon';
  if (s === 'taxed' || byDate === 'ok') return 'ok';
  if (s && s !== 'taxed') return 'bad';
  return 'unknown';
}

function getMotTone(status?: string | null, expiryDate?: string | null): ComplianceTone {
  const s = (status || '').trim().toLowerCase();
  if (s.includes('not valid') || s === 'invalid' || s.includes('expired')) return 'bad';
  const byDate = getExpiryTone(expiryDate);
  if (byDate === 'bad') return 'bad';
  if (byDate === 'soon') return 'soon';
  if (s === 'valid' || byDate === 'ok') return 'ok';
  if (s && s !== 'valid' && !s.includes('no details')) return 'bad';
  return 'unknown';
}

const TONE_COLOR: Record<ComplianceTone, string> = {
  ok: '#4ADE80',
  soon: '#FB923C',
  bad: '#F87171',
  unknown: '#94A3B8',
};

function daysUntil(raw?: string | null): number | null {
  const date = parseComplianceDate(raw);
  if (!date) return null;
  const end = new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  return Math.round((end - start) / (1000 * 60 * 60 * 24));
}

function formatShortDate(raw?: string | null) {
  const d = parseComplianceDate(raw);
  return d ? d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : null;
}

function docText(tone: ComplianceTone, status?: string | null, expiry?: string | null) {
  const days = daysUntil(expiry);
  if (tone === 'bad') return days != null && days < 0 ? `Expired ${Math.abs(days)}d ago` : status || 'Not valid';
  if (tone === 'soon') return days === 0 ? 'Due today' : `Due in ${days}d`;
  const date = formatShortDate(expiry);
  if (date) return `Until ${date}`;
  return status || 'Not checked';
}

function toneScore(t: ComplianceTone, full: number) {
  if (t === 'ok') return full;
  if (t === 'soon') return full / 2;
  return 0;
}

function scoreColorFor(score: number) {
  if (score >= 80) return GREEN;
  if (score >= 50) return '#FBBF24';
  return '#F87171';
}

function primaryActionLabel(canDvla: boolean, hasRegistration: boolean) {
  if (canDvla) return 'Check Tax & MOT';
  return hasRegistration ? 'Update details' : 'Add vehicle details';
}

function garageSubtitle(hasRegistration: boolean, taxTone: ComplianceTone, motTone: ComplianceTone) {
  if (!hasRegistration) return 'Add your reg to get road ready';
  if (taxTone === 'bad' || motTone === 'bad') return 'MOT or tax expired';
  if (taxTone === 'soon' || motTone === 'soon') return 'MOT or tax due soon';
  if (taxTone === 'unknown' || motTone === 'unknown') return 'Check your MOT & tax';
  return 'Road ready · seen by customers on every job';
}

function applyDvlaResult(prev: ValeterProfileData | null, data: any): ValeterProfileData | null {
  if (!prev) return prev;
  return {
    ...prev,
    vehicle_make: data.make ?? prev.vehicle_make,
    tax_status: data.taxStatus ?? null,
    tax_due_date: data.taxDueDate ?? null,
    mot_status: data.motStatus ?? null,
    mot_expiry_date: data.motExpiryDate ?? null,
  };
}

/** Asks for permission, opens the camera or library, and returns the picked photo's uri (or null). */
async function pickVehiclePhoto(source: 'camera' | 'library'): Promise<string | null> {
  const camera = source === 'camera';
  const perm = camera
    ? await ImagePicker.requestCameraPermissionsAsync()
    : await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (perm.status !== 'granted') {
    appToast.error(camera ? 'Camera access is required to take a photo.' : 'Photo library access is required.', 'Permission needed');
    return null;
  }
  const options = { mediaTypes: IMAGE_MEDIA_TYPES, allowsEditing: true, aspect: [16, 10] as [number, number], quality: 0.85 };
  const result = camera ? await ImagePicker.launchCameraAsync(options) : await ImagePicker.launchImageLibraryAsync(options);
  if (result.canceled) return null;
  return result.assets?.[0]?.uri ?? null;
}

function storageUploadError(error: { message?: string }) {
  const msg = String(error?.message || '').toLowerCase();
  if (msg.includes('bucket') || msg.includes('not found')) return new Error("Storage bucket 'valeter_documents' not found.");
  if (msg.includes('policy') || msg.includes('permission')) return new Error('Upload blocked by storage policy.');
  return error;
}

/** Garage unlocks once Stripe onboarding is complete. */
function useStripeStatus(userId: string | undefined) {
  const [stripeStatus, setStripeStatus] = useState<StripeConnectStatus | null>(null);
  const [stripeStatusLoading, setStripeStatusLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    const loadStripeStatus = async () => {
      if (!userId) {
        if (mounted) {
          setStripeStatus(null);
          setStripeStatusLoading(false);
        }
        return;
      }
      try {
        if (mounted) setStripeStatusLoading(true);
        const status = await valeterStripeConnectService.getStatus(userId);
        if (mounted) setStripeStatus(status.stripeConnectStatus);
      } catch (error) {
        console.warn('[ValeterVehicleInfo] failed to load stripe status', error);
        if (mounted) setStripeStatus('not_started');
      } finally {
        if (mounted) setStripeStatusLoading(false);
      }
    };

    void loadStripeStatus();

    return () => {
      mounted = false;
    };
  }, [userId]);

  return { stripeStatus, stripeStatusLoading };
}

function useGarageTheme() {
  const { theme } = useAccountTheme();
  const gradientBg = (theme?.background || VALETER_BG_FALLBACK) as [string, string];
  const isLight = theme?.mode === 'light';
  const stageGradient: [string, string, string] = [gradientBg[0], isLight ? '#3A5F78' : '#0E2740', gradientBg[1]];
  return {
    gradientBg,
    isLight,
    stageGradient,
    primary: theme?.primary ?? SKY,
    textMain: theme?.textPrimary ?? VALUE_WHITE,
    textMuted: theme?.textSecondary ?? LABEL_MUTED,
  };
}

/** 0–100: how complete and road-legal the work vehicle looks to customers. */
function readinessScore(p: ValeterProfileData, taxTone: ComplianceTone, motTone: ComplianceTone) {
  let score = 0;
  if ((p.vehicle_registration || '').trim()) score += 25;
  if ((p.vehicle_make || p.vehicle_model || '').trim()) score += 15;
  if (p.vehicle_photo_url) score += 20;
  score += toneScore(taxTone, 20);
  score += toneScore(motTone, 20);
  return Math.round(score);
}

/** Light band that sweeps across the showroom stage. */
function StageSweep() {
  const x = useSharedValue(-1);
  useEffect(() => {
    x.value = withRepeat(
      withSequence(
        withTiming(1, { duration: 2200, easing: Easing.inOut(Easing.quad) }),
        withDelay(2600, withTiming(-1, { duration: 0 }))
      ),
      -1
    );
  }, [x]);
  const style = useAnimatedStyle(() => ({ transform: [{ translateX: x.value * 420 }, { rotate: '18deg' }] }));
  return (
    <Reanimated.View pointerEvents="none" style={[styles.sweep, style]}>
      <LinearGradient
        colors={['transparent', 'rgba(255,255,255,0.16)', 'transparent']}
        start={{ x: 0, y: 0.5 }}
        end={{ x: 1, y: 0.5 }}
        style={StyleSheet.absoluteFill}
      />
    </Reanimated.View>
  );
}

function UkPlate({ registration }: Readonly<{ registration: string }>) {
  return (
    <View style={styles.plate}>
      <View style={styles.plateBand}>
        <Text style={styles.plateBandText}>UK</Text>
      </View>
      <Text style={styles.plateText}>{formatUkReg(registration)}</Text>
    </View>
  );
}

function DocRow({
  icon,
  label,
  value,
  color,
  alert,
}: Readonly<{ icon: IconGlyphName; label: string; value: string; color: string; alert?: boolean }>) {
  return (
    <View style={styles.docRow}>
      <Ionicons name={icon} size={17} color={color} />
      <Text style={styles.docLabel}>{label}</Text>
      {alert ? <PulseDot color={color} size={6} /> : null}
      <Text style={[styles.docValue, { color: color === TONE_COLOR.ok ? '#E2E8F0' : color }]} numberOfLines={1}>
        {value}
      </Text>
    </View>
  );
}

function RoundAction({
  icon,
  color,
  label,
  onPress,
  busy,
  disabled,
}: Readonly<{
  icon: IconGlyphName;
  color: string;
  label: string;
  onPress: () => void;
  busy?: boolean;
  disabled?: boolean;
}>) {
  return (
    <PressableScale onPress={disabled ? undefined : onPress} accessibilityLabel={label} style={styles.roundCell}>
      <GlassSurface style={styles.round} interactive fallbackColor="rgba(255,255,255,0.08)">
        {busy ? <ActivityIndicator size="small" color={color} /> : <Ionicons name={icon} size={18} color={color} />}
      </GlassSurface>
      <Text style={styles.roundLabel}>{label}</Text>
    </PressableScale>
  );
}

/** Vehicle photo (or empty prompt) on the showroom stage, with the camera pill. */
function StagePhoto({ photoUrl, uploading, primary }: Readonly<{ photoUrl?: string | null; uploading: boolean; primary: string }>) {
  return (
    <>
      {photoUrl ? (
        <>
          <Image source={{ uri: photoUrl }} style={styles.stageImage} resizeMode="cover" />
          <LinearGradient
            colors={['transparent', 'rgba(0,0,0,0.1)', 'rgba(0,0,0,0.55)']}
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
          />
        </>
      ) : (
        <View style={styles.stageEmpty}>
          <GlassOrb icon="car-sport" accent={primary} size={84} />
          <Text style={styles.stageEmptyTitle}>Add your work vehicle</Text>
          <Text style={styles.stageEmptySub}>Tap to add a photo customers will see</Text>
        </View>
      )}
      <View style={styles.floorShadow} pointerEvents="none" />
      <StageSweep />
      <View style={styles.cameraPill} pointerEvents="none">
        {uploading ? (
          <ActivityIndicator size="small" color="#fff" />
        ) : (
          <>
            <Ionicons name="camera" size={13} color="#fff" />
            <Text style={styles.cameraPillText}>{photoUrl ? 'Change' : 'Add photo'}</Text>
          </>
        )}
      </View>
    </>
  );
}

function DvlaButton({ primary, busy, onPress }: Readonly<{ primary: string; busy: boolean; onPress: () => void }>) {
  return (
    <TouchableOpacity
      style={[styles.dvlaBtn, { borderColor: `${primary}40`, backgroundColor: `${primary}10` }]}
      onPress={onPress}
      disabled={busy}
      activeOpacity={0.85}
    >
      {busy ? (
        <ActivityIndicator size="small" color={primary} />
      ) : (
        <>
          <Ionicons name="search-outline" size={18} color={primary} />
          <Text style={[styles.dvlaBtnText, { color: primary }]}>Pull Tax & MOT from DVLA</Text>
        </>
      )}
    </TouchableOpacity>
  );
}

export default function ValeterVehicleInfo() {
  const { user, isLoading: authLoading } = useAuth();
  const headerOffset = useValeterHeaderContentOffset(10);
  const { gradientBg, isLight, stageGradient, primary, textMain, textMuted } = useGarageTheme();
  const inputBg = isLight ? lightMistInput : CARD_BG;
  const inputBorder = isLight ? 'rgba(158,201,224,0.32)' : CARD_BORDER;

  const [profile, setProfile] = useState<ValeterProfileData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isLookingUpDVLA, setIsLookingUpDVLA] = useState(false);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const { stripeStatus, stripeStatusLoading } = useStripeStatus(user?.id);
  const [toast, setToast] = useState<ToastState>(null);
  const fit = useValeterFitInsets(10);
  const editSnapshot = useRef<ValeterProfileData | null>(null);

  const tiltX = useSharedValue(0);
  const tiltY = useSharedValue(0);
  const stageScale = useSharedValue(1);
  const tiltStyle = useAnimatedStyle(() => ({
    transform: [
      { perspective: 900 },
      { rotateY: `${tiltY.value}deg` },
      { rotateX: `${tiltX.value}deg` },
      { scale: stageScale.value },
    ],
  }));

  useEffect(() => {
    if (user?.id) void loadProfile();
  }, [user?.id]);

  const loadProfile = async () => {
    try {
      setIsLoading(true);
      const { data } = await supabase
        .from('valeter_profiles')
        .select('*')
        .eq('user_id', user!.id)
        .maybeSingle();
      if (data) setProfile(data);
      else {
        const { data: created } = await supabase
          .from('valeter_profiles')
          .insert({ user_id: user!.id, full_name: ' ' })
          .select()
          .single();
        setProfile(created);
      }
    } catch {
      appToast.error('Failed to load vehicle information');
    } finally {
      setIsLoading(false);
    }
  };

  const refreshProfile = async () => {
    if (!user?.id || refreshing) return;
    try {
      setRefreshing(true);
      const { data } = await supabase.from('valeter_profiles').select('*').eq('user_id', user.id).maybeSingle();
      if (data) setProfile(data);
      void hapticFeedback('light');
    } catch {
      setToast({ kind: 'error', message: 'Could not refresh your garage' });
    } finally {
      setRefreshing(false);
    }
  };

  const lookupDVLA = async (registration: string) => {
    if (!registration?.trim()) {
      Alert.alert('Enter registration', 'Add your registration to look up details.');
      return;
    }
    if (!DVLA_CONFIG.apiKey) {
      Alert.alert('DVLA not configured', 'Missing DVLA API key');
      return;
    }
    try {
      setIsLookingUpDVLA(true);
      const res = await fetch(DVLA_CONFIG.baseUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': DVLA_CONFIG.apiKey },
        body: JSON.stringify({ registrationNumber: registration.trim() }),
      });
      if (!res.ok) throw new Error('DVLA lookup failed');
      const data = await res.json();
      setProfile((prev) => applyDvlaResult(prev, data));
      await hapticFeedback('success');
      setToast({ kind: 'success', message: 'Tax & MOT updated from DVLA — tap Save' });
    } catch (e: any) {
      setToast({ kind: 'error', message: e.message || 'DVLA lookup failed' });
    } finally {
      setIsLookingUpDVLA(false);
    }
  };

  const uploadVehiclePhotoToStorage = async (uri: string): Promise<string> => {
    if (!user?.id) throw new Error('No user');
    const { extRaw, mime } = getExtAndMimeFromUri(uri);
    const fileName = `vehicle_${user.id}_${Date.now()}.${extRaw || 'jpg'}`;
    const storagePath = `vehicles/${user.id}/${fileName}`;
    const base64 = await FileSystem.readAsStringAsync(uri, { encoding: 'base64' as any });
    const bytes = base64ToUint8Array(base64);
    const { data, error } = await supabase.storage.from(BUCKET).upload(storagePath, bytes, { contentType: mime, upsert: true });
    if (error) throw storageUploadError(error);
    const { data: pub } = supabase.storage.from(BUCKET).getPublicUrl(data?.path ?? storagePath);
    return pub?.publicUrl ?? storagePath;
  };

  const persistVehiclePhotoUrl = async (publicUrl: string) => {
    if (!user?.id) return;
    const { error } = await supabase
      .from('valeter_profiles')
      .update({ vehicle_photo_url: publicUrl })
      .eq('user_id', user.id);
    if (error) {
      const msg = String(error?.message || '').toLowerCase();
      if (msg.includes('column') && msg.includes('vehicle_photo')) return;
      throw error;
    }
    setProfile(prev => (prev ? { ...prev, vehicle_photo_url: publicUrl } : null));
  };

  const onVehiclePhotoPicked = async (uri: string) => {
    try {
      setUploadingPhoto(true);
      const publicUrl = await uploadVehiclePhotoToStorage(uri);
      await persistVehiclePhotoUrl(publicUrl);
      void hapticFeedback('success');
      setToast({ kind: 'success', message: 'Vehicle photo updated' });
    } catch (e: any) {
      setToast({ kind: 'error', message: e?.message ?? 'Upload failed — please try again' });
    } finally {
      setUploadingPhoto(false);
    }
  };

  const pickAndUpload = async (source: 'camera' | 'library') => {
    const uri = await pickVehiclePhoto(source);
    if (uri) await onVehiclePhotoPicked(uri);
  };

  const showVehiclePhotoOptions = () => {
    void hapticFeedback('light');
    Alert.alert(
      'Vehicle photo',
      'Choose a photo of your vehicle',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Take photo', onPress: () => void pickAndUpload('camera') },
        { text: 'Choose from library', onPress: () => void pickAndUpload('library') },
      ]
    );
  };

  const handleSaveProfile = async () => {
    if (!profile || !user?.id) return;
    try {
      setIsSaving(true);
      const payload: Record<string, unknown> = {
        vehicle_make: profile.vehicle_make,
        vehicle_model: profile.vehicle_model,
        vehicle_registration: profile.vehicle_registration,
        tax_status: profile.tax_status,
        tax_due_date: profile.tax_due_date,
        mot_status: profile.mot_status,
        mot_expiry_date: profile.mot_expiry_date,
      };
      if (profile.vehicle_photo_url !== undefined) payload.vehicle_photo_url = profile.vehicle_photo_url;
      const { error } = await supabase.from('valeter_profiles').update(payload).eq('user_id', user.id);
      if (error) throw error;
      await hapticFeedback('success');
      setToast({ kind: 'success', message: 'Saved to your garage' });
      editSnapshot.current = null;
      setIsEditing(false);
    } catch (e: any) {
      setToast({ kind: 'error', message: e.message || 'Failed to save vehicle details' });
    } finally {
      setIsSaving(false);
    }
  };

  const openEditor = (runDvla = false) => {
    if (!profile) return;
    void hapticFeedback('light');
    editSnapshot.current = profile;
    setIsEditing(true);
    if (runDvla) void lookupDVLA(profile.vehicle_registration || '');
  };

  const closeEditor = () => {
    if (editSnapshot.current) setProfile(editSnapshot.current);
    editSnapshot.current = null;
    setIsEditing(false);
  };

  const renderLockedState = () => (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />
      <ValeterScreenHeader title="My garage" />
      <View style={[styles.lockStateWrap, { paddingTop: headerOffset }]}>
        <View
          style={[
            styles.lockStateCard,
            { borderColor: `${primary}28`, backgroundColor: isLight ? lightMistElevated : 'rgba(255,255,255,0.06)' },
          ]}
        >
          <View style={[styles.lockStateIconWrap, { backgroundColor: `${primary}18`, borderColor: `${primary}35` }]}>
            <Ionicons name="lock-closed" size={28} color={primary} />
          </View>
          <Text style={[styles.lockStateTitle, { color: textMain }]}>Vehicle setup locked</Text>
          <Text style={[styles.lockStateBody, { color: textMuted }]}>
            This page will become available after sign up is completed.
          </Text>
          <Text style={[styles.lockStateHint, { color: textMuted }]}>
            Finish onboarding and set up "Get paid" first, then come back here to add your vehicle details.
          </Text>
          <TouchableOpacity
            style={[styles.lockStateButton, { backgroundColor: primary }]}
            onPress={() => {
              void hapticFeedback('light');
              router.push('/valeter/valeter-onboarding');
            }}
            activeOpacity={0.88}
          >
            <Text style={styles.lockStateButtonText}>Continue sign up</Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );

  if (authLoading || stripeStatusLoading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="valeter" />
        <ValeterScreenHeader title="My garage" />
        <View style={[styles.loadingWrap, { paddingTop: headerOffset }]}>
          <DefaultLoadingSkeleton message="Loading…" />
        </View>
      </SafeAreaView>
    );
  }

  if (stripeStatus !== 'completed') {
    return renderLockedState();
  }

  if (isLoading || !profile) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="valeter" />
        <ValeterScreenHeader title="My garage" />
        <View style={[styles.loadingWrap, { paddingTop: headerOffset }]}>
          <DefaultLoadingSkeleton message="Loading…" />
        </View>
      </SafeAreaView>
    );
  }

  const hasRegistration = !!(profile.vehicle_registration || '').trim();
  const canDvla = hasRegistration && !!DVLA_CONFIG.apiKey;
  const taxTone = getTaxTone(profile.tax_status, profile.tax_due_date);
  const motTone = getMotTone(profile.mot_status, profile.mot_expiry_date);
  const score = readinessScore(profile, taxTone, motTone);
  const scoreColor = scoreColorFor(score);

  const vehicleTitle =
    [profile.vehicle_make, profile.vehicle_model].filter(Boolean).join(' ') || 'Your valeting vehicle';

  const headerSubtitle = garageSubtitle(hasRegistration, taxTone, motTone);

  const stagePan = Gesture.Pan()
    .minDistance(4)
    .onBegin(() => {
      stageScale.value = withSpring(0.98, { damping: 18, stiffness: 300 });
    })
    .onUpdate((e) => {
      tiltY.value = Math.max(-14, Math.min(14, e.translationX / 12));
      tiltX.value = Math.max(-10, Math.min(10, -e.translationY / 14));
    })
    .onFinalize(() => {
      tiltX.value = withSpring(0, { damping: 9, stiffness: 140 });
      tiltY.value = withSpring(0, { damping: 9, stiffness: 140 });
      stageScale.value = withSpring(1, { damping: 14, stiffness: 260 });
    });
  const stageTap = Gesture.Tap()
    .enabled(!uploadingPhoto)
    .runOnJS(true)
    .onEnd((_e, success) => {
      if (success) showVehiclePhotoOptions();
    });
  const stageGesture = Gesture.Exclusive(stagePan, stageTap);

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <LinearGradient
        colors={
          isLight
            ? ['rgba(158,201,224,0.16)', 'rgba(232,197,71,0.06)', 'rgba(42,70,96,0.5)']
            : ['rgba(56,189,248,0.08)', 'transparent', 'rgba(15,23,42,0.6)']
        }
        style={styles.garageAmbient}
        pointerEvents="none"
      />
      <BubbleBackground accountType="valeter" />
      <ValeterScreenHeader title="My garage" />
      <InlineToast toast={toast} onHide={() => setToast(null)} />

      <View style={[styles.content, { paddingTop: fit.top, paddingBottom: fit.bottom }]}>
        <View style={styles.header}>
          <View style={styles.flex}>
            <Text style={styles.kicker}>YOUR GARAGE</Text>
            <Text style={styles.subtitle} numberOfLines={1}>
              {headerSubtitle}
            </Text>
          </View>
          <Text style={[styles.tip, { color: textMuted }]}>Drag to tilt</Text>
        </View>

        <Reanimated.View entering={FadeInDown.springify().damping(18)} style={styles.stageWrap}>
        <GestureDetector gesture={stageGesture}>
          <Reanimated.View
            style={[styles.stage, { borderColor: `${primary}25`, backgroundColor: gradientBg[1] }, tiltStyle]}
          >
            <LinearGradient colors={stageGradient} style={StyleSheet.absoluteFill} pointerEvents="none" />
            <LinearGradient
              colors={[`${primary}38`, `${primary}00`]}
              start={{ x: 0.5, y: 1 }}
              end={{ x: 0.5, y: 0 }}
              style={StyleSheet.absoluteFill}
              pointerEvents="none"
            />
            <StagePhoto photoUrl={profile.vehicle_photo_url} uploading={uploadingPhoto} primary={primary} />
          </Reanimated.View>
        </GestureDetector>
        </Reanimated.View>

        <Reanimated.View entering={FadeInUp.delay(80).springify().damping(18)} style={styles.identity}>
          <UkPlate registration={profile.vehicle_registration || ''} />
          <Text style={[styles.name, { color: textMain }]} numberOfLines={1} adjustsFontSizeToFit>
            {vehicleTitle}
          </Text>
        </Reanimated.View>

        <Reanimated.View entering={FadeInUp.delay(140).springify().damping(18)}>
          <GlassSurface style={styles.panel} fallbackColor="rgba(10,25,41,0.55)">
            <View style={styles.scoreCol}>
              <AnimatedProgress progress={score} size={62} strokeWidth={5} showPercentage color={scoreColor} />
              <Text style={styles.scoreLabel}>Road ready</Text>
            </View>
            <View style={styles.docs}>
              <DocRow
                icon="shield-checkmark"
                label="MOT"
                value={docText(motTone, profile.mot_status, profile.mot_expiry_date)}
                color={TONE_COLOR[motTone]}
                alert={motTone === 'bad' || motTone === 'soon'}
              />
              <DocRow
                icon="receipt"
                label="Tax"
                value={docText(taxTone, profile.tax_status, profile.tax_due_date)}
                color={TONE_COLOR[taxTone]}
                alert={taxTone === 'bad' || taxTone === 'soon'}
              />
              <DocRow
                icon="image"
                label="Photo"
                value={profile.vehicle_photo_url ? 'Showing to customers' : 'Missing'}
                color={profile.vehicle_photo_url ? TONE_COLOR.ok : TONE_COLOR.soon}
              />
            </View>
          </GlassSurface>
        </Reanimated.View>

        <PressableScale
          onPress={() => openEditor(canDvla)}
          accessibilityLabel={canDvla ? 'Check tax and MOT with DVLA' : 'Add vehicle details'}
        >
          <GlassSurface style={styles.primaryBtn} tintColor={`${primary}66`} interactive fallbackColor={`${primary}55`}>
            <Ionicons name={canDvla ? 'search' : 'add'} size={16} color="#F0F9FF" />
            <Text style={styles.primaryBtnText}>{primaryActionLabel(canDvla, hasRegistration)}</Text>
          </GlassSurface>
        </PressableScale>

        <View style={styles.roundRow}>
          <RoundAction icon="create-outline" color={primary} label="Edit" onPress={() => openEditor(false)} />
          <RoundAction
            icon="camera-outline"
            color="#E2E8F0"
            label="Photo"
            busy={uploadingPhoto}
            disabled={uploadingPhoto}
            onPress={showVehiclePhotoOptions}
          />
          <RoundAction
            icon="refresh"
            color={GREEN}
            label="Refresh"
            busy={refreshing}
            disabled={refreshing}
            onPress={() => void refreshProfile()}
          />
        </View>
      </View>

      <InfoBottomSheet
        visible={isEditing}
        onClose={closeEditor}
        title="Update your garage"
        accentColor={primary}
        sizeToContent
        contentMaxHeight="80%"
      >
        <Reanimated.View entering={FadeIn.duration(200)} style={styles.form}>
          <View style={styles.field}>
            <Text style={[styles.fieldLabel, { color: textMuted }]}>Registration</Text>
            <TextInput
              style={[styles.input, { color: textMain, borderColor: inputBorder, backgroundColor: inputBg }]}
              value={profile.vehicle_registration || ''}
              autoCapitalize="characters"
              onChangeText={(t) =>
                setProfile({
                  ...profile,
                  vehicle_registration: t.replace(/\s/g, '').toUpperCase().slice(0, 8),
                })
              }
              placeholder="AB12 CDE"
              placeholderTextColor={textMuted}
            />
          </View>
          <View style={styles.field}>
            <Text style={[styles.fieldLabel, { color: textMuted }]}>Model</Text>
            <TextInput
              style={[styles.input, { color: textMain, borderColor: inputBorder, backgroundColor: inputBg }]}
              value={profile.vehicle_model || ''}
              onChangeText={(t) => setProfile({ ...profile, vehicle_model: t })}
              placeholder="Transit Custom"
              placeholderTextColor={textMuted}
            />
          </View>
          {profile.vehicle_make ? (
            <Text style={[styles.makeHint, { color: textMuted }]}>Make: {profile.vehicle_make} (from DVLA)</Text>
          ) : null}

          {(profile.vehicle_registration || '').trim() && DVLA_CONFIG.apiKey ? (
            <View style={styles.dvlaBlock}>
              <DvlaButton
                primary={primary}
                busy={isLookingUpDVLA}
                onPress={() => void lookupDVLA(profile.vehicle_registration || '')}
              />
              <View style={styles.dvlaResult}>
                <Text style={styles.dvlaResultText} numberOfLines={1}>
                  MOT: <Text style={{ color: TONE_COLOR[motTone] }}>{docText(motTone, profile.mot_status, profile.mot_expiry_date)}</Text>
                </Text>
                <Text style={styles.dvlaResultText} numberOfLines={1}>
                  Tax: <Text style={{ color: TONE_COLOR[taxTone] }}>{docText(taxTone, profile.tax_status, profile.tax_due_date)}</Text>
                </Text>
              </View>
            </View>
          ) : null}

          <TouchableOpacity
            style={[styles.saveBtn, { backgroundColor: primary }]}
            onPress={handleSaveProfile}
            disabled={isSaving}
            activeOpacity={0.88}
          >
            {isSaving ? <ActivityIndicator color="#fff" size="small" /> : <Text style={styles.saveBtnText}>Save to garage</Text>}
          </TouchableOpacity>
        </Reanimated.View>
      </InfoBottomSheet>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  flex: { flex: 1 },
  garageAmbient: { ...StyleSheet.absoluteFill, opacity: 0.9 },
  loadingWrap: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  lockStateWrap: { flex: 1, paddingHorizontal: 20, justifyContent: 'center' },
  lockStateCard: {
    borderRadius: 24,
    borderWidth: 1,
    paddingVertical: 28,
    paddingHorizontal: 22,
    alignItems: 'center',
    gap: 12,
  },
  lockStateIconWrap: {
    width: 60,
    height: 60,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  },
  lockStateTitle: { fontSize: 20, fontWeight: '900', textAlign: 'center', letterSpacing: -0.2 },
  lockStateBody: { fontSize: 15, fontWeight: '700', textAlign: 'center', lineHeight: 22 },
  lockStateHint: { fontSize: 13, fontWeight: '600', textAlign: 'center', lineHeight: 19, opacity: 0.95 },
  lockStateButton: {
    marginTop: 6,
    minHeight: 48,
    alignSelf: 'stretch',
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 16,
  },
  lockStateButtonText: { color: '#fff', fontSize: 15, fontWeight: '800' },

  content: { flex: 1, paddingHorizontal: 18, gap: 12 },
  header: { flexDirection: 'row', alignItems: 'flex-end', gap: 10 },
  kicker: { fontSize: 10, fontWeight: '800', color: 'rgba(186,230,253,0.92)', letterSpacing: 1.2 },
  subtitle: { color: 'rgba(148,163,184,0.95)', fontSize: 12, fontWeight: '600', marginTop: 2 },
  tip: { fontSize: 11, fontWeight: '600' },

  stageWrap: { flex: 1, minHeight: 120 },
  stage: {
    flex: 1,
    borderRadius: 28,
    borderWidth: 1,
    overflow: 'hidden',
    ...Platform.select({
      ios: { shadowColor: '#000', shadowOffset: { width: 0, height: 10 }, shadowOpacity: 0.35, shadowRadius: 18 },
      android: { elevation: 8 },
    }),
  },
  stageImage: { ...StyleSheet.absoluteFill },
  stageEmpty: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 24, gap: 6 },
  stageEmptyTitle: { color: VALUE_WHITE, fontSize: 16, fontWeight: '800', marginTop: 8 },
  stageEmptySub: { color: LABEL_MUTED, fontSize: 13, fontWeight: '500', textAlign: 'center' },
  floorShadow: {
    position: 'absolute',
    left: '18%',
    right: '18%',
    bottom: 10,
    height: 10,
    borderRadius: 999,
    backgroundColor: 'rgba(2,6,23,0.45)',
  },
  sweep: { position: 'absolute', top: -60, bottom: -60, left: '30%', width: 80 },
  cameraPill: {
    position: 'absolute',
    top: 12,
    right: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 10,
    height: 28,
    borderRadius: 14,
    backgroundColor: 'rgba(2,10,24,0.5)',
  },
  cameraPillText: { color: '#fff', fontSize: 11.5, fontWeight: '700' },

  identity: { alignItems: 'center', gap: 6 },
  plate: { flexDirection: 'row', alignItems: 'stretch', borderRadius: 7, overflow: 'hidden', backgroundColor: '#F8D70C' },
  plateBand: { width: 22, backgroundColor: '#003399', alignItems: 'center', justifyContent: 'center' },
  plateBandText: { color: '#FFFFFF', fontSize: 8, fontWeight: '900' },
  plateText: {
    color: '#0F172A',
    fontSize: 16,
    fontWeight: '900',
    letterSpacing: 1.8,
    paddingHorizontal: 12,
    paddingVertical: 4,
  },
  name: { fontSize: 19, fontWeight: '800', maxWidth: '90%' },

  panel: { flexDirection: 'row', alignItems: 'center', gap: 16, paddingHorizontal: 16, paddingVertical: 12, borderRadius: 24 },
  scoreCol: { alignItems: 'center', gap: 4 },
  scoreLabel: { color: 'rgba(203,213,225,0.8)', fontSize: 10, fontWeight: '700' },
  docs: { flex: 1, gap: 10 },
  docRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  docLabel: { color: 'rgba(148,163,184,0.95)', fontSize: 12, fontWeight: '700', width: 42 },
  docValue: { flex: 1, color: '#E2E8F0', fontSize: 12, fontWeight: '700', textAlign: 'right' },

  primaryBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    height: 50,
    paddingHorizontal: 22,
    borderRadius: 25,
  },
  primaryBtnText: { color: '#F0F9FF', fontSize: 15, fontWeight: '800' },

  roundRow: { flexDirection: 'row', justifyContent: 'space-evenly' },
  roundCell: { alignItems: 'center' },
  round: { width: 46, height: 46, borderRadius: 23, alignItems: 'center', justifyContent: 'center' },
  roundLabel: { color: 'rgba(203,213,225,0.85)', fontSize: 11, fontWeight: '600', marginTop: 5, textAlign: 'center' },

  form: { gap: 12 },
  field: { gap: 6 },
  fieldLabel: { fontSize: 11, fontWeight: '800', textTransform: 'uppercase', letterSpacing: 0.8 },
  input: {
    fontSize: 16,
    fontWeight: '600',
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 12,
    borderWidth: 1,
  },
  makeHint: { fontSize: 12, fontWeight: '600' },
  dvlaBlock: { gap: 8 },
  dvlaBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingVertical: 14,
    paddingHorizontal: 14,
    borderRadius: 14,
    borderWidth: 1,
  },
  dvlaBtnText: { fontSize: 14, fontWeight: '700' },
  dvlaResult: { flexDirection: 'row', justifyContent: 'space-between', gap: 10, paddingHorizontal: 4 },
  dvlaResultText: { color: 'rgba(203,213,225,0.8)', fontSize: 12, fontWeight: '700', flexShrink: 1 },
  saveBtn: {
    paddingVertical: 16,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 4,
    ...Platform.select({
      ios: { shadowColor: SKY, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8 },
      android: { elevation: 4 },
    }),
  },
  saveBtnText: { color: '#fff', fontSize: 17, fontWeight: '700' },
});
