/**
 * Valeter Documents — verification hub: progress hero, one row per document,
 * tap a row to upload (camera / library) or preview what's on file.
 */
import React, { useEffect, useMemo, useState } from 'react';
import { View, Text, StyleSheet, Image, ActivityIndicator, ScrollView, RefreshControl } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import Reanimated, { FadeIn, FadeInDown } from 'react-native-reanimated';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import type { IconGlyphName } from '../../../src/components/shared/iconGlyphTypes';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import ValeterScreenHeader from '../../../src/components/valeter/ValeterScreenHeader';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import GlassSurface from '../../../src/components/shared/GlassSurface';
import GlassOrb from '../../../src/components/valeter/road/GlassOrb';
import InfoBottomSheet from '../../../src/components/shared/InfoBottomSheet';
import ValeterTrackingProgressRing from '../../../src/components/valeter/ValeterTrackingProgressRing';
import ContinueCTAButton from '../../../src/components/ui/ContinueCTAButton';
import LoadingScreen from '../../../src/components/LoadingScreen';
import { PressableScale, PulseDot, useValeterFitInsets } from '../../../src/components/shared/fit/FitKit';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import {
  valeterDocumentsSupabaseService,
  UploadedDocument,
} from '../../../src/services/ValeterDocumentsSupabaseService';
import { VALETER_CONTENT_BOTTOM_PAD } from '../../../src/components/valeter/ValeterNavSidebar';
import { toast } from '../../../src/components/shared/ToastHost';

const IMAGE_MEDIA_TYPES: any =
  (ImagePicker as any)?.MediaType?.Images ? [(ImagePicker as any).MediaType.Images] : undefined;

const GREEN = '#34D399';
const AMBER = '#FBBF24';
const RED = '#F87171';
const MUTED_DOT = 'rgba(248,250,252,0.35)';

type UiStatus = 'missing' | 'pending' | 'approved' | 'rejected';

interface RequiredDocument {
  id: string;
  name: string;
  description: string;
  required: boolean;
  icon: IconGlyphName;
}

const STAGES = ['Upload', 'Review', 'Verified'] as const;

const REQUIRED_DOCUMENTS: RequiredDocument[] = [
  {
    id: 'profile_photo',
    name: 'Profile Photo',
    description: 'Clear face shot on plain background',
    required: true,
    icon: 'camera',
  },
  {
    id: 'driving_license',
    name: 'Driving Licence',
    description: 'Valid UK driving licence',
    required: true,
    icon: 'car',
  },
  {
    id: 'id_proof',
    name: 'Passport/Birth certificate',
    description: 'Valid passport photo page or birth certificate',
    required: true,
    icon: 'id-card',
  },
  {
    id: 'public_liability',
    name: 'Public Liability Insurance',
    description: 'Minimum £2M coverage',
    required: true,
    icon: 'document-text',
  },
];

const SUPPORTING_DOCUMENTS: RequiredDocument[] = [
  {
    id: 'dbs_check',
    name: 'DBS Check',
    description: 'Enhanced DBS certificate',
    required: false,
    icon: 'shield-checkmark',
  },
];

const PHOTO_TIPS: ReadonlyArray<{ icon: IconGlyphName; text: string }> = [
  { icon: 'sunny-outline', text: 'Good light, no glare or shadows' },
  { icon: 'scan-outline', text: 'All four corners in the frame' },
  { icon: 'eye-outline', text: 'Text sharp and easy to read' },
];

const STATUS_META: Record<UiStatus, { label: string; color: string }> = {
  missing: { label: 'Not uploaded', color: MUTED_DOT },
  pending: { label: 'In review', color: AMBER },
  approved: { label: 'Approved', color: GREEN },
  rejected: { label: 'Rejected · re-upload', color: RED },
};

const wait = (ms: number) => new Promise((r) => setTimeout(r, ms));

function formatUploadDate(d?: Date | null): string | null {
  if (!d) return null;
  const date = d instanceof Date ? d : new Date(d);
  if (Number.isNaN(date.getTime())) return null;
  return date.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
}

const STATUS_BADGE_ICON: Record<UiStatus, IconGlyphName> = {
  missing: 'time',
  pending: 'time',
  approved: 'checkmark',
  rejected: 'close',
};

type HeroCopy = { kicker: string; title: string; body: string };

function heroCopyFor(activeStep: number, attention: boolean, rejected: number, missing: number): HeroCopy {
  if (activeStep === 3) {
    return { kicker: 'VERIFIED', title: "You're verified", body: 'Every required document is approved. Optional ones can still help you stand out.' };
  }
  if (attention) {
    return {
      kicker: 'ACTION NEEDED',
      title: rejected > 1 ? `${rejected} documents need fixing` : 'One document needs fixing',
      body: 'Re-upload the rejected file and we’ll carry on reviewing the rest.',
    };
  }
  if (activeStep === 2) {
    return { kicker: 'IN REVIEW', title: 'We’re checking your documents', body: 'Reviews usually take up to 24 hours. We’ll let you know.' };
  }
  return {
    kicker: 'GET VERIFIED',
    title: `${missing} left to upload`,
    body: 'Snap a clear photo of each one. Verified Pros get booked first.',
  };
}

function uiStatusOf(doc: UploadedDocument | undefined): UiStatus {
  if (!doc) return 'missing';
  if (doc.verificationStatus === 'approved') return 'approved';
  if (doc.verificationStatus === 'rejected') return 'rejected';
  return 'pending';
}

/** Required-document counts, the current verification step (1–3) and the next document needing action. */
function summarizeDocuments(documents: UploadedDocument[]) {
  const statusFor = (d: RequiredDocument) => uiStatusOf(documents.find((u) => u.docTypeId === d.id));
  const statuses = REQUIRED_DOCUMENTS.map(statusFor);
  const count = (s: UiStatus) => statuses.filter((x) => x === s).length;
  const approved = count('approved');
  const rejected = count('rejected');
  const pending = count('pending');
  const missing = count('missing');
  const total = REQUIRED_DOCUMENTS.length;

  let activeStep = 1;
  if (approved >= total) activeStep = 3;
  else if (missing === 0) activeStep = 2;

  const nextActionDoc =
    REQUIRED_DOCUMENTS.find((d) => statusFor(d) === 'rejected') ??
    REQUIRED_DOCUMENTS.find((d) => statusFor(d) === 'missing') ??
    null;

  return {
    requiredStats: { approved, rejected, pending, missing, uploaded: approved + pending + rejected, total },
    activeStep,
    nextActionDoc,
  };
}

function primaryLabelFor(activeStep: number, next: RequiredDocument | null, nextStatus: UiStatus): string {
  if (activeStep === 3) return 'Done';
  if (!next) return 'Refresh status';
  return nextStatus === 'rejected' ? `Re-upload ${next.name}` : `Upload ${next.name}`;
}

function heroColorFor(activeStep: number, attention: boolean, primary: string): string {
  if (attention) return RED;
  if (activeStep === 3) return GREEN;
  if (activeStep === 2) return AMBER;
  return primary;
}

/** Ask for permission, then open the camera or library. Returns the picked image URI, or null. */
async function pickImageUri(source: 'camera' | 'library'): Promise<string | null> {
  const camera = source === 'camera';
  const permission = camera
    ? await ImagePicker.requestCameraPermissionsAsync()
    : await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (permission.status !== 'granted') {
    toast.error(
      camera
        ? 'Please allow camera access to take a document photo.'
        : 'Please allow photo library access to choose a document.',
      'Permission needed'
    );
    return null;
  }
  const result = camera
    ? await ImagePicker.launchCameraAsync({ mediaTypes: IMAGE_MEDIA_TYPES, quality: 0.8, allowsEditing: false })
    : await ImagePicker.launchImageLibraryAsync({
        mediaTypes: IMAGE_MEDIA_TYPES,
        quality: 0.8,
        allowsEditing: false,
        selectionLimit: 1,
      });
  if (result.canceled) return null;
  return result.assets?.[0]?.uri ?? null;
}

function stageColors(done: boolean, current: boolean, attention: boolean, accent: string) {
  if (current) {
    const color = attention ? RED : accent;
    return { bar: color, label: color, dot: color };
  }
  if (done) return { bar: GREEN, label: 'rgba(248,250,252,0.8)', dot: GREEN };
  return { bar: 'rgba(248,250,252,0.12)', label: 'rgba(248,250,252,0.4)', dot: GREEN };
}

function StageStrip({
  activeStep,
  accent,
  attention,
}: Readonly<{ activeStep: number; accent: string; attention: boolean }>) {
  return (
    <View style={styles.stageStrip}>
      {STAGES.map((label, i) => {
        const n = i + 1;
        const done = n < activeStep || activeStep === STAGES.length;
        const current = n === activeStep && !done;
        const c = stageColors(done, current, attention, accent);
        return (
          <View key={label} style={styles.stageItem}>
            <View style={[styles.stageBar, { backgroundColor: c.bar }]} />
            <View style={styles.stageLabelRow}>
              {current ? <PulseDot color={c.dot} size={6} /> : null}
              {done ? <Ionicons name="checkmark" size={11} color={GREEN} /> : null}
              <Text style={[styles.stageLabel, { color: c.label }, current && styles.stageLabelActive]}>
                {label}
              </Text>
            </View>
          </View>
        );
      })}
    </View>
  );
}

function DocumentRow({
  doc,
  status,
  uploaded,
  busy,
  accent,
  textMain,
  index,
  onPress,
}: Readonly<{
  doc: RequiredDocument;
  status: UiStatus;
  uploaded?: UploadedDocument;
  busy: boolean;
  accent: string;
  textMain: string;
  index: number;
  onPress: () => void;
}>) {
  const meta = STATUS_META[status];
  const orbAccent = status === 'missing' ? accent : meta.color;

  return (
    <Reanimated.View entering={FadeInDown.delay(80 + index * 60).springify().damping(18)}>
      <PressableScale
        onPress={onPress}
        disabled={busy}
        scaleTo={0.98}
        style={[
          styles.docRow,
          status === 'rejected' && { borderColor: `${RED}66`, backgroundColor: 'rgba(248,113,113,0.08)' },
        ]}
        accessibilityLabel={`${doc.name}, ${meta.label}`}
      >
        <View style={styles.docLead}>
          {uploaded?.uri ? (
            <Image source={{ uri: uploaded.uri }} style={styles.docThumb} />
          ) : (
            <GlassOrb icon={doc.icon} accent={orbAccent} size={44} glow={false} />
          )}
          {uploaded?.uri ? (
            <View style={[styles.docBadge, { backgroundColor: meta.color }]}>
              <Ionicons name={STATUS_BADGE_ICON[status]} size={10} color="#0A1929" />
            </View>
          ) : null}
        </View>

        <View style={styles.docCopy}>
          <View style={styles.docTitleRow}>
            <Text style={[styles.docName, { color: textMain }]} numberOfLines={1}>
              {doc.name}
            </Text>
            {!doc.required ? (
              <View style={styles.optionalTag}>
                <Text style={styles.optionalTagText}>Optional</Text>
              </View>
            ) : null}
          </View>
          {status === 'missing' ? (
            <Text style={styles.docDesc} numberOfLines={1}>
              {doc.description}
            </Text>
          ) : (
            <View style={styles.docStatusRow}>
              <View style={[styles.statusDot, { backgroundColor: meta.color }]} />
              <Text style={[styles.docStatus, { color: meta.color }]} numberOfLines={1}>
                {status === 'rejected' && uploaded?.rejectionReason ? uploaded.rejectionReason : meta.label}
              </Text>
            </View>
          )}
        </View>

        <DocTrailing busy={busy} status={status} accent={accent} />
      </PressableScale>
    </Reanimated.View>
  );
}

function DocTrailing({ busy, status, accent }: Readonly<{ busy: boolean; status: UiStatus; accent: string }>) {
  if (busy) return <ActivityIndicator size="small" color={accent} />;
  if (status !== 'missing' && status !== 'rejected') {
    return <Ionicons name="chevron-forward" size={16} color="rgba(226,232,240,0.5)" />;
  }
  const fix = status === 'rejected';
  const color = fix ? RED : accent;
  return (
    <View style={[styles.actionPill, { backgroundColor: `${color}26`, borderColor: `${color}66` }]}>
      <Ionicons name={fix ? 'refresh' : 'cloud-upload-outline'} size={14} color={color} />
      <Text style={[styles.actionPillText, { color }]}>{fix ? 'Fix' : 'Upload'}</Text>
    </View>
  );
}

export default function ValeterDocuments() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const fit = useValeterFitInsets(10);
  const { theme } = useAccountTheme();
  const primary = theme.primary || '#9EC9E0';
  const gradientBg = (theme.background || ['#6A9BB0', '#2A4660']) as [string, string];
  const textMain = theme.textPrimary || '#F8FAFC';
  const textMuted = theme.textOnBackground || 'rgba(248,250,252,0.66)';

  const [documents, setDocuments] = useState<UploadedDocument[]>([]);
  const [uploading, setUploading] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [sourceDoc, setSourceDoc] = useState<RequiredDocument | null>(null);
  const [previewDoc, setPreviewDoc] = useState<RequiredDocument | null>(null);

  useEffect(() => {
    if (!user?.id) return;
    void loadDocuments();
    return valeterDocumentsSupabaseService.subscribeToUserDocuments(user.id, () => {
      void loadDocuments(true);
    });
  }, [user?.id]);

  const loadDocuments = async (soft = false) => {
    if (!user?.id) return;
    try {
      if (soft) setRefreshing(true);
      else setLoading(true);
      const userDocs = await valeterDocumentsSupabaseService.listUserDocuments(user.id);
      setDocuments(userDocs);
    } catch {
      toast.error('Failed to load documents');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const findDocumentForType = (docType: RequiredDocument) =>
    documents.find((d) => d.docTypeId === docType.id);

  const getUiStatus = (docType: RequiredDocument): UiStatus => uiStatusOf(findDocumentForType(docType));

  const { requiredStats, activeStep, nextActionDoc } = useMemo(() => summarizeDocuments(documents), [documents]);
  const attention = requiredStats.rejected > 0;

  const copy = heroCopyFor(activeStep, attention, requiredStats.rejected, requiredStats.missing);
  const heroColor = heroColorFor(activeStep, attention, primary);
  const ringProgress = Math.round(
    ((requiredStats.approved + requiredStats.pending * 0.5) / Math.max(requiredStats.total, 1)) * 100
  );

  const openUpload = async (docType: RequiredDocument) => {
    await hapticFeedback('light');
    setPreviewDoc(null);
    setSourceDoc(docType);
  };

  const onRowPress = (docType: RequiredDocument) => {
    const status = getUiStatus(docType);
    if (status === 'missing' || status === 'rejected') {
      void openUpload(docType);
      return;
    }
    void hapticFeedback('light');
    setPreviewDoc(docType);
  };

  const uploadDocument = async (docType: RequiredDocument, localUri: string) => {
    if (!user?.id) return;
    try {
      setUploading(docType.id);
      await valeterDocumentsSupabaseService.uploadPhotoDocument({
        userId: user.id,
        docTypeId: docType.id,
        docName: docType.name,
        description: docType.description,
        localUri,
      });
      await loadDocuments(true);
      await hapticFeedback('success');
      toast.success(`${docType.name} uploaded. We’ll review it shortly.`, 'Uploaded');
    } catch (error: any) {
      toast.error(error?.message || 'Unable to upload this document right now.', 'Upload failed');
    } finally {
      setUploading(null);
    }
  };

  const pick = async (source: 'camera' | 'library') => {
    const docType = sourceDoc;
    if (!docType) return;
    setSourceDoc(null);
    await wait(350);
    const uri = await pickImageUri(source);
    if (uri) await uploadDocument(docType, uri);
  };

  const primaryLabel = primaryLabelFor(
    activeStep,
    nextActionDoc,
    uiStatusOf(nextActionDoc ? findDocumentForType(nextActionDoc) : undefined)
  );

  const onPrimary = () => {
    if (activeStep === 3) {
      router.back();
      return;
    }
    if (nextActionDoc) {
      void openUpload(nextActionDoc);
      return;
    }
    void loadDocuments(true);
  };

  if (loading) {
    return <LoadingScreen message="Loading documents…" />;
  }

  const renderRows = (docs: RequiredDocument[], offset: number) =>
    docs.map((doc, i) => (
      <DocumentRow
        key={doc.id}
        doc={doc}
        status={getUiStatus(doc)}
        uploaded={findDocumentForType(doc)}
        busy={uploading === doc.id}
        accent={primary}
        textMain={textMain}
        index={offset + i}
        onPress={() => onRowPress(doc)}
      />
    ));

  return (
    <View style={styles.flex}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />
      <ValeterScreenHeader title="Documents" />

      <ScrollView
        style={styles.flex}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[styles.content, { paddingTop: fit.top, paddingBottom: 16 }]}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={() => loadDocuments(true)}
            tintColor={primary}
            colors={[primary]}
            progressBackgroundColor="rgba(15,30,48,0.9)"
          />
        }
      >
        <Reanimated.View entering={FadeInDown.springify().damping(18)}>
          <GlassSurface style={styles.hero} fallbackColor="rgba(10,25,41,0.6)">
            <LinearGradient
              colors={[`${heroColor}33`, 'transparent']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={StyleSheet.absoluteFill}
              pointerEvents="none"
            />
            <View style={styles.heroTop}>
              <ValeterTrackingProgressRing progress={ringProgress} accent={heroColor} size={68} pulse={activeStep === 2} />
              <View style={styles.heroCopy}>
                <View style={styles.kickerRow}>
                  <View style={[styles.kickerDot, { backgroundColor: heroColor }]} />
                  <Text style={[styles.kicker, { color: heroColor }]}>{copy.kicker}</Text>
                </View>
                <Text style={[styles.heroTitle, { color: textMain }]} numberOfLines={2}>
                  {copy.title}
                </Text>
                <Text style={[styles.heroBody, { color: textMuted }]} numberOfLines={3}>
                  {copy.body}
                </Text>
              </View>
            </View>
            <StageStrip activeStep={activeStep} accent={primary} attention={attention} />
            <View style={styles.heroStats}>
              {(
                [
                  { label: 'Approved', value: requiredStats.approved, color: GREEN },
                  { label: 'In review', value: requiredStats.pending, color: AMBER },
                  { label: 'To upload', value: requiredStats.missing + requiredStats.rejected, color: attention ? RED : primary },
                ] as const
              ).map((s) => (
                <View key={s.label} style={styles.heroStat}>
                  <Text style={[styles.heroStatValue, { color: s.value > 0 ? s.color : 'rgba(248,250,252,0.4)' }]}>
                    {s.value}
                  </Text>
                  <Text style={styles.heroStatLabel}>{s.label}</Text>
                </View>
              ))}
            </View>
          </GlassSurface>
        </Reanimated.View>

        <View style={styles.sectionHead}>
          <Text style={styles.sectionLabel}>REQUIRED</Text>
          <Text style={styles.sectionMeta}>
            {requiredStats.uploaded}/{requiredStats.total} uploaded
          </Text>
        </View>
        <View style={styles.list}>{renderRows(REQUIRED_DOCUMENTS, 0)}</View>

        <View style={styles.sectionHead}>
          <Text style={styles.sectionLabel}>OPTIONAL</Text>
          <Text style={styles.sectionMeta}>Helps you stand out</Text>
        </View>
        <View style={styles.list}>{renderRows(SUPPORTING_DOCUMENTS, REQUIRED_DOCUMENTS.length)}</View>

        <Reanimated.View entering={FadeIn.delay(420)} style={styles.trustRow}>
          <Ionicons name="lock-closed" size={13} color={GREEN} />
          <Text style={styles.trustText}>Stored securely and only seen by our verification team.</Text>
        </Reanimated.View>
      </ScrollView>

      <View style={[styles.footer, { paddingBottom: Math.max(12, insets.bottom) + VALETER_CONTENT_BOTTOM_PAD }]}>
        <ContinueCTAButton
          title={primaryLabel}
          onPress={onPrimary}
          accentColor={attention ? RED : primary}
          disabled={!!uploading || refreshing}
          loading={!!uploading}
          showTrailingChevron={!uploading}
        />
      </View>

      <UploadSourceSheet
        doc={sourceDoc}
        row={sourceDoc ? findDocumentForType(sourceDoc) : undefined}
        accent={primary}
        onPick={(s) => void pick(s)}
        onClose={() => setSourceDoc(null)}
      />
      <DocumentPreviewSheet
        doc={previewDoc}
        row={previewDoc ? findDocumentForType(previewDoc) : undefined}
        onClose={() => setPreviewDoc(null)}
      />
    </View>
  );
}

const SOURCES = [
  { key: 'camera', icon: 'camera', title: 'Take photo', sub: 'Use your camera' },
  { key: 'library', icon: 'images', title: 'Choose photo', sub: 'From your library' },
] as const;

function UploadSourceSheet({
  doc,
  row,
  accent,
  onPick,
  onClose,
}: Readonly<{
  doc: RequiredDocument | null;
  row: UploadedDocument | undefined;
  accent: string;
  onPick: (source: 'camera' | 'library') => void;
  onClose: () => void;
}>) {
  const reason = row?.verificationStatus === 'rejected' ? row.rejectionReason : null;
  return (
    <InfoBottomSheet
      visible={!!doc}
      onClose={onClose}
      title={doc ? `Upload ${doc.name}` : 'Upload'}
      accentColor={accent}
      sizeToContent
      contentMaxHeight="70%"
    >
      {doc ? <Text style={styles.sheetSub}>{doc.description}</Text> : null}
      {reason ? (
        <View style={[styles.reasonBox, styles.reasonBoxTop]}>
          <Ionicons name="alert-circle" size={16} color={RED} />
          <Text style={styles.reasonText}>{reason}</Text>
        </View>
      ) : null}
      <View style={styles.sourceRow}>
        {SOURCES.map((s) => (
          <PressableScale
            key={s.key}
            fill
            onPress={() => onPick(s.key)}
            style={[styles.sourceTile, { borderColor: `${accent}55` }]}
            accessibilityLabel={s.title}
          >
            <GlassOrb icon={s.icon} accent={accent} size={48} />
            <Text style={styles.sourceTitle}>{s.title}</Text>
            <Text style={styles.sourceSub}>{s.sub}</Text>
          </PressableScale>
        ))}
      </View>
      <Text style={styles.tipsLabel}>FOR A QUICK APPROVAL</Text>
      <View style={styles.tips}>
        {PHOTO_TIPS.map((tip) => (
          <View key={tip.text} style={styles.tipRow}>
            <Ionicons name={tip.icon} size={16} color={accent} />
            <Text style={styles.tipText}>{tip.text}</Text>
          </View>
        ))}
      </View>
    </InfoBottomSheet>
  );
}

function DocumentPreviewSheet({
  doc,
  row,
  onClose,
}: Readonly<{ doc: RequiredDocument | null; row: UploadedDocument | undefined; onClose: () => void }>) {
  const status = doc ? uiStatusOf(row) : 'missing';
  const meta = STATUS_META[status];
  const approved = status === 'approved';
  const date = formatUploadDate(approved ? row?.approvedAt ?? row?.uploadDate : row?.uploadDate);
  return (
    <InfoBottomSheet
      visible={!!doc}
      onClose={onClose}
      title={doc?.name ?? 'Document'}
      accentColor={meta.color}
      sizeToContent
      contentMaxHeight="82%"
    >
      {row?.uri ? <Image source={{ uri: row.uri }} style={styles.previewImage} resizeMode="cover" /> : null}
      <View style={styles.previewMetaRow}>
        <View style={[styles.previewPill, { backgroundColor: `${meta.color}22`, borderColor: `${meta.color}66` }]}>
          <View style={[styles.statusDot, { backgroundColor: meta.color }]} />
          <Text style={[styles.previewPillText, { color: meta.color }]}>{meta.label}</Text>
        </View>
        {date ? (
          <Text style={styles.previewDate}>
            {approved ? 'Approved' : 'Uploaded'} {date}
          </Text>
        ) : null}
      </View>
      <Text style={styles.previewNote}>
        {approved
          ? 'This document is verified. Nothing else to do here.'
          : 'Our team is reviewing this now. You’ll get a notification once it’s checked.'}
      </Text>
      {row?.rejectionReason ? (
        <View style={styles.reasonBox}>
          <Ionicons name="alert-circle" size={16} color={RED} />
          <Text style={styles.reasonText}>{row.rejectionReason}</Text>
        </View>
      ) : null}
    </InfoBottomSheet>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  content: { flexGrow: 1, paddingHorizontal: 18, gap: 10 },

  hero: { borderRadius: 24, paddingHorizontal: 16, paddingTop: 16, paddingBottom: 14, gap: 14, overflow: 'hidden' },
  heroTop: { flexDirection: 'row', alignItems: 'center', gap: 14 },
  heroCopy: { flex: 1, gap: 3 },
  kickerRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  kickerDot: { width: 6, height: 6, borderRadius: 3 },
  kicker: { fontSize: 11, fontWeight: '900', letterSpacing: 1.2 },
  heroTitle: { fontSize: 19, fontWeight: '900', letterSpacing: -0.3 },
  heroBody: { fontSize: 13, fontWeight: '600', lineHeight: 18 },

  stageStrip: { flexDirection: 'row', gap: 6 },
  stageItem: { flex: 1, gap: 6 },
  stageBar: { height: 4, borderRadius: 2 },
  stageLabelRow: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  stageLabel: { fontSize: 11, fontWeight: '700' },
  stageLabelActive: { fontWeight: '900' },

  heroStats: {
    flexDirection: 'row',
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(248,250,252,0.14)',
    paddingTop: 12,
  },
  heroStat: { flex: 1, alignItems: 'center', gap: 2 },
  heroStatValue: { fontSize: 20, fontWeight: '900', fontVariant: ['tabular-nums'] },
  heroStatLabel: { color: 'rgba(226,232,240,0.6)', fontSize: 11, fontWeight: '700' },

  sectionHead: {
    flexDirection: 'row',
    alignItems: 'baseline',
    justifyContent: 'space-between',
    marginTop: 6,
    paddingHorizontal: 4,
  },
  sectionLabel: { color: 'rgba(226,232,240,0.7)', fontSize: 11, fontWeight: '900', letterSpacing: 1.2 },
  sectionMeta: { color: 'rgba(226,232,240,0.5)', fontSize: 12, fontWeight: '700' },
  list: { gap: 8 },

  docRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 12,
    paddingVertical: 11,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    backgroundColor: 'rgba(10,25,41,0.42)',
  },
  docLead: { width: 44, height: 44 },
  docThumb: { width: 44, height: 44, borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.08)' },
  docBadge: {
    position: 'absolute',
    right: -4,
    bottom: -4,
    width: 18,
    height: 18,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#0B1E33',
  },
  docCopy: { flex: 1, minWidth: 0, gap: 3 },
  docTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  docName: { fontSize: 15, fontWeight: '800', flexShrink: 1 },
  docDesc: { color: 'rgba(226,232,240,0.6)', fontSize: 12, fontWeight: '600' },
  docStatusRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  docStatus: { fontSize: 12, fontWeight: '800' },
  statusDot: { width: 7, height: 7, borderRadius: 4 },
  optionalTag: {
    paddingHorizontal: 6,
    paddingVertical: 1,
    borderRadius: 6,
    backgroundColor: 'rgba(232,197,71,0.18)',
  },
  optionalTagText: { color: '#E8C547', fontSize: 9, fontWeight: '900', letterSpacing: 0.4, textTransform: 'uppercase' },
  actionPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 11,
    paddingVertical: 7,
    borderRadius: 999,
    borderWidth: 1,
  },
  actionPillText: { fontSize: 12, fontWeight: '900' },

  trustRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, marginTop: 8 },
  trustText: { color: 'rgba(226,232,240,0.55)', fontSize: 12, fontWeight: '600' },

  footer: { paddingHorizontal: 18, paddingTop: 8 },

  sheetSub: { color: 'rgba(226,232,240,0.7)', fontSize: 13, fontWeight: '600', marginBottom: 14 },
  sourceRow: { flexDirection: 'row', gap: 10 },
  sourceTile: {
    flex: 1,
    alignItems: 'center',
    gap: 6,
    paddingVertical: 18,
    borderRadius: 20,
    borderWidth: 1,
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  sourceTitle: { color: '#F8FAFC', fontSize: 15, fontWeight: '800', marginTop: 4 },
  sourceSub: { color: 'rgba(226,232,240,0.6)', fontSize: 12, fontWeight: '600' },
  tipsLabel: {
    color: 'rgba(226,232,240,0.6)',
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 1.2,
    marginTop: 18,
    marginBottom: 8,
  },
  tips: { gap: 9, paddingBottom: 6 },
  tipRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  tipText: { color: 'rgba(241,245,249,0.85)', fontSize: 13, fontWeight: '600' },

  previewImage: {
    width: '100%',
    aspectRatio: 4 / 3,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  previewMetaRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 14 },
  previewPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 999,
    borderWidth: 1,
  },
  previewPillText: { fontSize: 12, fontWeight: '900' },
  previewDate: { color: 'rgba(226,232,240,0.6)', fontSize: 12, fontWeight: '700' },
  previewNote: { color: 'rgba(226,232,240,0.75)', fontSize: 13, fontWeight: '600', lineHeight: 19, marginTop: 12 },
  reasonBox: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 12,
    padding: 12,
    borderRadius: 14,
    backgroundColor: 'rgba(248,113,113,0.12)',
  },
  reasonBoxTop: { marginTop: 0, marginBottom: 14 },
  reasonText: { flex: 1, color: '#FECACA', fontSize: 13, fontWeight: '600', lineHeight: 18 },
});
