
/**
 * Valeter services & pricing — wash tiers, detailing, and repairs (Supabase valeter_service_settings).
 */
import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Switch,
  Alert,
  Animated,
  Modal,
  Platform,
  Pressable,
  ActivityIndicator,
} from 'react-native';
import Reanimated, { FadeIn, FadeInDown } from 'react-native-reanimated';
import GlassSurface from '../../../src/components/shared/GlassSurface';
import InlineToast, { type ToastState } from '../../../src/components/shared/InlineToast';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import type { IconGlyphName } from '../../../src/components/shared/iconGlyphTypes';
import { useLocalSearchParams } from 'expo-router';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import LoadingScreen from '../../../src/components/LoadingScreen';
import { colors } from '../../../src/constants/colors';
import { lightMistElevated, VALETER_PRIMARY_HEX } from '../../../src/constants/accountThemes';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import ValeterScreenHeader from '../../../src/components/valeter/ValeterScreenHeader';
import ValeterPickerSheet from '../../../src/components/valeter/ValeterPickerSheet';
import { ValeterPriceWheelPicker, ValeterDurationWheelPicker } from '../../../src/components/valeter/ValeterWheelPicker';
import ServiceTile from '../../../src/components/valeter/ServiceTile';
import GlassOrb from '../../../src/components/valeter/road/GlassOrb';
import { PriceRow, PricingDoneButton, PricingHero } from '../../../src/components/valeter/PricingSheetParts';
import { PressableScale, PulseDot, SegmentedPills, useValeterFitInsets } from '../../../src/components/shared/fit/FitKit';
import { toast as appToast } from '../../../src/components/shared/ToastHost';
import { SERVICE_CATEGORY_ICON, WASH_SCOPE_ICON, getServiceIcon } from '../../../src/constants/serviceIcons';

const BG = colors.BG ?? '#0F2847';
const SKY = colors.SKY ?? VALETER_PRIMARY_HEX;

// -------- Tier & detailing defs (aligned with valeter_profile) --------
type TierKey = 'bronze' | 'silver' | 'gold' | 'platinum' | 'emerald';
type VehicleSizeKey = 'small' | 'medium' | 'large' | 'xl' | 'xxl';
/** Bronze is interior OR exterior — each scope has its own price. */
type BronzeWashScope = 'exterior' | 'interior';
const BRONZE_WASH_SCOPES: Array<{ key: BronzeWashScope; label: string; subtitle: string; icon: IconGlyphName }> = [
  { key: 'exterior', label: 'Exterior wash', subtitle: 'Outside only — hand wash, wheels, dry', icon: WASH_SCOPE_ICON.exterior },
  { key: 'interior', label: 'Interior clean', subtitle: 'Inside only — vacuum & wipe-downs', icon: WASH_SCOPE_ICON.interior },
];
const TIER_DEFS: Array<{
  key: TierKey;
  name: string;
  icon: IconGlyphName;
  color: string;
  tier: string;
}> = [
  { key: 'bronze', name: 'Bronze Wash', icon: getServiceIcon('bronze-wash'), color: '#CD7F32', tier: 'BRONZE' },
  { key: 'silver', name: 'Silver Wash', icon: getServiceIcon('silver-wash'), color: '#C0C0C0', tier: 'SILVER' },
  { key: 'gold', name: 'Gold Wash', icon: getServiceIcon('gold-wash'), color: '#FFD700', tier: 'GOLD' },
  { key: 'platinum', name: 'Platinum Wash', icon: getServiceIcon('platinum-wash'), color: '#E5E4E2', tier: 'PLATINUM' },
  { key: 'emerald', name: 'Diamond Wash', icon: getServiceIcon('emerald-wash'), color: '#22D3EE', tier: 'DIAMOND' },
];

const STANDARD_TIER_DESCRIPTIONS: Record<string, { description: string; includes: string[]; bestFor: string }> = {
  bronze: {
    description: 'A quick refresh for your vehicle. Choose either an exterior hand wash or a light interior clean including vacuuming and surface wipe-downs.',
    includes: ['Your choice: exterior hand wash OR light interior clean', 'Exterior option: safe wash, wheels, rinse, dry, exterior glass', 'Interior option: vacuum, surface wipe-downs, light cabin tidy', 'Fast and affordable'],
    bestFor: 'Maintenance between deeper valets.',
  },
  silver: {
    description: 'A balanced clean inside and out. Includes an exterior hand wash plus a light interior refresh with vacuuming, surface cleaning, and a tidy finish.',
    includes: ['Exterior hand wash, wheels and dry', 'Interior vacuum (seats, carpets, boot)', 'Dashboard, console and trims wiped', 'Interior and exterior glass cleaned', 'Tyre dressing and light spray wax where included'],
    bestFor: 'Regular maintenance and everyday cleanliness.',
  },
  gold: {
    description: 'A full interior deep clean designed to restore your vehicle from the inside out. Includes deep vacuuming, stain removal, upholstery and carpet treatment.',
    includes: ['Deep vacuum throughout cabin and boot', 'Stain treatment and upholstery / carpet care', 'Seats, carpets and mats shampooed or refreshed', 'All interior surfaces, trims and touchpoints detailed', 'Leather cleaned and dressed where applicable', 'Headliner and hard-to-reach areas addressed', 'Interior glass and finishes refreshed', 'Air freshener to finish'],
    bestFor: 'Vehicles needing a deep interior restoration.',
  },
  platinum: {
    description: 'A complete interior and exterior valet with enhanced attention to detail. Includes a thorough wash, detailed interior cleaning, and finishing touches.',
    includes: ['Thorough exterior wash, wheels and arches', 'Interior deep clean aligned with Gold cabin standard', 'Trims, glass and surfaces finished to a high standard', 'Enhanced attention to detail inside and out', 'Finishing touches for a clean, fresh presentation'],
    bestFor: 'Full vehicle refresh in one visit.',
  },
  emerald: {
    description: 'Our highest level service delivering a full vehicle transformation. Deep interior clean, detailed exterior wash, and premium finishing.',
    includes: ['Deep interior clean plus detailed exterior wash', 'Paint decontamination and enhancement where appropriate', 'Upholstery / leather care and interior sanitisation', 'Machine or hand finishing for gloss and clarity', 'Long-lasting protection or sealant where included', 'Fine detailing on edges, trims and glass', 'Premium finish aimed at near showroom presentation'],
    bestFor: 'Premium care and a near showroom finish.',
  },
};

type ServiceDescBlock = { description: string; includes: string[]; bestFor: string };
const ADDON_SERVICE_DESCRIPTIONS: Record<DetailingKey | RepairKey, ServiceDescBlock> = {
  'ceramic-coating': {
    description: 'A durable protective layer applied over clear coat to help repel water, dirt, and UV, and to keep gloss for longer between washes.',
    includes: ['Surface prep and decontamination where needed', 'Application of ceramic or SIO2-based coating per product instructions', 'Curing guidance for the customer', 'Typically quoted by vehicle size due to paint area'],
    bestFor: 'Owners who want easier washing and longer-lasting shine.',
  },
  'machine-polishing': {
    description: 'Machine correction to reduce swirl marks, light scratches, and oxidation, restoring clarity and gloss before protection or hand finishing.',
    includes: ['Paint assessment and safe wash', 'Single- or multi-stage machine work as agreed', 'Panel wipe and inspection', 'Optional sealant or wax if you include it in the package'],
    bestFor: 'Paint that looks dull or swirled but is otherwise sound.',
  },
  'soft-top-restoration': {
    description: 'Cleaning, conditioning, and protection for convertible fabric hoods to improve appearance and help resist water ingress and fading.',
    includes: ['Gentle clean of fabric and seams', 'Mould/mildew treatment if required (see also Mould Removal)', 'Waterproofer / UV protectant where appropriate', 'Trim and glass edges checked for drips'],
    bestFor: 'Convertibles with stained, faded, or poorly beading hoods.',
  },
  'mould-removal': {
    description: 'Targeted interior treatment to address mould and musty odours from moisture, spills, or poor ventilation—often combined with deep cleaning.',
    includes: ['Inspection of affected areas (seats, carpets, boot, HVAC paths)', 'HEPA vacuum and antimicrobial treatment as appropriate', 'Drying aids and odour neutraliser', 'Advice on preventing recurrence'],
    bestFor: 'Vehicles with visible mould, mildew smell, or water damage history.',
  },
  'headlight-restoration': {
    description: 'Restores clarity to yellowed or hazed polycarbonate lenses to improve night visibility and appearance, usually via wet sanding and UV seal.',
    includes: ['Masking adjacent paint and trim', 'Progressive refinement of lens surface', 'UV protective clear coat or seal', 'Final polish and beam check where possible'],
    bestFor: 'Cloudy headlights that fail MOT beam pattern or look aged.',
  },
  'scratch-removal': {
    description: 'Localised paint correction to reduce or remove clear-coat level marks; deeper scratches may need touch-up or bodyshop work.',
    includes: ['Depth check (clear coat vs base)', 'Compound and refine within safe limits', 'Panel wipe and gloss match', 'Honest call-out when touch-up or respray is safer'],
    bestFor: 'Parking scrapes, brush wash marks, and light clear-coat scratches.',
  },
  'paint-chip-repair': {
    description: 'Small touch-up of stone chips and chips to primer to limit rust and improve looks—colour matched where you stock or mix paint.',
    includes: ['Clean and feather edges', 'Primer / base / clear as needed per chip depth', 'Level and cure per product', 'Blend into surrounding panels where practical'],
    bestFor: 'Bonnet and front bumper stone chips and minor road rash.',
  },
  'trim-restoration': {
    description: 'Revives faded exterior plastic trim (bumpers, mirrors, cladding) with clean, dye, or dressings depending on condition.',
    includes: ['Deep clean of porous plastic', 'Grey/faded trim restored with dye or coating', 'Satin or gloss finish to customer preference', 'Avoid overspray on paint and glass'],
    bestFor: 'Sun-faded black plastic that looks grey or chalky.',
  },
  'leather-repair': {
    description: 'Repairs minor tears, scuffs, and wear on leather or leatherette—colour matching and flexible fillers for seats and bolsters.',
    includes: ['Clean and degrease the area', 'Sub-patch or filler for small holes', 'Grain texture and colour match', 'Conditioner to finish'],
    bestFor: 'Worn driver bolsters, scuffs, and small punctures not needing full retrim.',
  },
  'maintenance-check': {
    description: 'An all-in-one maintenance inspection covering coolant, oil level, tyre tread, lights, and washer fluid so customers get a clear health check for the vehicle.',
    includes: [
      'Coolant level inspection',
      'Oil level check',
      'Tyre tread and visible condition check',
      'Light bulbs / exterior lights inspection',
      'Screen wash / washer fluid check and top-up advice',
    ],
    bestFor: 'Customers wanting a quick vehicle health check while the car is in for service.',
  },
};

const VEHICLE_SIZE_DEFS: Array<{ key: VehicleSizeKey; label: string; subtitle: string; icon: IconGlyphName }> = [
  { key: 'small', label: 'Small car', subtitle: 'Fiat 500, Corsa', icon: 'car-outline' },
  { key: 'medium', label: 'Medium SUV', subtitle: 'Qashqai, Sportage', icon: 'car-sport-outline' },
  { key: 'large', label: 'Large car', subtitle: 'Passat, 3 Series', icon: 'bus-outline' },
  { key: 'xl', label: 'XL van', subtitle: 'Transit, Vivaro, Sprinter', icon: 'subway-outline' },
  { key: 'xxl', label: 'XXL (HGV)', subtitle: 'Truck, rigid, artic', icon: 'train-outline' },
];

/** Soft min/max £ for standard wash tiers by vehicle size (wide bands; clamps the wheel only). */
type PriceBound = { min: number; max: number };
const STANDARD_TIER_PRICE_BOUNDS: Record<TierKey, Record<VehicleSizeKey, PriceBound>> = {
  bronze: {
    small: { min: 15, max: 45 },
    medium: { min: 17, max: 50 },
    large: { min: 20, max: 55 },
    xl: { min: 22, max: 62 },
    xxl: { min: 60, max: 180 },
  },
  silver: {
    small: { min: 25, max: 70 },
    medium: { min: 28, max: 78 },
    large: { min: 32, max: 85 },
    xl: { min: 36, max: 92 },
    xxl: { min: 90, max: 250 },
  },
  gold: {
    small: { min: 45, max: 120 },
    medium: { min: 52, max: 135 },
    large: { min: 58, max: 150 },
    xl: { min: 64, max: 165 },
    xxl: { min: 150, max: 400 },
  },
  platinum: {
    small: { min: 70, max: 180 },
    medium: { min: 78, max: 198 },
    large: { min: 85, max: 215 },
    xl: { min: 92, max: 232 },
    xxl: { min: 200, max: 550 },
  },
  emerald: {
    small: { min: 100, max: 250 },
    medium: { min: 112, max: 288 },
    large: { min: 125, max: 325 },
    xl: { min: 138, max: 362 },
    xxl: { min: 280, max: 750 },
  },
};

function getStandardPriceBound(tier: TierKey, size: VehicleSizeKey): PriceBound {
  return STANDARD_TIER_PRICE_BOUNDS[tier][size];
}

function clampStandardPrice(tier: TierKey, size: VehicleSizeKey, value: number): number {
  const { min, max } = getStandardPriceBound(tier, size);
  if (!Number.isFinite(value)) return min;
  return Number(Math.min(max, Math.max(min, value)).toFixed(2));
}

function formatBoundHint(bound: PriceBound): string {
  return `Range £${bound.min}–£${bound.max}`;
}

type DetailingKey = 'ceramic-coating' | 'machine-polishing' | 'soft-top-restoration' | 'mould-removal';
type RepairKey = 'headlight-restoration' | 'scratch-removal' | 'paint-chip-repair' | 'trim-restoration' | 'leather-repair' | 'maintenance-check';
type AddonKey = DetailingKey | RepairKey;

/** Soft min/max £ for detailing & repair add-ons by vehicle size (clamps the wheel). */
const ADDON_PRICE_BOUNDS: Record<AddonKey, Record<VehicleSizeKey, PriceBound>> = {
  'ceramic-coating': {
    small: { min: 180, max: 550 },
    medium: { min: 200, max: 620 },
    large: { min: 220, max: 700 },
    xl: { min: 250, max: 800 },
    xxl: { min: 500, max: 2000 },
  },
  'machine-polishing': {
    small: { min: 150, max: 480 },
    medium: { min: 170, max: 540 },
    large: { min: 190, max: 600 },
    xl: { min: 210, max: 680 },
    xxl: { min: 400, max: 1500 },
  },
  'soft-top-restoration': {
    small: { min: 80, max: 260 },
    medium: { min: 90, max: 290 },
    large: { min: 100, max: 320 },
    xl: { min: 110, max: 360 },
    xxl: { min: 180, max: 600 },
  },
  'mould-removal': {
    small: { min: 50, max: 180 },
    medium: { min: 55, max: 200 },
    large: { min: 60, max: 220 },
    xl: { min: 70, max: 250 },
    xxl: { min: 120, max: 450 },
  },
  'headlight-restoration': {
    small: { min: 20, max: 80 },
    medium: { min: 22, max: 90 },
    large: { min: 25, max: 100 },
    xl: { min: 28, max: 110 },
    xxl: { min: 50, max: 200 },
  },
  'scratch-removal': {
    small: { min: 30, max: 120 },
    medium: { min: 35, max: 135 },
    large: { min: 40, max: 150 },
    xl: { min: 45, max: 170 },
    xxl: { min: 80, max: 350 },
  },
  'paint-chip-repair': {
    small: { min: 20, max: 90 },
    medium: { min: 22, max: 100 },
    large: { min: 25, max: 110 },
    xl: { min: 28, max: 125 },
    xxl: { min: 50, max: 250 },
  },
  'trim-restoration': {
    small: { min: 18, max: 80 },
    medium: { min: 20, max: 90 },
    large: { min: 22, max: 100 },
    xl: { min: 25, max: 115 },
    xxl: { min: 45, max: 220 },
  },
  'leather-repair': {
    small: { min: 25, max: 110 },
    medium: { min: 28, max: 125 },
    large: { min: 32, max: 140 },
    xl: { min: 36, max: 160 },
    xxl: { min: 60, max: 280 },
  },
  'maintenance-check': {
    small: { min: 10, max: 45 },
    medium: { min: 12, max: 50 },
    large: { min: 14, max: 55 },
    xl: { min: 15, max: 60 },
    xxl: { min: 35, max: 120 },
  },
};

function getAddonPriceBound(key: AddonKey, size: VehicleSizeKey): PriceBound {
  return ADDON_PRICE_BOUNDS[key][size];
}

function clampAddonPrice(key: AddonKey, size: VehicleSizeKey, value: number): number {
  const { min, max } = getAddonPriceBound(key, size);
  if (!Number.isFinite(value)) return min;
  return Number(Math.min(max, Math.max(min, value)).toFixed(2));
}

type DetailingItem = {
  key: DetailingKey | RepairKey;
  name: string;
  enabled: boolean;
  price: number | null;
  prices?: Record<VehicleSizeKey, number | null>;
};

const DETAILING_DEFS: Array<{ key: DetailingKey; name: string; icon: IconGlyphName }> = [
  { key: 'ceramic-coating', name: 'Ceramic Coating', icon: getServiceIcon('ceramic-coating') },
  { key: 'machine-polishing', name: 'Machine Polishing', icon: getServiceIcon('machine-polishing') },
  { key: 'soft-top-restoration', name: 'Soft Top Restoration', icon: getServiceIcon('soft-top-restoration') },
  { key: 'mould-removal', name: 'Mould Removal', icon: getServiceIcon('mould-removal') },
];

const REPAIR_DEFS: Array<{ key: RepairKey; name: string; icon: IconGlyphName }> = [
  { key: 'headlight-restoration', name: 'Headlight Restoration', icon: getServiceIcon('headlight-restoration') },
  { key: 'scratch-removal', name: 'Scratch Removal', icon: getServiceIcon('scratch-removal') },
  { key: 'paint-chip-repair', name: 'Paint Chip Repair', icon: getServiceIcon('paint-chip-repair') },
  { key: 'trim-restoration', name: 'Trim Restoration', icon: getServiceIcon('trim-restoration') },
  { key: 'leather-repair', name: 'Leather Repair', icon: getServiceIcon('leather-repair') },
  { key: 'maintenance-check', name: 'Maintenance Check', icon: getServiceIcon('maintenance-check') },
];

const money = (n: any) => (Number.isFinite(Number(n)) ? Number(n).toFixed(2) : '0.00');

function formatPriceRange(prices: Record<VehicleSizeKey, number | null> | undefined): string {
  const vals = Object.values(prices ?? {}).filter((v): v is number => v != null && Number.isFinite(v));
  if (vals.length === 0) return 'Set pricing';
  const min = Math.min(...vals);
  const max = Math.max(...vals);
  if (min === max) return `£${money(min)}`;
  return `£${money(min)}–£${money(max)}`;
}

function minPriceFromRecord(prices: Record<VehicleSizeKey, number | null> | undefined): number | null {
  const vals = Object.values(prices ?? {}).filter((v): v is number => v != null && Number.isFinite(v));
  return vals.length > 0 ? Math.min(...vals) : null;
}

function formatPickerPrice(v: number | null | undefined): string {
  if (v == null || !Number.isFinite(v)) return 'Set price';
  return `£${v.toFixed(2)}`;
}

function formatPickerMinutes(m: number | null | undefined): string {
  if (m == null || !Number.isFinite(m)) return 'Set duration';
  return `${m} min`;
}

type PricePickerTarget =
  | { scope: 'tier'; tier: TierKey; size: VehicleSizeKey; label: string; washScope?: BronzeWashScope }
  | { scope: 'addon'; key: DetailingKey | RepairKey; size: VehicleSizeKey; label: string };

const buildDefaultDetailingItems = (): DetailingItem[] =>
  DETAILING_DEFS.map((d) => ({ key: d.key, name: d.name, enabled: false, price: null, prices: defaultTierSizePricing() }));

const buildDefaultRepairItems = (): DetailingItem[] =>
  REPAIR_DEFS.map((d) => ({ key: d.key, name: d.name, enabled: false, price: null, prices: defaultTierSizePricing() }));

const getDetailingPrices = (item: DetailingItem): Record<VehicleSizeKey, number | null> => {
  if (item.prices && Object.keys(item.prices).length > 0) return item.prices;
  const p = item.price != null && Number.isFinite(item.price) ? item.price : null;
  return { small: p, medium: p, large: p, xl: p, xxl: p };
};

const coerceDetailingMenu = (raw: any): DetailingItem[] => {
  const defaults = buildDefaultDetailingItems();
  const map = new Map<string, DetailingItem>();
  defaults.forEach((d) => map.set(d.key, { ...d }));
  const items = raw?.items;
  if (Array.isArray(items)) {
    for (const it of items) {
      const keyRaw = String(it?.key || '');
      const key = (keyRaw === 'ceramic' ? 'ceramic-coating' : keyRaw);
      if (!map.has(key)) continue;
      const legacy = it?.price != null && Number.isFinite(Number(it?.price)) ? Number(it?.price) : null;
      const nextPrices = defaultTierSizePricing();
      VEHICLE_SIZE_DEFS.forEach(({ key: sizeKey }) => {
        const v = it?.prices?.[sizeKey];
        nextPrices[sizeKey] = v != null && Number.isFinite(Number(v)) ? Number(v) : legacy;
      });
      map.set(key, {
        key: key as DetailingKey,
        name: String(it?.name || map.get(key)!.name),
        enabled: !!it?.enabled,
        price: legacy,
        prices: nextPrices,
      });
    }
  }
  return Array.from(map.values());
};

const coerceRepairMenu = (raw: any): DetailingItem[] => {
  const defaults = buildDefaultRepairItems();
  const map = new Map<string, DetailingItem>();
  defaults.forEach((d) => map.set(d.key, { ...d }));
  const items = raw?.items;
  if (Array.isArray(items)) {
    for (const it of items) {
      const key = String(it?.key || '');
      if (!map.has(key)) continue;
      const legacy = it?.price != null && Number.isFinite(Number(it?.price)) ? Number(it?.price) : null;
      const nextPrices = defaultTierSizePricing();
      VEHICLE_SIZE_DEFS.forEach(({ key: sizeKey }) => {
        const v = it?.prices?.[sizeKey];
        nextPrices[sizeKey] = v != null && Number.isFinite(Number(v)) ? Number(v) : legacy;
      });
      map.set(key, {
        key: key as RepairKey,
        name: String(it?.name || map.get(key)!.name),
        enabled: !!it?.enabled,
        price: legacy,
        prices: nextPrices,
      });
    }
  }
  return Array.from(map.values());
};

type TierPricingRow = {
  /** Flat size prices — used for silver+; for bronze kept in sync with exterior for legacy readers. */
  prices: Record<VehicleSizeKey, number | null>;
  /** Bronze exterior-only prices by vehicle size. */
  pricesExterior?: Record<VehicleSizeKey, number | null>;
  /** Bronze interior-only prices by vehicle size. */
  pricesInterior?: Record<VehicleSizeKey, number | null>;
  minutes: number | null;
  enabled?: boolean;
};
type TierPricing = Record<TierKey, TierPricingRow>;
const defaultTierSizePricing = (): Record<VehicleSizeKey, number | null> =>
  ({ small: null, medium: null, large: null, xl: null, xxl: null });
const ALL_TIER_KEYS: TierKey[] = ['bronze', 'silver', 'gold', 'platinum', 'emerald'];
const defaultTierPricing = (): TierPricing =>
  ALL_TIER_KEYS.reduce(
    (acc, k) => ({
      ...acc,
      [k]:
        k === 'bronze'
          ? {
              prices: defaultTierSizePricing(),
              pricesExterior: defaultTierSizePricing(),
              pricesInterior: defaultTierSizePricing(),
              minutes: null,
              enabled: true,
            }
          : { prices: defaultTierSizePricing(), minutes: null, enabled: true },
    }),
    {} as TierPricing
  );

function coerceSizePriceMap(raw: any, legacy: number | null): Record<VehicleSizeKey, number | null> {
  const next = defaultTierSizePricing();
  VEHICLE_SIZE_DEFS.forEach(({ key }) => {
    const v = raw?.[key];
    next[key] = v != null && Number.isFinite(Number(v)) ? Number(v) : legacy;
  });
  return next;
}

const coerceTierPricing = (raw: any): TierPricing => {
  const base = defaultTierPricing();
  const obj = raw && typeof raw === 'object' ? raw : {};
  ALL_TIER_KEYS.forEach((k) => {
    const row = obj?.[k] || {};
    const legacy = row?.price != null && Number.isFinite(Number(row.price)) ? Number(row.price) : null;
    const flatPrices = coerceSizePriceMap(row?.prices, legacy);
    if (k === 'bronze') {
      const exterior = coerceSizePriceMap(row?.pricesExterior ?? row?.prices_exterior, null);
      const interior = coerceSizePriceMap(row?.pricesInterior ?? row?.prices_interior, null);
      // Migrate legacy single price map into both scopes when split prices are missing.
      VEHICLE_SIZE_DEFS.forEach(({ key }) => {
        if (exterior[key] == null && flatPrices[key] != null) exterior[key] = flatPrices[key];
        if (interior[key] == null && flatPrices[key] != null) interior[key] = flatPrices[key];
      });
      base[k] = {
        prices: exterior,
        pricesExterior: exterior,
        pricesInterior: interior,
        minutes: row?.minutes != null && Number.isFinite(Number(row.minutes)) ? Math.round(Number(row.minutes)) : null,
        enabled: row?.enabled !== false,
      };
      return;
    }
    base[k] = {
      prices: flatPrices,
      minutes: row?.minutes != null && Number.isFinite(Number(row.minutes)) ? Math.round(Number(row.minutes)) : null,
      enabled: row?.enabled !== false,
    };
  });
  return base;
};

function getTierPricesForScope(
  row: TierPricingRow | null | undefined,
  washScope?: BronzeWashScope | null
): Record<VehicleSizeKey, number | null> {
  if (!row) return defaultTierSizePricing();
  if (washScope === 'exterior') return row.pricesExterior ?? row.prices ?? defaultTierSizePricing();
  if (washScope === 'interior') return row.pricesInterior ?? row.prices ?? defaultTierSizePricing();
  return row.prices ?? defaultTierSizePricing();
}

function formatTierPriceRange(key: TierKey, row: TierPricingRow | null | undefined): string {
  if (!row) return 'Set pricing';
  if (key === 'bronze') {
    const vals = [
      ...Object.values(row.pricesExterior ?? {}),
      ...Object.values(row.pricesInterior ?? {}),
    ].filter((v): v is number => v != null && Number.isFinite(v));
    if (vals.length === 0) return 'Set pricing';
    const min = Math.min(...vals);
    const max = Math.max(...vals);
    if (min === max) return `£${money(min)}`;
    return `£${money(min)}–£${money(max)}`;
  }
  return formatPriceRange(row.prices);
}

const isMissingTableErr = (err: any) => {
  const msg = String(err?.message || '').toLowerCase();
  return msg.includes('does not exist') || msg.includes('relation') || msg.includes('schema cache');
};

const isFilledNumber = (value: number | null | undefined) =>
  value != null && Number.isFinite(value) && Number(value) >= 0;

const getMissingTierFields = (key: TierKey, row: TierPricing[TierKey]) => {
  const label = TIER_DEFS.find((t) => t.key === key)?.name ?? key;
  const missing: string[] = [];
  if (key === 'bronze') {
    BRONZE_WASH_SCOPES.forEach(({ key: scope, label: scopeLabel }) => {
      const prices = getTierPricesForScope(row, scope);
      VEHICLE_SIZE_DEFS.forEach(({ key: sizeKey, label: sizeLabel }) => {
        if (!isFilledNumber(prices[sizeKey])) missing.push(`${label} · ${scopeLabel} - ${sizeLabel}`);
      });
    });
  } else {
    VEHICLE_SIZE_DEFS.forEach(({ key: sizeKey, label: sizeLabel }) => {
      if (!isFilledNumber(row.prices[sizeKey])) missing.push(`${label} - ${sizeLabel} price`);
    });
  }
  if (!isFilledNumber(row.minutes)) missing.push(`${label} - duration`);
  return missing;
};

const getMissingAddonFields = (item: DetailingItem, label: string) => {
  const missing: string[] = [];
  const prices = getDetailingPrices(item);
  VEHICLE_SIZE_DEFS.forEach(({ key: sizeKey, label: sizeLabel }) => {
    if (!isFilledNumber(prices[sizeKey])) missing.push(`${label} - ${sizeLabel} price`);
  });
  return missing;
};

type RevenueContribution = {
  id: string;
  kind: 'tier' | 'addon';
  key: TierKey | DetailingKey | RepairKey;
  name: string;
  accent: string;
  minPrice: number;
  monthly: number;
};

const WEEKS_PER_MONTH = 52 / 12;
const DEFAULT_JOBS_PER_WEEK = 3;
/** Valeter take-home share of booking price (platform keeps 18%). */
const VALETER_NET_RATE = 0.82;

function computeServicesDashboardStats(
  tierPricing: TierPricing,
  detailingItems: DetailingItem[],
  repairItems: DetailingItem[],
  jobsPerWeek: number
) {
  const jobsMonth = Math.max(0, jobsPerWeek) * WEEKS_PER_MONTH;
  const contributions: RevenueContribution[] = [];

  TIER_DEFS.forEach((t) => {
    const row = tierPricing[t.key];
    if (row?.enabled === false) return;
    const minP =
      t.key === 'bronze'
        ? (() => {
            const vals = [
              ...Object.values(row?.pricesExterior ?? {}),
              ...Object.values(row?.pricesInterior ?? {}),
            ].filter((v): v is number => v != null && Number.isFinite(v));
            return vals.length > 0 ? Math.min(...vals) : null;
          })()
        : minPriceFromRecord(row?.prices);
    if (minP == null) return;
    contributions.push({
      id: `tier-${t.key}`,
      kind: 'tier',
      key: t.key,
      name: stripWashSuffix(t.name),
      accent: t.color,
      minPrice: minP,
      monthly: minP * jobsMonth * VALETER_NET_RATE,
    });
  });

  DETAILING_DEFS.forEach((d) => {
    const item = detailingItems.find((x) => x.key === d.key);
    if (!item?.enabled) return;
    const minP = minPriceFromRecord(getDetailingPrices(item));
    if (minP == null) return;
    contributions.push({
      id: `addon-${d.key}`,
      kind: 'addon',
      key: d.key,
      name: d.name,
      accent: '#F59E0B',
      minPrice: minP,
      monthly: minP * jobsMonth * VALETER_NET_RATE,
    });
  });

  REPAIR_DEFS.forEach((d) => {
    const item = repairItems.find((x) => x.key === d.key);
    if (!item?.enabled) return;
    const minP = minPriceFromRecord(getDetailingPrices(item));
    if (minP == null) return;
    contributions.push({
      id: `addon-${d.key}`,
      kind: 'addon',
      key: d.key,
      name: d.name,
      accent: '#38BDF8',
      minPrice: minP,
      monthly: minP * jobsMonth * VALETER_NET_RATE,
    });
  });

  const activeWashCount = TIER_DEFS.filter((t) => tierPricing[t.key]?.enabled !== false).length;
  const activeDetailCount = detailingItems.filter((i) => i.enabled).length;
  const activeRepairCount = repairItems.filter((i) => i.enabled).length;
  const activeCount = activeWashCount + activeDetailCount + activeRepairCount;
  const priced = contributions.map((c) => c.minPrice);
  const avgBooking = priced.length > 0 ? priced.reduce((a, b) => a + b, 0) / priced.length : 0;
  const monthlyPotential = contributions.reduce((sum, c) => sum + c.monthly, 0);

  return {
    activeWashCount,
    activeDetailCount,
    activeRepairCount,
    activeCount,
    avgBooking,
    monthlyPotential,
    contributions,
    jobsPerWeek,
  };
}

function stripWashSuffix(name: string): string {
  if (!name.toLowerCase().endsWith('wash')) return name;
  const head = name.slice(0, -4);
  const trimmed = head.trimEnd();
  return trimmed.length < head.length ? trimmed : name;
}

type ServicePricingTab = 'standard' | 'detailing' | 'repairs';

function tabFromParam(raw: string | string[] | undefined): ServicePricingTab | null {
  const v = Array.isArray(raw) ? raw[0] : raw;
  if (v === 'standard' || v === 'detailing' || v === 'repairs') return v;
  return null;
}

type ServiceDescTarget =
  | { kind: 'tier'; key: TierKey }
  | { kind: 'addon'; key: DetailingKey | RepairKey };

function serviceDescTitle(target: ServiceDescTarget): string {
  if (target.kind === 'tier') {
    return TIER_DEFS.find((t) => t.key === target.key)?.name ?? 'Service';
  }
  return (
    DETAILING_DEFS.find((d) => d.key === target.key)?.name ??
    REPAIR_DEFS.find((r) => r.key === target.key)?.name ??
    'Service'
  );
}

function serviceDescBlock(target: ServiceDescTarget): ServiceDescBlock | null {
  if (target.kind === 'tier') {
    return STANDARD_TIER_DESCRIPTIONS[target.key] ?? null;
  }
  return ADDON_SERVICE_DESCRIPTIONS[target.key] ?? null;
}

const DETAILING_INFO_ACCENT = '#F59E0B';
const REPAIR_INFO_ACCENT = '#38BDF8';

type ServicesSnapshot = {
  detailingOffered: boolean;
  repairsOffered: boolean;
  detailingItems: DetailingItem[];
  repairItems: DetailingItem[];
  tierPricing: TierPricing;
};

function countItemDiffs(prev: DetailingItem[] | undefined, next: DetailingItem[]): number {
  return next.filter((it) => JSON.stringify(prev?.find((x) => x.key === it.key)) !== JSON.stringify(it)).length;
}

function countSnapshotChanges(baselineSnapshot: string, next: ServicesSnapshot): number {
  try {
    const base = JSON.parse(baselineSnapshot);
    let n = 0;
    if (base.detailingOffered !== next.detailingOffered) n++;
    if (base.repairsOffered !== next.repairsOffered) n++;
    n += TIER_DEFS.filter(
      (t) => JSON.stringify(base.tierPricing?.[t.key]) !== JSON.stringify(next.tierPricing[t.key])
    ).length;
    n += countItemDiffs(base.detailingItems, next.detailingItems);
    n += countItemDiffs(base.repairItems, next.repairItems);
    return Math.max(1, n);
  } catch {
    return 1;
  }
}

function tabAccentFor(tab: ServicePricingTab, primary: string): string {
  if (tab === 'detailing') return DETAILING_INFO_ACCENT;
  if (tab === 'repairs') return REPAIR_INFO_ACCENT;
  return primary;
}

function catBarText(
  tab: ServicePricingTab,
  stats: ReturnType<typeof computeServicesDashboardStats>,
  detailingOffered: boolean,
  repairsOffered: boolean
): string {
  if (tab === 'standard') return `${stats.activeWashCount} of ${TIER_DEFS.length} on · tap a tile to price`;
  if (tab === 'detailing') {
    return detailingOffered
      ? `${stats.activeDetailCount} of ${DETAILING_DEFS.length} on · hold for details`
      : 'Turn on to offer detailing';
  }
  return repairsOffered
    ? `${stats.activeRepairCount} of ${REPAIR_DEFS.length} on · hold for details`
    : 'Turn on to offer repairs';
}

function pickerDraft(current: number | null | undefined, clamp: (v: number) => number, fallback: number): number {
  return current != null && Number.isFinite(current) ? clamp(current) : fallback;
}

function infoStatusLabel(locked: boolean, enabled: boolean): string {
  if (locked) return 'Category off';
  return enabled ? 'On your menu' : 'Hidden';
}

function bronzeScopeMissingCount(tierPricing: TierPricing, scope: BronzeWashScope): number | undefined {
  const prices = getTierPricesForScope(tierPricing.bronze, scope);
  const missing = VEHICLE_SIZE_DEFS.filter((z) => !isFilledNumber(prices?.[z.key])).length;
  return missing || undefined;
}

function tierSheetSectionLabel(tierKey: TierKey | null, bronzeScope: BronzeWashScope): string {
  if (tierKey !== 'bronze') return 'PRICE BY VEHICLE SIZE';
  return (BRONZE_WASH_SCOPES.find((s) => s.key === bronzeScope)?.subtitle ?? '').toUpperCase();
}

function tierRowValue(
  tierPricing: TierPricing,
  tierKey: TierKey,
  bronzeScope: BronzeWashScope,
  size: VehicleSizeKey
): number | null | undefined {
  if (tierKey === 'bronze') return getTierPricesForScope(tierPricing.bronze, bronzeScope)?.[size];
  return tierPricing[tierKey]?.prices?.[size];
}

type TileModel = {
  key: string;
  name: string;
  priceLabel: string;
  enabled: boolean;
  accent: string;
  icon: IconGlyphName;
  switchValue: boolean;
  locked: boolean;
  onPress: () => void;
  onToggle: () => void;
  onInfo: () => void;
};

function buildTierTiles(
  tierPricing: TierPricing,
  deps: {
    onEdit: (key: TierKey) => void;
    setEnabled: (key: TierKey, enabled: boolean) => void;
    onInfo: (target: ServiceDescTarget) => void;
  }
): TileModel[] {
  return TIER_DEFS.map((t) => {
    const row = tierPricing[t.key];
    const enabled = row?.enabled !== false;
    return {
      key: t.key,
      name: t.name,
      priceLabel: formatTierPriceRange(t.key, row),
      enabled,
      accent: t.color,
      icon: t.icon,
      switchValue: enabled,
      locked: false,
      onPress: () => {
        void hapticFeedback('light');
        deps.onEdit(t.key);
      },
      onToggle: () => {
        void hapticFeedback('light');
        deps.setEnabled(t.key, !enabled);
      },
      onInfo: () => {
        void hapticFeedback('light');
        deps.onInfo({ kind: 'tier', key: t.key });
      },
    };
  });
}

function buildAddonTiles(
  defs: Array<{ key: DetailingKey | RepairKey; name: string; icon: IconGlyphName }>,
  items: DetailingItem[],
  deps: {
    offered: boolean;
    accent: string;
    offLabel: string;
    toggle: (key: any, enabled: boolean) => void;
    onEdit: (key: DetailingKey | RepairKey) => void;
    onInfo: (target: ServiceDescTarget) => void;
  }
): TileModel[] {
  const { offered, accent, offLabel } = deps;
  return defs.map((def) => {
    const item =
      items.find((x) => x.key === def.key) ??
      ({ key: def.key, name: def.name, enabled: false, price: null, prices: defaultTierSizePricing() } as DetailingItem);
    return {
      key: def.key,
      name: def.name,
      priceLabel: formatPriceRange(getDetailingPrices(item)),
      enabled: item.enabled && offered,
      accent,
      icon: def.icon,
      switchValue: item.enabled,
      locked: !offered,
      onPress: () => {
        if (!offered) {
          appToast.info(`Turn on "Offer" above to edit ${offLabel} pricing.`, `Enable ${offLabel}`);
          return;
        }
        void hapticFeedback('light');
        deps.onEdit(def.key);
      },
      onToggle: () => {
        void hapticFeedback('light');
        deps.toggle(def.key, !item.enabled);
      },
      onInfo: () => {
        void hapticFeedback('light');
        deps.onInfo({ kind: 'addon', key: def.key });
      },
    };
  });
}

function gridTileHeight(gridH: number, gap: number, rows: number): number {
  return gridH > 0 ? Math.floor((gridH - gap * (rows - 1)) / rows) : 0;
}

function tierSheetInfo(selected: TierKey | null, tierPricing: TierPricing, primary: string) {
  const def = selected ? TIER_DEFS.find((t) => t.key === selected) : undefined;
  const scopes = selected === 'bronze' ? BRONZE_WASH_SCOPES.length : 1;
  return {
    def,
    accent: def?.color ?? primary,
    total: scopes * VEHICLE_SIZE_DEFS.length + 1,
    missing: selected ? getMissingTierFields(selected, tierPricing[selected]).length : 0,
  };
}

function addonSheetInfo(
  selected: DetailingKey | RepairKey | null,
  detailingItems: DetailingItem[],
  repairItems: DetailingItem[]
) {
  if (!selected) {
    return { def: undefined, accent: DETAILING_INFO_ACCENT, item: null, missing: 0 };
  }
  const def = DETAILING_DEFS.find((d) => d.key === selected) ?? REPAIR_DEFS.find((d) => d.key === selected);
  const isRepair = REPAIR_DEFS.some((d) => d.key === selected);
  const item = detailingItems.find((x) => x.key === selected) ?? repairItems.find((x) => x.key === selected) ?? null;
  return {
    def,
    accent: isRepair ? REPAIR_INFO_ACCENT : DETAILING_INFO_ACCENT,
    item,
    missing: item ? getMissingAddonFields(item, def?.name ?? '').length : 0,
  };
}

function serviceInfoFor(target: ServiceDescTarget | null, tiles: TileModel[]) {
  if (!target) return { tile: null, desc: null };
  return { tile: tiles.find((t) => t.key === target.key) ?? null, desc: serviceDescBlock(target) };
}

async function fetchServiceSettings(userId: string) {
  const { data, error } = await supabase
    .from('valeter_service_settings')
    .select('*')
    .eq('valeter_id', userId)
    .maybeSingle();
  if (!error) return data;
  if (isMissingTableErr(error)) {
    Alert.alert('DB setup needed', "The table 'valeter_service_settings' doesn't exist yet.");
  }
  return null;
}

function withTierPrice(
  prev: TierPricing,
  key: TierKey,
  size: VehicleSizeKey,
  clamped: number,
  washScope?: BronzeWashScope
): TierPricing {
  const row = prev[key];
  if (key === 'bronze' && washScope) {
    const exterior = { ...(row.pricesExterior ?? defaultTierSizePricing()) };
    const interior = { ...(row.pricesInterior ?? defaultTierSizePricing()) };
    if (washScope === 'exterior') exterior[size] = clamped;
    else interior[size] = clamped;
    return {
      ...prev,
      [key]: {
        ...row,
        pricesExterior: exterior,
        pricesInterior: interior,
        // Keep legacy `prices` aligned with exterior for older consumers.
        prices: exterior,
      },
    };
  }
  return {
    ...prev,
    [key]: { ...row, prices: { ...row.prices, [size]: clamped } },
  };
}

function buildTilesForTab(
  tab: ServicePricingTab,
  deps: {
    tierPricing: TierPricing;
    detailingItems: DetailingItem[];
    repairItems: DetailingItem[];
    detailingOffered: boolean;
    repairsOffered: boolean;
    toggleDetailingItem: (key: DetailingKey, enabled: boolean) => void;
    toggleRepairItem: (key: RepairKey, enabled: boolean) => void;
    setTierEnabled: (key: TierKey, enabled: boolean) => void;
    onEditTier: (key: TierKey) => void;
    onEditAddon: (key: DetailingKey | RepairKey) => void;
    onInfo: (target: ServiceDescTarget) => void;
  }
): TileModel[] {
  if (tab === 'standard') {
    return buildTierTiles(deps.tierPricing, {
      onEdit: deps.onEditTier,
      setEnabled: deps.setTierEnabled,
      onInfo: deps.onInfo,
    });
  }
  if (tab === 'detailing') {
    return buildAddonTiles(DETAILING_DEFS, deps.detailingItems, {
      offered: deps.detailingOffered,
      accent: DETAILING_INFO_ACCENT,
      offLabel: 'detailing',
      toggle: deps.toggleDetailingItem,
      onEdit: deps.onEditAddon,
      onInfo: deps.onInfo,
    });
  }
  return buildAddonTiles(REPAIR_DEFS, deps.repairItems, {
    offered: deps.repairsOffered,
    accent: REPAIR_INFO_ACCENT,
    offLabel: 'repairs',
    toggle: deps.toggleRepairItem,
    onEdit: deps.onEditAddon,
    onInfo: deps.onInfo,
  });
}

type DashboardStats = ReturnType<typeof computeServicesDashboardStats>;

function tabSegments(stats: DashboardStats, detailingOffered: boolean, repairsOffered: boolean) {
  return [
    { key: 'standard', label: 'Washes', icon: SERVICE_CATEGORY_ICON.wash, count: stats.activeWashCount },
    {
      key: 'detailing',
      label: 'Detailing',
      icon: SERVICE_CATEGORY_ICON.detailing,
      count: detailingOffered ? stats.activeDetailCount : 0,
    },
    {
      key: 'repairs',
      label: 'Repairs',
      icon: SERVICE_CATEGORY_ICON.repair,
      count: repairsOffered ? stats.activeRepairCount : 0,
    },
  ];
}

function EarningsCard({
  primary,
  isLight,
  muted,
  textMain,
  revenueColor,
  displayRevenue,
  jobsPerWeek,
  stats,
  onStep,
  onOpenContribution,
}: Readonly<{
  primary: string;
  isLight: boolean;
  muted: string;
  textMain: string;
  revenueColor: Animated.AnimatedInterpolation<string | number>;
  displayRevenue: number;
  jobsPerWeek: number;
  stats: DashboardStats;
  onStep: (delta: number) => void;
  onOpenContribution: (c: RevenueContribution) => void;
}>) {
  const hasContributions = stats.contributions.length > 0;
  return (
    <Reanimated.View entering={FadeInDown.springify().damping(18)}>
      <GlassSurface
        style={styles.earnCard}
        tintColor={`${primary}22`}
        borderColor={`${primary}40`}
        fallbackColor={isLight ? lightMistElevated : 'rgba(10,25,41,0.6)'}
      >
        <LinearGradient
          colors={[`${primary}2E`, 'transparent']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
        />
        <View style={styles.earnTop}>
          <View style={styles.earnCopy}>
            <Text style={[styles.earnLabel, { color: muted }]}>EST. MONTHLY TAKE-HOME</Text>
            <Animated.Text style={[styles.earnValue, { color: revenueColor }]} numberOfLines={1} adjustsFontSizeToFit>
              £{money(displayRevenue)}
            </Animated.Text>
          </View>
          <View style={styles.stepper}>
            <PressableScale
              onPress={() => onStep(-1)}
              disabled={jobsPerWeek <= 1}
              style={styles.stepBtn}
              accessibilityLabel="Fewer jobs per week"
            >
              <Ionicons name="remove" size={16} color={textMain} />
            </PressableScale>
            <View style={styles.stepValueWrap}>
              <Text style={[styles.stepValue, { color: primary }]}>{jobsPerWeek}</Text>
              <Text style={[styles.stepUnit, { color: muted }]}>jobs/wk</Text>
            </View>
            <PressableScale
              onPress={() => onStep(1)}
              disabled={jobsPerWeek >= 20}
              style={styles.stepBtn}
              accessibilityLabel="More jobs per week"
            >
              <Ionicons name="add" size={16} color={textMain} />
            </PressableScale>
          </View>
        </View>

        {hasContributions ? (
          <View style={styles.mixBar}>
            {stats.contributions.map((c) => (
              <Pressable
                key={c.id}
                onPress={() => onOpenContribution(c)}
                style={[styles.mixSeg, { flex: Math.max(c.monthly, 1), backgroundColor: c.accent }]}
                accessibilityLabel={`${c.name}, £${Math.round(c.monthly)} a month`}
                hitSlop={{ top: 10, bottom: 10 }}
              />
            ))}
          </View>
        ) : (
          <View style={[styles.mixBar, styles.mixEmpty]} />
        )}
        <Text style={[styles.earnMeta, { color: muted }]} numberOfLines={1}>
          {hasContributions
            ? `${stats.activeCount} active · avg £${money(stats.avgBooking)} booking · tap bar to edit`
            : 'Turn on a service and set prices to see revenue build'}
        </Text>
      </GlassSurface>
    </Reanimated.View>
  );
}

function SaveBar({
  saving,
  hasUnsaved,
  changeCount,
  primary,
  glassBorder,
  muted,
  onSave,
}: Readonly<{
  saving: boolean;
  hasUnsaved: boolean;
  changeCount: number;
  primary: string;
  glassBorder: string;
  muted: string;
  onSave: () => void;
}>) {
  return (
    <PressableScale
      onPress={hasUnsaved ? onSave : undefined}
      disabled={saving}
      haptic={hasUnsaved}
      accessibilityLabel={hasUnsaved ? 'Save changes' : 'All changes saved'}
    >
      <GlassSurface
        style={styles.saveBar}
        tintColor={hasUnsaved ? `${primary}66` : undefined}
        borderColor={hasUnsaved ? primary : glassBorder}
        fallbackColor={hasUnsaved ? `${primary}55` : 'rgba(255,255,255,0.05)'}
        interactive={hasUnsaved}
      >
        <SaveBarContent saving={saving} hasUnsaved={hasUnsaved} changeCount={changeCount} muted={muted} />
      </GlassSurface>
    </PressableScale>
  );
}

function PricingSheetBackdrop({
  headerGradient,
  accent,
}: Readonly<{ headerGradient: [string, string]; accent: string }>) {
  return (
    <>
      <BlurView
        intensity={Platform.OS === 'ios' ? 70 : 85}
        tint="dark"
        style={StyleSheet.absoluteFill}
        {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
      />
      <LinearGradient colors={headerGradient} style={StyleSheet.absoluteFill} pointerEvents="none" />
      <LinearGradient
        colors={[`${accent}30`, 'transparent']}
        start={{ x: 0.5, y: 0 }}
        end={{ x: 0.5, y: 0.45 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
    </>
  );
}

function pickerBound(target: PricePickerTarget): { min: number; max: number } {
  return target.scope === 'tier'
    ? getStandardPriceBound(target.tier, target.size)
    : getAddonPriceBound(target.key, target.size);
}

function PricePickerOverlay({
  scope,
  target,
  draft,
  onDraftChange,
  onClose,
  onDone,
  accent,
  muted,
}: Readonly<{
  scope: PricePickerTarget['scope'];
  target: PricePickerTarget | null;
  draft: number;
  onDraftChange: (v: number) => void;
  onClose: () => void;
  onDone: () => void;
  accent: string;
  muted: string;
}>) {
  const active = target?.scope === scope ? target : null;
  const bound = active ? pickerBound(active) : null;
  return (
    <ValeterPickerSheet
      presentation="overlay"
      visible={!!active}
      title={target ? `Price · ${target.label}` : 'Set price'}
      onClose={onClose}
      onDone={onDone}
      accent={accent}
    >
      {bound ? (
        <>
          <ValeterPriceWheelPicker
            value={draft}
            onChange={onDraftChange}
            accent={accent}
            minValue={bound.min}
            maxValue={bound.max}
          />
          <Text style={[styles.priceBoundHint, { color: muted }]}>{formatBoundHint(bound)}</Text>
        </>
      ) : null}
    </ValeterPickerSheet>
  );
}

function SaveBarContent({
  saving,
  hasUnsaved,
  changeCount,
  muted,
}: Readonly<{
  saving: boolean;
  hasUnsaved: boolean;
  changeCount: number;
  muted: string;
}>) {
  if (saving) return <ActivityIndicator size="small" color="#F9FAFB" />;
  if (hasUnsaved) {
    return (
      <Reanimated.View key="unsaved" entering={FadeIn.duration(180)} style={styles.saveRow}>
        <PulseDot color="#F9FAFB" size={7} />
        <Text style={styles.saveText}>
          Save {changeCount} change{changeCount === 1 ? '' : 's'}
        </Text>
      </Reanimated.View>
    );
  }
  return (
    <Reanimated.View key="saved" entering={FadeIn.duration(180)} style={styles.saveRow}>
      <Ionicons name="checkmark-circle" size={16} color="#4ADE80" />
      <Text style={[styles.saveText, { color: muted }]}>All changes saved</Text>
    </Reanimated.View>
  );
}

function ServiceInfoMeta({ tile, accent }: Readonly<{ tile: TileModel; accent: string }>) {
  return (
    <View style={styles.infoMetaRow}>
      <Text
        style={[styles.infoPrice, { color: tile.priceLabel === 'Set pricing' ? '#FBBF24' : accent }]}
        numberOfLines={1}
      >
        {tile.priceLabel}
      </Text>
      <View
        style={[
          styles.infoStatus,
          { backgroundColor: tile.enabled ? 'rgba(74,222,128,0.16)' : 'rgba(148,163,184,0.16)' },
        ]}
      >
        <View style={[styles.infoStatusDot, { backgroundColor: tile.enabled ? '#4ADE80' : '#94A3B8' }]} />
        <Text style={[styles.infoStatusText, { color: tile.enabled ? '#86EFAC' : '#CBD5E1' }]}>
          {infoStatusLabel(tile.locked, tile.enabled)}
        </Text>
      </View>
    </View>
  );
}

function ServiceInfoBody({
  desc,
  accent,
  muted,
  textMain,
}: Readonly<{
  desc: ServiceDescBlock | null;
  accent: string;
  muted: string;
  textMain: string;
}>) {
  if (!desc) {
    return <Text style={[styles.infoDesc, { color: muted }]}>No description for this service yet.</Text>;
  }
  return (
    <>
      <Reanimated.Text entering={FadeIn.duration(220)} style={[styles.infoDesc, { color: muted }]}>
        {desc.description}
      </Reanimated.Text>

      <Text style={[styles.infoSection, { color: muted }]}>WHAT'S INCLUDED</Text>
      <View style={styles.infoList}>
        {desc.includes.map((item, i) => (
          <Reanimated.View
            key={item}
            entering={FadeInDown.delay(60 + i * 45).springify().damping(18)}
            style={styles.infoItem}
          >
            <View style={[styles.infoCheck, { backgroundColor: `${accent}26` }]}>
              <Ionicons name="checkmark" size={13} color={accent} />
            </View>
            <Text style={[styles.infoItemText, { color: textMain }]}>{item}</Text>
          </Reanimated.View>
        ))}
      </View>

      <Reanimated.View
        entering={FadeInDown.delay(80 + desc.includes.length * 45).springify().damping(18)}
        style={[styles.infoBestFor, { borderColor: `${accent}44`, backgroundColor: `${accent}14` }]}
      >
        <Ionicons name="sparkles" size={16} color={accent} />
        <View style={styles.infoBestForCopy}>
          <Text style={[styles.infoSection, styles.infoSectionTight, { color: accent }]}>BEST FOR</Text>
          <Text style={[styles.infoItemText, { color: textMain }]}>{desc.bestFor}</Text>
        </View>
      </Reanimated.View>
    </>
  );
}

export default function ValeterServices() {
  const { user } = useAuth();
  const { tab: tabParam } = useLocalSearchParams<{ tab?: string | string[] }>();
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const pageGradient: [string, string] = [theme.background[0], theme.background[1]];
  const headerGradient: [string, string] = [
    theme.headerBackground?.[0] ?? pageGradient[0],
    theme.headerBackground?.[1] ?? pageGradient[1],
  ];
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [detailingOffered, setDetailingOffered] = useState(false);
  const [repairsOffered, setRepairsOffered] = useState(false);
  const [detailingItems, setDetailingItems] = useState<DetailingItem[]>(buildDefaultDetailingItems());
  const [repairItems, setRepairItems] = useState<DetailingItem[]>(buildDefaultRepairItems());
  const [tierPricing, setTierPricing] = useState<TierPricing>(defaultTierPricing());
  const [tab, setTab] = useState<ServicePricingTab>(() => tabFromParam(tabParam) ?? 'standard');
  const [gridH, setGridH] = useState(0);
  const [gridW, setGridW] = useState(0);
  const fit = useValeterFitInsets(10);
  const [selectedTierForPricing, setSelectedTierForPricing] = useState<TierKey | null>(null);
  const [bronzeScope, setBronzeScope] = useState<BronzeWashScope>('exterior');
  const [serviceDescTarget, setServiceDescTarget] = useState<ServiceDescTarget | null>(null);
  const [selectedDetailingForPricing, setSelectedDetailingForPricing] = useState<DetailingKey | RepairKey | null>(null);
  const [pricePickerTarget, setPricePickerTarget] = useState<PricePickerTarget | null>(null);
  const [pricePickerDraft, setPricePickerDraft] = useState(0);
  const [minutePickerTier, setMinutePickerTier] = useState<TierKey | null>(null);
  const [minutePickerDraft, setMinutePickerDraft] = useState(60);
  const [jobsPerWeek, setJobsPerWeek] = useState(DEFAULT_JOBS_PER_WEEK);
  const [displayRevenue, setDisplayRevenue] = useState(0);
  const revenueAnim = useRef(new Animated.Value(0)).current;
  const revenueFlash = useRef(new Animated.Value(0)).current;
  const prevRevenueRef = useRef(0);
  const revenueReadyRef = useRef(false);
  const [toast, setToast] = useState<ToastState>(null);
  const hideToast = useCallback(() => setToast(null), []);
  const [baselineSnapshot, setBaselineSnapshot] = useState<string | null>(null);

  const currentSnapshot = useMemo(
    () => JSON.stringify({ detailingOffered, repairsOffered, detailingItems, repairItems, tierPricing }),
    [detailingOffered, repairsOffered, detailingItems, repairItems, tierPricing]
  );
  const hasUnsaved = baselineSnapshot !== null && baselineSnapshot !== currentSnapshot;

  useEffect(() => {
    if (!loading && baselineSnapshot === null) setBaselineSnapshot(currentSnapshot);
  }, [loading, baselineSnapshot, currentSnapshot]);

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 400, useNativeDriver: true }).start();
  }, []);

  useEffect(() => {
    if (user?.id) void loadSettings();
  }, [user?.id]);

  useEffect(() => {
    const next = tabFromParam(tabParam);
    if (next) setTab(next);
  }, [tabParam]);

  const dashboardStats = useMemo(
    () => computeServicesDashboardStats(tierPricing, detailingItems, repairItems, jobsPerWeek),
    [tierPricing, detailingItems, repairItems, jobsPerWeek]
  );

  useEffect(() => {
    const target = dashboardStats.monthlyPotential;

    if (!revenueReadyRef.current) {
      revenueReadyRef.current = true;
      prevRevenueRef.current = target;
      revenueAnim.setValue(target);
      setDisplayRevenue(target);
      return;
    }

    const prev = prevRevenueRef.current;
    const rising = target >= prev;
    prevRevenueRef.current = target;

    revenueFlash.setValue(rising ? 1 : -1);
    Animated.timing(revenueFlash, {
      toValue: 0,
      duration: 700,
      useNativeDriver: false,
    }).start();

    const id = revenueAnim.addListener(({ value }) => setDisplayRevenue(value));
    Animated.spring(revenueAnim, {
      toValue: target,
      useNativeDriver: false,
      friction: 10,
      tension: 48,
    }).start();

    return () => {
      revenueAnim.removeListener(id);
    };
  }, [dashboardStats.monthlyPotential, revenueAnim, revenueFlash]);

  const openContribution = (c: RevenueContribution) => {
    void hapticFeedback('light');
    if (c.kind === 'tier') {
      setSelectedTierForPricing(c.key as TierKey);
      return;
    }
    setSelectedDetailingForPricing(c.key as DetailingKey | RepairKey);
  };

  const loadSettings = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      const data = await fetchServiceSettings(user.id);
      if (data) {
        setDetailingOffered(data.detailing_offered === true);
        setRepairsOffered(data.repairs_offered === true);
        setDetailingItems(coerceDetailingMenu(data.detailing_menu));
        setRepairItems(coerceRepairMenu(data.repair_menu));
        setTierPricing(coerceTierPricing(data.tier_pricing));
      }
    } catch (e) {
      console.warn('[ValeterServices] load error', e);
    } finally {
      setLoading(false);
    }
  };

  const saveSettings = async () => {
    if (!user?.id) return;
    try {
      setSaving(true);
      const { error } = await supabase.from('valeter_service_settings').upsert(
        {
          valeter_id: user.id,
          detailing_offered: detailingOffered,
          repairs_offered: repairsOffered,
          detailing_menu: { items: detailingItems },
          repair_menu: { items: repairItems },
          tier_pricing: tierPricing,
        },
        { onConflict: 'valeter_id' }
      );
      if (error && isMissingTableErr(error)) {
        Alert.alert('DB setup needed', "Create 'valeter_service_settings' first.");
        return;
      }
      if (error) throw error;
      setBaselineSnapshot(currentSnapshot);
      void hapticFeedback('success');
      setToast({ kind: 'success', message: 'Services & pricing updated' });
    } catch (e: any) {
      void hapticFeedback('error');
      setToast({ kind: 'error', message: e?.message || 'Failed to save' });
    } finally {
      setSaving(false);
    }
  };

  const saveTierSheet = () => {
    if (!selectedTierForPricing) return;
    const row = tierPricing[selectedTierForPricing];
    const label = TIER_DEFS.find((t) => t.key === selectedTierForPricing)?.name ?? selectedTierForPricing;
    const missing = getMissingTierFields(selectedTierForPricing, row);
    if (missing.length > 0) {
      Alert.alert('Complete this block', `${label} needs every size price and the duration filled in before saving.`);
      return;
    }
    setSelectedTierForPricing(null);
  };

  const saveAddonSheet = () => {
    if (!selectedDetailingForPricing) return;
    const item =
      detailingItems.find((x) => x.key === selectedDetailingForPricing) ??
      repairItems.find((x) => x.key === selectedDetailingForPricing) ??
      null;
    if (!item) return;
    const label =
      DETAILING_DEFS.find((d) => d.key === selectedDetailingForPricing)?.name ??
      REPAIR_DEFS.find((r) => r.key === selectedDetailingForPricing)?.name ??
      'Service';
    const missing = getMissingAddonFields(item, label);
    if (missing.length > 0) {
      Alert.alert('Complete this block', `${label} needs every size price filled in before saving.`);
      return;
    }
    setSelectedDetailingForPricing(null);
  };

  const setTierPriceValue = (key: TierKey, size: VehicleSizeKey, v: number, washScope?: BronzeWashScope) => {
    const clamped = clampStandardPrice(key, size, v);
    setTierPricing((prev) => withTierPrice(prev, key, size, clamped, washScope));
  };
  const setTierMinutesValue = (key: TierKey, minutes: number) => {
    setTierPricing((prev) => ({ ...prev, [key]: { ...prev[key], minutes } }));
  };
  const openTierPricePicker = (
    tier: TierKey,
    size: VehicleSizeKey,
    label: string,
    washScope?: BronzeWashScope
  ) => {
    const bound = getStandardPriceBound(tier, size);
    const current = getTierPricesForScope(tierPricing[tier], washScope)?.[size];
    setPricePickerDraft(pickerDraft(current, (v) => clampStandardPrice(tier, size, v), bound.min));
    setPricePickerTarget({ scope: 'tier', tier, size, label, washScope });
    void hapticFeedback('light');
  };
  const openAddonPricePicker = (key: DetailingKey | RepairKey, size: VehicleSizeKey, label: string) => {
    const bound = getAddonPriceBound(key, size);
    const item = detailingItems.find((x) => x.key === key) ?? repairItems.find((x) => x.key === key);
    const current = item ? getDetailingPrices(item)[size] : null;
    setPricePickerDraft(pickerDraft(current, (v) => clampAddonPrice(key, size, v), bound.min));
    setPricePickerTarget({ scope: 'addon', key, size, label });
    void hapticFeedback('light');
  };
  const commitPricePicker = () => {
    if (!pricePickerTarget) return;
    if (pricePickerTarget.scope === 'tier') {
      const v = clampStandardPrice(pricePickerTarget.tier, pricePickerTarget.size, pricePickerDraft);
      setTierPriceValue(pricePickerTarget.tier, pricePickerTarget.size, v, pricePickerTarget.washScope);
    } else {
      const v = clampAddonPrice(pricePickerTarget.key, pricePickerTarget.size, pricePickerDraft);
      setDetailingPriceValue(pricePickerTarget.key, pricePickerTarget.size, v);
    }
    setPricePickerTarget(null);
    void hapticFeedback('light');
  };
  const openMinutePicker = (tier: TierKey) => {
    setMinutePickerDraft(pickerDraft(tierPricing[tier]?.minutes, (v) => v, 60));
    setMinutePickerTier(tier);
    void hapticFeedback('light');
  };
  const commitMinutePicker = () => {
    if (!minutePickerTier) return;
    setTierMinutesValue(minutePickerTier, minutePickerDraft);
    setMinutePickerTier(null);
    void hapticFeedback('light');
  };
  const setTierEnabled = (key: TierKey, enabled: boolean) => {
    setTierPricing((prev) => ({ ...prev, [key]: { ...prev[key], enabled } }));
  };
  const toggleDetailingItem = (key: DetailingKey, enabled: boolean) => {
    setDetailingItems((prev) => prev.map((it) => (it.key === key ? { ...it, enabled } : it)));
  };
  const toggleRepairItem = (key: RepairKey, enabled: boolean) => {
    setRepairItems((prev) => prev.map((it) => (it.key === key ? { ...it, enabled } : it)));
  };
  const setDetailingPriceValue = (key: DetailingKey | RepairKey, size: VehicleSizeKey, v: number) => {
    const clamped = clampAddonPrice(key, size, v);
    const isRepair = REPAIR_DEFS.some((d) => d.key === key);
    const setter = isRepair ? setRepairItems : setDetailingItems;
    setter((prev) =>
      prev.map((it) =>
        it.key === key ? { ...it, prices: { ...getDetailingPrices(it), [size]: clamped } } : it
      )
    );
  };
  const primary = theme.primary || SKY;
  const glassBorder = theme.glassBorder;
  const muted = theme.textSecondary ?? 'rgba(249,250,251,0.65)';
  const textMain = theme.textPrimary ?? '#F9FAFB';
  const isLight = theme.mode === 'light';
  const revenueColor = revenueFlash.interpolate({
    inputRange: [-1, 0, 1],
    outputRange: ['#F87171', primary, '#4ADE80'],
  });

  const stepJobs = (delta: number) => {
    void hapticFeedback('light');
    setJobsPerWeek((v) => Math.max(1, Math.min(20, v + delta)));
  };

  const changeCount = useMemo(() => {
    if (!baselineSnapshot || !hasUnsaved) return 0;
    return countSnapshotChanges(baselineSnapshot, {
      detailingOffered,
      repairsOffered,
      detailingItems,
      repairItems,
      tierPricing,
    });
  }, [baselineSnapshot, hasUnsaved, detailingOffered, repairsOffered, tierPricing, detailingItems, repairItems]);

  const GRID_ROWS = 3;
  const GRID_GAP = 10;
  const tileH = gridTileHeight(gridH, GRID_GAP, GRID_ROWS);
  const tabAccent = tabAccentFor(tab, primary);

  const {
    def: tierSheetDef,
    accent: tierSheetAccent,
    total: tierSheetTotal,
    missing: tierSheetMissing,
  } = tierSheetInfo(selectedTierForPricing, tierPricing, primary);
  const {
    def: addonSheetDef,
    accent: addonSheetAccent,
    item: addonSheetItem,
    missing: addonSheetMissing,
  } = addonSheetInfo(selectedDetailingForPricing, detailingItems, repairItems);

  const tiles = buildTilesForTab(tab, {
    tierPricing,
    detailingItems,
    repairItems,
    detailingOffered,
    repairsOffered,
    toggleDetailingItem,
    toggleRepairItem,
    setTierEnabled,
    onEditTier: setSelectedTierForPricing,
    onEditAddon: setSelectedDetailingForPricing,
    onInfo: setServiceDescTarget,
  });

  const { tile: infoTile, desc: infoDesc } = serviceInfoFor(serviceDescTarget, tiles);
  const infoAccent = infoTile?.accent ?? primary;

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={pageGradient} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="valeter" />
        <ValeterScreenHeader title="Service Studio" />
        <LoadingScreen message="Loading…" />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={pageGradient} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <ValeterScreenHeader title="Service Studio" />

      <Animated.View
        style={[styles.fitBody, { paddingTop: fit.top, paddingBottom: fit.bottom, opacity: fadeAnim }]}
      >
        <EarningsCard
          primary={primary}
          isLight={isLight}
          muted={muted}
          textMain={textMain}
          revenueColor={revenueColor}
          displayRevenue={displayRevenue}
          jobsPerWeek={jobsPerWeek}
          stats={dashboardStats}
          onStep={stepJobs}
          onOpenContribution={openContribution}
        />

        <SegmentedPills
          segments={tabSegments(dashboardStats, detailingOffered, repairsOffered)}
          value={tab}
          onChange={(k) => setTab(k as ServicePricingTab)}
          accent={primary}
          height={38}
        />

        <View style={styles.catBar}>
          <Text style={[styles.catText, { color: muted }]} numberOfLines={1}>
            {catBarText(tab, dashboardStats, detailingOffered, repairsOffered)}
          </Text>
          {tab !== 'standard' ? (
            <View style={styles.catSwitch}>
              <Text style={[styles.catSwitchLabel, { color: textMain }]}>Offer</Text>
              <Switch
                value={tab === 'detailing' ? detailingOffered : repairsOffered}
                onValueChange={() => {
                  void hapticFeedback('light');
                  if (tab === 'detailing') setDetailingOffered((v) => !v);
                  else setRepairsOffered((v) => !v);
                }}
                style={styles.catSwitchControl}
                trackColor={{ false: 'rgba(255,255,255,0.12)', true: tabAccent }}
                thumbColor="#fff"
              />
            </View>
          ) : null}
        </View>

        <View
          style={styles.grid}
          onLayout={(e) => {
            const h = Math.round(e.nativeEvent.layout.height);
            const w = Math.round(e.nativeEvent.layout.width);
            setGridH((prev) => (Math.abs(prev - h) < 2 ? prev : h));
            setGridW((prev) => (Math.abs(prev - w) < 2 ? prev : w));
          }}
        >
          {gridH > 0 && gridW > 0
            ? tiles.map((t, i) => (
                <Reanimated.View
                  key={`${tab}-${t.key}`}
                  entering={FadeInDown.delay(i * 40).springify().damping(18)}
                  style={{ width: Math.floor((gridW - GRID_GAP) / 2), height: tileH }}
                >
                  <ServiceTile
                    name={t.name}
                    priceLabel={t.priceLabel}
                    enabled={t.enabled}
                    accent={t.accent}
                    icon={t.icon}
                    switchValue={t.switchValue}
                    switchDisabled={t.locked}
                    locked={t.locked}
                    height={tileH}
                    onPress={t.onPress}
                    onToggle={t.onToggle}
                    onInfo={t.onInfo}
                  />
                </Reanimated.View>
              ))
            : null}
        </View>

        <SaveBar
          saving={saving}
          hasUnsaved={hasUnsaved}
          changeCount={changeCount}
          primary={primary}
          glassBorder={glassBorder}
          muted={muted}
          onSave={saveSettings}
        />
      </Animated.View>

      {/* Tier pricing bottom sheet */}
      <Modal
        visible={!!selectedTierForPricing}
        transparent
        animationType="slide"
        statusBarTranslucent
        onRequestClose={() => {
          setPricePickerTarget(null);
          setMinutePickerTier(null);
          setSelectedTierForPricing(null);
        }}
      >
        <View style={styles.sheetContainer}>
          <Pressable
            style={StyleSheet.absoluteFill}
            onPress={() => {
              if (pricePickerTarget || minutePickerTier) {
                setPricePickerTarget(null);
                setMinutePickerTier(null);
                return;
              }
              setSelectedTierForPricing(null);
            }}
          >
            <View style={[StyleSheet.absoluteFill, styles.sheetBackdrop]} />
          </Pressable>
            <View
            style={[
              styles.bottomSheet,
              styles.bottomSheetHeaderStyle,
              {
                paddingBottom: Math.max(insets.bottom, 20),
                borderColor: `${primary}40`,
                backgroundColor: headerGradient[1],
              },
            ]}
            pointerEvents="box-none"
          >
            <PricingSheetBackdrop headerGradient={headerGradient} accent={tierSheetAccent} />
            <View style={styles.sheetHandle} />
            <PricingHero
              title={tierSheetDef?.name ?? ''}
              icon={tierSheetDef?.icon ?? 'pricetag'}
              accent={tierSheetAccent}
              done={tierSheetTotal - tierSheetMissing}
              total={tierSheetTotal}
              textMain={textMain}
              muted={muted}
              onClose={() => {
                setPricePickerTarget(null);
                setMinutePickerTier(null);
                setSelectedTierForPricing(null);
              }}
            />
            {selectedTierForPricing === 'bronze' ? (
              <SegmentedPills
                segments={BRONZE_WASH_SCOPES.map((s) => ({
                  key: s.key,
                  label: s.key === 'exterior' ? 'Exterior' : 'Interior',
                  icon: s.icon,
                  count: bronzeScopeMissingCount(tierPricing, s.key),
                }))}
                value={bronzeScope}
                onChange={(k) => setBronzeScope(k as BronzeWashScope)}
                accent={tierSheetAccent}
                height={36}
                style={styles.scopePills}
              />
            ) : null}
            <ScrollView
              key={selectedTierForPricing ?? 'x'}
              style={styles.sheetScroll}
              contentContainerStyle={styles.priceList}
              showsVerticalScrollIndicator={false}
            >
              <Text style={[styles.priceSectionLabel, { color: muted }]}>
                {tierSheetSectionLabel(selectedTierForPricing, bronzeScope)}
              </Text>
              {VEHICLE_SIZE_DEFS.map((sizeDef, index) => {
                const tierKey = selectedTierForPricing;
                if (!tierKey) return null;
                const isBronze = tierKey === 'bronze';
                const scopeDef = BRONZE_WASH_SCOPES.find((s) => s.key === bronzeScope);
                const val = tierRowValue(tierPricing, tierKey, bronzeScope, sizeDef.key);
                return (
                  <PriceRow
                    key={`${tierKey}-${isBronze ? bronzeScope : 'all'}-${sizeDef.key}`}
                    index={index}
                    icon={sizeDef.icon}
                    label={sizeDef.label}
                    subtitle={`${sizeDef.subtitle} · ${formatBoundHint(getStandardPriceBound(tierKey, sizeDef.key))}`}
                    value={formatPickerPrice(val)}
                    empty={!isFilledNumber(val)}
                    accent={tierSheetAccent}
                    textMain={textMain}
                    muted={muted}
                    onPress={() =>
                      isBronze
                        ? openTierPricePicker('bronze', sizeDef.key, `${scopeDef?.label ?? ''} · ${sizeDef.label}`, bronzeScope)
                        : openTierPricePicker(tierKey, sizeDef.key, sizeDef.label)
                    }
                  />
                );
              })}
              <Text style={[styles.priceSectionLabel, { color: muted, marginTop: 8 }]}>TIME ON SITE</Text>
              {selectedTierForPricing ? (
                <PriceRow
                  index={VEHICLE_SIZE_DEFS.length}
                  icon="time-outline"
                  label="Duration"
                  subtitle="Estimated time per wash"
                  value={formatPickerMinutes(tierPricing[selectedTierForPricing]?.minutes)}
                  empty={!isFilledNumber(tierPricing[selectedTierForPricing]?.minutes)}
                  accent={tierSheetAccent}
                  textMain={textMain}
                  muted={muted}
                  onPress={() => openMinutePicker(selectedTierForPricing)}
                />
              ) : null}
            </ScrollView>
            <View style={styles.priceFooter}>
              <PricingDoneButton missing={tierSheetMissing} accent={tierSheetAccent} onPress={saveTierSheet} />
            </View>
          </View>

          <PricePickerOverlay
            scope="tier"
            target={pricePickerTarget}
            draft={pricePickerDraft}
            onDraftChange={setPricePickerDraft}
            onClose={() => setPricePickerTarget(null)}
            onDone={commitPricePicker}
            accent={tierSheetAccent}
            muted={muted}
          />

          <ValeterPickerSheet
            presentation="overlay"
            visible={!!minutePickerTier}
            title="Duration"
            onClose={() => setMinutePickerTier(null)}
            onDone={commitMinutePicker}
            accent={tierSheetAccent}
          >
            <ValeterDurationWheelPicker minutes={minutePickerDraft} onChange={setMinutePickerDraft} accent={tierSheetAccent} />
          </ValeterPickerSheet>
        </View>
      </Modal>

      {/* Detailing / repair pricing bottom sheet */}
      <Modal
        visible={!!selectedDetailingForPricing}
        transparent
        animationType="slide"
        statusBarTranslucent
        onRequestClose={() => {
          setPricePickerTarget(null);
          setSelectedDetailingForPricing(null);
        }}
      >
        <View style={styles.sheetContainer}>
          <Pressable
            style={StyleSheet.absoluteFill}
            onPress={() => {
              if (pricePickerTarget) {
                setPricePickerTarget(null);
                return;
              }
              setSelectedDetailingForPricing(null);
            }}
          >
            <View style={[StyleSheet.absoluteFill, styles.sheetBackdrop]} />
          </Pressable>
            <View
            style={[
              styles.bottomSheet,
              styles.bottomSheetHeaderStyle,
              {
                paddingBottom: Math.max(insets.bottom, 20),
                borderColor: `${primary}40`,
                backgroundColor: headerGradient[1],
              },
            ]}
            pointerEvents="box-none"
          >
            <PricingSheetBackdrop headerGradient={headerGradient} accent={addonSheetAccent} />
            <View style={styles.sheetHandle} />
            <PricingHero
              title={addonSheetDef?.name ?? ''}
              icon={addonSheetDef?.icon ?? 'pricetag'}
              accent={addonSheetAccent}
              done={VEHICLE_SIZE_DEFS.length - addonSheetMissing}
              total={VEHICLE_SIZE_DEFS.length}
              textMain={textMain}
              muted={muted}
              onClose={() => {
                setPricePickerTarget(null);
                setSelectedDetailingForPricing(null);
              }}
            />
            <ScrollView
              key={selectedDetailingForPricing ?? 'x'}
              style={styles.sheetScroll}
              contentContainerStyle={styles.priceList}
              showsVerticalScrollIndicator={false}
            >
              <Text style={[styles.priceSectionLabel, { color: muted }]}>PRICE BY VEHICLE SIZE</Text>
              {VEHICLE_SIZE_DEFS.map((sizeDef, index) => {
                const addonKey = selectedDetailingForPricing;
                if (!addonKey) return null;
                const val = addonSheetItem ? getDetailingPrices(addonSheetItem)[sizeDef.key] : null;
                return (
                  <PriceRow
                    key={`${addonKey}-${sizeDef.key}`}
                    index={index}
                    icon={sizeDef.icon}
                    label={sizeDef.label}
                    subtitle={`${sizeDef.subtitle} · ${formatBoundHint(getAddonPriceBound(addonKey, sizeDef.key))}`}
                    value={formatPickerPrice(val)}
                    empty={!isFilledNumber(val)}
                    accent={addonSheetAccent}
                    textMain={textMain}
                    muted={muted}
                    onPress={() => openAddonPricePicker(addonKey, sizeDef.key, sizeDef.label)}
                  />
                );
              })}
            </ScrollView>
            <View style={styles.priceFooter}>
              <PricingDoneButton missing={addonSheetMissing} accent={addonSheetAccent} onPress={saveAddonSheet} />
            </View>
          </View>

          <PricePickerOverlay
            scope="addon"
            target={pricePickerTarget}
            draft={pricePickerDraft}
            onDraftChange={setPricePickerDraft}
            onClose={() => setPricePickerTarget(null)}
            onDone={commitPricePicker}
            accent={addonSheetAccent}
            muted={muted}
          />
        </View>
      </Modal>

      {/* Wash / detailing / repair info bottom sheet */}
      <Modal visible={!!serviceDescTarget} transparent animationType="slide" statusBarTranslucent onRequestClose={() => setServiceDescTarget(null)}>
        <View style={styles.sheetContainer}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setServiceDescTarget(null)}>
            <View style={[StyleSheet.absoluteFill, styles.sheetBackdrop]} />
          </Pressable>
          <View style={[styles.bottomSheet, styles.bottomSheetHeaderStyle, { paddingBottom: Math.max(insets.bottom, 24), borderColor: theme.glassBorder, backgroundColor: headerGradient[1] }]} pointerEvents="box-none">
            <LinearGradient colors={headerGradient} style={StyleSheet.absoluteFill} pointerEvents="none" />
            <View style={styles.sheetHandle} />
            <LinearGradient
              colors={[`${infoAccent}30`, 'transparent']}
              start={{ x: 0.5, y: 0 }}
              end={{ x: 0.5, y: 0.45 }}
              style={StyleSheet.absoluteFill}
              pointerEvents="none"
            />
            <View style={styles.infoHero}>
              <GlassOrb icon={infoTile?.icon ?? 'information'} accent={infoAccent} size={54} />
              <View style={styles.infoHeroCopy}>
                <Text style={[styles.infoTitle, { color: textMain }]} numberOfLines={2}>
                  {serviceDescTarget ? serviceDescTitle(serviceDescTarget) : ''}
                </Text>
                {infoTile ? <ServiceInfoMeta tile={infoTile} accent={infoAccent} /> : null}
              </View>
              <Pressable
                onPress={() => setServiceDescTarget(null)}
                style={styles.infoClose}
                hitSlop={12}
                accessibilityLabel="Close"
              >
                <Ionicons name="close" size={18} color={textMain} />
              </Pressable>
            </View>
            <ScrollView
              key={serviceDescTarget ? `${serviceDescTarget.kind}-${serviceDescTarget.key}` : 'desc'}
              style={styles.sheetScroll}
              contentContainerStyle={styles.infoScroll}
              showsVerticalScrollIndicator={false}
            >
              <ServiceInfoBody desc={infoDesc} accent={infoAccent} muted={muted} textMain={textMain} />
            </ScrollView>

            {infoTile ? (
              <View style={styles.infoActions}>
                <View style={styles.infoToggle}>
                  <Text style={[styles.infoToggleLabel, { color: textMain }]}>Offer</Text>
                  <Switch
                    value={infoTile.switchValue}
                    disabled={infoTile.locked}
                    onValueChange={infoTile.onToggle}
                    trackColor={{ false: 'rgba(255,255,255,0.15)', true: infoAccent }}
                    thumbColor="#fff"
                  />
                </View>
                <PressableScale
                  fill
                  onPress={() => {
                    const open = infoTile.onPress;
                    setServiceDescTarget(null);
                    setTimeout(open, 250);
                  }}
                  style={[styles.infoPriceBtn, { backgroundColor: infoAccent }]}
                  accessibilityLabel="Set prices"
                >
                  <Ionicons name="pricetag" size={16} color="#0A1929" />
                  <Text style={styles.infoPriceBtnText}>
                    {infoTile.priceLabel === 'Set pricing' ? 'Set prices' : 'Edit prices'}
                  </Text>
                </PressableScale>
              </View>
            ) : null}
          </View>
        </View>
      </Modal>
      <InlineToast toast={toast} onHide={hideToast} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  fitBody: { flex: 1, paddingHorizontal: 18, gap: 10 },

  infoHero: { flexDirection: 'row', alignItems: 'center', gap: 14, paddingTop: 4, paddingBottom: 14 },
  infoHeroCopy: { flex: 1, minWidth: 0, gap: 6 },
  infoTitle: { fontSize: 21, fontWeight: '900', letterSpacing: -0.3 },
  infoMetaRow: { flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' },
  infoPrice: { fontSize: 14, fontWeight: '900' },
  infoStatus: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 9, height: 22, borderRadius: 11 },
  infoStatusDot: { width: 6, height: 6, borderRadius: 3 },
  infoStatusText: { fontSize: 11, fontWeight: '800' },
  infoClose: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
    alignSelf: 'flex-start',
  },
  infoScroll: { paddingBottom: 4, gap: 12 },
  infoDesc: { fontSize: 14, lineHeight: 21, fontWeight: '500' },
  infoSection: { fontSize: 10.5, fontWeight: '800', letterSpacing: 1.2, marginTop: 4 },
  infoSectionTight: { marginTop: 0, marginBottom: 2 },
  infoList: { gap: 8 },
  infoItem: { flexDirection: 'row', alignItems: 'flex-start', gap: 10 },
  infoCheck: { width: 22, height: 22, borderRadius: 11, alignItems: 'center', justifyContent: 'center', marginTop: -1 },
  infoItemText: { flex: 1, fontSize: 13.5, lineHeight: 19, fontWeight: '600' },
  infoBestFor: { flexDirection: 'row', gap: 10, padding: 12, borderRadius: 16, borderWidth: 1, alignItems: 'flex-start' },
  infoBestForCopy: { flex: 1 },
  infoActions: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  infoToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingLeft: 14,
    paddingRight: 6,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  infoToggleLabel: { fontSize: 14, fontWeight: '800' },
  infoPriceBtn: { height: 50, borderRadius: 25, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  infoPriceBtnText: { color: '#0A1929', fontSize: 15, fontWeight: '900' },

  earnCard: { paddingHorizontal: 14, paddingTop: 12, paddingBottom: 10, borderRadius: 22, gap: 9, overflow: 'hidden' },
  earnTop: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  earnCopy: { flex: 1, minWidth: 0 },
  earnLabel: { fontSize: 10, fontWeight: '800', letterSpacing: 1.1 },
  earnValue: { fontSize: 30, fontWeight: '900', letterSpacing: -0.6, fontVariant: ['tabular-nums'] },
  stepper: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    padding: 4,
    borderRadius: 999,
    backgroundColor: 'rgba(255,255,255,0.07)',
  },
  stepBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
  },
  stepValueWrap: { alignItems: 'center', minWidth: 44 },
  stepValue: { fontSize: 17, fontWeight: '900', fontVariant: ['tabular-nums'] },
  stepUnit: { fontSize: 9, fontWeight: '700', marginTop: -2 },
  mixBar: { flexDirection: 'row', height: 8, borderRadius: 4, overflow: 'hidden', gap: 2 },
  mixSeg: { height: '100%' },
  mixEmpty: { backgroundColor: 'rgba(255,255,255,0.1)' },
  earnMeta: { fontSize: 11.5, fontWeight: '600' },

  catBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', minHeight: 30, gap: 10 },
  catText: { flex: 1, fontSize: 12, fontWeight: '600' },
  catSwitch: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  catSwitchLabel: { fontSize: 12.5, fontWeight: '800' },
  catSwitchControl: { transform: [{ scale: 0.85 }] },

  grid: { flex: 1, minHeight: 0, flexDirection: 'row', flexWrap: 'wrap', alignContent: 'flex-start', gap: 10 },

  saveBar: { height: 50, borderRadius: 25, alignItems: 'center', justifyContent: 'center' },
  saveRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  saveText: { color: '#F9FAFB', fontSize: 15, fontWeight: '800' },
  scopePills: { marginBottom: 12 },
  priceList: { gap: 8, paddingBottom: 12 },
  priceSectionLabel: { fontSize: 10.5, fontWeight: '800', letterSpacing: 1.1, marginLeft: 4, marginBottom: 2 },
  priceFooter: { paddingTop: 10 },
  priceBoundHint: {
    textAlign: 'center',
    fontSize: 12,
    fontWeight: '600',
    marginTop: 10,
    letterSpacing: 0.2,
  },
  sheetContainer: { flex: 1, justifyContent: 'flex-end', position: 'relative' },
  sheetBackdrop: { backgroundColor: 'rgba(0,0,0,0.82)' },
  bottomSheet: {
    overflow: 'hidden',
    maxHeight: '88%',
    width: '100%',
    position: 'relative',
  },
  bottomSheetHeaderStyle: {
    borderTopLeftRadius: 22,
    borderTopRightRadius: 22,
    paddingHorizontal: 20,
    paddingTop: 8,
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderColor: 'rgba(56,189,248,0.35)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 16,
  },
  sheetHandle: {
    width: 36,
    height: 4,
    backgroundColor: 'rgba(255,255,255,0.35)',
    borderRadius: 2,
    alignSelf: 'center',
    marginBottom: 12,
  },
  sheetScroll: { maxHeight: 400, marginBottom: 16 },
});
