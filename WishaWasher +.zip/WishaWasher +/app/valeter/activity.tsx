import React, { useCallback, useState } from 'react';
import { RefreshControl, ScrollView, StyleSheet, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router, type Href } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import BubbleBackground from '../../src/components/shared/BubbleBackground';
import DefaultLoadingSkeleton from '../../src/components/shared/DefaultLoadingSkeleton';
import ValeterScreenHeader from '../../src/components/valeter/ValeterScreenHeader';
import { VALETER_MAP_ROUTE } from '../../src/components/valeter/ValeterNavSidebar';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import { BreathingEmpty, useValeterFitInsets } from '../../src/components/shared/fit/FitKit';
import YourJobSheetModal from '../../src/components/dashboard/powerfulDriver/YourJobSheetModal';
import { dashboardPalette } from '../../src/components/dashboard/powerfulDriver/palette';
import { NowSection, UpNextRow, WeekAgenda } from '../../src/components/valeter/activity/ActivitySections';
import { useValeterActivity, type ActivityJob } from '../../src/components/valeter/activity/useValeterActivity';
import { colors } from '../../src/constants/colors';
import { themeBackgroundGradient } from '../../src/utils/themeGradient';

/** Back to the map already in the stack, optionally straight into a trip. */
function openMap(params: Record<string, string>) {
  router.dismissTo({ pathname: VALETER_MAP_ROUTE, params: { ...params, sheetAt: String(Date.now()) } } as Href);
}

export default function ValeterActivityScreen() {
  const { theme } = useAccountTheme();
  const insets = useSafeAreaInsets();
  const fit = useValeterFitInsets(10);
  const accent = theme.primary ?? colors.SKY;
  const muted = theme.textSecondary ?? 'rgba(241,245,249,0.65)';
  const backgroundColors = themeBackgroundGradient(theme.background, [colors.BG, colors.headerBg ?? colors.BG]);
  const palette = dashboardPalette(theme);

  const { currentJob, customerName, upcoming, loading, refreshing, refresh } = useValeterActivity();
  const [openJob, setOpenJob] = useState<ActivityJob | null>(null);

  const resume = useCallback((jobId: string) => openMap({ trackingJobId: jobId }), []);
  const findWork = useCallback(() => openMap({ sheet: 'request' }), []);
  const viewTrip = useCallback(
    (jobId: string) => {
      setOpenJob(null);
      resume(jobId);
    },
    [resume]
  );

  const empty = !currentJob && upcoming.length === 0;

  return (
    <View style={styles.container}>
      <LinearGradient colors={backgroundColors} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <ValeterScreenHeader title="Activity" />

      {loading ? (
        <View style={[styles.loading, { paddingTop: fit.top }]}>
          <DefaultLoadingSkeleton message="Loading your jobs…" variant="rich" />
        </View>
      ) : (
        <ScrollView
          style={styles.scroll}
          contentContainerStyle={{ paddingTop: fit.top, paddingBottom: fit.bottom }}
          showsVerticalScrollIndicator={false}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={refresh} tintColor={accent} />}
        >
          <NowSection
            accent={accent}
            muted={muted}
            job={currentJob}
            customerName={customerName}
            onResume={resume}
            onFindWork={findWork}
          />
          {empty ? (
            <BreathingEmpty
              accent={accent}
              sf="calendar.badge.clock"
              ion="calendar-outline"
              title="Nothing scheduled"
              subtitle="Accepted bookings will line up here."
              actionLabel="Find work"
              onAction={findWork}
            />
          ) : (
            <>
              <UpNextRow accent={accent} muted={muted} jobs={upcoming} onOpenJob={setOpenJob} />
              <WeekAgenda accent={accent} muted={muted} jobs={upcoming} onOpenJob={setOpenJob} />
            </>
          )}
        </ScrollView>
      )}

      <YourJobSheetModal
        job={openJob}
        palette={palette}
        bottomInset={insets.bottom}
        onClose={() => setOpenJob(null)}
        onViewTrip={viewTrip}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scroll: {
    flex: 1,
  },
  loading: {
    flex: 1,
    paddingHorizontal: 16,
  },
});
