/**
 * Valeter chat with customer – WhatsApp-like UI (shared ChatThreadView).
 */
import React, { useMemo, useState, useEffect } from 'react';
import { View, Alert, TextInput, Text, StyleSheet, TouchableOpacity } from 'react-native';
import Reanimated, { FadeInDown, ZoomIn } from 'react-native-reanimated';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import { isChatLockedUntilPaid } from '../../../src/utils/trackingStatusHelpers';
import { router, useLocalSearchParams } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { promptAndSendBookingPhotoMessage } from '../../../src/services/bookingChatMediaService';
import { sendBookingPaymentRequest } from '../../../src/services/bookingPaymentRequestService';
import { colors } from '../../../src/constants/colors';
import { lightMistInput, lightMistPanel } from '../../../src/constants/accountThemes';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { getCustomerDisplayName } from '../../../src/utils/customerProfiles';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import ChatThreadView from '../../../src/components/chat/ChatThreadView';
import { VALETER_QUICK_REPLIES } from '../../../src/components/chat/chatTheme';
import LoadingScreen from '../../../src/components/LoadingScreen';
import InfoBottomSheet from '../../../src/components/shared/InfoBottomSheet';
import ContinueCTAButton from '../../../src/components/ui/ContinueCTAButton';
import { markValeterBookingChatMessagesAsRead } from '../../../src/services/valeterBookingChatService';
import { toast } from '../../../src/components/shared/ToastHost';

const SKY = colors.SKY;

export default function ValeterJobChatScreen() {
  const params = useLocalSearchParams<{ bookingId: string }>();
  const bookingId = params.bookingId;
  const { user } = useAuth();
  const { theme, mode } = useAccountTheme();
  const isLight = mode === 'light';
  const accent = theme?.primary ?? SKY;
  const chatWall = isLight ? '#C5DCE8' : (theme?.background?.[0] ?? '#0B1F36');
  const sheetText = isLight ? '#0F2740' : '#FFFFFF';
  const sheetMuted = isLight ? 'rgba(15,39,64,0.62)' : 'rgba(255,255,255,0.65)';
  const sheetSoft = isLight ? 'rgba(15,39,64,0.45)' : 'rgba(255,255,255,0.38)';
  const sheetFieldBg = isLight ? lightMistInput : 'rgba(255,255,255,0.06)';
  const sheetFieldBorder = isLight ? 'rgba(126,184,212,0.45)' : 'rgba(255,255,255,0.12)';
  const amountCardBg = isLight ? lightMistPanel : 'rgba(255,255,255,0.05)';
  const amountCardBorder = isLight ? 'rgba(126,184,212,0.4)' : 'rgba(255,255,255,0.1)';

  const [customerName, setCustomerName] = useState<string>('Customer');
  const [serviceName, setServiceName] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [bookingStatus, setBookingStatus] = useState<string | null>(null);
  const [requestModalVisible, setRequestModalVisible] = useState(false);
  const [requestAmount, setRequestAmount] = useState('');
  const [requestReason, setRequestReason] = useState('');
  const [requestNote, setRequestNote] = useState('');
  const [submittingRequest, setSubmittingRequest] = useState(false);

  const parsedAmount = Number(requestAmount);
  const amountPreview = useMemo(() => {
    if (!Number.isFinite(parsedAmount) || parsedAmount <= 0) return null;
    const platformFee = Math.max(0, parsedAmount * 0.05);
    return {
      total: parsedAmount,
      platformFee,
      youReceive: Math.max(0, parsedAmount - platformFee),
    };
  }, [parsedAmount]);

  useEffect(() => {
    if (!bookingId) {
      setLoading(false);
      return;
    }
    void (async () => {
      try {
        const { data, error } = await supabase
          .from('bookings')
          .select('user_id, service_type, service_name, location_address, status')
          .eq('id', bookingId)
          .eq('valeter_id', user?.id)
          .maybeSingle();
        if (error || !data) {
          setLoading(false);
          return;
        }
        const r = data as any;
        setBookingStatus(r.status ?? null);
        setServiceName(getServiceDisplayName(r.service_type, r.service_name));
        setCustomerName(await getCustomerDisplayName(r.user_id));
      } catch {
        setCustomerName('Customer');
      } finally {
        setLoading(false);
      }
    })();
  }, [bookingId, user?.id]);

  useEffect(() => {
    if (!bookingId || !user?.id) return;
    void markValeterBookingChatMessagesAsRead(bookingId).catch(() => undefined);
  }, [bookingId, user?.id]);

  const handleBack = () => {
    void hapticFeedback('light');
    router.back();
  };

  const handleCall = () => {
    void hapticFeedback('light');
    toast.info('Call customer – will open phone dialler when connected.', 'Call');
  };

  const handleAttachImage = async () => {
    void hapticFeedback('light');
    if (!bookingId || !user?.id) return;
    try {
      await promptAndSendBookingPhotoMessage({
        bookingId,
        senderId: user.id,
        senderRole: 'valeter',
        content: 'IMAGE',
        promptTitle: 'Photo',
        promptMessage: 'Take a photo to send in chat.',
      });
    } catch (error: any) {
      toast.error(error?.message || 'Could not take or send the photo.', 'Photo');
    }
  };


  const openPaymentRequest = () => {
    void hapticFeedback('light');
    setRequestModalVisible(true);
  };

  const submitPaymentRequest = async () => {
    if (!bookingId || !user?.id) return;
    const amount = Number(requestAmount);
    if (!Number.isFinite(amount) || amount <= 0) {
      Alert.alert('Extra charge', 'Enter a valid amount.');
      return;
    }
    if (!requestReason.trim()) {
      Alert.alert('Extra charge', 'Tell the customer why you need the extra amount.');
      return;
    }

    try {
      await hapticFeedback('medium');
      setSubmittingRequest(true);
      await sendBookingPaymentRequest({
        bookingId,
        senderId: user.id,
        senderRole: 'valeter',
        amount,
        reason: requestReason.trim(),
        note: requestNote.trim() || undefined,
        currency: 'gbp',
      });
      setRequestModalVisible(false);
      setRequestAmount('');
      setRequestReason('');
      setRequestNote('');
      toast.success('The customer will see the extra charge request in chat.', 'Request sent');
    } catch (error: any) {
      Alert.alert('Extra charge', error?.message || 'Could not send the request.');
    } finally {
      setSubmittingRequest(false);
    }
  };

  const handleDeleteChat = () => {
    void hapticFeedback('light');
    Alert.alert(
      'Delete chat',
      'Remove this conversation from your list?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            if (bookingId) {
              const { addDeletedChatBookingId } = await import('../../../src/services/DeletedChatsService');
              await addDeletedChatBookingId(bookingId);
            }
            router.back();
          },
        },
      ]
    );
  };

  if (loading) {
    return <LoadingScreen message="Loading…" />;
  }

  if (bookingStatus != null && isChatLockedUntilPaid(bookingStatus)) {
    return (
      <SafeAreaView style={[styles.lockedScreen, { backgroundColor: chatWall }]}>
        <BubbleBackground accountType="valeter" />
        <TouchableOpacity
          onPress={handleBack}
          style={[styles.lockedBack, { backgroundColor: sheetFieldBg, borderColor: sheetFieldBorder }]}
          accessibilityRole="button"
          accessibilityLabel="Back"
        >
          <Ionicons name="chevron-back" size={20} color={sheetText} />
        </TouchableOpacity>
        <Reanimated.View
          entering={FadeInDown.springify().damping(16)}
          style={[styles.lockedCard, { backgroundColor: amountCardBg, borderColor: `${accent}40` }]}
        >
          <Reanimated.View
            entering={ZoomIn.delay(120).springify().damping(10)}
            style={[styles.lockedIcon, { backgroundColor: 'rgba(251,191,36,0.16)', borderColor: 'rgba(251,191,36,0.45)' }]}
          >
            <Ionicons name="lock-closed" size={28} color="#FBBF24" />
          </Reanimated.View>
          <Text style={[styles.lockedTitle, { color: sheetText }]}>Chat unlocks after payment</Text>
          <Text style={[styles.lockedBody, { color: sheetMuted }]}>
            You can message {customerName} as soon as they've paid for this booking. We'll keep the job
            on your tracking screen until then.
          </Text>
          <ContinueCTAButton title="Back to job" onPress={handleBack} accentColor={accent} />
        </Reanimated.View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: chatWall }} edges={[]}>
      <ChatThreadView
        bookingId={bookingId}
        currentUserId={user?.id ?? null}
        currentUserRole="valeter"
        title={customerName}
        subtitle={serviceName}
        onBack={handleBack}
        onCall={handleCall}
        onAttachImage={handleAttachImage}
        onRequestPayment={openPaymentRequest}
        onDelete={handleDeleteChat}
        accentColor={accent}
        backgroundColor={chatWall}
        quickReplies={VALETER_QUICK_REPLIES}
      />

      <InfoBottomSheet
        visible={requestModalVisible}
        onClose={() => setRequestModalVisible(false)}
        title="Request extra payment"
        accentColor={accent}
        variant="header"
        contentMaxHeight="68%"
        footer={
          <View style={styles.sheetFooter}>
            <ContinueCTAButton
              title={submittingRequest ? 'Sending…' : 'Send request'}
              onPress={submitPaymentRequest}
              accentColor={accent}
              loading={submittingRequest}
              disabled={submittingRequest}
              showTrailingChevron={false}
            />
          </View>
        }
      >
        <Text style={[styles.sheetSubtitle, { color: sheetMuted }]}>
          The customer will get a pay button in this chat.
        </Text>

        <View style={[styles.amountCard, { backgroundColor: amountCardBg, borderColor: amountCardBorder }]}>
          <Text style={[styles.amountLabel, { color: sheetSoft }]}>Amount</Text>
          <View style={styles.amountRow}>
            <Text style={[styles.amountCurrency, { color: accent }]}>£</Text>
            <TextInput
              value={requestAmount}
              onChangeText={setRequestAmount}
              placeholder="0.00"
              placeholderTextColor={sheetSoft}
              keyboardType="decimal-pad"
              style={[styles.amountInput, { color: sheetText }]}
            />
          </View>
          {amountPreview ? (
            <Text style={[styles.amountMeta, { color: sheetMuted }]}>
              Fee £{amountPreview.platformFee.toFixed(2)} · You receive £{amountPreview.youReceive.toFixed(2)}
            </Text>
          ) : null}
        </View>

        <View style={styles.field}>
          <Text style={[styles.label, { color: sheetText }]}>Reason</Text>
          <TextInput
            value={requestReason}
            onChangeText={setRequestReason}
            placeholder="e.g. Very dirty car, extra time needed"
            placeholderTextColor={sheetSoft}
            style={[styles.input, styles.inputMultiline, { color: sheetText, backgroundColor: sheetFieldBg, borderColor: sheetFieldBorder }]}
            multiline
          />
        </View>

        <View style={styles.field}>
          <Text style={[styles.label, { color: sheetText }]}>
            Note <Text style={[styles.labelOptional, { color: sheetSoft }]}>(optional)</Text>
          </Text>
          <TextInput
            value={requestNote}
            onChangeText={setRequestNote}
            placeholder="Any extra detail"
            placeholderTextColor={sheetSoft}
            style={[styles.input, { color: sheetText, backgroundColor: sheetFieldBg, borderColor: sheetFieldBorder }]}
          />
        </View>
      </InfoBottomSheet>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  lockedScreen: {
    flex: 1,
    paddingHorizontal: 20,
    justifyContent: 'center',
  },
  lockedBack: {
    position: 'absolute',
    top: 60,
    left: 20,
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  lockedCard: {
    borderRadius: 24,
    borderWidth: 1,
    padding: 22,
    alignItems: 'center',
    gap: 10,
  },
  lockedIcon: {
    width: 64,
    height: 64,
    borderRadius: 32,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
  },
  lockedTitle: { fontSize: 20, fontWeight: '900', textAlign: 'center' },
  lockedBody: { fontSize: 14, lineHeight: 20, fontWeight: '600', textAlign: 'center', marginBottom: 8 },
  sheetFooter: {
    gap: 10,
  },
  sheetSubtitle: {
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 16,
  },
  amountCard: {
    marginBottom: 16,
    padding: 14,
    borderRadius: 16,
    borderWidth: 1,
  },
  amountLabel: {
    fontSize: 12,
    fontWeight: '700',
    marginBottom: 8,
  },
  amountRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  amountCurrency: {
    fontSize: 28,
    fontWeight: '800',
  },
  amountInput: {
    flex: 1,
    fontSize: 28,
    fontWeight: '800',
    paddingVertical: 0,
    minHeight: 40,
  },
  amountMeta: {
    marginTop: 10,
    fontSize: 12,
    lineHeight: 16,
    fontWeight: '500',
  },
  field: {
    gap: 8,
    marginBottom: 14,
  },
  label: {
    fontSize: 13,
    fontWeight: '700',
  },
  labelOptional: {
    fontWeight: '600',
  },
  input: {
    borderWidth: 1,
    borderRadius: 14,
    fontSize: 15,
    lineHeight: 21,
    minHeight: 48,
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  inputMultiline: {
    minHeight: 72,
    textAlignVertical: 'top',
  },
});
