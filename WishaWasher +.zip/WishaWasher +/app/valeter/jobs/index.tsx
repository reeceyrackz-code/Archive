import { Redirect } from 'expo-router';

/** Legacy /valeter/jobs list — current and upcoming jobs live on the Activity screen now. */
export default function JobsPageRedirect() {
  return <Redirect href="/valeter/activity" />;
}
