import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import Reanimated, {
  FadeInDown,
  useAnimatedStyle,
  useSharedValue,
  withSequence,
  withTiming,
} from 'react-native-reanimated';

import type { NotificationInboxGlyph } from '../../src/components/shared/NotificationInboxRow';
import DefaultLoadingSkeleton from '../../src/components/shared/DefaultLoadingSkeleton';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import GlassSurface from '../../src/components/shared/GlassSurface';
import ValeterScreenHeader from '../../src/components/valeter/ValeterScreenHeader';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { colors } from '../../src/constants/colors';
import { themeBackgroundGradient } from '../../src/utils/themeGradient';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import {
  BreathingEmpty,
  CountUpText,
  FitPager,
  PressableScale,
  PulseDot,
  SegmentedPills,
  SymbolGlyph,
  useValeterFitInsets,
} from '../../src/components/shared/fit/FitKit';
import { dismissValeterNotificationIds, loadDismissedValeterNotificationIds } from '../../src/services/valeterNotificationDismissals';
import {
  fetchUnreadValeterBookingChatThreads,
  type ValeterBookingChatNotificationThread,
} from '../../src/services/valeterBookingChatService';
import { ChromeGlyph as Ionicons } from '../../src/components/shared/ChromeGlyph';
type JobStatus =
  | 'pending'
  | 'pending_valeter_acceptance'
  | 'pending_payment'
  | 'scheduled'
  | 'confirmed'
  | 'en_route'
  | 'arrived'
  | 'in_progress'
  | 'completed';

type DocumentType = 'id_proof' | 'selfie' | 'profile_photo' | 'disclaimer_signed';

type DocumentStatus = 'pending' | 'approved' | 'rejected' | 'not_uploaded';

type ValeterNotificationType = 'job' | 'chat' | 'document' | 'compliance' | 'system';

interface ValeterNotification {
  id: string;
  title: string;
  message: string;
  createdAt: string;
  type: ValeterNotificationType;
  status?: string;
  priority?: 'low' | 'medium' | 'high';
  actionRoute?: string;
  actionParams?: Record<string, string>;
  unreadCount?: number;
  chatPreview?: string;
}

interface BookingRow {
  id: string;
  status: JobStatus;
  service_type: string | null;
  service_name: string | null;
  location_address: string | null;
  updated_at: string | null;
  created_at: string | null;
}

interface ValeterDocumentRow {
  id: string;
  type: DocumentType;
  status: DocumentStatus;
  name: string | null;
  rejection_reason?: string | null;
  uploaded_at?: string | null;
  updated_at?: string | null;
}

const DOC_LABELS: Record<DocumentType, string> = {
  id_proof: 'Proof of Identity',
  selfie: 'Selfie Photo',
  profile_photo: 'Profile Photo',
  disclaimer_signed: 'Terms & Conditions',
};

type SectionKey = 'today' | 'yesterday' | 'week' | 'older';

function getSectionKey(dateString: string): SectionKey {
  const d = new Date(dateString);
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const dayStart = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
  const diffDays = (today - dayStart) / (24 * 60 * 60 * 1000);
  if (diffDays <= 0) return 'today';
  if (diffDays <= 1) return 'yesterday';
  if (diffDays <= 7) return 'week';
  return 'older';
}


const ACTIVE_JOB_NOTIFICATION_STATUSES = new Set([
  'pending_valeter_acceptance',
  'pending_payment',
  'scheduled',
  'confirmed',
  'en_route',
  'arrived',
  'in_progress',
]);

function isJobNotificationActive(notification: ValeterNotification): boolean {
  if (notification.type !== 'job') return true;
  const status = typeof notification.status === 'string' ? notification.status.toLowerCase() : '';
  return ACTIVE_JOB_NOTIFICATION_STATUSES.has(status as JobStatus);
}

function jobNotificationIconMeta(status?: string): { icon: NotificationInboxGlyph; color: string; background: string } {
  let icon: NotificationInboxGlyph = 'briefcase-outline';
  if (status === 'completed') icon = 'checkmark-done-outline';
  else if (status === 'pending_payment') icon = 'wallet-outline';
  return { icon, color: '#10B981', background: 'rgba(16,185,129,0.15)' };
}

function documentNotificationIconMeta(status?: string): { icon: NotificationInboxGlyph; color: string; background: string } {
  if (status === 'rejected') {
    return { icon: 'close-circle-outline', color: '#F87171', background: 'rgba(248,113,113,0.12)' };
  }
  if (status === 'approved') {
    return { icon: 'checkmark-circle-outline', color: '#34D399', background: 'rgba(52,211,153,0.12)' };
  }
  return { icon: 'document-text-outline', color: '#7DD3FC', background: 'rgba(125,211,252,0.12)' };
}

function chatNotificationIconMeta(): { icon: NotificationInboxGlyph; color: string; background: string } {
  return { icon: 'chatbubbles-outline', color: '#7DD3FC', background: 'rgba(125,211,252,0.12)' };
}

const getIconMeta = (
  type: ValeterNotificationType,
  status?: string
): { icon: NotificationInboxGlyph; color: string; background: string } => {
  switch (type) {
    case 'job':
      return jobNotificationIconMeta(status);
    case 'chat':
      return chatNotificationIconMeta();
    case 'document':
      return documentNotificationIconMeta(status);
    case 'compliance':
      return { icon: 'shield-checkmark-outline', color: '#FBBF24', background: 'rgba(251,191,36,0.14)' };
    default:
      return { icon: 'notifications-outline', color: '#7DD3FC', background: 'rgba(125,211,252,0.12)' };
  }
};


type NotificationFilter = 'all' | 'jobs' | 'chats' | 'account';

const ROW_HEIGHT = 74;

function filterForType(type: ValeterNotificationType): Exclude<NotificationFilter, 'all'> {
  if (type === 'job') return 'jobs';
  if (type === 'chat') return 'chats';
  return 'account';
}

type NotificationListItemProps = {
  item: ValeterNotification;
  primary: string;
  formatRelativeTime: (dateString: string) => string;
  onPress: (notification: ValeterNotification) => void;
  onDismiss: (notificationId: string) => void;
};

function ValeterNotificationListItem({
  item,
  primary,
  formatRelativeTime,
  onPress,
  onDismiss,
}: Readonly<NotificationListItemProps>) {
  const iconMeta = getIconMeta(item.type, item.status);
  const inactive = !isJobNotificationActive(item);
  const canOpen = Boolean(item.actionRoute) && inactive === false;
  const urgent = item.priority === 'high' && !inactive;

  return (
    <PressableScale
      onPress={canOpen ? () => onPress(item) : undefined}
      haptic={canOpen}
      fill
      style={[styles.rowPress, inactive && styles.rowInactive]}
      accessibilityLabel={item.title}
    >
      <GlassSurface style={styles.row} interactive={canOpen} fallbackColor="rgba(10,25,41,0.55)">
        {urgent ? (
          <LinearGradient
            colors={['rgba(248,113,113,0.18)', 'transparent']}
            start={{ x: 0, y: 0.5 }}
            end={{ x: 0.7, y: 0.5 }}
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
          />
        ) : null}
        <View style={[styles.rowIcon, { backgroundColor: iconMeta.background }]}>
          <SymbolGlyphFor type={item.type} status={item.status} color={iconMeta.color} />
          {item.unreadCount ? (
            <View style={[styles.unreadBadge, { backgroundColor: primary }]}>
              <Text style={styles.unreadBadgeText}>{item.unreadCount > 9 ? '9+' : item.unreadCount}</Text>
            </View>
          ) : null}
        </View>
        <View style={styles.rowBody}>
          <View style={styles.rowTop}>
            {urgent ? <PulseDot color="#F87171" size={6} /> : null}
            <Text style={styles.rowTitle} numberOfLines={1}>
              {item.title}
            </Text>
          </View>
          <Text style={styles.rowMessage} numberOfLines={1}>
            {item.message}
          </Text>
          <Text style={[styles.rowTime, { color: `${primary}CC` }]}>{formatRelativeTime(item.createdAt)}</Text>
        </View>
        <TouchableOpacity
          onPress={() => {
            void hapticFeedback('light');
            onDismiss(item.id);
          }}
          hitSlop={10}
          style={styles.dismissBtn}
          accessibilityLabel="Dismiss notification"
        >
          <Ionicons name="close" size={15} color="rgba(203,213,225,0.7)" />
        </TouchableOpacity>
      </GlassSurface>
    </PressableScale>
  );
}

function heroSubtitle(urgentCount: number) {
  if (urgentCount === 0) return 'Nothing urgent · tap ✕ to clear';
  return urgentCount === 1 ? '1 needs your attention' : `${urgentCount} need your attention`;
}

function SymbolGlyphFor({
  type,
  status,
  color,
}: Readonly<{ type: ValeterNotificationType; status?: string; color: string }>) {
  const ion = getIconMeta(type, status).icon;
  if (type === 'chat') return <SymbolGlyph sf="bubble.left.and.bubble.right.fill" ion={ion} size={20} color={color} />;
  if (type === 'compliance') return <SymbolGlyph sf="checkmark.shield.fill" ion={ion} size={20} color={color} />;
  if (type === 'document') {
    if (status === 'rejected') return <SymbolGlyph sf="xmark.circle.fill" ion={ion} size={20} color={color} />;
    if (status === 'approved') return <SymbolGlyph sf="checkmark.seal.fill" ion={ion} size={20} color={color} />;
    return <SymbolGlyph sf="doc.text.fill" ion={ion} size={20} color={color} />;
  }
  if (type === 'job') {
    if (status === 'pending_payment') return <SymbolGlyph sf="creditcard.fill" ion={ion} size={20} color={color} />;
    if (status === 'completed') return <SymbolGlyph sf="checkmark.circle.fill" ion={ion} size={20} color={color} />;
    return <SymbolGlyph sf="car.fill" ion={ion} size={20} color={color} />;
  }
  return <SymbolGlyph sf="bell.fill" ion={ion} size={20} color={color} />;
}

/** Row builders for each notification source (stable callbacks). */
function useNotificationMappers() {
  const formatRelativeTime = useCallback((dateString: string) => {
    const date = new Date(dateString);
    if (Number.isNaN(date.getTime())) return '';
    const section = getSectionKey(dateString);
    const diff = Date.now() - date.getTime();
    const minute = 60 * 1000;
    const hour = 60 * minute;
    const day = 24 * hour;
    if (diff < minute) return 'Just now';
    if (diff < hour) {
      const m = Math.floor(diff / minute);
      return `${m} min${m === 1 ? '' : 's'} ago`;
    }
    if (diff < day) {
      const h = Math.floor(diff / hour);
      return `${h} hr${h === 1 ? '' : 's'} ago`;
    }
    if (section === 'yesterday') return `Yesterday · ${date.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}`;
    const d = Math.floor(diff / day);
    if (d < 7) {
      return `${d} day${d === 1 ? '' : 's'} ago`;
    }
    return date.toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  }, []);

  const mapJobNotification = useCallback((job: BookingRow): ValeterNotification => {
    const statusCopy: Record<JobStatus, { title: string; message: string; priority: 'low' | 'medium' | 'high' }> = {
      pending: {
        title: 'Booking Request',
        message: 'A customer has requested a booking. Open to review the details.',
        priority: 'high',
      },
      pending_valeter_acceptance: {
        title: 'New Booking Request',
        message: 'A customer is waiting for you to accept this job.',
        priority: 'high',
      },
      pending_payment: {
        title: 'Awaiting Payment',
        message: 'Customer needs to complete payment before work can begin.',
        priority: 'medium',
      },
      scheduled: {
        title: 'Scheduled Job',
        message: 'This booking is scheduled and ready for your route.',
        priority: 'low',
      },
      confirmed: {
        title: 'Job Confirmed',
        message: 'Payment received. You can start travelling when ready.',
        priority: 'medium',
      },
      en_route: {
        title: 'En Route',
        message: 'Marked as en route. Keep the customer updated.',
        priority: 'low',
      },
      arrived: {
        title: 'Arrived On Site',
        message: 'Remember to start the service when you begin washing.',
        priority: 'medium',
      },
      in_progress: {
        title: 'Service In Progress',
        message: 'Complete the checklist before finishing the job.',
        priority: 'low',
      },
      completed: {
        title: 'Job Completed',
        message: 'Nice work! Submit photos and completion details if required.',
        priority: 'low',
      },
    };

    const copy = statusCopy[job.status] ?? statusCopy.confirmed;
    const serviceName = job.service_name || job.service_type || 'Service';
    const isActive = ACTIVE_JOB_NOTIFICATION_STATUSES.has(job.status);

    return {
      id: `job-${job.id}-${job.status}`,
      title: `${copy.title} · ${serviceName}`,
      message: copy.message,
      createdAt: job.updated_at || job.created_at || new Date().toISOString(),
      type: 'job',
      status: job.status,
      priority: copy.priority,
      actionRoute: isActive ? '/valeter/valeter-dashboard' : undefined,
      actionParams: isActive ? { trackingJobId: job.id } : undefined,
    };
  }, []);

  const mapDocumentNotification = useCallback((doc: ValeterDocumentRow): ValeterNotification => {
    const baseTitle = DOC_LABELS[doc.type] || 'Document';
    let title: string;
    let message: string;
    let priority: ValeterNotification['priority'];

    switch (doc.status) {
      case 'pending':
        title = `${baseTitle} pending review`;
        message = 'Hang tight—our compliance team is reviewing this upload.';
        priority = 'low';
        break;
      case 'approved':
        title = `${baseTitle} approved`;
        message = 'You are all set for this requirement.';
        priority = 'low';
        break;
      case 'rejected':
        title = `${baseTitle} rejected`;
        message = doc.rejection_reason
          ? doc.rejection_reason
          : 'Please resubmit this document with the requested corrections.';
        priority = 'high';
        break;
      case 'not_uploaded':
      default:
        title = `${baseTitle} missing`;
        message = 'Upload this document to stay compliant.';
        priority = 'high';
        break;
    }

    return {
      id: `doc-${doc.id}`,
      title,
      message,
      createdAt: doc.updated_at || doc.uploaded_at || new Date().toISOString(),
      type: 'document',
      status: doc.status,
      priority,
      actionRoute: '/valeter/profile/valeter-documents',
    };
  }, []);

  const mapChatNotification = useCallback((thread: ValeterBookingChatNotificationThread): ValeterNotification => {
    const serviceName = thread.serviceName || thread.serviceType || 'Booking';
    const unreadLabel = thread.unreadCount === 1 ? '1 new message' : `${thread.unreadCount} new messages`;
    const preview = thread.latestMessagePreview ? ` • ${thread.latestMessagePreview}` : '';

    return {
      id: `chat-${thread.bookingId}`,
      title: `Customer message · ${serviceName}`,
      message: `${unreadLabel}${preview}`,
      createdAt: thread.latestMessageAt,
      type: 'chat',
      priority: thread.unreadCount > 1 ? 'high' : 'medium',
      actionRoute: '/valeter/jobs/chat',
      actionParams: { bookingId: thread.bookingId },
      unreadCount: thread.unreadCount,
      chatPreview: thread.latestMessagePreview,
    };
  }, []);

  const computeComplianceReminder = useCallback(
    (documents: ValeterDocumentRow[] = [], profilePhotoUrl?: string | null): ValeterNotification | null => {
      const requiredTypes: DocumentType[] = ['id_proof', 'selfie', 'profile_photo', 'disclaimer_signed'];
      const uploadedTypes = new Set(documents.map((doc) => doc.type));
      let missingTypes = requiredTypes.filter((type) => !uploadedTypes.has(type));

      const hasApprovedProfilePhoto = profilePhotoUrl || documents.some(
        (doc) => doc.type === 'profile_photo' && doc.status === 'approved'
      );
      if (!hasApprovedProfilePhoto && !missingTypes.includes('profile_photo')) {
        missingTypes = [...missingTypes, 'profile_photo'];
      }

      if (missingTypes.length === 0) {
        return null;
      }

      const missingNames = missingTypes.map((type) => DOC_LABELS[type]);

      return {
        id: `compliance-${missingTypes.join('-')}`,
        title: missingTypes.length === 1 ? 'Document Required' : 'Documents Required',
        message: `Upload ${missingNames.join(', ')} to stay compliant.`,
        createdAt: new Date().toISOString(),
        type: 'compliance',
        priority: missingTypes.length > 1 ? 'high' : 'medium',
        actionRoute: '/valeter/profile/valeter-documents',
      };
    },
    []
  );

  return { formatRelativeTime, mapJobNotification, mapDocumentNotification, mapChatNotification, computeComplianceReminder };
}

export default function ValeterNotifications() {
  const { user } = useAuth();
  const { theme } = useAccountTheme();
  const primary = theme.primary ?? colors.SKY;
  const backgroundColors = themeBackgroundGradient(theme.background, [colors.BG, colors.headerBg ?? colors.BG]);
  const fit = useValeterFitInsets(10);

  const [notifications, setNotifications] = useState<ValeterNotification[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [filter, setFilter] = useState<NotificationFilter>('all');
  const spin = useSharedValue(0);
  const spinStyle = useAnimatedStyle(() => ({ transform: [{ rotate: `${spin.value * 360}deg` }] }));

  const { formatRelativeTime, mapJobNotification, mapDocumentNotification, mapChatNotification, computeComplianceReminder } = useNotificationMappers();

  const fetchNotifications = useCallback(async () => {
    if (!user?.id) return;
    if (!refreshing) setLoading(true);
    try {
      const [jobsRes, docsRes, profileRes, chatThreads] = await Promise.all([
        supabase
          .from('bookings')
          .select('id,status,service_type,service_name,location_address,updated_at,created_at')
          .eq('valeter_id', user.id)
          .order('updated_at', { ascending: false })
          .limit(30),
        supabase
          .from('valeter_documents')
          .select('id,type,status,name,rejection_reason,uploaded_at,updated_at')
          .eq('user_id', user.id),
        supabase
          .from('valeter_profiles')
          .select('profile_photo_url')
          .eq('user_id', user.id)
          .maybeSingle(),
        fetchUnreadValeterBookingChatThreads(user.id),
      ]);

      const jobNotifications = (jobsRes.data ?? []).map((job) => mapJobNotification(job as BookingRow));
      const documentNotifications = (docsRes.data ?? []).map((doc) => mapDocumentNotification(doc as ValeterDocumentRow));
      const chatNotifications = (chatThreads ?? []).map((thread) => mapChatNotification(thread));

      const complianceNotification = computeComplianceReminder(
        (docsRes.data ?? []) as ValeterDocumentRow[],
        profileRes.data?.profile_photo_url
      );
      const complianceList = complianceNotification ? [complianceNotification] : [];
      const combined = [...jobNotifications, ...chatNotifications, ...documentNotifications, ...complianceList].sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
      const dismissed = await loadDismissedValeterNotificationIds(user.id);
      const visible = combined.filter((n) => !dismissed.has(n.id));
      setNotifications(visible);
    } catch (error) {
      console.error('[ValeterNotifications] Failed to load notifications', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [user?.id, mapJobNotification, mapChatNotification, mapDocumentNotification, computeComplianceReminder, refreshing]);

  useEffect(() => {
    void fetchNotifications();
  }, [fetchNotifications]);

  useEffect(() => {
    if (!user?.id) return;
    const jobChannel = supabase
      .channel(`valeter-notifications-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'bookings',
          filter: `valeter_id=eq.${user.id}`,
        },
        () => fetchNotifications()
      )
      .subscribe();

    const docChannel = supabase
      .channel(`valeter-docs-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'valeter_documents',
          filter: `user_id=eq.${user.id}`,
        },
        () => fetchNotifications()
      )
      .subscribe();

    const chatChannel = supabase
      .channel(`valeter-chat-notifications-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'booking_messages',
        },
        () => fetchNotifications()
      )
      .subscribe();

    return () => {
      void supabase.removeChannel(jobChannel);
      void supabase.removeChannel(docChannel);
      void supabase.removeChannel(chatChannel);
    };
  }, [user?.id, fetchNotifications]);

  const handleRefresh = useCallback(() => {
    if (refreshing) return;
    spin.value = 0;
    spin.value = withSequence(withTiming(1, { duration: 700 }), withTiming(1, { duration: 0 }));
    setRefreshing(true);
    void fetchNotifications();
  }, [fetchNotifications, refreshing, spin]);

  const handleNotificationPress = useCallback((notification: ValeterNotification) => {
    if (notification.actionRoute) {
      router.push({
        pathname: notification.actionRoute,
        params: notification.actionParams ?? {},
      });
    }
  }, []);

  const removeNotification = useCallback(async (notificationId: string) => {
    if (user?.id) {
      await dismissValeterNotificationIds(user.id, [notificationId]);
    }
    setNotifications((prev) => prev.filter((n) => n.id !== notificationId));
  }, [user?.id]);

  const removeAllNotifications = useCallback(async () => {
    if (user?.id) {
      await dismissValeterNotificationIds(
        user.id,
        notifications.map((n) => n.id)
      );
    }
    setNotifications([]);
  }, [notifications, user?.id]);

  const handleDeleteAll = useCallback(() => {
    if (notifications.length === 0) return;
    
    Alert.alert(
      'Delete All Notifications',
      `Are you sure you want to delete all ${notifications.length} notification${notifications.length === 1 ? '' : 's'}?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete All',
          style: 'destructive',
          onPress: () => {
            void removeAllNotifications();
          },
        },
      ]
    );
  }, [notifications, removeAllNotifications]);

  const counts = useMemo(() => {
    const c = { all: notifications.length, jobs: 0, chats: 0, account: 0 };
    for (const n of notifications) c[filterForType(n.type)] += 1;
    return c;
  }, [notifications]);

  const visible = useMemo(
    () => (filter === 'all' ? notifications : notifications.filter((n) => filterForType(n.type) === filter)),
    [filter, notifications]
  );

  const urgentCount = notifications.filter((n) => n.priority === 'high' && isJobNotificationActive(n)).length;

  const headerRightAction =
    notifications.length > 0 ? (
      <TouchableOpacity
        onPress={async () => {
          await hapticFeedback('light');
          handleDeleteAll();
        }}
        style={styles.deleteAllButton}
        activeOpacity={0.7}
      >
        <Text style={[styles.deleteAllText, { color: primary }]}>Clear all</Text>
      </TouchableOpacity>
    ) : null;

  return (
    <View style={styles.container}>
      <LinearGradient colors={backgroundColors} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <ValeterScreenHeader title="Notifications" rightAction={headerRightAction} />

      <View style={[styles.content, { paddingTop: fit.top, paddingBottom: fit.bottom }]}>
        {loading && notifications.length === 0 ? (
          <View style={styles.loadingWrap}>
            <DefaultLoadingSkeleton message="Loading notifications…" variant="rich" />
          </View>
        ) : null}
        {!loading && notifications.length === 0 ? (
          <BreathingEmpty
            accent={primary}
            sf="bell.badge.slash.fill"
            ion="notifications-off-outline"
            title="You're all caught up"
            subtitle="Job updates, chats and reminders will land here."
          />
        ) : null}
        {notifications.length > 0 ? (
          <>
            <Reanimated.View entering={FadeInDown.springify().damping(18)}>
              <GlassSurface style={styles.hero} fallbackColor="rgba(10,25,41,0.55)">
                <LinearGradient
                  colors={[urgentCount > 0 ? 'rgba(248,113,113,0.22)' : `${primary}33`, 'transparent']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={StyleSheet.absoluteFill}
                  pointerEvents="none"
                />
                <View style={[styles.heroIcon, { backgroundColor: `${primary}26` }]}>
                  <SymbolGlyph sf="bell.badge.fill" ion="notifications" size={22} color={primary} />
                </View>
                <View style={styles.heroCopy}>
                  <View style={styles.heroCountRow}>
                    <CountUpText value={notifications.length} style={styles.heroCount} />
                    <Text style={styles.heroCountLabel}>{notifications.length === 1 ? 'update' : 'updates'}</Text>
                  </View>
                  <View style={styles.heroSubRow}>
                    {urgentCount > 0 ? <PulseDot color="#F87171" size={6} /> : null}
                    <Text style={styles.heroSub}>{heroSubtitle(urgentCount)}</Text>
                  </View>
                </View>
                <PressableScale
                  onPress={handleRefresh}
                  style={[styles.refreshBtn, { borderColor: `${primary}55` }]}
                  accessibilityLabel="Refresh"
                >
                  <Reanimated.View style={spinStyle}>
                    <Ionicons name="refresh" size={18} color={primary} />
                  </Reanimated.View>
                </PressableScale>
              </GlassSurface>
            </Reanimated.View>

            <SegmentedPills
              accent={primary}
              value={filter}
              onChange={setFilter}
              style={styles.segments}
              segments={[
                { key: 'all', label: 'All', count: counts.all },
                { key: 'jobs', label: 'Jobs', count: counts.jobs },
                { key: 'chats', label: 'Chats', count: counts.chats },
                { key: 'account', label: 'Account', count: counts.account },
              ]}
            />

            <FitPager
              items={visible}
              rowHeight={ROW_HEIGHT}
              accent={primary}
              resetKey={filter}
              keyExtractor={(n) => n.id}
              renderItem={(n) => (
                <ValeterNotificationListItem
                  item={n}
                  primary={primary}
                  formatRelativeTime={formatRelativeTime}
                  onPress={handleNotificationPress}
                  onDismiss={(id) => void removeNotification(id)}
                />
              )}
              empty={
                <View style={styles.filterEmpty}>
                  <Text style={styles.filterEmptyText}>Nothing here right now</Text>
                </View>
              }
            />
          </>
        ) : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { flex: 1, paddingHorizontal: 18 },
  loadingWrap: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  deleteAllButton: {
    paddingVertical: 8,
    paddingHorizontal: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  deleteAllText: { fontSize: 14, fontWeight: '700' },
  hero: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14, borderRadius: 22 },
  heroIcon: { width: 46, height: 46, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  heroCopy: { flex: 1, minWidth: 0 },
  heroCountRow: { flexDirection: 'row', alignItems: 'baseline', gap: 6 },
  heroCount: { color: '#F8FAFC', fontSize: 26, fontWeight: '900', fontVariant: ['tabular-nums'] },
  heroCountLabel: { color: 'rgba(226,232,240,0.85)', fontSize: 14, fontWeight: '700' },
  heroSubRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 2 },
  heroSub: { color: 'rgba(203,213,225,0.8)', fontSize: 12, fontWeight: '600' },
  refreshBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  segments: { marginTop: 12, marginBottom: 12 },
  rowPress: { flex: 1 },
  rowInactive: { opacity: 0.55 },
  row: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingLeft: 12,
    paddingRight: 8,
    borderRadius: 20,
  },
  rowIcon: { width: 44, height: 44, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  unreadBadge: {
    position: 'absolute',
    top: -4,
    right: -4,
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    paddingHorizontal: 4,
    alignItems: 'center',
    justifyContent: 'center',
  },
  unreadBadgeText: { color: '#0A1929', fontSize: 10, fontWeight: '900' },
  rowBody: { flex: 1, minWidth: 0, gap: 2 },
  rowTop: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  rowTitle: { flex: 1, color: '#F8FAFC', fontSize: 14, fontWeight: '800' },
  rowMessage: { color: 'rgba(203,213,225,0.8)', fontSize: 12, fontWeight: '500' },
  rowTime: { fontSize: 11, fontWeight: '700' },
  dismissBtn: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  filterEmpty: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  filterEmptyText: { color: 'rgba(203,213,225,0.7)', fontSize: 14, fontWeight: '600' },
});
