/**
 * Valeter "Get paid" page (Stripe Connect): status hero, how-it-works steps, account checks.
 */
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { View, Text, Image, StyleSheet, Linking, ActivityIndicator, ScrollView, RefreshControl } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useLocalSearchParams } from 'expo-router';
import Reanimated, { FadeIn, FadeInDown, ZoomIn } from 'react-native-reanimated';
import { ChromeGlyph as Ionicons } from '../../src/components/shared/ChromeGlyph';
import type { IconGlyphName } from '../../src/components/shared/iconGlyphTypes';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { stripeConnectService } from '../../src/services/stripeConnectService';
import {
  valeterStripeConnectService,
  type StripeConnectStatus,
  type ValeterStripeConnectStatus,
} from '../../src/services/valeterStripeConnectService';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import GlassSurface from '../../src/components/shared/GlassSurface';
import GlassOrb from '../../src/components/valeter/road/GlassOrb';
import { PressableScale, PulseDot, useValeterFitInsets } from '../../src/components/shared/fit/FitKit';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import LoadingScreen from '../../src/components/LoadingScreen';
import ContinueCTAButton from '../../src/components/ui/ContinueCTAButton';
import ValeterScreenHeader from '../../src/components/valeter/ValeterScreenHeader';
import { VALETER_CONTENT_BOTTOM_PAD } from '../../src/components/valeter/ValeterNavSidebar';
import { toast } from '../../src/components/shared/ToastHost';
import StripeStatusPill from '../../src/components/valeter/StripeStatusPill';

const GREEN = '#34D399';
const AMBER = '#FBBF24';
const RED = '#F87171';
const STRIPE_PURPLE = '#635BFF';

const STAGES = ['Connect', 'Verify', 'Ready'] as const;

const HOW_IT_WORKS: ReadonlyArray<{ icon: IconGlyphName; title: string; body: string }> = [
  { icon: 'link', title: 'Link your bank with Stripe', body: 'A secure 2-minute form, opened right from here' },
  { icon: 'shield-checkmark', title: 'Stripe verifies you', body: 'Usually instant, sometimes up to a day' },
  { icon: 'cash', title: 'Get paid for every job', body: 'Earnings land in your bank automatically' },
];

function stepIndexForStatus(status: StripeConnectStatus | undefined): number {
  switch (status) {
    case 'completed':
      return 3;
    case 'in_progress':
    case 'restricted':
    case 'rejected':
      return 2;
    case 'not_started':
    default:
      return 1;
  }
}

function shortenAccountId(id: string | null | undefined): string {
  if (!id || id.length < 12) return id || 'Not linked yet';
  return `${id.slice(0, 10)}…${id.slice(-4)}`;
}

function formatRelativeTimestamp(value: string | null | undefined): string {
  if (!value) return 'Not synced yet';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  const diffMs = Date.now() - date.getTime();
  const diffMinutes = Math.max(1, Math.round(diffMs / 60000));
  if (diffMinutes < 60) return `${diffMinutes}m ago`;
  const diffHours = Math.round(diffMinutes / 60);
  if (diffHours < 24) return `${diffHours}h ago`;
  return `${Math.round(diffHours / 24)}d ago`;
}

function stepColor(done: boolean, current: boolean, color: string, idle: string): string {
  if (done) return GREEN;
  if (current) return color;
  return idle;
}

function checkColor(ok: boolean | null | undefined): string {
  if (ok == null) return 'rgba(241,245,249,0.85)';
  return ok ? GREEN : AMBER;
}

function ctaAccent(isComplete: boolean, attention: boolean): string {
  if (isComplete) return GREEN;
  return attention ? RED : STRIPE_PURPLE;
}

function StepTrailing({
  done,
  current,
  color,
  attention,
}: Readonly<{ done: boolean; current: boolean; color: string; attention: boolean }>) {
  if (current) {
    return (
      <View style={[styles.nowPill, { backgroundColor: `${color}22`, borderColor: `${color}66` }]}>
        <Text style={[styles.nowPillText, { color }]}>{attention ? 'Fix' : 'Now'}</Text>
      </View>
    );
  }
  return done ? <Text style={styles.doneText}>Done</Text> : null;
}

function StageStrip({ activeStep, color }: Readonly<{ activeStep: number; color: string }>) {
  return (
    <View style={styles.stageStrip}>
      {STAGES.map((label, i) => {
        const n = i + 1;
        const done = n < activeStep || activeStep === STAGES.length;
        const current = n === activeStep && !done;
        const c = stepColor(done, current, color, 'rgba(248,250,252,0.4)');
        return (
          <View key={label} style={styles.stageItem}>
            <View style={[styles.stageBar, { backgroundColor: done || current ? c : 'rgba(248,250,252,0.12)' }]} />
            <View style={styles.stageLabelRow}>
              {current ? <PulseDot color={c} size={6} /> : null}
              {done ? <Ionicons name="checkmark" size={11} color={GREEN} /> : null}
              <Text style={[styles.stageLabel, { color: current || done ? c : 'rgba(248,250,252,0.4)' }, current && styles.stageLabelActive]}>
                {label}
              </Text>
            </View>
          </View>
        );
      })}
    </View>
  );
}

function CheckRow({
  label,
  value,
  ok,
  last,
}: Readonly<{ label: string; value: string; ok?: boolean | null; last?: boolean }>) {
  const color = checkColor(ok);
  return (
    <View style={[styles.checkRow, !last && styles.checkRowBorder]}>
      <Text style={styles.checkLabel}>{label}</Text>
      <View style={styles.checkValueWrap}>
        {ok != null ? <Ionicons name={ok ? 'checkmark-circle' : 'time'} size={14} color={color} /> : null}
        <Text style={[styles.checkValue, { color }]} numberOfLines={1}>
          {value}
        </Text>
      </View>
    </View>
  );
}

export default function ValeterStripeConnectScreen() {
  const { user, logout } = useAuth();
  const params = useLocalSearchParams();
  const insets = useSafeAreaInsets();
  const fit = useValeterFitInsets(10);
  const { theme } = useAccountTheme();
  const primary = theme.primary || '#9EC9E0';
  const textMain = theme.textPrimary || '#F8FAFC';
  const textMuted = theme.textOnBackground || 'rgba(248,250,252,0.66)';
  const isOnboardingMode = params?.mode === 'onboarding';
  const autoSyncAttemptedRef = useRef(false);
  const autoStartAttemptedRef = useRef(false);
  const syncInFlightRef = useRef(false);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [status, setStatus] = useState<ValeterStripeConnectStatus | null>(null);

  const load = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      const next = await valeterStripeConnectService.getStatus(user.id);
      setStatus(next);
    } catch (error: any) {
      toast.error(error?.message || 'Failed to load Stripe Connect status.', 'Unable to load your payout account');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, [user?.id]);

  useEffect(() => {
    if (!params?.stripe_return && !params?.stripe_refresh) return;
    void handleCheckStatus(true);
  }, [params?.stripe_return, params?.stripe_refresh]);

  const startConnect = async () => {
    if (saving || !user?.id) return;
    try {
      await hapticFeedback('light');
      setSaving(true);
      const onboardingLink = await stripeConnectService.createOnboardingLink();
      await valeterStripeConnectService.startStripeConnect(user.id);
      await Linking.openURL(onboardingLink.url);
    } catch (error: any) {
      toast.error(error?.message || 'Failed to start Stripe Connect.', 'Unable to open Stripe');
    } finally {
      setSaving(false);
    }
  };

  const reloadStatusQuietly = async () => {
    if (!user?.id) return;
    try {
      const next = await valeterStripeConnectService.getStatus(user.id);
      setStatus(next);
    } catch (error: any) {
      toast.error(error?.message || 'Failed to load Stripe Connect status.', 'Unable to load your payout account');
    }
  };

  const handleCheckStatus = async (silent = false) => {
    if (saving || syncInFlightRef.current || !user?.id) return;
    syncInFlightRef.current = true;
    try {
      await hapticFeedback('light');
      setRefreshing(true);
      const result = await stripeConnectService.syncStatusFromStripe();
      await valeterStripeConnectService.setStripeStatus(user.id, {
        stripeConnectStatus: result.stripeConnectStatus,
        stripeAccountId: result.stripeAccountId,
        stripeDetails: {
          detailsSubmitted: result.detailsSubmitted,
          chargesEnabled: result.chargesEnabled,
          payoutsEnabled: result.payoutsEnabled,
          updated_from_stripe_at: new Date().toISOString(),
        },
        stripeOnboardingCompletedAt:
          result.stripeConnectStatus === 'completed' ? new Date().toISOString() : undefined,
        stripeOnboardingStartedAt:
          result.stripeConnectStatus !== 'not_started' ? new Date().toISOString() : undefined,
      });
      await reloadStatusQuietly();
      if (result.stripeConnectStatus === 'completed') {
        await hapticFeedback('success');
        toast.success('Your Stripe payout account is ready.', 'Connected');
        return;
      }
      if (!silent && (result.stripeConnectStatus === 'restricted' || result.stripeConnectStatus === 'rejected')) {
        toast.error('Finish the remaining steps in Stripe, then refresh again.', 'Not ready yet');
      } else if (!silent) {
        toast.info('Stripe is still checking your details.', 'Status updated');
      }
    } catch (error: any) {
      toast.error(
        silent ? error?.message || 'Failed to check Stripe status.' : 'Finish the remaining steps in Stripe, then refresh again.',
        silent ? 'Unable to check Stripe status' : 'Not ready yet'
      );
    } finally {
      syncInFlightRef.current = false;
      setRefreshing(false);
    }
  };

  useEffect(() => {
    if (loading || saving || refreshing || autoSyncAttemptedRef.current) return;
    if (!status?.stripeAccountId || status.stripeConnectStatus === 'completed') return;
    autoSyncAttemptedRef.current = true;
    void handleCheckStatus(true);
  }, [loading, saving, refreshing, status?.stripeAccountId, status?.stripeConnectStatus]);

  /** Onboarding: open Stripe Express as soon as the screen is ready (don’t wait for a tap). */
  useEffect(() => {
    if (!isOnboardingMode || loading || saving || !user?.id) return;
    if (autoStartAttemptedRef.current) return;
    if (status?.stripeConnectStatus === 'completed') return;
    if (params?.stripe_return || params?.stripe_refresh) return;
    autoStartAttemptedRef.current = true;
    const t = setTimeout(() => {
      void startConnect();
    }, 450);
    return () => clearTimeout(t);
  }, [isOnboardingMode, loading, saving, user?.id, status?.stripeConnectStatus, params?.stripe_return, params?.stripe_refresh]);

  const handleLogout = async () => {
    if (saving) return;
    try {
      await hapticFeedback('medium');
      setSaving(true);
      await logout();
      router.replace('/auth/login');
    } catch (error: any) {
      toast.error(error?.message || 'Failed to log out.', 'Unable to log out');
    } finally {
      setSaving(false);
    }
  };

  const stripeState = status?.stripeConnectStatus ?? 'not_started';
  const activeStep = stepIndexForStatus(stripeState);
  const isComplete = stripeState === 'completed';
  const attention = stripeState === 'restricted' || stripeState === 'rejected';
  const hasStarted = stripeState !== 'not_started';

  const view = useMemo((): { kicker: string; title: string; body: string; icon: IconGlyphName; color: string } => {
    if (stripeState === 'completed') {
      return {
        kicker: 'READY',
        title: "You're ready to get paid",
        body: 'Your payout account is linked. Earnings from every job go straight to your bank.',
        icon: 'checkmark-circle',
        color: GREEN,
      };
    }
    if (stripeState === 'restricted') {
      return {
        kicker: 'ACTION NEEDED',
        title: 'Stripe needs a little more',
        body: 'Open Stripe to finish the remaining verification steps, then refresh here.',
        icon: 'alert-circle',
        color: RED,
      };
    }
    if (stripeState === 'rejected') {
      return {
        kicker: 'ACTION NEEDED',
        title: 'Stripe needs updated details',
        body: 'Review your information in Stripe, update what’s needed, then refresh here.',
        icon: 'alert-circle',
        color: RED,
      };
    }
    if (stripeState === 'in_progress') {
      return {
        kicker: 'VERIFYING',
        title: 'Stripe is checking your details',
        body: 'Finish any open steps in Stripe’s secure form, then come back and refresh.',
        icon: 'hourglass',
        color: AMBER,
      };
    }
    return {
      kicker: 'GET PAID',
      title: 'Link your payout account',
      body: 'Connect once with Stripe so Wish a Washer can pay you for every completed job.',
      icon: 'wallet',
      color: primary,
    };
  }, [primary, stripeState]);

  const primaryLabel = (() => {
    if (isComplete) return isOnboardingMode ? 'Continue to app' : 'Done';
    if (attention) return 'Fix in Stripe';
    if (stripeState === 'in_progress') return 'Finish in Stripe';
    return 'Connect with Stripe';
  })();

  const onPrimary = () => {
    if (isComplete) {
      if (isOnboardingMode) router.replace('/valeter/valeter-dashboard');
      else router.back();
      return;
    }
    void startConnect();
  };

  const stripeDetails = (status?.stripeDetails ?? {}) as Record<string, any>;
  const stripeSyncedAt =
    stripeDetails.updated_from_stripe_at ??
    stripeDetails.updated_from_stripe_webhook_at ??
    status?.stripeOnboardingCompletedAt ??
    status?.stripeOnboardingStartedAt ??
    null;

  if (loading) {
    return <LoadingScreen message="Loading your payout account…" />;
  }

  return (
    <View style={styles.flex}>
      <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <ValeterScreenHeader
        title="Get paid"
        rightAction={
          <View style={styles.headerActions}>
            <PressableScale
              onPress={() => void handleCheckStatus(false)}
              disabled={saving || refreshing}
              style={[styles.headerIconBtn, { borderColor: `${primary}40` }]}
              accessibilityLabel="Refresh Stripe status"
            >
              {refreshing ? (
                <ActivityIndicator size="small" color={textMain} />
              ) : (
                <Ionicons name="refresh-outline" size={18} color={textMain} />
              )}
            </PressableScale>
            {isOnboardingMode ? (
              <PressableScale
                onPress={() => void handleLogout()}
                style={[styles.logoutBtn, { borderColor: `${primary}40` }]}
                accessibilityLabel="Log out"
              >
                <Ionicons name="log-out-outline" size={16} color={textMain} />
                <Text style={[styles.logoutText, { color: textMain }]}>Log out</Text>
              </PressableScale>
            ) : null}
          </View>
        }
      />

      <ScrollView
        style={styles.flex}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[styles.content, { paddingTop: fit.top, paddingBottom: 16 }]}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={() => void handleCheckStatus(true)}
            tintColor={primary}
            colors={[primary]}
            progressBackgroundColor="rgba(15,30,48,0.9)"
          />
        }
      >
        <Reanimated.View entering={FadeInDown.springify().damping(18)}>
          <GlassSurface style={styles.hero} fallbackColor="rgba(10,25,41,0.6)">
            <LinearGradient
              colors={[`${view.color}33`, 'transparent']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={StyleSheet.absoluteFill}
              pointerEvents="none"
            />
            <View style={styles.heroTop}>
              <Reanimated.View key={view.icon} entering={ZoomIn.springify().damping(14)}>
                <GlassOrb icon={view.icon} accent={view.color} size={64} />
              </Reanimated.View>
              <View style={styles.heroCopy}>
                <View style={styles.kickerRow}>
                  <View style={[styles.kickerDot, { backgroundColor: view.color }]} />
                  <Text style={[styles.kicker, { color: view.color }]}>{view.kicker}</Text>
                  <View style={styles.flex} />
                  <StripeStatusPill status={stripeState} size="sm" />
                </View>
                <Text style={[styles.heroTitle, { color: textMain }]} numberOfLines={2}>
                  {view.title}
                </Text>
              </View>
            </View>
            <Text style={[styles.heroBody, { color: textMuted }]}>{view.body}</Text>
            <StageStrip activeStep={activeStep} color={view.color} />
            <View style={styles.poweredRow}>
              <Ionicons name="lock-closed" size={12} color="rgba(226,232,240,0.6)" />
              <Text style={styles.poweredText}>Secured by</Text>
              <View style={styles.stripeBadge}>
                <Image source={require('../../assets/stripe/img.png')} style={styles.stripeLogo} resizeMode="contain" />
              </View>
            </View>
          </GlassSurface>
        </Reanimated.View>

        {!isComplete ? (
          <>
            <Text style={styles.sectionLabel}>HOW IT WORKS</Text>
            <View style={styles.list}>
              {HOW_IT_WORKS.map((s, i) => {
                const done = i + 1 < activeStep;
                const current = i + 1 === activeStep;
                const c = stepColor(done, current, view.color, 'rgba(148,163,184,0.9)');
                return (
                  <Reanimated.View
                    key={s.title}
                    entering={FadeInDown.delay(80 + i * 60).springify().damping(18)}
                    style={[styles.stepRow, current && { borderColor: `${view.color}55` }]}
                  >
                    <View style={!done && !current ? styles.dim : undefined}>
                      <GlassOrb icon={done ? 'checkmark' : s.icon} accent={c} size={40} glow={false} />
                    </View>
                    <View style={styles.stepCopy}>
                      <Text style={[styles.stepTitle, { color: textMain }]} numberOfLines={1}>
                        {s.title}
                      </Text>
                      <Text style={styles.stepBody} numberOfLines={1}>
                        {s.body}
                      </Text>
                    </View>
                    <StepTrailing done={done} current={current} color={view.color} attention={attention} />
                  </Reanimated.View>
                );
              })}
            </View>
          </>
        ) : null}

        {hasStarted ? (
          <Reanimated.View entering={FadeInDown.delay(200).springify().damping(18)}>
            <Text style={styles.sectionLabel}>ACCOUNT</Text>
            <View style={styles.accountCard}>
              <CheckRow label="Stripe account" value={shortenAccountId(status?.stripeAccountId)} />
              <CheckRow
                label="Details submitted"
                value={stripeDetails.detailsSubmitted ? 'Yes' : 'Not yet'}
                ok={!!stripeDetails.detailsSubmitted}
              />
              <CheckRow
                label="Payouts"
                value={stripeDetails.payoutsEnabled ? 'Enabled' : 'Pending'}
                ok={!!stripeDetails.payoutsEnabled}
              />
              <CheckRow label="Last synced" value={formatRelativeTimestamp(stripeSyncedAt)} last />
            </View>
          </Reanimated.View>
        ) : null}

        <Reanimated.View entering={FadeIn.delay(380)} style={styles.trustRow}>
          <Ionicons name="shield-checkmark" size={13} color={GREEN} />
          <Text style={styles.trustText}>Your bank details go straight to Stripe. We never see them.</Text>
        </Reanimated.View>
      </ScrollView>

      <View style={[styles.footer, { paddingBottom: Math.max(12, insets.bottom) + VALETER_CONTENT_BOTTOM_PAD }]}>
        <ContinueCTAButton
          title={primaryLabel}
          onPress={onPrimary}
          accentColor={ctaAccent(isComplete, attention)}
          disabled={saving || refreshing}
          loading={saving}
          showTrailingChevron={!saving}
        />
        <PressableScale
          onPress={() => (isComplete ? void startConnect() : void handleCheckStatus(false))}
          disabled={saving || refreshing}
          style={styles.secondaryBtn}
          accessibilityLabel={isComplete ? 'Update Stripe details' : 'Refresh status'}
        >
          <Ionicons name={isComplete ? 'create-outline' : 'refresh-outline'} size={15} color={textMuted} />
          <Text style={[styles.secondaryText, { color: textMuted }]}>
            {isComplete ? 'Update Stripe details' : 'I’ve finished, refresh status'}
          </Text>
        </PressableScale>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  dim: { opacity: 0.5 },
  content: { flexGrow: 1, paddingHorizontal: 18, gap: 10 },

  headerActions: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  headerIconBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  logoutBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    height: 36,
    paddingHorizontal: 12,
    borderRadius: 18,
    borderWidth: 1,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  logoutText: { fontSize: 13, fontWeight: '800' },

  hero: { borderRadius: 24, paddingHorizontal: 16, paddingTop: 16, paddingBottom: 14, gap: 12, overflow: 'hidden' },
  heroTop: { flexDirection: 'row', alignItems: 'center', gap: 14 },
  heroCopy: { flex: 1, gap: 4 },
  kickerRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  kickerDot: { width: 6, height: 6, borderRadius: 3 },
  kicker: { fontSize: 11, fontWeight: '900', letterSpacing: 1.2 },
  heroTitle: { fontSize: 20, fontWeight: '900', letterSpacing: -0.3 },
  heroBody: { fontSize: 13, fontWeight: '600', lineHeight: 19 },

  stageStrip: { flexDirection: 'row', gap: 6 },
  stageItem: { flex: 1, gap: 6 },
  stageBar: { height: 4, borderRadius: 2 },
  stageLabelRow: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  stageLabel: { fontSize: 11, fontWeight: '700' },
  stageLabelActive: { fontWeight: '900' },

  poweredRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(248,250,252,0.14)',
    paddingTop: 10,
  },
  poweredText: { color: 'rgba(226,232,240,0.6)', fontSize: 12, fontWeight: '700' },
  stripeBadge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
    backgroundColor: 'rgba(255,255,255,0.92)',
  },
  stripeLogo: { width: 46, height: 16 },

  sectionLabel: {
    color: 'rgba(226,232,240,0.7)',
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 1.2,
    marginTop: 6,
    marginBottom: 2,
    paddingHorizontal: 4,
  },
  list: { gap: 8 },
  stepRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 12,
    paddingVertical: 11,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    backgroundColor: 'rgba(10,25,41,0.42)',
  },
  stepCopy: { flex: 1, minWidth: 0, gap: 2 },
  stepTitle: { fontSize: 15, fontWeight: '800' },
  stepBody: { color: 'rgba(226,232,240,0.6)', fontSize: 12, fontWeight: '600' },
  nowPill: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 999, borderWidth: 1 },
  nowPillText: { fontSize: 12, fontWeight: '900' },
  doneText: { color: GREEN, fontSize: 12, fontWeight: '800' },

  accountCard: {
    marginTop: 8,
    paddingHorizontal: 14,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    backgroundColor: 'rgba(10,25,41,0.42)',
  },
  checkRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 12, gap: 12 },
  checkRowBorder: { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: 'rgba(248,250,252,0.12)' },
  checkLabel: { color: 'rgba(226,232,240,0.65)', fontSize: 13, fontWeight: '700' },
  checkValueWrap: { flexDirection: 'row', alignItems: 'center', gap: 5, flexShrink: 1 },
  checkValue: { fontSize: 13, fontWeight: '800', fontVariant: ['tabular-nums'] },

  trustRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, marginTop: 8 },
  trustText: { color: 'rgba(226,232,240,0.55)', fontSize: 12, fontWeight: '600' },

  footer: { paddingHorizontal: 18, paddingTop: 8, gap: 2 },
  secondaryBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 10,
  },
  secondaryText: { fontSize: 13, fontWeight: '700' },
});
