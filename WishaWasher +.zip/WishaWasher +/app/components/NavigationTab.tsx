import React, { useMemo, useCallback, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { usePathname, useRouter, type Href } from 'expo-router';
import type { IconGlyphName } from '../../src/components/shared/iconGlyphTypes';
import { ChromeGlyph } from '../../src/components/shared/ChromeGlyph';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { getTextColors } from '../../src/constants/themeColors';
import { useGlobalTheme } from '../../src/components/shared/GlobalThemeContext';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { isBusinessRoutePath, normalizeUserType } from '../../src/utils/authRole';
import ValeterDashboardChrome from '../../src/components/valeter/ValeterDashboardChrome';

const { width } = Dimensions.get('window');

const TAB_BAR_HEIGHT = 64;
const BAR_MARGIN_H = 12;
const BAR_RADIUS = 26;
const BAR_PAD = 6;
const INDICATOR_INSET = 3;
const TABLET_BREAKPOINT = 768;
const TABLET_MAX_BAR_WIDTH = 560;

// Used by screens to pad content above the bar (DO NOT include safe area here)
const TAB_BAR_TOTAL_HEIGHT = 54;
export { TAB_BAR_TOTAL_HEIGHT };

interface Tab {
  name: string;
  icon: IconGlyphName;
  route: string;
}

const getTabs = (userType?: string): Tab[] => {
  if (userType === 'valeter') {
    return [];
  }

  if (userType === 'organization') {
    return [
      { name: 'Home', icon: 'home', route: '/business/dashboard' },
      { name: 'Locations', icon: 'location', route: '/business/locations' },
      { name: 'Bookings', icon: 'briefcase', route: '/business/bookings' },
      { name: 'Chat', icon: 'chatbubbles', route: '/business/inbox' },
      { name: 'Profile', icon: 'person', route: '/business/profile' },
    ];
  }
  return getTabs('valeter');
};

/** First matching rule wins; order matters (e.g. bookings/activity before bookings/). */
const ACTIVE_INDEX_RULES: ReadonlyArray<{
  pathMatches: (pathname: string) => boolean;
  tabMatches: (t: Tab) => boolean;
}> = [
  { pathMatches: (p) => p.includes('/business/dashboard'), tabMatches: (t) => t.route === '/business/dashboard' },
  { pathMatches: (p) => p.includes('/business/locations'), tabMatches: (t) => t.route === '/business/locations' },
  { pathMatches: (p) => p.includes('/business/bookings'), tabMatches: (t) => t.route === '/business/bookings' },
  { pathMatches: (p) => p.includes('/business/inbox'), tabMatches: (t) => t.route === '/business/inbox' },
  { pathMatches: (p) => p.includes('/business/team'), tabMatches: (t) => t.route === '/business/bookings' },
  { pathMatches: (p) => p.includes('/business/profile'), tabMatches: (t) => t.route === '/business/profile' },
  {
    pathMatches: (p) => p.includes('/business/settings'),
    tabMatches: (t) => t.route === '/business/profile',
  },
];

function firstTabIndex(tabs: Tab[], tabMatches: (t: Tab) => boolean): number {
  return Math.max(0, tabs.findIndex(tabMatches));
}

function getActiveIndex(pathname: string, tabs: Tab[]): number {
  for (const rule of ACTIVE_INDEX_RULES) {
    if (rule.pathMatches(pathname)) {
      return firstTabIndex(tabs, rule.tabMatches);
    }
  }

  for (let i = 0; i < tabs.length; i++) {
    const route = tabs[i].route;
    if (pathname === route || pathname.startsWith(`${route}/`)) {
      return i;
    }
  }

  return 0;
}

function resolveTabs(
  pathname: string,
  business: boolean,
  userType: 'customer' | 'valeter' | 'organization' | undefined
): Tab[] {
  const canonicalRole = normalizeUserType(userType, null);
  if (canonicalRole === 'organization' || business) {
    return getTabs('organization');
  }
  if (canonicalRole === 'valeter') {
    return getTabs('valeter');
  }
  if (pathname.includes('/valeter/')) {
    return getTabs('valeter');
  }
  if (pathname.includes('/business/')) {
    return getTabs('organization');
  }
  return getTabs(normalizeUserType(userType, null) === 'organization' ? 'organization' : 'valeter');
}

function computeHideTabBar(pathname: string): boolean {
  const hideRoutes = [
    '/auth/',
    '/onboarding',
    '/valeter/valeter-onboarding',
    '/valeter/terms',
    '/valeter/terms-blocked',
    '/valeter/dev-work',
    '/organisation/organization-onboarding',
    '/account-deletion',
    '/business/onboarding',
    '/business/terms',
    '/business/terms-blocked',
    '/business/stripe-connect',
    '/business/settings',
    '/business/dev-work',
  ];
  if (hideRoutes.some((route) => pathname.includes(route))) {
    return true;
  }

  const isBusinessLocationsDetail = pathname.startsWith('/business/locations/') && pathname !== '/business/locations';
  return isBusinessLocationsDetail;
}

type ThemeShape = ReturnType<typeof getAccountTheme>;

interface NavigationTabItemProps {
  tab: Tab;
  isActive: boolean;
  slotW: number;
  accent: string;
  activeLabel: string;
  inactiveLabel: string;
  router: { push: (href: Href) => void };
}

function NavigationTabItem({
  tab,
  isActive,
  slotW,
  accent,
  activeLabel,
  inactiveLabel,
  router,
}: Readonly<NavigationTabItemProps>) {
  const isProfile = tab.name === 'Profile';
  const lift = useRef(new Animated.Value(isActive ? 1 : 0)).current;

  useEffect(() => {
    Animated.spring(lift, {
      toValue: isActive ? 1 : 0,
      friction: 7,
      tension: 140,
      useNativeDriver: true,
    }).start();
  }, [isActive, lift]);

  const onPress = useCallback(async () => {
    if (isActive && !isProfile) {
      return;
    }
    await hapticFeedback('light');
    router.push((isProfile ? '/business/profile' : tab.route) as Href);
  }, [isActive, isProfile, router, tab.route]);

  const iconScale = lift.interpolate({ inputRange: [0, 1], outputRange: [1, 1.12] });
  const iconLift = lift.interpolate({ inputRange: [0, 1], outputRange: [0, -1] });

  return (
    <TouchableOpacity
      style={[styles.tab, { width: slotW }]}
      onPress={onPress}
      activeOpacity={isActive && !isProfile ? 1 : 0.8}
      disabled={isActive && !isProfile}
      accessibilityRole="tab"
      accessibilityLabel={tab.name}
      accessibilityState={{ selected: isActive }}
    >
      <Animated.View style={{ transform: [{ translateY: iconLift }, { scale: iconScale }] }}>
        <ChromeGlyph
          name={isActive ? tab.icon : (`${String(tab.icon)}-outline` as IconGlyphName)}
          size={21}
          color={isActive ? accent : inactiveLabel}
        />
      </Animated.View>
      <Text
        style={[
          styles.label,
          { color: isActive ? activeLabel : inactiveLabel },
          isActive && styles.labelActive,
        ]}
        numberOfLines={1}
        adjustsFontSizeToFit
        minimumFontScale={0.75}
      >
        {tab.name}
      </Text>
    </TouchableOpacity>
  );
}

export default function NavigationTab() {
  const pathname = usePathname();
  const router = useRouter();
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { mode } = useGlobalTheme();

  const isBusinessRoute = useMemo(() => isBusinessRoutePath(pathname), [pathname]);

  const currentTheme: ThemeShape = useMemo(() => {
    if (pathname.includes('/valeter/')) return getAccountTheme('valeter', mode);
    if (isBusinessRoute) return getAccountTheme('business', mode);
    return getAccountTheme('valeter', mode);
  }, [pathname, isBusinessRoute, mode]);

  const tabs = useMemo(
    () => resolveTabs(pathname, isBusinessRoute, user?.userType),
    [pathname, isBusinessRoute, user?.userType]
  );

  const activeIndex = useMemo(() => getActiveIndex(pathname, tabs), [pathname, tabs]);

  const accent = currentTheme?.primary || colors.navActive;

  const textColors = currentTheme
    ? getTextColors(currentTheme)
    : { primary: '#F9FAFB', secondary: 'rgba(255,255,255,0.8)' };

  const bg = currentTheme?.headerBackground || currentTheme?.background || ['#0A1929', '#0F2236'];
  const chromeGradient: readonly [string, string] = [bg[0], bg[1] ?? bg[0]];

  const fullWidth = width - BAR_MARGIN_H * 2;
  const barWidth =
    width >= TABLET_BREAKPOINT ? Math.min(fullWidth, TABLET_MAX_BAR_WIDTH) : fullWidth;
  const slotW = tabs.length > 0 ? (barWidth - BAR_PAD * 2) / tabs.length : 0;

  const indicatorX = useRef(new Animated.Value(activeIndex)).current;
  useEffect(() => {
    Animated.spring(indicatorX, {
      toValue: activeIndex,
      friction: 9,
      tension: 120,
      useNativeDriver: true,
    }).start();
  }, [activeIndex, indicatorX]);

  const shouldHideTab = useMemo(() => computeHideTabBar(pathname), [pathname]);
  const bottomPad = Math.max(insets.bottom - 6, 10);

  if (shouldHideTab || tabs.length === 0) {
    return null;
  }

  const translateX = indicatorX.interpolate({
    inputRange: [0, Math.max(1, tabs.length - 1)],
    outputRange: [0, Math.max(1, tabs.length - 1) * slotW],
  });

  return (
    <View pointerEvents="box-none" style={styles.screenWrap}>
      <View style={[styles.bar, { width: barWidth, marginBottom: bottomPad }]}>
        <View style={styles.chromeClip} pointerEvents="none">
          <ValeterDashboardChrome accent={accent} headerGradient={chromeGradient} />
          <LinearGradient colors={['rgba(255,255,255,0.10)', 'transparent']} style={styles.sheen} />
        </View>

        <Animated.View
          pointerEvents="none"
          style={[
            styles.indicator,
            {
              width: slotW - INDICATOR_INSET * 2,
              left: BAR_PAD + INDICATOR_INSET,
              backgroundColor: `${accent}1F`,
              borderColor: `${accent}55`,
              transform: [{ translateX }],
            },
          ]}
        >
          <View style={[styles.indicatorDot, { backgroundColor: accent, shadowColor: accent }]} />
        </Animated.View>

        <View style={[styles.row, { paddingHorizontal: BAR_PAD }]}>
          {tabs.map((tab, index) => (
            <NavigationTabItem
              key={tab.route}
              tab={tab}
              isActive={index === activeIndex}
              slotW={slotW}
              accent={accent}
              activeLabel={textColors.primary}
              inactiveLabel={textColors.secondary}
              router={router}
            />
          ))}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screenWrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: 'center',
    zIndex: 9999,
    elevation: 30,
  },
  bar: {
    height: TAB_BAR_HEIGHT,
    borderRadius: BAR_RADIUS,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.32,
    shadowRadius: 18,
    elevation: 18,
  },
  chromeClip: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    borderRadius: BAR_RADIUS - 1,
    overflow: 'hidden',
  },
  sheen: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: TAB_BAR_HEIGHT / 2,
  },
  indicator: {
    position: 'absolute',
    top: BAR_PAD,
    bottom: BAR_PAD,
    borderRadius: BAR_RADIUS - BAR_PAD,
    borderWidth: 1,
    alignItems: 'center',
  },
  indicatorDot: {
    position: 'absolute',
    bottom: 3,
    width: 4,
    height: 4,
    borderRadius: 2,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.9,
    shadowRadius: 4,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  tab: {
    height: TAB_BAR_HEIGHT - 2,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 3,
    paddingBottom: 4,
  },
  label: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.1,
    textAlign: 'center',
    width: '100%',
    paddingHorizontal: 2,
  },
  labelActive: {
    fontWeight: '900',
  },
});
