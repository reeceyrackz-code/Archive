import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  Alert,
  Animated,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../src/components/shared/ChromeGlyph';
import { useAuth } from '../src/providers/enhanced-auth-context';
import { normalizeUserType } from '../src/utils/authRole';
import { supabase } from '../src/lib/supabase';
import { hapticFeedback } from '../src/services/HapticFeedbackService';
import BubbleBackground from '../src/components/shared/BubbleBackground';
import LoadingScreen from '../src/components/LoadingScreen';
import AppHeader, { HEADER_HEIGHT } from '../src/components/shared/AppHeader';
import { useAccountTheme } from '../src/components/shared/AccountThemeProvider';
import { getAccountTheme } from '../src/constants/accountThemes';

type AccountDeletionRow = {
  id: string;
  user_id: string;
  user_type: string | null;
  email: string | null;
  account_name: string | null;
  reason?: string | null;
  notes?: string | null;
  created_at?: string | null;
};

const DELETION_WORKING_DAYS = 28;
const OTHER = 'Other';

const REASONS: Record<'valeter' | 'business', string[]> = {
  valeter: ['Not enough jobs', 'Fees too high', 'Switching platform', 'Taking a break', OTHER],
  business: ['Not enough bookings', 'Fees too high', 'Switching platform', 'Closing the business', OTHER],
};

function addWorkingDays(from: Date, days: number) {
  const d = new Date(from);
  let added = 0;
  while (added < days) {
    d.setDate(d.getDate() + 1);
    const wd = d.getDay();
    if (wd !== 0 && wd !== 6) added += 1;
  }
  return d;
}

function deletionDeadline(createdAt?: string | null) {
  const start = createdAt ? new Date(createdAt) : new Date();
  const base = Number.isNaN(start.getTime()) ? new Date() : start;
  return new Intl.DateTimeFormat('en-GB', { day: 'numeric', month: 'long' }).format(
    addWorkingDays(base, DELETION_WORKING_DAYS)
  );
}

export default function AccountDeletionScreen() {
  const { user, isLoading, authReady } = useAuth();
  const { theme } = useAccountTheme();
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const role = normalizeUserType(user?.userType, null);
  const accountType = role === 'organization' ? 'business' : 'valeter';
  const fallbackTheme = useMemo(
    () => getAccountTheme(accountType),
    [accountType]
  );

  const [loadingRequest, setLoadingRequest] = useState(true);
  const [existingRequest, setExistingRequest] = useState<AccountDeletionRow | null>(null);
  const [accountName, setAccountName] = useState<string>('');
  const [reason, setReason] = useState('');
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [retracting, setRetracting] = useState(false);
  const [reasonChoice, setReasonChoice] = useState<string | null>(null);

  const resolvedTheme = theme ?? fallbackTheme;

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 450,
      useNativeDriver: true,
    }).start();
  }, [fadeAnim]);

  useEffect(() => {
    if (!authReady || isLoading) return;
    if (!user) {
      router.replace('/auth/login');
    }
  }, [authReady, isLoading, user]);

  useEffect(() => {
    let alive = true;

    const loadRequest = async () => {
      if (!user || !role) {
        if (alive) setLoadingRequest(false);
        return;
      }

      setLoadingRequest(true);
      try {
        let resolvedName = (user.name || '').trim() || 'Account';

        if (role === 'organization' && user.organizationId) {
          const { data: orgRow } = await supabase
            .from('organizations')
            .select('name')
            .eq('id', user.organizationId)
            .maybeSingle();
          const orgName = (orgRow as { name?: string } | null)?.name?.trim();
          if (orgName) resolvedName = orgName;
        }

        const { data, error } = await supabase
          .from('account_deletions')
          .select('*')
          .eq('user_id', user.id)
          .eq('user_type', role)
          .order('created_at', { ascending: false })
          .limit(1)
          .maybeSingle();

        if (error) throw error;

        if (!alive) return;
        setAccountName(resolvedName);
        const row = (data as AccountDeletionRow | null) ?? null;
        setExistingRequest(row);
        setReason(row?.reason ?? '');
        setNotes(row?.notes ?? '');
      } catch (e) {
        console.error('[AccountDeletion] load error:', e);
        Alert.alert('Error', 'We could not load your account deletion request right now.');
      } finally {
        if (alive) setLoadingRequest(false);
      }
    };

    void loadRequest();

    return () => {
      alive = false;
    };
  }, [user?.id, user?.userType, user?.organizationId, role]);

  const canSubmit = reason.trim().length > 0 && !submitting;

  const handleSubmit = async () => {
    if (!user || !role || existingRequest || !canSubmit) return;

    try {
      setSubmitting(true);
      await hapticFeedback('light');

      const insertPayload = {
        user_id: user.id,
        user_type: role,
        email: user.email,
        account_name: accountName || user.name || 'Account',
        reason: reason.trim(),
        notes: notes.trim(),
      };

      const { data, error } = await supabase
        .from('account_deletions')
        .insert(insertPayload)
        .select('*')
        .maybeSingle();

      if (error) throw error;

      const inserted = (data as AccountDeletionRow | null) ?? {
        ...insertPayload,
        id: `${Date.now()}`,
        created_at: new Date().toISOString(),
      };
      setExistingRequest(inserted);
      setReason(inserted.reason ?? reason.trim());
      setNotes(inserted.notes ?? notes.trim());
      Alert.alert('Request sent', 'Your account deletion request has been received.');
    } catch (e: any) {
      console.error('[AccountDeletion] submit error:', e);
      Alert.alert('Error', e?.message || 'We could not send your deletion request.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleRetract = () => {
    if (!existingRequest?.id) return;

    Alert.alert(
      'Retract deletion request?',
      'This will remove your request from our system and keep your account active.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Retract request',
          style: 'destructive',
          onPress: async () => {
            try {
              setRetracting(true);
              await hapticFeedback('medium');
              const { error } = await supabase.from('account_deletions').delete().eq('id', existingRequest.id);
              if (error) throw error;
              setExistingRequest(null);
              setReason('');
              setNotes('');
            } catch (e: any) {
              console.error('[AccountDeletion] retract error:', e);
              Alert.alert('Error', e?.message || 'We could not retract your request.');
            } finally {
              setRetracting(false);
            }
          },
        },
      ]
    );
  };

  const pickReason = (choice: string) => {
    void hapticFeedback('light');
    setReasonChoice(choice);
    setReason(choice === OTHER ? '' : choice);
  };

  const confirmDelete = () => {
    if (!canSubmit) return;
    Alert.alert(
      'Delete your account?',
      `Your account and data will be permanently deleted within ${DELETION_WORKING_DAYS} working days.`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Delete', style: 'destructive', onPress: () => void handleSubmit() },
      ]
    );
  };

  if (!authReady || isLoading || loadingRequest) {
    return <LoadingScreen message="Loading account deletion…" />;
  }

  if (!user) {
    return <LoadingScreen message="Redirecting to login…" overlay={false} />;
  }

  const accent = resolvedTheme.primary;

  return (
    <View style={styles.container}>
      <LinearGradient colors={resolvedTheme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType={accountType} />

      <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
        <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
          <Animated.View style={[styles.page, { opacity: fadeAnim }]}>
            {existingRequest ? (
              <PendingBody createdAt={existingRequest.created_at} reason={existingRequest.reason} />
            ) : (
              <View style={styles.body}>
                <Text style={styles.title}>Close your account?</Text>
                <Text style={styles.lead}>
                  We'll settle any payouts and delete your data within {DELETION_WORKING_DAYS} working days.
                </Text>

                <Text style={styles.label}>Why are you leaving?</Text>
                <ReasonChips options={REASONS[accountType]} value={reasonChoice} accent={accent} onPick={pickReason} />
                {reasonChoice === OTHER ? (
                  <TextInput
                    value={reason}
                    onChangeText={setReason}
                    placeholder="Your reason"
                    placeholderTextColor="rgba(249,250,251,0.4)"
                    style={styles.input}
                    autoFocus
                  />
                ) : null}

                <TextInput
                  value={notes}
                  onChangeText={setNotes}
                  placeholder="Anything else? (optional)"
                  placeholderTextColor="rgba(249,250,251,0.4)"
                  style={[styles.input, styles.notes]}
                  multiline
                  maxLength={500}
                  textAlignVertical="top"
                />
              </View>
            )}

            <View style={styles.actions}>
              {existingRequest ? (
                <TouchableOpacity
                  onPress={handleRetract}
                  activeOpacity={0.9}
                  disabled={retracting}
                  style={[styles.primaryButton, retracting && styles.disabled]}
                >
                  {retracting ? (
                    <ActivityIndicator color="#04121F" />
                  ) : (
                    <Text style={styles.primaryText}>Keep my account</Text>
                  )}
                </TouchableOpacity>
              ) : (
                <>
                  <TouchableOpacity
                    onPress={confirmDelete}
                    activeOpacity={0.9}
                    disabled={!canSubmit}
                    style={[styles.dangerButton, !canSubmit && styles.disabled]}
                  >
                    {submitting ? (
                      <ActivityIndicator color="#FFFFFF" />
                    ) : (
                      <Text style={styles.dangerText}>Delete my account</Text>
                    )}
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => router.back()} activeOpacity={0.8} style={styles.linkButton}>
                    <Text style={[styles.linkText, { color: accent }]}>Keep my account</Text>
                  </TouchableOpacity>
                </>
              )}
            </View>
          </Animated.View>
        </KeyboardAvoidingView>
        <AppHeader title="Close account" accountType={accountType} />
      </SafeAreaView>
    </View>
  );
}

function PendingBody({ createdAt, reason }: Readonly<{ createdAt?: string | null; reason?: string | null }>) {
  return (
    <View style={styles.body}>
      <View style={styles.pendingBadge}>
        <Ionicons name="hourglass-outline" size={13} color="#FBBF24" />
        <Text style={styles.pendingText}>Deletion pending</Text>
      </View>
      <Text style={styles.title}>We've got your request</Text>
      <Text style={styles.lead}>
        Your account will be deleted by {deletionDeadline(createdAt)}. Until then it stays active and you can still
        change your mind.
      </Text>
      {reason ? <Text style={styles.reasonLine}>Reason: {reason}</Text> : null}
    </View>
  );
}

function ReasonChips({
  options,
  value,
  accent,
  onPick,
}: Readonly<{ options: string[]; value: string | null; accent: string; onPick: (choice: string) => void }>) {
  return (
    <View style={styles.chips}>
      {options.map((r) => {
        const on = value === r;
        return (
          <TouchableOpacity
            key={r}
            onPress={() => onPick(r)}
            activeOpacity={0.85}
            style={[styles.chip, on && { backgroundColor: `${accent}26`, borderColor: accent }]}
            accessibilityRole="radio"
            accessibilityState={{ selected: on }}
          >
            <Text style={[styles.chipText, on && styles.chipTextOn]}>{r}</Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  flex: { flex: 1 },
  page: {
    flex: 1,
    justifyContent: 'space-between',
    paddingHorizontal: 22,
    paddingTop: HEADER_HEIGHT + 12,
    paddingBottom: 12,
  },
  body: { gap: 10 },
  title: { color: '#F9FAFB', fontSize: 26, fontWeight: '900', letterSpacing: -0.5 },
  lead: { color: 'rgba(249,250,251,0.7)', fontSize: 14.5, lineHeight: 21 },
  label: { color: '#F9FAFB', fontSize: 14, fontWeight: '800', marginTop: 14 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: {
    paddingHorizontal: 14,
    paddingVertical: 9,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  chipText: { color: 'rgba(249,250,251,0.78)', fontSize: 13.5, fontWeight: '700' },
  chipTextOn: { color: '#F9FAFB' },
  input: {
    marginTop: 6,
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 12,
    color: '#F9FAFB',
    backgroundColor: 'rgba(2,6,23,0.35)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    fontSize: 14,
    fontWeight: '600',
  },
  notes: { minHeight: 76 },
  pendingBadge: {
    alignSelf: 'flex-start',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 999,
    backgroundColor: 'rgba(251,191,36,0.14)',
    borderWidth: 1,
    borderColor: 'rgba(251,191,36,0.35)',
    marginBottom: 4,
  },
  pendingText: { color: '#FBBF24', fontSize: 12, fontWeight: '800' },
  reasonLine: { color: 'rgba(249,250,251,0.55)', fontSize: 13, fontWeight: '600', marginTop: 4 },
  actions: { gap: 4 },
  dangerButton: {
    height: 54,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#DC2626',
  },
  dangerText: { color: '#FFFFFF', fontSize: 15.5, fontWeight: '800' },
  primaryButton: {
    height: 54,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F9FAFB',
  },
  primaryText: { color: '#04121F', fontSize: 15.5, fontWeight: '800' },
  disabled: { opacity: 0.45 },
  linkButton: { alignItems: 'center', paddingVertical: 12 },
  linkText: { fontSize: 15, fontWeight: '800' },
});
