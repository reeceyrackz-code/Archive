import React, { useEffect, useRef, useState } from 'react';
import { TextInput, Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { router, useLocalSearchParams } from 'expo-router';
import * as AppleAuthentication from 'expo-apple-authentication';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { supabase } from '../../src/lib/supabase';
import AuthGateShell from '../../src/components/auth/AuthGateShell';
import ForgotPasswordSheet from '../../src/components/auth/ForgotPasswordSheet';
import { AuthCta, AuthField, AuthLink, AuthNotice } from '../../src/components/auth/AuthKit';
import { toast } from '../../src/components/shared/ToastHost';
import {
  isValeterRole,
  isCustomerRole,
  isOrganizationRole,
  normalizeUserType,
} from '../../src/utils/authRole';

export default function LoginScreen() {
  const { login, logout, loginWithApple, loginWithGoogle } = useAuth();
  const params = useLocalSearchParams<{ forgot?: string; email?: string; signin?: string }>();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [emailSheetOpen, setEmailSheetOpen] = useState(false);
  const [forgotSheetOpen, setForgotSheetOpen] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const passwordRef = useRef<TextInput>(null);

  const finishRouting = () => {
    router.replace('/');
  };

  useEffect(() => {
    if (params.forgot === '1' || params.forgot === 'true') {
      if (typeof params.email === 'string' && params.email.includes('@')) {
        setEmail(params.email);
      }
      setEmailSheetOpen(false);
      setForgotSheetOpen(true);
    }
  }, [params.forgot, params.email]);

  useEffect(() => {
    if (params.signin) {
      setFormError(null);
      setEmailSheetOpen(true);
    }
  }, [params.signin]);

  const openSignInSheet = () => {
    void hapticFeedback('light');
    setFormError(null);
    setEmailSheetOpen(true);
  };

  const getEffectiveRole = async (): Promise<{ role: string; isRestricted: boolean }> => {
    const { data: authData, error: authErr } = await supabase.auth.getUser();
    if (authErr) throw authErr;
    const sbUser = authData?.user;
    if (!sbUser?.id) return { role: '', isRestricted: false };
    const { data: profile, error: profErr } = await supabase
      .from('profiles')
      .select('user_type, is_restricted')
      .eq('id', sbUser.id)
      .maybeSingle();
    if (profErr) throw profErr;
    return {
      role: normalizeUserType(profile?.user_type ?? (sbUser.user_metadata as any)?.userType, null) ?? '',
      isRestricted: !!profile?.is_restricted,
    };
  };

  const rejectRestricted = async () => {
    await safeLogout();
    Alert.alert(
      'Account Restricted',
      'Your account has been restricted. Please contact support if you believe this is a mistake.'
    );
  };

  const safeLogout = async () => {
    try {
      if (typeof logout === 'function') await logout();
      else await supabase.auth.signOut();
    } catch {}
  };

  const rejectNonValeter = async (role: string) => {
    await safeLogout();
    if (isCustomerRole(role)) {
      Alert.alert(
        'Owner account',
        'This app is for Wish a Washer CCP accounts only. Owner/customer accounts can’t sign in here.'
      );
      return;
    }
    if (isOrganizationRole(role)) {
      Alert.alert(
        'Business account',
        'This sign-in is for CCP accounts. Use the business app for organization accounts.'
      );
      return;
    }
    Alert.alert(
      'Not a CCP account',
      'This app is for Wish a Washer CCP accounts only. Sign in with a CCP account.'
    );
  };

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
      setFormError('Enter your email and password to continue.');
      await hapticFeedback('error');
      return;
    }
    await hapticFeedback('medium');
    setFormError(null);
    setIsLoading(true);
    try {
      const ok = await login(email.trim(), password);
      if (!ok) {
        await hapticFeedback('error');
        setFormError(
          'That email and password don’t match. Just signed up? Verify your email first, then sign in.'
        );
        return;
      }

      const { role, isRestricted } = await getEffectiveRole();
      if (isRestricted) {
        setEmailSheetOpen(false);
        await rejectRestricted();
        return;
      }
      if (!isValeterRole(role)) {
        setEmailSheetOpen(false);
        await rejectNonValeter(role);
        return;
      }

      setEmailSheetOpen(false);
      finishRouting();
    } catch (e: any) {
      await hapticFeedback('error');
      setFormError(e?.message || 'Something went wrong. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAppleLogin = async () => {
    try {
      await hapticFeedback('light');
      const credential = await AppleAuthentication.signInAsync({
        requestedScopes: [
          AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
          AppleAuthentication.AppleAuthenticationScope.EMAIL,
        ],
      });
      if (typeof loginWithApple === 'function') {
        const ok = await loginWithApple(credential);
        if (!ok) {
          toast.error('Could not authenticate with Apple.', 'Apple sign in failed');
          return;
        }
      } else if (credential?.identityToken) {
        await AsyncStorage.setItem('appleIdentityToken', credential.identityToken);
      }

      const { role, isRestricted } = await getEffectiveRole();
      if (isRestricted) {
        await rejectRestricted();
        return;
      }
      if (!isValeterRole(role)) {
        await rejectNonValeter(role);
        return;
      }
      finishRouting();
    } catch (error: any) {
      if (error?.code === 'ERR_CANCELED') return;
      toast.error(error?.message || 'Please try again.', 'Apple sign in failed');
    }
  };

  const handleGoogleLogin = async () => {
    try {
      await hapticFeedback('light');
      const ok = await loginWithGoogle();
      if (!ok) {
        toast.error('Please try again.', 'Google sign in failed');
        return;
      }
      const { role, isRestricted } = await getEffectiveRole();
      if (isRestricted) {
        await rejectRestricted();
        return;
      }
      if (!isValeterRole(role)) {
        await rejectNonValeter(role);
        return;
      }
      finishRouting();
    } catch (error: any) {
      if (error?.message !== 'oauth_redirect_timeout') {
        toast.error(error?.message || 'Please try again.', 'Google sign in failed');
      }
    }
  };

  const handleForgotPassword = async () => {
    await hapticFeedback('light');
    setEmailSheetOpen(false);
    setTimeout(() => setForgotSheetOpen(true), 280);
  };

  const canSubmit = email.trim().length > 0 && password.length > 0;

  return (
    <>
      <AuthGateShell
        mode="login"
        tagline="Earn on your schedule."
        emailSheetTitle="Welcome back"
        emailSheetSubtitle="Sign in with the email on your Car Care Pro account."
        emailSheetOpen={emailSheetOpen}
        onOpenEmailSheet={openSignInSheet}
        onCloseEmailSheet={() => setEmailSheetOpen(false)}
        altLink={{
          prompt: 'New here?',
          label: 'Sign up with email',
          onPress: () => router.push('/auth/create-account' as any),
        }}
        onApple={handleAppleLogin}
        onGoogle={handleGoogleLogin}
        loading={isLoading}
        emailSheetChildren={
          <>
            <AuthField
              icon="mail-outline"
              placeholder="Email address"
              value={email}
              onChangeText={(v) => {
                setEmail(v);
                if (formError) setFormError(null);
              }}
              autoCapitalize="none"
              autoCorrect={false}
              keyboardType="email-address"
              autoComplete="email"
              textContentType="username"
              returnKeyType="next"
              submitBehavior="submit"
              onSubmitEditing={() => passwordRef.current?.focus()}
              invalid={!!formError && !email.trim()}
            />
            <AuthField
              ref={passwordRef}
              icon="lock-closed-outline"
              password
              placeholder="Password"
              value={password}
              onChangeText={(v) => {
                setPassword(v);
                if (formError) setFormError(null);
              }}
              autoCapitalize="none"
              autoCorrect={false}
              autoComplete="current-password"
              textContentType="password"
              returnKeyType="go"
              onSubmitEditing={() => void handleLogin()}
              invalid={!!formError && !password}
            />

            <AuthLink label="Forgot password?" onPress={() => void handleForgotPassword()} align="flex-end" />

            <AuthNotice message={formError} />

            <AuthCta
              title="Sign in"
              onPress={() => void handleLogin()}
              loading={isLoading}
              disabled={!canSubmit}
              style={{ marginTop: 8 }}
            />
          </>
        }
      />
      <ForgotPasswordSheet
        visible={forgotSheetOpen}
        initialEmail={email}
        onClose={() => setForgotSheetOpen(false)}
        onBackToSignIn={() => {
          setForgotSheetOpen(false);
          setTimeout(() => setEmailSheetOpen(true), 280);
        }}
      />
    </>
  );
}
