import React from 'react';
import { router } from 'expo-router';
import ProSetupWizard from '../../src/components/valeter/onboarding/ProSetupWizard';

export default function CreateAccountScreen() {
  return (
    <ProSetupWizard
      signup
      version="v1.0"
      continuePath="/valeter/stripe-connect?mode=onboarding"
      blockedPath="/valeter/terms-blocked"
      onClose={() => (router.canGoBack() ? router.back() : router.replace('/auth/login'))}
      onSignIn={() => router.navigate({ pathname: '/auth/login', params: { signin: String(Date.now()) } } as any)}
    />
  );
}
