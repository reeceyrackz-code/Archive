import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  ActivityIndicator,
  Platform,
  StatusBar,
  KeyboardAvoidingView,
  ScrollView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { router, useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons as BrandGlyph } from '@expo/vector-icons';
import Animated, { FadeIn, FadeInDown, ZoomIn } from 'react-native-reanimated';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import LoopingBackgroundVideo from '../../src/components/shared/LoopingBackgroundVideo';
import { AUTH_GRADIENT_COLORS } from '../../src/constants/authStyles';
import { AUTH_PAGES_VIDEO } from '../../assets/authExports';
import { supabase } from '../../src/lib/supabase';
import { AUTH_BRAND, AuthCta, AuthField, AuthNotice, PasswordStrength } from '../../src/components/auth/AuthKit';

function resetHeaderCopy(
  bootError: string | null,
  done: boolean
): { title: string; subtitle: string; icon: React.ComponentProps<typeof BrandGlyph>['name'] } {
  if (bootError) {
    return { title: 'Link expired', subtitle: bootError, icon: 'time-outline' };
  }
  if (done) {
    return {
      title: 'Password updated',
      subtitle: 'You’re all set. Sign in with your new password.',
      icon: 'checkmark-circle-outline',
    };
  }
  return {
    title: 'Choose a new password',
    subtitle: 'Enter a new password for your CCP account, then sign in again.',
    icon: 'lock-closed-outline',
  };
}

export default function ResetPasswordScreen() {
  const insets = useSafeAreaInsets();
  const { updatePassword, logout } = useAuth();
  const params = useLocalSearchParams();

  const [ready, setReady] = useState(false);
  const [bootError, setBootError] = useState<string | null>(null);
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const confirmRef = useRef<TextInput>(null);

  useEffect(() => {
    let cancelled = false;

    const boot = async () => {
      try {
        const code = typeof params.code === 'string' ? params.code : null;
        if (code) {
          const { error: exchangeError } = await supabase.auth.exchangeCodeForSession(code);
          if (exchangeError) throw exchangeError;
        }

        const { data } = await supabase.auth.getSession();
        if (!data.session) {
          throw new Error('Reset link expired or invalid. Request a new one from sign in.');
        }
        if (!cancelled) setReady(true);
      } catch (e: any) {
        if (!cancelled) {
          setBootError(e?.message || 'Unable to open password reset.');
        }
      }
    };

    void boot();
    return () => {
      cancelled = true;
    };
  }, [params.code]);

  const handleSave = async () => {
    await hapticFeedback('medium');
    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    if (password !== confirm) {
      setError('Passwords don’t match.');
      return;
    }
    setError(null);
    setSaving(true);
    try {
      await updatePassword('', password);
      await hapticFeedback('success');
      try {
        if (typeof logout === 'function') await logout();
        else await supabase.auth.signOut();
      } catch {
        /* continue to login */
      }
      setDone(true);
    } catch (e: any) {
      setError(e?.message || 'Couldn’t update password. Try the reset link again.');
    } finally {
      setSaving(false);
    }
  };

  const matches = confirm.length > 0 && confirm === password;

  const { title, subtitle, icon } = resetHeaderCopy(bootError, done);

  return (
    <View style={styles.root}>
      <StatusBar translucent backgroundColor="transparent" barStyle="light-content" />
      <LoopingBackgroundVideo source={AUTH_PAGES_VIDEO} />
      <LinearGradient colors={[...AUTH_GRADIENT_COLORS]} style={StyleSheet.absoluteFill} pointerEvents="none" />
      <LinearGradient
        colors={['rgba(12,42,72,0.35)', 'rgba(6,22,40,0.72)', 'rgba(3,12,24,0.97)']}
        locations={[0.18, 0.52, 1]}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />

      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView
          contentContainerStyle={[
            styles.scroll,
            { paddingTop: insets.top + 16, paddingBottom: Math.max(insets.bottom, 20) + 16 },
          ]}
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode="interactive"
          showsVerticalScrollIndicator={false}
        >
          <Animated.View entering={FadeInDown.springify().damping(18)} style={styles.card}>
            <BlurView
              intensity={Platform.OS === 'ios' ? 40 : 24}
              tint="dark"
              style={StyleSheet.absoluteFill}
              {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
            />
            <View style={styles.cardTint} pointerEvents="none" />
            <LinearGradient
              colors={[done ? 'rgba(74,222,128,0.2)' : 'rgba(158,201,224,0.22)', 'transparent']}
              style={styles.cardGlow}
              pointerEvents="none"
            />

            <View style={styles.cardContent}>
              <Animated.View key={icon} entering={ZoomIn.springify().damping(14)} style={[styles.badge, done && styles.badgeDone]}>
                <BrandGlyph name={icon} size={26} color={done ? '#4ADE80' : '#F8FAFC'} />
              </Animated.View>
              <Text style={styles.eyebrow}>CAR CARE PRO</Text>
              <Text style={styles.title}>{title}</Text>
              <Text style={styles.subtitle}>{subtitle}</Text>

              {!ready && !bootError ? (
                <View style={styles.loadingWrap}>
                  <ActivityIndicator color={AUTH_BRAND} />
                  <Text style={styles.loadingText}>Opening secure reset…</Text>
                </View>
              ) : null}

              {bootError || done ? (
                <Animated.View entering={FadeIn.duration(200)}>
                  <AuthCta
                    title={done ? 'Sign in' : 'Back to sign in'}
                    onPress={() => router.replace('/auth/login')}
                  />
                </Animated.View>
              ) : null}

              {ready && !done ? (
                <Animated.View entering={FadeIn.duration(200)}>
                  <AuthField
                    icon="lock-closed-outline"
                    password
                    placeholder="New password"
                    value={password}
                    onChangeText={(v) => {
                      setPassword(v);
                      if (error) setError(null);
                    }}
                    autoCapitalize="none"
                    autoCorrect={false}
                    autoComplete="new-password"
                    textContentType="newPassword"
                    passwordRules="minlength: 6;"
                    autoFocus
                    returnKeyType="next"
                    submitBehavior="submit"
                    onSubmitEditing={() => confirmRef.current?.focus()}
                    invalid={!!error && password.length < 6}
                  />
                  <PasswordStrength password={password} />
                  <AuthField
                    ref={confirmRef}
                    icon="shield-checkmark-outline"
                    password
                    placeholder="Confirm new password"
                    value={confirm}
                    onChangeText={(v) => {
                      setConfirm(v);
                      if (error) setError(null);
                    }}
                    autoCapitalize="none"
                    autoCorrect={false}
                    autoComplete="new-password"
                    textContentType="newPassword"
                    returnKeyType="done"
                    onSubmitEditing={() => void handleSave()}
                    invalid={!!error && password.length >= 6 && !matches}
                    valid={matches && password.length >= 6}
                  />

                  <AuthNotice message={error} />

                  <AuthCta
                    title="Save new password"
                    icon="checkmark"
                    onPress={() => void handleSave()}
                    loading={saving}
                    disabled={!password || !confirm}
                    style={styles.cta}
                  />
                </Animated.View>
              ) : null}
            </View>
          </Animated.View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#061525' },
  flex: { flex: 1 },
  scroll: {
    flexGrow: 1,
    paddingHorizontal: 18,
    justifyContent: 'flex-end',
  },
  card: {
    borderRadius: 30,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    backgroundColor: 'rgba(8,24,40,0.6)',
  },
  cardTint: {
    ...StyleSheet.absoluteFill,
    backgroundColor: 'rgba(20,70,110,0.22)',
  },
  cardGlow: { position: 'absolute', left: 0, right: 0, top: 0, height: 160 },
  cardContent: {
    paddingHorizontal: 22,
    paddingTop: 24,
    paddingBottom: 24,
  },
  badge: {
    width: 56,
    height: 56,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'rgba(158,201,224,0.45)',
    backgroundColor: 'rgba(158,201,224,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 14,
  },
  badgeDone: {
    borderColor: 'rgba(74,222,128,0.5)',
    backgroundColor: 'rgba(74,222,128,0.16)',
  },
  eyebrow: { color: AUTH_BRAND, fontSize: 10.5, fontWeight: '800', letterSpacing: 1.3, marginBottom: 2 },
  title: {
    color: '#F8FAFC',
    fontSize: 26,
    fontWeight: '900',
    letterSpacing: -0.4,
    marginBottom: 8,
  },
  subtitle: {
    color: 'rgba(226,240,250,0.72)',
    fontSize: 14,
    lineHeight: 20,
    fontWeight: '600',
    marginBottom: 20,
  },
  loadingWrap: {
    alignItems: 'center',
    gap: 12,
    paddingVertical: 28,
  },
  loadingText: {
    color: 'rgba(226,240,250,0.7)',
    fontSize: 14,
    fontWeight: '600',
  },
  cta: { marginTop: 6 },
});
