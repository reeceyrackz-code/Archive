import React from 'react';
import { router } from 'expo-router';
import * as AppleAuthentication from 'expo-apple-authentication';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AuthGateShell from '../../src/components/auth/AuthGateShell';
import { toast } from '../../src/components/shared/ToastHost';

const VALETER_USER_TYPE = 'valeter' as const;

export default function SignupScreen() {
  const { registerWithApple, registerWithGoogle } = useAuth();

  const handleAppleSignup = async () => {
    try {
      await hapticFeedback('light');
      const cred = await AppleAuthentication.signInAsync({
        requestedScopes: [
          AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
          AppleAuthentication.AppleAuthenticationScope.EMAIL,
        ],
      });

      if (typeof registerWithApple === 'function') {
        const ok = await registerWithApple(cred, { userType: VALETER_USER_TYPE });
        if (!ok) {
          toast.error('Could not create your account with Apple.', 'Apple sign up failed');
          return;
        }
      } else {
        toast.info('Apple sign up needs to be wired to your backend via registerWithApple.', 'Apple sign up');
        return;
      }
      router.replace('/');
    } catch (error: any) {
      if (error?.code === 'ERR_CANCELED') return;
      toast.error(error?.message || 'Please try again.', 'Apple sign up failed');
    }
  };

  const handleGoogleSignup = async () => {
    try {
      await hapticFeedback('light');
      const ok = await registerWithGoogle({ userType: VALETER_USER_TYPE });
      if (!ok) {
        toast.error('Please try again.', 'Google sign up failed');
        return;
      }
      router.replace('/');
    } catch (error: any) {
      if (error?.message !== 'oauth_redirect_timeout') {
        toast.error(error?.message || 'Please try again.', 'Google sign up failed');
      }
    }
  };

  return (
    <AuthGateShell
      mode="signup"
      tagline="Join as a Car Care Pro and earn on your schedule."
      emailSheetTitle="Create your account"
      emailSheetOpen={false}
      onOpenEmailSheet={() => {
        void hapticFeedback('light');
        router.push('/auth/create-account' as any);
      }}
      onCloseEmailSheet={() => {}}
      onApple={handleAppleSignup}
      onGoogle={handleGoogleSignup}
      emailSheetChildren={null}
    />
  );
}
