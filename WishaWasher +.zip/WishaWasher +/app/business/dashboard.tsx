import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  Alert,
  Image,
  Platform,
  Modal,
  Pressable,
} from 'react-native';
import type { BusinessDashboardJobRow } from '../../src/services/BusinessBookingsService';
import { getServiceDisplayName } from '../../src/utils/serviceNameMapper';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import GradientIconBox, { LocationStyleIconBox } from '../../src/components/shared/GradientIconBox';
import { ChromeGlyph as Ionicons } from '../../src/components/shared/ChromeGlyph';
import { Ionicons as RawIonicons } from '@expo/vector-icons';
import MapView, { Marker } from 'react-native-maps';
import AnimatedProgress from '../../src/components/booking/AnimatedProgress';
import { getStatusProgress, getRingColorForStep, getActiveBookingStatusLabel } from '../../src/utils/trackingStatusHelpers';
import { CONTINUE_CTA_ICON_NAME } from '../../src/utils/bookingContinueStyle';
import { accentToGradient } from '../../src/utils/accentGradient';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import {
  fetchBusinessNotificationFeed,
  DROPDOWN_FEED_DEFAULTS,
} from '../../src/services/businessNotificationsFeed';
import { loadDismissedBusinessNotificationIds } from '../../src/services/businessNotificationDismissals';
import AppHeader, { DASHBOARD_HEADER_HEIGHT } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import { DashboardGlassSection } from '../../src/components/shared/DashboardGlassSection';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import BusinessNotificationDropdown from '../../src/components/shared/BusinessNotificationDropdown';
import GradientNotificationBell from '../../src/components/shared/GradientNotificationBell';
import { colors } from '../../src/constants/colors';
import { MAP_LOCKED_DARK } from '../../src/constants/mapConstants';
import { SCREEN_PADDING_H, SECTION_GAP } from '../../src/constants/premiumTokens';
import { HEADER_STYLE_CARD_GRADIENT, BOOKING_SHEET_DARK_OVERLAY, BUSINESS_SHEET_CARD } from '../../src/constants/bookingCardTheme';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import BusinessSheetBackground from '../../src/components/shared/BusinessSheetBackground';
import { textStyles } from '../../src/constants/typography';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';
import ActiveBookingsSheet from '../../src/components/business/ActiveBookingsSheet';
import LoadingScreen from '../../src/components/LoadingScreen';
import StatusBadge from '../../src/components/booking/StatusBadge';
import { canOpenLiveTracking } from '../../src/utils/businessBookingAccess';
import {
  loadDismissedRecentJobIds,
} from '../../src/services/dashboardRecentJobsDismissals';
import { canBusinessUseBookingChat } from '../../src/services/bookingCustomerChatAccess';
import { getLocationOpenBlockReasons } from '../../src/utils/locationOpenValidation';

function getStatusRingColor(status: string): string {
  return getRingColorForStep(status as any);
}

function isBusinessDashboardUpcomingRow(b: { scheduled_at?: string | null; status?: string }) {
  const now = Date.now();
  if (!b.scheduled_at) return false;
  if (new Date(b.scheduled_at).getTime() <= now) return false;
  const s = String(b.status);
  return !['completed', 'cancelled', 'valeter_timeout'].includes(s);
}

type BusinessDashboardJobUi = BusinessDashboardJobRow & { _type: 'upcoming' | 'recent' };

function formatBusinessJobVehicle(row: BusinessDashboardJobRow): string | null {
  const info = typeof row.vehicle_info === 'string' ? row.vehicle_info.trim() : '';
  if (info) return info;
  const makeModel = [row.vehicle_make, row.vehicle_model].filter(Boolean).join(' ').trim();
  if (makeModel) return makeModel;
  const reg = row.vehicle_registration?.trim();
  if (reg) return reg;
  return null;
}

function getBookingStatusProgress(status: string): number {
  return getStatusProgress(status as any);
}

function getJobSheetStatusLabel(job: BusinessDashboardJobUi): string {
  if (job._type === 'upcoming') return 'Upcoming';
  if (job.status === 'completed') return 'Completed';
  if (job.status === 'in_progress') return 'Active';
  return 'Confirmed';
}

function getPresenceSubtitle(applyingScope: boolean, anyLocationOpen: boolean): string {
  if (applyingScope) return 'Updating locations…';
  return anyLocationOpen ? 'Locations open for bookings' : 'Locations closed for bookings';
}

function getLocationCardGradient(isClosed: boolean, isActive: boolean): [string, string] {
  if (isClosed) return ['rgba(239,68,68,0.1)', 'rgba(239,68,68,0.05)'];
  if (isActive) return ['rgba(16,185,129,0.08)', 'rgba(16,185,129,0.02)'];
  return ['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.02)'];
}

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
/** Static primary for StyleSheet only (avoids getAccountTheme at module load). */
const BUSINESS_PRIMARY = '#7DD3FC';
const ANDROID_BLUR_PROPS = Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {};

interface Location {
  id: string;
  name: string;
  address: string | null;
  is_active?: boolean | null;
  status?: string | null;
}

interface LiveBooking {
  id: string;
  time: string;
  service: string;
  price: number;
  status: string;
  customerName?: string;
  customer_profile_picture?: string | null;
  customer_email?: string | null;
  customer_phone?: string | null;
  customer_id?: string | null;
  scheduled_at?: string | null;
  vehicle_registration?: string | null;
  vehicle_make?: string | null;
  vehicle_model?: string | null;
  vehicle_type?: string | null;
  location_address?: string | null;
  location_lat?: number | null;
  location_lng?: number | null;
  assigned_valeter_name?: string | null;
  assigned_valeter_photo?: string | null;
}

const METRIC_ACTIVE_STATUSES = new Set<string>([
  'confirmed',
  'in_progress',
  'pending_business_acceptance',
  'pending_valeter_acceptance',
]);
const METRIC_COMPLETE_STATUSES = new Set<string>(['completed']);
const METRIC_CANCEL_STATUSES = new Set<string>(['cancelled']);

const clamp = (v: number, min: number, max: number) => Math.max(min, Math.min(max, v));

function isLocationOpenForBookings(loc: Location): boolean {
  return loc.is_active !== false && loc.status !== 'inactive';
}

// Animated counter component
const AnimatedCounter = ({ value, style }: { value: number; style?: any }) => {
  const [displayValue, setDisplayValue] = useState(0);
  const animValue = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(animValue, {
      toValue: value,
      duration: 800,
      useNativeDriver: false,
    }).start();

    const listener = animValue.addListener(({ value: v }) => {
      setDisplayValue(Math.round(v));
    });

    return () => animValue.removeListener(listener);
  }, [value]);

  return <Text style={style}>{displayValue}</Text>;
};

export default function BusinessDashboard() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme: businessTheme } = useAccountTheme();
  const accent = businessTheme.primary;
  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const livePulseAnim = useRef(new Animated.Value(1)).current;

  const [locations, setLocations] = useState<Location[]>([]);
  const [loading, setLoading] = useState(true);
  const [businessName, setBusinessName] = useState<string>('');
  const [businessAddress, setBusinessAddress] = useState<string>('');
  const [notificationCount, setNotificationCount] = useState<number>(0);
  const [showNotificationDropdown, setShowNotificationDropdown] = useState(false);
  const [profilePicture, setProfilePicture] = useState<string | null>(null);
  const [liveBookings, setLiveBookings] = useState<LiveBooking[]>([]);
  const [locationScopeSheetVisible, setLocationScopeSheetVisible] = useState(false);
  const [scopeIntent, setScopeIntent] = useState<'open' | 'close' | null>(null);
  const [scopeSelectedIds, setScopeSelectedIds] = useState<Set<string>>(() => new Set());
  const [applyingScope, setApplyingScope] = useState(false);
  const [showActiveBookingsSheet, setShowActiveBookingsSheet] = useState(false);
  const [lastJob, setLastJob] = useState<{ time: string; service: string } | null>(null);
  const [nextBooking, setNextBooking] = useState<{ time: string; service: string } | null>(null);
  const [lastWeekBookings, setLastWeekBookings] = useState(0);
  const [dashboardJobs, setDashboardJobs] = useState<BusinessDashboardJobRow[]>([]);
  const [selectedDashboardJob, setSelectedDashboardJob] = useState<BusinessDashboardJobUi | null>(null);
  const [jobSheetChatOk, setJobSheetChatOk] = useState(true);
  const [dismissedRecentJobIds, setDismissedRecentJobIds] = useState<Set<string>>(() => new Set());

  const [stats, setStats] = useState({
    totalLocations: 0,
    activeBookings: 0,
    valetersOnline: 0,
    todayRevenue: 0,
    todayJobs: 0,
    totalRevenue: 0,
    completionRate: 0,
    averageRating: 0,
    bookingsThisWeek: 0,
  });

  const organizationId = user?.organizationId ?? null;
  const isOrgUser = ['organization', 'business'].includes((user?.userType ?? '').toLowerCase());

  const upcomingDashboardJobs = useMemo(
    () => dashboardJobs.filter(isBusinessDashboardUpcomingRow),
    [dashboardJobs]
  );

  const combinedDashboardJobs = useMemo((): BusinessDashboardJobUi[] => {
    const upcoming = upcomingDashboardJobs.map((b) => ({ ...b, _type: 'upcoming' as const }));
    const rest = dashboardJobs.filter((b) => !upcomingDashboardJobs.some((u) => u.id === b.id));
    let recentSlice = rest
      .filter((b) => !dismissedRecentJobIds.has(b.id))
      .slice(0, 3)
      .map((b) => ({ ...b, _type: 'recent' as const }));
    if (recentSlice.length === 0 && rest.length > 0) {
      recentSlice = rest.slice(0, 3).map((b) => ({ ...b, _type: 'recent' as const }));
    }
    return [...upcoming, ...recentSlice].slice(0, 8);
  }, [dashboardJobs, upcomingDashboardJobs, dismissedRecentJobIds]);

  useEffect(() => {
    if (!organizationId) {
      setDismissedRecentJobIds(new Set());
      return;
    }
    let cancelled = false;
    void loadDismissedRecentJobIds('business', organizationId).then((s) => {
      if (!cancelled) setDismissedRecentJobIds(s);
    });
    return () => {
      cancelled = true;
    };
  }, [organizationId]);


  useEffect(() => {
    const job = selectedDashboardJob;
    if (!job) {
      setJobSheetChatOk(true);
      return;
    }
    let cancelled = false;
    void (async () => {
      const ok = await canBusinessUseBookingChat(job.status, job.id, job.customer_user_id);
      if (!cancelled) setJobSheetChatOk(ok);
    })();
    return () => {
      cancelled = true;
    };
  }, [selectedDashboardJob]);

  const anyLocationOpen = useMemo(() => locations.some(isLocationOpenForBookings), [locations]);

  const relevantLocationsForScope = useMemo(() => {
    if (!scopeIntent) return [];
    return scopeIntent === 'open'
      ? locations.filter((l) => !isLocationOpenForBookings(l))
      : locations.filter((l) => isLocationOpenForBookings(l));
  }, [locations, scopeIntent]);

  const toggleScopeLocationId = useCallback((id: string) => {
    setScopeSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const applyLocationOpenClose = useCallback(
    async (ids: string[], open: boolean) => {
      if (!organizationId || ids.length === 0) return;
      setApplyingScope(true);
      try {
        await hapticFeedback(open ? 'medium' : 'light');
        if (open) {
          const targets = locations.filter((loc) => ids.includes(loc.id));
          const blocked = await getLocationOpenBlockReasons(targets);
          if (blocked.length > 0) {
            Alert.alert(
              'Could not open location',
              blocked.map((item) => `${item.locationName}: ${item.reason}`).join('\n\n')
            );
            return;
          }
        }
        const { error } = await supabase
          .from('car_wash_locations')
          .update({
            is_active: open,
            status: open ? 'active' : 'inactive',
          })
          .in('id', ids)
          .eq('organization_id', organizationId);
        if (error) throw error;
        setLocations((prev) =>
          prev.map((l) =>
            ids.includes(l.id)
              ? { ...l, is_active: open, status: open ? 'active' : 'inactive' }
              : l
          )
        );
        setLocationScopeSheetVisible(false);
        setScopeIntent(null);
        setScopeSelectedIds(new Set());
        await hapticFeedback('light');
      } catch (e: any) {
        console.error('[BusinessDashboard] location status:', e);
        Alert.alert('Could not update', e?.message || 'Please try again.');
      } finally {
        setApplyingScope(false);
      }
    },
    [locations, organizationId]
  );

  const handleBusinessPresenceButtonPress = useCallback(async () => {
    await hapticFeedback('light');
    if (!isOrgUser || !organizationId) {
      Alert.alert('Business account', 'Sign in with a business account that is linked to an organization.');
      return;
    }
    if (locations.length === 0) {
      Alert.alert('No locations', 'Add a location first, then you can open for bookings.', [
        { text: 'OK' },
        { text: 'Add location', onPress: () => router.push('/business/locations' as any) },
      ]);
      return;
    }

    if (locations.length === 1) {
      const loc = locations[0];
      if (anyLocationOpen) {
        Alert.alert(
          'Go offline?',
          `This will close “${loc.name}” and stop new bookings there until you open again.`,
          [
            { text: 'Cancel', style: 'cancel' },
            {
              text: 'Close location',
              style: 'destructive',
              onPress: () => void applyLocationOpenClose([loc.id], false),
            },
          ]
        );
      } else {
        Alert.alert(
          'Open for bookings?',
          `This will open “${loc.name}” so customers can book at this location.`,
          [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Open location', onPress: () => void applyLocationOpenClose([loc.id], true) },
          ]
        );
      }
      return;
    }

    const intent: 'open' | 'close' = anyLocationOpen ? 'close' : 'open';
    Alert.alert(
      intent === 'open' ? 'Open for bookings?' : 'Close locations?',
      intent === 'open'
        ? 'Opening locations lets customers book at them. On the next step, choose all locations or pick individual sites.'
        : 'Closing locations stops new bookings there. On the next step, choose all open locations or pick which to close.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Continue',
          onPress: () => {
            setScopeIntent(intent);
            setScopeSelectedIds(new Set());
            setLocationScopeSheetVisible(true);
          },
        },
      ]
    );
  }, [
    anyLocationOpen,
    applyLocationOpenClose,
    isOrgUser,
    locations,
    organizationId,
  ]);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    // Pulsing animation for live indicator
    const pulseAnimation = Animated.loop(
      Animated.sequence([
        Animated.timing(livePulseAnim, {
          toValue: 1.3,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(livePulseAnim, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    );
    pulseAnimation.start();

    if (isOrgUser && organizationId) {
      void loadData();
      void fetchNotificationCount();

      const interval = setInterval(() => {
        void fetchNotificationCount();
        void loadTodayData();
      }, 120000); // Update every 2 minutes
      return () => clearInterval(interval);
    } else {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [organizationId, isOrgUser]);

  // Realtime: refresh active bookings when any booking is updated so cards disappear as soon as completed/cancelled
  useEffect(() => {
    if (!organizationId) return;
    const channel = supabase
      .channel('business-dashboard-bookings')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'bookings' }, () => {
        loadLiveBookings()
          .then((rows) => setLiveBookings(rows))
          .catch((err) => console.error('Error refreshing live bookings:', err));
        void (async () => {
          try {
            const { loadDashboardBookingsForOrganization } = await import('../../src/services/BusinessBookingsService');
            const list = await loadDashboardBookingsForOrganization(organizationId);
            setDashboardJobs(list);
          } catch (err) {
            console.error('[BusinessDashboard] refresh dashboard jobs:', err);
          }
        })();
      })
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [organizationId]);

  const loadData = async () => {
    if (!organizationId) return;

    try {
      setLoading(true);

      // Phase 1: Load critical data first
      const [locs, orgData] = await Promise.all([
        loadLocations(),
        loadOrganizationData(),
        loadProfilePicture(),
      ]);

      if (orgData) {
        setBusinessName(orgData.name || '');
        setBusinessAddress(orgData.address || '');
      }

      setStats(prev => ({
        ...prev,
        totalLocations: locs.length,
      }));

      // Phase 2: Load non-critical data in background
      Promise.all([
        calculateBusinessRating(),
        loadBookingMetrics(),
        loadTeamCount(),
        loadTodayData(),
        loadLiveBookings(),
        fetchDashboardJobs(),
        loadLastJob(),
        loadNextBooking(),
        loadLastWeekBookings(),
      ]).then(([rating, bookingMetrics, teamCount, todayData, bookings, dashJobs, lastJobData, nextBookingData, lastWeek]) => {
        setStats(prev => ({
          ...prev,
          activeBookings: bookingMetrics.activeBookings,
          valetersOnline: teamCount,
          completionRate: bookingMetrics.completionRate,
          averageRating: rating,
          bookingsThisWeek: bookingMetrics.bookingsThisWeek,
          todayRevenue: todayData.revenue,
          todayJobs: todayData.jobs,
        }));
        setLiveBookings(bookings);
        setDashboardJobs(dashJobs);
        setLastJob(lastJobData);
        setNextBooking(nextBookingData);
        setLastWeekBookings(lastWeek);
      }).catch((error) => {
        console.error('Error loading secondary data:', error);
      });
    } catch (error: any) {
      console.error('Error loading business data:', error);
      Alert.alert('Error', error?.message || 'Failed to load dashboard');
    } finally {
      setLoading(false);
    }
  };

  const loadLocations = async (): Promise<Location[]> => {
    if (!organizationId) return [];
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id, name, address, is_active, status')
        .eq('organization_id', organizationId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      const list = (data || []) as Location[];
      setLocations(list);
      return list;
    } catch (error) {
      console.error('Error loading locations:', error);
      return [];
    }
  };

  const loadOrganizationData = async () => {
    if (!organizationId) return null;
    try {
      const { data, error } = await supabase
        .from('organizations')
        .select('name, address')
        .eq('id', organizationId)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') {
        console.error('Error loading organization data:', error);
        return null;
      }
      return data;
    } catch (error) {
      console.error('Error loading organization data:', error);
      return null;
    }
  };

  const loadProfilePicture = async () => {
    if (!organizationId) return;
    try {
      // Try to get logo/profile picture - query only columns that might exist
      const { data, error } = await supabase
        .from('organizations')
        .select('logo, profile_picture')
        .eq('id', organizationId)
        .maybeSingle();

      if (error) {
        // Silently fail if columns don't exist - this is expected
        if (error.code === '42703') {
          // Column doesn't exist - ignore
          return;
        }
        // For other errors, also silently fail
        return;
      }

      if (data) {
        // Try multiple possible column names for logo
        const logoUrl = (data.logo ?? data.profile_picture ?? '') as string;
        if (logoUrl) {
          setProfilePicture(logoUrl);
        }
      }
    } catch (err) {
      console.warn('[BusinessDashboard] loadProfilePicture:', err);
    }
  };

  const getValeterIds = async (): Promise<string[]> => {
    if (!organizationId) return [];
    try {
      const { data: valeters, error: valErr } = await supabase
        .from('profiles')
        .select('id')
        .eq('organization_id', organizationId)
        .eq('user_type', 'valeter');

      if (valErr) {
        console.warn('Supabase error in getValeterIds:', JSON.stringify(valErr));
        if (!valeters) return [];
      }
      return (valeters || []).map((v: any) => v.id) as string[];
    } catch (error: any) {
      console.error('Error loading valeter IDs:', error?.message || error);
      return [];
    }
  };

  const loadTodayData = async () => {
    if (!organizationId) return { revenue: 0, jobs: 0 };
    try {
      const valeterIds = await getValeterIds();
      if (valeterIds.length === 0) return { revenue: 0, jobs: 0 };

      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);

      const { data: bookings, error } = await supabase
        .from('bookings')
        .select('id, price, status, scheduled_at')
        .in('valeter_id', valeterIds)
        .gte('scheduled_at', today.toISOString())
        .lt('scheduled_at', tomorrow.toISOString());

      if (error) throw error;

      const completed = (bookings || []).filter((b: any) => b.status === 'completed');
      const revenue = completed.reduce((sum: number, b: any) => {
        const price = Number(b.price || 0);
        return sum + (Number.isFinite(price) ? price : 0);
      }, 0);

      return { revenue: Math.round(revenue), jobs: completed.length };
    } catch (error) {
      console.error('Error loading today data:', error);
      return { revenue: 0, jobs: 0 };
    }
  };

  const loadLiveBookings = async (): Promise<LiveBooking[]> => {
    if (!organizationId) return [];
    try {
      const { loadActiveBookingsForOrganization } = await import('../../src/services/BusinessBookingsService');
      const list = await loadActiveBookingsForOrganization(organizationId);
      // Completed bookings only belong on the history page
      const activeOnly = list.filter((b) => b.status !== 'completed' && b.status !== 'cancelled');
      return activeOnly.map((b) => ({
        id: b.id,
        time: b.scheduled_time || '—',
        service: b.service_type || 'Car wash',
        price: b.price,
        status: b.status,
        customerName: b.customer_name,
        customer_profile_picture: b.customer_profile_picture ?? null,
        customer_id: b.customer_id ?? null,
        scheduled_at: b.scheduled_at ?? null,
        customer_email: b.customer_email ?? null,
        customer_phone: b.customer_phone ?? null,
        location_address: b.location_address,
        location_lat: b.location_lat ?? null,
        location_lng: b.location_lng ?? null,
        assigned_valeter_name: b.assigned_valeter_name,
        assigned_valeter_photo: b.assigned_valeter_photo ?? null,
        vehicle_info: b.vehicle_info ?? null,
        vehicle_registration: b.vehicle_registration ?? null,
        vehicle_make: b.vehicle_make ?? null,
        vehicle_model: b.vehicle_model ?? null,
      }));
    } catch (error) {
      console.error('Error loading live bookings:', error);
      return [];
    }
  };

  const refreshLiveBookings = useCallback(async () => {
    const list = await loadLiveBookings();
    setLiveBookings(list);
  }, [organizationId]);

  const fetchDashboardJobs = useCallback(async (): Promise<BusinessDashboardJobRow[]> => {
    if (!organizationId) return [];
    try {
      const { loadDashboardBookingsForOrganization } = await import('../../src/services/BusinessBookingsService');
      const list = await loadDashboardBookingsForOrganization(organizationId);
      if (list.length > 0) return list;

      const { loadHistoryBookingsForOrganization } = await import('../../src/services/BusinessBookingsService');
      const history = await loadHistoryBookingsForOrganization(organizationId);
      return history.slice(0, 8).map((row): BusinessDashboardJobRow => ({
        id: row.id,
        status: row.status,
        service_type: row.service_type,
        service_name: row.service_name,
        location_address: row.location_address,
        scheduled_at: row.scheduled_at,
        price: row.price,
        created_at: row.created_at,
        customer_name: row.customer_name,
        customer_user_id: null,
        customer_photo: row.customer_profile_picture,
        assigned_valeter_name: row.assigned_valeter_name,
        assigned_valeter_photo: row.assigned_valeter_photo,
        vehicle_info: null,
        vehicle_registration: null,
        vehicle_make: null,
        vehicle_model: null,
      }));
    } catch (error) {
      console.error('[BusinessDashboard] dashboard jobs:', error);
      return [];
    }
  }, [organizationId]);

  const loadLastJob = async (): Promise<{ time: string; service: string } | null> => {
    if (!organizationId) return null;
    try {
      const valeterIds = await getValeterIds();
      if (valeterIds.length === 0) return null;

      const { data: bookings, error } = await supabase
        .from('bookings')
        .select('completed_at, service_type')
        .in('valeter_id', valeterIds)
        .eq('status', 'completed')
        .not('completed_at', 'is', null)
        .order('completed_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') throw error;
      if (!bookings) return null;

      const completedAt = new Date(bookings.completed_at);
      const now = new Date();
      const diffMs = now.getTime() - completedAt.getTime();
      const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
      const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));

      let timeStr: string;
      if (diffHours > 0) {
        timeStr = `Completed ${diffHours}hr${diffHours > 1 ? 's' : ''} ago`;
      } else if (diffMins > 0) {
        timeStr = `Completed ${diffMins}min ago`;
      } else {
        timeStr = 'Just completed';
      }

      return {
        time: timeStr,
        service: bookings.service_type || 'Car wash',
      };
    } catch (error) {
      console.error('Error loading last job:', error);
      return null;
    }
  };

  const loadNextBooking = async (): Promise<{ time: string; service: string } | null> => {
    if (!organizationId) return null;
    try {
      const valeterIds = await getValeterIds();
      if (valeterIds.length === 0) return null;

      const now = new Date();
      const { data: bookings, error } = await supabase
        .from('bookings')
        .select('scheduled_at, service_type')
        .in('valeter_id', valeterIds)
        .in('status', ['confirmed', 'pending_valeter_acceptance'])
        .gte('scheduled_at', now.toISOString())
        .order('scheduled_at', { ascending: true })
        .limit(1)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') throw error;
      if (!bookings) return null;

      const scheduledAt = new Date(bookings.scheduled_at);
      const timeStr = scheduledAt.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });

      return {
        time: timeStr,
        service: bookings.service_type || 'Car wash',
      };
    } catch (error) {
      console.error('Error loading next booking:', error);
      return null;
    }
  };

  const loadLastWeekBookings = async (): Promise<number> => {
    if (!organizationId) return 0;
    try {
      const valeterIds = await getValeterIds();
      if (valeterIds.length === 0) return 0;

      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      const twoWeeksAgo = new Date(weekAgo);
      twoWeeksAgo.setDate(twoWeeksAgo.getDate() - 7);

      const { count, error } = await supabase
        .from('bookings')
        .select('id', { count: 'exact', head: true })
        .in('valeter_id', valeterIds)
        .gte('created_at', twoWeeksAgo.toISOString())
        .lt('created_at', weekAgo.toISOString());

      if (error) throw error;
      return count || 0;
    } catch (error) {
      console.error('Error loading last week bookings:', error);
      return 0;
    }
  };

  const loadBookingMetrics = async () => {
    if (!organizationId) {
      return { activeBookings: 0, bookingsThisWeek: 0, completionRate: 0 };
    }

    const valeterIds = await getValeterIds();
    if (valeterIds.length === 0) {
      return { activeBookings: 0, bookingsThisWeek: 0, completionRate: 0 };
    }

    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);

    const { data: bookings, error } = await supabase
      .from('bookings')
      .select('id, status, created_at')
      .in('valeter_id', valeterIds)
      .order('created_at', { ascending: false })
      .limit(200);

    if (error) throw error;

    const rows = (bookings || []) as { id: string; status: string; created_at: string }[];

    const activeBookings = rows.filter((b) => METRIC_ACTIVE_STATUSES.has(b.status)).length;

    const bookingsThisWeek = rows.filter((b) => {
      const t = new Date(b.created_at).getTime();
      return Number.isFinite(t) && t >= weekAgo.getTime();
    }).length;

    const completed = rows.filter((b) => METRIC_COMPLETE_STATUSES.has(b.status)).length;
    const cancelled = rows.filter((b) => METRIC_CANCEL_STATUSES.has(b.status)).length;
    const finished = completed + cancelled;

    const completionRate = finished > 0 ? Math.round((completed / finished) * 100) : 0;

    return { activeBookings, bookingsThisWeek, completionRate };
  };

  const loadTeamCount = async (): Promise<number> => {
    if (!organizationId) return 0;

    try {
      const { count, error } = await supabase
        .from('profiles')
        .select('id', { count: 'exact', head: true })
        .eq('organization_id', organizationId)
        .eq('user_type', 'valeter');

      if (error) throw error;
      return count || 0;
    } catch (e) {
      console.warn('Error loading team count:', e);
      return 0;
    }
  };

  const fetchNotificationCount = async () => {
    if (!organizationId) return;

    try {
      const [items, dismissed] = await Promise.all([
        fetchBusinessNotificationFeed(organizationId, {
          bookingLimit: DROPDOWN_FEED_DEFAULTS.bookingLimit,
          teamRequestLimit: DROPDOWN_FEED_DEFAULTS.teamRequestLimit,
          teamUpdateMaxAgeMs: DROPDOWN_FEED_DEFAULTS.teamUpdateMaxAgeMs,
        }),
        loadDismissedBusinessNotificationIds(organizationId),
      ]);
      const visible = items.filter((n) => !dismissed.has(n.id));
      setNotificationCount(visible.length);
    } catch (error) {
      console.error('Error fetching notification count:', error);
      setNotificationCount(0);
    }
  };

  const calculateBusinessRating = async (): Promise<number> => {
    if (!organizationId) return 0;
    try {
      const { data: valeters, error: valetersError } = await supabase
        .from('profiles')
        .select('id')
        .eq('organization_id', organizationId)
        .eq('user_type', 'valeter');

      if (valetersError) throw valetersError;
      if (!valeters || valeters.length === 0) return 0;

      const valeterIds = valeters.map((v: any) => v.id);

      const { data: bookings, error: bookingsError } = await supabase
        .from('bookings')
        .select('rating, status, valeter_id')
        .in('valeter_id', valeterIds)
        .eq('status', 'completed')
        .not('rating', 'is', null)
        .order('created_at', { ascending: false })
        .limit(100);

      if (bookingsError) throw bookingsError;
      if (!bookings || bookings.length === 0) return 0;

      const ratings = bookings
        .map((b: any) => Number(b.rating))
        .filter((r: number) => Number.isFinite(r) && r > 0);

      if (ratings.length === 0) return 0;

      const average = ratings.reduce((sum: number, r: number) => sum + r, 0) / ratings.length;
      return Math.round(average * 10) / 10;
    } catch (error) {
      console.error('Error calculating business rating:', error);
      return 0;
    }
  };


  if (loading) {
    return <LoadingScreen message="Loading…" />;
  }

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  };

  const headerSubtitle =
    businessAddress || (user?.name ? `${getGreeting()}, ${user.name.split(' ')[0]}` : getGreeting());

  const weeklyStreakDiff = stats.bookingsThisWeek - lastWeekBookings;
  const businessShortcutItems = [
    { key: 'bookings', label: 'Bookings', icon: 'calendar-outline', route: '/business/bookings' },
    { key: 'team', label: 'Team', icon: 'people-outline', route: '/business/team' },
    { key: 'services', label: 'Services', icon: 'construct-outline', route: '/business/services' },
    { key: 'metrics', label: 'Metrics', icon: 'pie-chart-outline', route: '/business/key-metrics' },
  ] as const;

  const renderDailyStats = () => (
    <Animated.View style={{ marginBottom: 14, opacity: fadeAnim }}>
      <View style={styles.bizDailyStatsWrap}>
        <View style={[styles.bizDailyStatsCard, { borderColor: `${accent}40`, shadowColor: accent }]}>
          <View pointerEvents="none" style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(15,23,42,0.45)' }]} />
          <BlurView
            intensity={Platform.OS === 'ios' ? 44 : 70}
            tint="dark"
            style={StyleSheet.absoluteFill}
            {...ANDROID_BLUR_PROPS}
          />
          <LinearGradient
            colors={businessTheme?.headerBackground ?? HEADER_STYLE_CARD_GRADIENT}
            start={{ x: 0, y: 0 }}
            end={{ x: 0, y: 1 }}
            style={StyleSheet.absoluteFill}
          />
          <View style={[styles.bizDailyStatsGlow, { backgroundColor: accent }]} />
          <LinearGradient
            colors={['rgba(255,255,255,0.08)', 'transparent']}
            start={{ x: 0, y: 0 }}
            end={{ x: 0, y: 0.45 }}
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
          />
          <View style={styles.bizDailyStatsRow}>
            <View style={styles.bizDailyStatItem}>
              <View style={styles.bizDailyStatIconWrap}>
                <LocationStyleIconBox icon="briefcase-outline" preset="sky" />
              </View>
              <Text style={[styles.bizDailyStatValue, { color: '#F9FAFB' }]}>{stats.todayJobs}</Text>
              <Text style={[styles.bizDailyStatLabel, { color: accent }]}>Jobs today</Text>
            </View>
            <View style={[styles.bizDailyStatDivider, { backgroundColor: `${accent}30` }]} />
            <View style={styles.bizDailyStatItem}>
              <View style={styles.bizDailyStatIconWrap}>
                <LocationStyleIconBox icon="wallet-outline" preset="green" />
              </View>
              <Text style={[styles.bizDailyStatValue, { color: accent }]}>£{Number(stats.todayRevenue || 0).toFixed(2)}</Text>
              <Text style={[styles.bizDailyStatLabel, { color: '#94A3B8' }]}>Earned today</Text>
            </View>
            <View style={[styles.bizDailyStatDivider, { backgroundColor: `${accent}30` }]} />
            <View style={styles.bizDailyStatItem}>
              <View style={styles.bizDailyStatIconWrap}>
                <LocationStyleIconBox icon="calendar-outline" preset="cyan" />
              </View>
              <Text style={[styles.bizDailyStatValue, { color: '#F9FAFB' }]}>{upcomingDashboardJobs.length}</Text>
              <Text style={[styles.bizDailyStatLabel, { color: '#94A3B8' }]}>Upcoming</Text>
            </View>
          </View>
          <TouchableOpacity
            style={[
              styles.bizDailyPresenceRow,
              anyLocationOpen ? styles.bizDailyPresenceRowOpen : styles.bizDailyPresenceRowClosed,
            ]}
            onPress={() => void handleBusinessPresenceButtonPress()}
            activeOpacity={0.88}
            disabled={applyingScope}
          >
            <View
              style={[
                styles.bizDailyPresenceDot,
                { backgroundColor: anyLocationOpen ? '#10B981' : '#EF4444' },
              ]}
            />
            <View style={styles.bizDailyPresenceTextWrap}>
              <Text style={styles.bizDailyPresenceTitle}>
                {anyLocationOpen ? 'You’re online' : 'You’re offline'}
              </Text>
              <Text style={styles.bizDailyPresenceSubtitle} numberOfLines={1}>
          {getPresenceSubtitle(applyingScope, anyLocationOpen)}
              </Text>
            </View>
            {applyingScope ? (
              <ActivityIndicator size="small" color="rgba(255,255,255,0.9)" />
            ) : (
              <View style={styles.bizDailyPresenceChevron}>
                <Ionicons name={CONTINUE_CTA_ICON_NAME} size={14} color="rgba(255,255,255,0.85)" />
              </View>
            )}
          </TouchableOpacity>
        </View>
      </View>

      <Animated.View style={{ marginBottom: 16, opacity: fadeAnim }}>
        <View style={[styles.businessShortcutGrid, { marginHorizontal: isSmallScreen ? 12 : SCREEN_PADDING_H }]}>
          {businessShortcutItems.map((item) => {
            return (
              <Pressable
                key={item.key}
                onPress={async () => {
                  await hapticFeedback('light');
                  router.push(item.route as any);
                }}
                style={styles.businessShortcutTileWrap}
              >
                <View
                  style={[
                    styles.businessShortcutTile,
                    {
                      borderColor: `${businessTheme.primary}32`,
                      shadowColor: businessTheme.primary,
                    },
                  ]}
                >
                  <View style={styles.businessShortcutTileGlow} />
                  <RawIonicons
                    name={item.icon as any}
                    size={item.key === 'metrics' ? 30 : 28}
                    color={businessTheme.primary}
                  />
                  <Text style={styles.businessShortcutTileLabel} numberOfLines={1}>
                    {item.label}
                  </Text>
                </View>
              </Pressable>
            );
          })}
        </View>
      </Animated.View>

    </Animated.View>
  );

  const renderActiveBookings = () => (
    <Animated.View style={[styles.bookingsBlock, { opacity: fadeAnim }]}>
      <DashboardGlassSection palette="business" tone="panel">
      <View style={styles.sectionTitleRow}>
        <TouchableOpacity
          style={styles.sectionTitleWithIcon}
          onPress={async () => {
            await hapticFeedback('light');
            setShowActiveBookingsSheet(true);
          }}
          activeOpacity={0.7}
        >
          <LocationStyleIconBox variant="inline" icon="calendar" preset="amber" />
          <Text style={styles.sectionTitle}>Active bookings</Text>
          <LocationStyleIconBox variant="inline" icon="list" preset="gray" style={{ marginLeft: 6 }} />
        </TouchableOpacity>
        <TouchableOpacity
          onPress={async () => {
            await hapticFeedback('light');
            router.push('/business/bookings/activity');
          }}
        >
          <Text style={styles.viewAllText}>Activity</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.bookingsCardStack}>
        {liveBookings.length > 0 ? (
          liveBookings.slice(0, 3).map((booking) => {
            const statusInfo = getActiveBookingStatusLabel(booking.status);
            const hasCoords = booking.location_lat != null && booking.location_lng != null && Number.isFinite(booking.location_lat) && Number.isFinite(booking.location_lng);
            const mapRegion = hasCoords
              ? {
                  latitude: Number(booking.location_lat),
                  longitude: Number(booking.location_lng),
                  latitudeDelta: 0.012,
                  longitudeDelta: 0.012,
                }
              : null;
            const ringColor = getStatusRingColor(booking.status);
            const progress = getBookingStatusProgress(booking.status);
            return (
              <TouchableOpacity
                key={booking.id}
                activeOpacity={0.92}
                onPress={async () => {
                  await hapticFeedback('light');
                  if (canOpenLiveTracking(booking.scheduled_at, booking.status)) {
                    router.push({ pathname: '/business/bookings/tracking', params: { bookingId: booking.id } } as any);
                  } else {
                    router.push({ pathname: '/business/bookings/[id]', params: { id: booking.id } } as any);
                  }
                }}
                style={styles.activeBookingCardWrap}
              >
                <View style={[styles.activeBookingCard, styles.activeBookingCardGlow]}>
                  <View style={styles.activeBookingMapContainer}>
                    {mapRegion ? (
                      <>
                        <MapView
                          style={StyleSheet.absoluteFill}
                          region={mapRegion}
                          scrollEnabled={false}
                          zoomEnabled={false}
                          pitchEnabled={false}
                          rotateEnabled={false}
                          userInterfaceStyle={MAP_LOCKED_DARK}
                        >
                          <Marker coordinate={{ latitude: mapRegion.latitude, longitude: mapRegion.longitude }}>
                            <View style={[styles.activeBookingMapMarker, { backgroundColor: ringColor }]}>
                              <Ionicons name="location" size={18} color="#0A1929" />
                            </View>
                          </Marker>
                        </MapView>
                        <LinearGradient colors={['transparent', 'rgba(0,0,0,0.78)']} style={StyleSheet.absoluteFill} />
                      </>
                    ) : (
                      <LinearGradient colors={['rgba(135,206,235,0.28)', 'rgba(30,58,138,0.35)']} style={StyleSheet.absoluteFill} />
                    )}
                    <View style={styles.activeBookingCardOverlayWrap}>
                      <BlurView intensity={Platform.OS === 'ios' ? 40 : 64} tint="dark" style={StyleSheet.absoluteFill} />
                      <View style={styles.activeBookingCardOverlay}>
                        <View style={[styles.activeBookingRingWrap, { shadowColor: ringColor }]}>
                          <AnimatedProgress
                            progress={progress}
                            size={72}
                            strokeWidth={8}
                            showPercentage
                            color={ringColor}
                          />
                        </View>
                        <View style={styles.activeBookingCardContent}>
                          {statusInfo.live ? (
                            <View style={styles.activeBookingLiveChip}>
                              <View style={styles.activeBookingLiveDot} />
                              <Text style={styles.activeBookingLiveText}>LIVE</Text>
                            </View>
                          ) : null}
                          <Text style={styles.activeBookingCardTitle}>Customer booking</Text>
                          <Text style={styles.activeBookingCardSubtitle} numberOfLines={1}>{booking.service}</Text>
                          <Text style={styles.activeBookingCardCustomer} numberOfLines={1}>{booking.customerName || 'Customer'}</Text>
                          <View style={styles.activeBookingTrackPill}>
                            <Text style={styles.activeBookingTrackPillText}>{statusInfo.label}</Text>
                            <Ionicons name={CONTINUE_CTA_ICON_NAME} size={14} color="#0A1929" />
                          </View>
                        </View>
                      </View>
                    </View>
                  </View>
                  <View style={styles.activeBookingBottomRow}>
                    <BlurView intensity={Platform.OS === 'ios' ? 56 : 80} tint="dark" style={StyleSheet.absoluteFill} />
                      <View style={styles.activeBookingBottomRowInner}>
                      <View style={styles.activeBookingPriceWrap}>
                        <LocationStyleIconBox variant="inline" icon="wallet-outline" preset="gray" />
                        <Text style={styles.activeBookingPrice}>£{booking.price.toFixed(2)}</Text>
                      </View>
                      <View style={styles.activeBookingCta}>
                        <Text style={styles.activeBookingCtaText}>Track</Text>
                        <Ionicons name={CONTINUE_CTA_ICON_NAME} size={18} color={SKY} />
                      </View>
                    </View>
                  </View>
                </View>
              </TouchableOpacity>
            );
          })
        ) : null}
        {nextBooking ? (
          <View style={[styles.bookingRowCard, styles.bookingSheetCardOuter]}>
            <BlurView
              intensity={Platform.OS === 'ios' ? 36 : 56}
              tint="dark"
              style={StyleSheet.absoluteFill}
              {...ANDROID_BLUR_PROPS}
            />
            <LinearGradient
              colors={HEADER_STYLE_CARD_GRADIENT}
              start={{ x: 0, y: 0 }}
              end={{ x: 0, y: 1 }}
              style={StyleSheet.absoluteFill}
            />
            <View style={[StyleSheet.absoluteFill, styles.bookingSheetCardOverlay]} />
            <View style={styles.bookingRowCardInner}>
              <View style={styles.bookingRowCardBadge}>
                <Text style={styles.bookingRowCardBadgeText}>Upcoming</Text>
              </View>
              <Text style={styles.bookingRowCardService}>{nextBooking.service}</Text>
              <Text style={styles.bookingMetaText}>{nextBooking.time}</Text>
            </View>
          </View>
        ) : null}
      </View>
      </DashboardGlassSection>
    </Animated.View>
  );

  const renderMetrics = () => (
    <Animated.View style={[styles.metricsSection, { opacity: fadeAnim }]}>
      <DashboardGlassSection palette="business" tone="frame" innerStyle={styles.dashboardGlassInnerFrame}>
      <View style={styles.sectionTitleRow}>
        <View style={styles.sectionTitleWithIcon}>
          <LocationStyleIconBox variant="inline" icon="stats-chart" preset="purple" />
          <Text style={styles.sectionTitle}>Metrics</Text>
        </View>
        <TouchableOpacity
          onPress={async () => {
            await hapticFeedback('light');
            router.push('/business/key-metrics' as any);
          }}
        >
          <Text style={styles.viewAllText}>Full view</Text>
        </TouchableOpacity>
      </View>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.metricsScrollContainer}
      >
        {/* Weekly Bookings Card */}
        <GlassCard style={styles.metricCardHorizontal} accountType="business">
          <View style={styles.metricCardContent}>
            <View style={[styles.metricRingPlate, { borderColor: `${accent}40`, shadowColor: accent }]}>
              <View style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(15,23,42,0.35)' }]} />
              <BlurView
                intensity={Platform.OS === 'ios' ? 36 : 56}
                tint="dark"
                style={StyleSheet.absoluteFill}
                {...ANDROID_BLUR_PROPS}
              />
              <LinearGradient
                colors={['rgba(255,255,255,0.12)', 'transparent']}
                start={{ x: 0, y: 0 }}
                end={{ x: 0, y: 0.55 }}
                style={StyleSheet.absoluteFill}
                pointerEvents="none"
              />
              <View style={styles.metricRingWrap}>
                <AnimatedProgress
                  progress={clamp(stats.bookingsThisWeek * 14, 0, 100)}
                  size={108}
                  strokeWidth={9}
                  showPercentage={false}
                  color={SKY}
                  futuristic
                  gamified
                  tierPalette={stats.bookingsThisWeek < 1 ? { fill: '#EF4444', glow: '#FCA5A5' } : { fill: '#10B981', glow: '#6EE7B7' }}
                  spinPalette={stats.bookingsThisWeek < 1 ? ['#EF4444', '#DC2626', '#991B1B', '#F87171'] : ['#10B981', '#34D399', '#059669', '#6EE7B7']}
                  sequentialSpin
                  glassCenter
                />
                <View style={styles.metricRingCenterOverlay} pointerEvents="none">
                  <AnimatedCounter value={stats.bookingsThisWeek} style={styles.metricRingCenterMain} />
                  <Text style={styles.metricRingCenterSub}>bookings</Text>
                </View>
              </View>
            </View>
            <View style={styles.metricBody}>
              <View style={styles.metricTitleRow}>
                <LocationStyleIconBox variant="inline" icon="calendar" preset="sky" />
                <Text style={styles.metricTitle}>This Week</Text>
              </View>
              <Text style={styles.metricSubtext}>Bookings in the last 7 days</Text>
              {weeklyStreakDiff !== 0 && (
                <View style={styles.metricTrendRow}>
                  <Ionicons
                    name={weeklyStreakDiff > 0 ? "arrow-up" : "arrow-down"}
                    size={12}
                    color={weeklyStreakDiff > 0 ? "#10B981" : "rgba(239,68,68,0.9)"}
                  />
                  <Text style={[styles.metricTrend, weeklyStreakDiff > 0 && styles.metricTrendUp]}>
                    {Math.abs(weeklyStreakDiff)} from last week
                  </Text>
                </View>
              )}
            </View>
          </View>
        </GlassCard>

        {/* Completion Rate Card */}
        <GlassCard style={styles.metricCardHorizontal} accountType="business">
          <View style={styles.metricCardContent}>
            <View style={[styles.metricRingPlate, { borderColor: `${accent}40`, shadowColor: accent }]}>
              <View style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(15,23,42,0.35)' }]} />
              <BlurView
                intensity={Platform.OS === 'ios' ? 36 : 56}
                tint="dark"
                style={StyleSheet.absoluteFill}
                {...ANDROID_BLUR_PROPS}
              />
              <LinearGradient
                colors={['rgba(255,255,255,0.12)', 'transparent']}
                start={{ x: 0, y: 0 }}
                end={{ x: 0, y: 0.55 }}
                style={StyleSheet.absoluteFill}
                pointerEvents="none"
              />
              <View style={styles.metricRingWrap}>
                <AnimatedProgress
                  progress={clamp(stats.completionRate, 0, 100)}
                  size={108}
                  strokeWidth={9}
                  showPercentage
                  color="#10B981"
                  futuristic
                  gamified
                  tierPalette={{ fill: '#94A3B8', glow: '#E2E8F0' }}
                  spinPalette={['#E2E8F0', '#94A3B8', '#E2E8F0', '#94A3B8']}
                  sequentialSpin
                  glassCenter
                />
              </View>
            </View>
            <View style={styles.metricBody}>
              <View style={styles.metricTitleRow}>
                <LocationStyleIconBox variant="inline" icon="checkmark-done" preset="green" />
                <Text style={styles.metricTitle}>Completion Rate</Text>
              </View>
              <Text style={styles.metricSubtext}>Closed jobs successfully completed</Text>
            </View>
          </View>
        </GlassCard>

        {/* Team Availability Card */}
        <GlassCard style={styles.metricCardHorizontal} accountType="business">
          <View style={styles.metricCardContent}>
            <View style={[styles.metricRingPlate, { borderColor: `${accent}40`, shadowColor: accent }]}>
              <View style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(15,23,42,0.35)' }]} />
              <BlurView
                intensity={Platform.OS === 'ios' ? 36 : 56}
                tint="dark"
                style={StyleSheet.absoluteFill}
                {...ANDROID_BLUR_PROPS}
              />
              <LinearGradient
                colors={['rgba(255,255,255,0.12)', 'transparent']}
                start={{ x: 0, y: 0 }}
                end={{ x: 0, y: 0.55 }}
                style={StyleSheet.absoluteFill}
                pointerEvents="none"
              />
              <View style={styles.metricRingWrap}>
                <AnimatedProgress
                  progress={clamp(stats.valetersOnline * 28, 0, 100)}
                  size={108}
                  strokeWidth={9}
                  showPercentage={false}
                  color="#14B8A6"
                  futuristic
                  gamified
                  tierPalette={{ fill: '#14B8A6', glow: '#5EEAD4' }}
                  spinPalette={['#14B8A6', '#5EEAD4', '#0D9488', '#2DD4BF']}
                  sequentialSpin
                  glassCenter
                />
                <View style={styles.metricRingCenterOverlay} pointerEvents="none">
                  <AnimatedCounter value={stats.valetersOnline} style={styles.metricRingCenterMain} />
                  <Text style={styles.metricRingCenterSub}>pros</Text>
                </View>
              </View>
            </View>
            <View style={styles.metricBody}>
              <View style={styles.metricTitleRow}>
                <LocationStyleIconBox variant="inline" icon="people" preset="teal" />
                <Text style={styles.metricTitle}>Team Online</Text>
              </View>
              <Text style={styles.metricSubtext}>Car Care Pros available</Text>
            </View>
          </View>
        </GlassCard>
      </ScrollView>
      </DashboardGlassSection>
    </Animated.View>
  );

  const renderLocations = () => (
    locations.length === 0 ? (
      <GlassCard style={styles.emptyCard} accountType="business">
        <View style={styles.emptyContent}>
          <View style={{ opacity: 0.92 }}>
            <LocationStyleIconBox variant="hero" icon="location-outline" preset="sky" />
          </View>
          <Text style={styles.emptyTitle}>No locations yet</Text>
          <Text style={styles.emptyText}>
            Add your first physical location to start accepting bookings
          </Text>
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('medium');
              router.push('/business/locations');
            }}
            style={styles.addButton}
            activeOpacity={0.85}
          >
            <LinearGradient colors={['#10B981', '#059669']} style={styles.addButtonGradient}>
              <GradientIconBox
                icon="add"
                borderless
                boxSize={28}
                size={18}
                borderRadius={10}
                colors={['#FFFFFF', '#FFFFFF']}
              />
              <Text style={styles.addButtonText}>Add Location</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </GlassCard>
    ) : (
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.locationsScrollContainer}
      >
        {locations.map((location, index) => {
          const isActive = location.is_active !== false && location.status !== 'inactive';
          const isClosed = location.is_active === false || location.status === 'inactive';

          return (
            <Animated.View
              key={location.id}
              style={[
                { opacity: fadeAnim },
                {
                  transform: [
                    {
                      translateX: fadeAnim.interpolate({
                        inputRange: [0, 1],
                        outputRange: [20 + index * 10, 0],
                      }),
                    },
                  ],
                },
              ]}
            >
              <GlassCard
                onPress={async () => {
                  await hapticFeedback('light');
                  router.push(`/business/locations/${location.id}` as any);
                }}
                style={styles.locationCard}
                accountType="business"
              >
              <LinearGradient
                colors={getLocationCardGradient(isClosed, isActive)}
                style={StyleSheet.absoluteFill}
              />
              <View style={styles.locationContent}>
                <View style={styles.locationHeader}>
                  <View style={styles.locationIconWrapper}>
                    <LocationStyleIconBox icon="location" preset="sky" />
                  </View>
                  {isClosed ? (
                    <LocationStyleIconBox variant="inline" icon="close-circle" preset="red" />
                  ) : (
                    <View style={[styles.locationStatusBadge, isActive && styles.locationStatusLive]}>
                      <View 
                        style={[
                          styles.locationStatusDot,
                          {
                            backgroundColor: isActive ? '#10B981' : '#6B7280',
                          },
                        ]}
                      />
                      <Text style={styles.locationStatusText}>
                        {isActive ? 'Open' : 'Offline'}
                      </Text>
                    </View>
                  )}
                </View>
                <View style={styles.locationInfo}>
                  <Text style={styles.locationName} numberOfLines={1}>
                    {location.name}
                  </Text>
                  <View style={styles.locationStats}>
                    <View style={styles.locationStatWithIcon}>
                      <LocationStyleIconBox variant="micro" icon="star" preset="amber" />
                      <Text style={styles.locationStat}>
                        {stats.averageRating.toFixed(1)}
                      </Text>
                    </View>
                    <Text style={styles.locationStatSeparator}>•</Text>
                    <View style={styles.locationStatWithIcon}>
                      <LocationStyleIconBox variant="micro" icon="time-outline" preset="gray" />
                      <Text style={styles.locationStat}>
                        Avg 32m
                      </Text>
                    </View>
                    <Text style={styles.locationStatSeparator}>•</Text>
                    <View style={styles.locationStatWithIcon}>
                      <LocationStyleIconBox variant="micro" icon="wallet-outline" preset="gray" />
                      <Text style={styles.locationStat}>
                        £{stats.todayRevenue} today
                      </Text>
                    </View>
                  </View>
                  <Text style={styles.locationNextBooking}>
                    Next booking: {nextBooking ? nextBooking.time : 'None'}
                  </Text>
                </View>
              </View>
              <View style={styles.locationPerformanceWrap}>
                <View style={styles.locationPerformancePill}>
                  <LocationStyleIconBox variant="micro" icon="trending-up" preset="green" />
                  <Text style={styles.locationPerformanceText}>Excellent Performance (98%)</Text>
                </View>
              </View>
            </GlassCard>
            </Animated.View>
          );
        })}
      </ScrollView>
    )
  );

  const renderLocationScopeSheet = () => (
    <Pressable
      style={[styles.locationScopeSheet, { paddingBottom: Math.max(28, insets.bottom + 16) }]}
      onPress={(e) => e.stopPropagation()}
    >
      <BusinessSheetBackground />
      <View style={[styles.locationScopeHandle, { backgroundColor: 'rgba(255,255,255,0.35)' }]} />
      <Text style={styles.locationScopeTitle}>
        {scopeIntent === 'open' ? 'Open locations' : 'Close locations'}
      </Text>
      <Text style={styles.locationScopeSubtitle}>
        {scopeIntent === 'open'
          ? 'Choose to open every closed site, or select specific locations only.'
          : 'Choose to close every open site, or select specific locations only.'}
      </Text>

      <TouchableOpacity
        style={[
          styles.locationScopeAllBtn,
          { borderColor: scopeIntent === 'open' ? 'rgba(16,185,129,0.45)' : 'rgba(248,113,113,0.5)' },
        ]}
        onPress={() => {
          const ids = relevantLocationsForScope.map((l) => l.id);
          if (ids.length === 0) {
            Alert.alert('Nothing to update', scopeIntent === 'open' ? 'All locations are already open.' : 'No locations are currently open.');
            return;
          }
          void applyLocationOpenClose(ids, scopeIntent === 'open');
        }}
        disabled={applyingScope || relevantLocationsForScope.length === 0}
        activeOpacity={0.85}
      >
        <BlurView
          intensity={Platform.OS === 'ios' ? 28 : 48}
          tint="dark"
          style={StyleSheet.absoluteFill}
          {...ANDROID_BLUR_PROPS}
        />
        <LinearGradient
          colors={
            scopeIntent === 'open'
              ? ['rgba(16,185,129,0.38)', 'rgba(5,150,105,0.28)']
              : ['rgba(239,68,68,0.42)', 'rgba(185,28,28,0.32)']
          }
          style={StyleSheet.absoluteFill}
        />
        <LinearGradient
          colors={['rgba(255,255,255,0.2)', 'transparent']}
          start={{ x: 0, y: 0 }}
          end={{ x: 0, y: 1 }}
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
        />
        <View style={styles.locationScopeAllBtnInner}>
          <Ionicons
            name={scopeIntent === 'open' ? 'globe-outline' : 'close-circle-outline'}
            size={22}
            color="#F9FAFB"
          />
          <Text style={styles.locationScopeAllBtnText}>
            {scopeIntent === 'open'
              ? `Open all (${relevantLocationsForScope.length})`
              : `Close all open (${relevantLocationsForScope.length})`}
          </Text>
        </View>
      </TouchableOpacity>

      <Text style={styles.locationScopeDividerLabel}>Or select individually</Text>

      <ScrollView
        style={styles.locationScopeList}
        contentContainerStyle={styles.locationScopeListContent}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {relevantLocationsForScope.map((loc) => {
          const selected = scopeSelectedIds.has(loc.id);
          return (
            <Pressable
              key={loc.id}
              onPress={() => !applyingScope && toggleScopeLocationId(loc.id)}
              style={[
                styles.locationScopeRow,
                selected && {
                  borderColor: businessTheme.primary,
                  backgroundColor: 'rgba(125,211,252,0.16)',
                },
              ]}
            >
              <Ionicons
                name={selected ? 'checkbox' : 'square-outline'}
                size={22}
                color={selected ? businessTheme.primary : 'rgba(249,250,251,0.45)'}
              />
              <View style={styles.locationScopeRowText}>
                <Text style={styles.locationScopeRowTitle} numberOfLines={1}>
                  {loc.name}
                </Text>
                {loc.address ? (
                  <Text style={styles.locationScopeRowSub} numberOfLines={1}>
                    {loc.address}
                  </Text>
                ) : null}
              </View>
            </Pressable>
          );
        })}
      </ScrollView>

      <TouchableOpacity
        style={[
          styles.locationScopeConfirmBtn,
          { opacity: scopeSelectedIds.size === 0 || applyingScope ? 0.45 : 1 },
        ]}
        disabled={scopeSelectedIds.size === 0 || applyingScope}
        onPress={() => {
          void applyLocationOpenClose([...scopeSelectedIds], scopeIntent === 'open');
        }}
        activeOpacity={0.88}
      >
        <LinearGradient colors={[businessTheme.primary, '#0EA5E9']} style={StyleSheet.absoluteFill} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} />
        <Text style={styles.locationScopeConfirmText}>
          {scopeIntent === 'open'
            ? `Open selected (${scopeSelectedIds.size})`
            : `Close selected (${scopeSelectedIds.size})`}
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.locationScopeCancelBtn}
        onPress={() => !applyingScope && setLocationScopeSheetVisible(false)}
        disabled={applyingScope}
      >
        <Text style={styles.locationScopeCancelText}>Cancel</Text>
      </TouchableOpacity>

      {applyingScope ? (
        <View style={styles.locationScopeApplying}>
          <ActivityIndicator color={businessTheme.primary} />
        </View>
      ) : null}
    </Pressable>
  );

  const renderJobSheet = (job: BusinessDashboardJobUi) => (
    <>
      <View style={styles.bizYourJobSheetHandle} />
      <View style={styles.bizYourJobSheetHeader}>
        <Text style={styles.bizYourJobSheetTitle}>
          {getServiceDisplayName(job.service_type, job.service_name) ||
            job.service_name ||
            'Job'}
        </Text>
        <View style={styles.bizYourJobSheetSubtitleRow}>
          <Text style={[styles.bizYourJobSheetSubtitle, { color: accent }]}>
            {getJobSheetStatusLabel(job)}
          </Text>
          <StatusBadge status={job.status as any} size="small" />
        </View>
      </View>
      <View style={styles.bizYourJobSheetPhotoHero}>
        {job.customer_photo ? (
          <Image
            source={{ uri: job.customer_photo }}
            style={[styles.bizYourJobSheetPhotoHeroImg, { borderColor: `${accent}55` }]}
            resizeMode="cover"
          />
        ) : (
          <View
            style={[
              styles.bizYourJobSheetPhotoHeroImg,
              styles.bizYourJobSheetPhotoHeroPlaceholder,
              { borderColor: `${accent}40` },
            ]}
          >
            <LocationStyleIconBox
              variant="hero"
              icon="person"
              colors={accentToGradient(accent)}
            />
          </View>
        )}
      </View>
      <View style={styles.bizYourJobSheetCustomer}>
        <View style={styles.bizYourJobSheetCustomerText}>
          <Text style={styles.bizYourJobSheetCustomerLabel}>Customer</Text>
          <Text style={styles.bizYourJobSheetCustomerName} numberOfLines={2}>
            {job.customer_name || 'Customer'}
          </Text>
        </View>
      </View>
      <ScrollView style={styles.bizYourJobSheetScroll} showsVerticalScrollIndicator={false}>
        {job.assigned_valeter_name ? (
          <View style={styles.bizYourJobSheetRow}>
            <LocationStyleIconBox
              variant="inline"
              icon="person-outline"
              colors={accentToGradient(accent)}
            />
            <Text style={styles.bizYourJobSheetLabel}>Car Care Pro</Text>
            <View style={styles.bizYourJobSheetValeterValueWrap}>
              {job.assigned_valeter_photo ? (
                <Image
                  source={{ uri: job.assigned_valeter_photo }}
                  style={styles.bizYourJobSheetValeterAvatar}
                  resizeMode="cover"
                />
              ) : null}
              <Text style={styles.bizYourJobSheetValue}>{job.assigned_valeter_name}</Text>
            </View>
          </View>
        ) : null}
        {job.scheduled_at ? (
          <View style={styles.bizYourJobSheetRow}>
            <LocationStyleIconBox
              variant="inline"
              icon="calendar-outline"
              colors={accentToGradient(accent)}
            />
            <Text style={styles.bizYourJobSheetLabel}>Scheduled</Text>
            <Text style={styles.bizYourJobSheetValue}>
              {new Date(job.scheduled_at).toLocaleString('en-GB', {
                day: 'numeric',
                month: 'short',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
              })}
            </Text>
          </View>
        ) : null}
        {formatBusinessJobVehicle(job) ? (
          <View style={styles.bizYourJobSheetRow}>
            <LocationStyleIconBox
              variant="inline"
              icon="car-sport-outline"
              colors={accentToGradient(accent)}
            />
            <Text style={styles.bizYourJobSheetLabel}>Vehicle</Text>
            <Text style={styles.bizYourJobSheetValue}>{formatBusinessJobVehicle(job)}</Text>
          </View>
        ) : null}
        {job.location_address ? (
          <View style={styles.bizYourJobSheetRow}>
            <LocationStyleIconBox
              variant="inline"
              icon="location-outline"
              colors={accentToGradient(accent)}
            />
            <Text style={styles.bizYourJobSheetLabel}>Address</Text>
            <Text style={styles.bizYourJobSheetValue}>{job.location_address}</Text>
          </View>
        ) : null}
        <View style={styles.bizYourJobSheetRow}>
          <LocationStyleIconBox
            variant="inline"
            icon="wallet-outline"
            colors={accentToGradient(accent)}
          />
          <Text style={styles.bizYourJobSheetLabel}>Price</Text>
          <Text style={[styles.bizYourJobSheetValue, styles.bizYourJobSheetPrice, { color: accent }]}>
            £{Number(job.price || 0).toFixed(2)}
          </Text>
        </View>
      </ScrollView>
      <View style={styles.bizYourJobSheetActions}>
        <View style={styles.bizYourJobSheetActionRow}>
          <TouchableOpacity
            style={[styles.bizYourJobSheetCloseBtn, { borderColor: `${accent}50` }]}
            onPress={() => {
              void hapticFeedback('light');
              setSelectedDashboardJob(null);
            }}
            activeOpacity={0.85}
          >
            <Text style={[styles.bizYourJobSheetCloseBtnText, { color: accent }]}>Close</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.bizYourJobSheetCloseBtn, { borderColor: `${accent}50` }]}
            onPress={() => {
              void hapticFeedback('light');
              const id = job.id;
              setSelectedDashboardJob(null);
              router.push({ pathname: '/business/bookings/[id]', params: { id } } as any);
            }}
            activeOpacity={0.85}
          >
            <Text style={[styles.bizYourJobSheetCloseBtnText, { color: accent }]}>Full details</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.bizYourJobSheetActionRow}>
          <TouchableOpacity
            style={[
              styles.bizYourJobSheetViewBtn,
              {
                backgroundColor: accent,
                opacity: canOpenLiveTracking(
                  job.scheduled_at,
                  job.status
                )
                  ? 1
                  : 0.45,
              },
            ]}
            onPress={() => {
              void hapticFeedback('light');
              if (
                !canOpenLiveTracking(
                  job.scheduled_at,
                  job.status
                )
              ) {
                Alert.alert(
                  'Tracking unavailable',
                  ['completed', 'cancelled'].includes(
                    String(job.status).toLowerCase()
                  )
                    ? 'This booking has ended.'
                    : 'Live tracking unlocks 30 minutes before the scheduled start.'
                );
                return;
              }
              const id = job.id;
              setSelectedDashboardJob(null);
              router.push({ pathname: '/business/bookings/tracking', params: { bookingId: id } } as any);
            }}
            activeOpacity={0.85}
          >
            <GradientIconBox
              icon="navigate"
              borderless
              boxSize={28}
              size={17}
              borderRadius={10}
              colors={['#FFFFFF', '#FFFFFF']}
            />
            <Text style={styles.bizYourJobSheetViewBtnText}>Live tracking</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.bizYourJobSheetViewBtn,
              {
                backgroundColor: 'transparent',
                borderWidth: 1.5,
                borderColor: `${accent}55`,
                opacity: jobSheetChatOk ? 1 : 0.45,
              },
            ]}
            onPress={() => {
              void hapticFeedback('light');
              if (!jobSheetChatOk) {
                Alert.alert(
                  'Messaging locked',
                  'For completed jobs, messaging unlocks when the customer sends a message.'
                );
                return;
              }
              const id = job.id;
              setSelectedDashboardJob(null);
              router.push({ pathname: '/business/bookings/chat', params: { id } } as any);
            }}
            activeOpacity={0.85}
          >
            <LocationStyleIconBox
              variant="inline"
              icon="chatbubble-ellipses"
              colors={accentToGradient(accent)}
            />
            <Text style={[styles.bizYourJobSheetViewBtnText, { color: accent }]}>Message</Text>
          </TouchableOpacity>
        </View>
      </View>
    </>
  );

  return (
    <View style={styles.container}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />
      <SafeAreaView style={styles.container} edges={['top', 'bottom']}>

      <AppHeader
        title={businessName || 'Business Overview'}
        subtitle={headerSubtitle}
        accountType="business"
        showBack={false}
        variant="dashboard"
        dashboardFlat
        businessName={businessName}
        businessAddress={businessAddress}
        businessRating={stats.averageRating}
        showOnlineStatus={true}
        onlineStatusAnim={livePulseAnim}
        profilePicture={profilePicture || undefined}
        todayRevenue={stats.todayRevenue}
        todayJobs={stats.todayJobs}
        lastJob={lastJob ? lastJob.time : null}
        isOnline={anyLocationOpen}
        AnimatedCounter={AnimatedCounter}
        scrollY={scrollY}
        enableScrollAnimation
        rightAction={
          <GradientNotificationBell
            count={notificationCount}
            onPress={async () => {
              await hapticFeedback('light');
              setShowNotificationDropdown(true);
            }}
          />
        }
      />

      <View
        style={[
          styles.scrollClipWrapper,
          {
            marginTop: DASHBOARD_HEADER_HEIGHT,
            marginBottom: 0,
          },
        ]}
      >
        <Animated.ScrollView
          style={styles.scrollView}
          showsVerticalScrollIndicator={false}
          onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], {
            useNativeDriver: false,
          })}
          scrollEventThrottle={32}
          contentContainerStyle={[
            styles.scrollContent,
            {
              paddingTop: 16,
              paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 24,
              paddingHorizontal: 12,
            },
          ]}
        >
        {/* Daily stats + recent jobs — same structure as valeter dashboard */}
        {isOrgUser && organizationId ? renderDailyStats() : null}

        {/* Active bookings — same data as Bookings tab; tap section to open sheet */}
        {(liveBookings.length > 0 || nextBooking) && renderActiveBookings()}

        {/* Metrics strip: only when there are no recent jobs (Quick actions → Metrics + /business/key-metrics) */}
        {isOrgUser && organizationId && combinedDashboardJobs.length === 0 ? renderMetrics() : null}

        {/* Locations Summary - Enhanced */}
        <Animated.View style={[styles.section, { opacity: fadeAnim }]}>
          <DashboardGlassSection palette="business" tone="panel">
          <View style={styles.sectionHeader}>
            <View style={styles.sectionTitleWithIcon}>
              <LocationStyleIconBox variant="inline" icon="location" preset="sky" />
              <Text style={styles.sectionTitle}>Your Locations</Text>
            </View>
            <TouchableOpacity
              onPress={async () => {
                await hapticFeedback('light');
                router.push('/business/locations');
              }}
            >
              <Text style={styles.viewAllText}>View All</Text>
            </TouchableOpacity>
          </View>

          {renderLocations()}
          </DashboardGlassSection>
        </Animated.View>
        </Animated.ScrollView>
      </View>

      <Modal
        visible={locationScopeSheetVisible}
        transparent
        animationType="slide"
        statusBarTranslucent
        onRequestClose={() => !applyingScope && setLocationScopeSheetVisible(false)}
      >
        <Pressable
          style={styles.locationScopeBackdrop}
          onPress={() => !applyingScope && setLocationScopeSheetVisible(false)}
        >
          {renderLocationScopeSheet()}
        </Pressable>
      </Modal>

      <Modal
        visible={!!selectedDashboardJob}
        transparent
        animationType="slide"
        onRequestClose={() => setSelectedDashboardJob(null)}
      >
        <View style={styles.bizYourJobSheetContainer}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setSelectedDashboardJob(null)}>
            <BlurView intensity={40} tint="dark" style={StyleSheet.absoluteFill} />
          </Pressable>
          <View style={[styles.bizYourJobSheet, { paddingBottom: Math.max(insets.bottom, 24) }]} pointerEvents="box-none">
            {selectedDashboardJob ? renderJobSheet(selectedDashboardJob) : null}
          </View>
        </View>
      </Modal>

      <BusinessNotificationDropdown
        visible={showNotificationDropdown}
        onClose={() => setShowNotificationDropdown(false)}
        organizationId={organizationId}
      />

      <ActiveBookingsSheet
        visible={showActiveBookingsSheet}
        onClose={() => setShowActiveBookingsSheet(false)}
        bookings={liveBookings}
        onRefresh={refreshLiveBookings}
        onViewAll={() => router.push('/business/bookings/activity')}
      />
      </SafeAreaView>
    </View>
  );
}

// Shared horizontal card size and spacing for Metrics strip and Your Locations
const HORIZONTAL_CARD_WIDTH = width * 0.79;
const HORIZONTAL_CARD_MAX_WIDTH = 290;
const HORIZONTAL_CARD_MIN_HEIGHT = 100;
const HORIZONTAL_CARD_PADDING = 16;
const HORIZONTAL_CARD_RADIUS = 14;
const HORIZONTAL_CARD_GAP = 12;
const HORIZONTAL_SCROLL_PADDING_RIGHT = 24;

const styles = StyleSheet.create({
  container: { flex: 1 },

  scrollClipWrapper: {
    flex: 1,
    overflow: 'hidden',
  },
  scrollView: { flex: 1 },
  scrollContent: { paddingVertical: 16, paddingBottom: 40 },

  businessShortcutGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  businessShortcutTileWrap: {
    width: '48%',
    minWidth: 0,
  },
  businessShortcutTile: {
    minHeight: 88,
    borderRadius: 20,
    borderWidth: 0,
    backgroundColor: 'rgba(10, 25, 41, 0.10)',
    overflow: 'hidden',
    paddingHorizontal: 14,
    paddingVertical: 14,
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 1,
  },
  businessShortcutTileGlow: {
    ...StyleSheet.absoluteFill,
    backgroundColor: 'rgba(255,255,255,0.02)',
  },
  businessShortcutTileLabel: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '800',
    letterSpacing: -0.1,
    marginTop: 8,
  },

  dashboardGlassInnerFrame: {
    paddingTop: 12,
    paddingBottom: 12,
    paddingHorizontal: 12,
  },

  // Bookings — live bookings (LinkedIn-style section)
  bookingsBlock: { marginBottom: SECTION_GAP },
  bookingsCardStack: { gap: 12 },
  // Customer-style active booking card (same as customer dashboard)
  // Active booking card with map + status ring (premium gamified)
  activeBookingCardWrap: { marginBottom: 0 },
  activeBookingCard: {
    borderRadius: 22,
    overflow: 'hidden',
    backgroundColor: 'rgba(10,25,41,0.52)',
    borderWidth: 0.6,
    borderColor: 'rgba(125,211,252,0.16)',
    shadowColor: '#0A1929',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.14,
    shadowRadius: 10,
    elevation: 4,
  },
  activeBookingCardGlow: {
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
  },
  activeBookingMapContainer: {
    height: 200,
    position: 'relative',
    overflow: 'hidden',
  },
  activeBookingMapMarker: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.5)',
  },
  activeBookingCardOverlayWrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    overflow: 'hidden',
  },
  activeBookingCardOverlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingBottom: 50,
    gap: 14,
  },
  activeBookingRingWrap: {
    width: 80,
    height: 80,
    alignItems: 'center',
    justifyContent: 'center',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 6,
  },
  activeBookingCardContent: { flex: 1, minWidth: 0 },
  activeBookingLiveChip: {
    alignSelf: 'flex-start',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 9,
    paddingVertical: 4,
    borderRadius: 8,
    marginBottom: 6,
    backgroundColor: 'rgba(16,185,129,0.3)',
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.5)',
  },
  activeBookingLiveDot: {
    width: 5,
    height: 5,
    borderRadius: 3,
    backgroundColor: '#10B981',
  },
  activeBookingLiveText: {
    color: 'rgba(255,255,255,0.98)',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 0.8,
  },
  activeBookingCardTitle: {
    color: 'rgba(255,255,255,0.98)',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.35,
    marginBottom: 2,
  },
  activeBookingCardSubtitle: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 0.1,
  },
  activeBookingCardCustomer: {
    color: 'rgba(255,255,255,0.72)',
    fontSize: 12,
    fontWeight: '600',
    marginTop: 4,
    letterSpacing: 0.05,
  },
  activeBookingTrackPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.95)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.4)',
    marginTop: 8,
    alignSelf: 'flex-start',
  },
  activeBookingTrackPillText: {
    color: '#0A1929',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  activeBookingBottomRow: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    minHeight: 50,
    overflow: 'hidden',
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.15)',
  },
  activeBookingBottomRowInner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    flex: 1,
    zIndex: 1,
  },
  activeBookingPriceWrap: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  activeBookingPrice: {
    color: 'rgba(255,255,255,0.98)',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  activeBookingCta: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  activeBookingCtaText: { color: SKY, fontSize: 14, fontWeight: '700' },
  bookingSheetCardOuter: {
    ...BUSINESS_SHEET_CARD,
    position: 'relative',
    borderWidth: 0.6,
    borderColor: 'rgba(125,211,252,0.16)',
    shadowColor: '#7DD3FC',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 6,
    elevation: 2,
  },
  bookingSheetCardOverlay: {
    backgroundColor: BOOKING_SHEET_DARK_OVERLAY,
    borderRadius: 16,
  },
  bookingRowCard: {
    borderRadius: 16,
    overflow: 'hidden',
    padding: 14,
    position: 'relative',
    borderWidth: 0.6,
    borderColor: 'rgba(125,211,252,0.14)',
    backgroundColor: 'rgba(10,25,41,0.22)',
  },
  bookingRowCardInner: { gap: 8 },
  bookingRowCardBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 10,
    backgroundColor: 'rgba(107,114,128,0.2)',
  },
  bookingRowCardBadgeText: { color: '#E5E7EB', fontSize: 11, fontWeight: '600' },
  bookingRowCardService: { color: 'rgba(249,250,251,0.7)', fontSize: 13, fontWeight: '500' },
  bookingMetaText: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 11,
    fontWeight: '500',
    flex: 1,
  },

  // Metrics (horizontal strip when no recent jobs)
  metricsSection: { marginBottom: 16 },
  metricsScrollContainer: {
    paddingRight: HORIZONTAL_SCROLL_PADDING_RIGHT,
  },
  metricCardHorizontal: {
    width: HORIZONTAL_CARD_WIDTH,
    maxWidth: HORIZONTAL_CARD_MAX_WIDTH,
    minHeight: 154,
    borderRadius: HORIZONTAL_CARD_RADIUS,
    overflow: 'hidden',
    padding: HORIZONTAL_CARD_PADDING,
    marginRight: HORIZONTAL_CARD_GAP,
    borderWidth: 0.6,
    borderColor: 'rgba(125,211,252,0.12)',
    shadowColor: '#7DD3FC',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.03,
    shadowRadius: 6,
    elevation: 2,
    backgroundColor: 'rgba(10,25,41,0.2)',
  },
  metricCardContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  metricRingPlate: {
    width: 120,
    height: 120,
    borderRadius: 60,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.22,
    shadowRadius: 12,
    elevation: 6,
  },
  metricRingWrap: {
    width: 108,
    height: 108,
    alignItems: 'center',
    justifyContent: 'center',
  },
  metricRingCenterOverlay: {
    position: 'absolute',
    width: 108,
    height: 108,
    alignItems: 'center',
    justifyContent: 'center',
  },
  metricRingCenterMain: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '800',
  },
  metricRingCenterSub: {
    color: 'rgba(249,250,251,0.55)',
    fontSize: 11,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.4,
    marginTop: 2,
  },
  metricBody: {
    flex: 1,
    minWidth: 0,
  },
  metricTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 4,
  },
  metricTitle: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
  },
  metricSubtext: {
    color: 'rgba(249,250,251,0.58)',
    fontSize: 12,
    lineHeight: 16,
    fontWeight: '600',
  },
  metricTrendRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 10,
  },
  metricTrend: {
    color: 'rgba(249,250,251,0.75)',
    fontSize: 13,
    fontWeight: '700',
  },
  metricTrendUp: {
    color: '#10B981',
  },

  // Section Styles
  sectionTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  sectionTitleWithIcon: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  sectionTitle: {
    ...textStyles.sectionTitle,
    color: '#F9FAFB',
    fontSize: 17,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  viewAllText: {
    color: BUSINESS_PRIMARY,
    fontSize: 13,
    fontWeight: '600',
  },

  // Live Pill

  // Locations
  section: { marginBottom: SECTION_GAP },
  locationsScrollContainer: { paddingLeft: 2, paddingRight: HORIZONTAL_SCROLL_PADDING_RIGHT },
  locationCard: {
    width: HORIZONTAL_CARD_WIDTH,
    maxWidth: HORIZONTAL_CARD_MAX_WIDTH,
    minHeight: HORIZONTAL_CARD_MIN_HEIGHT,
    marginRight: HORIZONTAL_CARD_GAP,
    borderRadius: HORIZONTAL_CARD_RADIUS,
    overflow: 'hidden',
    padding: HORIZONTAL_CARD_PADDING,
    borderWidth: 0.6,
    borderColor: 'rgba(125,211,252,0.12)',
    shadowColor: '#7DD3FC',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.03,
    shadowRadius: 5,
    elevation: 2,
    backgroundColor: 'rgba(10,25,41,0.2)',
  },
  locationContent: {
    gap: 10,
  },
  locationHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  locationIconWrapper: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: `${BUSINESS_PRIMARY}25`,
    justifyContent: 'center',
    alignItems: 'center',
  },
  locationStatusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 6,
    backgroundColor: 'rgba(107,114,128,0.2)',
  },
  locationStatusLive: {
    backgroundColor: 'rgba(16,185,129,0.15)',
  },
  locationStatusDot: {
    width: 5,
    height: 5,
    borderRadius: 2.5,
    backgroundColor: '#10B981',
  },
  locationStatusText: {
    color: '#F9FAFB',
    fontSize: 10,
    fontWeight: '700',
  },
  locationInfo: {
    gap: 8,
  },
  locationName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: -0.1,
  },
  locationStats: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    flexWrap: 'wrap',
  },
  locationStatWithIcon: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
  },
  locationStat: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 11,
    fontWeight: '600',
  },
  locationStatSeparator: {
    color: 'rgba(249,250,251,0.4)',
    fontSize: 11,
  },
  locationNextBooking: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 11,
    fontWeight: '500',
  },
  locationPerformanceWrap: {
    marginTop: 6,
  },
  locationPerformancePill: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(16,185,129,0.15)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    gap: 4,
  },
  locationPerformanceText: {
    color: '#10B981',
    fontSize: 10,
    fontWeight: '700',
  },

  emptyCard: {
    borderRadius: 20,
    overflow: 'hidden',
    padding: 24,
    borderWidth: 0.6,
    borderColor: 'rgba(125,211,252,0.12)',
    shadowColor: '#7DD3FC',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.02,
    shadowRadius: 6,
    elevation: 1,
    backgroundColor: 'rgba(10,25,41,0.2)',
  },
  emptyContent: {
    alignItems: 'center',
    gap: 12,
  },
  emptyTitle: {
    ...textStyles.emptyTitle,
    color: '#F9FAFB',
    marginTop: 12,
  },
  emptyText: {
    ...textStyles.bodySmall,
    color: 'rgba(249,250,251,0.7)',
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 8,
  },
  addButton: {
    borderRadius: 16,
    overflow: 'hidden',
    marginTop: 8,
  },
  addButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    paddingHorizontal: 22,
  },
  addButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '800',
  },

  locationScopeBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.48)',
    justifyContent: 'flex-end',
  },
  locationScopeSheet: {
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    paddingHorizontal: 22,
    paddingTop: 10,
    paddingBottom: 28,
    maxHeight: '78%',
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.22)',
    backgroundColor: 'transparent',
  },
  locationScopeHandle: {
    width: 40,
    height: 5,
    borderRadius: 3,
    alignSelf: 'center',
    marginBottom: 16,
  },
  locationScopeTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 8,
  },
  locationScopeSubtitle: {
    color: 'rgba(249,250,251,0.65)',
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 18,
  },
  locationScopeAllBtn: {
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1.5,
    marginBottom: 16,
  },
  locationScopeAllBtnInner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingVertical: 16,
    paddingHorizontal: 14,
    zIndex: 1,
  },
  locationScopeAllBtnText: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
  },
  locationScopeDividerLabel: {
    color: 'rgba(249,250,251,0.45)',
    fontSize: 12,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.6,
    marginBottom: 10,
  },
  locationScopeList: {
    maxHeight: 220,
    marginBottom: 14,
  },
  locationScopeListContent: {
    gap: 8,
    paddingBottom: 4,
  },
  locationScopeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 14,
    paddingHorizontal: 14,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.16)',
    backgroundColor: 'rgba(255,255,255,0.07)',
  },
  locationScopeRowText: { flex: 1, minWidth: 0 },
  locationScopeRowTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
  },
  locationScopeRowSub: {
    color: 'rgba(249,250,251,0.5)',
    fontSize: 12,
    marginTop: 2,
  },
  locationScopeConfirmBtn: {
    borderRadius: 18,
    overflow: 'hidden',
    paddingVertical: 16,
    alignItems: 'center',
    marginBottom: 10,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  locationScopeConfirmText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
  locationScopeCancelBtn: {
    alignItems: 'center',
    paddingVertical: 10,
  },
  locationScopeCancelText: {
    color: 'rgba(249,250,251,0.65)',
    fontSize: 15,
    fontWeight: '600',
  },
  locationScopeApplying: {
    ...StyleSheet.absoluteFill,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(10,25,41,0.4)',
  },

  /* Valeter-parity: daily stats + horizontal recent jobs */
  bizDailyStatsWrap: { marginBottom: 14 },
  bizDailyStatsCard: {
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 0.6,
    backgroundColor: 'rgba(10,25,41,0.16)',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 5,
    elevation: 1,
  },
  bizDailyStatsGlow: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 1.5,
    zIndex: 2,
    opacity: 0.6,
  },
  bizDailyStatsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    paddingVertical: 14,
    paddingHorizontal: 12,
    zIndex: 2,
  },
  bizDailyStatItem: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bizDailyStatIconWrap: {
    width: 42,
    height: 42,
    borderRadius: 14,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 6,
  },
  bizDailyStatValue: {
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 2,
  },
  bizDailyStatLabel: {
    fontSize: 11,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 0.3,
  },
  bizDailyPresenceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginTop: 14,
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 16,
    borderWidth: 0.6,
  },
  bizDailyPresenceRowOpen: {
    backgroundColor: 'rgba(16,185,129,0.1)',
    borderColor: 'rgba(16,185,129,0.24)',
  },
  bizDailyPresenceRowClosed: {
    backgroundColor: 'rgba(239,68,68,0.1)',
    borderColor: 'rgba(239,68,68,0.24)',
  },
  bizDailyPresenceDot: {
    width: 14,
    height: 14,
    borderRadius: 999,
    marginRight: 12,
    shadowColor: '#000',
    shadowOpacity: 0.18,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 1 },
    elevation: 2,
  },
  bizDailyPresenceTextWrap: {
    flex: 1,
    minWidth: 0,
  },
  bizDailyPresenceTitle: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '800',
    letterSpacing: 0.15,
  },
  bizDailyPresenceSubtitle: {
    color: 'rgba(255,255,255,0.72)',
    fontSize: 11,
    fontWeight: '600',
    marginTop: 2,
    lineHeight: 14,
  },
  bizDailyPresenceChevron: {
    width: 24,
    height: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.14)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  bizDailyStatDivider: {
    width: 1,
    height: 32,
    borderRadius: 1,
  },

  bizYourJobSheetContainer: { flex: 1, justifyContent: 'flex-end' },
  bizYourJobSheet: {
    backgroundColor: '#0F2847',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingHorizontal: 24,
    paddingTop: 12,
    maxHeight: '85%',
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  bizYourJobSheetHandle: {
    width: 40,
    height: 5,
    backgroundColor: 'rgba(255,255,255,0.25)',
    borderRadius: 3,
    alignSelf: 'center',
    marginBottom: 20,
  },
  bizYourJobSheetHeader: { marginBottom: 12 },
  bizYourJobSheetPhotoHero: { alignItems: 'center', marginBottom: 14 },
  bizYourJobSheetPhotoHeroImg: {
    width: 96,
    height: 96,
    borderRadius: 48,
    borderWidth: 2,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  bizYourJobSheetPhotoHeroPlaceholder: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  bizYourJobSheetTitle: { color: '#F9FAFB', fontSize: 20, fontWeight: '800', marginBottom: 4 },
  bizYourJobSheetSubtitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    flexWrap: 'wrap',
    marginTop: 2,
  },
  bizYourJobSheetSubtitle: { fontSize: 14, fontWeight: '600' },
  bizYourJobSheetCustomer: {
    marginBottom: 18,
    paddingVertical: 12,
    paddingHorizontal: 14,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 16,
  },
  bizYourJobSheetCustomerText: { flex: 1, minWidth: 0 },
  bizYourJobSheetCustomerLabel: { color: '#94A3B8', fontSize: 12, fontWeight: '600', marginBottom: 4 },
  bizYourJobSheetCustomerName: { color: '#F9FAFB', fontSize: 17, fontWeight: '700' },
  bizYourJobSheetScroll: { maxHeight: 280, marginBottom: 16 },
  bizYourJobSheetRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 14,
  },
  bizYourJobSheetLabel: { color: '#94A3B8', fontSize: 14, fontWeight: '600', minWidth: 90 },
  bizYourJobSheetValeterValueWrap: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8 },
  bizYourJobSheetValeterAvatar: { width: 20, height: 20, borderRadius: 10 },
  bizYourJobSheetValue: { flex: 1, color: '#F9FAFB', fontSize: 15, fontWeight: '600' },
  bizYourJobSheetPrice: { fontSize: 18, fontWeight: '800' },
  bizYourJobSheetActions: { gap: 12 },
  bizYourJobSheetActionRow: { flexDirection: 'row', gap: 12, alignItems: 'stretch' },
  bizYourJobSheetCloseBtn: {
    flex: 1,
    paddingVertical: 16,
    borderRadius: 14,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bizYourJobSheetCloseBtnText: { fontSize: 16, fontWeight: '700' },
  bizYourJobSheetViewBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    borderRadius: 14,
    minWidth: 0,
  },
  bizYourJobSheetViewBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});
