// app/business/locations/[id].tsx
import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  ActivityIndicator,
  TouchableOpacity,
  ActionSheetIOS,
  TextInput,
  Alert,
  Dimensions,
  Platform,
  KeyboardAvoidingView,
  Switch,
  Pressable,
  Image,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons, type IconGlyphName } from '../../../src/components/shared/ChromeGlyph';
import { useLocalSearchParams, router } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system/legacy';

import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';

import GlassCard from '../../../src/components/booking/GlassCard';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import { colors } from '../../../src/constants/colors';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import LoadingScreen from '../../../src/components/LoadingScreen';
import ContinueCTAButton from '../../../src/components/ui/ContinueCTAButton';
import { LocationStyleIconBox } from '../../../src/components/shared/GradientIconBox';
import InfoIconButton from '../../../src/components/shared/InfoIconButton';
import { SERVICE_CATEGORY_ICON, getServiceIcon } from '../../../src/constants/serviceIcons';
import { accentToGradient } from '../../../src/utils/accentGradient';

const { width } = Dimensions.get('window');
const BG = colors.BG;
const SKY = colors.SKY;
const LIGHT_TEXT = '#F9FAFB';
const MUTED_TEXT = 'rgba(249,250,251,0.7)';

type AnyRow = Record<string, any>;

interface LocationRow {
  id: string;
  organization_id: string;
  name: string;
  address: string | null;
  latitude: number | null;
  longitude: number | null;
  status?: string | null;
  is_active?: boolean | null;
  created_at?: string;

  // images (dynamic)
  header_image_url?: string | null;
  photo_url?: string | null;
  image_url?: string | null;

  // optional columns
  eco_washing?: boolean | null;
  detailing_offered?: boolean | null;
  detailing_menu?: any; // jsonb
  site_type?: string | null;
  custom_services?: unknown;
}

interface LocationServiceRow {
  id: string;
  location_id: string;
  service_name: string;
  is_enabled: boolean;
  price: number | null;
  price_by_size?: Record<string, number | null> | null;
  duration_minutes: number | null;
  created_at?: string;
}


const TIER_DEFS = [
  { key: 'bronze', name: 'Bronze Wash', color: '#CD7F32', tier: 'BRONZE', group: 'standard' as const },
  { key: 'silver', name: 'Silver Wash', color: '#C0C0C0', tier: 'SILVER', group: 'standard' as const },
  { key: 'gold', name: 'Gold Wash', color: '#FFD700', tier: 'GOLD', group: 'standard' as const },
  { key: 'platinum', name: 'Platinum Wash', color: '#E5E4E2', tier: 'PLATINUM', group: 'standard' as const },
  { key: 'emerald', name: 'Diamond Wash', color: '#22D3EE', tier: 'DIAMOND', group: 'standard' as const },
  { key: 'repair-headlight', name: 'Headlight Restoration', color: '#FB923C', tier: 'REPAIR', group: 'repairs' as const },
  { key: 'repair-scratch', name: 'Scratch Removal', color: '#FB923C', tier: 'REPAIR', group: 'repairs' as const },
  { key: 'repair-paint-chip', name: 'Paint Chip Repair', color: '#FB923C', tier: 'REPAIR', group: 'repairs' as const },
  { key: 'repair-trim', name: 'Trim Restoration', color: '#FB923C', tier: 'REPAIR', group: 'repairs' as const },
  { key: 'repair-leather', name: 'Leather Repair', color: '#FB923C', tier: 'REPAIR', group: 'repairs' as const },
  { key: 'maintenance-check', name: 'Maintenance Check', color: '#FB923C', tier: 'REPAIR', group: 'repairs' as const },
].map((t) => ({ ...t, icon: getServiceIcon(t.key, t.name) }));

type TierDescription = { description: string; includes: string[]; bestFor: string };

const STANDARD_TIER_DESCRIPTIONS: Record<string, TierDescription> = {
  bronze: {
    description: 'A quick refresh for your vehicle. Choose either an exterior hand wash or a light interior clean including vacuuming and surface wipe-downs.',
    includes: ['Your choice: exterior hand wash OR light interior clean', 'Exterior option: safe wash, wheels, rinse, dry, exterior glass', 'Interior option: vacuum, surface wipe-downs, light cabin tidy', 'Fast and affordable'],
    bestFor: 'Maintenance between deeper valets.',
  },
  silver: {
    description: 'A balanced clean inside and out. Includes an exterior hand wash plus a light interior refresh with vacuuming, surface cleaning, and a tidy finish.',
    includes: ['Exterior hand wash, wheels and dry', 'Interior vacuum (seats, carpets, boot)', 'Dashboard, console and trims wiped', 'Interior and exterior glass cleaned', 'Tyre dressing and light spray wax where included'],
    bestFor: 'Regular maintenance and everyday cleanliness.',
  },
  gold: {
    description: 'A full interior deep clean designed to restore your vehicle from the inside out. Includes deep vacuuming, stain removal, upholstery and carpet treatment.',
    includes: ['Deep vacuum throughout cabin and boot', 'Stain treatment and upholstery / carpet care', 'Seats, carpets and mats shampooed or refreshed', 'All interior surfaces, trims and touchpoints detailed', 'Leather cleaned and dressed where applicable', 'Headliner and hard-to-reach areas addressed', 'Interior glass and finishes refreshed', 'Air freshener to finish'],
    bestFor: 'Vehicles needing a deep interior restoration.',
  },
  platinum: {
    description: 'A complete interior and exterior valet with enhanced attention to detail. Includes a thorough wash, detailed interior cleaning, and finishing touches.',
    includes: ['Thorough exterior wash, wheels and arches', 'Interior deep clean aligned with Gold cabin standard', 'Trims, glass and surfaces finished to a high standard', 'Enhanced attention to detail inside and out', 'Finishing touches for a clean, fresh presentation'],
    bestFor: 'Full vehicle refresh in one visit.',
  },
  emerald: {
    description: 'Our highest level service delivering a full vehicle transformation. Deep interior clean, detailed exterior wash, and premium finishing.',
    includes: ['Deep interior clean plus detailed exterior wash', 'Paint decontamination and enhancement where appropriate', 'Upholstery / leather care and interior sanitisation', 'Machine or hand finishing for gloss and clarity', 'Long-lasting protection or sealant where included', 'Fine detailing on edges, trims and glass', 'Premium finish aimed at near showroom presentation'],
    bestFor: 'Premium care and a near showroom finish.',
  },
};

const REPAIR_TIER_DESCRIPTIONS: Record<string, TierDescription> = {
  'repair-headlight': {
    description:
      'Restore cloudy or yellowed headlights for clearer vision and a like-new look.',
    includes: [
      'Inspection and prep of lens condition',
      'Oxidation and yellowing removal',
      'Polish and clarity refinement',
      'UV sealant to slow future hazing',
    ],
    bestFor: 'Cloudy, yellowed, or hazy headlights.',
  },
  'repair-scratch': {
    description:
      'Targeted reduction or removal of light scratches and swirl marks in clear coat.',
    includes: [
      'Paint inspection under good light',
      'Safe wash and area decontamination',
      'Machine or hand correction where appropriate',
      'Refinement and gloss restoration',
    ],
    bestFor: 'Light clear-coat scratches, wash swirls, and minor scuffs.',
  },
  'repair-paint-chip': {
    description:
      'Clean, fill and touch in small stone chips and minor paint damage to protect metal and improve appearance.',
    includes: [
      'Chip area cleaning and degreasing',
      'Rust/contamination treatment if present',
      'Color-matched touch-in where available',
      'Sealed finish to reduce spreading',
    ],
    bestFor: 'Small chips, motorway strikes, and parking nicks.',
  },
  'repair-trim': {
    description:
      'Restore faded or greying exterior plastic trim, bumpers and mouldings with deep clean and UV dressing.',
    includes: [
      'Trim cleaned and stripped of old dressings',
      'Oxidation and fade treatment',
      'OEM-style satin/gloss finish',
      'UV protection to slow future fading',
    ],
    bestFor: 'Door strips, mirror caps, bumper inserts, and side mouldings.',
  },
  'repair-leather': {
    description:
      'Minor leather repairs for scuffs, small tears and color wear for a neater cabin.',
    includes: [
      'Leather cleaned and assessed',
      'Small tear/scuff repair where suitable',
      'Color touch-up and blend',
      'Conditioning for softness and protection',
    ],
    bestFor: 'Worn bolsters, cat scratches, scuffs, and small splits.',
  },
  'maintenance-check': {
    description:
      'An all-in-one maintenance inspection covering coolant, oil level, tyre tread, lights, and washer fluid so customers get a clear vehicle health check.',
    includes: [
      'Coolant level inspection',
      'Oil level check',
      'Tyre tread and visible condition check',
      'Light bulbs / exterior lights inspection',
      'Screen wash / washer fluid check and top-up advice',
    ],
    bestFor: 'Customers wanting a quick vehicle health check while the car is in for service.',
  },
};

const DETAILING_TIER_DESCRIPTIONS: Record<string, TierDescription> = {
  'ceramic-coating': {
    description:
      'Long-lasting paint protection with a premium ceramic layer that bonds to your paint.',
    includes: [
      'Full exterior wash and paint decontamination',
      'Paint preparation and light correction if needed',
      'Professional ceramic coating application',
      'Hydrophobic finish and enhanced gloss',
    ],
    bestFor: 'Long-term paint protection and easier maintenance.',
  },
  'machine-polishing': {
    description:
      'Professional paint correction to reduce swirls, light scratches and restore gloss.',
    includes: [
      'Wash and decontamination before correction',
      'Multi-stage machine polish where required',
      'Gloss and clarity restoration',
      'Protective finish applied',
    ],
    bestFor: 'Dull paintwork and visible swirl marks.',
  },
  'soft-top-restoration': {
    description:
      'Specialist care for fabric and vinyl convertible roofs to restore finish and weather resistance.',
    includes: [
      'Gentle roof clean and stain treatment',
      'Mould/mildew treatment where needed',
      'Conditioning and colour restoration',
      'Water-repellent and UV protection',
    ],
    bestFor: 'Convertibles with faded or weathered soft tops.',
  },
  'mould-removal': {
    description:
      'Targeted removal of mould and odours from the cabin, vents, and affected interior surfaces.',
    includes: [
      'Inspection of vents and cabin filter areas',
      'Air-con sanitisation treatment',
      'Mould treatment on interior surfaces',
      'Odour neutralisation finish',
    ],
    bestFor: 'Musty cabins, visible mould, or damp-related odours.',
  },
};

const TIER_DESCRIPTIONS: Record<string, TierDescription> = {
  ...STANDARD_TIER_DESCRIPTIONS,
  ...REPAIR_TIER_DESCRIPTIONS,
  ...DETAILING_TIER_DESCRIPTIONS,
};

type VehicleSizeKey = 'small' | 'medium' | 'large' | 'xl' | 'xxl';
const VEHICLE_SIZE_DEFS: Array<{ key: VehicleSizeKey; label: string }> = [
  { key: 'small', label: 'Small' },
  { key: 'medium', label: 'Medium' },
  { key: 'large', label: 'Large' },
  { key: 'xl', label: 'XL' },
  { key: 'xxl', label: 'XXL (HGV)' },
];

type DetailingKey = 'ceramic-coating' | 'machine-polishing' | 'soft-top-restoration' | 'mould-removal';

type DetailingItem = {
  key: DetailingKey;
  name: string;
  enabled: boolean;
  price: number | null;
  prices?: Record<VehicleSizeKey, number | null>;
  duration_minutes?: number | null;
};

const DETAILING_SIZE_DEFS: Array<{ key: VehicleSizeKey; label: string; icon: IconGlyphName }> = [
  { key: 'small', label: 'Small (Base)', icon: 'car-outline' },
  { key: 'medium', label: 'Medium', icon: 'car-sport-outline' },
  { key: 'large', label: 'Large', icon: 'bus-outline' },
  { key: 'xl', label: 'XL', icon: 'subway-outline' },
  { key: 'xxl', label: 'XXL (HGV)', icon: 'train-outline' },
];

const defaultDetailingPrices = (): Record<VehicleSizeKey, number | null> =>
  ({ small: null, medium: null, large: null, xl: null, xxl: null });

function getDetailingPrices(item: DetailingItem): Record<VehicleSizeKey, number | null> {
  if (item.prices && Object.keys(item.prices).length > 0) return item.prices;
  const p = item.price != null && Number.isFinite(item.price) ? item.price : null;
  return { small: p, medium: p, large: p, xl: p, xxl: p };
}

const DETAILING_DEFS: Array<{ key: DetailingKey; name: string; icon: IconGlyphName }> = [
  { key: 'ceramic-coating', name: 'Ceramic Coating', icon: getServiceIcon('ceramic-coating') },
  { key: 'machine-polishing', name: 'Machine Polishing', icon: getServiceIcon('machine-polishing') },
  { key: 'soft-top-restoration', name: 'Soft Top Restoration', icon: getServiceIcon('soft-top-restoration') },
  { key: 'mould-removal', name: 'Mould & Odour Removal', icon: getServiceIcon('mould-removal') },
];

const STORAGE_BUCKET = 'location-images';
const IMAGE_MEDIA_TYPES: any =
  (ImagePicker as any)?.MediaType?.Images ? [(ImagePicker as any).MediaType.Images] : undefined;

// Opening hours (new)
type DayKey = 'mon' | 'tue' | 'wed' | 'thu' | 'fri' | 'sat' | 'sun';
const DAYS: Array<{ key: DayKey; label: string; idx: number }> = [
  { key: 'mon', label: 'Mon', idx: 0 },
  { key: 'tue', label: 'Tue', idx: 1 },
  { key: 'wed', label: 'Wed', idx: 2 },
  { key: 'thu', label: 'Thu', idx: 3 },
  { key: 'fri', label: 'Fri', idx: 4 },
  { key: 'sat', label: 'Sat', idx: 5 },
  { key: 'sun', label: 'Sun', idx: 6 },
];

type OpeningHourRow = {
  id: string;
  location_id: string;
  day_of_week: number; // 0=Mon ... 6=Sun
  is_open: boolean;
  open_time: string | null;  // "09:00"
  close_time: string | null; // "17:00"
  slot_minutes: number | null; // 30
  created_at?: string;
};

type OpeningHourState = {
  isOpen: boolean;
  openTime: string;  // "09:00"
  closeTime: string; // "17:00"
  slotMinutes: number; // 30
};

const defaultOpeningHours = (): Record<DayKey, OpeningHourState> => ({
  mon: { isOpen: true, openTime: '09:00', closeTime: '17:00', slotMinutes: 30 },
  tue: { isOpen: true, openTime: '09:00', closeTime: '17:00', slotMinutes: 30 },
  wed: { isOpen: true, openTime: '09:00', closeTime: '17:00', slotMinutes: 30 },
  thu: { isOpen: true, openTime: '09:00', closeTime: '17:00', slotMinutes: 30 },
  fri: { isOpen: true, openTime: '09:00', closeTime: '17:00', slotMinutes: 30 },
  sat: { isOpen: false, openTime: '09:00', closeTime: '13:00', slotMinutes: 30 },
  sun: { isOpen: false, openTime: '09:00', closeTime: '13:00', slotMinutes: 30 },
});

// ---------- helpers ----------
const SERVICE_TAB_META = {
  standard: { label: 'Standard', icon: SERVICE_CATEGORY_ICON.wash },
  repairs: { label: 'Repairs', icon: SERVICE_CATEGORY_ICON.repair },
  detailing: { label: 'Detailing', icon: SERVICE_CATEGORY_ICON.detailing },
} as const;

const toNumberOrZero = (n: any): number => {
  if (typeof n === 'string') return Number(n);
  if (typeof n === 'number') return n;
  return 0;
};

const money = (n: any) => {
  const v = toNumberOrZero(n);
  if (!Number.isFinite(v)) return '0.00';
  return v.toFixed(2);
};

function isMissingColumnErr(err: any) {
  return typeof err?.code === 'string' && err.code.startsWith('PGRST');
}

function isMissingPriceBySizeColumnErr(err: any) {
  const msg = String(err?.message || '').toLowerCase();
  return msg.includes('price_by_size') && msg.includes('does not exist');
}

function normalizeServiceName(s: any) {
  return String(s || '').trim().toLowerCase();
}

function safeBool(v: any, fallback = false) {
  if (v === true) return true;
  if (v === false) return false;
  return fallback;
}







function buildDefaultDetailingItems(): DetailingItem[] {
  return DETAILING_DEFS.map((d) => ({
    key: d.key,
    name: d.name,
    enabled: false,
    price: null,
    prices: defaultDetailingPrices(),
    duration_minutes: null,
  }));
}

function parseOptionalNumber(v: any): number | null {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function coerceDetailingItem(it: any, fallbackName: string, k: DetailingKey): DetailingItem {
  const legacy = parseOptionalNumber(it?.price);
  const nextPrices = defaultDetailingPrices();
  DETAILING_SIZE_DEFS.forEach(({ key: sizeKey }) => {
    const v = it?.prices?.[sizeKey];
    nextPrices[sizeKey] = v != null && Number.isFinite(Number(v)) ? Number(v) : legacy;
  });
  const duration = parseOptionalNumber(it?.duration_minutes);
  return {
    key: k,
    name: String(it?.name || fallbackName),
    enabled: !!it?.enabled,
    price: legacy,
    prices: nextPrices,
    duration_minutes: duration === null ? null : Math.max(0, Math.round(duration)),
  };
}

function coerceDetailingMenu(raw: any): DetailingItem[] {
  const defaults = buildDefaultDetailingItems();
  const map = new Map<DetailingKey, DetailingItem>();
  defaults.forEach((d) => map.set(d.key, { ...d }));

  const items = raw?.items;
  if (Array.isArray(items)) {
    for (const it of items) {
      let key: string = it?.key;
      if (!key) continue;
      if (key === 'ceramic') key = 'ceramic-coating';
      if (!map.has(key as DetailingKey)) continue;
      const k = key as DetailingKey;
      map.set(k, coerceDetailingItem(it, map.get(k)!.name, k));
    }
  }

  return Array.from(map.values());
}

const base64ToUint8Array = (base64: string) => {
  const bin = globalThis.atob ? globalThis.atob(base64) : Buffer.from(base64, 'base64').toString('binary');
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.codePointAt(i) ?? 0;
  return bytes;
};

const guessContentType = (uri: string) => {
  const lower = (uri || '').toLowerCase();
  if (lower.endsWith('.png')) return 'image/png';
  if (lower.endsWith('.webp')) return 'image/webp';
  if (lower.endsWith('.heic') || lower.endsWith('.heif')) return 'image/heic';
  return 'image/jpeg';
};

const getFileExtFromUri = (uri: string) => {
  const clean = (uri || '').split('?')[0];
  const extRaw = (clean.split('.').pop() || 'jpg').toLowerCase();
  return extRaw === 'jpg' ? 'jpeg' : extRaw;
};

const pad2 = (n: number) => String(n).padStart(2, '0');

const isValidHHMM = (s: string) => /^([01]\d|2[0-3]):([0-5]\d)$/.test((s || '').trim());

const hhmmToMinutes = (s: string) => {
  if (!isValidHHMM(s)) return null;
  const [h, m] = s.split(':').map(Number);
  return h * 60 + m;
};

const minutesToHHMM = (mins: number) => {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return `${pad2(h)}:${pad2(m)}`;
};

const buildSlots = (openHHMM: string, closeHHMM: string, slotMinutes: number) => {
  const open = hhmmToMinutes(openHHMM);
  const close = hhmmToMinutes(closeHHMM);
  if (open === null || close === null) return [];
  if (slotMinutes <= 0) return [];
  if (close <= open) return [];
  const out: string[] = [];
  for (let t = open; t + slotMinutes <= close; t += slotMinutes) {
    out.push(minutesToHHMM(t));
  }
  return out;
};

export default function BusinessLocationDetails() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme: businessTheme } = useAccountTheme();

  const textMain = businessTheme.textPrimary ?? LIGHT_TEXT;
  const muted = businessTheme.textSecondary ?? MUTED_TEXT;

  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const nameInputRef = useRef<TextInput>(null);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [detailsDirty, setDetailsDirty] = useState(false);

  const [location, setLocation] = useState<LocationRow | null>(null);
  const [locationImageUrl, setLocationImageUrl] = useState<string | null>(null);
  const [uploadingLocationImage, setUploadingLocationImage] = useState(false);

  // editable fields
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [isActive, setIsActive] = useState(true);

  // repairs + detailing
  const [ecoWashing, setEcoWashing] = useState(false);
  const [detailingOffered, setDetailingOffered] = useState(false);
  const [detailingItems, setDetailingItems] = useState<DetailingItem[]>(buildDefaultDetailingItems());
  // services (tiers)
  const [services, setServices] = useState<LocationServiceRow[]>([]);
  const [servicesTableOk, setServicesTableOk] = useState(true);
  const [seedingTiers, setSeedingTiers] = useState(false);

  // opening hours (new)
  const [openingHoursTableOk, setOpeningHoursTableOk] = useState(true);
  const [openingHours, setOpeningHours] = useState<Record<DayKey, OpeningHourState>>(defaultOpeningHours());
  const [savingHours, setSavingHours] = useState(false);

  const [activeServiceTab, setActiveServiceTab] = useState<'standard' | 'repairs' | 'detailing'>('standard');
  const [activeTab, setActiveTab] = useState<'details' | 'services' | 'hours'>('details');
  const [siteType, setSiteType] = useState<'unit' | 'mobile'>('unit');

  const organizationId = useMemo(() => user?.organizationId ?? null, [user?.organizationId]);
  const isOrgUser = (user?.userType ?? '').toLowerCase() === 'organization';
  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 500, useNativeDriver: true }).start();
  }, []);

  useEffect(() => {
    if (!id || !isOrgUser || !organizationId) {
      setLoading(false);
      return;
    }
    void loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, isOrgUser, organizationId]);

  const loadAll = async () => {
    try {
      setLoading(true);
      await Promise.all([loadLocation(), loadServicesAndEnsureTiers(), loadOpeningHours()]);
    } catch (e) {
      console.error('[LocationDetails] loadAll error:', e);
    } finally {
      setLoading(false);
    }
  };

  const loadLocation = async () => {
    if (!id || !organizationId) return;

    const { data, error } = await supabase.from('car_wash_locations').select('*').eq('id', id).maybeSingle();
    if (error) throw error;

    if (!data) {
      setLocation(null);
      return;
    }

    if ((data as AnyRow).organization_id !== organizationId) {
      setLocation(null);
      Alert.alert('Access denied', 'That location does not belong to this business.');
      router.back();
      return;
    }

    const row = data as LocationRow;
    setLocation(row);

    setName(row.name ?? '');
    setAddress(row.address ?? '');
    setIsActive(row.is_active === null || row.is_active === undefined ? row.status !== 'inactive' : !!row.is_active);

    setEcoWashing(safeBool((row as AnyRow).eco_washing, false));
    setDetailingOffered(safeBool((row as AnyRow).detailing_offered, false));
    setDetailingItems(coerceDetailingMenu((row as AnyRow).detailing_menu));
    setLocationImageUrl(
      (row as AnyRow).photo_url ||
        (row as AnyRow).image_url ||
        (row as AnyRow).header_image_url ||
        null
    );

    const st = String((row as AnyRow).site_type ?? 'unit').toLowerCase();
    setSiteType(st === 'mobile' ? 'mobile' : 'unit');
    setDetailsDirty(false);

  };

  const updateLocationPatch = async (patch: Record<string, any>) => {
    if (!location?.id) return { ok: false as const };

    const { error } = await supabase.from('car_wash_locations').update(patch).eq('id', location.id);
    if (!error) return { ok: true as const };

    if (isMissingColumnErr(error) && /column/i.test(String(error?.message || ''))) {
      Alert.alert(
        'DB update needed',
        "Your 'car_wash_locations' table is missing one of the new columns.\n\nRun this SQL in Supabase:\n\n" +
          "ALTER TABLE public.car_wash_locations\n" +
          "  ADD COLUMN IF NOT EXISTS eco_washing boolean NOT NULL DEFAULT false;\n\n" +
          "ALTER TABLE public.car_wash_locations\n" +
          "  ADD COLUMN IF NOT EXISTS detailing_offered boolean NOT NULL DEFAULT false;\n\n" +
          "ALTER TABLE public.car_wash_locations\n" +
          "  ADD COLUMN IF NOT EXISTS detailing_menu jsonb NULL;\n\n" +
          "ALTER TABLE public.car_wash_locations\n" +
          "  ADD COLUMN IF NOT EXISTS site_type text NOT NULL DEFAULT 'unit';\n",
      );
      return { ok: false as const };
    }

    Alert.alert('Error', error.message || 'Failed to update location');
    return { ok: false as const };
  };

  const uploadLocationImage = async (uri: string) => {
    if (!location?.id || !organizationId) return;
    const ext = getFileExtFromUri(uri);
    const mime = guessContentType(uri);
    const fileName = `location_${location.id}_${Date.now()}.${ext || 'jpg'}`;
    const storagePath = `locations/${organizationId}/${location.id}/${fileName}`;
    const base64 = await FileSystem.readAsStringAsync(uri, { encoding: 'base64' as any });
    const bytes = base64ToUint8Array(base64);

    const { data, error } = await supabase.storage.from(STORAGE_BUCKET).upload(storagePath, bytes, {
      contentType: mime,
      upsert: true,
    });

    if (error) throw error;
    const { data: pub } = supabase.storage.from(STORAGE_BUCKET).getPublicUrl(data?.path ?? storagePath);
    const publicUrl = pub?.publicUrl ?? null;
    if (!publicUrl) throw new Error('Failed to generate a public URL for the location image.');

    const patch = {
      photo_url: publicUrl,
      image_url: publicUrl,
      header_image_url: publicUrl,
    };
    const next = await updateLocationPatch(patch);
    if (next.ok) {
      setLocationImageUrl(publicUrl);
      setLocation((prev) => (prev ? { ...prev, ...patch } : prev));
    }
  };

  const takeLocationPhoto = async () => {
    if (uploadingLocationImage) return;
    try {
      setUploadingLocationImage(true);
      const perm = await ImagePicker.requestCameraPermissionsAsync();
      if (perm.status !== 'granted') {
        Alert.alert('Permission Required', 'Camera permission is required to take a location photo.');
        return;
      }

      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: IMAGE_MEDIA_TYPES,
        allowsEditing: true,
        aspect: [16, 9],
        quality: 0.85,
      });

      if (!result.canceled && result.assets?.[0]?.uri) {
        await uploadLocationImage(result.assets[0].uri);
      }
    } catch (e: any) {
      console.error('[LocationDetails] takeLocationPhoto error:', e);
      Alert.alert('Upload failed', e?.message || 'Failed to take location photo.');
    } finally {
      setUploadingLocationImage(false);
    }
  };

  const pickLocationImage = async () => {
    if (uploadingLocationImage) return;
    try {
      setUploadingLocationImage(true);
      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (perm.status !== 'granted') {
        Alert.alert('Permission Required', 'Gallery permission is required to select a location image.');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: IMAGE_MEDIA_TYPES,
        allowsEditing: true,
        aspect: [16, 9],
        quality: 0.85,
      });

      if (!result.canceled && result.assets?.[0]?.uri) {
        await uploadLocationImage(result.assets[0].uri);
      }
    } catch (e: any) {
      console.error('[LocationDetails] pickLocationImage error:', e);
      Alert.alert('Upload failed', e?.message || 'Failed to select a location image.');
    } finally {
      setUploadingLocationImage(false);
    }
  };

  const handleLocationImageUpload = async () => {
    await hapticFeedback('light');
    if (uploadingLocationImage) return;

    if (Platform.OS === 'ios') {
      ActionSheetIOS.showActionSheetWithOptions(
        {
          title: 'Location image',
          message: 'Choose how you want to add a photo for this location',
          options: ['Cancel', 'Take Photo', 'Choose from Gallery'],
          cancelButtonIndex: 0,
          userInterfaceStyle: 'dark',
        },
        async (buttonIndex) => {
          if (buttonIndex === 1) await takeLocationPhoto();
          if (buttonIndex === 2) await pickLocationImage();
        }
      );
    } else {
      Alert.alert('Location image', 'Choose how you want to add a photo for this location', [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Take Photo', onPress: () => { void takeLocationPhoto(); } },
        { text: 'Choose from Gallery', onPress: () => { void pickLocationImage(); } },
      ]);
    }
  };


  const defaultTierSizePricing = (): Record<VehicleSizeKey, number | null> => ({
    small: null,
    medium: null,
    large: null,
    xl: null,
    xxl: null,
  });

  const getTierSizePricing = (row: LocationServiceRow) => {
    const base = defaultTierSizePricing();
    const raw = row?.price_by_size && typeof row.price_by_size === 'object' ? row.price_by_size : null;

    VEHICLE_SIZE_DEFS.forEach(({ key }) => {
      const value = raw?.[key];
      if (value === null || value === undefined) {
        base[key] = key === 'small' ? row.price ?? null : null;
      } else {
        const num = Number(value);
        base[key] = Number.isFinite(num) ? num : null;
      }
    });

    return base;
  };

  const getTierFromPrice = (row: LocationServiceRow) => {
    const values = Object.values(getTierSizePricing(row)).filter(
      (v): v is number => v !== null && Number.isFinite(Number(v))
    );
    if (values.length === 0) return null;
    return Math.min(...values);
  };





  // ---------- Opening hours: load + save ----------
  const openingHoursSQL = () =>
    [
      `-- Create opening hours table`,
      `CREATE TABLE IF NOT EXISTS public.location_opening_hours (`,
      `  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),`,
      `  location_id uuid NOT NULL REFERENCES public.car_wash_locations(id) ON DELETE CASCADE,`,
      `  day_of_week int NOT NULL CHECK (day_of_week >= 0 AND day_of_week <= 6), -- 0=Mon ... 6=Sun`,
      `  is_open boolean NOT NULL DEFAULT true,`,
      `  open_time text NULL,  -- "09:00"`,
      `  close_time text NULL, -- "17:00"`,
      `  slot_minutes int NOT NULL DEFAULT 30,`,
      `  created_at timestamptz NOT NULL DEFAULT now(),`,
      `  UNIQUE (location_id, day_of_week)`,
      `);`,
    ].join('\n');

  const loadOpeningHours = async () => {
    if (!id) return;

    try {
      const { data, error } = await supabase
        .from('location_opening_hours')
        .select('*')
        .eq('location_id', id)
        .order('day_of_week', { ascending: true });

      if (error) {
        console.warn('[LocationDetails] opening hours table not available:', error.message || error);
        setOpeningHoursTableOk(false);
        return;
      }

      setOpeningHoursTableOk(true);

      const rows = (data || []) as OpeningHourRow[];
      const next = defaultOpeningHours();

      for (const d of DAYS) {
        const row = rows.find((r) => r.day_of_week === d.idx);
        if (!row) continue;

        const openTime = row.open_time && isValidHHMM(row.open_time) ? row.open_time : next[d.key].openTime;
        const closeTime = row.close_time && isValidHHMM(row.close_time) ? row.close_time : next[d.key].closeTime;
        const slotMinutes = Number.isFinite(Number(row.slot_minutes)) ? Math.max(5, Number(row.slot_minutes)) : 30;

        next[d.key] = {
          isOpen: !!row.is_open,
          openTime,
          closeTime,
          slotMinutes,
        };
      }

      setOpeningHours(next);
    } catch (e) {
      console.error('[LocationDetails] loadOpeningHours error:', e);
      setOpeningHoursTableOk(false);
    }
  };

  const validateOpeningHours = () => {
    for (const d of DAYS) {
      const s = openingHours[d.key];
      if (!s.isOpen) continue;

      if (!isValidHHMM(s.openTime) || !isValidHHMM(s.closeTime)) {
        return `${d.label}: please use HH:MM (e.g. 09:00)`;
      }

      const open = hhmmToMinutes(s.openTime)!;
      const close = hhmmToMinutes(s.closeTime)!;
      if (close <= open) {
        return `${d.label}: close time must be after open time`;
      }

      if (!Number.isFinite(s.slotMinutes) || s.slotMinutes < 5 || s.slotMinutes > 240) {
        return `${d.label}: slot minutes must be between 5 and 240`;
      }
    }
    return null;
  };

  const saveOpeningHours = async () => {
    if (!id) return;

    const errMsg = validateOpeningHours();
    if (errMsg) {
      Alert.alert('Opening hours', errMsg);
      return;
    }

    try {
      setSavingHours(true);
      await hapticFeedback('light');

      // Upsert each day
      const payload = DAYS.map((d) => {
        const s = openingHours[d.key];
        return {
          location_id: id,
          day_of_week: d.idx,
          is_open: !!s.isOpen,
          open_time: s.isOpen ? s.openTime : null,
          close_time: s.isOpen ? s.closeTime : null,
          slot_minutes: s.slotMinutes || 30,
        };
      });

      const { error } = await supabase.from('location_opening_hours').upsert(payload, {
        onConflict: 'location_id,day_of_week',
      });

      if (error) {
        console.error('[LocationDetails] saveOpeningHours error:', error);

        // Common when table doesn't exist yet
        Alert.alert('DB update needed', `Run this SQL in Supabase:\n\n${openingHoursSQL()}`);
        setOpeningHoursTableOk(false);
        return;
      }

      await hapticFeedback('success');
      Alert.alert('Saved', 'Opening hours updated.');
      await loadOpeningHours();
    } catch (e: any) {
      console.error('[LocationDetails] saveOpeningHours crash:', e);
      Alert.alert('Error', e?.message || 'Failed to save opening hours');
    } finally {
      setSavingHours(false);
    }
  };

  // ---------- Save location ----------
  const handleSaveLocation = async () => {
    if (!location?.id) return;

    if (!name.trim()) {
      Alert.alert('Missing info', 'Location name is required.');
      return;
    }

    try {
      setSaving(true);
      await hapticFeedback('medium');

      const nextStatus = isActive ? 'active' : 'inactive';

      const patch: AnyRow = {
        name: name.trim(),
        address: address.trim() ? address.trim() : null,
        status: nextStatus,
        is_active: isActive,
        eco_washing: ecoWashing,
        detailing_offered: detailingOffered,
        detailing_menu: { items: detailingItems },
        site_type: siteType,
      };

      const { error } = await supabase.from('car_wash_locations').update(patch).eq('id', location.id);
      if (error) throw error;

      await loadLocation();
      setDetailsDirty(false);
      Alert.alert('Saved', 'Location updated.');
    } catch (e: any) {
      console.error('[LocationDetails] save error:', e);
      Alert.alert('Error', e?.message || 'Failed to save location');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteLocation = () => {
    if (!location?.id) return;

    Alert.alert('Delete location', 'Are you sure? This cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          try {
            setSaving(true);
            await hapticFeedback('medium');

            const { error } = await supabase.from('car_wash_locations').delete().eq('id', location.id);
            if (error) throw error;

            Alert.alert('Deleted', 'Location removed.');
            router.back();
          } catch (e: any) {
            console.error('[LocationDetails] delete error:', e);
            Alert.alert('Error', e?.message || 'Failed to delete location');
          } finally {
            setSaving(false);
          }
        },
      },
    ]);
  };

  // ---------- Services ----------
  const loadServicesAndEnsureTiers = async () => {
    if (!id) return;

    const { data, error } = await supabase
      .from('location_services')
      .select('*')
      .eq('location_id', id)
      .order('created_at', { ascending: false });

    if (error) {
      console.warn('[LocationDetails] location_services not available:', error.message);
      setServicesTableOk(false);
      setServices([]);
      return;
    }

    setServicesTableOk(true);

    const rows = (data || []) as LocationServiceRow[];
    const ensured = await ensureTierRows(rows);
    setServices(ensured);
  };

  const ensureTierRows = async (rows: LocationServiceRow[]) => {
    if (!id) return rows;

    const byName = new Map<string, LocationServiceRow>();
    rows.forEach((r) => byName.set(normalizeServiceName(r.service_name), r));

    const missingDefs = TIER_DEFS.filter((t) => !byName.has(normalizeServiceName(t.name)));
    if (missingDefs.length === 0) {
      return rows.filter((r) => TIER_DEFS.some((t) => normalizeServiceName(t.name) === normalizeServiceName(r.service_name)));
    }

    try {
      setSeedingTiers(true);

      const inserts = missingDefs.map((t) => ({
        location_id: id,
        service_name: t.name,
        is_enabled: true,
        price: null,
        duration_minutes: null,
      }));

      const ins = await supabase.from('location_services').insert(inserts);
      if (ins.error) {
        console.error('[LocationDetails] ensureTierRows insert error:', ins.error);
        return rows.filter((r) => TIER_DEFS.some((t) => normalizeServiceName(t.name) === normalizeServiceName(r.service_name)));
      }

      const { data: next, error: nextErr } = await supabase.from('location_services').select('*').eq('location_id', id);
      if (nextErr) throw nextErr;

      const nextRows = (next || []) as LocationServiceRow[];
      return nextRows.filter((r) => TIER_DEFS.some((t) => normalizeServiceName(t.name) === normalizeServiceName(r.service_name)));
    } finally {
      setSeedingTiers(false);
    }
  };

  const getTierRow = (tierName: string) =>
    services.find((s) => normalizeServiceName(s.service_name) === normalizeServiceName(tierName)) || null;

  const updateTierRow = async (row: LocationServiceRow, patch: Partial<LocationServiceRow>) => {
    if (!servicesTableOk) return;

    try {
      const { error } = await supabase.from('location_services').update(patch).eq('id', row.id);
      if (error) throw error;

      setServices((prev) => prev.map((s) => (s.id === row.id ? { ...s, ...patch } : s)));
      return true;
    } catch (e: any) {
      console.error('[LocationDetails] updateTierRow error:', e);
      if (isMissingPriceBySizeColumnErr(e)) {
        Alert.alert(
          'DB update needed',
          "To save Small/Medium/Large/XL prices, add this column in Supabase:\n\nALTER TABLE public.location_services ADD COLUMN IF NOT EXISTS price_by_size jsonb NULL;"
        );
      } else {
        Alert.alert('Error', e?.message || 'Failed to update tier');
      }
      return false;
    }
  };


  const updateDetailingItem = async (key: DetailingKey, patch: Partial<DetailingItem>) => {
    const next = detailingItems.map((it) => (it.key === key ? { ...it, ...patch } : it));
    setDetailingItems(next);
    await updateLocationPatch({ detailing_menu: { items: next } });
  };


  const renderTierCard = (tier: (typeof TIER_DEFS)[number]) => {
    const row = getTierRow(tier.name);

    if (!row) {
      return (
        <View key={tier.key} style={[styles.svcPriceRow, { borderColor: businessTheme.glassBorder }]}>
          <View style={styles.svcPriceRowTop}>
            <View style={styles.svcPriceRowLead}>
              <LocationStyleIconBox variant="inline" icon={tier.icon} colors={accentToGradient(tier.color)} />
              <Text style={[styles.svcPriceRowTitle, { color: textMain }]} numberOfLines={1}>
                {tier.name}
              </Text>
            </View>
            <ActivityIndicator size="small" color={businessTheme.primary} />
          </View>
        </View>
      );
    }

    const tierFromPrice = getTierFromPrice(row);

    return (
      <View key={tier.key} style={[styles.svcPriceRow, { borderColor: businessTheme.glassBorder }]}>
        <View style={styles.svcPriceRowTop}>
          <Pressable
            onPress={() => void hapticFeedback('light')}
            style={styles.svcPriceRowLeadPressable}
            accessibilityRole="button"
            accessibilityLabel={`Edit ${tier.name} pricing`}
          >
            <View style={styles.svcPriceRowLead}>
              <LocationStyleIconBox variant="inline" icon={tier.icon} colors={accentToGradient(tier.color)} />
              <View style={styles.svcPriceRowTitles}>
                <View style={styles.svcPriceRowTitleLine}>
                  <Text style={[styles.svcPriceRowTitle, { color: textMain }]} numberOfLines={1}>
                    {tier.name}
                  </Text>
                  {TIER_DESCRIPTIONS[tier.key] ? (
                    <InfoIconButton
                      accentColor={tier.color}
                      onPress={() => void hapticFeedback('light')}
                    />
                  ) : null}
                  {tier.tier ? (
                    <View style={[styles.tierBadge, { backgroundColor: `${tier.color}40`, borderColor: tier.color }]}>
                      <Text style={styles.tierBadgeText}>{tier.tier}</Text>
                    </View>
                  ) : null}
                </View>
                <Text style={[styles.svcPriceRowSub, { color: muted }]}>
                  {tierFromPrice !== null ? `From £${money(tierFromPrice)}` : 'No prices set'}
                </Text>
              </View>
            </View>
          </Pressable>
          <View style={styles.svcPriceRowActions}>
            <Switch
              value={!!row.is_enabled}
              onValueChange={async (v) => {
                await hapticFeedback('light');
                void updateTierRow(row, { is_enabled: v });
              }}
              trackColor={{ false: 'rgba(255,255,255,0.15)', true: businessTheme.primary }}
              thumbColor={row.is_enabled ? '#FFFFFF' : '#9CA3AF'}
              ios_backgroundColor="rgba(255,255,255,0.15)"
            />
            <LocationStyleIconBox variant="inline" icon="chevron-forward" colors={accentToGradient(businessTheme.primary)} />
          </View>
        </View>
      </View>
    );
  };

  const renderDetailingCard = (def: (typeof DETAILING_DEFS)[number]) => {
    const item =
      detailingItems.find((x) => x.key === def.key) || {
        key: def.key,
        name: def.name,
        enabled: false,
        price: null,
        prices: defaultDetailingPrices(),
        duration_minutes: null,
      };

    const prices = getDetailingPrices(item);
    const numericPrices = Object.values(prices).filter((p): p is number => p != null && Number.isFinite(p)) as number[];
    const fromPrice = numericPrices.length > 0 ? Math.min(...numericPrices) : null;
    const amber = '#F59E0B';

    return (
      <View key={def.key} style={[styles.svcPriceRow, { borderColor: businessTheme.glassBorder }]}>
        <View style={styles.svcPriceRowTop}>
          <Pressable
            onPress={() => void hapticFeedback('light')}
            style={styles.svcPriceRowLeadPressable}
            accessibilityRole="button"
            accessibilityLabel={`Edit ${def.name} pricing`}
          >
            <View style={styles.svcPriceRowLead}>
              <LocationStyleIconBox variant="inline" icon={def.icon} preset="amber" />
              <View style={styles.svcPriceRowTitles}>
                <View style={styles.svcPriceRowTitleLine}>
                  <Text style={[styles.svcPriceRowTitle, { color: textMain }]} numberOfLines={2}>
                    {def.name}
                  </Text>
                  {TIER_DESCRIPTIONS[def.key] ? (
                    <InfoIconButton
                      accentColor={amber}
                      onPress={() => void hapticFeedback('light')}
                    />
                  ) : null}
                  <View style={[styles.tierBadge, { backgroundColor: 'rgba(245,158,11,0.22)', borderColor: amber }]}>
                    <Text style={styles.tierBadgeText}>DETAILING</Text>
                  </View>
                </View>
                <Text style={[styles.svcPriceRowSub, { color: muted }]}>
                  {fromPrice !== null ? `From £${money(fromPrice)}` : 'No prices set'}
                </Text>
              </View>
            </View>
          </Pressable>
          <View style={styles.svcPriceRowActions}>
            <Switch
              value={!!item.enabled}
              onValueChange={async (v) => {
                await hapticFeedback('light');
                await updateDetailingItem(def.key, { enabled: v });
              }}
              trackColor={{ false: 'rgba(255,255,255,0.15)', true: businessTheme.primary }}
              thumbColor={item.enabled ? '#FFFFFF' : '#9CA3AF'}
              ios_backgroundColor="rgba(255,255,255,0.15)"
            />
            <LocationStyleIconBox variant="inline" icon="chevron-forward" colors={accentToGradient(businessTheme.primary)} />
          </View>
        </View>
      </View>
    );
  };


  const renderDetailsTab = () => (
    <GlassCard style={{ ...styles.sectionCard, borderColor: businessTheme.glassBorder, marginTop: 0 }} accountType="business" variant="header">
      <View style={styles.sectionHeaderRow}>
        <Text style={[styles.sectionTitle, { color: textMain, marginBottom: 0 }]}>Business information</Text>
        <TouchableOpacity
          onPress={() => nameInputRef.current?.focus()}
          activeOpacity={0.85}
          style={styles.sectionEditPill}
        >
          <Ionicons name="pencil-outline" size={14} color="#F9FAFB" />
          <Text style={styles.sectionEditPillText}>Edit</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.infoFieldList}>
        <View style={styles.infoFieldRow}>
          <View style={styles.infoFieldLead}>
            <View style={styles.infoFieldIcon}>
              <Ionicons name="storefront-outline" size={18} color="#9CD8FF" />
            </View>
            <Text style={styles.infoFieldLabel}>Location name</Text>
          </View>
          <View style={styles.infoFieldValueWrap}>
            <TextInput
              ref={nameInputRef}
              value={name}
              onChangeText={(t) => {
                setName(t);
                setDetailsDirty(true);
              }}
              placeholder="e.g., Main Car Wash Hub"
              placeholderTextColor="rgba(249,250,251,0.45)"
              style={styles.infoFieldValue}
            />
          </View>
        </View>

        <View style={styles.infoFieldRow}>
          <View style={styles.infoFieldLead}>
            <View style={styles.infoFieldIcon}>
              <Ionicons name="location-outline" size={18} color="#9CD8FF" />
            </View>
            <Text style={styles.infoFieldLabel}>Address</Text>
          </View>
          <View style={[styles.infoFieldValueWrap, styles.infoFieldValueWrapMultiline]}>
            <TextInput
              value={address}
              onChangeText={(t) => {
                setAddress(t);
                setDetailsDirty(true);
              }}
              placeholder="Enter full address"
              placeholderTextColor="rgba(249,250,251,0.45)"
              style={[styles.infoFieldValue, styles.infoFieldValueMultiline]}
              multiline
              numberOfLines={3}
            />
          </View>
        </View>
      </View>

      <View style={styles.hubSectionDivider} />
      <Text style={[styles.hubSectionLabel, { color: muted }]}>Site type</Text>
      <Text style={[styles.miniText, { marginBottom: 12 }]}>
        Fixed unit = bays or forecourt customers visit. Mobile = this listing represents a roaming team (you can still set a base address for the map).
      </Text>
      <View style={styles.siteTypeRow}>
        <TouchableOpacity
          style={[
            styles.siteTypeChip,
            siteType === 'unit' && {
              backgroundColor: `${businessTheme.primary}30`,
              borderColor: businessTheme.primary,
            },
          ]}
          onPress={async () => {
            await hapticFeedback('light');
            setSiteType('unit');
            setDetailsDirty(true);
          }}
          activeOpacity={0.85}
        >
          <Ionicons name="cube-outline" size={26} color={LIGHT_TEXT} />
          <View style={styles.siteTypeChipTextWrap}>
            <Text style={styles.siteTypeChipText}>Fixed unit</Text>
            <Text style={styles.siteTypeChipSub}>Customers visit your location</Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.siteTypeChip,
            siteType === 'mobile' && {
              backgroundColor: `${businessTheme.primary}30`,
              borderColor: businessTheme.primary,
            },
          ]}
          onPress={async () => {
            await hapticFeedback('light');
            setSiteType('mobile');
            setDetailsDirty(true);
          }}
          activeOpacity={0.85}
        >
          <Ionicons name="car-sport-outline" size={26} color={LIGHT_TEXT} />
          <View style={styles.siteTypeChipTextWrap}>
            <Text style={styles.siteTypeChipText}>Mobile</Text>
            <Text style={styles.siteTypeChipSub}>You or your team travel to customers</Text>
          </View>
        </TouchableOpacity>
      </View>
      <TouchableOpacity
        onPress={handleDeleteLocation}
        disabled={saving}
        style={[styles.dangerBtn, { marginTop: 14 }, saving && { opacity: 0.7 }]}
        activeOpacity={0.85}
      >
        <View style={styles.dangerBtnInner}>
          <Ionicons name="trash-outline" size={18} color="#FFFFFF" />
          <Text style={styles.dangerBtnText}>Delete location</Text>
        </View>
      </TouchableOpacity>
    </GlassCard>
  );

  const renderServicesTab = () => (
    <View style={{ gap: 14 }}>
      <View style={[styles.sectionHeaderRow, { marginBottom: 4 }]}>
        <Text style={[styles.sectionTitle, { color: textMain }]}>Service catalogue</Text>
        <TouchableOpacity
          onPress={async () => {
        await hapticFeedback('light');
        void loadServicesAndEnsureTiers();
          }}
          style={styles.smallAddBtn}
          activeOpacity={0.85}
        >
          {seedingTiers ? <ActivityIndicator size="small" color={SKY} /> : <Ionicons name="refresh" size={18} color={SKY} />}
        </TouchableOpacity>
      </View>

      {!servicesTableOk ? (
        <GlassCard style={styles.card} accountType="business" variant="header">
          <View style={{ gap: 10 }}>
            <View style={styles.row}>
              <Ionicons name="information-circle-outline" size={18} color={SKY} />
              <Text style={styles.infoText}>
                Tier pricing isn’t available because <Text style={{ fontWeight: '900' }}>location_services</Text> table/policy isn’t accessible.
              </Text>
            </View>
            <Text style={styles.miniText}>If you want, I’ll generate the SQL + RLS for the location_services table.</Text>
          </View>
        </GlassCard>
      ) : (
        <View>
          <View style={[styles.hubCategoryRail, { borderColor: businessTheme.glassBorder, marginTop: 4 }]}>
            {(['standard', 'repairs', 'detailing'] as const).map((tab) => {
              const active = activeServiceTab === tab;
          const svcIcon = SERVICE_TAB_META[tab].icon;
              return (
                <Pressable
                  key={tab}
                  onPress={async () => {
                    await hapticFeedback('light');
                    setActiveServiceTab(tab);
                  }}
                  style={[
                    styles.hubCategorySegment,
                    active && {
                      backgroundColor: `${businessTheme.primary}2E`,
                      borderColor: businessTheme.primary,
                    },
                  ]}
                >
                  <LocationStyleIconBox
                    variant="inline"
                    icon={svcIcon}
                    colors={accentToGradient(active ? businessTheme.primary : 'rgba(148,163,184,0.95)')}
                  />
                  <Text
                    style={[
                      styles.hubCategoryLabel,
                      { color: muted },
                      active && { color: textMain, fontWeight: '800' },
                    ]}
                    numberOfLines={1}
                    adjustsFontSizeToFit
                    minimumFontScale={0.85}
                  >
                    {SERVICE_TAB_META[tab].label}
                  </Text>
                </Pressable>
              );
            })}
          </View>

          {activeServiceTab === 'detailing' ? (
            <>
              <View style={[styles.rowBetween, { marginBottom: 10 }]}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.label}>Detailing enabled</Text>
                  <Text style={styles.miniText}>Turn on to offer detailing services at this location.</Text>
                </View>
                <Switch
                  value={detailingOffered}
                  onValueChange={async (v) => {
                    await hapticFeedback('light');
                    setDetailingOffered(v);
                    await updateLocationPatch({ detailing_offered: v, detailing_menu: { items: detailingItems } });
                  }}
                  trackColor={{ false: 'rgba(255,255,255,0.15)', true: businessTheme.primary }}
                  thumbColor={detailingOffered ? '#FFFFFF' : '#9CA3AF'}
                  ios_backgroundColor="rgba(255,255,255,0.15)"
                />
              </View>

              <View style={{ gap: 12 }}>
                {DETAILING_DEFS.map(renderDetailingCard)}
              </View>

              <View style={{ height: 10 }} />

              <Text style={styles.miniText}>Set per-size pricing and duration for detailing options.</Text>
            </>
          ) : (
            <>
              <View style={{ gap: 12 }}>
                {TIER_DEFS.filter((tier) => tier.group === activeServiceTab).map(renderTierCard)}
              </View>

              <View style={{ height: 10 }} />

              <Text style={styles.miniText}>
                Set pricing for Small/Medium/Large/XL/XXL (HGV) vehicles plus duration per location.
              </Text>
            </>
          )}
        </View>
      )}
    </View>
  );

  const renderHoursTab = () => (
    <View style={{ gap: 14 }}>
      <View style={styles.sectionHeaderRow}>
        <Text style={[styles.sectionTitle, { color: textMain }]}>Opening hours</Text>
        <TouchableOpacity
          onPress={async () => {
        await hapticFeedback('light');
        void loadOpeningHours();
          }}
          style={styles.smallAddBtn}
          activeOpacity={0.85}
        >
          <Ionicons name="refresh" size={18} color={SKY} />
        </TouchableOpacity>
      </View>

      {!openingHoursTableOk ? (
        <GlassCard style={styles.card} accountType="business" variant="header">
          <View style={{ gap: 10 }}>
            <View style={styles.row}>
              <Ionicons name="information-circle-outline" size={18} color={SKY} />
              <Text style={styles.infoText}>
                Opening hours aren’t available because the <Text style={{ fontWeight: '900' }}>location_opening_hours</Text> table isn’t accessible.
              </Text>
            </View>
            <Text style={styles.miniText}>Run this SQL in Supabase to add it:</Text>
            <GlassCard style={{ padding: 12 }} accountType="business" variant="header">
              <Text style={[styles.miniText, { fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace' }]}>{openingHoursSQL()}</Text>
            </GlassCard>
          </View>
        </GlassCard>
      ) : (
        <View style={{ gap: 12 }}>
          {DAYS.map((d) => {
            const s = openingHours[d.key];
            const slots = s.isOpen ? buildSlots(s.openTime, s.closeTime, s.slotMinutes) : [];
            return (
              <View key={d.key} style={styles.hoursRow}>
                <View style={styles.hoursTop}>
                  <View style={styles.row}>
                    <View style={styles.dayPill}>
                      <Text style={styles.dayPillText}>{d.label}</Text>
                    </View>
                    <Text style={styles.label}>{s.isOpen ? 'Open' : 'Closed'}</Text>
                  </View>

                  <Switch
                    value={s.isOpen}
                    onValueChange={async (v) => {
                      await hapticFeedback('light');
                      setOpeningHours((prev) => ({ ...prev, [d.key]: { ...prev[d.key], isOpen: v } }));
                    }}
                  />
                </View>

                {s.isOpen ? (
                  <>
                    <View style={styles.hoursInputs}>
                      <View style={{ flex: 1 }}>
                        <Text style={styles.inlineLabel}>Open</Text>
                        <GlassCard style={styles.inlineInputCard} accountType="business" variant="header">
                          <TextInput
                            value={s.openTime}
                            onChangeText={(t) => setOpeningHours((prev) => ({ ...prev, [d.key]: { ...prev[d.key], openTime: t } }))}
                            placeholder="09:00"
                            placeholderTextColor="rgba(249,250,251,0.45)"
                            style={styles.inlineInput}
                            autoCapitalize="none"
                            autoCorrect={false}
                          />
                        </GlassCard>
                      </View>

                      <View style={{ flex: 1 }}>
                        <Text style={styles.inlineLabel}>Close</Text>
                        <GlassCard style={styles.inlineInputCard} accountType="business" variant="header">
                          <TextInput
                            value={s.closeTime}
                            onChangeText={(t) => setOpeningHours((prev) => ({ ...prev, [d.key]: { ...prev[d.key], closeTime: t } }))}
                            placeholder="17:00"
                            placeholderTextColor="rgba(249,250,251,0.45)"
                            style={styles.inlineInput}
                            autoCapitalize="none"
                            autoCorrect={false}
                          />
                        </GlassCard>
                      </View>

                      <View style={{ width: 110 }}>
                        <Text style={styles.inlineLabel}>Slot (min)</Text>
                        <GlassCard style={styles.inlineInputCard} accountType="business" variant="header">
                          <TextInput
                            value={String(s.slotMinutes)}
                            onChangeText={(t) => {
                              const n = Number((t || '').replace(/[^\d]/g, ''));
                              setOpeningHours((prev) => ({
                                ...prev,
                                [d.key]: { ...prev[d.key], slotMinutes: Number.isFinite(n) && n > 0 ? n : prev[d.key].slotMinutes },
                              }));
                            }}
                            placeholder="30"
                            placeholderTextColor="rgba(249,250,251,0.45)"
                            keyboardType="number-pad"
                            style={styles.inlineInput}
                          />
                        </GlassCard>
                      </View>
                    </View>

                    <View style={styles.slotPreviewRow}>
                      <View style={styles.serviceChip}>
                        <Text style={styles.serviceChipText}>Creates {slots.length} slots</Text>
                      </View>

                      {slots.length > 0 ? (
                        <Text style={[styles.miniText, { flex: 1, textAlign: 'right' }]} numberOfLines={1}>
                          {slots.slice(0, 4).join(', ')}
                          {slots.length > 4 ? ` …` : ''}
                        </Text>
                      ) : (
                        <Text style={[styles.miniText, { flex: 1, textAlign: 'right' }]}>Check times</Text>
                      )}
                    </View>
                  </>
                ) : null}
              </View>
            );
          })}
        </View>
      )}

      <View style={{ height: 14 }} />
      <ContinueCTAButton
        title="Save opening hours"
        onPress={saveOpeningHours}
        accentColor={businessTheme.primary}
        disabled={savingHours}
        loading={savingHours}
        style={styles.hubSaveCta}
        leading={<Ionicons name="time-outline" size={20} color={colors.textOnDarkPrimary} />}
      />
    </View>
  );

  const renderActiveTab = () => {
    if (activeTab === 'details') return renderDetailsTab();
    if (activeTab === 'services') return renderServicesTab();
    return renderHoursTab();
  };

  // ---------- UI guards ----------
  if (loading) {
    return <LoadingScreen message="Loading location…" />;
  }

  if (!location) {
    return (
      <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <View style={styles.loadingContainer}>
          <View style={styles.missingHeaderRow}>
            <TouchableOpacity onPress={() => router.back()} style={styles.missingHeaderBtn} activeOpacity={0.8}>
              <Ionicons name="close" size={20} color={businessTheme.primary} />
            </TouchableOpacity>
          </View>
          <Ionicons name="alert-circle-outline" size={36} color={SKY} style={{ opacity: 0.8 }} />
          <Text style={styles.loadingText}>Location not found.</Text>
          <ContinueCTAButton
            title="Go back"
            onPress={() => router.back()}
            accentColor={businessTheme.primary}
            style={{ marginTop: 12 }}
            showTrailingChevron={false}
          />
        </View>
      </SafeAreaView>
    );
  }

  return (
  <View style={styles.container}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />
      <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
        <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
          <Animated.ScrollView
            style={styles.scrollView}
            showsVerticalScrollIndicator={false}
            onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
            scrollEventThrottle={16}
            contentContainerStyle={[
              styles.scrollContentProfile,
              {
                paddingTop: 12,
                paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 164,
              },
            ]}
          >
            <Animated.View style={{ opacity: fadeAnim }}>
              <View style={styles.heroWrap}>
                <View style={styles.hero}>
                  {locationImageUrl ? (
                    <Image source={{ uri: locationImageUrl }} style={[StyleSheet.absoluteFill, styles.heroImg]} resizeMode="cover" />
                  ) : (
                    <LinearGradient
                      colors={['rgba(96,217,255,0.25)', 'rgba(37,99,235,0.45)', 'rgba(10,25,41,0.92)']}
                      style={StyleSheet.absoluteFill}
                    />
                  )}
                  <View style={styles.heroOverlay} pointerEvents="box-none">
                    <View style={styles.heroChromeRow} pointerEvents="box-none">
                      <TouchableOpacity onPress={() => router.back()} style={styles.heroChromeBtn} activeOpacity={0.8}>
                        <Ionicons name="arrow-back" size={20} color="#F9FAFB" />
                      </TouchableOpacity>
                      <TouchableOpacity
                        onPress={handleLocationImageUpload}
                        style={styles.heroPhotoBtn}
                        activeOpacity={0.85}
                        disabled={uploadingLocationImage}
                      >
                        {uploadingLocationImage ? (
                          <ActivityIndicator size="small" color="#F9FAFB" />
                        ) : (
                          <>
                            <Ionicons name="camera-outline" size={18} color="#F9FAFB" />
                            <Text style={styles.heroPhotoBtnText}>Edit photo</Text>
                          </>
                        )}
                      </TouchableOpacity>
                    </View>
                    <LinearGradient
                      colors={['rgba(0,0,0,0)', 'rgba(0,0,0,0.34)', 'rgba(0,0,0,0.82)']}
                      locations={[0, 0.72, 1]}
                      style={styles.heroBottomFade}
                    />
                    <View style={styles.heroBottom} pointerEvents="box-none">
                      <View style={[styles.heroStatusPill, { borderColor: isActive ? 'rgba(52,211,153,0.35)' : 'rgba(248,113,113,0.35)' }]}>
                        <View
                          style={[
                            styles.heroStatusDot,
                            { backgroundColor: isActive ? '#4ADE80' : '#F87171' },
                          ]}
                        />
                        <Text style={styles.heroStatusText}>{isActive ? 'Open' : 'Closed'}</Text>
                      </View>
                      <Text style={styles.heroTitle} numberOfLines={1}>
                        {name || location.name || 'Location'}
                      </Text>
                      <Text style={styles.heroSubtitle} numberOfLines={2}>
                        {address || location.address || 'Tap the image to add a single hero photo for this physical location.'}
                      </Text>
                    </View>
                  </View>
                </View>
              </View>

              <View style={[styles.hubCategoryRail, { borderColor: businessTheme.glassBorder }]}>
                {[
                  { key: 'details' as const, label: 'Details', icon: 'business-outline' as const },
                  { key: 'services' as const, label: 'Services', icon: SERVICE_CATEGORY_ICON.wash },
                  { key: 'hours' as const, label: 'Hours', icon: 'time-outline' as const },
                ].map((tab) => {
                  const active = activeTab === tab.key;
                  return (
                    <Pressable
                      key={tab.key}
                      onPress={async () => {
                        await hapticFeedback('light');
                        setActiveTab(tab.key);
                      }}
                      style={[
                        styles.hubCategorySegment,
                        active && {
                          backgroundColor: `${businessTheme.primary}22`,
                          borderColor: businessTheme.primary,
                        },
                      ]}
                    >
                      <View
                        style={[
                          styles.tabIconCircle,
                          active && {
                            backgroundColor: `${businessTheme.primary}2E`,
                            borderColor: businessTheme.primary,
                          },
                        ]}
                      >
                        <Ionicons name={tab.icon} size={19} color={active ? '#F9FAFB' : 'rgba(249,250,251,0.8)'} />
                      </View>
                      <Text
                        style={[
                          styles.hubCategoryLabel,
                          { color: muted },
                          active && { color: textMain, fontWeight: '800' },
                        ]}
                        numberOfLines={1}
                        adjustsFontSizeToFit
                        minimumFontScale={0.85}
                      >
                        {tab.label}
                      </Text>
                    </Pressable>
                  );
                })}
              </View>

              <View style={{ height: 14 }} />

              {renderActiveTab()}

              <View style={{ height: 28 }} />
            </Animated.View>
          </Animated.ScrollView>

          {activeTab === 'details' ? (
            <View style={[styles.bottomDockWrap, { bottom: insets.bottom + 10 }]}>
              <View style={[styles.bottomDock, { borderColor: businessTheme.glassBorder }]}>
                <View style={styles.bottomDockStatus}>
                  <View
                    style={[
                      styles.bottomDockDot,
                      {
                        backgroundColor: detailsDirty ? '#F59E0B' : '#34D399',
                      },
                    ]}
                  />
                  <Text style={styles.bottomDockStatusText}>{detailsDirty ? 'Unsaved changes' : 'All changes saved'}</Text>
                </View>
                <ContinueCTAButton
                  title="Save changes"
                  onPress={handleSaveLocation}
                  accentColor={businessTheme.primary}
                  disabled={saving}
                  loading={saving}
                  style={styles.bottomDockSave}
                  leading={<Ionicons name="checkmark-circle" size={20} color={colors.textOnDarkPrimary} />}
                />
              </View>
            </View>
          ) : null}
        </KeyboardAvoidingView>
      </SafeAreaView>
    </View>
  );

}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  scrollView: { flex: 1 },
  scrollContentProfile: { paddingHorizontal: 20 },



  hubSectionLabel: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1.1,
    textTransform: 'uppercase',
    marginBottom: 12,
    opacity: 0.9,
  },
  hubSectionDivider: {
    height: StyleSheet.hairlineWidth,
    backgroundColor: 'rgba(255,255,255,0.12)',
    marginVertical: 20,
  },
  hubCategorySegment: {
    flex: 1,
    minHeight: 76,
    paddingHorizontal: 10,
    paddingVertical: 10,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    borderWidth: 1,
    borderColor: 'transparent',
  },
  hubCategoryLabel: {
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.2,
    textAlign: 'center',
    includeFontPadding: false,
    textAlignVertical: 'center',
  },
  hubCategoryRail: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 12,
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderRadius: 24,
    padding: 8,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  svcPriceRow: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 14,
    backgroundColor: 'rgba(255,255,255,0.03)',
  },
  svcPriceRowTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  svcPriceRowLead: { flexDirection: 'row', alignItems: 'center', flex: 1, gap: 12, minWidth: 0 },
  svcPriceRowTitles: { flex: 1, minWidth: 0 },
  svcPriceRowTitleLine: { flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' },
  svcPriceRowTitle: { fontSize: 16, fontWeight: '800', flexShrink: 1 },
  svcPriceRowSub: { fontSize: 13, fontWeight: '600', marginTop: 5 },
  svcPriceRowActions: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  hubSaveCta: { marginTop: 0 },
  svcPriceRowLeadPressable: {
    flex: 1,
    minWidth: 0,
  },

  // Section card (Details tab)
  sectionCard: {
    padding: 14,
    marginBottom: 16,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
  },
  sectionEditPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 7,
    paddingHorizontal: 10,
    borderRadius: 999,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
  },
  sectionEditPillText: { color: '#F9FAFB', fontSize: 11.5, fontWeight: '800' },
  infoFieldList: { gap: 10 },
  infoFieldRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 10,
    paddingHorizontal: 10,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  infoFieldLead: { flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1, minWidth: 0 },
  infoFieldIcon: {
    width: 30,
    height: 30,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(156,216,255,0.10)',
    borderWidth: 1,
    borderColor: 'rgba(156,216,255,0.18)',
  },
  infoFieldLabel: {
    color: 'rgba(255,255,255,0.94)',
    fontSize: 12.5,
    fontWeight: '700',
    flexShrink: 1,
  },
  infoFieldValue: {
    flex: 1,
    minWidth: 0,
    color: '#FFFFFF',
    fontSize: 13.5,
    fontWeight: '700',
    textAlign: 'left',
    paddingVertical: 0,
    paddingHorizontal: 0,
  },
  infoFieldValueWrap: {
    flex: 1,
    minWidth: 0,
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
  },
  infoFieldValueWrapMultiline: { minHeight: 52, justifyContent: 'center' },
  infoFieldValueMultiline: { minHeight: 32, textAlignVertical: 'center' },

  siteTypeRow: { flexDirection: 'row', gap: 12, marginBottom: 4 },
  siteTypeChip: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    gap: 12,
    paddingVertical: 12,
    paddingHorizontal: 12,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
    backgroundColor: 'rgba(255,255,255,0.06)',
    minHeight: 82,
  },
  siteTypeChipTextWrap: { flex: 1, minWidth: 0 },
  siteTypeChipText: { color: LIGHT_TEXT, fontSize: 14, fontWeight: '800' },
  siteTypeChipSub: { color: 'rgba(249,250,251,0.75)', fontSize: 11.5, lineHeight: 15, marginTop: 3 },

  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12 },
  loadingText: { color: SKY, fontSize: 14 },
  missingHeaderRow: {
    width: '100%',
    paddingHorizontal: 20,
    paddingTop: 8,
    alignItems: 'flex-start',
  },
  missingHeaderBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.22)',
  },

  heroWrap: {
    marginBottom: 14,
    marginHorizontal: -20,
    borderRadius: 0,
    overflow: 'hidden',
    borderWidth: 0,
  },
  hero: {
    height: Math.max(330, Math.round(width * 0.78)),
    width: '100%',
    justifyContent: 'space-between',
    backgroundColor: 'rgba(255,255,255,0.04)',
  },
  heroOverlay: {
    ...StyleSheet.absoluteFill,
    zIndex: 2,
  },
  heroImg: { borderRadius: 0 },
  heroBottomFade: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    height: '52%',
    zIndex: 2,
  },
  heroChromeRow: {
    position: 'absolute',
    top: 14,
    left: 14,
    right: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10,
    zIndex: 3,
  },
  heroChromeBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(10,25,41,0.64)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.26)',
    shadowColor: '#000',
    shadowOpacity: 0.22,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 4,
  },
  heroPhotoBtn: {
    minHeight: 36,
    paddingHorizontal: 12,
    borderRadius: 999,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: 'rgba(10,25,41,0.64)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.26)',
    shadowColor: '#000',
    shadowOpacity: 0.22,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 4,
  },
  heroPhotoBtnText: { color: '#F9FAFB', fontSize: 12, fontWeight: '800' },
  heroStatusPill: {
    alignSelf: 'flex-start',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 999,
    backgroundColor: 'rgba(10,25,41,0.62)',
    borderWidth: 1,
    marginBottom: 10,
  },
  heroStatusDot: { width: 8, height: 8, borderRadius: 4 },
  heroStatusText: { color: '#F9FAFB', fontSize: 12, fontWeight: '800' },
  heroBottom: {
    position: 'absolute',
    left: 14,
    right: 14,
    bottom: 14,
    zIndex: 3,
    paddingTop: 44,
  },
  heroTitle: { color: '#F9FAFB', fontSize: 24, fontWeight: '900', letterSpacing: -0.6 },
  heroSubtitle: { color: 'rgba(249,250,251,0.82)', fontSize: 12.5, marginTop: 4, fontWeight: '700', lineHeight: 17 },
  tabIconCircle: {
    width: 30,
    height: 30,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },

  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '900',
    letterSpacing: 0.2,
    marginBottom: 12,
  },
  sectionHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 14,
  },
  bottomDockWrap: {
    position: 'absolute',
    left: 16,
    right: 16,
    zIndex: 20,
  },
  bottomDock: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
    padding: 12,
    borderRadius: 24,
    backgroundColor: 'rgba(6,12,22,0.82)',
    borderWidth: 1,
    shadowColor: '#000',
    shadowOpacity: 0.22,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 6 },
    elevation: 10,
  },
  bottomDockStatus: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 999,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.09)',
    flexShrink: 1,
  },
  bottomDockDot: { width: 10, height: 10, borderRadius: 5 },
  bottomDockStatusText: { color: '#F9FAFB', fontSize: 12, fontWeight: '800' },
  bottomDockSave: { flex: 1, marginTop: 0 },

  card: {
    padding: 18,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
  },

  label: { color: 'rgba(255,255,255,0.9)', fontSize: 13, fontWeight: '700' },
  miniText: { color: 'rgba(255,255,255,0.8)', fontSize: 12, lineHeight: 18 },


  row: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  rowBetween: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12 },

  dangerBtn: {
    borderRadius: 18,
    borderWidth: 1,
    borderColor: '#DC2626',
    backgroundColor: '#EF4444',
    overflow: 'hidden',
    justifyContent: 'center',
    minWidth: 110,
  },
  dangerBtnInner: { 
    paddingVertical: 14, 
    paddingHorizontal: 16,
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'center', 
    gap: 8 
  },
  dangerBtnText: { 
    color: '#FFFFFF', 
    fontSize: 13, 
    fontWeight: '800' 
  },


  smallAddBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.22)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.35)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.24,
    shadowRadius: 10,
    elevation: 6,
  },

  infoText: { color: 'rgba(249,250,251,0.8)', fontSize: 13, fontWeight: '700', flex: 1 },

  serviceChip: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: 'rgba(135,206,235,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.18)',
    alignSelf: 'flex-start',
  },
  serviceChipText: { color: 'rgba(249,250,251,0.85)', fontSize: 12, fontWeight: '800' },

  inlineLabel: { color: 'rgba(249,250,251,0.6)', fontSize: 11, fontWeight: '900', marginBottom: 6 },
  inlineInputCard: { padding: 0, overflow: 'hidden' },
  inlineInput: { color: '#F9FAFB', fontSize: 14, paddingVertical: 10, paddingHorizontal: 12 },

  tierBadge: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  tierBadgeText: {
    color: '#F9FAFB',
    fontSize: 9,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },


  // Opening hours UI
  hoursRow: {
    padding: 12,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.14)',
    backgroundColor: 'rgba(255,255,255,0.05)',
    gap: 10,
  },
  hoursTop: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  dayPill: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.22)',
  },
  dayPillText: { color: '#F9FAFB', fontSize: 12, fontWeight: '900' },
  hoursInputs: {
    flexDirection: 'row',
    gap: 10,
    alignItems: 'flex-end',
  },
  slotPreviewRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },



});
