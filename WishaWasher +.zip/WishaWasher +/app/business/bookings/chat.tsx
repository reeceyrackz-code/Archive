/**
 * Business chat with customer – same WhatsApp-like UI as valeter (shared ChatThreadView).
 */
import React, { useState, useEffect, useCallback } from 'react';
import { Alert } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { supabase } from '../../../src/lib/supabase';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import ChatThreadView from '../../../src/components/chat/ChatThreadView';
import LoadingScreen from '../../../src/components/LoadingScreen';
import { addDeletedChatBookingId } from '../../../src/services/DeletedChatsService';
import { canBusinessUseBookingChat } from '../../../src/services/bookingCustomerChatAccess';
import { promptAndSendBookingPhotoMessage } from '../../../src/services/bookingChatMediaService';

async function getCustomerName(userId: string | null, fallback: string): Promise<string> {
  if (!userId) return fallback;
  try {
    const { data } = await supabase.from('profiles').select('full_name, name').eq('id', userId).maybeSingle();
    const p = data as any;
    return (p?.full_name || p?.name || fallback) as string;
  } catch {
    return fallback;
  }
}

export default function BusinessBookingChatScreen() {
  const params = useLocalSearchParams<{ id: string }>();
  const bookingId = params.id;
  const { user } = useAuth();
  const { theme, mode } = useAccountTheme();
  const isLight = mode === 'light';
  const [title, setTitle] = useState<string>('Customer');
  const [subtitle, setSubtitle] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [composerLocked, setComposerLocked] = useState(false);
  const [customerUserId, setCustomerUserId] = useState<string | null>(null);
  const [bookingStatus, setBookingStatus] = useState<string>('');

  const refreshChatAccess = useCallback(
    async (status: string, custId: string | null) => {
      if (!bookingId) return;
      const allowed = await canBusinessUseBookingChat(status, bookingId, custId);
      setComposerLocked(!allowed);
    },
    [bookingId]
  );

  useEffect(() => {
    if (!bookingId) {
      setLoading(false);
      return;
    }
    let cancelled = false;
    void (async () => {
      try {
        const { data, error } = await supabase
          .from('bookings')
          .select('user_id, service_type, service_name, customer_name, status')
          .eq('id', bookingId)
          .maybeSingle();

        if (error || !data) {
          if (!cancelled) setLoading(false);
          return;
        }
        const r = data as any;
        const st = String(r.status || '');
        const uid = (r.user_id as string | null) ?? null;
        if (!cancelled) {
          setCustomerUserId(uid);
          setBookingStatus(st);
        }
        const serviceDisplay = getServiceDisplayName(r.service_type, r.service_name);
        setSubtitle(serviceDisplay);
        const name = r.customer_name || (await getCustomerName(uid, 'Customer'));
        setTitle(name);
        await refreshChatAccess(st, uid);
      } catch {
        setTitle('Customer');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [bookingId, refreshChatAccess]);

  useEffect(() => {
    if (!bookingId || !customerUserId) return;
    const channel = supabase
      .channel(`business-booking-chat-${bookingId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'booking_messages',
          filter: `booking_id=eq.${bookingId}`,
        },
        (payload) => {
          const row = payload.new as { sender_id?: string } | null;
          if (row?.sender_id && row.sender_id === customerUserId) {
            setComposerLocked(false);
          }
        }
      )
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [bookingId, customerUserId]);

  useEffect(() => {
    if (!bookingId) return;
    const channel = supabase
      .channel(`business-booking-chat-booking-${bookingId}`)
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'bookings', filter: `id=eq.${bookingId}` },
        (payload) => {
          const row = payload.new as { status?: string } | null;
          const st = String(row?.status ?? '');
          if (st) {
            setBookingStatus(st);
            void refreshChatAccess(st, customerUserId);
          }
        }
      )
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [bookingId, customerUserId, refreshChatAccess]);

  const handleBack = () => {
    void hapticFeedback('light');
    router.back();
  };

  const handleCall = () => {
    void hapticFeedback('light');
    Alert.alert('Call', 'Call customer – will open phone dialler when connected.');
  };

  const handleAttachImage = async () => {
    void hapticFeedback('light');
    if (!bookingId || !user?.id) return;
    try {
      await promptAndSendBookingPhotoMessage({
        bookingId,
        senderId: user.id,
        senderRole: 'business',
        content: 'IMAGE',
        promptTitle: 'Photo',
        promptMessage: 'Take a photo to send in chat.',
      });
    } catch (error: any) {
      Alert.alert('Photo', error?.message || 'Could not take or send the photo.');
    }
  };


  const handleDeleteChat = () => {
    void hapticFeedback('light');
    Alert.alert(
      'Delete chat',
      'Remove this conversation from your list? You can still see the booking in activity.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => {
            void (async () => {
              if (bookingId) {
                await addDeletedChatBookingId(bookingId);
              }
              router.back();
            })();
          },
        },
      ]
    );
  };

  const accent = theme?.primary ?? '#7EB8D4';
  const darkBg = Array.isArray(theme?.background) ? theme.background[0] : '#0B1F36';
  const bg = isLight ? '#C5DCE8' : darkBg;

  if (loading) {
    return <LoadingScreen message="Loading…" />;
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: bg }} edges={[]}>
      <ChatThreadView
        bookingId={bookingId}
        currentUserId={user?.id ?? null}
        currentUserRole="business"
        title={title}
        subtitle={subtitle}
        onBack={handleBack}
        onCall={handleCall}
        onAttachImage={handleAttachImage}
        onDelete={handleDeleteChat}
        accentColor={accent}
        backgroundColor={bg}
        composerLocked={composerLocked}
        composerLockHint={
          String(bookingStatus).toLowerCase() === 'completed'
            ? 'Messaging unlocks when the customer sends a message for this completed job.'
            : undefined
        }
      />
    </SafeAreaView>
  );
}
