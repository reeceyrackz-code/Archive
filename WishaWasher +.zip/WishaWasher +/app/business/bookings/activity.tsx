import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert,
  Image,
  Platform,
  Modal,
  RefreshControl,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import MapView, { Marker, PROVIDER_DEFAULT } from 'react-native-maps';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import BusinessSheetBackground from '../../../src/components/shared/BusinessSheetBackground';
import StatusBadge from '../../../src/components/booking/StatusBadge';
import { colors } from '../../../src/constants/colors';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { MAP_LOCKED_DARK } from '../../../src/constants/mapConstants';
import {
  loadActiveBookingsForOrganization,
  loadHistoryBookingsForOrganization,
  type BusinessActiveBooking,
  type BusinessHistoryBooking,
} from '../../../src/services/BusinessBookingsService';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import { SCREEN_PADDING_H, SECTION_GAP, CARD_GAP } from '../../../src/constants/premiumTokens';
import DefaultLoadingSkeleton from '../../../src/components/shared/DefaultLoadingSkeleton';
import EmptyState from '../../../src/components/shared/EmptyState';
import { canOpenLiveTracking } from '../../../src/utils/businessBookingAccess';

const SKY = colors.SKY;
const CARD_MAP_HEIGHT = 108;
const MAP_PROVIDER = Platform.OS === 'ios' ? PROVIDER_DEFAULT : undefined;

type UpcomingBooking = BusinessActiveBooking;
type PastBooking = BusinessHistoryBooking;
type BookingRow = UpcomingBooking | PastBooking;
type StatusTone = 'green' | 'sky' | 'amber' | 'gray' | 'red';
type ActivityFilter = 'upcoming' | 'completed';

function getStatusTone(status: string): StatusTone {
  const s = String(status).toLowerCase();
  if (s === 'completed') return 'green';
  if (s === 'cancelled') return 'red';
  if (s === 'in_progress' || s === 'arrived' || s === 'en_route') return 'sky';
  if (s === 'pending' || s === 'confirmed' || s === 'scheduled') return 'amber';
  return 'gray';
}

const CARD_AVATAR_COLORS: Record<StatusTone, [string, string]> = {
  green: ['rgba(16,185,129,0.34)', 'rgba(16,185,129,0.12)'],
  red: ['rgba(248,113,113,0.34)', 'rgba(248,113,113,0.12)'],
  amber: ['rgba(245,158,11,0.34)', 'rgba(245,158,11,0.12)'],
  sky: ['rgba(135,206,235,0.34)', 'rgba(135,206,235,0.12)'],
  gray: ['rgba(135,206,235,0.34)', 'rgba(135,206,235,0.12)'],
};

function getCardAccentStyle(tone: StatusTone) {
  if (tone === 'green') return styles.cardAccentCompleted;
  if (tone === 'red') return styles.cardAccentCancelled;
  return styles.cardAccentPending;
}

function getDetailAvatarColors(tone: StatusTone): [string, string] {
  if (tone === 'red') return ['rgba(248,113,113,0.36)', 'rgba(248,113,113,0.15)'];
  if (tone === 'green') return ['rgba(16,185,129,0.32)', 'rgba(16,185,129,0.14)'];
  return ['rgba(246,211,101,0.32)', 'rgba(246,211,101,0.14)'];
}

const FILTER_COPY = {
  upcoming: {
    title: 'Upcoming',
    emptyIcon: 'time-outline',
    emptyTitle: 'No upcoming jobs',
    emptySubtitle: 'Scheduled and active bookings will show here',
    viewAllLabel: 'upcoming',
  },
  completed: {
    title: 'Completed',
    emptyIcon: 'checkmark-circle-outline',
    emptyTitle: 'No completed jobs',
    emptySubtitle: 'Completed jobs will appear here',
    viewAllLabel: 'completed',
  },
} as const;

function formatBookingDate(booking: BookingRow) {
  const at = booking.scheduled_at;
  return at
    ? new Date(at).toLocaleString('en-GB', {
        weekday: 'short',
        day: 'numeric',
        month: 'short',
        hour: '2-digit',
        minute: '2-digit',
      })
    : new Date(booking.created_at).toLocaleDateString('en-GB', {
        weekday: 'short',
        day: 'numeric',
        month: 'short',
      });
}

function formatStatusLabel(status: string | null | undefined) {
  return status ? status.replaceAll('_', ' ').replace(/\b\w/g, (c) => c.toUpperCase()) : '';
}

const hasCoords = (b: BookingRow) =>
  b.location_lat != null &&
  b.location_lng != null &&
  Number.isFinite(b.location_lat) &&
  Number.isFinite(b.location_lng);

function getCardRegion(booking: BookingRow, coords: boolean) {
  if (coords) {
    return {
      latitude: booking.location_lat!,
      longitude: booking.location_lng!,
      latitudeDelta: 0.003,
      longitudeDelta: 0.003,
    };
  }
  return {
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.05,
    longitudeDelta: 0.05,
  };
}

type BookingCardProps = {
  booking: BookingRow;
  variant: 'upcoming' | 'past';
  avatarFailed: boolean;
  onAvatarError: (id: string) => void;
  onPress: (booking: BookingRow) => void;
};

function BookingCard({ booking, variant, avatarFailed, onAvatarError, onPress }: Readonly<BookingCardProps>) {
  const coords = hasCoords(booking);
  const region = getCardRegion(booking, coords);
  const photoUri = booking.customer_profile_picture;
  const showAvatarImage = !!photoUri && !avatarFailed;
  const customerName = booking.customer_name?.trim() || 'Customer';
  const customerInitial = customerName.charAt(0).toUpperCase() || '?';
  const statusTone = getStatusTone(booking.status);
  const priceLabel = variant === 'upcoming' ? 'Booked' : 'Earned';
  const avatarColors = CARD_AVATAR_COLORS[statusTone];
  const accentStyle = getCardAccentStyle(statusTone);

  return (
    <TouchableOpacity
      activeOpacity={0.88}
      onPress={async () => {
        await hapticFeedback('light');
        onPress(booking);
      }}
      style={styles.card}
      >
      <View style={styles.cardInner}>
        <View style={[styles.cardAccent, accentStyle]} />
        <View style={styles.cardHeader}>
          <View style={styles.cardHeaderLeft}>
            <View style={styles.avatarWrap}>
              {showAvatarImage && photoUri ? (
                <Image
                  source={{ uri: photoUri }}
                  style={styles.avatarImage}
                  resizeMode="cover"
                  onError={() => onAvatarError(booking.id)}
                />
              ) : (
                <LinearGradient
                  colors={avatarColors}
                  style={styles.avatarGrad}
                >
                  <Text style={styles.avatarLetter}>{customerInitial}</Text>
                </LinearGradient>
              )}
            </View>
            <View style={styles.cardHeaderText}>
              <Text style={styles.customerName} numberOfLines={1}>
                {customerName}
              </Text>
              <Text style={styles.serviceName} numberOfLines={1}>
                {getServiceDisplayName(booking.service_type, booking.service_name)}
              </Text>
              <View style={styles.statusRow}>
                <StatusBadge status={booking.status as any} size="small" />
              </View>
            </View>
          </View>

          <View style={styles.priceStack}>
            <Text style={styles.pricePillText}>£{Number(booking.price || 0).toFixed(2)}</Text>
            <Text style={[styles.priceLabel, statusTone === 'red' && styles.priceLabelAlert]}>{priceLabel}</Text>
          </View>
        </View>

        <View style={styles.infoBlock}>
          <View style={styles.infoRow}>
            <Ionicons name="calendar-outline" size={16} color="rgba(249,250,251,0.7)" />
            <Text style={styles.infoText}>{formatBookingDate(booking)}</Text>
          </View>
          {booking.location_address ? (
            <View style={styles.infoRow}>
              <Ionicons name="location-outline" size={16} color="rgba(249,250,251,0.7)" />
              <Text style={styles.infoText} numberOfLines={1}>
                {booking.location_address.split(',')[0]}
              </Text>
            </View>
          ) : (
            <View style={styles.infoRow}>
              <Ionicons name="location-outline" size={16} color="rgba(148,163,184,0.5)" />
              <Text style={styles.infoTextMuted}>Location not recorded</Text>
            </View>
          )}
        </View>

        <View style={styles.mapWrap}>
          {coords ? (
            <MapView
              style={styles.map}
              region={region}
              scrollEnabled={false}
              zoomEnabled={false}
              pitchEnabled={false}
              rotateEnabled={false}
              provider={MAP_PROVIDER}
              mapType="standard"
              userInterfaceStyle={MAP_LOCKED_DARK}
            >
              <Marker
                coordinate={{
                  latitude: booking.location_lat!,
                  longitude: booking.location_lng!,
                }}
                anchor={{ x: 0.5, y: 0.5 }}
              >
                <View style={styles.mapPin}>
                  <Ionicons name="location" size={16} color={SKY} />
                </View>
              </Marker>
            </MapView>
          ) : (
            <View style={styles.mapPlaceholder}>
              <Ionicons name="map-outline" size={32} color="rgba(148,163,184,0.4)" />
              <Text style={styles.mapPlaceholderText}>No map data</Text>
            </View>
          )}
          <View style={styles.mapChevronBubble}>
            <Ionicons name="chevron-forward" size={20} color="#F9FAFB" />
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
}

type FilterChipProps = {
  label: string;
  count: number;
  active: boolean;
  onPress: () => void;
};

function FilterChip({ label, count, active, onPress }: Readonly<FilterChipProps>) {
  return (
    <TouchableOpacity
      onPress={async () => {
        await hapticFeedback('light');
        onPress();
      }}
      style={[
        styles.filterChip,
        active && styles.filterChipActive,
      ]}
      activeOpacity={0.85}
    >
      <Text style={[styles.filterChipText, active && styles.filterChipTextActive]}>
        {label}
      </Text>
      <View style={[styles.filterChipCount, active && styles.filterChipCountActive]}>
        <Text style={[styles.filterChipCountText, active && styles.filterChipCountTextActive]}>
          {count}
        </Text>
      </View>
    </TouchableOpacity>
  );
}

type FilterBarProps = {
  activeFilter: ActivityFilter;
  upcomingCount: number;
  completedCount: number;
  onSelect: (filter: ActivityFilter) => void;
  onRefresh: () => void;
};

function FilterBar({ activeFilter, upcomingCount, completedCount, onSelect, onRefresh }: Readonly<FilterBarProps>) {
  return (
    <View style={styles.filterBar}>
      <FilterChip
        label="Upcoming"
        count={upcomingCount}
        active={activeFilter === 'upcoming'}
        onPress={() => onSelect('upcoming')}
      />
      <FilterChip
        label="Completed"
        count={completedCount}
        active={activeFilter === 'completed'}
        onPress={() => onSelect('completed')}
      />
      <TouchableOpacity
        onPress={async () => {
          await hapticFeedback('light');
          onRefresh();
        }}
        style={styles.headerBtnCircle}
      >
        <Ionicons name="refresh-outline" size={20} color={SKY} />
      </TouchableOpacity>
    </View>
  );
}

function AssignedValeterRow({ name, photo }: Readonly<{ name: string; photo: string | null }>) {
  return (
    <View style={styles.detailRow}>
      {photo ? (
        <Image
          source={{ uri: photo }}
          style={styles.detailValeterAvatar}
          resizeMode="cover"
        />
      ) : (
        <View style={styles.detailValeterAvatarFallback}>
          <Text style={styles.detailValeterAvatarLetter}>
            {(name || '?').trim().charAt(0).toUpperCase()}
          </Text>
        </View>
      )}
      <Text style={styles.detailRowText}>Car Care Pro: {name}</Text>
    </View>
  );
}

function BookingDetailInfoCard({ booking }: Readonly<{ booking: BookingRow }>) {
  const statusLabel = formatStatusLabel(booking.status);
  const customerId = 'customer_id' in booking ? booking.customer_id : null;
  return (
    <View style={styles.detailInfoCard}>
      <View style={styles.detailRow}>
        <Ionicons name="calendar-outline" size={18} color={SKY} />
        <Text style={styles.detailRowText}>{formatBookingDate(booking)}</Text>
      </View>
      {booking.location_address ? (
        <View style={styles.detailRow}>
          <Ionicons name="location-outline" size={18} color={SKY} />
          <Text style={styles.detailRowText}>{booking.location_address}</Text>
        </View>
      ) : null}
      {booking.assigned_valeter_name ? (
        <AssignedValeterRow name={booking.assigned_valeter_name} photo={booking.assigned_valeter_photo} />
      ) : null}
      {statusLabel ? (
        <View style={styles.detailRow}>
          <Ionicons name="radio-button-on-outline" size={18} color={SKY} />
          <Text style={styles.detailRowText}>{statusLabel}</Text>
        </View>
      ) : null}
      {customerId ? (
        <View style={styles.detailRow}>
          <Ionicons name="chatbubble-outline" size={18} color={SKY} />
          <Text style={styles.detailRowText}>Customer chat available from this booking</Text>
        </View>
      ) : null}
    </View>
  );
}

function BookingDetailMap({ booking }: Readonly<{ booking: BookingRow }>) {
  return (
    <View style={styles.detailMapWrap}>
      {booking.location_lat != null && booking.location_lng != null ? (
        <MapView
          style={StyleSheet.absoluteFill}
          region={{
            latitude: booking.location_lat,
            longitude: booking.location_lng,
            latitudeDelta: 0.008,
            longitudeDelta: 0.008,
          }}
          provider={MAP_PROVIDER}
          userInterfaceStyle={MAP_LOCKED_DARK}
        >
          <Marker coordinate={{ latitude: booking.location_lat, longitude: booking.location_lng }}>
            <View style={styles.detailMapPin}>
              <Ionicons name="location" size={18} color={SKY} />
            </View>
          </Marker>
        </MapView>
      ) : (
        <View style={styles.detailMapPlaceholder}>
          <Ionicons name="map-outline" size={30} color="rgba(148,163,184,0.42)" />
          <Text style={styles.detailMapPlaceholderText}>No map data</Text>
        </View>
      )}
    </View>
  );
}

function BookingDetailContent({ booking, onClose }: Readonly<{ booking: BookingRow; onClose: () => void }>) {
  const name = booking.customer_name?.trim() || 'Customer';
  const service = getServiceDisplayName(booking.service_type, booking.service_name);
  const statusTone = getStatusTone(booking.status);
  const canTrack = canOpenLiveTracking(booking.scheduled_at, booking.status);

  return (
    <>
      <View style={styles.detailHeaderRow}>
        <View style={styles.detailHeaderCopy}>
          <Text style={styles.detailTitle}>{name}</Text>
          <Text style={styles.detailSubtitle}>{service}</Text>
        </View>
        <TouchableOpacity onPress={onClose} style={styles.detailCloseBtn} hitSlop={12}>
          <Ionicons name="close" size={24} color="rgba(249,250,251,0.9)" />
        </TouchableOpacity>
      </View>

      <View style={styles.detailHeroRow}>
        <View style={styles.detailAvatarWrap}>
          {booking.customer_profile_picture ? (
            <Image source={{ uri: booking.customer_profile_picture }} style={styles.detailAvatar} resizeMode="cover" />
          ) : (
            <LinearGradient
              colors={getDetailAvatarColors(statusTone)}
              style={styles.detailAvatarFallback}
            >
              <Text style={styles.detailAvatarLetter}>{name.charAt(0).toUpperCase()}</Text>
            </LinearGradient>
          )}
        </View>
        <View style={styles.detailHeroStats}>
          <View style={[styles.detailPricePill, statusTone === 'red' && styles.detailPricePillRed, statusTone === 'green' && styles.detailPricePillGreen]}>
            <Text style={styles.detailPriceValue}>£{Number(booking.price || 0).toFixed(2)}</Text>
            <Text style={styles.detailPriceLabel}>Earned</Text>
          </View>
          <View style={styles.detailStatusWrap}>
            <StatusBadge status={booking.status as any} size="medium" />
          </View>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.detailScrollContent}>
        <BookingDetailInfoCard booking={booking} />
        <BookingDetailMap booking={booking} />
      </ScrollView>

      <View style={styles.detailActions}>
        <TouchableOpacity style={styles.detailActionGhost} onPress={onClose}>
          <Text style={styles.detailActionGhostText}>Close</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.detailActionPrimary, !canTrack && styles.detailActionPrimaryDisabled]}
          onPress={async () => {
            if (!canTrack) return;
            await hapticFeedback('light');
            onClose();
            router.push({
              pathname: '/business/bookings/tracking',
              params: { bookingId: booking.id },
            } as any);
          }}
          disabled={!canTrack}
        >
          <Text style={styles.detailActionPrimaryText}>
            {canTrack ? 'Track booking' : 'Tracking locked'}
          </Text>
        </TouchableOpacity>
      </View>
    </>
  );
}

function sortUpcoming(bookings: UpcomingBooking[]) {
  return [...bookings].sort((a, b) => {
    const aTime = new Date(a.scheduled_at ?? a.created_at).getTime();
    const bTime = new Date(b.scheduled_at ?? b.created_at).getTime();
    return aTime - bTime;
  });
}

function sortPast(bookings: PastBooking[]) {
  return [...bookings].sort((a, b) => {
    const aTime = new Date(a.created_at).getTime();
    const bTime = new Date(b.created_at).getTime();
    return bTime - aTime;
  });
}

export default function ActivityPage() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme: businessTheme } = useAccountTheme();
  const [upcomingBookings, setUpcomingBookings] = useState<UpcomingBooking[]>([]);
  const [pastBookings, setPastBookings] = useState<PastBooking[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [activeFilter, setActiveFilter] = useState<ActivityFilter>('upcoming');
  const [showAllUpcoming, setShowAllUpcoming] = useState(false);
  const [showAllPast, setShowAllPast] = useState(false);
  const [failedAvatarIds, setFailedAvatarIds] = useState<Record<string, boolean>>({});
  const [selectedBooking, setSelectedBooking] = useState<BookingRow | null>(null);

  const organizationId = user?.organizationId ?? null;
  const isOrgUser = ['organization', 'business'].includes((user?.userType ?? '').toLowerCase());

  const loadActivity = useCallback(async (isRefresh = false) => {
    if (!organizationId) {
      setLoading(false);
      setRefreshing(false);
      return;
    }
    try {
      if (!isRefresh) setLoading(true);
      else setRefreshing(true);

      const LOAD_TIMEOUT_MS = 15000;
      const [upcoming, past] = await Promise.race([
        Promise.all([
          loadActiveBookingsForOrganization(organizationId),
          loadHistoryBookingsForOrganization(organizationId),
        ]),
        new Promise<[UpcomingBooking[], PastBooking[]]>((_, reject) =>
          setTimeout(() => reject(new Error('Load timed out')), LOAD_TIMEOUT_MS)
        ),
      ]);

      setUpcomingBookings(upcoming);
      setPastBookings(past);
    } catch (e: any) {
      console.error('[Activity] load error', e);
      setUpcomingBookings([]);
      setPastBookings([]);
      if (!isRefresh) {
        Alert.alert(
          'Couldn’t load bookings',
          e?.message === 'Load timed out' ? 'Request took too long. Pull down to try again.' : 'Pull down to try again.'
        );
      }
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [organizationId]);

  useEffect(() => {
    if (isOrgUser && organizationId) {
      void loadActivity(false);
    } else {
      setLoading(false);
    }
  }, [organizationId, isOrgUser, loadActivity]);

  const markAvatarFailed = (id: string) =>
    setFailedAvatarIds((prev) => (prev[id] ? prev : { ...prev, [id]: true }));

  const upcoming = sortUpcoming(upcomingBookings);
  const past = sortPast(pastBookings);

  const upcomingVisible = showAllUpcoming ? upcoming : upcoming.slice(0, 4);
  const pastVisible = showAllPast ? past : past.slice(0, 5);
  const hasAnyBookings = upcoming.length > 0 || past.length > 0;
  const active =
    activeFilter === 'upcoming'
      ? {
          bookings: upcoming as BookingRow[],
          visible: upcomingVisible as BookingRow[],
          showAll: showAllUpcoming,
          setShowAll: setShowAllUpcoming,
          variant: 'upcoming' as const,
        }
      : {
          bookings: past as BookingRow[],
          visible: pastVisible as BookingRow[],
          showAll: showAllPast,
          setShowAll: setShowAllPast,
          variant: 'past' as const,
        };
  const activeHasMore = active.bookings.length > active.visible.length;
  const copy = FILTER_COPY[activeFilter];

  const refresh = () => void loadActivity(true);
  const refreshControl = <RefreshControl refreshing={refreshing} onRefresh={refresh} tintColor={SKY} />;
  const filterBar = (
    <FilterBar
      activeFilter={activeFilter}
      upcomingCount={upcoming.length}
      completedCount={past.length}
      onSelect={setActiveFilter}
      onRefresh={refresh}
    />
  );

  const renderBody = () => {
    if (loading) {
      return (
        <View style={styles.loadingArea}>
          <DefaultLoadingSkeleton message="Loading bookings…" variant="rich" />
        </View>
      );
    }
    if (!hasAnyBookings) {
      return (
        <ScrollView
          contentContainerStyle={styles.centeredScroll}
          refreshControl={refreshControl}
        >
          {filterBar}
          <EmptyState
            icon="calendar-outline"
            title="No bookings yet"
            subtitle="Upcoming and past washes will appear here"
            iconColor={SKY}
          />
        </ScrollView>
      );
    }
    return (
      <ScrollView
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        refreshControl={refreshControl}
      >
        {filterBar}
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>{copy.title}</Text>
          <Text style={styles.sectionCount}>{active.bookings.length}</Text>
        </View>
        {active.bookings.length === 0 ? (
          <EmptyState
            icon={copy.emptyIcon}
            title={copy.emptyTitle}
            subtitle={copy.emptySubtitle}
            iconColor={SKY}
          />
        ) : (
          <>
            {active.visible.map((b) => (
              <BookingCard
                key={b.id}
                booking={b}
                variant={active.variant}
                avatarFailed={!!failedAvatarIds[b.id]}
                onAvatarError={markAvatarFailed}
                onPress={setSelectedBooking}
              />
            ))}
            {activeHasMore && (
              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  active.setShowAll(true);
                }}
                style={styles.viewAllWrap}
                activeOpacity={0.8}
              >
                <Text style={styles.viewAllText}>
                  View all {copy.viewAllLabel}
                </Text>
                <Ionicons name="list" size={20} color={SKY} />
              </TouchableOpacity>
            )}
            {active.showAll && activeHasMore && (
              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  active.setShowAll(false);
                }}
                style={styles.viewAllWrap}
                activeOpacity={0.8}
              >
                <Text style={styles.viewAllText}>Show less</Text>
                <Ionicons name="chevron-up" size={20} color={SKY} />
              </TouchableOpacity>
            )}
          </>
        )}
      </ScrollView>
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />

      <View
        style={[
          styles.contentWrap,
          {
            paddingTop: insets.top + 2,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + SECTION_GAP,
          },
        ]}
      >
        {renderBody()}
      </View>

      <Modal
        visible={!!selectedBooking}
        transparent
        animationType="slide"
        statusBarTranslucent
        onRequestClose={() => setSelectedBooking(null)}
      >
        <View style={styles.detailModalRoot}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setSelectedBooking(null)}>
            <View style={styles.detailBackdrop} />
          </Pressable>
          <Pressable
            style={[styles.detailSheet, { paddingBottom: Math.max(24, insets.bottom + 12) }]}
            onPress={(e) => e.stopPropagation()}
          >
            <BusinessSheetBackground />
            <View style={styles.detailHandle} />
            {selectedBooking ? (
              <BookingDetailContent booking={selectedBooking} onClose={() => setSelectedBooking(null)} />
            ) : null}
          </Pressable>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  contentWrap: { flex: 1 },
  loadingArea: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: SCREEN_PADDING_H,
  },
  centeredScroll: {
    flexGrow: 1,
    justifyContent: 'center',
    paddingHorizontal: SCREEN_PADDING_H,
    gap: SECTION_GAP,
  },
  listContent: {
    paddingHorizontal: SCREEN_PADDING_H,
    paddingTop: 4,
    paddingBottom: SECTION_GAP,
    gap: CARD_GAP,
  },
  filterBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
    gap: 8,
  },
  headerBtnCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.18)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.35)',
  },
  filterChip: {
    flex: 1,
    minWidth: 0,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.15)',
  },
  filterChipActive: {
    backgroundColor: 'rgba(135,206,235,0.16)',
    borderColor: 'rgba(135,206,235,0.32)',
  },
  filterChipText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    fontWeight: '800',
  },
  filterChipTextActive: {
    color: '#F9FAFB',
  },
  filterChipCount: {
    minWidth: 24,
    height: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
    paddingHorizontal: 7,
  },
  filterChipCountActive: {
    backgroundColor: 'rgba(255,255,255,0.16)',
  },
  filterChipCountText: {
    color: 'rgba(249,250,251,0.65)',
    fontSize: 12,
    fontWeight: '800',
  },
  filterChipCountTextActive: {
    color: '#F9FAFB',
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 8,
    marginBottom: 2,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: -0.25,
  },
  sectionCount: {
    color: 'rgba(248,250,252,0.7)',
    fontSize: 13,
    fontWeight: '700',
  },
  card: {
    borderRadius: 22,
    overflow: 'hidden',
    backgroundColor: 'rgba(10,18,30,0.78)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.18)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.14,
    shadowRadius: 18,
    elevation: 5,
  },
  cardInner: {
    padding: 16,
    gap: 12,
    position: 'relative',
  },
  cardAccent: {
    position: 'absolute',
    right: 0,
    top: 0,
    bottom: 0,
    width: 4,
    borderTopLeftRadius: 0,
    borderBottomLeftRadius: 0,
    borderTopRightRadius: 22,
    borderBottomRightRadius: 22,
  },
  cardAccentPending: {
    backgroundColor: 'rgba(245,158,11,0.95)',
  },
  cardAccentCompleted: {
    backgroundColor: 'rgba(16,185,129,0.95)',
  },
  cardAccentCancelled: {
    backgroundColor: 'rgba(248,113,113,0.95)',
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    gap: 12,
  },
  cardHeaderLeft: {
    flex: 1,
    minWidth: 0,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  avatarWrap: {
    width: 60,
    height: 60,
    borderRadius: 18,
    overflow: 'hidden',
  },
  avatarGrad: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarImage: {
    width: '100%',
    height: '100%',
  },
  avatarLetter: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: '800',
  },
  cardHeaderText: {
    flex: 1,
    minWidth: 0,
    gap: 6,
  },
  customerName: {
    fontSize: 19,
    fontWeight: '800',
    color: '#F9FAFB',
    lineHeight: 21,
  },
  serviceName: {
    color: 'rgba(226,232,240,0.78)',
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 18,
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flexWrap: 'wrap',
  },
  priceStack: {
    alignItems: 'flex-end',
    minWidth: 96,
    gap: 1,
  },
  pricePillText: {
    color: '#F9FAFB',
    fontSize: 19,
    fontWeight: '900',
    letterSpacing: -0.2,
  },
  priceLabel: {
    color: 'rgba(248,250,252,0.68)',
    fontSize: 12,
    fontWeight: '600',
  },
  priceLabelAlert: {
    color: 'rgba(248,250,252,0.72)',
  },
  infoBlock: {
    gap: 8,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
  },
  infoText: {
    fontSize: 14,
    color: 'rgba(249,250,251,0.9)',
    fontWeight: '500',
    flex: 1,
  },
  infoTextMuted: {
    fontSize: 14,
    color: 'rgba(148,163,184,0.7)',
    fontWeight: '500',
    fontStyle: 'italic',
  },
  mapWrap: {
    height: CARD_MAP_HEIGHT,
    width: '100%',
    borderRadius: 18,
    overflow: 'hidden',
    backgroundColor: 'rgba(15,23,42,0.72)',
    marginTop: 2,
  },
  map: {
    width: '100%',
    height: '100%',
    borderRadius: 18,
  },
  mapPin: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(15,23,42,0.92)',
    borderWidth: 2,
    borderColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
  },
  mapPlaceholder: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
  },
  mapPlaceholderText: {
    fontSize: 12,
    color: 'rgba(148,163,184,0.6)',
    fontWeight: '500',
  },
  mapChevronBubble: {
    position: 'absolute',
    right: 14,
    bottom: 14,
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(17,24,39,0.62)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  viewAllWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    paddingHorizontal: 20,
    marginTop: 4,
    borderRadius: 16,
    backgroundColor: 'rgba(135,206,235,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  viewAllText: {
    fontSize: 16,
    fontWeight: '700',
    color: SKY,
  },
  detailModalRoot: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  detailBackdrop: {
    ...StyleSheet.absoluteFill,
    backgroundColor: 'rgba(3,10,21,0.62)',
  },
  detailSheet: {
    maxHeight: '88%',
    borderTopLeftRadius: 26,
    borderTopRightRadius: 26,
    overflow: 'hidden',
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    backgroundColor: '#0B1D34',
    paddingHorizontal: 20,
    paddingTop: 12,
  },
  detailHandle: {
    width: 40,
    height: 5,
    borderRadius: 999,
    backgroundColor: 'rgba(255,255,255,0.22)',
    alignSelf: 'center',
    marginBottom: 18,
  },
  detailHeaderRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    gap: 12,
    marginBottom: 14,
  },
  detailHeaderCopy: {
    flex: 1,
    minWidth: 0,
  },
  detailTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  detailSubtitle: {
    color: 'rgba(226,232,240,0.72)',
    fontSize: 14,
    fontWeight: '600',
    marginTop: 4,
  },
  detailCloseBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
  },
  detailHeroRow: {
    flexDirection: 'row',
    alignItems: 'stretch',
    justifyContent: 'space-between',
    gap: 12,
    marginBottom: 16,
  },
  detailAvatarWrap: {
    width: 78,
    height: 78,
    borderRadius: 22,
    overflow: 'hidden',
  },
  detailAvatar: {
    width: '100%',
    height: '100%',
  },
  detailAvatarFallback: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  detailAvatarLetter: {
    color: '#F9FAFB',
    fontSize: 28,
    fontWeight: '900',
  },
  detailValeterAvatar: {
    width: 20,
    height: 20,
    borderRadius: 10,
  },
  detailValeterAvatarFallback: {
    width: 20,
    height: 20,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(135,206,235,0.24)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.38)',
  },
  detailValeterAvatarLetter: {
    color: '#F9FAFB',
    fontSize: 9,
    fontWeight: '800',
  },
  detailHeroStats: {
    flex: 1,
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    gap: 10,
  },
  detailPricePill: {
    minWidth: 126,
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 18,
    backgroundColor: 'rgba(135,206,235,0.14)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.28)',
    alignItems: 'flex-end',
  },
  detailPricePillGreen: {
    backgroundColor: 'rgba(16,185,129,0.14)',
    borderColor: 'rgba(16,185,129,0.28)',
  },
  detailPricePillRed: {
    backgroundColor: 'rgba(248,113,113,0.14)',
    borderColor: 'rgba(248,113,113,0.28)',
  },
  detailPriceValue: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '900',
    letterSpacing: -0.25,
  },
  detailPriceLabel: {
    color: 'rgba(248,250,252,0.7)',
    fontSize: 12,
    fontWeight: '600',
    marginTop: 2,
  },
  detailStatusWrap: {
    alignSelf: 'flex-end',
  },
  detailScrollContent: {
    gap: 14,
    paddingBottom: 18,
  },
  detailInfoCard: {
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.16)',
    padding: 16,
    gap: 12,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
  },
  detailRowText: {
    flex: 1,
    color: 'rgba(249,250,251,0.92)',
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 20,
  },
  detailMapWrap: {
    height: 220,
    borderRadius: 22,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.16)',
    backgroundColor: 'rgba(8,15,26,0.72)',
  },
  detailMapPin: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: 'rgba(15,23,42,0.94)',
    borderWidth: 2,
    borderColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
  },
  detailMapPlaceholder: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
  },
  detailMapPlaceholderText: {
    color: 'rgba(148,163,184,0.68)',
    fontSize: 12,
    fontWeight: '600',
  },
  detailActions: {
    flexDirection: 'row',
    gap: 12,
    paddingTop: 12,
  },
  detailActionGhost: {
    flex: 1,
    minWidth: 0,
    paddingVertical: 14,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
    backgroundColor: 'rgba(255,255,255,0.04)',
  },
  detailActionGhostText: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '800',
  },
  detailActionPrimary: {
    flex: 1,
    minWidth: 0,
    paddingVertical: 14,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: SKY,
  },
  detailActionPrimaryDisabled: {
    opacity: 0.45,
  },
  detailActionPrimaryText: {
    color: '#0B1D34',
    fontSize: 15,
    fontWeight: '900',
  },
});
