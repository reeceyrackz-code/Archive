/**
 * Business Stripe Connect — calm 3-step payout setup process.
 */
import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  TouchableOpacity,
  Linking,
  ActivityIndicator,
  Modal,
  Pressable,
  Animated,
  Easing,
  LayoutAnimation,
  Platform,
  UIManager,
  ScrollView,
  RefreshControl,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useLocalSearchParams } from 'expo-router';
import { ChromeGlyph as Ionicons } from '../../src/components/shared/ChromeGlyph';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import {
  businessOnboardingService,
  BusinessOnboardingStatus,
  type StripeConnectStatus,
} from '../../src/services/businessOnboardingService';
import { stripeConnectService } from '../../src/services/stripeConnectService';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import { lightMistElevated, lightMistPanel } from '../../src/constants/accountThemes';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import LoadingScreen from '../../src/components/LoadingScreen';
import ContinueCTAButton from '../../src/components/ui/ContinueCTAButton';
import AppHeader, { HEADER_HEIGHT } from '../../src/components/shared/AppHeader';

if (Platform.OS === 'android' && UIManager.setLayoutAnimationEnabledExperimental) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

const STEPS = [
  { id: 1, label: 'Connect', title: 'Link your payout account' },
  { id: 2, label: 'Verify', title: 'Stripe is checking your details' },
  { id: 3, label: 'Ready', title: "You're ready to get paid" },
] as const;

function stepIndexForStatus(status: StripeConnectStatus | undefined): number {
  switch (status) {
    case 'completed':
      return 3;
    case 'in_progress':
    case 'restricted':
    case 'rejected':
      return 2;
    case 'not_started':
    default:
      return 1;
  }
}

function shortenAccountId(id: string | null | undefined): string {
  if (!id || id.length < 12) return id || 'Not linked yet';
  return `${id.slice(0, 10)}…${id.slice(-4)}`;
}

function formatRelativeTimestamp(value: string | null | undefined): string {
  if (!value) return 'Not synced yet';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  const diffMs = Date.now() - date.getTime();
  const diffMinutes = Math.max(1, Math.round(diffMs / 60000));
  if (diffMinutes < 60) return `${diffMinutes}m ago`;
  const diffHours = Math.round(diffMinutes / 60);
  if (diffHours < 24) return `${diffHours}h ago`;
  return `${Math.round(diffHours / 24)}d ago`;
}

type RailNodeState = { done: boolean; current: boolean; attention: boolean; accent: string };

function railNodeBorderColor({ done, current, attention, accent }: RailNodeState): string {
  if (!done && !current) return 'rgba(255,255,255,0.2)';
  return attention && current ? '#FCA5A5' : accent;
}

function railNodeBackground({ done, current, attention, accent }: RailNodeState): string {
  if (done) return accent;
  if (!current) return 'rgba(255,255,255,0.06)';
  return attention ? 'rgba(248,113,113,0.22)' : `${accent}28`;
}

function railNodeTextColor({ current, attention, accent }: RailNodeState): string {
  if (!current) return 'rgba(248,250,252,0.45)';
  return attention ? '#FCA5A5' : accent;
}

function railLabelColor(current: boolean, done: boolean, gold: string): string {
  if (current) return gold;
  return done ? 'rgba(248,250,252,0.78)' : 'rgba(248,250,252,0.4)';
}

function ProgressRail({
  activeStep,
  accent,
  gold,
  attention,
}: Readonly<{ activeStep: number; accent: string; gold: string; attention: boolean }>) {
  const pulse = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, {
          toValue: 1,
          duration: 1100,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
        Animated.timing(pulse, {
          toValue: 0,
          duration: 1100,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [pulse, activeStep]);

  return (
    <View style={styles.rail}>
      {STEPS.map((step, index) => {
        const n = step.id;
        const done = n < activeStep;
        const current = n === activeStep;
        const nodeState = { done, current, attention, accent };
        return (
          <React.Fragment key={step.id}>
            {index > 0 ? (
              <View
                style={[
                  styles.railLine,
                  { backgroundColor: n <= activeStep ? accent : 'rgba(255,255,255,0.14)' },
                ]}
              />
            ) : null}
            <View style={styles.railNodeWrap}>
              <Animated.View
                style={[
                  styles.railNode,
                  {
                    borderColor: railNodeBorderColor(nodeState),
                    backgroundColor: railNodeBackground(nodeState),
                    transform: current
                      ? [
                          {
                            scale: pulse.interpolate({
                              inputRange: [0, 1],
                              outputRange: [1, 1.08],
                            }),
                          },
                        ]
                      : undefined,
                  },
                ]}
              >
                {done ? (
                  <Ionicons name="checkmark" size={16} color="#0A1929" />
                ) : (
                  <Text
                    style={[
                      styles.railNodeText,
                      { color: railNodeTextColor(nodeState) },
                    ]}
                  >
                    {n}
                  </Text>
                )}
              </Animated.View>
              <Text
                style={[
                  styles.railLabel,
                  {
                    color: railLabelColor(current, done, gold),
                    fontWeight: current ? '800' : '600',
                  },
                ]}
              >
                {step.label}
              </Text>
            </View>
          </React.Fragment>
        );
      })}
    </View>
  );
}

type AccountTheme = ReturnType<typeof useAccountTheme>['theme'];
type DialogType = 'error' | 'warning' | 'info';

function resolveStripePalette(theme: AccountTheme, isLight: boolean) {
  return {
    primary: theme.primary || '#9EC9E0',
    gold: theme.accentAlt || '#E8C547',
    surface: isLight ? lightMistElevated : 'rgba(255,255,255,0.06)',
    panel: isLight ? lightMistPanel : 'rgba(255,255,255,0.05)',
    border: isLight ? theme.glassBorder || 'rgba(158,201,224,0.42)' : 'rgba(255,255,255,0.12)',
    textMain: theme.textPrimary || '#F8FAFC',
    textMuted: theme.textOnBackground || 'rgba(248,250,252,0.66)',
  };
}

function getStripeSyncedAt(status: BusinessOnboardingStatus | null): string | null {
  const details = (status?.stripeDetails ?? {}) as Record<string, any>;
  return (
    details.updated_from_stripe_at ??
    details.updated_from_stripe_webhook_at ??
    status?.stripeOnboardingCompletedAt ??
    status?.stripeOnboardingStartedAt ??
    null
  );
}

function dialogTypeStyle(type: DialogType) {
  if (type === 'error') return styles.dialogError;
  if (type === 'warning') return styles.dialogWarning;
  return styles.dialogInfo;
}

export default function BusinessStripeConnectScreen() {
  const { user, logout } = useAuth();
  const params = useLocalSearchParams();
  const insets = useSafeAreaInsets();
  const { theme, mode } = useAccountTheme();
  const isLight = mode === 'light';
  const { primary, gold, surface, panel, border, textMain, textMuted } = resolveStripePalette(theme, isLight);
  const isOnboardingMode = params?.mode === 'onboarding';
  const autoSyncAttemptedRef = useRef(false);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [status, setStatus] = useState<BusinessOnboardingStatus | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [dialogVisible, setDialogVisible] = useState(false);
  const [dialogTitle, setDialogTitle] = useState('');
  const [dialogMessage, setDialogMessage] = useState('');
  const [dialogType, setDialogType] = useState<DialogType>('info');
  const [dialogActions, setDialogActions] = useState<
    Array<{ label: string; kind?: 'primary' | 'secondary' | 'danger'; onPress?: () => void }>
  >([]);

  const openDialog = (
    title: string,
    message: string,
    type: DialogType = 'info',
    actions: Array<{ label: string; kind?: 'primary' | 'secondary' | 'danger'; onPress?: () => void }> = [
      { label: 'Close', kind: 'primary' },
    ]
  ) => {
    setDialogTitle(title);
    setDialogMessage(message);
    setDialogType(type);
    setDialogActions(actions);
    setDialogVisible(true);
  };

  const load = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      const next = await businessOnboardingService.getStatus(user.id);
      setStatus(next);
    } catch (error: any) {
      openDialog('Unable to load Stripe setup', error?.message || 'Failed to load Stripe Connect status.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, [user?.id]);

  useEffect(() => {
    if (!params?.stripe_return && !params?.stripe_refresh) return;
    void handleCheckStatus(true);
  }, [params?.stripe_return, params?.stripe_refresh]);

  const startConnect = async () => {
    if (saving) return;
    try {
      await hapticFeedback('light');
      setSaving(true);
      if (user?.id) {
        await businessOnboardingService.setStripeSkipForNow(user.id, false);
      }
      const { url } = await stripeConnectService.createOnboardingLink();
      await Linking.openURL(url);
    } catch (error: any) {
      openDialog('Unable to start Stripe Connect', error?.message || 'Failed to start Stripe Connect.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleCheckStatus = async (silent = false) => {
    if (saving || refreshing) return;
    try {
      await hapticFeedback('light');
      setRefreshing(true);
      const result = await stripeConnectService.syncStatusFromStripe();
      await load();
      if (result.stripeConnectStatus === 'completed') {
        router.replace('/business/dashboard');
        return;
      }
      if (!silent) {
        openDialog(
          'Still verifying',
          'Finish the remaining steps in Stripe, then come back and tap Refresh.',
          'warning'
        );
      }
    } catch (error: any) {
      openDialog('Unable to check Stripe status', error?.message || 'Failed to check Stripe status.', 'error');
    } finally {
      setRefreshing(false);
    }
  };

  useEffect(() => {
    if (loading || saving || refreshing || autoSyncAttemptedRef.current) return;
    if (!status?.stripeAccountId || status.stripeConnectStatus === 'completed') return;
    autoSyncAttemptedRef.current = true;
    void handleCheckStatus(true);
  }, [loading, saving, refreshing, status?.stripeAccountId, status?.stripeConnectStatus]);

  const handleBackOrLogout = async () => {
    if (saving) return;
    if (isOnboardingMode) {
      try {
        await hapticFeedback('medium');
        setSaving(true);
        await logout();
        router.replace('/auth/login');
      } catch (error: any) {
        openDialog('Unable to log out', error?.message || 'Failed to log out.', 'error');
      } finally {
        setSaving(false);
      }
      return;
    }
    router.back();
  };

  const stripeState = status?.stripeConnectStatus ?? 'not_started';
  const activeStep = stepIndexForStatus(stripeState);
  const isComplete = stripeState === 'completed';
  const attention = stripeState === 'restricted' || stripeState === 'rejected';
  const hasStarted = stripeState !== 'not_started';

  const copy = useMemo(() => {
    if (stripeState === 'completed') {
      return {
        title: "You're ready to get paid",
        body: 'Your business can receive platform payouts. Stripe handles transfer timing and verification.',
      };
    }
    if (stripeState === 'restricted') {
      return {
        title: 'Stripe needs a little more',
        body: 'Open Stripe to finish the remaining verification steps, then refresh here.',
      };
    }
    if (stripeState === 'rejected') {
      return {
        title: 'Stripe needs updated details',
        body: 'Review the business information in Stripe, update what’s needed, then refresh status here.',
      };
    }
    if (stripeState === 'in_progress') {
      return {
        title: 'Stripe is checking your details',
        body: 'Finish any open steps in Stripe’s secure form, then return here and refresh.',
      };
    }
    return {
      title: 'Link your payout account',
      body: 'Connect once with Stripe so this business can receive payouts through the platform.',
    };
  }, [stripeState]);

  const primaryLabel = (() => {
    if (isComplete) return isOnboardingMode ? 'Continue to app' : 'Done';
    if (stripeState === 'restricted' || stripeState === 'rejected') return 'Fix in Stripe';
    if (stripeState === 'in_progress') return 'Finish in Stripe';
    return 'Connect with Stripe';
  })();

  const onPrimary = () => {
    if (isComplete) {
      if (isOnboardingMode) router.replace('/business/dashboard');
      else router.back();
      return;
    }
    void startConnect();
  };

  const stripeDetails = status?.stripeDetails ?? {};
  const stripeSyncedAt = getStripeSyncedAt(status);

  if (loading) {
    return <LoadingScreen message="Loading payout setup…" />;
  }

  return (
    <View style={styles.flex}>
      <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />

      <SafeAreaView style={styles.flex} edges={[]}>
        <AppHeader
          title="Payout setup"
          subtitle="Wish a Washer App"
          accountType="business"
          fullWidth
          flushTop
          rightAction={
            isOnboardingMode ? (
              <TouchableOpacity
                style={[styles.logoutBtn, { borderColor: `${primary}40` }]}
                onPress={handleBackOrLogout}
                activeOpacity={0.85}
              >
                <Ionicons name="log-out-outline" size={18} color={textMain} />
                <Text style={[styles.logoutText, { color: textMain }]}>Log out</Text>
              </TouchableOpacity>
            ) : null
          }
        />

        <ScrollView
          style={styles.scroll}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[
            styles.scrollInner,
            {
              paddingTop: insets.top + HEADER_HEIGHT + 16,
              paddingBottom: 24 + insets.bottom,
            },
          ]}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={() => {
                void handleCheckStatus(true);
              }}
              tintColor={primary}
              colors={[primary]}
              progressBackgroundColor="rgba(15,30,48,0.9)"
            />
          }
        >
          <View style={styles.logoRow}>
            <Image
              source={require('../../assets/stripe/img.png')}
              style={styles.stripeLogo}
              resizeMode="contain"
            />
          </View>

          <ProgressRail activeStep={activeStep} accent={primary} gold={gold} attention={attention} />

          <View
            style={[
              styles.statusCard,
              { backgroundColor: surface, borderColor: attention ? 'rgba(248,113,113,0.45)' : border },
            ]}
          >
            <Text style={[styles.stepEyebrow, { color: attention ? '#FCA5A5' : gold }]}>
              STEP {activeStep} OF 3
            </Text>
            <Text style={[styles.statusTitle, { color: textMain }]}>{copy.title}</Text>
            <Text style={[styles.statusBody, { color: textMuted }]}>{copy.body}</Text>
          </View>

          {(isComplete || hasStarted) && (
            <TouchableOpacity
              style={[styles.detailsToggle, { borderColor: border, backgroundColor: panel }]}
              onPress={() => {
                LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
                setDetailsOpen((v) => !v);
              }}
              activeOpacity={0.85}
            >
              <Text style={[styles.detailsToggleText, { color: textMain }]}>Account details</Text>
              <Ionicons name={detailsOpen ? 'chevron-up' : 'chevron-down'} size={18} color={primary} />
            </TouchableOpacity>
          )}

          {detailsOpen ? (
            <View style={[styles.detailsCard, { backgroundColor: panel, borderColor: border }]}>
              <View style={styles.detailRow}>
                <Text style={[styles.detailLabel, { color: textMuted }]}>Account</Text>
                <Text style={[styles.detailValue, { color: textMain }]} numberOfLines={1}>
                  {shortenAccountId(status?.stripeAccountId)}
                </Text>
              </View>
              <View style={styles.detailRow}>
                <Text style={[styles.detailLabel, { color: textMuted }]}>Payouts</Text>
                <Text style={[styles.detailValue, { color: textMain }]}>
                  {stripeDetails.payoutsEnabled ? 'Enabled' : 'Pending'}
                </Text>
              </View>
              <View style={styles.detailRow}>
                <Text style={[styles.detailLabel, { color: textMuted }]}>Last synced</Text>
                <Text style={[styles.detailValue, { color: textMain }]}>
                  {formatRelativeTimestamp(stripeSyncedAt)}
                </Text>
              </View>
            </View>
          ) : null}
        </ScrollView>

        <View style={[styles.footer, { paddingBottom: Math.max(14, insets.bottom + 10) }]}>
          <ContinueCTAButton
            title={primaryLabel}
            onPress={onPrimary}
            accentColor={primary}
            disabled={saving || refreshing}
            loading={saving}
            showTrailingChevron={!saving}
            style={styles.primaryCta}
          />

          {hasStarted && !isComplete ? (
            <TouchableOpacity
              style={[styles.refreshBtn, { borderColor: `${primary}44` }]}
              onPress={() => handleCheckStatus(false)}
              disabled={saving || refreshing}
              activeOpacity={0.88}
            >
              {refreshing ? (
                <ActivityIndicator color={textMain} />
              ) : (
                <>
                  <Ionicons name="refresh-outline" size={18} color={textMain} />
                  <Text style={[styles.refreshText, { color: textMain }]}>Refresh status</Text>
                </>
              )}
            </TouchableOpacity>
          ) : null}

          {isComplete ? (
            <TouchableOpacity style={styles.tertiaryBtn} onPress={startConnect} disabled={saving || refreshing} activeOpacity={0.85}>
              <Text style={[styles.tertiaryText, { color: textMuted }]}>Update Stripe details</Text>
            </TouchableOpacity>
          ) : null}

          <Text style={[styles.footerHint, { color: textMuted }]}>
            {isComplete
              ? 'Stripe controls payout timing and verification.'
              : 'You can leave and finish later — progress is saved.'}
          </Text>
        </View>
      </SafeAreaView>

      <Modal visible={dialogVisible} transparent animationType="fade" onRequestClose={() => setDialogVisible(false)}>
        <Pressable style={styles.dialogOverlay} onPress={() => setDialogVisible(false)}>
          <View
            style={[
              styles.dialogCard,
              dialogTypeStyle(dialogType),
            ]}
          >
            <Text style={styles.dialogTitle}>{dialogTitle}</Text>
            <Text style={styles.dialogMessage}>{dialogMessage}</Text>
            <View style={styles.dialogActions}>
              {dialogActions.map((action) => (
                <TouchableOpacity
                  key={action.label}
                  style={[
                    styles.dialogButton,
                    action.kind === 'secondary' && styles.dialogButtonSecondary,
                    action.kind === 'danger' && styles.dialogButtonDanger,
                  ]}
                  onPress={async () => {
                    await hapticFeedback('light');
                    setDialogVisible(false);
                    action.onPress?.();
                  }}
                >
                  <Text style={styles.dialogButtonText}>{action.label}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  scroll: { flex: 1 },
  scrollInner: {
    paddingHorizontal: 20,
    gap: 16,
  },
  logoutBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    borderWidth: 1,
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  logoutText: {
    fontSize: 13,
    fontWeight: '800',
  },
  logoRow: {
    alignItems: 'center',
    paddingTop: 4,
  },
  stripeLogo: {
    width: 120,
    height: 48,
  },
  rail: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'center',
    paddingHorizontal: 8,
    paddingVertical: 8,
  },
  railNodeWrap: {
    alignItems: 'center',
    width: 72,
    gap: 8,
  },
  railNode: {
    width: 36,
    height: 36,
    borderRadius: 18,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  railNodeText: {
    fontSize: 13,
    fontWeight: '800',
  },
  railLabel: {
    fontSize: 11,
    textAlign: 'center',
  },
  railLine: {
    flex: 1,
    height: 2,
    marginTop: 17,
    borderRadius: 1,
    maxWidth: 48,
  },
  statusCard: {
    borderRadius: 22,
    borderWidth: 1,
    paddingHorizontal: 18,
    paddingVertical: 18,
    gap: 8,
  },
  stepEyebrow: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1.4,
  },
  statusTitle: {
    fontSize: 24,
    fontWeight: '900',
    letterSpacing: -0.5,
    lineHeight: 30,
  },
  statusBody: {
    fontSize: 14,
    lineHeight: 21,
  },
  detailsToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderRadius: 14,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  detailsToggleText: {
    fontSize: 14,
    fontWeight: '700',
  },
  detailsCard: {
    borderRadius: 16,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 8,
    gap: 2,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
    paddingVertical: 10,
  },
  detailLabel: {
    fontSize: 12,
    fontWeight: '700',
  },
  detailValue: {
    flex: 1,
    textAlign: 'right',
    fontSize: 13,
    fontWeight: '800',
  },
  footer: {
    paddingHorizontal: 20,
    paddingTop: 10,
    gap: 10,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(255,255,255,0.08)',
  },
  primaryCta: {
    borderRadius: 20,
    minHeight: 52,
  },
  refreshBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    borderWidth: 1,
    borderRadius: 16,
    paddingVertical: 13,
  },
  refreshText: {
    fontSize: 15,
    fontWeight: '800',
  },
  tertiaryBtn: {
    alignItems: 'center',
    paddingVertical: 4,
  },
  tertiaryText: {
    fontSize: 13,
    fontWeight: '700',
  },
  footerHint: {
    fontSize: 12,
    lineHeight: 17,
    textAlign: 'center',
  },
  dialogOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.58)',
    justifyContent: 'center',
    padding: 20,
  },
  dialogCard: {
    borderRadius: 20,
    padding: 18,
    gap: 12,
    borderWidth: 1,
  },
  dialogError: { backgroundColor: '#1F0F10', borderColor: 'rgba(239,68,68,0.4)' },
  dialogWarning: { backgroundColor: '#1F1609', borderColor: 'rgba(245,158,11,0.4)' },
  dialogInfo: { backgroundColor: '#0C1B2A', borderColor: 'rgba(96,165,250,0.4)' },
  dialogTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '800' },
  dialogMessage: { color: 'rgba(249,250,251,0.72)', fontSize: 14, lineHeight: 20 },
  dialogActions: { flexDirection: 'row', gap: 10, justifyContent: 'flex-end', flexWrap: 'wrap' },
  dialogButton: {
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.12)',
  },
  dialogButtonSecondary: { backgroundColor: 'rgba(255,255,255,0.08)' },
  dialogButtonDanger: { backgroundColor: 'rgba(239,68,68,0.18)' },
  dialogButtonText: { color: '#F9FAFB', fontSize: 13, fontWeight: '800' },
});
