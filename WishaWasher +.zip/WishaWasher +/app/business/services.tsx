import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Animated,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import Reanimated, { FadeIn, ZoomIn } from 'react-native-reanimated';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import type { IconGlyphName } from '../../src/components/shared/iconGlyphTypes';
import { ChromeGlyph as Ionicons } from '../../src/components/shared/ChromeGlyph';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import LoadingScreen from '../../src/components/LoadingScreen';
import { colors } from '../../src/constants/colors';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import GlassSurface from '../../src/components/shared/GlassSurface';
import InlineToast, { type ToastState } from '../../src/components/shared/InlineToast';
import ServiceTierCard from '../../src/components/business/ServiceTierCard';
import ServicePricingSheet from '../../src/components/business/ServicePricingSheet';
import { WASH_DEFINITIONS, getVehicleSizeAdjustmentGBP, type VehicleSize } from '../../src/pricing/pricingEngine';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';
import ContinueCTAButton from '../../src/components/ui/ContinueCTAButton';
import { getServiceIcon } from '../../src/constants/serviceIcons';

const BG = colors.BG;
const SIZES: VehicleSize[] = ['SMALL', 'MEDIUM', 'LARGE', 'XL', 'XXL'];

const TIER_ICON: Record<string, IconGlyphName> = {
  BRONZE: getServiceIcon('bronze-wash'),
  SILVER: getServiceIcon('silver-wash'),
  GOLD: getServiceIcon('gold-wash'),
  PLATINUM: getServiceIcon('platinum-wash'),
  DIAMOND: getServiceIcon('emerald-wash'),
};

const TIER_HEX: Record<string, string> = {
  BRONZE: '#CD7F32',
  SILVER: '#C0C0C0',
  GOLD: '#FFD700',
  PLATINUM: '#E5E4E2',
  DIAMOND: '#22D3EE',
};

type ServiceConfig = {
  id: string;
  name: string;
  description: string;
  tier: string;
  enabled: boolean;
  prices: Record<VehicleSize, number>;
};

function saveButtonTitle(unsavedCount: number): string {
  if (unsavedCount <= 0) return 'Save services';
  return `Save ${unsavedCount} change${unsavedCount === 1 ? '' : 's'}`;
}

export default function BusinessServices() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme: businessTheme } = useAccountTheme();
  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const textMain = businessTheme.textPrimary ?? '#F9FAFB';
  const muted = businessTheme.textSecondary ?? 'rgba(249,250,251,0.72)';
  const glassBorder = businessTheme.glassBorder;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [services, setServices] = useState<ServiceConfig[]>([]);
  const [editingServiceId, setEditingServiceId] = useState<string | null>(null);
  const [priceDraft, setPriceDraft] = useState<Record<VehicleSize, string> | null>(null);
  const [baseline, setBaseline] = useState<ServiceConfig[] | null>(null);
  const [toast, setToast] = useState<ToastState>(null);
  const hideToast = useCallback(() => setToast(null), []);

  useEffect(() => {
    if (!loading && baseline === null && services.length > 0) setBaseline(services);
  }, [loading, baseline, services]);

  const changedIds = useMemo(() => {
    if (!baseline) return new Set<string>();
    const ids = new Set<string>();
    for (const service of services) {
      const before = baseline.find((b) => b.id === service.id);
      if (!before) continue;
      const pricesChanged = SIZES.some((size) => before.prices[size] !== service.prices[size]);
      if (before.enabled !== service.enabled || pricesChanged) ids.add(service.id);
    }
    return ids;
  }, [baseline, services]);
  const unsavedCount = changedIds.size;
  const enabledCount = services.filter((s) => s.enabled).length;

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 450,
      useNativeDriver: true,
    }).start();
  }, [fadeAnim]);

  useEffect(() => {
    if (user?.id) {
      void loadServices();
    } else {
      setLoading(false);
    }
  }, [user?.id]);

  const loadServices = async () => {
    try {
      setLoading(true);
      const mapped: ServiceConfig[] = WASH_DEFINITIONS.filter((wash) => wash.isMobile).map((wash) => {
        const prices = SIZES.reduce((acc, size) => {
          acc[size] = wash.basePriceSmallGBP + getVehicleSizeAdjustmentGBP(size);
          return acc;
        }, {} as Record<VehicleSize, number>);

        return {
          id: wash.id,
          name: wash.label,
          description: wash.description,
          tier: wash.tier,
          enabled: true,
          prices,
        };
      });
      setServices(mapped);
    } catch (error) {
      console.error('[BusinessServices] Failed to load services:', error);
      Alert.alert('Error', 'Failed to load services.');
    } finally {
      setLoading(false);
    }
  };

  const filteredServices = services;

  const toggleService = async (serviceId: string) => {
    await hapticFeedback('light');
    setServices((prev) => prev.map((service) => (service.id === serviceId ? { ...service, enabled: !service.enabled } : service)));
  };

  const getServicePriceRange = (service: ServiceConfig) => {
    const values = SIZES.map((size) => service.prices[size]);
    return { min: Math.min(...values), max: Math.max(...values) };
  };

  const getSelectedService = () => services.find((service) => service.id === editingServiceId) ?? null;

  const closePricingSheet = () => {
    setEditingServiceId(null);
    setPriceDraft(null);
  };

  const commitPricingDraft = () => {
    if (!editingServiceId || !priceDraft) {
      closePricingSheet();
      return;
    }
    const parseMoney = (raw: string) => {
      const cleaned = raw.replaceAll(',', '').trim();
      if (cleaned === '' || cleaned === '.') return 0;
      const n = Number.parseFloat(cleaned);
      return Number.isFinite(n) ? Math.max(0, n) : 0;
    };
    setServices((prev) =>
      prev.map((service) => {
        if (service.id !== editingServiceId) return service;
        const nextPrices = { ...service.prices };
        for (const size of SIZES) {
          nextPrices[size] = parseMoney(priceDraft[size] ?? '');
        }
        return { ...service, prices: nextPrices };
      })
    );
    closePricingSheet();
  };

  const handleSave = async () => {
    if (!user?.id) return;
    try {
      setSaving(true);
      setBaseline(services);
      void hapticFeedback('success');
      setToast({ kind: 'success', message: 'Services configuration updated' });
    } catch (error) {
      console.error('[BusinessServices] Failed to save services:', error);
      void hapticFeedback('error');
      setToast({ kind: 'error', message: 'Could not save services configuration' });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
        <LoadingScreen message="Loading services..." />
      </SafeAreaView>
    );
  }

  const selectedService = getSelectedService();

  const openPricing = async (service: ServiceConfig) => {
    await hapticFeedback('light');
    setPriceDraft(
      SIZES.reduce((acc, size) => {
        acc[size] = String(service.prices[size]);
        return acc;
      }, {} as Record<VehicleSize, string>)
    );
    setEditingServiceId(service.id);
  };

  const headerSave = (
    <TouchableOpacity
      onPress={handleSave}
      disabled={saving}
      activeOpacity={0.8}
      accessibilityRole="button"
      accessibilityLabel={unsavedCount > 0 ? `Save ${unsavedCount} changes` : 'Save services'}
    >
      <GlassSurface
        style={styles.headerSave}
        tintColor={unsavedCount > 0 ? `${businessTheme.primary}55` : undefined}
        borderColor={unsavedCount > 0 ? businessTheme.primary : glassBorder}
        interactive
      >
        {saving ? (
          <ActivityIndicator size="small" color="#F9FAFB" />
        ) : (
          <Text style={styles.headerSaveText}>Save</Text>
        )}
      </GlassSurface>
      {unsavedCount > 0 && !saving ? (
        <Reanimated.View
          key={unsavedCount}
          entering={ZoomIn.springify().damping(12)}
          style={[styles.headerBadge, { backgroundColor: businessTheme.primary }]}
        >
          <Text style={styles.headerBadgeText}>{unsavedCount}</Text>
        </Reanimated.View>
      ) : null}
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />
      <AppHeader title="Services & pricing" accountType="business" rightAction={headerSave} />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
        scrollEventThrottle={16}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingTop: HEADER_CONTENT_OFFSET, paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 24 },
        ]}
      >
        <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
          <Text style={[styles.heroKicker, { color: muted }]}>Configuration</Text>
          <Text style={[styles.heroTitle, { color: textMain }]}>Your wash tiers</Text>
          <Text style={[styles.heroSubtitle, { color: muted }]}>
            Enable tiers and set per–vehicle-size pricing. Matches how valeters see their services list.
          </Text>

          <Reanimated.View entering={FadeIn.delay(120)} style={styles.summaryRow}>
            <GlassSurface style={styles.summaryPill} borderColor={glassBorder}>
              <View style={[styles.summaryDot, { backgroundColor: '#4ADE80' }]} />
              <Text style={[styles.summaryText, { color: textMain }]}>
                {enabledCount} of {services.length} active
              </Text>
            </GlassSurface>
            {unsavedCount > 0 ? (
              <Reanimated.View entering={FadeIn}>
                <GlassSurface
                  style={styles.summaryPill}
                  tintColor={`${businessTheme.primary}33`}
                  borderColor={`${businessTheme.primary}88`}
                >
                  <View style={[styles.summaryDot, { backgroundColor: businessTheme.primary }]} />
                  <Text style={[styles.summaryText, { color: textMain }]}>
                    {unsavedCount} unsaved
                  </Text>
                </GlassSurface>
              </Reanimated.View>
            ) : null}
          </Reanimated.View>

          <View style={styles.listSection}>
            {filteredServices.map((service, index) => {
              const range = getServicePriceRange(service);
              return (
                <ServiceTierCard
                  key={service.id}
                  index={index}
                  name={service.name}
                  description={service.description}
                  tier={service.tier}
                  enabled={service.enabled}
                  minPrice={range.min}
                  maxPrice={range.max}
                  tierHex={TIER_HEX[service.tier] ?? businessTheme.primary}
                  tierIcon={TIER_ICON[service.tier] ?? getServiceIcon(service.name)}
                  accent={businessTheme.primary}
                  textMain={textMain}
                  muted={muted}
                  glassBorder={glassBorder}
                  edited={changedIds.has(service.id)}
                  onToggle={() => toggleService(service.id)}
                  onEdit={() => openPricing(service)}
                />
              );
            })}
          </View>

          <ContinueCTAButton
            title={saveButtonTitle(unsavedCount)}
            onPress={handleSave}
            accentColor={businessTheme.primary}
            disabled={saving}
            loading={saving}
            style={styles.saveCta}
            leading={<Ionicons name="save-outline" size={20} color={colors.textOnDarkPrimary} />}
          />
        </Animated.View>
      </Animated.ScrollView>

      <ServicePricingSheet
        visible={!!editingServiceId}
        title={selectedService?.name ?? 'Service pricing'}
        tier={selectedService?.tier}
        tierHex={(selectedService && TIER_HEX[selectedService.tier]) ?? businessTheme.primary}
        accent={businessTheme.primary}
        sizes={SIZES}
        draft={priceDraft}
        borderColor={glassBorder}
        onChangeDraft={setPriceDraft}
        onClose={closePricingSheet}
        onSave={() => {
          void hapticFeedback('medium');
          commitPricingDraft();
        }}
      />

      <InlineToast toast={toast} onHide={hideToast} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  scrollView: { flex: 1 },
  scrollContent: { paddingHorizontal: 20 },
  content: { gap: 0 },
  heroKicker: { marginBottom: 6, fontSize: 12, fontWeight: '800', letterSpacing: 1.2, textTransform: 'uppercase' },
  heroTitle: { fontSize: 26, fontWeight: '800', letterSpacing: -0.4, marginBottom: 8 },
  heroSubtitle: { fontSize: 14, lineHeight: 21, marginBottom: 16 },
  summaryRow: { flexDirection: 'row', gap: 8, marginBottom: 18, flexWrap: 'wrap' },
  summaryPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 999,
  },
  summaryDot: { width: 7, height: 7, borderRadius: 4 },
  summaryText: { fontSize: 12, fontWeight: '800' },
  listSection: { gap: 12, paddingBottom: 8 },
  saveCta: { marginTop: 28, marginBottom: 8 },
  headerSave: {
    minWidth: 64,
    height: 36,
    paddingHorizontal: 14,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerSaveText: { color: '#F9FAFB', fontSize: 14, fontWeight: '800' },
  headerBadge: {
    position: 'absolute',
    top: -6,
    right: -6,
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    paddingHorizontal: 4,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1.5,
    borderColor: '#0A1929',
  },
  headerBadgeText: { color: '#0A1929', fontSize: 10, fontWeight: '900' },
});
