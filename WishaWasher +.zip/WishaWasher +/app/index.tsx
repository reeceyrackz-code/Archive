// app/index.tsx
import React, { useEffect, useState } from 'react';
import { useRouter, useRootNavigationState } from 'expo-router';
import { useAuth } from '../src/providers/enhanced-auth-context';
import LoadingScreen from '../src/components/LoadingScreen';
import { isValeterRole, isOrganizationRole, normalizeUserType } from '../src/utils/authRole';
import { termsAgreementService, type TermsStatus } from '../src/services/termsAgreementService';
import { businessOnboardingService } from '../src/services/businessOnboardingService';
import { stripeConnectService } from '../src/services/stripeConnectService';
import { valeterStripeConnectService } from '../src/services/valeterStripeConnectService';

type StripeConnectStatus =
  | 'not_started'
  | 'in_progress'
  | 'completed'
  | 'restricted'
  | 'rejected';

type StripeGateStatus = {
  stripeConnectStatus: StripeConnectStatus;
  stripeAccountId: string | null;
};

function accountTypeFor(userType: string | undefined): 'business' | 'valeter' | null {
  if (userType === 'organization') return 'business';
  if (userType === 'valeter') return 'valeter';
  return null;
}

function termsRouteFor(termsStatus: TermsStatus, userType: string | undefined): string | null {
  if (termsStatus === 'declined') {
    if (userType === 'organization') return '/business/terms-blocked';
    if (userType === 'valeter') return '/valeter/terms-blocked';
  }
  if (termsStatus !== 'accepted') {
    if (userType === 'organization') return '/business/terms';
    if (userType === 'valeter') return '/valeter/terms';
  }
  return null;
}

function stripeGateRouteFor(status: StripeConnectStatus, userType: string | undefined): string | null {
  if (status !== 'not_started' && status !== 'restricted' && status !== 'rejected') return null;
  if (userType === 'organization') return '/business/stripe-connect';
  if (userType === 'valeter') return '/valeter/stripe-connect';
  return '/auth/login';
}

function dashboardRouteFor(userType: string | undefined): string {
  if (userType === 'valeter') return '/valeter/valeter-dashboard';
  if (userType === 'organization') return '/business/dashboard';
  return '/auth/login';
}

export default function Index() {
  const router = useRouter();
  const navReady = useRootNavigationState()?.key != null;
  const { user, isLoading, authReady, logout } = useAuth();

  const [termsStatus, setTermsStatus] = useState<TermsStatus | null>(null);
  const [stripeStatus, setStripeStatus] = useState<StripeGateStatus | null>(null);
  const stripeRefreshAttemptedRef = React.useRef(false);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      if (!user || !authReady || isLoading) {
        setTermsStatus(null);
        setStripeStatus(null);
        return;
      }

      const userType = normalizeUserType(user?.userType, null) ?? undefined;

      // Owner/customer accounts cannot use this CCP/valeter app.
      if (userType && !isValeterRole(userType) && !isOrganizationRole(userType)) {
        setTermsStatus(null);
        setStripeStatus(null);
        return;
      }

      const accountType = accountTypeFor(userType);
      if (!accountType) {
        setTermsStatus(null);
        setStripeStatus(null);
        return;
      }

      try {
        const [rec, stripeRec] = await Promise.all([
          termsAgreementService.load(accountType, user.id),
          accountType === 'business'
            ? businessOnboardingService.getStatus(user.id)
            : valeterStripeConnectService.getStatus(user.id),
        ]);
        if (!cancelled) setTermsStatus(rec.status);
        if (!cancelled) {
          setStripeStatus({
            stripeConnectStatus: stripeRec.stripeConnectStatus,
            stripeAccountId: stripeRec.stripeAccountId,
          });
        }
      } catch {
        if (!cancelled) {
          setTermsStatus('pending');
          setStripeStatus({
            stripeConnectStatus: 'not_started',
            stripeAccountId: null,
          });
        }
      }
    })();
    return () => {
      cancelled = true;
      stripeRefreshAttemptedRef.current = false;
    };
  }, [authReady, isLoading, user?.id, user?.userType]);

  useEffect(() => {
    if (!navReady || !authReady || isLoading) return;
    const userType = normalizeUserType(user?.userType, null) ?? undefined;

    // 1) Not logged in → auth flow
    if (!user) {
      router.replace('/auth/login');
      return;
    }

    // Owner / customer accounts cannot enter the valeter (CCP) app.
    if (!isValeterRole(userType) && !isOrganizationRole(userType)) {
      void (async () => {
        try {
          if (typeof logout === 'function') await logout();
        } catch {
          // ignore
        } finally {
          router.replace('/auth/login');
        }
      })();
      return;
    }

    if (termsStatus === null || stripeStatus === null) {
      return;
    }

    const termsRoute = termsRouteFor(termsStatus, userType);
    if (termsRoute) {
      router.replace(termsRoute);
      return;
    }

    const shouldRefreshStripe =
      stripeStatus.stripeConnectStatus !== 'completed' &&
      !!stripeStatus.stripeAccountId &&
      !stripeRefreshAttemptedRef.current;

    if (shouldRefreshStripe) {
      stripeRefreshAttemptedRef.current = true;
      void (async () => {
        try {
          const live = await stripeConnectService.syncStatusFromStripe();
          setStripeStatus({
            stripeConnectStatus: live.stripeConnectStatus,
            stripeAccountId: live.stripeAccountId,
          });
        } catch {
          // Keep the locally cached status if Stripe is temporarily unavailable.
        }
      })();
      return;
    }

    const stripeRoute = stripeGateRouteFor(stripeStatus.stripeConnectStatus, userType);
    if (stripeRoute) {
      router.replace(stripeRoute);
      return;
    }

    // 3) Ready → dashboards (valeter / business only); fallback never sends owner/customer into valeter
    router.replace(dashboardRouteFor(userType));
  }, [navReady, authReady, isLoading, user, termsStatus, stripeStatus, router, logout]);

  return <LoadingScreen overlay={false} />;
}
