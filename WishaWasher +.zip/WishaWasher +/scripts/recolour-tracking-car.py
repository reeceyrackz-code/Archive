"""Builds colour variants of assets/tracking-car.png for the tracking scene.

Only the blue body paint is shifted (weighted by how blue/saturated a pixel is), so glass, lights,
plate and outlines keep their look. Re-run after replacing the source art:

    python3 scripts/recolour-tracking-car.py
"""

import colorsys
import os

from PIL import Image

SRC = 'assets/tracking-car.png'
OUT_DIR = 'assets/tracking-car'
OUT_W = 512

# (hue 0-1 or None for neutral, saturation scale, value curve (a, b) -> a + b * v)
VARIANTS = {
    'black': (None, 0.12, (0.04, 0.32)),
    'white': (None, 0.06, (0.5, 0.5)),
    'silver': (None, 0.08, (0.36, 0.52)),
    'grey': (None, 0.08, (0.22, 0.5)),
    'red': (0.995, 1.0, (0.0, 0.95)),
    'green': (0.36, 0.85, (0.0, 0.8)),
    'yellow': (0.13, 1.0, (0.12, 0.9)),
    'orange': (0.07, 1.0, (0.05, 0.95)),
    'brown': (0.07, 0.65, (0.0, 0.55)),
    'purple': (0.77, 0.8, (0.0, 0.85)),
}


def smoothstep(e0, e1, x):
    t = max(0.0, min(1.0, (x - e0) / (e1 - e0)))
    return t * t * (3 - 2 * t)


def paint_weight(h, s, v):
    """How much this pixel is body paint: blue hue, saturated, not near-black."""
    hue_deg = h * 360
    hue_w = 1 - smoothstep(18, 34, abs(hue_deg - 212))
    return hue_w * smoothstep(0.28, 0.5, s) * smoothstep(0.12, 0.25, v)


def recolour(src, spec):
    hue, s_scale, (va, vb) = spec
    out = src.copy()
    px = out.load()
    w, h = out.size
    for y in range(h):
        for x in range(w):
            r, g, b, a = px[x, y]
            if a == 0:
                continue
            hh, ss, vv = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
            k = paint_weight(hh, ss, vv)
            if k <= 0:
                continue
            nh = hh if hue is None else hue
            ns = min(1.0, ss * s_scale)
            nv = min(1.0, va + vb * vv)
            nr, ng, nb = colorsys.hsv_to_rgb(nh, ns, nv)
            px[x, y] = (
                round(r + (nr * 255 - r) * k),
                round(g + (ng * 255 - g) * k),
                round(b + (nb * 255 - b) * k),
                a,
            )
    return out


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    src = Image.open(SRC).convert('RGBA')
    src = src.resize((OUT_W, round(src.height * OUT_W / src.width)), Image.LANCZOS)
    save(src, 'blue')
    for name, spec in VARIANTS.items():
        save(recolour(src, spec), name)
        print('wrote', name)


def save(im, name):
    im.quantize(256, method=Image.Quantize.FASTOCTREE).save(
        os.path.join(OUT_DIR, f'{name}.png'), optimize=True
    )


if __name__ == '__main__':
    main()
