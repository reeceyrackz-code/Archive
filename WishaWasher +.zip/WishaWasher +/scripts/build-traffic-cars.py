"""Builds the traffic car sprites in assets/traffic/ from the green-screen art in scripts/art/.

Keys out the chroma green, crops to the car, then reuses the body recolouring from
recolour-tracking-car.py to make a few common paint colours per view:

    python3 scripts/build-traffic-cars.py
"""

import importlib.util
import os

from PIL import Image

HERE = os.path.dirname(__file__)
OUT_DIR = 'assets/traffic'
OUT_W = 384
VIEWS = ('rear', 'front')
PAINTS = ('red', 'white', 'black', 'silver', 'grey')

_spec = importlib.util.spec_from_file_location('recolour', os.path.join(HERE, 'recolour-tracking-car.py'))
recolour_mod = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(recolour_mod)


def key_out_green(im):
    """Green-dominant pixels become transparent with a soft edge; edge spill is pulled back to neutral."""
    im = im.convert('RGBA')
    px = im.load()
    w, h = im.size
    for y in range(h):
        for x in range(w):
            r, g, b, _ = px[x, y]
            spill = g - max(r, b)
            if spill <= 20:
                continue
            alpha = max(0, min(255, round(255 * (90 - spill) / 70)))
            px[x, y] = (r, max(r, b), b, alpha)
    return im


def crop_to_content(im):
    bbox = im.getchannel('A').point(lambda a: 255 if a > 24 else 0).getbbox()
    return im.crop(bbox) if bbox else im


def save(im, name):
    im.quantize(256, method=Image.Quantize.FASTOCTREE).save(os.path.join(OUT_DIR, f'{name}.png'), optimize=True)


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    for view in VIEWS:
        src = crop_to_content(key_out_green(Image.open(os.path.join(HERE, 'art', f'traffic-{view}.jpg'))))
        src = src.resize((OUT_W, round(src.height * OUT_W / src.width)), Image.LANCZOS)
        print(view, src.size)
        save(src, f'{view}-blue')
        for paint in PAINTS:
            save(recolour_mod.recolour(src, recolour_mod.VARIANTS[paint]), f'{view}-{paint}')


if __name__ == '__main__':
    main()
