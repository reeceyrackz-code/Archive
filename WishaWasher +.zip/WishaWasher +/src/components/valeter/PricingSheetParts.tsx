import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import Reanimated, { FadeInDown } from 'react-native-reanimated';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import type { IconGlyphName } from '../shared/iconGlyphTypes';
import { PressableScale } from '../shared/fit/FitKit';
import GlassOrb from './road/GlassOrb';

const AMBER = '#FBBF24';
const GREEN = '#4ADE80';

/** Header for the pricing sheets: service orb, title and a "3 of 6 set" progress ring-chip. */
export function PricingHero({
  title,
  icon,
  accent,
  done,
  total,
  textMain,
  muted,
  onClose,
}: Readonly<{
  title: string;
  icon: IconGlyphName;
  accent: string;
  done: number;
  total: number;
  textMain: string;
  muted: string;
  onClose: () => void;
}>) {
  const complete = done >= total;
  const ratio = total > 0 ? Math.min(1, done / total) : 0;
  return (
    <View style={styles.hero}>
      <GlassOrb icon={icon} accent={accent} size={52} />
      <View style={styles.heroCopy}>
        <Text style={[styles.eyebrow, { color: muted }]}>SET PRICING</Text>
        <Text style={[styles.title, { color: textMain }]} numberOfLines={1} adjustsFontSizeToFit>
          {title}
        </Text>
        <View style={styles.progressRow}>
          <View style={styles.progressTrack}>
            <View style={[styles.progressFill, { width: `${ratio * 100}%`, backgroundColor: complete ? GREEN : accent }]} />
          </View>
          <Text style={[styles.progressText, { color: complete ? GREEN : muted }]}>
            {complete ? 'All set' : `${done} of ${total} set`}
          </Text>
        </View>
      </View>
      <Pressable onPress={onClose} style={styles.close} hitSlop={12} accessibilityLabel="Close">
        <Ionicons name="close" size={18} color={textMain} />
      </Pressable>
    </View>
  );
}

/** One vehicle size (or duration) with a tappable value pill that opens the wheel picker. */
export function PriceRow({
  icon,
  label,
  subtitle,
  value,
  empty,
  accent,
  textMain,
  muted,
  index = 0,
  onPress,
}: Readonly<{
  icon: IconGlyphName;
  label: string;
  subtitle?: string;
  value: string;
  empty: boolean;
  accent: string;
  textMain: string;
  muted: string;
  index?: number;
  onPress: () => void;
}>) {
  return (
    <Reanimated.View entering={FadeInDown.delay(index * 40).springify().damping(18)}>
      <PressableScale onPress={onPress} style={styles.row} accessibilityLabel={`${label}, ${value}`}>
        <View style={[styles.rowIcon, { backgroundColor: `${accent}1F` }]}>
          <Ionicons name={icon} size={18} color={accent} />
        </View>
        <View style={styles.rowCopy}>
          <Text style={[styles.rowLabel, { color: textMain }]} numberOfLines={1}>
            {label}
          </Text>
          {subtitle ? (
            <Text style={[styles.rowSub, { color: muted }]} numberOfLines={1}>
              {subtitle}
            </Text>
          ) : null}
        </View>
        <View
          style={[
            styles.pill,
            empty
              ? { borderColor: `${AMBER}88`, backgroundColor: `${AMBER}14`, borderStyle: 'dashed' }
              : { borderColor: `${accent}66`, backgroundColor: `${accent}1F` },
          ]}
        >
          {empty ? <Ionicons name="add" size={14} color={AMBER} /> : null}
          <Text style={[styles.pillText, { color: empty ? AMBER : textMain }]} numberOfLines={1}>
            {value}
          </Text>
          {!empty ? <Ionicons name="chevron-expand" size={13} color={muted} /> : null}
        </View>
      </PressableScale>
    </Reanimated.View>
  );
}

/** Footer button: counts down missing fields, turns into "Done" when complete. */
export function PricingDoneButton({
  missing,
  accent,
  onPress,
}: Readonly<{ missing: number; accent: string; onPress: () => void }>) {
  const complete = missing === 0;
  return (
    <PressableScale
      onPress={onPress}
      style={[
        styles.done,
        complete ? { backgroundColor: accent } : { backgroundColor: 'rgba(255,255,255,0.08)', borderColor: `${AMBER}66`, borderWidth: 1 },
      ]}
      accessibilityLabel={complete ? 'Done' : `${missing} left to set`}
    >
      <Ionicons name={complete ? 'checkmark-circle' : 'alert-circle'} size={18} color={complete ? '#0A1929' : AMBER} />
      <Text style={[styles.doneText, { color: complete ? '#0A1929' : AMBER }]}>
        {complete ? 'Done' : `${missing} left to set`}
      </Text>
    </PressableScale>
  );
}

const styles = StyleSheet.create({
  hero: { flexDirection: 'row', alignItems: 'center', gap: 14, paddingTop: 2, paddingBottom: 14 },
  heroCopy: { flex: 1, minWidth: 0, gap: 3 },
  eyebrow: { fontSize: 10, fontWeight: '800', letterSpacing: 1.2 },
  title: { fontSize: 21, fontWeight: '900', letterSpacing: -0.3 },
  progressRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 2 },
  progressTrack: { flex: 1, height: 5, borderRadius: 3, backgroundColor: 'rgba(255,255,255,0.12)', overflow: 'hidden' },
  progressFill: { height: '100%', borderRadius: 3 },
  progressText: { fontSize: 11.5, fontWeight: '800' },
  close: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
    alignSelf: 'flex-start',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  rowIcon: { width: 38, height: 38, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  rowCopy: { flex: 1, minWidth: 0 },
  rowLabel: { fontSize: 14.5, fontWeight: '800' },
  rowSub: { fontSize: 11.5, fontWeight: '600', marginTop: 1 },
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    minWidth: 86,
    justifyContent: 'center',
    paddingHorizontal: 12,
    height: 36,
    borderRadius: 18,
    borderWidth: 1,
  },
  pillText: { fontSize: 15, fontWeight: '900', fontVariant: ['tabular-nums'] },
  done: { height: 52, borderRadius: 26, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  doneText: { fontSize: 16, fontWeight: '900' },
});
