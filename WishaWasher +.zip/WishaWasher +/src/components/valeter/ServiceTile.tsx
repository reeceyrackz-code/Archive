import React, { useEffect } from 'react';
import { StyleSheet, Switch, Text, TouchableOpacity, View } from 'react-native';
import Reanimated, { useAnimatedStyle, useSharedValue, withTiming } from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import GlassSurface from '../shared/GlassSurface';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import type { IconGlyphName } from '../shared/iconGlyphTypes';
import { PressableScale } from '../shared/fit/FitKit';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import { lightMistElevated } from '../../constants/accountThemes';
import GlassOrb from './road/GlassOrb';

const UNPRICED = 'Set pricing';

/** Grid tile for one service: icon, on/off switch, name and price range. Tap edits pricing. */
export default function ServiceTile({
  name,
  priceLabel,
  enabled,
  accent,
  icon,
  switchValue,
  switchDisabled,
  locked,
  height,
  onPress,
  onToggle,
  onInfo,
}: Readonly<{
  name: string;
  priceLabel: string;
  enabled: boolean;
  accent: string;
  icon: IconGlyphName;
  switchValue: boolean;
  switchDisabled?: boolean;
  /** Category is switched off; tile is greyed but still shows its own switch state. */
  locked?: boolean;
  height: number;
  onPress: () => void;
  onToggle: () => void;
  onInfo?: () => void;
}>) {
  const { theme } = useAccountTheme();
  const isLight = theme.mode === 'light';
  const muted = theme.textSecondary ?? 'rgba(249,250,251,0.6)';
  const textMain = theme.textPrimary ?? '#F9FAFB';
  const unpriced = priceLabel === UNPRICED;
  const compact = height < 112;

  const on = useSharedValue(enabled ? 1 : 0);
  useEffect(() => {
    on.value = withTiming(enabled ? 1 : 0, { duration: 260 });
  }, [enabled, on]);
  const dimStyle = useAnimatedStyle(() => ({ opacity: 0.55 + on.value * 0.45 }));
  const glowStyle = useAnimatedStyle(() => ({ opacity: on.value }));

  return (
    <PressableScale onPress={onPress} onLongPress={onInfo} style={{ height }} fill accessibilityLabel={`${name}, ${priceLabel}`}>
      <GlassSurface
        style={styles.tile}
        tintColor={enabled ? `${accent}1C` : undefined}
        borderColor={enabled ? `${accent}55` : isLight ? 'rgba(158,201,224,0.28)' : 'rgba(255,255,255,0.08)'}
        fallbackColor={isLight ? lightMistElevated : 'rgba(15,23,42,0.45)'}
        interactive
      >
        <Reanimated.View pointerEvents="none" style={[StyleSheet.absoluteFill, glowStyle]}>
          <LinearGradient
            colors={[`${accent}33`, 'transparent']}
            start={{ x: 0, y: 0 }}
            end={{ x: 0.9, y: 0.9 }}
            style={StyleSheet.absoluteFill}
          />
        </Reanimated.View>

        <Reanimated.View style={[styles.inner, dimStyle]}>
          <View style={styles.top}>
            <GlassOrb icon={icon} accent={accent} size={compact ? 32 : 38} glow={enabled} />
            <Switch
              value={switchValue}
              disabled={switchDisabled}
              onValueChange={onToggle}
              style={styles.switch}
              trackColor={{ false: 'rgba(255,255,255,0.15)', true: accent }}
              thumbColor={switchValue ? '#fff' : '#9CA3AF'}
            />
          </View>

          <View style={styles.bottom}>
            <View style={styles.nameRow}>
              <Text style={[styles.name, { color: textMain }]} numberOfLines={compact ? 1 : 2}>
                {name}
              </Text>
              {onInfo ? (
                <TouchableOpacity onPress={onInfo} hitSlop={10} accessibilityLabel={`About ${name}`}>
                  <Ionicons name="information-circle-outline" size={15} color={muted} />
                </TouchableOpacity>
              ) : null}
            </View>
            <View style={styles.priceRow}>
              {unpriced ? <Ionicons name="alert-circle" size={12} color="#FBBF24" /> : null}
              <Text
                style={[styles.price, { color: unpriced ? '#FBBF24' : enabled ? accent : muted }]}
                numberOfLines={1}
                adjustsFontSizeToFit
              >
                {locked ? 'Category off' : priceLabel}
              </Text>
            </View>
          </View>
        </Reanimated.View>
      </GlassSurface>
    </PressableScale>
  );
}

const styles = StyleSheet.create({
  tile: { flex: 1, borderRadius: 20, overflow: 'hidden' },
  inner: { flex: 1, padding: 12, justifyContent: 'space-between' },
  top: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' },
  switch: { transform: [{ scale: 0.78 }], marginTop: -4, marginRight: -6 },
  bottom: { gap: 3 },
  nameRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 4 },
  name: { flex: 1, fontSize: 14, fontWeight: '800', lineHeight: 18 },
  priceRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  price: { fontSize: 13, fontWeight: '800', flexShrink: 1 },
});
