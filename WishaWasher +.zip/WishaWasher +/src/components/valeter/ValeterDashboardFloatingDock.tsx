import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  Animated,
  Easing,
  ActivityIndicator,
  Pressable,
} from 'react-native';
import Reanimated, {
  Easing as REasing,
  cancelAnimation,
  useAnimatedProps,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
  type SharedValue,
} from 'react-native-reanimated';
import { scheduleOnRN } from 'react-native-worklets';
import { LinearGradient } from 'expo-linear-gradient';
import Svg, { Defs, LinearGradient as SvgGradient, Path, Stop } from 'react-native-svg';
import { usePathname, useRouter, type Href } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import type { IconGlyphName } from '../shared/iconGlyphTypes';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import { useValeterNav, VALETER_MAP_ROUTE } from './ValeterNavSidebar';
import { isValeterDashboardRoute } from '../../utils/valeterNavigation';

const APP_ICON = require('../../../assets/icon.png');
/** Small copy of auth-mascot so each screen's dock decodes it instantly. */
const AUTH_MASCOT = require('../../../assets/dock-mascot.png');

const ONLINE_GREEN = '#4ADE80';
const OFFLINE_RED = '#F87171';
const ONLINE_RING = ['#BBF7D0', '#22C55E', '#15803D'] as const;
const OFFLINE_RING = ['#FECACA', '#EF4444', '#991B1B'] as const;

const CAPSULE_H = 50;
const ORB = 54;
const ORB_RING = 3;
const CRADLE = ORB + 10;
/** Lifts the orb above the capsule so the dock keeps its fixed row height. */
const ORB_RAISE = 34;
/** Orb centre relative to the capsule's top edge (negative = above). */
const ORB_CY = CRADLE / 2 - ORB_RAISE;
/** How far the bar's hump rises above the capsule to wrap the orb. */
const HUMP_H = -ORB_CY + ORB / 2 + 9;
const HUMP_HALF_W = ORB / 2 + 34;
const SHAPE_PAD = 2;
/** Dock surface colours, shared with cards that join onto the dock. */
export const DOCK_FILL = 'rgba(6,14,26,0.86)';
export const DOCK_SHEEN = ['rgba(255,255,255,0.12)', 'rgba(255,255,255,0.02)'] as const;
export const DOCK_STROKE = 'rgba(255,255,255,0.12)';
/** Space either side of the dock bar; a card this far in matches the bar's width. */
export const DOCK_SIDE_INSET = 10;

/** Pill-shaped bar whose top edge swells into a hump around the centre orb. */
function dockShapePath(w: number) {
  const r = CAPSULE_H / 2;
  const t = HUMP_H + SHAPE_PAD;
  const b = t + CAPSULE_H;
  const cx = w / 2;
  const hw = HUMP_HALF_W;
  const top = t - HUMP_H;
  return [
    `M ${r} ${t}`,
    `L ${cx - hw} ${t}`,
    `C ${cx - hw * 0.45} ${t} ${cx - ORB / 2 - 6} ${top} ${cx} ${top}`,
    `C ${cx + ORB / 2 + 6} ${top} ${cx + hw * 0.45} ${t} ${cx + hw} ${t}`,
    `L ${w - r} ${t}`,
    `A ${r} ${r} 0 0 1 ${w - r} ${b}`,
    `L ${r} ${b}`,
    `A ${r} ${r} 0 0 1 ${r} ${t}`,
    'Z',
  ].join(' ');
}

function dockHumpPath(w: number) {
  const t = HUMP_H + SHAPE_PAD;
  const cx = w / 2;
  const hw = HUMP_HALF_W;
  const top = t - HUMP_H;
  return [
    `M ${cx - hw} ${t}`,
    `C ${cx - hw * 0.45} ${t} ${cx - ORB / 2 - 6} ${top} ${cx} ${top}`,
    `C ${cx + ORB / 2 + 6} ${top} ${cx + hw * 0.45} ${t} ${cx + hw} ${t}`,
  ].join(' ');
}

function DockShape({ width, statusColor, accent }: Readonly<{ width: number; statusColor: string; accent: string }>) {
  if (width <= 0) return null;
  const h = HUMP_H + SHAPE_PAD + CAPSULE_H;
  return (
    <Svg
      pointerEvents="none"
      width={width}
      height={h}
      style={[styles.shapeSvg, { top: -(HUMP_H + SHAPE_PAD) }]}
    >
      <Defs>
        <SvgGradient id="dockSheen" x1="0" y1="0" x2="0" y2="1">
          <Stop offset="0" stopColor="#FFFFFF" stopOpacity={0.12} />
          <Stop offset="1" stopColor="#FFFFFF" stopOpacity={0.02} />
        </SvgGradient>
        <SvgGradient id="dockEdge" x1="0" y1="0" x2="1" y2="0">
          <Stop offset="0" stopColor={accent} stopOpacity={0} />
          <Stop offset="0.5" stopColor={accent} stopOpacity={0.35} />
          <Stop offset="1" stopColor={accent} stopOpacity={0} />
        </SvgGradient>
      </Defs>
      <Path d={dockShapePath(width)} fill={DOCK_FILL} />
      <Path d={dockShapePath(width)} fill="url(#dockSheen)" stroke={DOCK_STROKE} strokeWidth={1} />
      <Path d={dockHumpPath(width)} fill="none" stroke="url(#dockEdge)" strokeWidth={1} />
      <Path
        d={dockHumpPath(width)}
        fill="none"
        stroke={statusColor}
        strokeOpacity={0.55}
        strokeWidth={1.5}
        strokeLinecap="round"
      />
    </Svg>
  );
}
/** How long the next-step button must be held before the step runs. */
const HOLD_MS = 1000;
/** Padding around the trace so its stroke isn't clipped at the dock's edges. */
const TRACE_PAD = 4;
const AnimatedPath = Reanimated.createAnimatedComponent(Path);

type Pt = [number, number];

/**
 * The dock outline as a polyline, starting at the top of the hump and running clockwise all the way
 * round back to it, so a dashed stroke can "travel" the whole bar.
 */
function dockOutline(w: number) {
  const r = CAPSULE_H / 2;
  const t = HUMP_H + SHAPE_PAD;
  const b = t + CAPSULE_H;
  const cx = w / 2;
  const hw = HUMP_HALF_W;
  const top = t - HUMP_H;
  const pts: Pt[] = [[cx, top]];
  const cubic = (p0: Pt, p1: Pt, p2: Pt, p3: Pt) => {
    for (let k = 1; k <= 24; k++) {
      const s = k / 24;
      const u = 1 - s;
      pts.push([
        u * u * u * p0[0] + 3 * u * u * s * p1[0] + 3 * u * s * s * p2[0] + s * s * s * p3[0],
        u * u * u * p0[1] + 3 * u * u * s * p1[1] + 3 * u * s * s * p2[1] + s * s * s * p3[1],
      ]);
    }
  };
  const arc = (ax: number, ay: number, from: number, to: number) => {
    for (let k = 1; k <= 20; k++) {
      const a = from + ((to - from) * k) / 20;
      pts.push([ax + r * Math.cos(a), ay + r * Math.sin(a)]);
    }
  };
  cubic([cx, top], [cx + ORB / 2 + 6, top], [cx + hw * 0.45, t], [cx + hw, t]);
  pts.push([w - r, t]);
  arc(w - r, t + r, -Math.PI / 2, Math.PI / 2);
  pts.push([r, b]);
  arc(r, t + r, Math.PI / 2, (3 * Math.PI) / 2);
  pts.push([cx - hw, t]);
  cubic([cx - hw, t], [cx - hw * 0.45, t], [cx - ORB / 2 - 6, top], [cx, top]);

  let length = 0;
  for (let i = 1; i < pts.length; i++) length += Math.hypot(pts[i]![0] - pts[i - 1]![0], pts[i]![1] - pts[i - 1]![1]);
  const d = pts.map(([x, y], i) => `${i ? 'L' : 'M'} ${(x + TRACE_PAD).toFixed(1)} ${(y + TRACE_PAD).toFixed(1)}`).join(' ');
  return { d, length };
}

/**
 * The bar's top edge across its full width as [x, lift] points, where lift is the height above the
 * capsule top (0 on the flats, HUMP_H over the centre button). Matches dockShapePath's curves.
 */
export function dockTopEdge(w: number, samples = 24): Pt[] {
  const cx = w / 2;
  const hw = HUMP_HALF_W;
  const pts: Pt[] = [[0, 0], [cx - hw, 0]];
  const cubic = (p0: Pt, p1: Pt, p2: Pt, p3: Pt) => {
    for (let k = 1; k <= samples; k++) {
      const s = k / samples;
      const u = 1 - s;
      pts.push([
        u * u * u * p0[0] + 3 * u * u * s * p1[0] + 3 * u * s * s * p2[0] + s * s * s * p3[0],
        u * u * u * p0[1] + 3 * u * u * s * p1[1] + 3 * u * s * s * p2[1] + s * s * s * p3[1],
      ]);
    }
  };
  cubic([cx - hw, 0], [cx - hw * 0.45, 0], [cx - ORB / 2 - 6, HUMP_H], [cx, HUMP_H]);
  cubic([cx, HUMP_H], [cx + ORB / 2 + 6, HUMP_H], [cx + hw * 0.45, 0], [cx + hw, 0]);
  pts.push([w, 0]);
  return pts;
}

/** Green line that runs round the whole dock as the next-step button is held. */
function HoldTrace({ width, progress }: Readonly<{ width: number; progress: SharedValue<number> }>) {
  const outline = useMemo(() => dockOutline(width), [width]);
  const len = outline.length;
  const dash = useAnimatedProps(() => ({ strokeDashoffset: len * (1 - progress.value) }));
  const glow = useAnimatedProps(() => ({ strokeDashoffset: len * (1 - progress.value), strokeOpacity: 0.35 * Math.min(1, progress.value * 6) }));
  if (width <= 0) return null;
  const h = HUMP_H + SHAPE_PAD + CAPSULE_H;
  return (
    <Svg
      pointerEvents="none"
      width={width + TRACE_PAD * 2}
      height={h + TRACE_PAD * 2}
      style={[styles.traceSvg, { top: -(HUMP_H + SHAPE_PAD) - TRACE_PAD, left: -TRACE_PAD }]}
    >
      <AnimatedPath
        d={outline.d}
        fill="none"
        stroke={ONLINE_GREEN}
        strokeWidth={8}
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeDasharray={[len, len]}
        animatedProps={glow}
      />
      <AnimatedPath
        d={outline.d}
        fill="none"
        stroke="#BBF7D0"
        strokeWidth={2.5}
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeDasharray={[len, len]}
        animatedProps={dash}
      />
    </Svg>
  );
}

/** Press-and-hold confirm: progress fills over HOLD_MS while held, springs back if released early. */
function useHoldToConfirm(onConfirm: () => void) {
  const progress = useSharedValue(0);
  const [holding, setHolding] = useState(false);
  const [done, setDone] = useState(false);
  const doneRef = useRef(false);
  const ticks = useRef<ReturnType<typeof setInterval> | null>(null);
  const resetTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const stopTicks = () => {
    if (ticks.current) clearInterval(ticks.current);
    ticks.current = null;
  };

  const complete = useCallback(() => {
    stopTicks();
    doneRef.current = true;
    setHolding(false);
    setDone(true);
    void hapticFeedback('success');
    onConfirm();
    resetTimer.current = setTimeout(() => {
      doneRef.current = false;
      setDone(false);
      progress.value = withTiming(0, { duration: 420, easing: REasing.out(REasing.cubic) });
    }, 900);
  }, [onConfirm, progress]);

  useEffect(
    () => () => {
      stopTicks();
      if (resetTimer.current) clearTimeout(resetTimer.current);
    },
    []
  );

  const onPressIn = () => {
    if (doneRef.current) return;
    setHolding(true);
    void hapticFeedback('light');
    stopTicks();
    ticks.current = setInterval(() => void hapticFeedback('light'), 250);
    const remaining = HOLD_MS * (1 - progress.value);
    progress.value = withTiming(1, { duration: remaining, easing: REasing.linear }, (finished) => {
      if (finished) scheduleOnRN(complete);
    });
  };

  const onPressOut = () => {
    if (doneRef.current) return;
    stopTicks();
    setHolding(false);
    cancelAnimation(progress);
    progress.value = withTiming(0, { duration: 260, easing: REasing.out(REasing.cubic) });
  };

  return { progress, holding, done, onPressIn, onPressOut, confirmNow: complete };
}

export type DockTripAction = Readonly<{
  /** e.g. "Start journey", "Mark arrived". */
  label: string;
  icon: IconGlyphName;
  onConfirm: () => void;
}>;

/** Live job: the dock becomes Home · Chat · [next step] · Cancel. */
export type DockTrip = Readonly<{
  step: DockTripAction | null;
  /** Centre state when there is nothing to confirm (e.g. awaiting payment). */
  waiting?: Readonly<{ label: string; icon: IconGlyphName; color: string }> | null;
  onHome?: () => void;
  chatLocked: boolean;
  onChat: () => void;
  canCancel: boolean;
  cancelling?: boolean;
  /** Cancels while allowed; once locked the same slot becomes "Report a problem". */
  onCancel: () => void;
}>;

/** A job offer is on screen: the online orb becomes hold-to-Accept and Pricing becomes Decline. */
export type DockOffer = Readonly<{
  onAccept: () => void;
  onDecline: () => void;
}>;

const CANCEL_RED = '#FCA5A5';
const REPORT_AMBER = '#FCD34D';

/** Centre orb while the job is waiting on someone else — not pressable. */
function WaitOrb({ label, icon, color }: Readonly<{ label: string; icon: IconGlyphName; color: string }>) {
  return (
    <View style={styles.orbSlot} pointerEvents="box-none" accessibilityLabel={label}>
      <View style={styles.orbAnchor} pointerEvents="none">
        <View style={[styles.orbShadow, styles.waitOrb, { shadowColor: color, borderColor: `${color}99` }]}>
          <Ionicons name={icon} size={22} color={color} />
        </View>
      </View>
      <View pointerEvents="none" style={[styles.orbChip, { backgroundColor: `${color}24`, borderColor: `${color}80` }]}>
        <Text style={[styles.stepChipText, { color }]} numberOfLines={1}>
          {label}
        </Text>
      </View>
    </View>
  );
}

/** During a job the online orb becomes the next-step button: glowing green, hold for a second to confirm. */
function StepOrb({
  action,
  hold,
}: Readonly<{ action: DockTripAction; hold: ReturnType<typeof useHoldToConfirm> }>) {
  const breathe = useSharedValue(0);
  useEffect(() => {
    breathe.value = withRepeat(withTiming(1, { duration: 1600, easing: REasing.inOut(REasing.sin) }), -1, true);
    return () => cancelAnimation(breathe);
  }, [breathe]);
  const halo = useAnimatedStyle(() => ({
    opacity: 0.35 + breathe.value * 0.45,
    transform: [{ scale: 1 + breathe.value * 0.12 }],
  }));
  const { progress } = hold;
  const press = useAnimatedStyle(() => ({ transform: [{ scale: 1 - progress.value * 0.06 }] }));

  let chip = action.label;
  if (hold.done) chip = 'Done';
  else if (hold.holding) chip = 'Keep holding';

  return (
    <View style={styles.orbSlot} pointerEvents="box-none">
      <View style={styles.orbAnchor} pointerEvents="box-none">
        <Reanimated.View pointerEvents="none" style={[styles.stepHalo, halo]} />
        <Pressable
          onPressIn={hold.onPressIn}
          onPressOut={hold.onPressOut}
          hitSlop={8}
          accessibilityRole="button"
          accessibilityLabel={action.label}
          accessibilityHint="Press and hold for a second to confirm"
          accessibilityActions={[{ name: 'activate' }]}
          onAccessibilityAction={hold.confirmNow}
        >
          <Reanimated.View style={[styles.orbShadow, { shadowColor: ONLINE_GREEN }, press]}>
            <LinearGradient colors={ONLINE_RING} start={{ x: 0.2, y: 0 }} end={{ x: 0.8, y: 1 }} style={styles.orbRing}>
              <View style={[styles.orbInner, styles.stepInner]}>
                <Ionicons name={hold.done ? 'checkmark' : action.icon} size={24} color="#FFFFFF" />
              </View>
            </LinearGradient>
          </Reanimated.View>
        </Pressable>
      </View>
      <View pointerEvents="none" style={[styles.orbChip, styles.stepChip]}>
        <Text style={styles.stepChipText} numberOfLines={1}>
          {chip}
        </Text>
      </View>
    </View>
  );
}

function orbChipLabel(busy: boolean | undefined, isOnline: boolean) {
  if (busy) return 'Updating';
  return isOnline ? 'Online' : 'Go online';
}

function stripTrailingSlashes(path: string) {
  let end = path.length;
  while (end > 0 && path[end - 1] === '/') end--;
  return path.slice(0, end);
}

const SPARKLE_ORBITS = [
  { dx: 36, dy: -30 },
  { dx: -38, dy: -22 },
  { dx: 42, dy: 6 },
  { dx: -42, dy: 8 },
  { dx: 0, dy: -46 },
  { dx: 20, dy: -44 },
] as const;

export const VALETER_ACTIVITY_ROUTE = '/valeter/activity';

export type DockTabId = 'jobs' | 'messages' | 'vehicle' | 'pricing' | 'activity';

/** Visible dock row height incl. the hump around the online orb (excluding safe-area inset). */
export const VALETER_DOCK_ROW_HEIGHT = CAPSULE_H + HUMP_H + SHAPE_PAD + 4;

/** Even gap between a notched card and the dock it wraps. */
export const DOCK_NOTCH_GAP = 3;
/** Height the notch rises into a card's bottom edge. */
export const DOCK_NOTCH_DEPTH = HUMP_H;
/** How far a notched card hangs into the dock row so its bottom sits DOCK_NOTCH_GAP above the bar. */
export const DOCK_CARD_OVERLAP = VALETER_DOCK_ROW_HEIGHT - CAPSULE_H - DOCK_NOTCH_GAP;

/**
 * Rounded-rect card outline whose bottom edge (when `notched`) curves up around the dock's hump,
 * keeping DOCK_NOTCH_GAP clear of it. Card and dock must share a horizontal centre.
 */
export function dockNotchedCardPath(w: number, h: number, r: number, notched: boolean) {
  const cx = w / 2;
  const g = DOCK_NOTCH_GAP;
  const hw = HUMP_HALF_W + g;
  const top = h - DOCK_NOTCH_DEPTH;
  const notch = notched
    ? [
        `L ${cx + hw} ${h}`,
        `C ${cx + hw * 0.45} ${h} ${cx + ORB / 2 + 6 + g} ${top} ${cx} ${top}`,
        `C ${cx - ORB / 2 - 6 - g} ${top} ${cx - hw * 0.45} ${h} ${cx - hw} ${h}`,
      ]
    : [];
  return [
    `M ${r} 0`,
    `L ${w - r} 0`,
    `A ${r} ${r} 0 0 1 ${w} ${r}`,
    `L ${w} ${h - r}`,
    `A ${r} ${r} 0 0 1 ${w - r} ${h}`,
    ...notch,
    `L ${r} ${h}`,
    `A ${r} ${r} 0 0 1 0 ${h - r}`,
    `L 0 ${r}`,
    `A ${r} ${r} 0 0 1 ${r} 0`,
    'Z',
  ].join(' ');
}

type DockItem = {
  id: DockTabKey;
  icon?: IconGlyphName;
  /** Use app mark instead of an Ionicons glyph (Jobs / home). */
  appIcon?: boolean;
  label: string;
  route?: string;
  action?: 'jobs';
  badge?: number;
  /** Round auth-page mascot instead of an icon. */
  mascot?: boolean;
  /** Overrides route/home handling. */
  onPress?: () => void;
  tint?: string;
  /** Small padlock on the icon; the tab stays pressable (to explain why). */
  locked?: boolean;
  /** Takes the width of two tabs so the centre orb stays centred. */
  wide?: boolean;
  busy?: boolean;
};

export type DockTabKey = DockTabId | 'cancel';

export function resolveValeterDockTab(p: string = ''): DockTabId | null {
  if (p.includes('/valeter/inbox') || p.includes('/valeter/notifications')) return 'messages';
  if (p.includes('/valeter/profile/valeter-vehicle-info')) return 'vehicle';
  if (p.includes('/valeter/profile/valeter-services')) return 'pricing';
  if (p.includes('/valeter/activity')) return 'activity';
  if (p.includes('/valeter/valeter-dashboard') || p.includes('/valeter/jobs')) return 'jobs';
  return null;
}

export type ValeterDashboardFloatingDockProps = Readonly<{
  accent: string;
  /** `tabBar` = sheet footer. `global` = fixed bottom bar on other screens. */
  variant?: 'tabBar' | 'global';
  jobRequestCount?: number;
  activeTab?: DockTabId | null;
  onJobsPress?: () => void;
  isOnline?: boolean;
  /** Presence is loading or a toggle is in flight. */
  onlineBusy?: boolean;
  /** When omitted, the centre button opens the map instead of toggling. */
  onToggleOnline?: () => void;
  /** While a job is live: Home · Chat · hold-to-confirm next step · Cancel. */
  trip?: DockTrip | null;
  /** Offer showing (ignored during a trip): Home · Chat · hold-to-Accept · Decline · Activity. */
  offer?: DockOffer | null;
}>;

function OnlineOrb({
  isOnline,
  busy,
  onPress,
}: Readonly<{ isOnline: boolean; busy: boolean; onPress: () => void }>) {
  const statusColor = isOnline ? ONLINE_GREEN : OFFLINE_RED;
  const ringPulse = useRef(new Animated.Value(0)).current;
  const spinAnim = useRef(new Animated.Value(0)).current;
  const spinScale = useRef(new Animated.Value(1)).current;
  const pressScale = useRef(new Animated.Value(1)).current;
  const sparkleAnims = useRef(SPARKLE_ORBITS.map(() => new Animated.Value(0))).current;
  const wasOnlineRef = useRef(isOnline);
  const idleSpin = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (isOnline || busy) {
      idleSpin.stopAnimation((value) => {
        if (value <= 0) return;
        Animated.timing(idleSpin, {
          toValue: 1,
          duration: Math.max(120, (1 - value) * 600),
          easing: Easing.out(Easing.cubic),
          useNativeDriver: true,
        }).start(() => idleSpin.setValue(0));
      });
      return;
    }
    idleSpin.setValue(0);
    const loop = Animated.loop(
      Animated.timing(idleSpin, {
        toValue: 1,
        duration: 3200,
        easing: Easing.linear,
        useNativeDriver: true,
      })
    );
    loop.start();
    return () => loop.stop();
  }, [isOnline, busy, idleSpin]);

  useEffect(() => {
    ringPulse.setValue(0);
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(ringPulse, {
          toValue: 1,
          duration: isOnline ? 1800 : 2200,
          easing: Easing.out(Easing.cubic),
          useNativeDriver: true,
        }),
        Animated.timing(ringPulse, { toValue: 0, duration: 0, useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [isOnline, ringPulse]);

  useEffect(() => {
    if (!wasOnlineRef.current && isOnline && !busy) {
      spinAnim.setValue(0);
      spinScale.setValue(0.65);
      Animated.parallel([
        Animated.timing(spinAnim, {
          toValue: 1,
          duration: 620,
          easing: Easing.out(Easing.cubic),
          useNativeDriver: true,
        }),
        Animated.spring(spinScale, { toValue: 1, friction: 5, tension: 90, useNativeDriver: true }),
      ]).start(() => spinAnim.setValue(0));
      sparkleAnims.forEach((anim, i) => {
        anim.setValue(0);
        Animated.timing(anim, {
          toValue: 1,
          duration: 720,
          delay: i * 35,
          easing: Easing.out(Easing.cubic),
          useNativeDriver: true,
        }).start(() => anim.setValue(0));
      });
    }
    wasOnlineRef.current = isOnline;
  }, [isOnline, busy, spinAnim, spinScale, sparkleAnims]);

  const pressTo = (to: number) =>
    Animated.spring(pressScale, { toValue: to, friction: 6, tension: 220, useNativeDriver: true }).start();

  const ringScale = ringPulse.interpolate({ inputRange: [0, 1], outputRange: [1, 1.38] });
  const ringOpacity = ringPulse.interpolate({ inputRange: [0, 0.2, 1], outputRange: [0.6, 0.4, 0] });
  const spinRotate = spinAnim.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });
  const idleRotate = idleSpin.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });
  const ring = isOnline ? ONLINE_RING : OFFLINE_RING;

  return (
    <View style={styles.orbSlot} pointerEvents="box-none">
      <View style={styles.orbAnchor} pointerEvents="box-none">
        <LinearGradient
          pointerEvents="none"
          colors={[`${statusColor}40`, `${statusColor}00`]}
          style={styles.orbHalo}
        />

        {sparkleAnims.map((anim, i) => {
          const orbit = SPARKLE_ORBITS[i];
          return (
            <Animated.View
              key={`spark-${orbit.dx}-${orbit.dy}`}
              pointerEvents="none"
              style={[
                styles.sparkle,
                {
                  backgroundColor: i % 2 ? '#FDE68A' : '#86EFAC',
                  opacity: anim.interpolate({ inputRange: [0, 0.15, 0.85, 1], outputRange: [0, 1, 0.6, 0] }),
                  transform: [
                    { translateX: anim.interpolate({ inputRange: [0, 1], outputRange: [0, orbit.dx] }) },
                    { translateY: anim.interpolate({ inputRange: [0, 1], outputRange: [0, orbit.dy] }) },
                    { scale: anim.interpolate({ inputRange: [0, 0.5, 1], outputRange: [0.2, 1, 0.4] }) },
                  ],
                },
              ]}
            />
          );
        })}

        <Animated.View
          pointerEvents="none"
          style={[
            styles.orbPulse,
            { borderColor: statusColor, opacity: ringOpacity, transform: [{ scale: ringScale }] },
          ]}
        />

        <TouchableOpacity
          onPress={onPress}
          onPressIn={() => pressTo(0.92)}
          onPressOut={() => pressTo(1)}
          disabled={busy}
          activeOpacity={1}
          hitSlop={6}
          accessibilityRole="button"
          accessibilityLabel={isOnline ? 'You are online. Go offline' : 'You are offline. Go online'}
        >
          <Animated.View
            style={[
              styles.orbShadow,
              {
                shadowColor: statusColor,
                transform: [{ scale: Animated.multiply(spinScale, pressScale) }, { rotate: spinRotate }],
              },
            ]}
          >
            <LinearGradient colors={ring} start={{ x: 0.2, y: 0 }} end={{ x: 0.8, y: 1 }} style={styles.orbRing}>
              <View style={styles.orbInner}>
                {busy ? (
                  <ActivityIndicator size="small" color="#FFFFFF" />
                ) : (
                  <Animated.Image
                    source={AUTH_MASCOT}
                    style={[styles.orbMascot, { transform: [{ rotate: idleRotate }] }]}
                    resizeMode="cover"
                    fadeDuration={0}
                  />
                )}
                <LinearGradient
                  pointerEvents="none"
                  colors={['rgba(255,255,255,0.38)', 'rgba(255,255,255,0)']}
                  start={{ x: 0.3, y: 0 }}
                  end={{ x: 0.5, y: 0.55 }}
                  style={styles.orbGloss}
                />
              </View>
            </LinearGradient>
          </Animated.View>
        </TouchableOpacity>
      </View>

      <View
        pointerEvents="none"
        style={[
          styles.orbChip,
          {
            backgroundColor: isOnline ? 'rgba(16,185,129,0.18)' : 'rgba(239,68,68,0.16)',
            borderColor: isOnline ? 'rgba(74,222,128,0.5)' : 'rgba(248,113,113,0.5)',
          },
        ]}
      >
        <View style={[styles.orbChipDot, { backgroundColor: statusColor, shadowColor: statusColor }]} />
        <Text style={[styles.orbChipText, { color: isOnline ? '#BBF7D0' : '#FECACA' }]} numberOfLines={1}>
          {orbChipLabel(busy, isOnline)}
        </Text>
      </View>
    </View>
  );
}

function TabGlyph({
  item,
  active,
  color,
  glyph,
}: Readonly<{ item: DockItem; active: boolean; color: string; glyph?: IconGlyphName }>) {
  if (item.busy) return <ActivityIndicator size="small" color={color} />;
  if (item.mascot) {
    return (
      <Image
        source={AUTH_MASCOT}
        style={[styles.mascotIcon, !active && styles.appIconIdle]}
        resizeMode="cover"
        fadeDuration={0}
      />
    );
  }
  if (item.appIcon) {
    return <Image source={APP_ICON} style={[styles.appIcon, !active && styles.appIconIdle]} resizeMode="contain" />;
  }
  return <Ionicons name={glyph!} size={20} color={color} />;
}

function DockTab({
  item,
  active,
  accent,
  idleColor,
  onPress,
}: Readonly<{
  item: DockItem;
  active: boolean;
  accent: string;
  idleColor: string;
  onPress: () => void;
}>) {
  const on = useRef(new Animated.Value(active ? 1 : 0)).current;

  useEffect(() => {
    Animated.spring(on, {
      toValue: active ? 1 : 0,
      friction: 7,
      tension: 160,
      useNativeDriver: true,
    }).start();
  }, [active, on]);

  const color = item.tint ?? (active ? accent : idleColor);
  const pillScale = on.interpolate({ inputRange: [0, 1], outputRange: [0.6, 1] });
  const iconScale = on.interpolate({ inputRange: [0, 1], outputRange: [1, 1.1] });
  const glyph = active && item.icon ? (String(item.icon).replace(/-outline$/, '') as IconGlyphName) : item.icon;

  return (
    <TouchableOpacity
      style={[styles.tabItem, item.wide && styles.tabItemWide]}
      onPress={onPress}
      disabled={item.busy}
      activeOpacity={0.75}
      accessibilityRole="tab"
      accessibilityState={{ selected: active }}
      accessibilityLabel={item.label}
    >
      <Animated.View
        pointerEvents="none"
        style={[
          styles.tabPill,
          {
            backgroundColor: `${accent}1C`,
            borderColor: `${accent}40`,
            opacity: on,
            transform: [{ scale: pillScale }],
          },
        ]}
      >
        <View style={[styles.tabPillBar, { backgroundColor: accent, shadowColor: accent }]} />
      </Animated.View>

      <Animated.View style={[styles.iconWrap, { transform: [{ scale: iconScale }] }]}>
        <TabGlyph item={item} active={active} color={color} glyph={glyph} />
        {item.locked ? (
          <View style={styles.tabLock}>
            <Ionicons name="lock-closed" size={8} color="#0A1929" />
          </View>
        ) : null}
        {item.badge != null && item.badge > 0 ? (
          <View style={styles.badge}>
            <Text style={styles.badgeText}>{item.badge > 9 ? '9+' : item.badge}</Text>
          </View>
        ) : null}
      </Animated.View>
      <Text style={[styles.tabLabel, { color }, active && styles.tabLabelActive]} numberOfLines={1}>
        {item.label}
      </Text>
    </TouchableOpacity>
  );
}

export default function ValeterDashboardFloatingDock({
  accent,
  variant = 'tabBar',
  jobRequestCount = 0,
  activeTab = null,
  onJobsPress,
  isOnline = false,
  onlineBusy = false,
  onToggleOnline,
  trip = null,
  offer = null,
}: ValeterDashboardFloatingDockProps) {
  const router = useRouter();
  const pathname = usePathname();
  const insets = useSafeAreaInsets();
  const isGlobal = variant === 'global';
  const idleColor = 'rgba(241,245,249,0.5)';
  const resolvedActive = activeTab ?? resolveValeterDockTab(pathname || '');
  const [capsuleWidth, setCapsuleWidth] = useState(0);
  const liveOffer = trip ? null : offer;
  const offerAction: DockTripAction | null = useMemo(
    () => (liveOffer ? { label: 'Accept', icon: 'checkmark', onConfirm: liveOffer.onAccept } : null),
    [liveOffer]
  );
  const tripAction = trip?.step ?? offerAction;
  const tripConfirm = tripAction?.onConfirm;
  const confirmStep = useCallback(() => tripConfirm?.(), [tripConfirm]);
  const hold = useHoldToConfirm(confirmStep);
  const items: DockItem[] = useMemo(() => {
    if (trip) {
      return [
        { id: 'jobs', mascot: true, label: 'Map', action: 'jobs', onPress: trip.onHome },
        {
          id: 'messages',
          icon: 'chatbubble-ellipses-outline',
          label: 'Chat',
          onPress: trip.onChat,
          locked: trip.chatLocked,
        },
        {
          id: 'cancel',
          icon: trip.canCancel ? 'close-circle-outline' : 'alert-circle-outline',
          label: trip.canCancel ? 'Cancel' : 'Report',
          onPress: trip.onCancel,
          tint: trip.canCancel ? CANCEL_RED : REPORT_AMBER,
          wide: true,
          busy: trip.cancelling,
        },
      ];
    }
    return [
      { id: 'jobs', mascot: true, label: 'Home', action: 'jobs', badge: jobRequestCount },
      { id: 'messages', icon: 'chatbubble-ellipses-outline', label: 'Chat', route: '/valeter/inbox' },
      liveOffer
        ? { id: 'cancel', icon: 'close-circle-outline', label: 'Decline', onPress: liveOffer.onDecline, tint: CANCEL_RED }
        : { id: 'pricing', icon: 'pricetag-outline', label: 'Pricing', route: '/valeter/profile/valeter-services' },
      { id: 'activity', icon: 'calendar-outline', label: 'Activity', route: VALETER_ACTIVITY_ROUTE },
    ];
  }, [jobRequestCount, liveOffer, trip]);

  /** Pop back to the dashboard already in the stack — a second map instance fights the first over the live trip. */
  const openMapOffers = () => {
    router.dismissTo({ pathname: VALETER_MAP_ROUTE, params: { sheet: 'request', sheetAt: String(Date.now()) } } as Href);
  };

  const handlePress = async (item: DockItem) => {
    if (item.onPress) {
      await hapticFeedback('light');
      item.onPress();
      return;
    }
    const current = stripTrailingSlashes(pathname || '');
    if (item.action === 'jobs') {
      if (!onJobsPress && isValeterDashboardRoute(current)) return;
      await hapticFeedback('light');
      if (onJobsPress) onJobsPress();
      else openMapOffers();
      return;
    }
    if (current === item.route) return;
    await hapticFeedback('light');
    if (item.route) router.push(item.route as Href);
  };

  const handleOnlinePress = async () => {
    await hapticFeedback(isOnline ? 'light' : 'medium');
    if (onToggleOnline) {
      onToggleOnline();
      return;
    }
    router.replace(VALETER_MAP_ROUTE as Href);
  };

  const renderTab = (item: DockItem) => (
    <DockTab
      key={item.id}
      item={item}
      active={!trip && resolvedActive === item.id}
      accent={accent}
      idleColor={idleColor}
      onPress={() => handlePress(item)}
    />
  );

  const half = trip ? 2 : Math.ceil(items.length / 2);
  let centre: React.ReactNode;
  if (tripAction) centre = <StepOrb action={tripAction} hold={hold} />;
  else if (trip?.waiting) centre = <WaitOrb {...trip.waiting} />;
  else centre = <OnlineOrb isOnline={isOnline} busy={onlineBusy} onPress={handleOnlinePress} />;
  const tabs = (
    <View style={styles.tabRow}>
      <View style={styles.capsule} onLayout={(e) => setCapsuleWidth(e.nativeEvent.layout.width)}>
        <DockShape
          width={capsuleWidth}
          accent={accent}
          statusColor={isOnline || trip ? ONLINE_GREEN : OFFLINE_RED}
        />
        {tripAction ? <HoldTrace width={capsuleWidth} progress={hold.progress} /> : null}
        {items.slice(0, half).map(renderTab)}
        {centre}
        {items.slice(half).map(renderTab)}
      </View>
    </View>
  );

  if (!isGlobal) {
    return tabs;
  }

  return (
    <View style={[styles.globalWrap, { paddingBottom: Math.max(insets.bottom, 8) }]} pointerEvents="box-none">
      {tabs}
    </View>
  );
}

/** Global dock for non-dashboard valeter screens (reads badge + presence from nav context). */
export function ValeterGlobalDock() {
  const { theme } = useAccountTheme();
  const { jobRequestCount, dashboardStats } = useValeterNav();
  const accent = theme.primary || '#9EC9E0';
  return (
    <ValeterDashboardFloatingDock
      variant="global"
      accent={accent}
      jobRequestCount={jobRequestCount}
      isOnline={dashboardStats.isOnline}
    />
  );
}

const styles = StyleSheet.create({
  tabRow: {
    minHeight: VALETER_DOCK_ROW_HEIGHT,
    paddingTop: VALETER_DOCK_ROW_HEIGHT - CAPSULE_H,
    paddingHorizontal: DOCK_SIDE_INSET,
    marginTop: 'auto',
    backgroundColor: 'transparent',
    overflow: 'visible',
  },
  capsule: {
    height: CAPSULE_H,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 4,
    overflow: 'visible',
  },
  shapeSvg: {
    position: 'absolute',
    left: 0,
  },
  tabItemWide: {
    flex: 2,
  },
  mascotIcon: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.7)',
  },
  tabLock: {
    position: 'absolute',
    top: -3,
    right: 2,
    width: 13,
    height: 13,
    borderRadius: 7,
    backgroundColor: '#FBBF24',
    alignItems: 'center',
    justifyContent: 'center',
  },
  waitOrb: {
    backgroundColor: '#0B1F36',
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
  },
  traceSvg: {
    position: 'absolute',
    zIndex: 2,
  },
  stepHalo: {
    position: 'absolute',
    width: CRADLE + 14,
    height: CRADLE + 14,
    borderRadius: (CRADLE + 14) / 2,
    backgroundColor: 'rgba(74,222,128,0.22)',
    shadowColor: ONLINE_GREEN,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.9,
    shadowRadius: 16,
  },
  stepInner: {
    backgroundColor: '#0B3B2A',
  },
  stepChip: {
    backgroundColor: 'rgba(16,185,129,0.22)',
    borderColor: 'rgba(74,222,128,0.6)',
    maxWidth: 120,
  },
  stepChipText: {
    color: '#DCFCE7',
    fontSize: 8.5,
    fontWeight: '900',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  tabItem: {
    flex: 1,
    height: CAPSULE_H,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 2,
    minWidth: 0,
  },
  tabPill: {
    position: 'absolute',
    top: 4,
    bottom: 4,
    left: 4,
    right: 4,
    borderRadius: 17,
    borderWidth: 1,
    alignItems: 'center',
  },
  tabPillBar: {
    width: 14,
    height: 2.5,
    borderRadius: 2,
    marginTop: -1,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.9,
    shadowRadius: 4,
  },
  iconWrap: {
    width: 32,
    height: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  appIcon: {
    width: 21,
    height: 21,
    borderRadius: 6,
  },
  appIconIdle: {
    opacity: 0.7,
  },
  tabLabel: {
    fontSize: 9,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  tabLabelActive: {
    fontWeight: '900',
  },
  badge: {
    position: 'absolute',
    top: -5,
    right: -3,
    minWidth: 16,
    height: 16,
    paddingHorizontal: 4,
    borderRadius: 8,
    backgroundColor: '#EF4444',
    borderWidth: 1.5,
    borderColor: '#0A1929',
    alignItems: 'center',
    justifyContent: 'center',
  },
  badgeText: {
    color: '#FFFFFF',
    fontSize: 8.5,
    fontWeight: '900',
  },
  orbSlot: {
    flex: 1.25,
    height: CAPSULE_H,
    alignItems: 'center',
    overflow: 'visible',
  },
  orbAnchor: {
    position: 'absolute',
    top: -ORB_RAISE,
    width: CRADLE,
    height: CRADLE,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'visible',
  },
  orbHalo: {
    position: 'absolute',
    width: CRADLE + 6,
    height: CRADLE + 6,
    borderRadius: (CRADLE + 6) / 2,
  },
  orbPulse: {
    position: 'absolute',
    width: ORB,
    height: ORB,
    borderRadius: ORB / 2,
    borderWidth: 2,
  },
  orbShadow: {
    width: ORB,
    height: ORB,
    borderRadius: ORB / 2,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.6,
    shadowRadius: 12,
    elevation: 12,
  },
  orbRing: {
    flex: 1,
    borderRadius: ORB / 2,
    padding: ORB_RING,
  },
  orbInner: {
    flex: 1,
    borderRadius: (ORB - ORB_RING * 2) / 2,
    overflow: 'hidden',
    backgroundColor: '#0B2A4A',
    alignItems: 'center',
    justifyContent: 'center',
  },
  orbMascot: {
    width: '100%',
    height: '100%',
  },
  orbGloss: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: '55%',
  },
  sparkle: {
    position: 'absolute',
    width: 7,
    height: 7,
    borderRadius: 4,
  },
  orbChip: {
    position: 'absolute',
    bottom: 5,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 7,
    paddingVertical: 1.5,
    borderRadius: 999,
    borderWidth: 1,
  },
  orbChipDot: {
    width: 5,
    height: 5,
    borderRadius: 3,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.9,
    shadowRadius: 3,
  },
  orbChipText: {
    fontSize: 8.5,
    fontWeight: '900',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  globalWrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 40,
    overflow: 'visible',
  },
});
