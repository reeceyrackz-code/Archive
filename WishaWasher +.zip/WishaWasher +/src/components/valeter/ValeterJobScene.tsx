import React, { useEffect, useMemo } from 'react';
import { Image, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import Reanimated, {
  Easing,
  FadeIn,
  FadeOut,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withTiming,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import UkNumberPlate from '../shared/UkNumberPlate';
import ValeterArrivalScene from './ValeterArrivalScene';
import { useJobPhotos } from '../../services/jobPhotos';
import { bookingJourney } from '../../utils/washJourney';
import type { ValeterBackdropJob } from './ValeterStageBackdrop';

const GREEN = '#34D399';
const AMBER = '#FBBF24';
const KIND_WORD = { wash: 'WASHING', detail: 'DETAILING', repair: 'REPAIRING' } as const;

type StageLook = Readonly<{ chip: string; tone: string; line: string; dim: number }>;

function stageLook(status: string | null, first: string, kind: keyof typeof KIND_WORD, accent: string): StageLook {
  switch (status) {
    case 'pending_payment':
      return { chip: 'AWAITING PAYMENT', tone: AMBER, line: `Waiting for ${first} to pay`, dim: 0.62 };
    case 'arrived':
      return { chip: 'ON SITE', tone: GREEN, line: 'Take the before photo to start', dim: 0.3 };
    case 'in_progress':
      return { chip: KIND_WORD[kind], tone: accent, line: 'Hands free · mark complete when you’re done', dim: 0.22 };
    case 'completed':
      return { chip: 'COMPLETE', tone: GREEN, line: 'Finished and handed back', dim: 0.18 };
    default:
      return { chip: 'PAID', tone: GREEN, line: 'Locked in · start the journey when ready', dim: 0.3 };
  }
}

/** Slow push-in on the photo so the still feels live. */
function useKenBurns() {
  const t = useSharedValue(0);
  useEffect(() => {
    t.value = withRepeat(withTiming(1, { duration: 18000, easing: Easing.inOut(Easing.sin) }), -1, true);
  }, [t]);
  return useAnimatedStyle(() => ({ transform: [{ scale: 1.04 + t.value * 0.06 }] }));
}

/** A soft band of light that crosses the car when the stage changes (and slowly, on loop, while working). */
function LightSweep({ status, working }: Readonly<{ status: string | null; working: boolean }>) {
  const { width: W, height: H } = useWindowDimensions();
  const t = useSharedValue(0);
  useEffect(() => {
    t.value = 0;
    t.value = working
      ? withRepeat(withSequence(withTiming(1, { duration: 2600, easing: Easing.inOut(Easing.cubic) }), withTiming(1, { duration: 5200 })), -1, false)
      : withTiming(1, { duration: 1400, easing: Easing.inOut(Easing.cubic) });
  }, [t, status, working]);
  const style = useAnimatedStyle(() => ({
    opacity: Math.sin(Math.min(1, t.value) * Math.PI) * (working ? 0.55 : 0.9),
    transform: [{ translateX: -W + t.value * W * 2.2 }, { rotate: '14deg' }],
  }));
  return (
    <Reanimated.View pointerEvents="none" style={[styles.sweep, { width: W * 0.7, height: H * 1.4, top: -H * 0.2 }, style]}>
      <LinearGradient
        colors={['rgba(255,255,255,0)', 'rgba(255,255,255,0.10)', 'rgba(255,255,255,0.18)', 'rgba(255,255,255,0.10)', 'rgba(255,255,255,0)']}
        start={{ x: 0, y: 0.5 }}
        end={{ x: 1, y: 0.5 }}
        style={StyleSheet.absoluteFill}
      />
    </Reanimated.View>
  );
}

/** Lighting over the photo: darker while waiting to be paid, up once the job is on. */
function StageLight({ dim }: Readonly<{ dim: number }>) {
  const v = useSharedValue(dim);
  useEffect(() => {
    v.value = withTiming(dim, { duration: 900, easing: Easing.out(Easing.cubic) });
  }, [v, dim]);
  const style = useAnimatedStyle(() => ({ opacity: v.value }));
  return <Reanimated.View pointerEvents="none" style={[StyleSheet.absoluteFill, styles.dim, style]} />;
}

function photoFor(status: string | null, photos: { before: string | null; after: string | null }, booked: string | null) {
  if (status === 'completed') return { uri: photos.after ?? photos.before ?? booked, tag: photos.after ? 'FINISHED' : 'BEFORE' };
  if (status === 'in_progress' && photos.before) return { uri: photos.before, tag: 'BEFORE' };
  return { uri: booked, tag: 'FROM BOOKING' };
}

/**
 * The job as it really is: the customer's car (booking photo, then the Pro's own before / finished shots)
 * full-bleed behind the trip sheet, with its plate, make and the stage. Covers the map for every stage
 * except the drive.
 */
export default function ValeterJobScene({
  job,
  accent,
  topInset,
  bottomInset,
}: Readonly<{ job: ValeterBackdropJob; accent: string; topInset: number; bottomInset: number }>) {
  const status = job.status;
  const photos = useJobPhotos(job.id, status, !job.isPreview && (status === 'arrived' || status === 'in_progress' || status === 'completed'));
  const kind = useMemo(
    () =>
      bookingJourney({ serviceType: job.serviceType, serviceName: job.serviceName, washType: job.washType, addOnIds: job.addOnIds })
        .kind,
    [job.serviceType, job.serviceName, job.washType, job.addOnIds]
  );
  const first = job.customerName.trim().split(/\s+/)[0] || 'the customer';
  const look = stageLook(status, first, kind, accent);
  const photo = photoFor(status, photos, job.vehiclePhoto);
  const kenBurns = useKenBurns();
  const vehicleLine = [job.vehicleColour, job.vehicleLabel].filter(Boolean).join(' · ');
  const more = job.vehicleCount > 1 ? `+${job.vehicleCount - 1} more` : null;

  if (!photo.uri) {
    return (
      <Reanimated.View
        entering={FadeIn.duration(600)}
        exiting={FadeOut.duration(400)}
        pointerEvents="box-none"
        style={[StyleSheet.absoluteFill, styles.root, styles.rootScene]}
      >
        <LinearGradient pointerEvents="none" colors={['#27344F', '#1F2A40', '#1A2337']} style={StyleSheet.absoluteFill} />
        <View pointerEvents="box-none" style={[styles.carStage, { top: topInset + 4, bottom: bottomInset + 84 }]}>
          <ValeterArrivalScene
            status={status}
            tone={look.tone}
            accent={accent}
            kind={kind}
            first={first}
            carLabel={job.vehicleLabel ? vehicleLine : null}
          />
        </View>
        {status === 'pending_payment' ? <StageLight dim={0.12} /> : null}
        <JobInfo job={job} look={look} vehicleLine={vehicleLine} more={more} bottom={bottomInset + 18} />
      </Reanimated.View>
    );
  }

  return (
    <Reanimated.View
      entering={FadeIn.duration(600)}
      exiting={FadeOut.duration(400)}
      pointerEvents="none"
      style={[StyleSheet.absoluteFill, styles.root]}
    >
      <Reanimated.View key={photo.uri} entering={FadeIn.duration(800)} style={StyleSheet.absoluteFill}>
        <Reanimated.View style={[StyleSheet.absoluteFill, kenBurns]}>
          <Image source={{ uri: photo.uri }} resizeMode="cover" style={StyleSheet.absoluteFill} />
        </Reanimated.View>
      </Reanimated.View>

      <StageLight dim={look.dim} />
      <LightSweep status={status} working={status === 'in_progress'} />

      <LinearGradient
        colors={['rgba(3,6,14,0.92)', 'rgba(3,6,14,0.35)', 'rgba(3,6,14,0)']}
        style={[styles.topShade, { height: topInset + 70 }]}
      />
      <LinearGradient
        colors={['rgba(3,6,14,0)', 'rgba(3,6,14,0.7)', 'rgba(3,6,14,0.96)']}
        style={[styles.bottomShade, { height: bottomInset + 240 }]}
      />

      <Reanimated.View key={`tag-${photo.tag}`} entering={FadeIn.duration(500)} style={[styles.photoTag, { top: topInset + 12 }]}>
        <Text style={styles.photoTagText}>{photo.tag}</Text>
      </Reanimated.View>

      <JobInfo job={job} look={look} vehicleLine={vehicleLine} more={more} bottom={bottomInset + 18} />
    </Reanimated.View>
  );
}

function JobInfo({
  job,
  look,
  vehicleLine,
  more,
  bottom,
}: Readonly<{ job: ValeterBackdropJob; look: StageLook; vehicleLine: string; more: string | null; bottom: number }>) {
  return (
    <View pointerEvents="none" style={[styles.info, { bottom }]}>
      <Reanimated.View key={`chip-${look.chip}-${look.line}`} entering={FadeIn.duration(450)} style={styles.chipRow}>
        <View style={[styles.chipDot, { backgroundColor: look.tone }]} />
        <Text style={[styles.chipText, { color: look.tone }]}>{look.chip}</Text>
        <Text style={styles.line} numberOfLines={1}>
          {look.line}
        </Text>
      </Reanimated.View>
      {job.vehicleReg || vehicleLine || more ? (
        <View style={styles.vehicleRow}>
          {job.vehicleReg ? <UkNumberPlate reg={job.vehicleReg} size="sm" /> : null}
          {vehicleLine || more ? (
            <Text style={styles.vehicle} numberOfLines={1}>
              {vehicleLine}
              {more ? <Text style={styles.vehicleMore}>{vehicleLine ? `  ·  ${more}` : more}</Text> : null}
            </Text>
          ) : null}
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { zIndex: 11, backgroundColor: '#04060B', overflow: 'hidden' },
  rootScene: { backgroundColor: '#1F2A40' },
  dim: { backgroundColor: '#03060E' },
  sweep: { position: 'absolute', left: 0 },
  carStage: { position: 'absolute', left: 0, right: 0 },
  topShade: { position: 'absolute', top: 0, left: 0, right: 0 },
  bottomShade: { position: 'absolute', bottom: 0, left: 0, right: 0 },
  photoTag: {
    position: 'absolute',
    left: 16,
    paddingHorizontal: 9,
    paddingVertical: 4,
    borderRadius: 6,
    backgroundColor: 'rgba(3,6,14,0.55)',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(255,255,255,0.18)',
  },
  photoTagText: { color: 'rgba(241,245,249,0.85)', fontSize: 10, fontWeight: '700', letterSpacing: 1.2 },
  info: { position: 'absolute', left: 20, right: 20, alignItems: 'stretch', gap: 7 },
  chipRow: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  chipDot: { width: 7, height: 7, borderRadius: 4 },
  chipText: { fontSize: 11, fontWeight: '800', letterSpacing: 1.3 },
  vehicleRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  vehicle: { flexShrink: 1, color: '#F8FAFC', fontSize: 15, fontWeight: '700', letterSpacing: -0.2 },
  vehicleMore: { color: 'rgba(203,213,225,0.75)', fontWeight: '600', fontSize: 13 },
  line: { flexShrink: 1, color: 'rgba(203,213,225,0.82)', fontSize: 12.5, fontWeight: '600' },
});
