import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  PanResponder,
  type GestureResponderHandlers,
  type LayoutChangeEvent,
  type PanResponderGestureState,
} from 'react-native';
import Reanimated, {
  Easing,
  FadeIn,
  FadeInDown,
  FadeInUp,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withRepeat,
  withSequence,
  withTiming,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import InfoBottomSheet from '../shared/InfoBottomSheet';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import ValeterDashboardChrome, { headerChromeStop, softenedTint } from './ValeterDashboardChrome';
import Svg, { Defs, LinearGradient as SvgGradient, Path, Stop } from 'react-native-svg';
import { dockNotchedCardPath } from './ValeterDashboardFloatingDock';
import HillRoadStepper, { currentStageIndex } from './HillRoadStepper';
import { getServiceDisplayName } from '../../utils/serviceNameMapper';
import { openExternalDirections } from '../../utils/externalMaps';
import { HEADER_STYLE_CARD_GRADIENT } from '../../constants/bookingCardTheme';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import {
  type ValeterTrackingJob,
  type ValeterTrackingStatus,
  type BookingVehicleItem,
} from '../../hooks/useValeterJobTracking';
import { isChatLockedUntilPaid, type StageItem } from '../../utils/trackingStatusHelpers';
import { lightMistPanel, lightMistElevated } from '../../constants/accountThemes';
import BookingVehiclesInfoSheet from '../shared/BookingVehiclesInfoSheet';
import { clock, firstName, formatTimeLeft, useCountdown, useWashLive, type WashLive } from './road/stageHooks';
import { bookingJourney } from '../../utils/washJourney';

/** Content-only estimate for map padding when sheet height is not measured yet */
export const VALETER_TRACKING_SHEET_CONTENT_ESTIMATE = 270;
const DRAG_CLOSE_THRESHOLD = 80;
const DRAG_VELOCITY_THRESHOLD = 0.3;
const MAX_PEEK_DRAG = 48;
/** Same green as the nav dock's step button — progress and done states share it. */
const DONE_GREEN = '#4ADE80';
/** The dark theme's accentAlt is amber, so the yellow is pinned here. */
const BRAND_YELLOW = '#FACC15';
const CARD_RADIUS = 24;
/** Share of the theme's sky tint the card keeps — it already sits on the tinted sheet glass. */
const CARD_TINT = 0.35;

export function valeterTrackingSheetTotalHeight(safeBottom: number, contentHeight = VALETER_TRACKING_SHEET_CONTENT_ESTIMATE) {
  return contentHeight + Math.max(safeBottom, 8);
}

type VehicleDetails = {
  registration?: string;
  make?: string;
  model?: string;
  photo?: string;
  colour?: string;
  summaryLine?: string;
} | null;

export type ValeterJobTrackingSheetProps = Readonly<{
  accent: string;
  sheetGradient?: readonly [string, string];
  job: ValeterTrackingJob;
  status: ValeterTrackingStatus;
  statusMessage: string;
  customerName: string;
  vehicleDetails: VehicleDetails;
  bookingVehicles?: BookingVehicleItem[];
  etaMinutes: number | null;
  distanceMi: number | null;
  stages: StageItem[];
  stageProgressPercent: number;
  onChat: () => void;
  onClose: () => void;
  infoSheetVisible: boolean;
  onOpenInfo: () => void;
  onCloseInfo: () => void;
  onMeasuredHeight?: (totalHeight: number) => void;
  /** Render inside the dashboard bottom sheet (no absolute overlay / drag-to-dismiss). */
  embedded?: boolean;
  /** Seconds left in the customer's payment window (pending payment only). */
  paymentSecondsLeft?: number | null;
  /** Valeter's take-home for this job. */
  earned?: number | null;
  isPreview?: boolean;
}>;

/** Card background drawn as a path so its bottom edge can wrap the nav dock's hump. */
function TrackingCardShape({
  width,
  height,
  notched,
  gradient,
  border,
}: Readonly<{
  width: number;
  height: number;
  notched: boolean;
  gradient: readonly [string, string];
  border: string;
}>) {
  if (width <= 0 || height <= 0) return null;
  const d = dockNotchedCardPath(width, height, CARD_RADIUS, notched);
  const [top, bottom] = softenedTint(gradient, CARD_TINT);
  return (
    <Svg pointerEvents="none" width={width} height={height} style={StyleSheet.absoluteFill}>
      <Defs>
        <SvgGradient id="trackCardFill" x1="0" y1="0" x2="0" y2="1">
          <Stop offset="0" stopColor={headerChromeStop(top, 'EE')} />
          <Stop offset="1" stopColor={headerChromeStop(bottom, 'F0')} />
        </SvgGradient>
      </Defs>
      <Path d={d} fill="url(#trackCardFill)" />
      <Path d={d} fill="none" stroke={border} strokeWidth={1} />
    </Svg>
  );
}

const VAN_ART = require('../../../assets/tracking-van-pin.png');
/** Top-down van art facing right — width / height. */
const VAN_RATIO = 300 / 143;
const ROAD_H = 34;
const ROAD_STRIP = 12;
const ROAD_PAD = 18;
const VAN_W = 38;
const VAN_H = VAN_W / VAN_RATIO;
const DRIVE_MS = 1200;
const LABEL_W = 64;
const STOP = 14;

const SHORT_STAGE_LABELS: Record<string, string> = {
  'Awaiting payment': 'Payment',
  'Accept job': 'Accept',
};

function shortStageLabel(label: string) {
  return SHORT_STAGE_LABELS[label] ?? label;
}

function RoadStop({
  done,
  final,
  color,
  x,
  hidden,
}: Readonly<{ done: boolean; final: boolean; color: string; x: number; hidden: boolean }>) {
  if (hidden) return null;
  if (final) {
    return (
      <View
        style={[
          styles.roadStop,
          styles.roadStopFlag,
          { left: x - STOP / 2 - 1 },
          done ? { backgroundColor: DONE_GREEN, borderColor: DONE_GREEN } : null,
        ]}
      >
        <Ionicons name={done ? 'sparkles' : 'flag'} size={9} color={done ? '#04121F' : 'rgba(226,232,240,0.85)'} />
      </View>
    );
  }
  if (done) {
    return (
      <View style={[styles.roadStop, styles.roadStopDone, { left: x - STOP / 2, backgroundColor: color, shadowColor: color }]}>
        <Ionicons name="checkmark" size={9} color="#04121F" />
      </View>
    );
  }
  return <View style={[styles.roadStop, styles.roadStopTodo, { left: x - 4 }]} />;
}

function TrackingStepper({
  stages,
  accent,
  textMain,
  mutedColor,
  isLight,
}: Readonly<{ stages: StageItem[]; accent: string; textMain: string; mutedColor: string; isLight: boolean }>) {
  const [width, setWidth] = useState(0);
  const n = stages.length;
  const activeIndex = currentStageIndex(stages);
  const allDone = n > 0 && stages.every((s) => s.done);
  const asphalt = isLight ? 'rgba(15,23,42,0.16)' : 'rgba(2,6,23,0.55)';
  const roadColor = DONE_GREEN;
  const stopX = (i: number) => (n > 1 ? ROAD_PAD + (i * (width - ROAD_PAD * 2)) / (n - 1) : width / 2);

  const vanX = useSharedValue(0);
  const moving = useSharedValue(0);
  const bob = useSharedValue(0);
  const halo = useSharedValue(0);
  const placedRef = useRef(false);

  useEffect(() => {
    bob.value = withRepeat(withTiming(1, { duration: 420, easing: Easing.inOut(Easing.sin) }), -1, true);
    halo.value = withRepeat(withTiming(1, { duration: 1600, easing: Easing.out(Easing.quad) }), -1, false);
  }, [bob, halo]);

  useEffect(() => {
    if (!width) return;
    const target = stopX(activeIndex);
    if (!placedRef.current) {
      placedRef.current = true;
      vanX.value = target;
      return;
    }
    if (Math.abs(vanX.value - target) < 1) return;
    void hapticFeedback('soft');
    moving.value = withSequence(
      withTiming(1, { duration: 120 }),
      withDelay(DRIVE_MS - 200, withTiming(0, { duration: 260 }))
    );
    vanX.value = withTiming(target, { duration: DRIVE_MS, easing: Easing.inOut(Easing.cubic) });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [width, activeIndex]);

  const vanStyle = useAnimatedStyle(() => ({
    transform: [
      { translateX: vanX.value - VAN_W / 2 },
      { translateY: (bob.value - 0.5) * (0.5 + moving.value * 2) },
      { rotate: `${(bob.value - 0.5) * moving.value * 3}deg` },
    ],
  }));
  const haloStyle = useAnimatedStyle(() => ({
    opacity: allDone ? 0 : 0.45 * (1 - halo.value) * (1 - moving.value),
    transform: [{ translateX: vanX.value - VAN_W / 2 }, { scale: 0.7 + halo.value * 0.6 }],
  }));
  const fillStyle = useAnimatedStyle(() => ({ width: Math.max(0, vanX.value) }));
  const puffA = useAnimatedStyle(() => ({
    opacity: moving.value * (0.35 + bob.value * 0.35),
    transform: [{ translateX: vanX.value - VAN_W / 2 - 8 - bob.value * 6 }, { scale: 0.7 + bob.value * 0.6 }],
  }));
  const puffB = useAnimatedStyle(() => ({
    opacity: moving.value * (0.7 - bob.value * 0.4),
    transform: [{ translateX: vanX.value - VAN_W / 2 - 18 - (1 - bob.value) * 6 }, { scale: 1.1 - bob.value * 0.5 }],
  }));

  return (
    <View style={styles.stepperWrap}>
      <View
        style={styles.road}
        onLayout={(e) => {
          const w = Math.round(e.nativeEvent.layout.width);
          if (w !== width) setWidth(w);
        }}
        accessible
        accessibilityLabel={`Step ${activeIndex + 1} of ${n}: ${stages[activeIndex]?.label ?? ''}`}
      >
        <View style={[styles.roadStrip, { backgroundColor: asphalt }]}>
          <Reanimated.View style={[styles.roadFill, fillStyle]}>
            <LinearGradient
              colors={[`${roadColor}14`, `${roadColor}80`]}
              start={{ x: 0, y: 0.5 }}
              end={{ x: 1, y: 0.5 }}
              style={StyleSheet.absoluteFill}
            />
          </Reanimated.View>
          <View style={styles.roadDashes} pointerEvents="none">
            {Array.from({ length: 16 }, (_, i) => (
              <View key={i} style={styles.roadDash} />
            ))}
          </View>
        </View>
        {width > 0
          ? stages.map((stage, i) => (
              <RoadStop
                key={`${stage.label}-${i}`}
                done={stage.done}
                final={i === n - 1}
                hidden={!allDone && i === activeIndex}
                color={roadColor}
                x={stopX(i)}
              />
            ))
          : null}
        {width > 0 ? (
          <>
            <Reanimated.View pointerEvents="none" style={[styles.vanHalo, { backgroundColor: roadColor }, haloStyle]} />
            <Reanimated.View pointerEvents="none" style={[styles.puff, puffB]} />
            <Reanimated.View pointerEvents="none" style={[styles.puff, puffA]} />
            <Reanimated.View pointerEvents="none" style={[styles.van, vanStyle]}>
              <LinearGradient
                colors={['rgba(255,255,255,0.32)', 'rgba(255,255,255,0)']}
                start={{ x: 0, y: 0.5 }}
                end={{ x: 1, y: 0.5 }}
                style={styles.vanBeam}
              />
              <View style={styles.vanShadow} />
              <Reanimated.Image source={VAN_ART} resizeMode="contain" style={styles.vanImage} />
            </Reanimated.View>
          </>
        ) : null}
      </View>

      <View style={styles.roadLabels}>
        {width > 0
          ? stages.map((stage, i) => {
              const isCurrent = !allDone && i === activeIndex;
              const finalDone = allDone && i === n - 1;
              const pill = isCurrent || finalDone;
              const tone = DONE_GREEN;
              return (
                <View key={`${stage.label}-${i}`} style={[styles.roadLabelSlot, { left: stopX(i) - LABEL_W / 2 }]}>
                  <Text
                    numberOfLines={1}
                    style={[
                      styles.roadLabel,
                      { color: stage.done ? textMain : mutedColor },
                      pill && [styles.roadLabelCurrent, { color: tone, backgroundColor: `${tone}1F`, borderColor: `${tone}55` }],
                    ]}
                  >
                    {shortStageLabel(stage.label)}
                  </Text>
                </View>
              );
            })
          : null}
      </View>
    </View>
  );
}

function LiveDot({ color }: Readonly<{ color: string }>) {
  const pulse = useSharedValue(0);
  useEffect(() => {
    pulse.value = withRepeat(withTiming(1, { duration: 1400, easing: Easing.out(Easing.quad) }), -1, false);
  }, [pulse]);
  const ring = useAnimatedStyle(() => ({
    opacity: 0.7 * (1 - pulse.value),
    transform: [{ scale: 1 + pulse.value * 1.6 }],
  }));
  return (
    <View style={styles.liveDotWrap}>
      <Reanimated.View style={[styles.liveDotRing, { backgroundColor: color }, ring]} />
      <View style={[styles.liveDot, { backgroundColor: color }]} />
    </View>
  );
}



const PAY_GOLD = '#FBBF24';
const PAY_RED = '#FB7185';
const PAYMENT_WINDOW_S = 300;

type HeroMetric = Readonly<{ value: string; unit: string | null; caption: string | null; tone: string; progress: number }>;

type HeroInput = Readonly<{
  status: ValeterTrackingStatus;
  accent: string;
  paySecs: number | null;
  etaMinutes: number | null;
  distanceMi: number | null;
  wash: WashLive;
  earned: number | null;
  stageProgressPercent: number;
}>;

function paymentTone(secs: number | null, accent: string) {
  if (secs == null) return accent;
  if (secs <= 60) return PAY_RED;
  if (secs <= 150) return PAY_GOLD;
  return accent;
}

function money(amount: number | null) {
  return amount == null ? null : `£${amount.toFixed(2)}`;
}

const etaMetric = (h: HeroInput): HeroMetric => ({
  value: h.etaMinutes == null ? '—' : String(Math.max(1, h.etaMinutes)),
  unit: h.etaMinutes == null ? null : 'min',
  caption: h.distanceMi == null ? 'away' : `${h.distanceMi.toFixed(1)} mi away`,
  tone: h.accent,
  progress: h.stageProgressPercent / 100,
});

const HERO_METRICS: Partial<Record<ValeterTrackingStatus, (h: HeroInput) => HeroMetric>> = {
  pending_payment: (h) => ({
    value: h.paySecs == null ? '--:--' : clock(h.paySecs),
    unit: null,
    caption: h.paySecs === 0 ? 'window ended' : 'to pay',
    tone: paymentTone(h.paySecs, h.accent),
    progress: h.paySecs == null ? 1 : h.paySecs / PAYMENT_WINDOW_S,
  }),
  confirmed: etaMetric,
  scheduled: etaMetric,
  en_route: etaMetric,
  arrived: (h) => ({ value: 'Here', unit: null, caption: 'on site', tone: DONE_GREEN, progress: h.stageProgressPercent / 100 }),
  in_progress: (h) => ({
    value: h.wash.timeLeftMs == null ? 'Starting' : formatTimeLeft(h.wash.timeLeftMs),
    unit: null,
    caption: h.wash.timeLeftMs != null && h.wash.timeLeftMs <= 0 ? 'past estimate' : 'est. left',
    tone: h.accent,
    progress: h.wash.progress,
  }),
  completed: (h) => ({ value: money(h.earned) ?? 'Done', unit: null, caption: 'take-home', tone: DONE_GREEN, progress: 1 }),
};

function heroMetricFor(h: HeroInput): HeroMetric {
  const pick = HERO_METRICS[h.status];
  if (pick) return pick(h);
  const pct = Math.max(0, Math.min(100, Math.round(h.stageProgressPercent)));
  return { value: String(pct), unit: '%', caption: 'complete', tone: h.accent, progress: pct / 100 };
}

function HeroProgress({ progress, color, track }: Readonly<{ progress: number; color: string; track: string }>) {
  const p = useSharedValue(progress);
  useEffect(() => {
    p.value = withTiming(Math.max(0, Math.min(1, progress)), { duration: 700, easing: Easing.out(Easing.cubic) });
  }, [p, progress]);
  const fill = useAnimatedStyle(() => ({ width: `${p.value * 100}%` }));
  return (
    <View style={[styles.heroTrack, { backgroundColor: track }]}>
      <Reanimated.View style={[styles.heroFill, { backgroundColor: color }, fill]} />
    </View>
  );
}

type StripInfo = Readonly<{ icon: React.ComponentProps<typeof Ionicons>['name']; tone: string; title: string; sub: string | null }>;

/** The one stage-specific line under the headline: who we're waiting on, what's being done now, or what was earned. */
function stageStripFor(status: ValeterTrackingStatus, first: string, earned: number | null, paySecs: number | null): StripInfo | null {
  switch (status) {
    case 'pending_payment':
      return {
        icon: 'wallet-outline',
        tone: paymentTone(paySecs, PAY_GOLD),
        title: paySecs === 0 ? 'Payment window ended' : `Waiting for ${first} to pay`,
        sub: `Chat unlocks once ${first} has paid`,
      };
    case 'confirmed':
      return {
        icon: 'checkmark-circle',
        tone: DONE_GREEN,
        title: `${first} has paid`,
        sub: earned == null ? "You're clear to head over" : `${money(earned)} take-home · clear to head over`,
      };
    case 'in_progress':
      return null;
    case 'completed':
      return { icon: 'sparkles', tone: DONE_GREEN, title: 'Job complete', sub: earned == null ? null : `${money(earned)} added to today` };
    default:
      return null;
  }
}

function StageStrip({ strip, textMain }: Readonly<{ strip: StripInfo; textMain: string }>) {
  return (
    <Reanimated.View
      key={`strip-${strip.title}`}
      entering={FadeIn.duration(320)}
      style={styles.strip}
    >
      <View style={[styles.stripIcon, { backgroundColor: `${strip.tone}22` }]}>
        <Ionicons name={strip.icon} size={14} color={strip.tone} />
      </View>
      <View style={styles.stripCopy}>
        <Text style={[styles.stripTitle, { color: textMain }]} numberOfLines={1}>
          {strip.title}
        </Text>
      </View>
    </Reanimated.View>
  );
}

function VehicleInfoTrigger({
  accent,
  count,
  mutedColor,
  textMain,
  onPress,
}: Readonly<{
  accent: string;
  count: number;
  mutedColor: string;
  textMain: string;
  onPress: () => void;
}>) {
  return (
    <TouchableOpacity
      style={[styles.vehicleInfoTrigger, { borderColor: `${accent}40`, backgroundColor: `${accent}12` }]}
      onPress={async () => {
        await hapticFeedback('light');
        onPress();
      }}
      activeOpacity={0.85}
      accessibilityRole="button"
      accessibilityLabel="Vehicle info"
    >
      <View style={[styles.vehicleInfoIconWrap, { backgroundColor: `${accent}22` }]}>
        <Ionicons name="information-circle" size={18} color={accent} />
      </View>
      <View style={styles.vehicleInfoCopy}>
        <Text style={[styles.vehicleInfoTitle, { color: textMain }]}>Vehicle info</Text>
        <Text style={[styles.vehicleInfoSub, { color: mutedColor }]}>
          {count > 1 ? `${count} vehicles · tap to view` : 'Tap to view details & photos'}
        </Text>
      </View>
      <Ionicons name="chevron-forward" size={18} color={accent} />
    </TouchableOpacity>
  );
}

/** Primary CTA: solid accent pill for the next step, a calm waiting state while the customer pays. */
function formatScheduledAt(iso?: string | null): string | null {
  if (!iso) return null;
  try {
    return new Date(iso).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
  } catch {
    return null;
  }
}

function JobDetailRow({
  accent,
  icon,
  label,
  value,
  highlight,
  textMain,
  textMuted,
}: Readonly<{
  accent: string;
  icon: React.ComponentProps<typeof Ionicons>['name'];
  label: string;
  value: string;
  highlight?: boolean;
  textMain: string;
  textMuted: string;
}>) {
  return (
    <View style={styles.jobDetailRow}>
      <View style={[styles.jobDetailRowIcon, { backgroundColor: `${accent}18` }]}>
        <Ionicons name={icon} size={17} color={accent} />
      </View>
      <View style={styles.jobDetailRowBody}>
        <Text style={[styles.jobDetailRowLabel, { color: textMuted }]}>{label}</Text>
        <Text
          style={[
            styles.jobDetailRowValue,
            { color: textMain },
            highlight && { color: accent, fontWeight: '800' },
          ]}
          numberOfLines={3}
        >
          {value}
        </Text>
      </View>
    </View>
  );
}

function JobDetailsContent({
  accent,
  customerName,
  job,
  status,
  statusMessage,
  bookingVehicles,
  etaMinutes,
  distanceMi,
  onChat,
  onOpenVehicles,
}: Readonly<{
  accent: string;
  customerName: string;
  job: ValeterTrackingJob;
  status: ValeterTrackingStatus;
  statusMessage: string;
  bookingVehicles: BookingVehicleItem[];
  etaMinutes: number | null;
  distanceMi: number | null;
  onChat: () => void;
  onOpenVehicles: () => void;
}>) {
  const { theme, mode } = useAccountTheme();
  const isLight = mode === 'light';
  const textMain = theme.textPrimary ?? '#F1F5F9';
  const textMuted = theme.textSecondary ?? 'rgba(241,245,249,0.7)';
  const moneyColor = theme.accentAlt ?? '#E8C547';
  const vehicleCount = bookingVehicles.length;
  const chatLocked = isChatLockedUntilPaid(status);
  const scheduledLabel = formatScheduledAt(job.scheduled_at);
  const priceLabel = `£${Number(job.price ?? 0).toFixed(2)}`;
  const etaLabel =
    etaMinutes != null && distanceMi != null ? `~${etaMinutes} min · ${distanceMi} mi away` : null;

  const handleDirections = async () => {
    await hapticFeedback('light');
    try {
      await openExternalDirections({
        address: job.location_address,
        latitude: job.location_lat != null ? Number(job.location_lat) : null,
        longitude: job.location_lng != null ? Number(job.location_lng) : null,
        label: customerName,
      });
    } catch {
      /* no destination */
    }
  };

  return (
    <View style={styles.jobInfoProfile}>
      <View style={styles.jobInfoHero}>
        <View style={[styles.jobInfoAvatar, { borderColor: `${accent}70` }]}>
          <Ionicons name="person" size={32} color={accent} />
        </View>
        <Text style={[styles.jobInfoProfileName, { color: textMain }]}>{customerName}</Text>
        <Text style={[styles.jobInfoProfileHeadline, { color: accent }]}>
          {getServiceDisplayName(job.service_type, job.service_name)}
        </Text>
        <View style={[styles.jobInfoStatusPill, { backgroundColor: `${accent}18`, borderColor: `${accent}40` }]}>
          <View style={[styles.jobInfoStatusDot, { backgroundColor: accent }]} />
          <Text style={[styles.jobInfoStatusText, { color: accent }]}>{statusMessage}</Text>
        </View>
      </View>

      {vehicleCount > 0 ? (
        <VehicleInfoTrigger
          accent={accent}
          count={vehicleCount}
          mutedColor={textMuted}
          textMain={textMain}
          onPress={onOpenVehicles}
        />
      ) : null}

      <View style={[styles.jobInfoList, { borderColor: `${accent}22`, backgroundColor: isLight ? lightMistPanel : undefined }]}>
        {etaLabel && (status === 'en_route' || status === 'confirmed' || status === 'scheduled') ? (
          <JobDetailRow accent={accent} icon="navigate-outline" label="ETA" value={etaLabel} highlight textMain={textMain} textMuted={textMuted} />
        ) : null}
        {job.location_address ? (
          <JobDetailRow accent={accent} icon="location-outline" label="Location" value={job.location_address} textMain={textMain} textMuted={textMuted} />
        ) : null}
        <JobDetailRow accent={moneyColor} icon="wallet-outline" label="Price" value={priceLabel} highlight textMain={textMain} textMuted={textMuted} />
        {scheduledLabel ? (
          <JobDetailRow accent={accent} icon="calendar-outline" label="Scheduled" value={scheduledLabel} textMain={textMain} textMuted={textMuted} />
        ) : null}
      </View>

      <View style={styles.jobInfoQuickActions}>
        <TouchableOpacity
          onPress={async () => {
            if (chatLocked) {
              await hapticFeedback('warning');
              return;
            }
            await hapticFeedback('light');
            onChat();
          }}
          disabled={chatLocked}
          style={[
            styles.jobInfoQuickBtn,
            {
              borderColor: chatLocked ? 'rgba(148,163,184,0.35)' : `${accent}45`,
              backgroundColor: isLight ? lightMistElevated : undefined,
              opacity: chatLocked ? 0.7 : 1,
            },
          ]}
          activeOpacity={0.85}
          accessibilityState={{ disabled: chatLocked }}
        >
          <Ionicons
            name={chatLocked ? 'lock-closed' : 'lock-open'}
            size={18}
            color={chatLocked ? textMuted : '#34D399'}
          />
          <Text style={[styles.jobInfoQuickBtnText, { color: chatLocked ? textMuted : accent }]}>
            {chatLocked ? 'After payment' : 'Message'}
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={handleDirections}
          style={[styles.jobInfoQuickBtn, styles.jobInfoQuickBtnPrimary, { backgroundColor: `${accent}20`, borderColor: `${accent}50` }]}
          activeOpacity={0.85}
        >
          <Ionicons name="navigate-outline" size={18} color={accent} />
          <Text style={[styles.jobInfoQuickBtnText, { color: accent }]}>Directions</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

/** Vehicles for the gallery: the booking's own list, else its summary line, else the single car on the job row. */
function galleryVehiclesFor(
  bookingVehicles: BookingVehicleItem[],
  vehicleDetails: ValeterJobTrackingSheetProps['vehicleDetails'],
  job: ValeterJobTrackingSheetProps['job']
): BookingVehicleItem[] {
  if (bookingVehicles.length > 0) return bookingVehicles;
  const jobInfo = typeof job.vehicle_info === 'string' ? job.vehicle_info.trim() : '';
  const summary = vehicleDetails?.summaryLine || jobInfo;
  if (summary) {
    return summary
      .split('·')
      .map((s) => s.trim())
      .filter(Boolean)
      .map((label, i) => ({ id: `fallback-${i}`, make: label }));
  }
  const car = {
    id: 'fallback-0',
    make: vehicleDetails?.make ?? job.vehicle_make ?? undefined,
    model: vehicleDetails?.model ?? job.vehicle_model ?? undefined,
    registration: vehicleDetails?.registration ?? job.vehicle_registration ?? undefined,
    colour: vehicleDetails?.colour ?? undefined,
    photo: vehicleDetails?.photo ?? job.vehicle_photo ?? null,
  };
  return car.make || car.model || car.registration || car.photo ? [car] : [];
}

type AccountTheme = ReturnType<typeof useAccountTheme>['theme'];

function sheetPalette(theme: AccountTheme, isLight: boolean, accent: string) {
  return {
    textMain: theme.textPrimary ?? '#F1F5F9',
    textMuted: theme.textSecondary ?? 'rgba(241,245,249,0.65)',
    cardBorder: isLight ? (theme.glassBorder ?? `${accent}40`) : 'rgba(148,163,184,0.2)',
    chipBg: isLight ? lightMistElevated : 'rgba(255,255,255,0.06)',
    trackColor: isLight ? 'rgba(15,23,42,0.1)' : 'rgba(148,163,184,0.18)',
  };
}

function sheetContainerStyle(embedded: boolean, accent: string, dragOffset: Animated.Value, bottomPad: number) {
  if (embedded) {
    return [styles.containerEmbedded, { borderColor: 'transparent', transform: undefined, paddingBottom: bottomPad }];
  }
  return [styles.container, { borderColor: `${accent}35`, transform: [{ translateY: dragOffset }], paddingBottom: bottomPad }];
}

function nextCardSize(s: { w: number; h: number }, w: number, h: number) {
  return Math.abs(s.w - w) > 0.5 || Math.abs(s.h - h) > 0.5 ? { w, h } : s;
}

function handleSheetLayout(
  h: number,
  opts: Readonly<{
    embedded: boolean;
    sheetHeight: number;
    bottomPad: number;
    onMeasuredHeight?: (totalHeight: number) => void;
    setContentHeight: (height: number) => void;
  }>
) {
  if (h <= 0) return;
  opts.onMeasuredHeight?.(h);
  if (!opts.embedded && Math.abs(h - opts.sheetHeight) > 4) {
    opts.setContentHeight(h - opts.bottomPad);
  }
}

function dragMove(g: PanResponderGestureState, embedded: boolean, dragOffset: Animated.Value) {
  if (embedded) return;
  if (g.dy > 0) dragOffset.setValue(Math.min(g.dy, MAX_PEEK_DRAG));
}

function dragRelease(
  g: PanResponderGestureState,
  embedded: boolean,
  dragOffset: Animated.Value,
  sheetHeight: number,
  onClose: () => void
) {
  if (embedded) return;
  const shouldClose = g.dy > DRAG_CLOSE_THRESHOLD || (g.dy > 30 && g.vy > DRAG_VELOCITY_THRESHOLD);
  if (shouldClose) {
    Animated.timing(dragOffset, { toValue: sheetHeight, duration: 220, useNativeDriver: true }).start(() =>
      onClose()
    );
  } else {
    Animated.spring(dragOffset, { toValue: 0, useNativeDriver: true, damping: 25, stiffness: 300 }).start();
  }
}

/** Drag-to-dismiss for the floating sheet; embedded sheets get no pan handlers. */
function useSheetDrag(embedded: boolean, onClose: () => void, sheetHeight: number) {
  const dragOffset = useRef(new Animated.Value(0)).current;
  const panResponder = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => !embedded,
        onMoveShouldSetPanResponder: (_, g) => !embedded && Math.abs(g.dy) > 5,
        onPanResponderMove: (_, g) => dragMove(g, embedded, dragOffset),
        onPanResponderRelease: (_, g) => dragRelease(g, embedded, dragOffset, sheetHeight, onClose),
      }),
    [dragOffset, embedded, onClose, sheetHeight]
  );
  const panelPanHandlers: GestureResponderHandlers | Record<string, never> = embedded ? {} : panResponder.panHandlers;
  return { dragOffset, panelPanHandlers };
}

function SheetTopActions({
  chipBg,
  textMuted,
  onClose,
}: Readonly<{ chipBg: string; textMuted: string; onClose: () => void }>) {
  return (
    <View style={styles.topActions}>
      <View style={{ width: 1 }} />
      <TouchableOpacity
        onPress={() => {
          void hapticFeedback('light');
          onClose();
        }}
        style={[styles.collapseBtn, { backgroundColor: chipBg }]}
      >
        <Ionicons name="chevron-down" size={18} color={textMuted} />
        <Text style={[styles.collapseText, { color: textMuted }]}>Jobs list</Text>
      </TouchableOpacity>
    </View>
  );
}

function TrackingPanel({
  embedded,
  accent,
  panelPanHandlers,
  fadeAnim,
  children,
}: Readonly<{
  embedded: boolean;
  accent: string;
  panelPanHandlers: GestureResponderHandlers | Record<string, never>;
  fadeAnim: Animated.Value;
  children: React.ReactNode;
}>) {
  return (
    <View style={styles.panel} {...panelPanHandlers}>
      {embedded ? null : <View style={[styles.handle, { backgroundColor: `${accent}55` }]} />}

      <Animated.View style={[styles.body, embedded && styles.bodyEmbedded, { opacity: fadeAnim }]}>
        {children}
      </Animated.View>
    </View>
  );
}

function TrackingCardHead({
  status,
  serviceLabel,
  statusMessage,
  strip,
  hero,
  timerTone,
  textMain,
  textMuted,
}: Readonly<{
  status: ValeterTrackingStatus;
  serviceLabel: string;
  statusMessage: string;
  strip: StripInfo | null;
  hero: HeroMetric;
  timerTone: string;
  textMain: string;
  textMuted: string;
}>) {
  const kickerTone = DONE_GREEN;
  return (
    <View style={styles.heroRow}>
      <View style={styles.cardBody}>
        <View style={styles.heroKickerRow}>
          <LiveDot color={kickerTone} />
          <Text style={[styles.heroKickerLive, { color: kickerTone }]}>
            {status === 'completed' ? 'DONE' : 'LIVE'}
          </Text>
          <Text style={[styles.cardService, { color: textMuted }]} numberOfLines={1}>
            · {serviceLabel}
          </Text>
        </View>
        <Reanimated.View
          key={`status-${statusMessage}`}
          entering={FadeInDown.duration(420).easing(Easing.out(Easing.cubic))}
        >
          <Text style={[styles.cardStatus, { color: textMain }]} numberOfLines={2}>
            {statusMessage}
          </Text>
        </Reanimated.View>
        {strip?.sub ? (
          <Reanimated.View key={`note-${strip.sub}`} entering={FadeIn.duration(260)} style={styles.headNote}>
            <Ionicons
              name={status === 'pending_payment' ? 'lock-closed' : strip.icon}
              size={11}
              color={textMuted}
            />
            <Text style={[styles.headNoteText, { color: textMuted }]} numberOfLines={1}>
              {strip.sub}
            </Text>
          </Reanimated.View>
        ) : null}
      </View>
      <Reanimated.View key={`metric-${status}`} entering={FadeIn.duration(420)} style={styles.metricCol}>
        <View style={styles.metricRow}>
          <Reanimated.Text
            key={`m-${hero.value}`}
            entering={FadeInUp.duration(260)}
            style={[styles.metricValue, { color: timerTone }]}
            numberOfLines={1}
            adjustsFontSizeToFit
          >
            {hero.value}
          </Reanimated.Text>
          {hero.unit ? <Text style={[styles.metricUnit, { color: timerTone }]}>{hero.unit}</Text> : null}
        </View>
        {hero.caption ? (
          <Text style={[styles.metricHint, { color: textMuted }]} numberOfLines={1}>
            {hero.caption}
          </Text>
        ) : null}
      </Reanimated.View>
    </View>
  );
}

function TrackingCard({
  notched,
  cardSize,
  onCardLayout,
  sheetGradient,
  cardBorder,
  hero,
  timerTone,
  trackColor,
  strip,
  stages,
  accent,
  textMain,
  textMuted,
  isLight,
  children,
}: Readonly<{
  notched: boolean;
  cardSize: { w: number; h: number };
  onCardLayout: (e: LayoutChangeEvent) => void;
  sheetGradient: readonly [string, string];
  cardBorder: string;
  hero: HeroMetric;
  timerTone: string;
  trackColor: string;
  strip: StripInfo | null;
  stages: StageItem[];
  accent: string;
  textMain: string;
  textMuted: string;
  isLight: boolean;
  children: React.ReactNode;
}>) {
  return (
    <View style={[styles.trackingCard, notched && styles.trackingCardNotched]} onLayout={onCardLayout}>
      <TrackingCardShape
        width={cardSize.w}
        height={cardSize.h}
        notched={notched}
        gradient={sheetGradient}
        border={cardBorder}
      />
      {children}

      <HeroProgress progress={hero.progress} color={timerTone} track={trackColor} />

      {strip ? (
        <StageStrip strip={strip} textMain={textMain} />
      ) : null}

      {notched ? (
        <View style={styles.hillInCard}>
          <HillRoadStepper stages={stages} textMain={textMain} mutedColor={textMuted} isLight={isLight} clear={4} compact />
        </View>
      ) : (
      <TrackingStepper
        stages={stages}
        accent={accent}
        textMain={textMain}
        mutedColor={textMuted}
        isLight={isLight}
      />
      )}
    </View>
  );
}

export default function ValeterJobTrackingSheet({
  accent,
  sheetGradient = HEADER_STYLE_CARD_GRADIENT,
  job,
  status,
  statusMessage,
  customerName,
  vehicleDetails,
  bookingVehicles = [],
  etaMinutes,
  distanceMi,
  stages,
  stageProgressPercent,
  onChat,
  onClose,
  infoSheetVisible,
  onCloseInfo,
  onMeasuredHeight,
  embedded = false,
  paymentSecondsLeft = null,
  earned = null,
  isPreview = false,
}: ValeterJobTrackingSheetProps) {
  const insets = useSafeAreaInsets();
  const { theme, mode } = useAccountTheme();
  const isLight = mode === 'light';
  const { textMain, textMuted, cardBorder, chipBg, trackColor } = sheetPalette(theme, isLight, accent);
  /** Keep a light inset only — parent sheet already sits on the home indicator. */
  const bottomPad = embedded ? 0 : Math.max(insets.bottom, 8);
  const [contentHeight, setContentHeight] = useState(VALETER_TRACKING_SHEET_CONTENT_ESTIMATE);
  const [vehiclesSheetVisible, setVehiclesSheetVisible] = useState(false);
  const sheetHeight = contentHeight + bottomPad;
  const journey = useMemo(
    () =>
      bookingJourney({
        serviceType: job.service_type,
        serviceName: job.service_name,
        washType: job.wash_type ?? null,
        addOnIds: job.add_on_ids,
      }),
    [job.service_type, job.service_name, job.wash_type, job.add_on_ids]
  );
  const wash = useWashLive(journey, {
    jobId: job.id,
    updatedAt: job.updated_at,
    isPreview,
    active: status === 'in_progress',
  });
  const paySecs = useCountdown(status === 'pending_payment' ? paymentSecondsLeft : null);
  const hero = heroMetricFor({ status, accent, paySecs, etaMinutes, distanceMi, wash, earned, stageProgressPercent });
  const strip = stageStripFor(status, firstName(customerName), earned, paySecs);
  /** Brand yellow for the headline number; the payment countdown still turns red in its last minute. */
  const timerTone = hero.tone === PAY_RED ? PAY_RED : BRAND_YELLOW;
  const [cardSize, setCardSize] = useState({ w: 0, h: 0 });
  /** Embedded = sitting on the nav dock, so the card notches round its hump. */
  const notched = embedded;
  /** On the drive the card steps aside: only the steps road over the nav bar stays, so the map is clear. */
  const roadOnly = embedded && status === 'en_route';
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const { dragOffset, panelPanHandlers } = useSheetDrag(embedded, onClose, sheetHeight);

  const galleryVehicles = useMemo(
    () => galleryVehiclesFor(bookingVehicles, vehicleDetails, job),
    [bookingVehicles, vehicleDetails, job]
  );

  const openVehicles = () => setVehiclesSheetVisible(true);

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 400, useNativeDriver: true }).start();
  }, [fadeAnim]);

  const serviceLabel = journey.packageName || getServiceDisplayName(job.service_type, job.service_name);
  const onSheetLayout = (e: LayoutChangeEvent) =>
    handleSheetLayout(e.nativeEvent.layout.height, {
      embedded,
      sheetHeight,
      bottomPad,
      onMeasuredHeight,
      setContentHeight,
    });
  const onCardLayout = (e: LayoutChangeEvent) => {
    const { width: w, height: h } = e.nativeEvent.layout;
    setCardSize((s) => nextCardSize(s, w, h));
  };

  return (
    <>
      <Animated.View
        pointerEvents={roadOnly ? 'box-none' : 'auto'}
        style={sheetContainerStyle(embedded, accent, dragOffset, bottomPad)}
        onLayout={onSheetLayout}
      >
        {embedded ? null : <ValeterDashboardChrome accent={accent} headerGradient={sheetGradient} />}

        {embedded ? null : <SheetTopActions chipBg={chipBg} textMuted={textMuted} onClose={onClose} />}

        {roadOnly ? (
          <HillRoadStepper stages={stages} textMain={textMain} mutedColor={textMuted} isLight={isLight} scale={1.5} />
        ) : (
          <TrackingPanel embedded={embedded} accent={accent} panelPanHandlers={panelPanHandlers} fadeAnim={fadeAnim}>
            <TrackingCard
              notched={notched}
              cardSize={cardSize}
              onCardLayout={onCardLayout}
              sheetGradient={sheetGradient}
              cardBorder={cardBorder}
              hero={hero}
              timerTone={timerTone}
              trackColor={trackColor}
              strip={strip}
              stages={stages}
              accent={accent}
              textMain={textMain}
              textMuted={textMuted}
              isLight={isLight}
            >
              <TrackingCardHead
                status={status}
                serviceLabel={serviceLabel}
                statusMessage={statusMessage}
                strip={strip}
                hero={hero}
                timerTone={timerTone}
                textMain={textMain}
                textMuted={textMuted}
              />
            </TrackingCard>
          </TrackingPanel>
        )}
      </Animated.View>

      <InfoBottomSheet
        visible={infoSheetVisible}
        onClose={onCloseInfo}
        title="Job details"
        accentColor={accent}
        variant="header"
        contentMaxHeight="72%"
      >
        <JobDetailsContent
          accent={accent}
          customerName={customerName}
          job={job}
          status={status}
          statusMessage={statusMessage}
          bookingVehicles={galleryVehicles}
          etaMinutes={etaMinutes}
          distanceMi={distanceMi}
          onChat={onChat}
          onOpenVehicles={openVehicles}
        />
      </InfoBottomSheet>

      <BookingVehiclesInfoSheet
        visible={vehiclesSheetVisible}
        onClose={() => setVehiclesSheetVisible(false)}
        accent={accent}
        vehicles={galleryVehicles}
      />

    </>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderWidth: 1,
    overflow: 'hidden',
    zIndex: 45,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -8 },
    shadowOpacity: 0.35,
    shadowRadius: 20,
    elevation: 30,
  },
  containerEmbedded: {
    flexGrow: 0,
    flexShrink: 0,
    width: '100%',
    overflow: 'hidden',
    backgroundColor: 'transparent',
    justifyContent: 'flex-start',
  },
  topActions: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingTop: 4,
    paddingBottom: 0,
  },
  collapseBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  collapseText: {
    color: 'rgba(249,250,251,0.55)',
    fontSize: 12,
    fontWeight: '700',
  },
  panel: {
    paddingHorizontal: 16,
  },
  handle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    alignSelf: 'center',
    marginBottom: 4,
  },
  body: {
    gap: 4,
  },
  bodyEmbedded: {
    paddingTop: 0,
    paddingBottom: 0,
  },
  trackingCard: {
    paddingHorizontal: 16,
    paddingTop: 14,
    paddingBottom: 10,
    position: 'relative',
    gap: 10,
  },
  /** The steps road fills the bottom of the card and arches up over the notch. */
  trackingCardNotched: {
    paddingBottom: 0,
  },
  hillInCard: { marginHorizontal: -16, marginTop: -6, zIndex: 1 },
  heroRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 12,
    zIndex: 1,
  },
  heroTrack: { height: 3, borderRadius: 1.5, overflow: 'hidden', zIndex: 1 },
  heroFill: { height: '100%', borderRadius: 1.5 },
  strip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    zIndex: 1,
  },
  stripIcon: { width: 24, height: 24, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  stripCopy: { flex: 1, minWidth: 0, flexDirection: 'row', alignItems: 'baseline', gap: 6 },
  stripTitle: { flexShrink: 0, maxWidth: '60%', fontSize: 13.5, fontWeight: '800', letterSpacing: -0.2 },
  stepperWrap: {
    zIndex: 1,
  },
  road: { height: ROAD_H, justifyContent: 'center' },
  roadStrip: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: ROAD_H / 2 - ROAD_STRIP / 2,
    height: ROAD_STRIP,
    borderRadius: ROAD_STRIP / 2,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(255,255,255,0.14)',
    overflow: 'hidden',
  },
  roadFill: { position: 'absolute', left: 0, top: 0, bottom: 0 },
  roadDashes: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    paddingHorizontal: 8,
  },
  roadDash: { width: 7, height: 1.5, borderRadius: 1, backgroundColor: 'rgba(241,245,249,0.3)' },
  van: {
    position: 'absolute',
    left: 0,
    top: ROAD_H / 2 - VAN_H / 2,
    width: VAN_W,
    height: VAN_H,
    alignItems: 'center',
    justifyContent: 'center',
  },
  vanHalo: {
    position: 'absolute',
    left: 0,
    top: ROAD_H / 2 - VAN_W / 2,
    width: VAN_W,
    height: VAN_W,
    borderRadius: VAN_W / 2,
  },
  vanBeam: {
    position: 'absolute',
    left: VAN_W - 4,
    width: 22,
    height: VAN_H * 0.7,
    borderTopRightRadius: VAN_H,
    borderBottomRightRadius: VAN_H,
  },
  vanShadow: {
    position: 'absolute',
    width: VAN_W * 0.9,
    height: VAN_H * 0.75,
    borderRadius: VAN_H * 0.3,
    backgroundColor: 'rgba(0,0,0,0.4)',
    transform: [{ translateY: 3 }],
  },
  vanImage: { width: '100%', height: '100%' },
  puff: {
    position: 'absolute',
    left: 0,
    top: ROAD_H / 2 - 4,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(226,232,240,0.55)',
  },
  roadLabels: { height: 18, marginTop: 1 },
  roadLabelSlot: { position: 'absolute', top: 0, width: LABEL_W, alignItems: 'center' },
  roadLabel: { fontSize: 9.5, fontWeight: '700', opacity: 0.7, paddingHorizontal: 6, paddingVertical: 1.5 },
  roadLabelCurrent: {
    fontSize: 10,
    fontWeight: '900',
    opacity: 1,
    borderRadius: 8,
    borderWidth: 1,
    overflow: 'hidden',
  },
  roadStop: {
    position: 'absolute',
    alignItems: 'center',
    justifyContent: 'center',
  },
  roadStopDone: {
    top: ROAD_H / 2 - STOP / 2,
    width: STOP,
    height: STOP,
    borderRadius: STOP / 2,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
  },
  roadStopFlag: {
    top: ROAD_H / 2 - (STOP + 2) / 2,
    width: STOP + 2,
    height: STOP + 2,
    borderRadius: (STOP + 2) / 2,
    borderWidth: 1.5,
    borderColor: 'rgba(226,232,240,0.5)',
    backgroundColor: 'rgba(2,6,23,0.75)',
  },
  roadStopTodo: {
    top: ROAD_H / 2 - 4,
    width: 8,
    height: 8,
    borderRadius: 4,
    borderWidth: 1.5,
    borderColor: 'rgba(203,213,225,0.6)',
    backgroundColor: 'rgba(2,6,23,0.6)',
  },
  liveDotWrap: { width: 10, height: 10, alignItems: 'center', justifyContent: 'center' },
  liveDot: { width: 7, height: 7, borderRadius: 4 },
  liveDotRing: { position: 'absolute', width: 7, height: 7, borderRadius: 4 },
  heroKickerRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 5 },
  heroKickerLive: { fontSize: 10.5, fontWeight: '900', letterSpacing: 1.2 },
  metricCol: { alignItems: 'flex-end', maxWidth: '46%' },
  metricRow: { flexDirection: 'row', alignItems: 'baseline', gap: 3 },
  metricValue: { fontSize: 26, fontWeight: '800', fontVariant: ['tabular-nums'], letterSpacing: -1 },
  metricUnit: { fontSize: 13, fontWeight: '800', opacity: 0.85 },
  metricHint: { fontSize: 11.5, fontWeight: '700', marginTop: -2 },
  cardBody: { flex: 1, minWidth: 0 },
  cardService: {
    flexShrink: 1,
    fontSize: 10,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 1.2,
  },
  headNote: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 4 },
  headNoteText: { fontSize: 12, fontWeight: '600', flexShrink: 1 },
  cardStatus: { fontSize: 17, fontWeight: '800', letterSpacing: -0.3, lineHeight: 22 },
  jobInfoProfile: { paddingBottom: 8 },
  jobInfoHero: {
    alignItems: 'center',
    paddingVertical: 12,
    marginBottom: 14,
  },
  jobInfoAvatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
    backgroundColor: 'rgba(255,255,255,0.04)',
  },
  jobInfoProfileName: { color: '#F9FAFB', fontSize: 18, fontWeight: '800' },
  jobInfoProfileHeadline: { fontSize: 13, fontWeight: '700', marginTop: 2, textAlign: 'center' },
  jobInfoStatusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 10,
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 999,
    borderWidth: 1,
  },
  jobInfoStatusDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
  },
  jobInfoStatusText: {
    fontSize: 12,
    fontWeight: '700',
  },
  vehicleInfoTrigger: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginTop: 10,
    marginBottom: 2,
    paddingVertical: 10,
    paddingHorizontal: 10,
    borderRadius: 14,
    borderWidth: 1,
    zIndex: 1,
  },
  vehicleInfoIconWrap: {
    width: 34,
    height: 34,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  vehicleInfoCopy: { flex: 1, minWidth: 0 },
  vehicleInfoTitle: { fontSize: 14, fontWeight: '800' },
  vehicleInfoSub: { fontSize: 12, fontWeight: '600', marginTop: 1 },
  jobInfoList: {
    borderRadius: 16,
    borderWidth: 1,
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.03)',
    marginBottom: 14,
    padding: 6,
    gap: 4,
  },
  jobDetailRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    paddingHorizontal: 10,
    paddingVertical: 10,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.02)',
  },
  jobDetailRowIcon: {
    width: 34,
    height: 34,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 1,
  },
  jobDetailRowBody: { flex: 1, minWidth: 0 },
  jobDetailRowLabel: {
    color: 'rgba(148,163,184,0.9)',
    fontSize: 10,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 0.8,
    marginBottom: 3,
  },
  jobDetailRowValue: {
    color: '#E2E8F0',
    fontSize: 14,
    lineHeight: 20,
    fontWeight: '600',
  },
  jobInfoQuickActions: {
    flexDirection: 'row',
    gap: 10,
  },
  jobInfoQuickBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 12,
    borderRadius: 14,
    borderWidth: 1,
    backgroundColor: 'rgba(255,255,255,0.04)',
  },
  jobInfoQuickBtnPrimary: {},
  jobInfoQuickBtnText: {
    fontSize: 14,
    fontWeight: '700',
  },
});
