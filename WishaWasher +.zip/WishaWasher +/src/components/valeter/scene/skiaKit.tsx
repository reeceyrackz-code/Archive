import React from 'react';
import {
  BlurMask,
  Circle,
  FractalNoise,
  Group,
  LinearGradient,
  Oval,
  Path,
  RadialGradient,
  Rect,
  RoundedRect,
  rect,
  useClock,
  vec,
} from '@shopify/react-native-skia';
import { useDerivedValue } from 'react-native-reanimated';

/**
 * GPU-drawn pieces of the job world at dusk, shared by every scene: textured ground, lit houses, wet roads,
 * lamp light and the atmosphere that sits over the top.
 */

export type Pt = Readonly<{ x: number; y: number }>;

const WARM_LIGHT = 'rgba(255,226,170,';

/** Grain laid over a surface so it reads as a material rather than a flat colour. */
function Grain({ x, y, w, h, freq, opacity }: Readonly<{ x: number; y: number; w: number; h: number; freq: number; opacity: number }>) {
  return (
    <Rect x={x} y={y} width={w} height={h} opacity={opacity} blendMode="overlay">
      <FractalNoise freqX={freq} freqY={freq} octaves={4} />
    </Rect>
  );
}

export function SkLawn({ x, y, w, h }: Readonly<{ x: number; y: number; w: number; h: number }>) {
  const stripes = Math.ceil(w / 28);
  return (
    <Group clip={rect(x, y, w, h)}>
      <Rect x={x} y={y} width={w} height={h}>
        <LinearGradient start={vec(x, y)} end={vec(x + w * 0.3, y + h)} colors={['#3A7A5C', '#2A5E46', '#24513D']} />
      </Rect>
      {Array.from({ length: stripes }, (_, i) =>
        i % 2 ? <Rect key={i} x={x + i * 28} y={y} width={14} height={h} color="rgba(190,255,215,0.06)" /> : null
      )}
      <Grain x={x} y={y} w={w} h={h} freq={0.9} opacity={0.16} />
    </Group>
  );
}

/** Concrete yard: pale, grainy, with expansion joints and the odd oil stain. */
export function SkConcrete({ x, y, w, h }: Readonly<{ x: number; y: number; w: number; h: number }>) {
  const cols = Math.ceil(w / 64);
  return (
    <Group clip={rect(x, y, w, h)}>
      <Rect x={x} y={y} width={w} height={h}>
        <LinearGradient start={vec(x, y)} end={vec(x + w, y + h)} colors={['#58647E', '#4C5770', '#465069']} />
      </Rect>
      <Grain x={x} y={y} w={w} h={h} freq={1.4} opacity={0.2} />
      {Array.from({ length: cols }, (_, i) => (
        <Rect key={i} x={x + (i + 1) * 64} y={y} width={1} height={h} color="rgba(15,22,38,0.35)" />
      ))}
      <Rect x={x} y={y + h / 2} width={w} height={1} color="rgba(15,22,38,0.3)" />
      <Oval x={x + w * 0.2} y={y + h * 0.58} width={34} height={20} color="rgba(10,14,26,0.28)">
        <BlurMask blur={5} style="normal" />
      </Oval>
      <Oval x={x + w * 0.66} y={y + h * 0.22} width={22} height={14} color="rgba(10,14,26,0.22)">
        <BlurMask blur={4} style="normal" />
      </Oval>
    </Group>
  );
}

/** Painted road / yard marking with a slightly worn edge. */
export function SkPaint({ x, y, w, h, color = 'rgba(244,247,252,0.85)' }: Readonly<{ x: number; y: number; w: number; h: number; color?: string }>) {
  return (
    <RoundedRect x={x} y={y} width={w} height={h} r={Math.min(w, h) / 2} color={color}>
      <BlurMask blur={0.6} style="solid" />
    </RoundedRect>
  );
}

/** Hip roof: soft shadow, shaded slopes, tile courses, ridge highlight, chimney and warm skylights. */
export function SkRoof({ x, y, w, h, lit = true }: Readonly<{ x: number; y: number; w: number; h: number; lit?: boolean }>) {
  const r = Math.min(w, h) / 2;
  const p = (pts: number[][]) => 'M ' + pts.map(([px, py]) => `${x + px} ${y + py}`).join(' L ') + ' Z';
  const courses = Math.floor(h / 9);
  return (
    <Group>
      <Path path={p([[0, 0], [w, 0], [w, h], [0, h]])} color="rgba(5,10,25,0.55)" transform={[{ translateX: 8 }, { translateY: 12 }]}>
        <BlurMask blur={16} style="normal" />
      </Path>
      <Path path={p([[0, 0], [w, 0], [w - r, r], [r, r]])}>
        <LinearGradient start={vec(x, y)} end={vec(x, y + r)} colors={['#7E90B4', '#6A7CA0']} />
      </Path>
      <Path path={p([[0, h], [w, h], [w - r, h - r], [r, h - r]])}>
        <LinearGradient start={vec(x, y + h - r)} end={vec(x, y + h)} colors={['#4C5A7C', '#3F4B6A']} />
      </Path>
      <Path path={p([[0, 0], [r, r], [r, h - r], [0, h]])} color="#5E6F92" />
      <Path path={p([[w, 0], [w - r, r], [w - r, h - r], [w, h]])} color="#56668A" />
      <Group opacity={0.18}>
        {Array.from({ length: courses }, (_, i) => (
          <Rect key={i} x={x} y={y + (i + 1) * 9} width={w} height={1} color="#0B1222" />
        ))}
      </Group>
      <Rect x={x + r} y={y + r - 1} width={Math.max(0, w - 2 * r)} height={2} color="rgba(255,255,255,0.35)" />
      <RoundedRect x={x + w * 0.7} y={y + h * 0.16} width={16} height={13} r={3} color="#8A99B6" />
      {lit
        ? [0.22, 0.4].map((f) => (
            <Group key={f}>
              <RoundedRect x={x + w * f} y={y + h * 0.64} width={20} height={13} r={3} color="rgba(255,214,150,0.55)">
                <BlurMask blur={8} style="outer" />
              </RoundedRect>
              <RoundedRect x={x + w * f} y={y + h * 0.64} width={20} height={13} r={3} color="#FFE2AE" />
            </Group>
          ))
        : null}
    </Group>
  );
}

/** Flat commercial roof: membrane, a field of solar panels catching the sky, vents and a lit roller door. */
export function SkFlatRoof({ x, y, w, h }: Readonly<{ x: number; y: number; w: number; h: number }>) {
  const cols = Math.max(4, Math.floor((w * 0.66) / 30));
  const panelW = 26;
  const panelH = 18;
  const gridY = y + h / 2 - panelH - 3;
  return (
    <Group>
      <RoundedRect x={x + 6} y={y + 12} width={w} height={h} r={10} color="rgba(5,10,25,0.55)">
        <BlurMask blur={16} style="normal" />
      </RoundedRect>
      <RoundedRect x={x} y={y} width={w} height={h} r={10}>
        <LinearGradient start={vec(x, y)} end={vec(x, y + h)} colors={['#76839F', '#5E6B88']} />
      </RoundedRect>
      <Grain x={x} y={y} w={w} h={h} freq={1.2} opacity={0.16} />
      <RoundedRect x={x + 3} y={y + 3} width={w - 6} height={h - 6} r={8} color="rgba(255,255,255,0.1)" style="stroke" strokeWidth={1.5} />
      {[0, 1].map((r) =>
        Array.from({ length: cols }, (_, c) => {
          const px = x + 16 + c * (panelW + 4);
          const py = gridY + r * (panelH + 6);
          return (
            <Group key={`${r}-${c}`}>
              <RoundedRect x={px} y={py} width={panelW} height={panelH} r={2.5}>
                <LinearGradient start={vec(px, py)} end={vec(px + panelW, py + panelH)} colors={['#3A5BA0', '#1C2F5E', '#253E7A']} />
              </RoundedRect>
              <Rect x={px} y={py + panelH / 2} width={panelW} height={0.8} color="rgba(160,200,255,0.4)" />
              <Rect x={px + panelW / 2} y={py} width={0.8} height={panelH} color="rgba(160,200,255,0.4)" />
              <Rect x={px + 2} y={py + 2} width={panelW * 0.35} height={2} color="rgba(255,255,255,0.35)" />
            </Group>
          );
        })
      )}
      {[0.22, 0.5].map((f) => (
        <Group key={f}>
          <Circle cx={x + w - 26} cy={y + h * f + 6} r={11} color="#8D9AB6" />
          <Circle cx={x + w - 26} cy={y + h * f + 6} r={6} color="#5E6B88" />
        </Group>
      ))}
      {[0.2, 0.46, 0.72].map((f, i) => (
        <Group key={f}>
          {i === 1 ? (
            <Rect x={x + w * f} y={y + h - 4} width={w * 0.2} height={14} color="rgba(255,214,150,0.45)">
              <BlurMask blur={10} style="normal" />
            </Rect>
          ) : null}
          <RoundedRect x={x + w * f} y={y + h - 7} width={w * 0.2} height={7} r={2} color={i === 1 ? '#FFE2AE' : '#8D9AB6'} />
        </Group>
      ))}
    </Group>
  );
}

/** Block paving drive with an edge course; wet sheen once it's been washed. */
export function SkDrive({ x, y, w, h, wet = false }: Readonly<{ x: number; y: number; w: number; h: number; wet?: boolean }>) {
  const rows = Math.floor(h / 12);
  const cols = Math.ceil(w / 22);
  return (
    <Group>
      <RoundedRect x={x - 3} y={y - 3} width={w + 6} height={h + 6} r={9} color="#3E4A63" />
      <RoundedRect x={x} y={y} width={w} height={h} r={7}>
        <LinearGradient start={vec(x, y)} end={vec(x + w, y + h)} colors={['#6C7A98', '#5A6886']} />
      </RoundedRect>
      <Group clip={rect(x, y, w, h)} opacity={0.22}>
        {Array.from({ length: rows }, (_, r) => (
          <Group key={r}>
            <Rect x={x} y={y + r * 12} width={w} height={1} color="#1C2436" />
            {Array.from({ length: cols }, (_, c) => (
              <Rect key={c} x={x + c * 22 + (r % 2 ? 11 : 0)} y={y + r * 12} width={1} height={12} color="#1C2436" />
            ))}
          </Group>
        ))}
      </Group>
      <Grain x={x} y={y} w={w} h={h} freq={1.6} opacity={0.12} />
      {wet ? (
        <RoundedRect x={x} y={y} width={w} height={h} r={7} blendMode="screen">
          <LinearGradient start={vec(x, y)} end={vec(x + w, y + h)} colors={['rgba(170,205,255,0.05)', 'rgba(170,205,255,0.28)', 'rgba(170,205,255,0.06)']} />
        </RoundedRect>
      ) : null}
    </Group>
  );
}

export function SkPavement({ w, top, height = 16 }: Readonly<{ w: number; top: number; height?: number }>) {
  const slabs = Math.ceil(w / 30);
  return (
    <Group>
      <Rect x={0} y={top} width={w} height={height} color="#56637E" />
      {Array.from({ length: slabs }, (_, i) => (
        <Rect key={i} x={i * 30} y={top} width={1} height={height} color="rgba(15,22,38,0.25)" />
      ))}
      <Grain x={0} y={top} w={w} h={height} freq={1.5} opacity={0.15} />
      <Rect x={0} y={top} width={w} height={1} color="rgba(255,255,255,0.18)" />
      <Rect x={0} y={top + height - 1} width={w} height={2} color="rgba(241,245,249,0.42)" />
    </Group>
  );
}

/** Asphalt with real grain, optional centre dashes, and the lamps' reflections streaking across it. */
export function SkRoad({
  w,
  top,
  height,
  dashes = true,
  lamps = [],
  wet = false,
}: Readonly<{ w: number; top: number; height: number; dashes?: boolean; lamps?: readonly number[]; wet?: boolean }>) {
  const n = Math.ceil(w / 46) + 1;
  return (
    <Group>
      <Rect x={0} y={top} width={w} height={height}>
        <LinearGradient start={vec(0, top)} end={vec(0, top + height)} colors={['#3B4762', '#323D56']} />
      </Rect>
      <Grain x={0} y={top} w={w} h={height} freq={1.6} opacity={0.24} />
      <Rect x={0} y={top + height - 2} width={w} height={2} color="rgba(241,245,249,0.32)" />
      {dashes
        ? Array.from({ length: n }, (_, i) => <SkPaint key={i} x={i * 46} y={top + height / 2 - 2} w={22} h={4} color="rgba(248,250,252,0.78)" />)
        : null}
      {lamps.map((lx) => (
        <Oval key={lx} x={lx - 14} y={top + 4} width={28} height={height * 0.85} color={`${WARM_LIGHT}${wet ? 0.45 : 0.24})`}>
          <BlurMask blur={10} style="normal" />
        </Oval>
      ))}
      {wet ? (
        <Oval x={w * 0.05} y={top + height * 0.3} width={w * 0.3} height={height * 0.35} color="rgba(160,200,255,0.12)">
          <BlurMask blur={8} style="normal" />
        </Oval>
      ) : null}
    </Group>
  );
}

export function SkFence({ x, top, bottom }: Readonly<{ x: number; top: number; bottom: number }>) {
  return (
    <Group>
      <Rect x={x + 2} y={top} width={3} height={bottom - top} color="rgba(5,10,25,0.3)">
        <BlurMask blur={2} style="normal" />
      </Rect>
      <Rect x={x - 1} y={top} width={3} height={bottom - top} color="#8A7458" />
      <Rect x={x - 1} y={top} width={1} height={bottom - top} color="rgba(255,230,190,0.35)" />
    </Group>
  );
}

/** Pool of warm light a street lamp throws on the ground. */
export function SkLampPool({ x, y, r = 95 }: Readonly<{ x: number; y: number; r?: number }>) {
  return (
    <Circle cx={x} cy={y} r={r} blendMode="screen">
      <RadialGradient c={vec(x, y)} r={r} colors={[`${WARM_LIGHT}0.32)`, `${WARM_LIGHT}0)`]} />
    </Circle>
  );
}

/** Soft glow under a car or van in the stage colour. */
export function SkGlow({ x, y, r, color, opacity = 0.22 }: Readonly<{ x: number; y: number; r: number; color: string; opacity?: number }>) {
  return (
    <Oval x={x - r} y={y - r} width={r * 2} height={r * 2} opacity={opacity}>
      <RadialGradient c={vec(x, y)} r={r} colors={[color, `${color}00`]} />
    </Oval>
  );
}

/** Canopy from above: a shadow cast on the ground, a bright crown and a soft edge. */
export function SkTree({ x, y, r }: Readonly<{ x: number; y: number; r: number }>) {
  return (
    <Group>
      <Circle cx={x + 8} cy={y + 10} r={r} color="rgba(5,12,20,0.42)">
        <BlurMask blur={10} style="normal" />
      </Circle>
      <Circle cx={x} cy={y} r={r}>
        <RadialGradient c={vec(x - r * 0.3, y - r * 0.35)} r={r * 1.3} colors={['#7FD9A6', '#3C8C62', '#1E5238']} />
        <BlurMask blur={1.5} style="normal" />
      </Circle>
      {[
        [-0.35, -0.2, 0.42],
        [0.3, -0.3, 0.36],
        [0.1, 0.35, 0.4],
      ].map(([dx, dy, s]) => (
        <Circle key={`${dx}${dy}`} cx={x + dx * r} cy={y + dy * r} r={r * s} color="rgba(200,255,220,0.12)" />
      ))}
    </Group>
  );
}

/** Over everything: lamp heads blooming, a slow breath of evening haze and a soft vignette. */
export function SkAtmosphere({ w, h, lamps }: Readonly<{ w: number; h: number; lamps: readonly Pt[] }>) {
  const clock = useClock();
  const haze = useDerivedValue(() => 0.05 + Math.sin(clock.value / 2600) * 0.02);
  return (
    <Group>
      {lamps.map((l) => (
        <Group key={`${l.x}-${l.y}`}>
          <Circle cx={l.x} cy={l.y} r={18} color="rgba(255,230,180,0.7)" blendMode="screen">
            <BlurMask blur={14} style="normal" />
          </Circle>
          <Circle cx={l.x} cy={l.y} r={4.5} color="#FFF6E0" />
        </Group>
      ))}
      <Rect x={0} y={0} width={w} height={h} opacity={haze}>
        <LinearGradient start={vec(0, 0)} end={vec(0, h)} colors={['#B9C8FF', '#B9C8FF00']} />
      </Rect>
      <Rect x={0} y={0} width={w} height={h}>
        <RadialGradient
          c={vec(w / 2, h * 0.5)}
          r={Math.max(w, h) * 0.75}
          colors={['rgba(10,16,32,0)', 'rgba(10,16,32,0)', 'rgba(10,16,32,0.42)']}
          positions={[0, 0.55, 1]}
        />
      </Rect>
    </Group>
  );
}
