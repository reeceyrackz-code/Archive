import React, { useEffect } from 'react';
import { StyleSheet, View } from 'react-native';
import Reanimated, { Easing, useAnimatedStyle, useSharedValue, withDelay, withSequence, withSpring, withTiming } from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { Canvas } from '@shopify/react-native-skia';
import { Burst, CAR_LEN, CAR_WIDE, Callout, CarSprite, EdgeFades, HitArea, Pulse, VAN_RATIO, VanSprite, useLoop, useTaps, type SceneProps } from './sceneKit';
import { SkAtmosphere, SkDrive, SkFence, SkGlow, SkLampPool, SkLawn, SkPavement, SkRoad, SkRoof, SkTree } from './skiaKit';

type Plot = Readonly<{ cx: number; plotW: number; roofY: number; roofH: number; driveTop: number; pavementTop: number }>;

/** A neighbour's (or the customer's) front: lawn, roof, and a driveway to the pavement. */
function House({ p, driveW, lit }: Readonly<{ p: Plot; driveW: number; lit: boolean }>) {
  const roofW = p.plotW * 0.74;
  return (
    <>
      <SkLawn x={p.cx - p.plotW / 2} y={0} w={p.plotW} h={p.pavementTop} />
      <SkRoof x={p.cx - roofW / 2 - p.plotW * 0.06} y={p.roofY} w={roofW} h={p.roofH} lit={lit} />
      <SkDrive x={p.cx + p.plotW * 0.08 - driveW / 2} y={p.driveTop} w={driveW} h={p.pavementTop - p.driveTop} />
    </>
  );
}

/**
 * On site: the customer's street. The van pulls up at the kerb outside their drive, a pin drops on their car
 * and the bay glows while the Pro takes the before photo.
 */
export default function StreetScene({ w, h, tone, first, carLabel }: SceneProps) {
  const vanW = Math.min(w * 0.34, h * 0.36);
  const vanH = vanW / VAN_RATIO;
  const roadH = Math.min(vanH * 2.6, h * 0.3);
  const roadTop = h - roadH;
  const pavementTop = roadTop - 16;
  const plotW = w * 0.62;
  const roofY = h * 0.03;
  const roofH = h * 0.24;
  const driveTop = roofY + roofH + 8;
  const carS = Math.min((pavementTop - driveTop - 14) / CAR_LEN, plotW * 0.6);
  const driveW = carS * CAR_WIDE * 1.55;
  const carX = w / 2 + plotW * 0.08;
  const carY = (driveTop + pavementTop) / 2;
  const laneY = roadTop + roadH * 0.27;
  const plot = (cx: number): Plot => ({ cx, plotW, roofY, roofH, driveTop, pavementTop });
  const [carTaps, tapCar] = useTaps();
  const [homeTaps, tapHome] = useTaps();

  const parkX = carX - vanW * 0.1;
  const x = useSharedValue(-vanW);
  const goal = useSharedValue(parkX);
  useEffect(() => {
    goal.value = parkX;
    x.value = withDelay(350, withTiming(parkX, { duration: 2600, easing: Easing.out(Easing.cubic) }));
  }, [parkX, x, goal]);

  const roofX = w / 2 - plotW * 0.06;
  const lamps = [
    { x: w * 0.12, y: pavementTop + 8 },
    { x: w * 0.9, y: pavementTop + 8 },
  ];

  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="box-none">
      <Canvas style={StyleSheet.absoluteFill} pointerEvents="none">
        <House p={plot(w / 2 - plotW)} driveW={driveW} lit={false} />
        <House p={plot(w / 2)} driveW={driveW} lit />
        <House p={plot(w / 2 + plotW)} driveW={driveW} lit={false} />
        <SkFence x={w / 2 - plotW / 2} top={0} bottom={pavementTop} />
        <SkFence x={w / 2 + plotW / 2} top={0} bottom={pavementTop} />
        <SkPavement w={w} top={pavementTop} />
        <SkRoad w={w} top={roadTop} height={roadH} lamps={lamps.map((l) => l.x)} />
        {lamps.map((l) => (
          <SkLampPool key={l.x} x={l.x} y={l.y} />
        ))}
        <SkGlow x={carX} y={carY} r={carS * 0.6} color={tone} opacity={0.26} />
        <SkTree x={w / 2 - plotW / 2} y={pavementTop - 30} r={33} />
        <SkTree x={w / 2 + plotW / 2} y={pavementTop - 26} r={29} />
      </Canvas>
      <View pointerEvents="none" style={StyleSheet.absoluteFill}>
        <Pulse x={carX} y={carY} d={carS * 0.95} tone={tone} />
      </View>

      <HitArea x={roofX} y={roofY + roofH / 2} w={plotW * 0.74} h={roofH} onPress={tapHome} label={`${first}'s home`} />
      <CarSprite x={carX} y={carY} s={carS} glow={tone} onPress={tapCar} />
      <Burst x={carX} y={carY} nonce={carTaps} kind="glint" spread={carS * 0.45} />
      <VanSprite x={x} goal={goal} y={laneY} w={vanW} />
      <PinDrop x={carX} y={carY - (carS * CAR_LEN) / 2 - 6} tone={tone} nonce={carTaps} />
      <Canvas style={StyleSheet.absoluteFill} pointerEvents="none">
        <SkAtmosphere w={w} h={h} lamps={lamps} />
      </Canvas>
      <EdgeFades w={w} />

      <Callout x={roofX} y={roofY + roofH * 0.45} nonce={homeTaps} tone={tone} text={`${first}'s home`} />
      <Callout x={carX} y={carY - (carS * CAR_LEN) / 2 - 40} nonce={carTaps} tone={tone} text={carLabel ?? `${first}'s car`} />
    </View>
  );
}

/** Map pin that drops onto the car once the van has pulled up, then bobs; tapping the car makes it hop. */
function PinDrop({ x, y, tone, nonce }: Readonly<{ x: number; y: number; tone: string; nonce: number }>) {
  const drop = useSharedValue(-60);
  const fade = useSharedValue(0);
  const bob = useLoop(1500, true, 3000);
  useEffect(() => {
    fade.value = withDelay(2600, withTiming(1, { duration: 250 }));
    drop.value = withDelay(2600, withSequence(withTiming(0, { duration: 380, easing: Easing.in(Easing.quad) }), withSpring(0, { damping: 6 })));
  }, [drop, fade]);
  useEffect(() => {
    if (nonce > 0) drop.value = withSequence(withTiming(-14, { duration: 140 }), withSpring(0, { damping: 5 }));
  }, [drop, nonce]);
  const style = useAnimatedStyle(() => ({ opacity: fade.value, transform: [{ translateY: drop.value - bob.value * 4 }] }));
  return (
    <Reanimated.View pointerEvents="none" style={[styles.pin, { left: x - 18, top: y - 36 }, style]}>
      <Ionicons name="location" size={36} color={tone} />
    </Reanimated.View>
  );
}

const styles = StyleSheet.create({
  pin: { position: 'absolute', width: 36, height: 36, shadowColor: '#0A1020', shadowOpacity: 0.5, shadowRadius: 6, shadowOffset: { width: 0, height: 4 } },
});
