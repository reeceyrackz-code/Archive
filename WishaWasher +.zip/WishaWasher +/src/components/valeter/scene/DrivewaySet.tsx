import React, { useEffect, type ReactNode } from 'react';
import { StyleSheet, View } from 'react-native';
import Reanimated, { Easing, ZoomIn, useSharedValue, withDelay, withTiming } from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { Burst, CAR_LEN, CAR_WIDE, Callout, CarSprite, EdgeFades, GREEN, VAN_RATIO, VanSprite, useTaps, type SceneProps } from './sceneKit';
import { DrivewayAtmosphere, DrivewayGround } from './SkiaDriveway';

export type CarBox = Readonly<{ x: number; y: number; len: number; wide: number; s: number }>;

export type DrivewayLayout = Readonly<{
  vanW: number;
  vanH: number;
  laneY: number;
  parkX: number;
  roadTop: number;
  pavementTop: number;
  driveTop: number;
  car: CarBox;
}>;

export function drivewayLayout(w: number, h: number): DrivewayLayout {
  const vanW = Math.min(w * 0.4, h * 0.42);
  const vanH = vanW / VAN_RATIO;
  const roadTop = h * 0.76;
  const pavementTop = roadTop - 16;
  const driveTop = -h * 0.08 + h * 0.3 + 8;
  const s = Math.min((pavementTop - driveTop - 14) / CAR_LEN, w * 0.62);
  return {
    vanW,
    vanH,
    laneY: roadTop + vanH * 0.8,
    parkX: w * 0.28,
    roadTop,
    pavementTop,
    driveTop,
    car: { x: w * 0.6, y: (driveTop + pavementTop) / 2, len: s * CAR_LEN, wide: s * CAR_WIDE, s },
  };
}

/**
 * Close on the customer's drive, shared by wash / detail / repair. The scene supplies what sits under and
 * over the car; this handles the house, the van (which heads off when the job's done) and car taps.
 */
export default function DrivewaySet({
  w,
  h,
  status,
  tone,
  first,
  carLabel,
  wet = false,
  burst,
  under,
  over,
  doneOver,
}: SceneProps &
  Readonly<{
    wet?: boolean;
    burst: 'bubble' | 'glint' | 'spark';
    under?: ReactNode;
    over: ReactNode;
    doneOver: ReactNode;
  }>) {
  const done = status === 'completed';
  const l = drivewayLayout(w, h);
  const { car } = l;
  const [taps, tap] = useTaps();

  const x = useSharedValue(l.parkX);
  const goal = useSharedValue(l.parkX);
  useEffect(() => {
    const target = done ? w + l.vanW : l.parkX;
    goal.value = target;
    x.value = withDelay(done ? 1400 : 0, withTiming(target, { duration: 2600, easing: Easing.in(Easing.cubic) }));
  }, [done, w, l.vanW, l.parkX, x, goal]);

  const glow = done ? GREEN : tone;

  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="box-none">
      <DrivewayGround w={w} h={h} l={l} wet={wet} glow={glow} />
      <View pointerEvents="none" style={StyleSheet.absoluteFill}>
        {under}
      </View>

      <CarSprite x={car.x} y={car.y} s={car.s} glow={glow} onPress={tap} />
      <View pointerEvents="none" style={StyleSheet.absoluteFill}>
        {done ? doneOver : over}
        <Burst x={car.x} y={car.y} nonce={taps} kind={done ? 'glint' : burst} spread={car.wide * 0.9} />
      </View>

      <VanSprite x={x} goal={goal} y={l.laneY} w={l.vanW} beams={done} />
      {done ? (
        <Reanimated.View pointerEvents="none" entering={ZoomIn.delay(500).springify().damping(11)} style={[styles.tick, { left: car.x - 20, top: car.y - 20 }]}>
          <Ionicons name="checkmark" size={24} color="#04121F" />
        </Reanimated.View>
      ) : null}
      <DrivewayAtmosphere w={w} h={h} l={l} />
      <EdgeFades w={w} />
      <Callout x={car.x} y={car.y - car.len / 2 - 4} nonce={taps} tone={glow} text={carLabel ?? `${first}'s car`} />
    </View>
  );
}

const styles = StyleSheet.create({
  tick: {
    position: 'absolute',
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: GREEN,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: GREEN,
    shadowOpacity: 0.8,
    shadowRadius: 14,
  },
});
