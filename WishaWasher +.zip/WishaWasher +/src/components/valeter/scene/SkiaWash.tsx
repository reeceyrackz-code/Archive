import React from 'react';
import { StyleSheet } from 'react-native';
import { BlurMask, Canvas, Circle, Group, Line, vec, useClock } from '@shopify/react-native-skia';
import { useDerivedValue, type SharedValue } from 'react-native-reanimated';
import type { CarBox } from './DrivewaySet';
import { scatter } from './sceneKit';

const PUFFS = scatter(14, 21);
const DROPS = scatter(10, 4);

/**
 * Wash effects on the GPU: soft foam clouds rolling slowly over the car and a fine spray of water from the
 * hose nozzle onto the bodywork.
 */
export default function SkiaWash({ car, nozzle }: Readonly<{ car: CarBox; nozzle: { x: number; y: number } }>) {
  const clock = useClock();
  return (
    <Canvas style={StyleSheet.absoluteFill} pointerEvents="none">
      <Group blendMode="screen">
        {PUFFS.map((p) => (
          <Puff key={p.i} clock={clock} car={car} dx={p.dx} dy={p.dy} i={p.i} />
        ))}
      </Group>
      <Group>
        {DROPS.map((p) => (
          <Drop key={p.i} clock={clock} from={nozzle} to={{ x: car.x - car.wide * 0.3 + p.dx * car.wide * 0.18, y: car.y + p.dy * car.len * 0.22 }} i={p.i} />
        ))}
      </Group>
      <Circle cx={nozzle.x} cy={nozzle.y} r={10} color="rgba(186,230,253,0.5)">
        <BlurMask blur={8} style="normal" />
      </Circle>
    </Canvas>
  );
}

function Puff({ clock, car, dx, dy, i }: Readonly<{ clock: SharedValue<number>; car: CarBox; dx: number; dy: number; i: number }>) {
  const r = 9 + ((i * 7) % 11);
  const period = 3800 + (i % 5) * 600;
  const cx = useDerivedValue(() => car.x + dx * car.wide * 0.5 + Math.sin(clock.value / 1400 + i) * 4);
  const cy = useDerivedValue(() => {
    const t = ((clock.value + i * 420) % period) / period;
    return car.y + dy * car.len * 0.44 - t * 14;
  });
  const opacity = useDerivedValue(() => {
    const t = ((clock.value + i * 420) % period) / period;
    return Math.sin(t * Math.PI) * 0.8;
  });
  return (
    <Circle cx={cx} cy={cy} r={r} color="rgba(240,248,255,0.85)" opacity={opacity}>
      <BlurMask blur={6} style="normal" />
    </Circle>
  );
}

/** One droplet streak travelling nozzle → car on a slight arc. */
function Drop({
  clock,
  from,
  to,
  i,
}: Readonly<{ clock: SharedValue<number>; from: { x: number; y: number }; to: { x: number; y: number }; i: number }>) {
  const period = 520;
  const t = useDerivedValue(() => ((clock.value + i * 53) % period) / period);
  const p1 = useDerivedValue(() => {
    const k = t.value;
    return vec(from.x + (to.x - from.x) * k, from.y + (to.y - from.y) * k - Math.sin(k * Math.PI) * 18);
  });
  const p2 = useDerivedValue(() => {
    const k = Math.max(0, t.value - 0.08);
    return vec(from.x + (to.x - from.x) * k, from.y + (to.y - from.y) * k - Math.sin(k * Math.PI) * 18);
  });
  const opacity = useDerivedValue(() => Math.sin(t.value * Math.PI) * 0.9);
  return (
    <Line p1={p1} p2={p2} color="rgba(200,235,255,0.95)" strokeWidth={2} strokeCap="round" opacity={opacity}>
      <BlurMask blur={1} style="solid" />
    </Line>
  );
}
