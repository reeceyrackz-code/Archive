import React, { useEffect, useReducer, useState } from 'react';
import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import Reanimated, {
  Easing,
  Extrapolation,
  FadeInDown,
  FadeOut,
  cancelAnimation,
  interpolate,
  useAnimatedReaction,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withRepeat,
  withSequence,
  withSpring,
  withTiming,
  type SharedValue,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { CAR_IMAGE, VALETER_VAN_IMAGE } from '../../../constants/appAssetExports';
import { hapticFeedback } from '../../../services/HapticFeedbackService';

/** Soft dusk: light enough to read at a glance, calm enough to sit behind the trip sheet. */
export const BG = '#1F2A40';
export const GREEN = '#34D399';
export const AMBER = '#FBBF24';
export const WARM = 'rgba(255,236,196,';
/** Van art is top-down facing right (width / height). */
export const VAN_RATIO = 288 / 145;
/** Car art is top-down facing up in a square; the body fills ~90% of its length and ~56% of its width. */
export const CAR_LEN = 0.9;
export const CAR_WIDE = 0.56;

export type JobKind = 'wash' | 'detail' | 'repair';

export type SceneProps = Readonly<{
  w: number;
  h: number;
  status: string | null;
  tone: string;
  accent: string;
  first: string;
  carLabel: string | null;
}>;

/** 0→1 forever; mirrored (with a soft ease) when `reverse`. */
export function useLoop(duration: number, reverse = false, delay = 0) {
  const t = useSharedValue(0);
  useEffect(() => {
    const easing = reverse ? Easing.inOut(Easing.sin) : Easing.linear;
    t.value = withDelay(delay, withRepeat(withTiming(1, { duration, easing }), -1, reverse));
    return () => cancelAnimation(t);
  }, [t, duration, reverse, delay]);
  return t;
}

/** A counter bumped on every tap; key one-shot effects off it. */
export function useTaps() {
  return useReducer((n: number) => n + 1, 0);
}

/* ───────────── interaction ───────────── */

/** Glass pill that pops up where you tapped and tucks itself away. */
export function Callout({ x, y, text, nonce, tone = '#F8FAFC' }: Readonly<{ x: number; y: number; text: string; nonce: number; tone?: string }>) {
  const [shown, setShown] = useState(nonce > 0);
  useEffect(() => {
    if (nonce === 0) return;
    setShown(true);
    const id = setTimeout(() => setShown(false), 1900);
    return () => clearTimeout(id);
  }, [nonce]);
  if (!shown) return null;
  return (
    <Reanimated.View
      key={nonce}
      pointerEvents="none"
      entering={FadeInDown.springify().damping(14)}
      exiting={FadeOut.duration(220)}
      style={[styles.callout, { left: x - 110, top: y - 34 }]}
    >
      <View style={styles.calloutPill}>
        <View style={[styles.calloutDot, { backgroundColor: tone }]} />
        <Text style={styles.calloutText} numberOfLines={1}>
          {text}
        </Text>
      </View>
    </Reanimated.View>
  );
}

/** An invisible hit area over a sprite. */
export function HitArea({
  x,
  y,
  w,
  h,
  onPress,
  label,
}: Readonly<{ x: number; y: number; w: number; h: number; onPress: () => void; label: string }>) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      onPress={() => {
        void hapticFeedback('light');
        onPress();
      }}
      style={{ position: 'absolute', left: x - w / 2, top: y - h / 2, width: w, height: h }}
    />
  );
}

type BurstKind = 'bubble' | 'glint' | 'spark';

/** A one-shot spray of particles from a point; replays every time `nonce` changes. */
export function Burst({ x, y, nonce, kind, spread = 60 }: Readonly<{ x: number; y: number; nonce: number; kind: BurstKind; spread?: number }>) {
  if (nonce === 0) return null;
  return (
    <View key={nonce} pointerEvents="none" style={StyleSheet.absoluteFill}>
      {scatter(kind === 'glint' ? 6 : 10, nonce).map((p) => (
        <Particle key={p.i} x={x} y={y} dx={p.dx * spread} dy={p.dy * spread} kind={kind} delay={p.i * 25} />
      ))}
    </View>
  );
}

function Particle({ x, y, dx, dy, kind, delay }: Readonly<{ x: number; y: number; dx: number; dy: number; kind: BurstKind; delay: number }>) {
  const t = useSharedValue(0);
  useEffect(() => {
    t.value = withDelay(delay, withTiming(1, { duration: 900, easing: Easing.out(Easing.cubic) }));
  }, [t, delay]);
  const style = useAnimatedStyle(() => ({
    opacity: interpolate(t.value, [0, 0.15, 1], [0, 1, 0]),
    transform: [{ translateX: dx * t.value }, { translateY: dy * t.value - (kind === 'bubble' ? t.value * 18 : 0) }, { scale: 0.5 + t.value * 0.8 }],
  }));
  if (kind === 'glint') {
    return (
      <Reanimated.View style={[styles.particle, { left: x - 8, top: y - 8, width: 16, height: 16 }, style]}>
        <Text style={styles.glintText}>✦</Text>
      </Reanimated.View>
    );
  }
  const size = kind === 'bubble' ? 12 : 6;
  return (
    <Reanimated.View
      style={[
        styles.particle,
        kind === 'bubble' ? styles.bubble : styles.sparkDot,
        { left: x - size / 2, top: y - size / 2, width: size, height: size, borderRadius: size / 2 },
        style,
      ]}
    />
  );
}

/* ───────────── vehicles ───────────── */

/** The customer's car; tap it for a little bounce (and whatever the scene adds). */
export function CarSprite({
  x,
  y,
  s,
  glow,
  onPress,
}: Readonly<{ x: number; y: number; s: number; glow?: string; onPress?: () => void }>) {
  const len = s * CAR_LEN;
  const wide = s * CAR_WIDE;
  const wobble = useSharedValue(0);
  const style = useAnimatedStyle(() => ({ transform: [{ rotate: `${wobble.value}deg` }, { scale: 1 + Math.abs(wobble.value) * 0.006 }] }));
  const press = () => {
    wobble.value = withSequence(withTiming(-3, { duration: 70 }), withTiming(3, { duration: 110 }), withSpring(0, { damping: 6 }));
    onPress?.();
  };
  return (
    <>
      <View
        pointerEvents="none"
        style={[
          styles.carShadow,
          { width: wide * 0.92, height: len * 0.94, left: x - (wide * 0.92) / 2 + 3, top: y - (len * 0.94) / 2 + 6 },
          glow ? { shadowColor: glow, shadowOpacity: 0.55 } : null,
        ]}
      />
      <Reanimated.View pointerEvents="none" style={[{ position: 'absolute', width: s, height: s, left: x - s / 2, top: y - s / 2 }, style]}>
        <Image source={CAR_IMAGE} resizeMode="contain" style={styles.fill} />
      </Reanimated.View>
      <HitArea x={x} y={y} w={wide} h={len} onPress={press} label="Customer's car" />
    </>
  );
}

/** How fast the van looks: zero when parked at either end of a trip, full mid-way. */
function speedOf(goal: number, origin: number, x: number, span: number) {
  'worklet';
  return interpolate(Math.min(Math.abs(goal - x), Math.abs(x - origin)), [0, span], [0, 1], Extrapolation.CLAMP);
}

/** The Wish-a-Wash van. Tap it to give a friendly toot. */
export function VanSprite({
  x,
  goal,
  y,
  w,
  beams = true,
  hazards = false,
}: Readonly<{ x: SharedValue<number>; goal: SharedValue<number>; y: number; w: number; beams?: boolean; hazards?: boolean }>) {
  const h = w / VAN_RATIO;
  const idle = useLoop(900, true);
  const beam = useSharedValue(beams ? 1 : 0);
  const hop = useSharedValue(0);
  const [toots, toot] = useTaps();
  useEffect(() => {
    beam.value = withTiming(beams ? 1 : 0, { duration: 500 });
  }, [beam, beams]);

  const origin = useSharedValue(0);
  useAnimatedReaction(
    () => goal.value,
    (next, prev) => {
      if (next !== prev) origin.value = x.value;
    }
  );

  const body = useAnimatedStyle(() => {
    const speed = speedOf(goal.value, origin.value, x.value, w * 0.8);
    return {
      transform: [
        { translateX: x.value - w / 2 },
        { translateY: -idle.value * 0.8 * (1 - speed) - hop.value * 4 },
        { scale: 1 + hop.value * 0.05 },
      ],
    };
  });
  const beamStyle = useAnimatedStyle(() => ({
    opacity: Math.min(1, beam.value * (0.55 + speedOf(goal.value, origin.value, x.value, w * 0.8) * 0.45) + hop.value * 0.6),
  }));
  const streakStyle = useAnimatedStyle(() => {
    const speed = speedOf(goal.value, origin.value, x.value, w * 0.6);
    return { opacity: speed * 0.75, transform: [{ translateX: -speed * 10 }] };
  });

  const press = () => {
    void hapticFeedback('medium');
    hop.value = withSequence(withTiming(1, { duration: 90 }), withSpring(0, { damping: 7 }));
    toot();
  };

  return (
    <Reanimated.View style={[styles.van, { width: w, height: h, top: y - h / 2 }, body]}>
      <Reanimated.View pointerEvents="none" style={[styles.beams, { left: w * 0.94, height: h }, beamStyle]}>
        {[0.1, 0.64].map((f) => (
          <LinearGradient
            key={f}
            colors={[`${WARM}0.5)`, `${WARM}0)`]}
            start={{ x: 0, y: 0.5 }}
            end={{ x: 1, y: 0.5 }}
            style={[styles.beam, { top: h * f, height: h * 0.26, width: w * 0.6 }]}
          />
        ))}
      </Reanimated.View>
      <Reanimated.View pointerEvents="none" style={[styles.streaks, { right: w + 6, top: h * 0.18, gap: h * 0.36 }, streakStyle]}>
        <View style={styles.streak} />
        <View style={[styles.streak, styles.streakShort]} />
      </Reanimated.View>
      <View pointerEvents="none" style={[styles.vanShadow, { borderRadius: h * 0.3 }]} />
      <Image source={VALETER_VAN_IMAGE} resizeMode="contain" style={styles.fill} />
      {hazards ? <Hazards w={w} h={h} /> : null}
      {toots > 0 ? <TootRings key={toots} w={w} h={h} /> : null}
      <Pressable accessibilityRole="button" accessibilityLabel="Your van" onPress={press} style={StyleSheet.absoluteFill} />
    </Reanimated.View>
  );
}

function TootRings({ w, h }: Readonly<{ w: number; h: number }>) {
  return (
    <View pointerEvents="none" style={[styles.toot, { left: w - 8, top: h / 2 - 20 }]}>
      {[0, 1, 2].map((i) => (
        <TootRing key={i} delay={i * 120} />
      ))}
    </View>
  );
}

function TootRing({ delay }: Readonly<{ delay: number }>) {
  const t = useSharedValue(0);
  useEffect(() => {
    t.value = withDelay(delay, withTiming(1, { duration: 650, easing: Easing.out(Easing.quad) }));
  }, [t, delay]);
  const style = useAnimatedStyle(() => ({ opacity: 1 - t.value, transform: [{ translateX: t.value * 22 }, { scale: 0.5 + t.value }] }));
  return <Reanimated.View style={[styles.tootRing, style]} />;
}

function Hazards({ w, h }: Readonly<{ w: number; h: number }>) {
  const t = useSharedValue(0);
  useEffect(() => {
    t.value = withRepeat(
      withSequence(withTiming(1, { duration: 90 }), withTiming(1, { duration: 420 }), withTiming(0, { duration: 90 }), withTiming(0, { duration: 420 })),
      -1,
      false
    );
    return () => cancelAnimation(t);
  }, [t]);
  const style = useAnimatedStyle(() => ({ opacity: t.value }));
  const spots = [
    { left: w * 0.02, top: h * 0.04 },
    { left: w * 0.02, top: h * 0.8 },
    { left: w * 0.93, top: h * 0.04 },
    { left: w * 0.93, top: h * 0.8 },
  ];
  return (
    <Reanimated.View pointerEvents="none" style={[StyleSheet.absoluteFill, style]}>
      {spots.map((p) => (
        <View key={`${p.left}-${p.top}`} style={[styles.hazard, p]} />
      ))}
    </Reanimated.View>
  );
}

/* ───────────── ambient effects ───────────── */

export function Pulse({ x, y, d, tone }: Readonly<{ x: number; y: number; d: number; tone: string }>) {
  const t = useLoop(2200);
  const style = useAnimatedStyle(() => ({
    opacity: interpolate(t.value, [0, 0.15, 1], [0, 0.8, 0]),
    transform: [{ scale: 0.55 + t.value * 0.6 }],
  }));
  return (
    <Reanimated.View
      pointerEvents="none"
      style={[styles.pulse, { width: d, height: d, borderRadius: d / 2, left: x - d / 2, top: y - d / 2, borderColor: tone }, style]}
    />
  );
}

/** Deterministic scatter so effects sit in the same places every render. */
export function scatter(count: number, seed: number) {
  return Array.from({ length: count }, (_, i) => {
    const a = Math.sin((i + 1) * 12.9898 + seed * 78.233) * 43758.5453;
    const b = Math.sin((i + 1) * 39.3468 + seed * 11.135) * 24634.6345;
    return { dx: (a - Math.floor(a)) * 2 - 1, dy: (b - Math.floor(b)) * 2 - 1, i };
  });
}

export function Bubble({ x, y, size, delay }: Readonly<{ x: number; y: number; size: number; delay: number }>) {
  const t = useLoop(2400, false, delay);
  const style = useAnimatedStyle(() => ({
    opacity: Math.sin(t.value * Math.PI) * 0.9,
    transform: [{ translateY: -t.value * 26 }, { scale: 0.5 + t.value * 0.7 }],
  }));
  return (
    <Reanimated.View
      pointerEvents="none"
      style={[styles.bubble, { position: 'absolute', width: size, height: size, borderRadius: size / 2, left: x - size / 2, top: y - size / 2 }, style]}
    />
  );
}

export function Glint({ x, y, size, delay }: Readonly<{ x: number; y: number; size: number; delay: number }>) {
  const t = useSharedValue(0);
  useEffect(() => {
    t.value = withDelay(
      delay,
      withRepeat(
        withSequence(
          withTiming(1, { duration: 700, easing: Easing.out(Easing.quad) }),
          withTiming(0, { duration: 900, easing: Easing.in(Easing.quad) }),
          withTiming(0, { duration: 1000 })
        ),
        -1,
        false
      )
    );
    return () => cancelAnimation(t);
  }, [t, delay]);
  const style = useAnimatedStyle(() => ({ opacity: t.value, transform: [{ scale: 0.4 + t.value * 0.7 }, { rotate: `${t.value * 45}deg` }] }));
  return (
    <Reanimated.View pointerEvents="none" style={[styles.glint, { left: x - size / 2, top: y - size / 2, width: size, height: size }, style]}>
      <Text style={[styles.glintText, { fontSize: size, lineHeight: size }]}>✦</Text>
    </Reanimated.View>
  );
}

/** Arrows painted on the lane that light up one after another, pointing the way out. */
export function Chevrons({ x, y, tone, count = 3, size = 22 }: Readonly<{ x: number; y: number; tone: string; count?: number; size?: number }>) {
  const t = useLoop(1400);
  return (
    <View pointerEvents="none" style={[styles.chevrons, { left: x, top: y - size / 2, height: size }]}>
      {Array.from({ length: count }, (_, i) => (
        <Chevron key={i} t={t} i={i} count={count} tone={tone} size={size} />
      ))}
    </View>
  );
}

function Chevron({ t, i, count, tone, size }: Readonly<{ t: SharedValue<number>; i: number; count: number; tone: string; size: number }>) {
  const style = useAnimatedStyle(() => {
    const phase = (t.value - i / count + 1) % 1;
    return { opacity: 0.2 + 0.8 * Math.max(0, Math.sin(phase * Math.PI)) };
  });
  return <Reanimated.Text style={[styles.chevron, { color: tone, fontSize: size, lineHeight: size }, style]}>›</Reanimated.Text>;
}

/** Left/right fades so the world melts into the backdrop. */
export function EdgeFades({ w }: Readonly<{ w: number }>) {
  return (
    <>
      <LinearGradient
        colors={[BG, `${BG}00`]}
        start={{ x: 0, y: 0.5 }}
        end={{ x: 1, y: 0.5 }}
        style={[styles.edge, { left: 0, width: w * 0.08 }]}
        pointerEvents="none"
      />
      <LinearGradient
        colors={[`${BG}00`, BG]}
        start={{ x: 0, y: 0.5 }}
        end={{ x: 1, y: 0.5 }}
        style={[styles.edge, { right: 0, width: w * 0.08 }]}
        pointerEvents="none"
      />
    </>
  );
}

const styles = StyleSheet.create({
  fill: { width: '100%', height: '100%' },
  carShadow: { position: 'absolute', borderRadius: 22, backgroundColor: 'rgba(10,16,32,0.3)', shadowColor: '#0A1020', shadowOpacity: 0.35, shadowRadius: 16 },
  van: { position: 'absolute', left: 0 },
  vanShadow: {
    position: 'absolute',
    top: 6,
    left: 6,
    right: 6,
    bottom: 6,
    backgroundColor: 'rgba(10,16,32,0.3)',
    transform: [{ translateY: 5 }],
    shadowColor: '#0A1020',
    shadowOpacity: 0.5,
    shadowRadius: 12,
  },
  beams: { position: 'absolute', top: 0 },
  beam: { position: 'absolute', left: 0, borderTopRightRadius: 40, borderBottomRightRadius: 40 },
  streaks: { position: 'absolute' },
  streak: { width: 46, height: 2, borderRadius: 1, backgroundColor: 'rgba(248,250,252,0.7)' },
  streakShort: { width: 28, marginLeft: 18 },
  hazard: { position: 'absolute', width: 7, height: 7, borderRadius: 4, backgroundColor: AMBER, shadowColor: AMBER, shadowOpacity: 1, shadowRadius: 6 },
  toot: { position: 'absolute', width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  tootRing: { position: 'absolute', width: 26, height: 26, borderRadius: 13, borderWidth: 2, borderColor: 'rgba(248,250,252,0.85)' },
  pulse: { position: 'absolute', borderWidth: 2 },
  bubble: { borderWidth: 1, borderColor: 'rgba(255,255,255,0.75)', backgroundColor: 'rgba(186,230,253,0.22)' },
  sparkDot: { backgroundColor: '#FDE68A', shadowColor: AMBER, shadowOpacity: 1, shadowRadius: 6 },
  particle: { position: 'absolute', alignItems: 'center', justifyContent: 'center' },
  glint: { position: 'absolute', alignItems: 'center', justifyContent: 'center' },
  glintText: { color: '#FFFFFF', textAlign: 'center', fontSize: 14 },
  chevrons: { position: 'absolute', flexDirection: 'row', gap: 4 },
  chevron: { fontWeight: '900' },
  edge: { position: 'absolute', top: 0, bottom: 0 },
  callout: { position: 'absolute', width: 220, alignItems: 'center' },
  calloutPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 999,
    backgroundColor: 'rgba(15,23,42,0.78)',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(255,255,255,0.22)',
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
  },
  calloutDot: { width: 6, height: 6, borderRadius: 3 },
  calloutText: { color: '#F8FAFC', fontSize: 12.5, fontWeight: '700' },
});
