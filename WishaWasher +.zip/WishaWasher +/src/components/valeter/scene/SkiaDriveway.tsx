import React, { useMemo } from 'react';
import { StyleSheet } from 'react-native';
import { Canvas } from '@shopify/react-native-skia';
import type { DrivewayLayout } from './DrivewaySet';
import { SkAtmosphere, SkDrive, SkGlow, SkLampPool, SkLawn, SkPavement, SkRoad, SkRoof, SkTree } from './skiaKit';

/** Where the fixed props of the drive sit, shared by the ground and the atmosphere layers. */
function setDressing(w: number, h: number, l: DrivewayLayout) {
  const { car } = l;
  return {
    roof: { x: w * 0.06, y: -h * 0.08, w: w * 0.78, h: h * 0.3 },
    drive: { x: car.x - car.wide * 0.85, y: l.driveTop, w: car.wide * 1.7, h: l.pavementTop - l.driveTop },
    tree: { x: w * 0.95, y: l.pavementTop - 40, r: 31 },
    lamp: { x: w * 0.86, y: l.pavementTop + 8 },
  };
}

/** The drive at dusk, drawn on the GPU: textured lawn, a lit house, wet block paving and a glistening road. */
export function DrivewayGround({ w, h, l, wet = false, glow }: Readonly<{ w: number; h: number; l: DrivewayLayout; wet?: boolean; glow: string }>) {
  const d = useMemo(() => setDressing(w, h, l), [w, h, l]);
  const { car } = l;
  return (
    <Canvas style={StyleSheet.absoluteFill} pointerEvents="none">
      <SkLawn x={0} y={0} w={w} h={l.pavementTop} />
      <SkRoof {...d.roof} />
      <SkDrive {...d.drive} wet={wet} />
      <SkPavement w={w} top={l.pavementTop} />
      <SkRoad w={w} top={l.roadTop} height={h - l.roadTop} dashes={false} lamps={[d.lamp.x]} wet={wet} />
      <SkLampPool x={d.lamp.x} y={d.lamp.y} />
      <SkGlow x={car.x} y={car.y} r={car.len * 0.62} color={glow} />
      <SkTree {...d.tree} />
    </Canvas>
  );
}

export function DrivewayAtmosphere({ w, h, l }: Readonly<{ w: number; h: number; l: DrivewayLayout }>) {
  const d = useMemo(() => setDressing(w, h, l), [w, h, l]);
  return (
    <Canvas style={StyleSheet.absoluteFill} pointerEvents="none">
      <SkAtmosphere w={w} h={h} lamps={[d.lamp]} />
    </Canvas>
  );
}
