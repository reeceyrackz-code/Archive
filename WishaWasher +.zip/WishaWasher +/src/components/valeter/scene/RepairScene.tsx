import React from 'react';
import { StyleSheet, View } from 'react-native';
import Reanimated, { ZoomIn, interpolate, useAnimatedProps, useAnimatedStyle } from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import Svg, { Path } from 'react-native-svg';
import { Ionicons } from '@expo/vector-icons';
import DrivewaySet, { drivewayLayout, type CarBox } from './DrivewaySet';
import { AMBER, GREEN, Glint, scatter, useLoop, type SceneProps } from './sceneKit';

const AnimatedPath = Reanimated.createAnimatedComponent(Path);
/** One full repair pass along the scratch. */
const PASS_MS = 6500;

/** Scratch across the front-left wing, as [x, y] offsets in car widths / lengths from the car's centre. */
const SCRATCH: readonly (readonly [number, number])[] = [
  [-0.36, -0.36],
  [-0.28, -0.31],
  [-0.31, -0.26],
  [-0.2, -0.21],
  [-0.24, -0.16],
  [-0.12, -0.12],
];

function scratchPoints(car: CarBox) {
  return SCRATCH.map(([dx, dy]) => ({ x: car.x + dx * car.wide, y: car.y + dy * car.len }));
}

function pathOf(pts: readonly { x: number; y: number }[]) {
  return pts.map((p, i) => `${i ? 'L' : 'M'} ${p.x} ${p.y}`).join(' ');
}

function lengthOf(pts: readonly { x: number; y: number }[]) {
  let total = 0;
  for (let i = 1; i < pts.length; i++) total += Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y);
  return total;
}

/**
 * Repair: warning triangle out, a work light trained on the damaged wing, the toolbox open. The scratch is
 * filled along its length with a glowing bead, sparks at the tool tip; then it's smoothed away. Done: a
 * green tick where the damage was.
 */
export default function RepairScene(props: SceneProps) {
  const { w, h, accent } = props;
  const { car } = drivewayLayout(w, h);
  return (
    <DrivewaySet
      {...props}
      burst="spark"
      under={<Workshop car={car} tone={accent} />}
      over={<Fix car={car} w={w} h={h} tone={accent} />}
      doneOver={<Fixed car={car} />}
    />
  );
}

function Workshop({ car, tone }: Readonly<{ car: CarBox; tone: string }>) {
  return (
    <>
      <Triangle x={car.x + car.wide * 0.98} y={car.y + car.len * 0.34} />
      <Toolbox x={Math.max(40, car.x - car.wide * 1.7)} y={car.y + car.len * 0.12} tone={tone} />
      <WorkLight car={car} />
    </>
  );
}

function Triangle({ x, y }: Readonly<{ x: number; y: number }>) {
  return (
    <View style={[styles.triangleWrap, { left: x - 15, top: y - 14 }]}>
      <Ionicons name="warning" size={30} color="#F87171" />
    </View>
  );
}

function Toolbox({ x, y, tone }: Readonly<{ x: number; y: number; tone: string }>) {
  return (
    <View style={[styles.toolbox, { left: x - 28, top: y - 22 }]}>
      <View style={[styles.lid, { backgroundColor: tone }]} />
      <View style={styles.tray}>
        <View style={[styles.tool, styles.wrench]} />
        <View style={[styles.tool, styles.driver]} />
        <View style={[styles.tool, styles.socket]} />
      </View>
    </View>
  );
}

/** Tripod lamp off the front-left corner, its beam on the damage. */
function WorkLight({ car }: Readonly<{ car: CarBox }>) {
  const lx = car.x - car.wide * 1.05;
  const ly = car.y - car.len * 0.46;
  const beamW = car.wide * 0.95;
  return (
    <>
      <View style={[styles.beamWrap, { left: lx, top: ly - 26, width: beamW, height: 52, transform: [{ rotate: '24deg' }] }]}>
        <LinearGradient
          colors={['rgba(255,244,214,0.55)', 'rgba(255,244,214,0)']}
          start={{ x: 0, y: 0.5 }}
          end={{ x: 1, y: 0.5 }}
          style={styles.beam}
        />
      </View>
      <View style={[styles.lamp, { left: lx - 9, top: ly - 9 }]}>
        <View style={styles.lampLens} />
      </View>
    </>
  );
}

/** The scratch, the bead of filler running along it, the tool tip and its sparks. */
function Fix({ car, w, h, tone }: Readonly<{ car: CarBox; w: number; h: number; tone: string }>) {
  const pts = scratchPoints(car);
  const d = pathOf(pts);
  const len = lengthOf(pts);
  const pass = useLoop(PASS_MS);

  const scratchProps = useAnimatedProps(() => ({ strokeOpacity: interpolate(pass.value, [0, 0.7, 0.9, 1], [0.95, 0.95, 0.1, 0.95]) }));
  const beadProps = useAnimatedProps(() => ({
    strokeDashoffset: len * (1 - interpolate(pass.value, [0, 0.7, 1], [0, 1, 1])),
    strokeOpacity: interpolate(pass.value, [0, 0.05, 0.75, 0.92], [0, 1, 1, 0]),
  }));
  const tip = useAnimatedStyle(() => {
    const p = interpolate(pass.value, [0, 0.7, 1], [0, 1, 1]);
    const at = p * (pts.length - 1);
    const i = Math.min(pts.length - 2, Math.floor(at));
    const f = at - i;
    return {
      opacity: interpolate(pass.value, [0, 0.04, 0.68, 0.74], [0, 1, 1, 0]),
      transform: [{ translateX: pts[i].x + (pts[i + 1].x - pts[i].x) * f }, { translateY: pts[i].y + (pts[i + 1].y - pts[i].y) * f }],
    };
  });

  return (
    <>
      <Svg width={w} height={h} style={StyleSheet.absoluteFill}>
        <AnimatedPath d={d} stroke="#0F172A" strokeWidth={4.5} fill="none" strokeLinejoin="round" strokeLinecap="round" animatedProps={scratchProps} />
        <AnimatedPath d={d} stroke="#E2E8F0" strokeWidth={1.6} fill="none" strokeLinejoin="round" strokeLinecap="round" animatedProps={scratchProps} />
        <AnimatedPath
          d={d}
          stroke={tone}
          strokeWidth={4}
          fill="none"
          strokeLinejoin="round"
          strokeLinecap="round"
          strokeDasharray={`${len} ${len}`}
          animatedProps={beadProps}
        />
      </Svg>
      <Reanimated.View style={[styles.tip, tip]}>
        <View style={[styles.tipGlow, { backgroundColor: AMBER }]} />
        {scatter(4, 2).map((s) => (
          <Spark key={s.i} dx={s.dx * 12} dy={s.dy * 12} delay={s.i * 160} />
        ))}
      </Reanimated.View>
    </>
  );
}

function Spark({ dx, dy, delay }: Readonly<{ dx: number; dy: number; delay: number }>) {
  const t = useLoop(520, false, delay);
  const style = useAnimatedStyle(() => ({
    opacity: 1 - t.value,
    transform: [{ translateX: dx * (0.4 + t.value) }, { translateY: dy * (0.4 + t.value) }, { scale: 1 - t.value * 0.6 }],
  }));
  return <Reanimated.View style={[styles.spark, style]} />;
}

function Fixed({ car }: Readonly<{ car: CarBox }>) {
  const pts = scratchPoints(car);
  const mid = pts[Math.floor(pts.length / 2)];
  return (
    <>
      <Reanimated.View entering={ZoomIn.springify().damping(12)} style={[styles.fixed, { left: mid.x - 12, top: mid.y - 12 }]}>
        <Ionicons name="checkmark" size={15} color="#04121F" />
      </Reanimated.View>
      {scatter(5, 13).map((s) => (
        <Glint key={s.i} x={car.x + s.dx * car.wide * 0.5} y={car.y + s.dy * car.len * 0.42} size={12 + ((s.i * 3) % 8)} delay={s.i * 480} />
      ))}
    </>
  );
}

const styles = StyleSheet.create({
  triangleWrap: { position: 'absolute', shadowColor: '#0A1020', shadowOpacity: 0.4, shadowRadius: 4, shadowOffset: { width: 1, height: 3 } },
  toolbox: {
    position: 'absolute',
    width: 56,
    height: 44,
    borderRadius: 8,
    backgroundColor: '#475569',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    overflow: 'hidden',
    shadowColor: '#0A1020',
    shadowOpacity: 0.4,
    shadowRadius: 6,
    shadowOffset: { width: 2, height: 4 },
  },
  lid: { height: 8 },
  tray: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-evenly' },
  tool: { borderRadius: 2, backgroundColor: '#E2E8F0' },
  wrench: { width: 5, height: 24 },
  driver: { width: 4, height: 20, backgroundColor: '#FBBF24' },
  socket: { width: 10, height: 10, borderRadius: 5 },
  beamWrap: { position: 'absolute', transformOrigin: 'left center' },
  beam: { flex: 1, borderTopRightRadius: 60, borderBottomRightRadius: 60 },
  lamp: {
    position: 'absolute',
    width: 18,
    height: 18,
    borderRadius: 5,
    backgroundColor: '#334155',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.3)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  lampLens: { width: 9, height: 9, borderRadius: 5, backgroundColor: '#FFF4D6', shadowColor: '#FFF4D6', shadowOpacity: 1, shadowRadius: 6 },
  tip: { position: 'absolute', left: 0, top: 0, width: 0, height: 0, alignItems: 'center', justifyContent: 'center' },
  tipGlow: { position: 'absolute', width: 10, height: 10, borderRadius: 5, shadowColor: AMBER, shadowOpacity: 1, shadowRadius: 8 },
  spark: { position: 'absolute', width: 4, height: 4, borderRadius: 2, backgroundColor: '#FDE68A' },
  fixed: {
    position: 'absolute',
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: GREEN,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: GREEN,
    shadowOpacity: 0.8,
    shadowRadius: 8,
  },
});
