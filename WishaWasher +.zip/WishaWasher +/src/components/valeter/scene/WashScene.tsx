import React from 'react';
import { StyleSheet, View } from 'react-native';
import Reanimated, { FadeIn, useAnimatedProps } from 'react-native-reanimated';
import Svg, { Path } from 'react-native-svg';
import DrivewaySet, { drivewayLayout, type CarBox, type DrivewayLayout } from './DrivewaySet';
import { Bubble, Glint, scatter, useLoop, type SceneProps } from './sceneKit';
import SkiaWash from './SkiaWash';

const AnimatedPath = Reanimated.createAnimatedComponent(Path);

/** Wash: a hose from the van, foam rolling off the car, a wet drive. Done: shine and drying puddles. */
export default function WashScene(props: SceneProps) {
  const { w, h, accent } = props;
  const l = drivewayLayout(w, h);
  return (
    <DrivewaySet
      {...props}
      wet
      burst="bubble"
      under={<Puddles car={l.car} />}
      over={
        <Reanimated.View entering={FadeIn.duration(500)} style={StyleSheet.absoluteFill}>
          <Hose w={w} h={h} l={l} tone={accent} />
          <SkiaWash car={l.car} nozzle={{ x: l.car.x - l.car.wide / 2 - 4, y: l.car.y + l.car.len * 0.18 }} />
          <Foam car={l.car} />
        </Reanimated.View>
      }
      doneOver={<Shine car={l.car} />}
    />
  );
}

/** Hose from the van's side door to the car, with water pulsing along it. */
function Hose({ w, h, l, tone }: Readonly<{ w: number; h: number; l: DrivewayLayout; tone: string }>) {
  const flow = useLoop(700);
  const x0 = l.parkX + l.vanW * 0.12;
  const y0 = l.laneY - l.vanH / 2 + 4;
  const x1 = l.car.x - l.car.wide / 2 - 4;
  const y1 = l.car.y + l.car.len * 0.18;
  const d = `M ${x0} ${y0} C ${x0} ${y0 - 60}, ${x1 - 50} ${y1 + 40}, ${x1} ${y1}`;
  const props = useAnimatedProps(() => ({ strokeDashoffset: -flow.value * 18 }));
  return (
    <Svg width={w} height={h} style={StyleSheet.absoluteFill}>
      <Path d={d} stroke="rgba(10,16,32,0.3)" strokeWidth={6} fill="none" strokeLinecap="round" transform="translate(2,4)" />
      <Path d={d} stroke="#334155" strokeWidth={5} fill="none" strokeLinecap="round" />
      <AnimatedPath d={d} stroke={tone} strokeWidth={2.5} fill="none" strokeLinecap="round" strokeDasharray="6 12" animatedProps={props} />
    </Svg>
  );
}

function Foam({ car }: Readonly<{ car: CarBox }>) {
  return (
    <>
      {scatter(7, 3).map((p) => (
        <Bubble key={p.i} x={car.x + p.dx * car.wide * 0.55} y={car.y + p.dy * car.len * 0.45} size={8 + ((p.i * 5) % 10)} delay={p.i * 240} />
      ))}
    </>
  );
}

function Shine({ car }: Readonly<{ car: CarBox }>) {
  return (
    <>
      {scatter(5, 5).map((p) => (
        <Glint key={p.i} x={car.x + p.dx * car.wide * 0.5} y={car.y + p.dy * car.len * 0.42} size={12 + ((p.i * 3) % 8)} delay={p.i * 520} />
      ))}
    </>
  );
}

function Puddles({ car }: Readonly<{ car: CarBox }>) {
  const spots = [
    { dx: -0.95, dy: 0.3, rw: 34, rh: 16 },
    { dx: 0.9, dy: -0.15, rw: 26, rh: 12 },
    { dx: -0.7, dy: -0.4, rw: 20, rh: 10 },
  ];
  return (
    <>
      {spots.map((s) => (
        <View
          key={`${s.dx}-${s.dy}`}
          style={[
            styles.puddle,
            { left: car.x + s.dx * car.wide - s.rw, top: car.y + s.dy * car.len - s.rh, width: s.rw * 2, height: s.rh * 2, borderRadius: s.rw },
          ]}
        />
      ))}
    </>
  );
}

const styles = StyleSheet.create({
  puddle: { position: 'absolute', backgroundColor: 'rgba(147,197,253,0.16)', borderWidth: 1, borderColor: 'rgba(186,230,253,0.22)' },
});
