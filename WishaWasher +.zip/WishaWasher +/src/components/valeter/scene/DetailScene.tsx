import React from 'react';
import { StyleSheet, View } from 'react-native';
import Reanimated, { interpolate, useAnimatedStyle } from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import Svg, { Line } from 'react-native-svg';
import DrivewaySet, { drivewayLayout, type CarBox } from './DrivewaySet';
import { Glint, scatter, useLoop, type SceneProps } from './sceneKit';

/** One full polish pass, nose to tail. */
const PASS_MS = 7000;

/**
 * Detail: the car under a pop-up gazebo, lit by LED bars, a dull haze being polished off it nose to tail
 * with a glossy finish left behind. Done: a deep shine.
 */
export default function DetailScene(props: SceneProps) {
  const { accent, w, h } = props;
  const { car } = drivewayLayout(w, h);
  return (
    <DrivewaySet
      {...props}
      burst="glint"
      under={<Studio car={car} tone={accent} />}
      over={<Polish car={car} tone={accent} />}
      doneOver={<Gloss car={car} />}
    />
  );
}

function Studio({ car, tone }: Readonly<{ car: CarBox; tone: string }>) {
  return (
    <>
      <Gazebo car={car} />
      <LightBar x={car.x - car.wide * 0.98} car={car} tone={tone} />
      <LightBar x={car.x + car.wide * 0.98} car={car} tone={tone} />
      <Trolley x={Math.max(34, car.x - car.wide * 1.7)} y={car.y + car.len * 0.1} tone={tone} />
    </>
  );
}

/** Pop-up gazebo from above: a translucent canopy with corner legs and seams. */
function Gazebo({ car }: Readonly<{ car: CarBox }>) {
  const w = car.wide * 2.3;
  const h = car.len * 1.28;
  return (
    <View style={[styles.gazebo, { left: car.x - w / 2, top: car.y - h / 2, width: w, height: h }]}>
      <Svg width={w} height={h} style={StyleSheet.absoluteFill}>
        <Line x1={0} y1={0} x2={w} y2={h} stroke="rgba(255,255,255,0.14)" strokeWidth={1} />
        <Line x1={w} y1={0} x2={0} y2={h} stroke="rgba(255,255,255,0.14)" strokeWidth={1} />
      </Svg>
      <View style={[styles.leg, styles.legTL]} />
      <View style={[styles.leg, styles.legTR]} />
      <View style={[styles.leg, styles.legBL]} />
      <View style={[styles.leg, styles.legBR]} />
    </View>
  );
}

function LightBar({ x, car, tone }: Readonly<{ x: number; car: CarBox; tone: string }>) {
  const t = useLoop(2400, true);
  const glow = useAnimatedStyle(() => ({ opacity: 0.3 + t.value * 0.2 }));
  const h = car.len * 0.86;
  return (
    <>
      <Reanimated.View style={[styles.barGlow, { left: x - 18, top: car.y - h / 2, height: h, backgroundColor: tone }, glow]} />
      <View style={[styles.bar, { left: x - 2.5, top: car.y - h / 2, height: h }]} />
    </>
  );
}

function Trolley({ x, y, tone }: Readonly<{ x: number; y: number; tone: string }>) {
  const bottles = [tone, '#F472B6', '#FBBF24', '#60A5FA'];
  return (
    <View style={[styles.trolley, { left: x - 22, top: y - 30 }]}>
      {bottles.map((c) => (
        <View key={c} style={[styles.bottle, { backgroundColor: c }]} />
      ))}
      <View style={styles.towel} />
    </View>
  );
}

/**
 * A matt haze covers the car; the pad works across it from the nose down and the haze rolls back behind it,
 * leaving gloss (with a glint along the fresh edge). Loops gently.
 */
function Polish({ car, tone }: Readonly<{ car: CarBox; tone: string }>) {
  const pass = useLoop(PASS_MS);
  const sway = useLoop(900, true);
  const bodyW = car.wide * 0.9;
  const bodyH = car.len * 0.95;
  const top = car.y - bodyH / 2;

  const haze = useAnimatedStyle(() => {
    const p = interpolate(pass.value, [0, 0.85, 1], [0, 1, 1]);
    return {
      opacity: interpolate(pass.value, [0, 0.04, 0.9, 1], [0, 1, 1, 0]),
      transform: [{ translateY: p * bodyH }],
    };
  });
  const pad = useAnimatedStyle(() => {
    const p = interpolate(pass.value, [0, 0.85, 1], [0, 1, 1]);
    return {
      opacity: interpolate(pass.value, [0, 0.04, 0.85, 0.95], [0, 1, 1, 0]),
      transform: [{ translateX: (sway.value - 0.5) * bodyW * 0.6 }, { translateY: p * bodyH }, { rotate: `${sway.value * 540}deg` }],
    };
  });
  const edge = useAnimatedStyle(() => ({
    opacity: interpolate(pass.value, [0, 0.05, 0.85, 0.9], [0, 0.9, 0.9, 0]),
    transform: [{ translateY: interpolate(pass.value, [0, 0.85, 1], [0, 1, 1]) * bodyH }],
  }));

  const d = 30;
  return (
    <>
      <View style={[styles.clip, { left: car.x - bodyW / 2, top, width: bodyW, height: bodyH, borderRadius: bodyW * 0.32 }]}>
        <Reanimated.View style={[StyleSheet.absoluteFill, haze]}>
          <LinearGradient colors={['rgba(203,213,225,0.55)', 'rgba(148,163,184,0.5)']} style={StyleSheet.absoluteFill} />
        </Reanimated.View>
        <Reanimated.View style={[styles.edge, edge]}>
          <LinearGradient
            colors={['rgba(255,255,255,0)', 'rgba(255,255,255,0.85)', 'rgba(255,255,255,0)']}
            start={{ x: 0, y: 0.5 }}
            end={{ x: 1, y: 0.5 }}
            style={StyleSheet.absoluteFill}
          />
        </Reanimated.View>
      </View>
      <Reanimated.View style={[styles.pad, { left: car.x - d / 2, top: top - d / 2, width: d, height: d, borderRadius: d / 2, borderColor: tone }, pad]}>
        <View style={[styles.padHub, { backgroundColor: tone }]} />
        <View style={styles.padNotch} />
      </Reanimated.View>
    </>
  );
}

function Gloss({ car }: Readonly<{ car: CarBox }>) {
  const t = useLoop(3200);
  const sweep = useAnimatedStyle(() => ({ transform: [{ translateY: -50 + t.value * (car.len + 100) }] }));
  const bodyW = car.wide * 0.9;
  const bodyH = car.len * 0.95;
  return (
    <>
      <View style={[styles.clip, { left: car.x - bodyW / 2, top: car.y - bodyH / 2, width: bodyW, height: bodyH, borderRadius: bodyW * 0.32 }]}>
        <Reanimated.View style={[styles.sweep, sweep]}>
          <LinearGradient colors={['rgba(255,255,255,0)', 'rgba(255,255,255,0.45)', 'rgba(255,255,255,0)']} style={StyleSheet.absoluteFill} />
        </Reanimated.View>
      </View>
      {scatter(6, 9).map((p) => (
        <Glint key={p.i} x={car.x + p.dx * car.wide * 0.5} y={car.y + p.dy * car.len * 0.42} size={12 + ((p.i * 3) % 9)} delay={p.i * 420} />
      ))}
    </>
  );
}

const styles = StyleSheet.create({
  gazebo: {
    position: 'absolute',
    borderRadius: 16,
    backgroundColor: 'rgba(248,250,252,0.07)',
    borderWidth: 1.5,
    borderColor: 'rgba(248,250,252,0.35)',
    shadowColor: '#0A1020',
    shadowOpacity: 0.25,
    shadowRadius: 12,
  },
  leg: { position: 'absolute', width: 10, height: 10, borderRadius: 3, backgroundColor: '#CBD5E1' },
  legTL: { left: -4, top: -4 },
  legTR: { right: -4, top: -4 },
  legBL: { left: -4, bottom: -4 },
  legBR: { right: -4, bottom: -4 },
  bar: { position: 'absolute', width: 5, borderRadius: 3, backgroundColor: '#F8FAFC' },
  barGlow: { position: 'absolute', width: 36, borderRadius: 18 },
  trolley: {
    position: 'absolute',
    width: 44,
    height: 60,
    borderRadius: 10,
    padding: 6,
    backgroundColor: '#64748B',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.22)',
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 4,
    shadowColor: '#0A1020',
    shadowOpacity: 0.4,
    shadowRadius: 6,
    shadowOffset: { width: 2, height: 4 },
  },
  bottle: { width: 13, height: 13, borderRadius: 7, borderWidth: 1.5, borderColor: 'rgba(255,255,255,0.7)' },
  towel: { width: 30, height: 10, borderRadius: 3, marginTop: 2, backgroundColor: '#A5B4FC' },
  clip: { position: 'absolute', overflow: 'hidden' },
  edge: { position: 'absolute', left: 0, right: 0, top: -2, height: 4 },
  sweep: { position: 'absolute', left: 0, right: 0, height: 50 },
  pad: {
    position: 'absolute',
    borderWidth: 2.5,
    backgroundColor: 'rgba(248,250,252,0.9)',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#0A1020',
    shadowOpacity: 0.35,
    shadowRadius: 5,
    shadowOffset: { width: 1, height: 3 },
  },
  padHub: { width: 10, height: 10, borderRadius: 5 },
  padNotch: { position: 'absolute', top: 2, width: 4, height: 6, borderRadius: 2, backgroundColor: 'rgba(15,23,42,0.5)' },
});
