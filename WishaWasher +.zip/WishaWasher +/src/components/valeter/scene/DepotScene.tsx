import React, { useEffect, useRef } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Reanimated, { Easing, useAnimatedStyle, useSharedValue, withDelay, withSequence, withSpring, withTiming } from 'react-native-reanimated';
import { Canvas } from '@shopify/react-native-skia';
import { AMBER, Callout, Chevrons, EdgeFades, GREEN, HitArea, VAN_RATIO, VanSprite, useTaps, type SceneProps } from './sceneKit';
import { SkAtmosphere, SkConcrete, SkFlatRoof, SkGlow, SkLampPool, SkPaint, SkPavement, SkRoad } from './skiaKit';

/**
 * Before the journey: the van waits in its bay at the depot. Waiting for payment it idles on hazards behind a
 * closed barrier; once paid the barrier lifts and the van rolls up to the exit.
 */
export default function DepotScene({ w, h, status, first }: SceneProps) {
  const paid = status !== 'pending_payment';
  const vanW = Math.min(w * 0.36, h * 0.4);
  const vanH = vanW / VAN_RATIO;
  const roofH = h * 0.26;
  const yardBottom = h * 0.8;
  const laneY = roofH + (yardBottom - roofH) * 0.52;
  const laneH = vanH * 1.9;
  const bayX = w * 0.28;
  const gateX = w * 0.74;
  const exitX = gateX - vanW / 2 - 12;
  const [gateTaps, tapGate] = useTaps();
  const [roofTaps, tapRoof] = useTaps();

  const x = useSharedValue(bayX);
  const goal = useSharedValue(bayX);
  useEffect(() => {
    const target = paid ? exitX : bayX;
    goal.value = target;
    x.value = withDelay(paid ? 900 : 0, withTiming(target, { duration: 2200, easing: Easing.inOut(Easing.cubic) }));
  }, [paid, exitX, bayX, x, goal]);

  const postY = laneY + laneH / 2 + 4;

  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="box-none">
      <Canvas style={StyleSheet.absoluteFill} pointerEvents="none">
        <SkConcrete x={0} y={roofH - 10} w={w} h={yardBottom - roofH + 10} />
        <SkFlatRoof x={w * 0.04} y={-10} w={w * 0.92} h={roofH} />
        <SkPaint x={w * 0.06} y={laneY - laneH / 2 - 1} w={w * 0.46} h={3} />
        <SkPaint x={w * 0.06} y={laneY + laneH / 2 - 1} w={w * 0.46} h={3} />
        <SkPaint x={w * 0.06 - 1} y={laneY - laneH / 2} w={3} h={laneH} />
        <SkPaint x={w * 0.62} y={laneY - laneH / 2 - 10} w={w * 0.38} h={2} color="rgba(241,245,249,0.45)" />
        <SkPaint x={w * 0.62} y={laneY + laneH / 2 + 8} w={w * 0.38} h={2} color="rgba(241,245,249,0.45)" />
        <SkPavement w={w} top={yardBottom} />
        <SkRoad w={w} top={yardBottom + 16} height={h - yardBottom - 16} lamps={[w * 0.05, w * 0.95]} />
        <SkLampPool x={w * 0.05} y={roofH + 10} />
        <SkLampPool x={w * 0.95} y={roofH + 10} />
        <SkGlow x={bayX} y={laneY} r={vanW * 0.75} color={paid ? GREEN : AMBER} opacity={paid ? 0.14 : 0.26} />
      </Canvas>
      <View pointerEvents="none" style={StyleSheet.absoluteFill}>
        <Text style={[styles.bayTag, { left: w * 0.09, top: laneY + laneH / 2 + 6 }]}>BAY 1</Text>
        {paid ? <Chevrons x={gateX + 18} y={laneY} tone={GREEN} size={24} /> : null}
      </View>

      <HitArea x={w / 2} y={roofH / 2} w={w * 0.9} h={roofH} onPress={tapRoof} label="Depot" />
      <VanSprite x={x} goal={goal} y={laneY} w={vanW} beams={paid} hazards={!paid} />
      <Barrier x={gateX} y={postY} len={laneH + 6} open={paid} nonce={gateTaps} />
      <HitArea x={gateX} y={laneY} w={56} h={laneH + 30} onPress={tapGate} label="Exit barrier" />
      <Canvas style={StyleSheet.absoluteFill} pointerEvents="none">
        <SkAtmosphere w={w} h={h} lamps={[{ x: w * 0.05, y: roofH + 10 }, { x: w * 0.95, y: roofH + 10 }]} />
      </Canvas>
      <EdgeFades w={w} />

      <Callout
        x={gateX - 20}
        y={laneY - laneH / 2 - 8}
        nonce={gateTaps}
        tone={paid ? GREEN : AMBER}
        text={paid ? 'Barrier’s up · start the journey' : `Opens once ${first} pays`}
      />
      <Callout x={w / 2} y={roofH * 0.55} nonce={roofTaps} text="Your base · fully stocked" />
    </View>
  );
}

/** Top-down car-park barrier: a post on the kerb with a striped arm across the exit lane. Tap to rattle it. */
function Barrier({ x, y, len, open, nonce }: Readonly<{ x: number; y: number; len: number; open: boolean; nonce: number }>) {
  const angle = useSharedValue(-90);
  useEffect(() => {
    angle.value = withDelay(open ? 400 : 0, withTiming(open ? 0 : -90, { duration: 1100, easing: Easing.inOut(Easing.cubic) }));
  }, [angle, open]);
  const openRef = useRef(open);
  openRef.current = open;
  useEffect(() => {
    if (nonce === 0) return;
    const rest = openRef.current ? 0 : -90;
    angle.value = withSequence(withTiming(rest + 7, { duration: 80 }), withTiming(rest - 5, { duration: 90 }), withSpring(rest, { damping: 5 }));
  }, [angle, nonce]);
  const style = useAnimatedStyle(() => ({ transform: [{ rotate: `${angle.value}deg` }] }));
  const lightTone = open ? GREEN : AMBER;
  return (
    <View pointerEvents="none" style={{ position: 'absolute', left: x - len, top: y - len, width: len * 2, height: len * 2 }}>
      <Reanimated.View style={[StyleSheet.absoluteFill, style]}>
        <View style={[styles.arm, { left: len, top: len - 3, width: len }]}>
          {Array.from({ length: 6 }, (_, i) => (
            <View key={i} style={[styles.armStripe, { backgroundColor: i % 2 ? '#F8FAFC' : '#EF4444' }]} />
          ))}
        </View>
      </Reanimated.View>
      <View style={[styles.post, { left: len - 7, top: len - 7 }]}>
        <View style={[styles.postLight, { backgroundColor: lightTone, shadowColor: lightTone }]} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  bayTag: { position: 'absolute', color: 'rgba(248,250,252,0.55)', fontSize: 10, fontWeight: '800', letterSpacing: 1.4 },
  arm: { position: 'absolute', height: 6, borderRadius: 3, flexDirection: 'row', overflow: 'hidden' },
  armStripe: { flex: 1 },
  post: { position: 'absolute', width: 14, height: 14, borderRadius: 4, backgroundColor: '#64748B', alignItems: 'center', justifyContent: 'center' },
  postLight: { width: 6, height: 6, borderRadius: 3, shadowOpacity: 1, shadowRadius: 6 },
});
