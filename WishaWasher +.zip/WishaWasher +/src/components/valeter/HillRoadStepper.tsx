import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Image, StyleSheet, Text, View } from 'react-native';
import Reanimated, {
  Easing,
  useAnimatedProps,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withTiming,
  withDelay,
  FadeInDown,
} from 'react-native-reanimated';
import Svg, { Defs, LinearGradient as SvgGradient, Path, Stop, Text as SvgText, TextPath } from 'react-native-svg';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import type { StageItem } from '../../utils/trackingStatusHelpers';
import { DOCK_NOTCH_DEPTH, DOCK_NOTCH_GAP, dockTopEdge } from './ValeterDashboardFloatingDock';

const VAN_ART = require('../../../assets/tracking-van-pin.png');
/** Top-down van art facing right — width / height. */
const VAN_RATIO = 300 / 143;
const VAN_W = 36;
const VAN_H = VAN_W / VAN_RATIO;
const ROAD_W = 12;
/** Clear air between the bar's edge and the road's underside. */
const ROAD_CLEAR = DOCK_NOTCH_GAP;
const END_PAD = 4;
/** First and last stops sit this far along the road, so its ends can fade out beyond them. */
const STOP_INSET = 32;
const STOP = 14;
const NEXT_RING = 18;
/** Baseline of the step names above the road's centreline (clears the van). */
const LABEL_SIZE = 9.5;
/** Extra lift for step names on the hill so they read clear of the climbing road and van. */
const HILL_LABEL_RAISE = 22;
const COMPACT_LABEL_RAISE = 10;

/** Road, van, stop and label sizes for a given scale (1 = card size, bigger for the drive). */
function hillDims(scale: number, raise = HILL_LABEL_RAISE, headroom = 8) {
  const soft = 1 + (scale - 1) * 0.45;
  const roadW = ROAD_W * scale;
  const vanH = VAN_H * scale;
  return {
    scale,
    roadW,
    stopScale: soft,
    labelSize: LABEL_SIZE * soft,
    /** Baseline of the step names above the road centreline, clear of the van. */
    labelLift: Math.max(roadW / 2, vanH / 2) + 6 + 4 * soft,
    raise,
    headroom,
  };
}
type HillDims = ReturnType<typeof hillDims>;
const DRIVE_MS = 1400;
/** Room for the road's crest over the button, plus the van and a label above it. */
export function hillRoadHeight(clear = 0, dims: HillDims = hillDims(1)) {
  return Math.ceil(
    DOCK_NOTCH_DEPTH + ROAD_CLEAR + clear + dims.roadW / 2 + dims.labelLift + dims.raise + dims.labelSize * 1.4 + dims.headroom
  );
}
const DONE_GREEN = '#4ADE80';

const SHORT_LABELS: Record<string, string> = { 'Awaiting payment': 'Payment', 'Accept job': 'Accept' };

export function currentStageIndex(stages: StageItem[]): number {
  const active = stages.findIndex((s) => s.current && !s.done);
  if (active >= 0) return active;
  let lastDone = -1;
  stages.forEach((s, i) => {
    if (s.done) lastDone = i;
  });
  return Math.max(0, lastDone);
}

type Lane = Readonly<{ d: string; cum: number[]; length: number }>;
type Road = Readonly<{
  xs: number[];
  ys: number[];
  angles: number[];
  cum: number[];
  length: number;
  d: string;
  /** Baseline the step names are written along, just above the road. */
  label: Lane;
  /** Mid-height of the names, for the current step's pill. */
  pill: Lane;
}>;

/** The road shifted up along its normal by `by`, keeping one point per road point so distances map across. */
function laneAbove(xs: number[], ys: number[], angles: number[], by: (i: number) => number): Lane {
  let lx = xs.map((x, i) => x + Math.sin((angles[i]! * Math.PI) / 180) * by(i));
  let ly = ys.map((y, i) => y - Math.cos((angles[i]! * Math.PI) / 180) * by(i));
  /* Offsetting above the hill's inward bends folds the line back on itself, which squashes the names
     there together. Keep it moving forward, then smooth it out. */
  for (let i = 1; i < lx.length; i++) lx[i] = Math.max(lx[i]!, lx[i - 1]! + 0.5);
  const R = 7;
  for (let pass = 0; pass < 4; pass++) {
    const avg = (arr: number[]) =>
      arr.map((_, i) => {
        /* Window narrows at the ends so the line keeps its full length. */
        const r = Math.min(R, i, arr.length - 1 - i);
        const a = i - r;
        const b = i + r;
        let sum = 0;
        for (let k = a; k <= b; k++) sum += arr[k]!;
        return sum / (b - a + 1);
      });
    lx = avg(lx);
    ly = avg(ly);
  }
  const cum: number[] = [];
  let length = 0;
  const parts = lx.map((x, i) => {
    if (i > 0) length += Math.hypot(x - lx[i - 1]!, ly[i]! - ly[i - 1]!);
    cum.push(length);
    return `${i ? 'L' : 'M'} ${x.toFixed(1)} ${ly[i]!.toFixed(1)}`;
  });
  return { d: parts.join(' '), cum, length };
}

/** Scale for every name so no two neighbours touch along the curve (1 when they already fit). */
function labelFit(road: Road, widths: number[], stopS: (i: number) => number) {
  let fit = 1;
  for (let i = 0; i < widths.length - 1; i++) {
    const gap = laneAt(road, road.label, stopS(i + 1)) - laneAt(road, road.label, stopS(i));
    const need = (widths[i]! + widths[i + 1]!) / 2 + 10;
    fit = Math.min(fit, gap / need);
  }
  return fit;
}

/** Distance along `lane` that sits beside distance `s` along the road. */
function laneAt(road: Road, lane: Lane, s: number) {
  let i = 1;
  while (i < road.cum.length - 1 && road.cum[i]! < s) i++;
  const span = road.cum[i]! - road.cum[i - 1]! || 1;
  const t = Math.max(0, Math.min(1, (s - road.cum[i - 1]!) / span));
  return lane.cum[i - 1]! + (lane.cum[i]! - lane.cum[i - 1]!) * t;
}

/**
 * The road's centreline: the bar's top edge pushed out along its normal, so the road keeps an even gap
 * as it climbs over the next-step button and back down. Densified so the van can be placed by distance.
 */
function buildRoad(w: number, h: number, clear: number, dims: HillDims): Road {
  const edge = dockTopEdge(w).map(([x, lift]) => [x, h + DOCK_NOTCH_GAP - lift] as const);
  const dense: [number, number][] = [];
  for (let i = 0; i < edge.length - 1; i++) {
    const [x0, y0] = edge[i]!;
    const [x1, y1] = edge[i + 1]!;
    const steps = Math.max(1, Math.ceil(Math.hypot(x1 - x0, y1 - y0) / 5));
    for (let k = 0; k < steps; k++) dense.push([x0 + ((x1 - x0) * k) / steps, y0 + ((y1 - y0) * k) / steps]);
  }
  const tail = edge.at(-1)!;
  dense.push([tail[0], tail[1]]);

  const off = ROAD_CLEAR + clear + dims.roadW / 2;
  const pts = dense
    .map(([x, y], i) => {
      const [ax, ay] = dense[Math.max(0, i - 1)]!;
      const [bx, by] = dense[Math.min(dense.length - 1, i + 1)]!;
      const len = Math.hypot(bx - ax, by - ay) || 1;
      return [x + ((by - ay) / len) * off, y - ((bx - ax) / len) * off] as const;
    })
    .filter(([x]) => x >= END_PAD && x <= w - END_PAD);

  const xs: number[] = [];
  const ys: number[] = [];
  const cum: number[] = [];
  let length = 0;
  pts.forEach(([x, y], i) => {
    if (i > 0) length += Math.hypot(x - xs[i - 1]!, y - ys[i - 1]!);
    xs.push(x);
    ys.push(y);
    cum.push(length);
  });
  const angles = xs.map((_, i) => {
    const a = Math.max(0, i - 2);
    const b = Math.min(xs.length - 1, i + 2);
    return (Math.atan2(ys[b]! - ys[a]!, xs[b]! - xs[a]!) * 180) / Math.PI;
  });
  const d = xs.map((x, i) => `${i ? 'L' : 'M'} ${x.toFixed(1)} ${ys[i]!.toFixed(1)}`).join(' ');
  /** 0 on the flats, 1 at the crest — names on the hill are lifted further off the road. */
  const flatY = Math.max(...ys);
  const hill = ys.map((y) => Math.sqrt(Math.max(0, Math.min(1, (flatY - y) / DOCK_NOTCH_DEPTH))));
  return {
    xs,
    ys,
    angles,
    cum,
    length,
    d,
    label: laneAbove(xs, ys, angles, (i) => dims.labelLift + dims.raise * hill[i]!),
    pill: laneAbove(xs, ys, angles, (i) => dims.labelLift + dims.raise * hill[i]! + dims.labelSize * 0.37),
  };
}

function pointAt(road: Road, s: number) {
  const { cum, xs, ys, angles } = road;
  let i = 1;
  while (i < cum.length - 1 && cum[i]! < s) i++;
  const span = cum[i]! - cum[i - 1]! || 1;
  const t = Math.max(0, Math.min(1, (s - cum[i - 1]!) / span));
  return {
    x: xs[i - 1]! + (xs[i]! - xs[i - 1]!) * t,
    y: ys[i - 1]! + (ys[i]! - ys[i - 1]!) * t,
    angle: angles[i - 1]! + (angles[i]! - angles[i - 1]!) * t,
  };
}

const AnimatedPath = Reanimated.createAnimatedComponent(Path);

/** Soft green pill drawn along the curve behind the current step's name. */
function LanePill({ lane, center, textWidth, fontSize }: Readonly<{ lane: Lane; center: number; textWidth: number; fontSize: number }>) {
  const len = textWidth + fontSize * 0.5;
  const thick = fontSize * 1.3;
  const dash = [len, lane.length * 2];
  const offset = -(center - len / 2);
  return (
    <Path d={lane.d} fill="none" stroke={DONE_GREEN} strokeOpacity={0.24} strokeWidth={thick} strokeLinecap="round" strokeDasharray={dash} strokeDashoffset={offset} />
  );
}

/** Horizontal stroke gradient that fades a layer out at both ends of the road. */
function EndFade({ id, width, color, opacity }: Readonly<{ id: string; width: number; color: string; opacity: number }>) {
  return (
    <SvgGradient id={id} x1={0} y1={0} x2={width} y2={0} gradientUnits="userSpaceOnUse">
      <Stop offset="0" stopColor={color} stopOpacity={0} />
      <Stop offset="0.07" stopColor={color} stopOpacity={opacity} />
      <Stop offset="0.93" stopColor={color} stopOpacity={opacity} />
      <Stop offset="1" stopColor={color} stopOpacity={0} />
    </SvgGradient>
  );
}

function HillStop({ x, y, done, final, k }: Readonly<{ x: number; y: number; done: boolean; final: boolean; k: number }>) {
  const grow = { transform: [{ scale: k }] };
  if (final) {
    const size = STOP + 2;
    return (
      <View style={[styles.stop, styles.stopFlag, done && styles.stopFlagDone, { left: x - size / 2, top: y - size / 2 }, grow]}>
        <Ionicons name={done ? 'sparkles' : 'flag'} size={9} color={done ? '#04121F' : 'rgba(226,232,240,0.85)'} />
      </View>
    );
  }
  if (done) {
    return (
      <View style={[styles.stop, styles.stopDone, { left: x - STOP / 2, top: y - STOP / 2 }, grow]}>
        <Ionicons name="checkmark" size={9} color="#04121F" />
      </View>
    );
  }
  return <View style={[styles.stop, styles.stopTodo, { left: x - 4, top: y - 4 }, grow]} />;
}

/**
 * Trip steps as a little road that climbs over the nav bar's next-step button and back down, with the
 * van parked at the current step. Replaces the trip card for the drive so the map stays open.
 */
export default function HillRoadStepper({
  stages,
  textMain,
  mutedColor,
  isLight,
  clear = 0,
  scale = 1,
  compact = false,
}: Readonly<{
  stages: StageItem[];
  textMain: string;
  mutedColor: string;
  isLight: boolean;
  /** Extra gap above the bar's edge, e.g. to clear the trip card's notched border. */
  clear?: number;
  /** Size of the road and van; the drive uses a bigger one since it has the bar to itself. */
  scale?: number;
  /** Tight fit for inside the trip card: names hug the hill and there is no spare air above them. */
  compact?: boolean;
}>) {
  const [width, setWidth] = useState(0);
  const dims = useMemo(() => (compact ? hillDims(scale, COMPACT_LABEL_RAISE, 2) : hillDims(scale)), [scale, compact]);
  const h = hillRoadHeight(clear, dims);
  const road = useMemo(() => (width > 0 ? buildRoad(width, h, clear, dims) : null), [width, h, clear, dims]);
  const n = stages.length;
  const activeIndex = currentStageIndex(stages);
  const allDone = n > 0 && stages.every((s) => s.done);
  const stopS = (i: number) => {
    if (!road) return 0;
    const span = Math.max(0, road.length - STOP_INSET * 2);
    return n > 1 ? STOP_INSET + (i * span) / (n - 1) : road.length / 2;
  };

  const vanS = useSharedValue(0);
  const moving = useSharedValue(0);
  const bob = useSharedValue(0);
  const halo = useSharedValue(0);
  const placedRef = useRef(false);

  useEffect(() => {
    bob.value = withRepeat(withTiming(1, { duration: 420, easing: Easing.inOut(Easing.sin) }), -1, true);
    halo.value = withRepeat(withTiming(1, { duration: 1600, easing: Easing.out(Easing.quad) }), -1, false);
  }, [bob, halo]);

  useEffect(() => {
    if (!road) return;
    const target = stopS(activeIndex);
    if (!placedRef.current) {
      placedRef.current = true;
      vanS.value = target;
      return;
    }
    if (Math.abs(vanS.value - target) < 1) return;
    void hapticFeedback('soft');
    moving.value = withSequence(withTiming(1, { duration: 120 }), withDelay(DRIVE_MS - 200, withTiming(0, { duration: 260 })));
    vanS.value = withTiming(target, { duration: DRIVE_MS, easing: Easing.inOut(Easing.cubic) });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [road, activeIndex]);

  const xs = road?.xs ?? [0];
  const ys = road?.ys ?? [0];
  const angles = road?.angles ?? [0];
  const cum = road?.cum ?? [0];
  const length = road?.length ?? 0;

  const vanStyle = useAnimatedStyle(() => {
    let i = 1;
    while (i < cum.length - 1 && cum[i]! < vanS.value) i++;
    const j = Math.max(0, i - 1);
    const span = (cum[i] ?? 0) - (cum[j] ?? 0) || 1;
    const t = Math.max(0, Math.min(1, (vanS.value - (cum[j] ?? 0)) / span));
    const x = (xs[j] ?? 0) + ((xs[i] ?? 0) - (xs[j] ?? 0)) * t;
    const y = (ys[j] ?? 0) + ((ys[i] ?? 0) - (ys[j] ?? 0)) * t;
    const a = (angles[j] ?? 0) + ((angles[i] ?? 0) - (angles[j] ?? 0)) * t;
    return {
      transform: [
        { translateX: x - VAN_W / 2 },
        { translateY: y - VAN_H / 2 + (bob.value - 0.5) * (0.5 + moving.value * 1.5) },
        { rotate: `${a}deg` },
        { scale },
      ],
    };
  });
  const haloStyle = useAnimatedStyle(() => {
    let i = 1;
    while (i < cum.length - 1 && cum[i]! < vanS.value) i++;
    return {
      opacity: allDone ? 0 : 0.4 * (1 - halo.value) * (1 - moving.value),
      transform: [
        { translateX: (xs[i] ?? 0) - VAN_W / 2 },
        { translateY: (ys[i] ?? 0) - VAN_W / 2 },
        { scale: (0.7 + halo.value * 0.6) * scale },
      ],
    };
  });
  const fillProps = useAnimatedProps(() => ({ strokeDashoffset: length - vanS.value }));
  const nextIndex = !allDone && activeIndex + 1 < n ? activeIndex + 1 : -1;
  const nextPoint = road && nextIndex >= 0 ? pointAt(road, stopS(nextIndex)) : null;
  const ringK = dims.stopScale;
  const nextPulse = useAnimatedStyle(() => ({
    opacity: 0.75 * (1 - halo.value) * (1 - moving.value),
    transform: [{ scale: (0.6 + halo.value * 1.3) * ringK }],
  }));

  const labels = stages.map((s) => SHORT_LABELS[s.label] ?? s.label);
  const [measured, setMeasured] = useState<Record<string, number>>({});
  const labelWidth = (text: string) => measured[text] ?? text.length * dims.labelSize * 0.6;
  const fit = road ? labelFit(road, labels.map(labelWidth), stopS) : 1;
  const fontSize = dims.labelSize * fit;

  return (
    <Reanimated.View
      entering={FadeInDown.duration(420).easing(Easing.out(Easing.cubic))}
      style={[styles.wrap, { height: h }]}
      pointerEvents="none"
      onLayout={(e) => {
        const w = Math.round(e.nativeEvent.layout.width);
        if (w !== width) setWidth(w);
      }}
      accessible
      accessibilityLabel={`Step ${activeIndex + 1} of ${n}: ${stages[activeIndex]?.label ?? ''}`}
    >
      <View style={styles.measure} pointerEvents="none" accessibilityElementsHidden importantForAccessibility="no-hide-descendants">
        {labels.map((text, i) => (
          <Text
            key={`m-${text}-${i}`}
            style={{ fontSize: dims.labelSize, fontWeight: '800' }}
            onLayout={(e) => {
              const w = e.nativeEvent.layout.width;
              setMeasured((m) => (Math.abs((m[text] ?? 0) - w) < 0.5 ? m : { ...m, [text]: w }));
            }}
          >
            {text}
          </Text>
        ))}
      </View>
      {road ? (
        <>
          <Svg width={width} height={h} style={StyleSheet.absoluteFill}>
            <Defs>
              <EndFade id="hillShadow" width={width} color="#000000" opacity={0.4} />
              <EndFade id="hillKerb" width={width} color="#FFFFFF" opacity={0.2} />
              <EndFade id="hillAsphalt" width={width} color={isLight ? '#1E293B' : '#0A101E'} opacity={0.95} />
              <EndFade id="hillLine" width={width} color="#F1F5F9" opacity={0.45} />
            </Defs>
            <Path d={road.d} fill="none" stroke="url(#hillShadow)" strokeWidth={dims.roadW + 7} strokeLinecap="round" strokeLinejoin="round" />
            <Path d={road.d} fill="none" stroke="url(#hillKerb)" strokeWidth={dims.roadW + 2} strokeLinecap="round" strokeLinejoin="round" />
            <Path d={road.d} fill="none" stroke="url(#hillAsphalt)" strokeWidth={dims.roadW} strokeLinecap="round" strokeLinejoin="round" />
            <AnimatedPath
              d={road.d}
              fill="none"
              stroke={DONE_GREEN}
              strokeOpacity={0.16}
              strokeWidth={dims.roadW + 8}
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeDasharray={[road.length, road.length]}
              animatedProps={fillProps}
            />
            <AnimatedPath
              d={road.d}
              fill="none"
              stroke={DONE_GREEN}
              strokeOpacity={0.55}
              strokeWidth={dims.roadW}
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeDasharray={[road.length, road.length]}
              animatedProps={fillProps}
            />
            <Path
              d={road.d}
              fill="none"
              stroke="url(#hillLine)"
              strokeWidth={1.4}
              strokeDasharray={[6, 7]}
              strokeLinecap="round"
            />
          </Svg>

          {nextPoint ? (
            <Reanimated.View
              style={[styles.nextPulse, { left: nextPoint.x - NEXT_RING / 2, top: nextPoint.y - NEXT_RING / 2 }, nextPulse]}
            />
          ) : null}
          {stages.map((stage, i) => {
            const p = pointAt(road, stopS(i));
            const final = i === n - 1;
            const isCurrent = !allDone && i === activeIndex;
            return (
              <React.Fragment key={`${stage.label}-${i}`}>
                {isCurrent ? null : <HillStop x={p.x} y={p.y} done={stage.done} final={final} k={dims.stopScale} />}
              </React.Fragment>
            );
          })}

          <Svg width={width} height={h} style={StyleSheet.absoluteFill}>
            <Defs>
              <Path id="hillLabelLane" d={road.label.d} />
            </Defs>
            {stages.map((stage, i) => {
              const text = labels[i]!;
              const textWidth = labelWidth(text) * fit;
              const center = laneAt(road, road.label, stopS(i));
              const start = Math.max(2, Math.min(road.label.length - textWidth - 2, center - textWidth / 2));
              const shift = start + textWidth / 2 - center;
              const pill = (!allDone && i === activeIndex) || (allDone && i === n - 1);
              const later = !stage.done && i !== nextIndex && !pill;
              let fill = mutedColor;
              if (pill) fill = DONE_GREEN;
              else if (stage.done || i === nextIndex) fill = textMain;
              return (
                <React.Fragment key={`label-${stage.label}-${i}`}>
                  {pill ? <LanePill lane={road.pill} center={laneAt(road, road.pill, stopS(i)) + shift} textWidth={textWidth} fontSize={fontSize} /> : null}
                  <SvgText fontSize={fontSize} fontWeight="800" stroke="rgba(2,6,23,0.8)" strokeWidth={2.6} fill="rgba(2,6,23,0.8)">
                    <TextPath href="#hillLabelLane" startOffset={start}>
                      {text}
                    </TextPath>
                  </SvgText>
                  <SvgText fontSize={fontSize} fontWeight="800" fill={fill} fillOpacity={later ? 0.7 : 1}>
                    <TextPath href="#hillLabelLane" startOffset={start}>
                      {text}
                    </TextPath>
                  </SvgText>
                </React.Fragment>
              );
            })}
          </Svg>

          <Reanimated.View style={[styles.halo, haloStyle]} />
          <Reanimated.View style={[styles.van, vanStyle]}>
            <LinearGradient
              colors={['rgba(255,250,220,0.38)', 'rgba(255,250,220,0)']}
              start={{ x: 0, y: 0.5 }}
              end={{ x: 1, y: 0.5 }}
              style={styles.vanBeam}
            />
            <View style={styles.vanShadow} />
            <Image source={VAN_ART} resizeMode="contain" style={styles.vanImage} />
          </Reanimated.View>
        </>
      ) : null}
    </Reanimated.View>
  );
}

const styles = StyleSheet.create({
  wrap: { width: '100%' },
  measure: { position: 'absolute', left: 0, top: 0, opacity: 0, alignItems: 'flex-start' },
  stop: { position: 'absolute', alignItems: 'center', justifyContent: 'center' },
  stopDone: {
    width: STOP,
    height: STOP,
    borderRadius: STOP / 2,
    backgroundColor: DONE_GREEN,
    shadowColor: DONE_GREEN,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
  },
  stopFlag: {
    width: STOP + 2,
    height: STOP + 2,
    borderRadius: (STOP + 2) / 2,
    borderWidth: 1.5,
    borderColor: 'rgba(226,232,240,0.5)',
    backgroundColor: 'rgba(2,6,23,0.85)',
  },
  stopFlagDone: { backgroundColor: DONE_GREEN, borderColor: DONE_GREEN },
  stopTodo: {
    width: 8,
    height: 8,
    borderRadius: 4,
    borderWidth: 1.5,
    borderColor: 'rgba(203,213,225,0.7)',
    backgroundColor: 'rgba(2,6,23,0.8)',
  },
  nextPulse: {
    position: 'absolute',
    width: NEXT_RING,
    height: NEXT_RING,
    borderRadius: NEXT_RING / 2,
    borderWidth: 2,
    borderColor: DONE_GREEN,
  },
  vanBeam: {
    position: 'absolute',
    left: VAN_W - 5,
    width: 20,
    height: VAN_H * 0.75,
    borderTopRightRadius: VAN_H,
    borderBottomRightRadius: VAN_H,
  },
  halo: {
    position: 'absolute',
    left: 0,
    top: 0,
    width: VAN_W,
    height: VAN_W,
    borderRadius: VAN_W / 2,
    backgroundColor: DONE_GREEN,
  },
  van: { position: 'absolute', left: 0, top: 0, width: VAN_W, height: VAN_H, alignItems: 'center', justifyContent: 'center' },
  vanShadow: {
    position: 'absolute',
    width: VAN_W * 0.9,
    height: VAN_H * 0.75,
    borderRadius: VAN_H * 0.3,
    backgroundColor: 'rgba(0,0,0,0.45)',
    transform: [{ translateY: 3 }],
  },
  vanImage: { width: '100%', height: '100%' },
});
