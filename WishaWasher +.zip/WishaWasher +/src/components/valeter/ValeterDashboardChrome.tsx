import React from 'react';
import { Platform, StyleSheet, View } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { GlassView } from 'expo-glass-effect';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import { hasLiquidGlass } from '../shared/GlassSurface';

const ANDROID_BLUR =
  Platform.OS === 'android' ? ({ experimentalBlurMethod: 'dimezisBlurView' as const } as const) : {};

/** Append hex alpha only when the stop is a plain #RRGGBB (rgba stays untouched). */
export function headerChromeStop(color: string, hexAlpha: string): string {
  const c = (color || '').trim();
  if (/^#[0-9A-Fa-f]{6}$/.test(c)) return `${c}${hexAlpha}`;
  return c;
}

/** The gradient with its top tint's alpha scaled by `k`, so a tinted glass reads calmer. */
export function softenedTint(gradient: readonly [string, string], k: number): [string, string] {
  const top = gradient[0].replace(
    /rgba\(([^)]+),\s*([\d.]+)\)/,
    (_, rgb: string, a: string) => `rgba(${rgb}, ${(Number(a) * k).toFixed(3)})`
  );
  return [top, gradient[1] ?? gradient[0]];
}

type Props = Readonly<{
  accent: string;
  headerGradient: readonly [string, string];
  /** Use native Liquid Glass (iOS 26+) under a lighter tint. */
  liquid?: boolean;
}>;

/**
 * Shared frosted chrome for map header + dashboard bottom sheet.
 * Light mode: lighter steel-blue frost with a soft gold edge wash.
 */
function blurIntensity(isLight: boolean) {
  if (Platform.OS === 'ios') return isLight ? 52 : 64;
  return isLight ? 66 : 80;
}

export default function ValeterDashboardChrome({ accent, headerGradient, liquid = false }: Props) {
  const { theme, mode } = useAccountTheme();
  const isLight = mode === 'light';
  const gold = theme.accentAlt ?? '#E8C547';
  const glass = liquid && hasLiquidGlass;
  const top = headerChromeStop(headerGradient[0], glass ? 'B3' : 'EE');
  const bottom = headerChromeStop(headerGradient[1] ?? headerGradient[0], glass ? 'C7' : 'F0');

  if (glass) {
    return (
      <View style={StyleSheet.absoluteFill} pointerEvents="none">
        <GlassView style={StyleSheet.absoluteFill} glassEffectStyle="regular" colorScheme="dark" />
        <LinearGradient colors={[top, bottom]} style={StyleSheet.absoluteFill} />
        <LinearGradient colors={['rgba(255,255,255,0.14)', 'transparent']} style={styles.topSheen} />
        <LinearGradient colors={[`${accent}30`, 'transparent']} style={styles.accentLine} />
      </View>
    );
  }

  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="none">
      <BlurView
        intensity={blurIntensity(isLight)}
        tint="dark"
        style={StyleSheet.absoluteFill}
        {...ANDROID_BLUR}
      />
      {isLight ? (
        <View style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(42,70,96,0.32)' }]} />
      ) : null}
      <LinearGradient colors={[top, bottom]} style={StyleSheet.absoluteFill} />
      {isLight ? (
        <LinearGradient
          colors={[`${gold}22`, 'transparent', `${accent}18`]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={StyleSheet.absoluteFill}
        />
      ) : null}
      <LinearGradient colors={[`${accent}30`, 'transparent']} style={styles.accentLine} />
      {isLight ? (
        <LinearGradient colors={[`${gold}55`, 'transparent']} style={styles.goldEdge} />
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  topSheen: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 28,
  },
  accentLine: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 2,
  },
  goldEdge: {
    position: 'absolute',
    top: 0,
    left: 0,
    width: '42%',
    height: 2,
  },
});
