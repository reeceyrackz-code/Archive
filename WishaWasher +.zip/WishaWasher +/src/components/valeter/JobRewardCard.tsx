import React, { useEffect, useMemo, useState } from 'react';
import { StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import Reanimated, {
  Easing,
  FadeInDown,
  ZoomIn,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withRepeat,
  withSequence,
  withTiming,
} from 'react-native-reanimated';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import { CountUpText } from '../shared/fit/FitKit';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import {
  getValeterLoyaltyBalance,
  getValeterTierProgress,
  VALETER_POINTS_FIVE_STAR,
  VALETER_POINTS_PER_JOB,
} from '../../services/ValeterLoyaltyService';

const GOLD = '#FBBF24';
const GREEN = '#34D399';
const CONFETTI_COLORS = ['#38BDF8', '#FBBF24', '#34D399', '#F472B6', '#A78BFA', '#F8FAFC'];
const CONFETTI_COUNT = 28;
const JOB_MILESTONES = [1, 5, 10, 25, 50, 100, 250, 500, 1000];

type Piece = Readonly<{
  id: string;
  x: number;
  drift: number;
  delay: number;
  spin: number;
  w: number;
  h: number;
  color: string;
  fall: number;
}>;

/** Even-looking scatter in [0, 1) for piece `i`, channel `k` (golden-ratio sequence, no RNG needed). */
function scatter(i: number, k: number) {
  const v = (i + 1) * 0.618034 + k * 0.414214;
  return v - Math.floor(v);
}

function makePieces(width: number): Piece[] {
  return Array.from({ length: CONFETTI_COUNT }, (_, i) => ({
    id: `confetti-${i}`,
    x: scatter(i, 0) * width,
    drift: (scatter(i, 1) - 0.5) * 120,
    delay: scatter(i, 2) * 260,
    spin: (scatter(i, 3) - 0.5) * 900,
    w: 5 + scatter(i, 4) * 5,
    h: 8 + scatter(i, 5) * 8,
    color: CONFETTI_COLORS[i % CONFETTI_COLORS.length]!,
    fall: 380 + scatter(i, 6) * 260,
  }));
}

function ConfettiPiece({ piece }: Readonly<{ piece: Piece }>) {
  const t = useSharedValue(0);
  useEffect(() => {
    t.value = withDelay(piece.delay, withTiming(1, { duration: 1700, easing: Easing.out(Easing.quad) }));
  }, [t, piece.delay]);
  const style = useAnimatedStyle(() => ({
    opacity: t.value < 0.75 ? 1 : 1 - (t.value - 0.75) / 0.25,
    transform: [
      { translateX: piece.x + piece.drift * t.value },
      { translateY: -20 + piece.fall * t.value },
      { rotate: `${piece.spin * t.value}deg` },
    ],
  }));
  return (
    <Reanimated.View
      style={[styles.confetti, { width: piece.w, height: piece.h, backgroundColor: piece.color }, style]}
    />
  );
}

/** One-shot burst over the top of the screen. */
export function ConfettiBurst() {
  const { width } = useWindowDimensions();
  const pieces = useMemo(() => makePieces(width), [width]);
  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill}>
      {pieces.map((p) => (
        <ConfettiPiece key={p.id} piece={p} />
      ))}
    </View>
  );
}

function AnimatedBar({ from, to, color, delay = 0 }: Readonly<{ from: number; to: number; color: string; delay?: number }>) {
  const w = useSharedValue(from);
  useEffect(() => {
    w.value = from;
    w.value = withDelay(delay, withTiming(to, { duration: 1100, easing: Easing.out(Easing.cubic) }));
  }, [w, from, to, delay]);
  const style = useAnimatedStyle(() => ({ width: `${Math.max(0, Math.min(1, w.value)) * 100}%` }));
  return (
    <View style={styles.barTrack}>
      <Reanimated.View style={[styles.barFill, { backgroundColor: color }, style]} />
    </View>
  );
}

function PointsPop() {
  const glow = useSharedValue(0);
  useEffect(() => {
    glow.value = withDelay(500, withRepeat(withSequence(withTiming(1, { duration: 900 }), withTiming(0, { duration: 900 })), 3, false));
  }, [glow]);
  const glowStyle = useAnimatedStyle(() => ({ shadowOpacity: 0.25 + glow.value * 0.5 }));
  return (
    <Reanimated.View entering={ZoomIn.delay(250).springify().damping(10)} style={[styles.pointsPill, glowStyle]}>
      <Ionicons name="sparkles" size={14} color="#0A1929" />
      <Text style={styles.pointsText}>+{VALETER_POINTS_PER_JOB} pts</Text>
    </Reanimated.View>
  );
}

type Balance = Readonly<{ before: number; after: number; jobs: number }>;

function jobMilestone(jobs: number) {
  const next = JOB_MILESTONES.find((m) => m > jobs) ?? null;
  const prev = [...JOB_MILESTONES].reverse().find((m) => m <= jobs) ?? 0;
  const hit = JOB_MILESTONES.includes(jobs);
  const plural = jobs === 1 ? '' : 's';
  return {
    next,
    hit,
    ratio: next == null ? 1 : (jobs - prev) / (next - prev),
    title: hit ? `${jobs} job${plural} milestone!` : `Job #${jobs}`,
    hint: next == null ? 'Legend status' : `${next - jobs} to ${next}`,
    color: hit ? GOLD : GREEN,
    icon: hit ? ('medal' as const) : ('checkmark-done' as const),
  };
}

function tierBarRange(before: number, after: number) {
  const from = getValeterTierProgress(before);
  const to = getValeterTierProgress(after);
  const tierUp = from.tier !== to.tier;
  return { tier: to, tierUp, from: tierUp ? 0 : from.progress / 100, to: to.progress / 100 };
}

/**
 * Post-job reward moment: points for the job, the tier bar filling (with a tier-up flourish), the job-count
 * milestone, and the 5★ bonus still up for grabs. Read-only — points are credited server-side.
 */
export default function JobRewardCard({
  userId,
  rewardCredited,
  customerFirstName,
  textMain,
  textMuted,
  cardBg,
  cardBorder,
}: Readonly<{
  userId: string | null | undefined;
  /** The booking's points have already landed in the balance. */
  rewardCredited: boolean;
  customerFirstName: string;
  textMain: string;
  textMuted: string;
  cardBg: string;
  cardBorder: string;
}>) {
  const [balance, setBalance] = useState<Balance | null>(null);

  useEffect(() => {
    if (!userId) return;
    let cancelled = false;
    void getValeterLoyaltyBalance(userId)
      .then(({ points, completedJobs }) => {
        if (cancelled) return;
        const before = rewardCredited ? Math.max(0, points - VALETER_POINTS_PER_JOB) : points;
        setBalance({ before, after: before + VALETER_POINTS_PER_JOB, jobs: Math.max(1, completedJobs) });
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, [userId, rewardCredited]);

  const bar = balance ? tierBarRange(balance.before, balance.after) : null;
  const milestone = balance ? jobMilestone(balance.jobs) : null;
  const celebrate = !!bar?.tierUp || !!milestone?.hit;

  useEffect(() => {
    if (celebrate) void hapticFeedback('success');
  }, [celebrate]);

  if (!balance || !bar || !milestone) return null;

  const afterTier = bar.tier;
  const tierColor = afterTier.color;

  return (
    <Reanimated.View
      entering={FadeInDown.delay(150).duration(420)}
      style={[styles.card, { backgroundColor: cardBg, borderColor: cardBorder }]}
    >
      <View style={styles.headRow}>
        <View style={styles.headCopy}>
          <Text style={[styles.eyebrow, { color: textMuted }]}>Rewards</Text>
          <View style={styles.totalRow}>
            <CountUpText value={balance.after} style={[styles.total, { color: textMain }]} duration={1100} />
            <Text style={[styles.totalUnit, { color: textMuted }]}>pts</Text>
          </View>
        </View>
        <PointsPop />
      </View>

      {bar.tierUp ? (
        <Reanimated.View
          entering={ZoomIn.delay(900).springify().damping(12)}
          style={[styles.tierUp, { borderColor: `${tierColor}88`, backgroundColor: `${tierColor}22` }]}
        >
          <Ionicons name="trophy" size={16} color={tierColor} />
          <Text style={[styles.tierUpText, { color: tierColor }]}>Tier up! You're now {afterTier.tier}</Text>
        </Reanimated.View>
      ) : null}

      <View style={styles.section}>
        <View style={styles.sectionRow}>
          <View style={[styles.tierChip, { borderColor: `${tierColor}88`, backgroundColor: `${tierColor}1F` }]}>
            <Ionicons name="ribbon" size={12} color={tierColor} />
            <Text style={[styles.tierChipText, { color: tierColor }]}>{afterTier.tier}</Text>
          </View>
          <Text style={[styles.sectionHint, { color: textMuted }]} numberOfLines={1}>
            {afterTier.nextTier ? `${afterTier.pointsToNext.toLocaleString()} pts to ${afterTier.nextTier}` : 'Top tier'}
          </Text>
        </View>
        <AnimatedBar from={bar.from} to={bar.to} color={tierColor} delay={400} />
      </View>

      <View style={styles.section}>
        <View style={styles.sectionRow}>
          <Ionicons name={milestone.icon} size={15} color={milestone.color} />
          <Text style={[styles.sectionTitle, { color: textMain }]}>{milestone.title}</Text>
          <Text style={[styles.sectionHint, { color: textMuted }]} numberOfLines={1}>
            {milestone.hint}
          </Text>
        </View>
        <AnimatedBar from={0} to={milestone.ratio} color={milestone.color} delay={650} />
      </View>

      <View style={[styles.bonus, { borderColor: `${GOLD}44` }]}>
        <Ionicons name="star" size={14} color={GOLD} />
        <Text style={[styles.bonusText, { color: textMuted }]} numberOfLines={2}>
          <Text style={{ color: GOLD, fontWeight: '800' }}>+{VALETER_POINTS_FIVE_STAR} pts</Text> if {customerFirstName} rates you 5★
        </Text>
      </View>
    </Reanimated.View>
  );
}

const styles = StyleSheet.create({
  confetti: { position: 'absolute', left: 0, top: 0, borderRadius: 2 },
  card: { borderRadius: 22, borderWidth: 1, padding: 18, marginBottom: 18, gap: 14 },
  headRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  headCopy: { flex: 1, minWidth: 0 },
  eyebrow: { fontSize: 11, fontWeight: '800', letterSpacing: 0.8, textTransform: 'uppercase' },
  totalRow: { flexDirection: 'row', alignItems: 'baseline', gap: 5, marginTop: 2 },
  total: { fontSize: 28, fontWeight: '900', letterSpacing: -0.6, fontVariant: ['tabular-nums'] },
  totalUnit: { fontSize: 14, fontWeight: '800' },
  pointsPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 999,
    backgroundColor: GOLD,
    shadowColor: GOLD,
    shadowOffset: { width: 0, height: 0 },
    shadowRadius: 12,
  },
  pointsText: { color: '#0A1929', fontSize: 14, fontWeight: '900' },
  tierUp: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    alignSelf: 'flex-start',
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 12,
    borderWidth: 1,
  },
  tierUpText: { fontSize: 13.5, fontWeight: '900' },
  section: { gap: 8 },
  sectionRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  sectionTitle: { fontSize: 14, fontWeight: '800' },
  sectionHint: { flex: 1, textAlign: 'right', fontSize: 12, fontWeight: '600' },
  tierChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 9,
    paddingVertical: 3,
    borderRadius: 999,
    borderWidth: 1,
  },
  tierChipText: { fontSize: 12, fontWeight: '900' },
  barTrack: { height: 6, borderRadius: 3, overflow: 'hidden', backgroundColor: 'rgba(148,163,184,0.18)' },
  barFill: { height: '100%', borderRadius: 3 },
  bonus: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 14,
    borderWidth: 1,
    borderStyle: 'dashed',
  },
  bonusText: { flex: 1, fontSize: 12.5, fontWeight: '600' },
});
