import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Image, PanResponder, StyleSheet, Text, View } from 'react-native';
import Reanimated, { Easing, FadeInDown, useAnimatedStyle, useSharedValue, withDelay, withTiming } from 'react-native-reanimated';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import { hapticFeedback } from '../../services/HapticFeedbackService';

const HEIGHT = 230;
const KNOB = 36;

/**
 * Drag-to-compare of the Pro's own before and finished photos. Opens with a sweep from "before" to the
 * middle so the change lands without a tap.
 */
export default function BeforeAfterReveal({ before, after }: Readonly<{ before: string; after: string }>) {
  const [width, setWidth] = useState(0);
  const split = useSharedValue(1);
  const widthRef = useRef(0);
  widthRef.current = width;

  useEffect(() => {
    if (width <= 0) return;
    split.value = withDelay(500, withTiming(0.5, { duration: 1400, easing: Easing.inOut(Easing.cubic) }));
  }, [split, width]);

  const pan = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => true,
        onMoveShouldSetPanResponder: (_, g) => Math.abs(g.dx) > Math.abs(g.dy),
        onPanResponderGrant: (e) => {
          void hapticFeedback('light');
          if (widthRef.current > 0) split.value = Math.max(0, Math.min(1, e.nativeEvent.locationX / widthRef.current));
        },
        onPanResponderMove: (e) => {
          if (widthRef.current > 0) split.value = Math.max(0, Math.min(1, e.nativeEvent.locationX / widthRef.current));
        },
        onPanResponderTerminationRequest: () => false,
      }),
    [split]
  );

  const beforeClip = useAnimatedStyle(() => ({ width: split.value * width }));
  const handle = useAnimatedStyle(() => ({ transform: [{ translateX: split.value * width - 1 }] }));

  return (
    <Reanimated.View entering={FadeInDown.delay(100).duration(420)} style={styles.card}>
      <View
        style={styles.frame}
        onLayout={(e) => setWidth(Math.round(e.nativeEvent.layout.width))}
        {...pan.panHandlers}
        accessibilityLabel="Before and after photos. Drag to compare."
      >
        <View pointerEvents="none" style={StyleSheet.absoluteFill}>
          <Image source={{ uri: after }} resizeMode="cover" style={StyleSheet.absoluteFill} />
          <Reanimated.View style={[styles.beforeClip, beforeClip]}>
            <Image source={{ uri: before }} resizeMode="cover" style={{ width, height: HEIGHT }} />
          </Reanimated.View>
          <View style={[styles.tag, styles.tagLeft]}>
            <Text style={styles.tagText}>BEFORE</Text>
          </View>
          <View style={[styles.tag, styles.tagRight]}>
            <Text style={styles.tagText}>AFTER</Text>
          </View>
          <Reanimated.View style={[styles.handle, handle]}>
            <View style={styles.handleLine} />
            <View style={styles.knob}>
              <Ionicons name="code-outline" size={18} color="#0A1929" />
            </View>
          </Reanimated.View>
        </View>
      </View>
    </Reanimated.View>
  );
}

const styles = StyleSheet.create({
  card: { marginBottom: 18 },
  frame: {
    height: HEIGHT,
    borderRadius: 20,
    overflow: 'hidden',
    backgroundColor: '#05080F',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(255,255,255,0.16)',
  },
  beforeClip: { position: 'absolute', left: 0, top: 0, bottom: 0, overflow: 'hidden' },
  tag: {
    position: 'absolute',
    top: 12,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    backgroundColor: 'rgba(3,6,14,0.6)',
  },
  tagLeft: { left: 12 },
  tagRight: { right: 12 },
  tagText: { color: '#F8FAFC', fontSize: 10, fontWeight: '800', letterSpacing: 1.2 },
  handle: { position: 'absolute', top: 0, bottom: 0, left: 0, width: 2, alignItems: 'center', justifyContent: 'center' },
  handleLine: { position: 'absolute', top: 0, bottom: 0, width: 2, backgroundColor: '#F8FAFC' },
  knob: {
    width: KNOB,
    height: KNOB,
    borderRadius: KNOB / 2,
    backgroundColor: '#F8FAFC',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.4,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 2 },
  },
});
