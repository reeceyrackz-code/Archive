import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  Pressable,
  TextInput,
  Animated,
  PanResponder,
  Dimensions,
  ActivityIndicator,
} from 'react-native';
import Reanimated, { FadeIn, FadeInDown, ZoomIn } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import { lightMistElevated, lightMistPanel } from '../../constants/accountThemes';
import { useKeyboardHeight } from '../../hooks/useKeyboardHeight';

const { height: SCREEN_H } = Dimensions.get('window');
const DANGER = '#EF4444';
const DONE_GREEN = '#34D399';

type ReasonOption = Readonly<{
  id: string;
  label: string;
  icon: React.ComponentProps<typeof Ionicons>['name'];
}>;

const REASONS: ReasonOption[] = [
  { id: 'vehicle_problem', label: 'Vehicle or equipment problem', icon: 'construct-outline' },
  { id: 'running_late', label: "Can't get there in time", icon: 'time-outline' },
  { id: 'emergency', label: 'Personal emergency', icon: 'medkit-outline' },
  { id: 'customer_request', label: 'Customer asked me to cancel', icon: 'chatbubbles-outline' },
  { id: 'unsafe_location', label: 'Unsafe or inaccessible location', icon: 'warning-outline' },
  { id: 'other', label: 'Something else', icon: 'ellipsis-horizontal-circle-outline' },
];

export type CancelJobReasonSheetProps = Readonly<{
  visible: boolean;
  accent: string;
  customerName: string;
  onClose: () => void;
  /** Resolve true when the cancel saved — sheet then shows its success state. */
  onConfirm: (reason: string) => Promise<boolean>;
  onCancelled: () => void;
}>;

/** "Other" needs the note; any other reason takes the note as optional detail. */
function reasonText(reason: ReasonOption, note: string) {
  const extra = note.trim();
  if (reason.id === 'other') return `Other: ${extra}`;
  return extra ? `${reason.label} — ${extra}` : reason.label;
}

function useSheetColours() {
  const { theme, mode } = useAccountTheme();
  const light = mode === 'light';
  const base = light
    ? { panel: lightMistPanel, groupBg: lightMistElevated, hairline: 'rgba(15,23,42,0.08)', handle: 'rgba(15,23,42,0.18)' }
    : { panel: 'rgba(11,17,28,0.98)', groupBg: 'rgba(255,255,255,0.05)', hairline: 'rgba(255,255,255,0.08)', handle: 'rgba(255,255,255,0.22)' };
  return {
    ...base,
    textMain: theme.textPrimary ?? '#F8FAFC',
    textMuted: theme.textSecondary ?? 'rgba(248,250,252,0.65)',
  };
}

function ReasonRow({
  reason,
  first,
  active,
  accent,
  textMain,
  textMuted,
  hairline,
  onPress,
}: Readonly<{
  reason: ReasonOption;
  first: boolean;
  active: boolean;
  accent: string;
  textMain: string;
  textMuted: string;
  hairline: string;
  onPress: () => void;
}>) {
  return (
    <Pressable
      onPress={() => {
        void hapticFeedback('light');
        onPress();
      }}
      style={({ pressed }) => [
        styles.row,
        !first && { borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: hairline },
        (pressed || active) && { backgroundColor: hairline },
      ]}
      accessibilityRole="radio"
      accessibilityState={{ selected: active }}
      accessibilityLabel={reason.label}
    >
      <Ionicons name={reason.icon} size={18} color={active ? textMain : textMuted} />
      <Text style={[styles.rowText, { color: textMain }, active && styles.rowTextActive]} numberOfLines={1}>
        {reason.label}
      </Text>
      {active ? (
        <Reanimated.View entering={FadeIn.duration(150)}>
          <Ionicons name="checkmark" size={18} color={accent} />
        </Reanimated.View>
      ) : null}
    </Pressable>
  );
}

export default function CancelJobReasonSheet({
  visible,
  accent,
  customerName,
  onClose,
  onConfirm,
  onCancelled,
}: CancelJobReasonSheetProps) {
  const insets = useSafeAreaInsets();
  const keyboardHeight = useKeyboardHeight(visible);
  const { textMain, textMuted, panel, groupBg, hairline, handle } = useSheetColours();

  const [selected, setSelected] = useState<string | null>(null);
  const [note, setNote] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const translateY = useRef(new Animated.Value(SCREEN_H)).current;

  useEffect(() => {
    if (!visible) return;
    setSelected(null);
    setNote('');
    setDone(false);
    setSubmitting(false);
    translateY.setValue(SCREEN_H);
    Animated.spring(translateY, { toValue: 0, useNativeDriver: true, damping: 26, stiffness: 260 }).start();
  }, [visible, translateY]);

  const dismiss = useMemo(
    () => () => {
      if (submitting) return;
      Animated.timing(translateY, { toValue: SCREEN_H, duration: 220, useNativeDriver: true }).start(() => onClose());
    },
    [onClose, submitting, translateY]
  );

  const panResponder = useMemo(
    () =>
      PanResponder.create({
        onMoveShouldSetPanResponder: (_, g) => !submitting && !done && g.dy > 6 && Math.abs(g.dy) > Math.abs(g.dx),
        onPanResponderMove: (_, g) => translateY.setValue(Math.max(0, g.dy)),
        onPanResponderRelease: (_, g) => {
          if (g.dy > 110 || g.vy > 0.9) {
            dismiss();
            return;
          }
          Animated.spring(translateY, { toValue: 0, useNativeDriver: true, damping: 22, stiffness: 300 }).start();
        },
      }),
    [dismiss, done, submitting, translateY]
  );

  if (!visible) return null;

  const selectedReason = REASONS.find((r) => r.id === selected) ?? null;
  const needsNote = selected === 'other';
  const canSubmit = !!selectedReason && (!needsNote || note.trim().length >= 3) && !submitting;

  const submit = async () => {
    if (!selectedReason || !canSubmit) return;
    void hapticFeedback('heavy');
    setSubmitting(true);
    const ok = await onConfirm(reasonText(selectedReason, note));
    setSubmitting(false);
    if (!ok) return;
    setDone(true);
    void hapticFeedback('success');
    setTimeout(() => {
      Animated.timing(translateY, { toValue: SCREEN_H, duration: 220, useNativeDriver: true }).start(() => {
        onClose();
        onCancelled();
      });
    }, 1300);
  };

  const backdropOpacity = translateY.interpolate({
    inputRange: [0, SCREEN_H * 0.6],
    outputRange: [1, 0],
    extrapolate: 'clamp',
  });

  return (
    <Modal visible transparent animationType="none" onRequestClose={dismiss} statusBarTranslucent>
      <View style={styles.root}>
        <Animated.View style={[StyleSheet.absoluteFill, styles.backdrop, { opacity: backdropOpacity }]}>
          <Pressable style={StyleSheet.absoluteFill} onPress={dismiss} accessibilityLabel="Keep job" />
        </Animated.View>

        <Animated.View
          style={[
            styles.sheet,
            {
              backgroundColor: panel,
              borderColor: hairline,
              paddingBottom: Math.max(16, insets.bottom + 8),
              marginBottom: keyboardHeight > 0 ? keyboardHeight - insets.bottom : 0,
              transform: [{ translateY }],
            },
          ]}
        >
          {done ? (
            <Reanimated.View entering={FadeIn.duration(200)} style={styles.doneWrap}>
              <Reanimated.View entering={ZoomIn.duration(220)} style={styles.doneIcon}>
                <Ionicons name="checkmark" size={26} color={DONE_GREEN} />
              </Reanimated.View>
              <Text style={[styles.doneTitle, { color: textMain }]}>Job cancelled</Text>
              <Text style={[styles.doneSub, { color: textMuted }]}>We've let {customerName} know.</Text>
            </Reanimated.View>
          ) : (
            <>
              <View {...panResponder.panHandlers}>
                <View style={styles.handleRow}>
                  <View style={[styles.handle, { backgroundColor: handle }]} />
                </View>
                <Text style={[styles.title, { color: textMain }]}>Cancel this job?</Text>
                <Text style={[styles.subtitle, { color: textMuted }]}>
                  Choose a reason. {customerName} is notified straight away.
                </Text>
              </View>

              <Text style={[styles.sectionLabel, { color: textMuted }]}>REASON</Text>
              <View style={[styles.group, { backgroundColor: groupBg }]}>
                {REASONS.map((reason, i) => (
                  <ReasonRow
                    key={reason.id}
                    reason={reason}
                    first={i === 0}
                    active={selected === reason.id}
                    accent={accent}
                    textMain={textMain}
                    textMuted={textMuted}
                    hairline={hairline}
                    onPress={() => setSelected(reason.id)}
                  />
                ))}
              </View>

              {selected ? (
                <Reanimated.View entering={FadeInDown.duration(220)} style={styles.noteWrap}>
                  <TextInput
                    value={note}
                    onChangeText={setNote}
                    placeholder={needsNote ? 'Tell us what happened (required)' : 'Add a note (optional)'}
                    placeholderTextColor="rgba(148,163,184,0.8)"
                    style={[styles.noteInput, { color: textMain, backgroundColor: groupBg }]}
                    multiline
                    maxLength={200}
                    autoFocus={needsNote}
                  />
                </Reanimated.View>
              ) : null}

              <Pressable
                onPress={submit}
                disabled={!canSubmit}
                style={({ pressed }) => [
                  styles.cancelBtn,
                  !canSubmit && styles.cancelBtnDisabled,
                  pressed && canSubmit && styles.pressed,
                ]}
                accessibilityRole="button"
                accessibilityState={{ disabled: !canSubmit }}
              >
                {submitting ? <ActivityIndicator color="#FFFFFF" /> : <Text style={styles.cancelText}>Cancel job</Text>}
              </Pressable>
              <Pressable
                onPress={dismiss}
                hitSlop={6}
                style={({ pressed }) => [styles.keepBtn, pressed && styles.pressed]}
                accessibilityRole="button"
              >
                <Text style={[styles.keepText, { color: textMain }]}>Keep job</Text>
              </Pressable>
            </>
          )}
        </Animated.View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, justifyContent: 'flex-end' },
  backdrop: { backgroundColor: 'rgba(2,6,23,0.6)' },
  sheet: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    borderWidth: StyleSheet.hairlineWidth,
    borderBottomWidth: 0,
    paddingTop: 8,
    paddingHorizontal: 16,
  },
  handleRow: { alignItems: 'center', paddingBottom: 14 },
  handle: { width: 36, height: 4, borderRadius: 2 },
  title: { fontSize: 19, fontWeight: '700', letterSpacing: -0.3 },
  subtitle: { fontSize: 13.5, fontWeight: '500', marginTop: 4, lineHeight: 19 },
  sectionLabel: { marginTop: 18, marginBottom: 6, marginLeft: 4, fontSize: 11, fontWeight: '600', letterSpacing: 1 },
  group: { borderRadius: 14, overflow: 'hidden' },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    minHeight: 48,
    paddingHorizontal: 14,
  },
  rowText: { flex: 1, fontSize: 15, fontWeight: '500' },
  rowTextActive: { fontWeight: '600' },
  noteWrap: { marginTop: 10 },
  noteInput: {
    minHeight: 60,
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 14,
    textAlignVertical: 'top',
  },
  cancelBtn: {
    marginTop: 18,
    minHeight: 50,
    borderRadius: 14,
    backgroundColor: DANGER,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cancelBtnDisabled: { opacity: 0.35 },
  cancelText: { color: '#FFFFFF', fontSize: 15.5, fontWeight: '600' },
  keepBtn: { minHeight: 46, alignItems: 'center', justifyContent: 'center', marginTop: 4 },
  keepText: { fontSize: 15, fontWeight: '600' },
  pressed: { opacity: 0.8 },
  doneWrap: { alignItems: 'center', paddingVertical: 32, gap: 6 },
  doneIcon: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: 'rgba(52,211,153,0.14)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 6,
  },
  doneTitle: { fontSize: 18, fontWeight: '700' },
  doneSub: { fontSize: 14, fontWeight: '500' },
});
