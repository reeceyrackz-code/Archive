import React from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import ValeterDashboardChrome from './ValeterDashboardChrome';

const ICON_AUTH = require('../../../assets/icon-auth.png');

const CARD_H = 64;
const CARD_GAP_TOP = 6;
const CARD_GAP_BOTTOM = 6;
const CARD_MARGIN_H = 12;
const AVATAR = 44;
const BELL = 38;
const ONLINE_GREEN = '#4ADE80';
const OFFLINE_RED = '#F87171';
const MONEY = '#E8C547';

/** Total chrome below safe area (floating card + gaps). */
export const VALETER_MAP_HEADER_BODY = CARD_GAP_TOP + CARD_H + CARD_GAP_BOTTOM;

export function valeterMapHeaderTotalHeight(safeTop: number) {
  return safeTop + VALETER_MAP_HEADER_BODY;
}

export type ValeterMapHeaderProps = Readonly<{
  profileName: string;
  locationLabel: string;
  profilePictureUri?: string | null;
  earnings: number;
  jobsCompleted: number;
  jobRequestCount: number;
  isOnline: boolean;
  accent: string;
  headerGradient: readonly [string, string];
  onProfilePress: () => void;
  onLocationPress: () => void;
  onNotificationsPress: () => void;
  /** Opens the earnings sheet when the take-home figure is tapped. */
  onEarningsPress?: () => void;
  /** Daily take-home goal — drives the thin progress bar under the earnings. */
  dailyGoal?: number;
  /** Live job header — replaces online toggle / valeter location with trip context. */
  trackingMode?: boolean;
  trackingCustomerName?: string;
  trackingLocationLabel?: string;
  /** Owner profile photo (left avatar during tracking). */
  trackingCustomerPhotoUri?: string | null;
  /** Kept for card/preview callers; not shown in the left avatar anymore. */
  trackingVehiclePhotoUri?: string | null;
  trackingEtaMinutes?: number | null;
  trackingPrice?: number | null;
  /** Seconds left while awaiting customer payment (pending_payment). */
  trackingPaymentSecondsLeft?: number | null;
  /** Customer's car on this booking (e.g. "Tesla Model 3"). */
  trackingVehicleLabel?: string | null;
  trackingVehicleReg?: string | null;
  /** Number of cars on the booking — shows "+N" when more than one. */
  trackingVehicleCount?: number;
  /** Opens customer profile card while in tracking mode. */
  onCustomerPress?: () => void;
}>;

function greetingFor(date: Date) {
  const h = date.getHours();
  if (h < 12) return 'Good morning';
  if (h < 18) return 'Good afternoon';
  return 'Good evening';
}

export default function ValeterMapHeader({
  profileName,
  locationLabel,
  profilePictureUri,
  earnings,
  jobsCompleted,
  jobRequestCount,
  isOnline,
  accent,
  headerGradient,
  onProfilePress,
  onLocationPress,
  onNotificationsPress,
  onEarningsPress,
  dailyGoal,
  trackingMode = false,
  trackingCustomerName,
  trackingLocationLabel,
  trackingCustomerPhotoUri,
  trackingVehiclePhotoUri: _trackingVehiclePhotoUri,
  trackingEtaMinutes,
  trackingPrice,
  trackingPaymentSecondsLeft = null,
  trackingVehicleLabel,
  trackingVehicleReg,
  trackingVehicleCount = 0,
  onCustomerPress,
}: ValeterMapHeaderProps) {
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const textMain = theme.textPrimary ?? '#F1F5F9';
  const textMuted = theme.textSecondary ?? 'rgba(241,245,249,0.55)';

  return (
    <View style={[styles.wrap, { paddingTop: insets.top + CARD_GAP_TOP }]} pointerEvents="box-none">
      <LinearGradient
        pointerEvents="none"
        colors={['rgba(6,14,24,0.72)', 'rgba(6,14,24,0.28)', 'transparent']}
        style={[styles.statusScrim, { height: insets.top + CARD_H * 0.9 }]}
      />

      <View style={styles.card}>
        <View style={styles.chromeClip} pointerEvents="none">
          <ValeterDashboardChrome accent={accent} headerGradient={headerGradient} />
          <LinearGradient
            colors={['rgba(255,255,255,0.10)', 'transparent']}
            style={styles.cardSheen}
          />
        </View>

        {trackingMode ? (
          <TrackingRow
            accent={accent}
            textMain={textMain}
            textMuted={textMuted}
            customerName={trackingCustomerName}
            locationLabel={trackingLocationLabel}
            customerPhotoUri={trackingCustomerPhotoUri}
            etaMinutes={trackingEtaMinutes}
            price={trackingPrice}
            paymentSecondsLeft={trackingPaymentSecondsLeft}
            vehicleLabel={trackingVehicleLabel}
            vehicleReg={trackingVehicleReg}
            vehicleCount={trackingVehicleCount}
            onCustomerPress={onCustomerPress}
          />
        ) : (
          <IdleRow
            profileName={profileName}
            locationLabel={locationLabel}
            profilePictureUri={profilePictureUri}
            earnings={earnings}
            jobsCompleted={jobsCompleted}
            jobRequestCount={jobRequestCount}
            isOnline={isOnline}
            accent={accent}
            textMain={textMain}
            textMuted={textMuted}
            dailyGoal={dailyGoal}
            onProfilePress={onProfilePress}
            onLocationPress={onLocationPress}
            onNotificationsPress={onNotificationsPress}
            onEarningsPress={onEarningsPress}
          />
        )}
      </View>
    </View>
  );
}

type RowTheme = Readonly<{
  accent: string;
  textMain: string;
  textMuted: string;
}>;

/* ------------------------------------------------------------------------------------------------
 * Tracking mode (live job): customer tile + identity, ETA / payment-timer capsule.
 * ---------------------------------------------------------------------------------------------- */

type TrackingRowProps = RowTheme &
  Readonly<{
    customerName?: string;
    locationLabel?: string;
    customerPhotoUri?: string | null;
    etaMinutes?: number | null;
    price?: number | null;
    paymentSecondsLeft: number | null;
    vehicleLabel?: string | null;
    vehicleReg?: string | null;
    vehicleCount: number;
    onCustomerPress?: () => void;
  }>;

function TrackingRow({
  accent,
  textMain,
  textMuted,
  customerName,
  locationLabel,
  customerPhotoUri,
  etaMinutes,
  price,
  paymentSecondsLeft,
  vehicleLabel,
  vehicleReg,
  vehicleCount,
  onCustomerPress,
}: TrackingRowProps) {
  const headerLocation = locationLabel?.trim() || 'Customer location';
  const headerName = customerName?.trim() || 'Customer';
  const customerA11y = [`Customer ${headerName}`, vehicleLabel, vehicleReg].filter(Boolean).join(', ');

  return (
    <View style={styles.row}>
      <TouchableOpacity
        onPress={async () => {
          await hapticFeedback('light');
          onCustomerPress?.();
        }}
        disabled={!onCustomerPress}
        activeOpacity={0.85}
        style={styles.customerTap}
        accessibilityRole="button"
        accessibilityLabel={`${customerA11y}. Open profile`}
      >
        <CustomerTile accent={accent} textMain={textMain} name={headerName} photoUri={customerPhotoUri} />

        <View style={styles.identity}>
          <CustomerMetaRow textMuted={textMuted} priceLabel={priceLabelOf(price)} />
          <View style={styles.customerNameRow}>
            <Text style={[styles.customerName, { color: textMain }]} numberOfLines={1}>
              {headerName}
            </Text>
            <Ionicons name="chevron-forward" size={12} color={textMuted} />
          </View>
          <VehicleRow
            accent={accent}
            textMuted={textMuted}
            vehicleLabel={vehicleLabel}
            vehicleReg={vehicleReg}
            vehicleCount={vehicleCount}
            fallbackLabel={headerLocation}
          />
        </View>
      </TouchableOpacity>

      <EtaCapsule
        accent={accent}
        textMuted={textMuted}
        etaMinutes={etaMinutes}
        paymentSecondsLeft={paymentSecondsLeft}
      />
    </View>
  );
}

function CustomerTile({
  accent,
  textMain,
  name,
  photoUri,
}: Readonly<{ accent: string; textMain: string; name: string; photoUri?: string | null }>) {
  return (
    <View style={[styles.customerTile, { borderColor: accent }]}>
      {photoUri ? (
        <Image source={{ uri: photoUri }} style={styles.avatarImg} resizeMode="cover" />
      ) : (
        <View style={[styles.avatarFallback, { backgroundColor: `${accent}33` }]}>
          <Text style={[styles.customerInitials, { color: textMain }]}>
            {initialsOf(name)}
          </Text>
        </View>
      )}
    </View>
  );
}

function CustomerMetaRow({ textMuted, priceLabel }: Readonly<{ textMuted: string; priceLabel: string | null }>) {
  return (
    <View style={styles.customerMetaRow}>
      <Text style={[styles.kicker, { color: textMuted }]} numberOfLines={1}>
        Your customer
      </Text>
      {priceLabel ? (
        <>
          <Text style={[styles.kicker, { color: textMuted }]}>·</Text>
          <Text style={[styles.kicker, styles.customerPrice]} numberOfLines={1}>
            {priceLabel}
          </Text>
        </>
      ) : null}
    </View>
  );
}

function VehicleRow({
  accent,
  textMuted,
  vehicleLabel,
  vehicleReg,
  vehicleCount,
  fallbackLabel,
}: Readonly<{
  accent: string;
  textMuted: string;
  vehicleLabel?: string | null;
  vehicleReg?: string | null;
  vehicleCount: number;
  fallbackLabel: string;
}>) {
  const labelColor = vehicleLabel ? textMuted : accent;
  return (
    <View style={styles.vehicleRow}>
      {vehicleReg ? (
        <View style={styles.plate}>
          <View style={styles.plateBand} />
          <Text style={styles.plateText} numberOfLines={1}>
            {vehicleReg.toUpperCase()}
          </Text>
        </View>
      ) : (
        <Ionicons name={vehicleLabel ? 'car-sport' : 'location'} size={11} color={accent} />
      )}
      <Text style={[styles.vehicleText, { color: labelColor }]} numberOfLines={1}>
        {vehicleLabel || fallbackLabel}
      </Text>
      {vehicleCount > 1 ? (
        <View style={[styles.moreCars, { backgroundColor: `${accent}26`, borderColor: `${accent}55` }]}>
          <Text style={[styles.moreCarsText, { color: accent }]}>+{vehicleCount - 1}</Text>
        </View>
      ) : null}
    </View>
  );
}

function EtaCapsule({
  accent,
  textMuted,
  etaMinutes,
  paymentSecondsLeft,
}: Readonly<{
  accent: string;
  textMuted: string;
  etaMinutes?: number | null;
  paymentSecondsLeft: number | null;
}>) {
  const paymentClock = paymentClockText(paymentSecondsLeft);
  const colors = capsuleColors(accent, paymentSecondsLeft);
  return (
    <View
      style={[
        styles.etaCapsule,
        { borderColor: colors.border, backgroundColor: colors.bg },
      ]}
    >
      <Text
        style={[
          styles.etaValue,
          { color: colors.text },
        ]}
        numberOfLines={1}
      >
        {paymentClock ?? etaText(etaMinutes)}
      </Text>
      <Text style={[styles.etaCaption, { color: textMuted }]}>
        {paymentClock == null ? 'ETA' : 'To pay'}
      </Text>
    </View>
  );
}

/* ------------------------------------------------------------------------------------------------
 * Idle mode: avatar + status dot, greeting / name / location, today's earnings + notifications bell.
 * ---------------------------------------------------------------------------------------------- */

type IdleRowProps = RowTheme &
  Readonly<{
    profileName: string;
    locationLabel: string;
    profilePictureUri?: string | null;
    earnings: number;
    jobsCompleted: number;
    jobRequestCount: number;
    isOnline: boolean;
    dailyGoal?: number;
    onProfilePress: () => void;
    onLocationPress: () => void;
    onNotificationsPress: () => void;
    onEarningsPress?: () => void;
  }>;

function IdleRow({
  profileName,
  locationLabel,
  profilePictureUri,
  earnings,
  jobsCompleted,
  jobRequestCount,
  isOnline,
  accent,
  textMain,
  textMuted,
  dailyGoal,
  onProfilePress,
  onLocationPress,
  onNotificationsPress,
  onEarningsPress,
}: IdleRowProps) {
  return (
    <View style={styles.row}>
      {/* Left: avatar + identity */}
      <View style={styles.side}>
        <ProfileAvatarButton
          accent={accent}
          isOnline={isOnline}
          profilePictureUri={profilePictureUri}
          onPress={onProfilePress}
        />
        <IdleIdentity
          accent={accent}
          textMain={textMain}
          textMuted={textMuted}
          name={profileName || 'Car Care Pro'}
          locationLabel={locationLabel}
          onLocationPress={onLocationPress}
        />
      </View>

      {/* Right: earnings + bell */}
      <View style={[styles.side, styles.sideRight]}>
        <EarningsButton
          textMuted={textMuted}
          earnings={earnings}
          jobsCompleted={jobsCompleted}
          dailyGoal={dailyGoal}
          onPress={onEarningsPress}
        />
        <NotificationsBell
          accent={accent}
          textMain={textMain}
          jobRequestCount={jobRequestCount}
          onPress={onNotificationsPress}
        />
      </View>
    </View>
  );
}

function ProfileAvatarButton({
  accent,
  isOnline,
  profilePictureUri,
  onPress,
}: Readonly<{ accent: string; isOnline: boolean; profilePictureUri?: string | null; onPress: () => void }>) {
  const statusColor = isOnline ? ONLINE_GREEN : OFFLINE_RED;
  return (
    <TouchableOpacity
      onPress={async () => {
        await hapticFeedback('light');
        onPress();
      }}
      disabled={false}
      activeOpacity={0.85}
      style={[styles.avatarRing, { borderColor: statusColor }]}
      accessibilityRole="button"
      accessibilityLabel="Open profile"
    >
      <View style={styles.avatarInner}>
        <AvatarImage trackingMode={false} profilePictureUri={profilePictureUri} accent={accent} />
      </View>
      <View style={[styles.statusDot, { backgroundColor: statusColor }]} />
    </TouchableOpacity>
  );
}

function IdleIdentity({
  accent,
  textMain,
  textMuted,
  name,
  locationLabel,
  onLocationPress,
}: RowTheme & Readonly<{ name: string; locationLabel: string; onLocationPress: () => void }>) {
  return (
    <View style={styles.identity}>
      <Text style={[styles.kicker, { color: textMuted }]} numberOfLines={1}>
        {greetingFor(new Date())}
      </Text>
      <Text style={[styles.name, { color: textMain }]} numberOfLines={1}>
        {name}
      </Text>
      <TouchableOpacity
        onPress={onLocationPress}
        disabled={false}
        activeOpacity={0.75}
        hitSlop={{ top: 6, bottom: 6, left: 4, right: 4 }}
        style={styles.locationRow}
        accessibilityRole="button"
        accessibilityLabel={`Location ${locationLabel}. Change`}
      >
        <Ionicons name="location" size={10} color={accent} />
        <Text style={[styles.location, { color: accent }]} numberOfLines={1}>
          {locationLabel}
        </Text>
        <Ionicons name="chevron-down" size={10} color={accent} />
      </TouchableOpacity>
    </View>
  );
}

function EarningsButton({
  textMuted,
  earnings,
  jobsCompleted,
  dailyGoal,
  onPress,
}: Readonly<{
  textMuted: string;
  earnings: number;
  jobsCompleted: number;
  dailyGoal?: number;
  onPress?: () => void;
}>) {
  const jobsSuffix = jobsCompleted === 1 ? '' : 's';
  return (
    <TouchableOpacity
      onPress={async () => {
        await hapticFeedback('light');
        onPress?.();
      }}
      disabled={!onPress}
      activeOpacity={0.75}
      hitSlop={{ top: 8, bottom: 8, left: 8, right: 4 }}
      style={styles.moneyCol}
      accessibilityRole="button"
      accessibilityLabel={`Today's take-home £${earnings.toFixed(2)}, ${jobsCompleted} jobs. Open earnings`}
    >
      <Text style={[styles.kicker, styles.textRight, { color: textMuted }]} numberOfLines={1}>
        Today · {jobsCompleted} job{jobsSuffix}
      </Text>
      <Text style={[styles.money, { color: MONEY }]} numberOfLines={1} adjustsFontSizeToFit>
        £{earnings.toFixed(2)}
      </Text>
      {dailyGoal ? <GoalBar earnings={earnings} dailyGoal={dailyGoal} /> : null}
    </TouchableOpacity>
  );
}

function GoalBar({ earnings, dailyGoal }: Readonly<{ earnings: number; dailyGoal: number }>) {
  const goalProgress = Math.min(1, Math.max(0, earnings / dailyGoal));
  const goalHit = earnings >= dailyGoal;
  return (
    <View style={styles.goalTrack}>
      <View
        style={[
          styles.goalFill,
          {
            width: `${goalProgress * 100}%`,
            backgroundColor: goalHit ? '#34D399' : MONEY,
          },
        ]}
      />
    </View>
  );
}

function NotificationsBell({
  accent,
  textMain,
  jobRequestCount,
  onPress,
}: Readonly<{ accent: string; textMain: string; jobRequestCount: number; onPress: () => void }>) {
  const hasRequests = jobRequestCount > 0;
  return (
    <TouchableOpacity
      onPress={async () => {
        await hapticFeedback('light');
        onPress();
      }}
      activeOpacity={0.8}
      style={[styles.bell, { borderColor: `${accent}40`, backgroundColor: `${accent}14` }]}
      accessibilityRole="button"
      accessibilityLabel={hasRequests ? `${jobRequestCount} notifications` : 'Notifications'}
    >
      <Ionicons name="notifications-outline" size={18} color={textMain} />
      {hasRequests ? (
        <View style={styles.badge}>
          <Text style={styles.badgeText}>{badgeText(jobRequestCount)}</Text>
        </View>
      ) : null}
    </TouchableOpacity>
  );
}

function priceLabelOf(price: number | null | undefined) {
  if (price == null || !Number.isFinite(Number(price))) return null;
  return `£${Number(price).toFixed(2)}`;
}

/** `m:ss` countdown while awaiting customer payment; null when no timer is running. */
function paymentClockText(secondsLeft: number | null) {
  if (secondsLeft == null || !Number.isFinite(secondsLeft)) return null;
  const s = Math.max(0, Math.floor(secondsLeft));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${m}:${r.toString().padStart(2, '0')}`;
}

function capsuleColors(accent: string, paymentSecondsLeft: number | null) {
  if (paymentSecondsLeft == null || !Number.isFinite(paymentSecondsLeft)) {
    return { border: `${accent}55`, bg: `${accent}14`, text: accent };
  }
  if (paymentSecondsLeft <= 60) {
    return { border: `${OFFLINE_RED}66`, bg: 'rgba(248,113,113,0.12)', text: OFFLINE_RED };
  }
  return { border: 'rgba(251,191,36,0.4)', bg: 'rgba(251,191,36,0.10)', text: '#FBBF24' };
}

function badgeText(count: number) {
  return count > 9 ? '9+' : String(count);
}

function etaText(minutes: number | null | undefined) {
  if (minutes == null || !Number.isFinite(minutes)) return '—';
  if (minutes <= 0) return 'Here';
  return `${Math.max(1, Math.round(minutes))} min`;
}

/** Left avatar: the customer while on a job (photo or person glyph), otherwise the Pro's own picture. */
function AvatarImage({
  trackingMode,
  customerPhotoUri,
  profilePictureUri,
  accent,
}: Readonly<{ trackingMode: boolean; customerPhotoUri?: string | null; profilePictureUri?: string | null; accent: string }>) {
  if (!trackingMode) {
    return (
      <Image source={profilePictureUri ? { uri: profilePictureUri } : ICON_AUTH} style={styles.avatarImg} resizeMode="cover" />
    );
  }
  if (customerPhotoUri) {
    return <Image source={{ uri: customerPhotoUri }} style={styles.avatarImg} resizeMode="cover" />;
  }
  return (
    <View style={[styles.avatarFallback, { backgroundColor: `${accent}22` }]}>
      <Ionicons name="person" size={20} color={accent} />
    </View>
  );
}

function initialsOf(name: string) {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  const letters = parts.length > 1 ? parts[0][0] + parts.at(-1)![0] : (parts[0] ?? '?').slice(0, 2);
  return letters.toUpperCase();
}

const styles = StyleSheet.create({
  wrap: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 20,
    paddingHorizontal: CARD_MARGIN_H,
    paddingBottom: CARD_GAP_BOTTOM,
    overflow: 'visible',
  },
  statusScrim: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
  },
  card: {
    height: CARD_H,
    borderRadius: 24,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.32,
    shadowRadius: 18,
    elevation: 12,
  },
  chromeClip: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    borderRadius: 23,
    overflow: 'hidden',
    opacity: 0.72,
  },
  cardSheen: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: CARD_H / 2,
  },
  row: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
  },
  side: {
    flex: 1,
    minWidth: 0,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
  },
  sideRight: {
    justifyContent: 'flex-end',
    gap: 8,
  },
  avatarRing: {
    width: AVATAR,
    height: AVATAR,
    borderRadius: AVATAR / 2,
    borderWidth: 2,
    padding: 2,
  },
  avatarInner: {
    flex: 1,
    borderRadius: AVATAR / 2,
    overflow: 'hidden',
  },
  avatarImg: {
    width: '100%',
    height: '100%',
  },
  avatarFallback: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  statusDot: {
    position: 'absolute',
    bottom: -1,
    right: -1,
    width: 12,
    height: 12,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: '#0A1929',
  },
  identity: {
    flex: 1,
    minWidth: 0,
  },
  kicker: {
    fontSize: 9.5,
    fontWeight: '700',
    letterSpacing: 0.4,
    textTransform: 'uppercase',
  },
  textRight: {
    textAlign: 'right',
  },
  name: {
    fontSize: 14,
    fontWeight: '800',
    letterSpacing: -0.3,
    marginTop: 1,
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    marginTop: 2,
  },
  location: {
    fontSize: 10.5,
    fontWeight: '700',
    flexShrink: 1,
  },
  center: {
    paddingHorizontal: 6,
    height: CARD_H,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 5,
  },
  etaCapsule: {
    minWidth: 68,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 16,
    borderWidth: 1,
    alignItems: 'center',
  },
  etaValue: {
    fontSize: 17,
    fontWeight: '900',
    letterSpacing: -0.4,
  },
  etaCaption: {
    fontSize: 8.5,
    fontWeight: '800',
    letterSpacing: 0.6,
    textTransform: 'uppercase',
    marginTop: 1,
  },
  moneyCol: {
    flexShrink: 1,
    minWidth: 0,
    alignItems: 'flex-end',
  },
  money: {
    fontSize: 17,
    fontWeight: '900',
    letterSpacing: -0.5,
    marginTop: 1,
  },
  goalTrack: {
    width: 52,
    height: 3,
    borderRadius: 2,
    marginTop: 4,
    backgroundColor: 'rgba(148,163,184,0.25)',
    overflow: 'hidden',
  },
  goalFill: {
    height: '100%',
    borderRadius: 2,
  },
  bell: {
    width: BELL,
    height: BELL,
    borderRadius: BELL / 2,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  badge: {
    position: 'absolute',
    top: -3,
    right: -3,
    minWidth: 17,
    height: 17,
    paddingHorizontal: 4,
    borderRadius: 9,
    backgroundColor: '#EF4444',
    borderWidth: 1.5,
    borderColor: '#0A1929',
    alignItems: 'center',
    justifyContent: 'center',
  },
  badgeText: {
    color: '#FFFFFF',
    fontSize: 9,
    fontWeight: '900',
  },
  customerTap: {
    flex: 1,
    minWidth: 0,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginRight: 8,
  },
  customerTile: {
    width: AVATAR,
    height: AVATAR,
    borderRadius: 14,
    borderWidth: 1.5,
    overflow: 'hidden',
  },
  customerInitials: {
    fontSize: 15,
    fontWeight: '900',
    letterSpacing: 0.3,
  },
  customerMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  customerPrice: {
    color: MONEY,
    fontWeight: '900',
  },
  customerNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    marginTop: 1,
  },
  customerName: {
    flexShrink: 1,
    fontSize: 15,
    fontWeight: '800',
    letterSpacing: -0.3,
  },
  vehicleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    marginTop: 2,
  },
  plate: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 14,
    borderRadius: 3,
    backgroundColor: '#FACC15',
    overflow: 'hidden',
    paddingRight: 4,
  },
  plateBand: {
    width: 4,
    height: '100%',
    backgroundColor: '#1D4ED8',
    marginRight: 3,
  },
  plateText: {
    color: '#0A0A0A',
    fontSize: 9.5,
    fontWeight: '900',
    letterSpacing: 0.4,
  },
  vehicleText: {
    flexShrink: 1,
    fontSize: 10.5,
    fontWeight: '700',
  },
  moreCars: {
    paddingHorizontal: 5,
    borderRadius: 6,
    borderWidth: 1,
  },
  moreCarsText: {
    fontSize: 9.5,
    fontWeight: '900',
  },
});
