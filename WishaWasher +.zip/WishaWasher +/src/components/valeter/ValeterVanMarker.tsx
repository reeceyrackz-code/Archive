import React, { useEffect, useRef } from 'react';
import { Animated, Easing, Image, StyleSheet, View } from 'react-native';
import { VALETER_VAN_ASPECT, VALETER_VAN_IMAGE } from '../../constants/washerAssets';

/**
 * The Pro's own position on a map: branded van over a soft accent halo. The artwork faces right.
 * `heading` (degrees clockwise from screen-up) points the van's nose the way the Pro is driving;
 * pass the travel bearing minus the map's camera heading so it stays right when the map rotates.
 */
export default function ValeterVanMarker({
  width = 56,
  accent = '#38BDF8',
  heading = null,
}: Readonly<{ width?: number; accent?: string; heading?: number | null }>) {
  const height = Math.round(width / VALETER_VAN_ASPECT);
  const boxW = width + 12;
  const boxH = height + 12;
  const turning = heading != null;
  const side = Math.max(boxW, boxH);

  /* Art faces right (90°), so the nose sits at heading - 90. Unwrapped so it always turns the short way. */
  const target = turning ? heading - 90 : 0;
  const angleRef = useRef(target);
  const angle = useRef(new Animated.Value(target)).current;
  useEffect(() => {
    const delta = ((((target - angleRef.current) % 360) + 540) % 360) - 180;
    if (Math.abs(delta) < 1) return;
    angleRef.current += delta;
    Animated.timing(angle, {
      toValue: angleRef.current,
      duration: 450,
      easing: Easing.out(Easing.quad),
      useNativeDriver: true,
    }).start();
  }, [target, angle]);
  const rotate = angle.interpolate({ inputRange: [-360, 360], outputRange: ['-360deg', '360deg'], extrapolate: 'extend' });

  return (
    <View style={[styles.wrap, turning ? { width: side, height: side } : { width: boxW, height: boxH }]} collapsable={false}>
      <Animated.View style={[styles.wrap, { width: boxW, height: boxH }, turning && { transform: [{ rotate }] }]}>
        <View
          style={[
            styles.halo,
            { width: width * 0.8, height: height * 1.1, borderRadius: height, backgroundColor: `${accent}33`, shadowColor: accent },
          ]}
        />
        <Image source={VALETER_VAN_IMAGE} style={{ width, height }} resizeMode="contain" />
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { alignItems: 'center', justifyContent: 'center' },
  halo: {
    position: 'absolute',
    shadowOpacity: 0.8,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 0 },
  },
});
