import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Image, Pressable, StyleSheet, Switch, Text, View, type ImageSourcePropType } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import InfoBottomSheet from '../shared/InfoBottomSheet';
import { toast } from '../shared/ToastHost';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { NAV_APP_LABEL, navAppsForPlatform, openNavApp, type NavApp } from '../../utils/externalMaps';

type NavChoice = 'in_app' | NavApp;

const PREF_KEY = 'valeter_nav_app_pref_v1';

const OPTION: Record<NavChoice, { title: string; sub: string; logo: ImageSourcePropType }> = {
  in_app: {
    title: 'Wish Map',
    sub: 'Voice directions and arrival spotted for you',
    logo: require('../../../assets/auth-mascot.png'),
  },
  apple: { title: NAV_APP_LABEL.apple, sub: 'Turn-by-turn in Apple Maps', logo: require('../../../assets/nav-apps/apple-maps.jpg') },
  google: { title: NAV_APP_LABEL.google, sub: 'Turn-by-turn in Google Maps', logo: require('../../../assets/nav-apps/google-maps.jpg') },
  waze: { title: NAV_APP_LABEL.waze, sub: 'Live traffic and police alerts', logo: require('../../../assets/nav-apps/waze.jpg') },
};

const listeners = new Set<() => void>();

/** Re-open the picker (e.g. from the sat-nav header) to switch apps mid-drive. */
export function requestNavAppPicker() {
  listeners.forEach((l) => l());
}

async function loadPref(): Promise<NavChoice | null> {
  try {
    const raw = await AsyncStorage.getItem(PREF_KEY);
    return raw === 'in_app' || raw === 'apple' || raw === 'google' || raw === 'waze' ? raw : null;
  } catch {
    return null;
  }
}

async function savePref(choice: NavChoice | null) {
  try {
    if (choice) await AsyncStorage.setItem(PREF_KEY, choice);
    else await AsyncStorage.removeItem(PREF_KEY);
  } catch {
    /* preference is best-effort */
  }
}

type Destination = Readonly<{ address?: string | null; latitude?: number | null; longitude?: number | null }>;

async function launch(app: NavApp, destination: Destination) {
  try {
    await openNavApp(app, destination);
    toast.info('Your trip is still tracked here. Come back to mark arrived.', `Opening ${NAV_APP_LABEL[app]}`);
  } catch {
    toast.error(`Couldn't open ${NAV_APP_LABEL[app]}.`, 'Navigation');
  }
}

/**
 * Asks how the Pro wants to drive to the job the moment they set off: our sat-nav or their usual maps
 * app. A remembered choice skips the question next time.
 */
export default function NavAppPickerSheet({
  enabled,
  isPreview = false,
  status,
  jobId,
  destination,
  accent,
}: Readonly<{
  enabled: boolean;
  /** Sample trip: ask whenever the preview switches to On the way. */
  isPreview?: boolean;
  status: string | null;
  jobId: string | null;
  destination: Destination;
  accent: string;
}>) {
  const [open, setOpen] = useState(false);
  const [pref, setPref] = useState<NavChoice | null>(null);
  const [remember, setRemember] = useState(false);
  const last = useRef<{ jobId: string | null; status: string | null }>({ jobId, status });
  const destRef = useRef(destination);
  destRef.current = destination;

  const showPicker = useCallback(async () => {
    const saved = await loadPref();
    setPref(saved);
    setRemember(saved != null);
    setOpen(true);
  }, []);

  useEffect(() => {
    if (!enabled) return;
    const l = () => void showPicker();
    listeners.add(l);
    return () => {
      listeners.delete(l);
    };
  }, [enabled, showPicker]);

  useEffect(() => {
    const prev = last.current;
    last.current = { jobId, status };
    const changed = isPreview || (prev.jobId === jobId && prev.status != null);
    const setOff = enabled && changed && status === 'en_route' && prev.status !== 'en_route';
    if (!setOff) return;
    void (async () => {
      const saved = await loadPref();
      if (saved == null || isPreview) {
        void showPicker();
        return;
      }
      if (saved !== 'in_app') void launch(saved, destRef.current);
    })();
  }, [enabled, isPreview, jobId, status, showPicker]);

  const choose = async (choice: NavChoice) => {
    void hapticFeedback('medium');
    setOpen(false);
    await savePref(remember ? choice : null);
    if (choice !== 'in_app') await launch(choice, destRef.current);
  };

  const choices: NavChoice[] = ['in_app', ...navAppsForPlatform()];

  return (
    <InfoBottomSheet visible={open && enabled} onClose={() => setOpen(false)} title="How do you want to navigate?" accentColor={accent} variant="header" sizeToContent>
      <View style={styles.root}>
        {choices.map((c) => {
          const o = OPTION[c];
          const current = pref === c;
          return (
            <Pressable
              key={c}
              onPress={() => void choose(c)}
              style={({ pressed }) => [
                styles.row,
                current && { borderColor: `${accent}88`, backgroundColor: `${accent}14` },
                pressed && styles.pressed,
              ]}
              accessibilityRole="button"
              accessibilityLabel={o.title}
            >
              <Image source={o.logo} style={styles.icon} resizeMode="cover" accessibilityIgnoresInvertColors />

              <View style={styles.copy}>
                <Text style={styles.title}>{o.title}</Text>
                <Text style={styles.sub} numberOfLines={1}>
                  {o.sub}
                </Text>
              </View>
              <Ionicons name={current ? 'checkmark-circle' : 'chevron-forward'} size={18} color={current ? accent : 'rgba(203,213,225,0.5)'} />
            </Pressable>
          );
        })}

        <View style={styles.rememberRow}>
          <View style={styles.copy}>
            <Text style={styles.rememberTitle}>Remember my choice</Text>
            <Text style={styles.sub}>Switch any time with the map button up top</Text>
          </View>
          <Switch
            value={remember}
            onValueChange={(v) => {
              void hapticFeedback('light');
              setRemember(v);
            }}
            trackColor={{ true: accent, false: 'rgba(255,255,255,0.15)' }}
          />
        </View>
      </View>
    </InfoBottomSheet>
  );
}

const styles = StyleSheet.create({
  root: { gap: 10, paddingBottom: 8 },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 12,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    backgroundColor: 'rgba(255,255,255,0.04)',
  },
  pressed: { opacity: 0.75 },
  icon: {
    width: 42,
    height: 42,
    borderRadius: 11,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(255,255,255,0.18)',
    overflow: 'hidden',
  },
  copy: { flex: 1, minWidth: 0, gap: 2 },
  title: { color: '#F8FAFC', fontSize: 15, fontWeight: '800' },
  sub: { color: 'rgba(203,213,225,0.75)', fontSize: 12, fontWeight: '600' },
  rememberRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 4, paddingTop: 6 },
  rememberTitle: { color: '#F8FAFC', fontSize: 14, fontWeight: '700' },
});
