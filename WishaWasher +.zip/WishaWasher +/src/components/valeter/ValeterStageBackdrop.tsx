import React from 'react';
import { StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import type { RouteTurn } from '../../utils/routeTurnAhead';
import ValeterJobScene from './ValeterJobScene';

export type ValeterBackdropStage = 'gate' | 'road' | 'washing' | 'done';

export type ValeterGateInput = Readonly<{
  phase: 'payment' | 'paid';
  secondsLeft: number | null;
  earned: number | null;
  customerName: string;
  customerPhoto: string | null;
  selfPhoto?: string | null;
}>;

export type ValeterRoadInput = Readonly<{
  phase: 'en_route' | 'arrived';
  etaMin: number | null;
  miles: number | null;
  customerName: string;
  customerPhoto: string | null;
  selfPhoto?: string | null;
  /** Next bend on the real route, if any. */
  turn?: RouteTurn | null;
  /** Within ~100 m of the customer but not yet marked arrived. */
  nearby?: boolean;
  voiceMuted?: boolean;
  onToggleVoice?: () => void;
}>;

export type ValeterBackdropJob = Readonly<{
  id: string | null;
  serviceType: string | null;
  serviceName: string | null;
  washType: string | null;
  addOnIds: string | null;
  updatedAt: string | null;
  earned: number | null;
  isPreview: boolean;
  vehicleReg: string | null;
  vehicleColour: string | null;
  vehicleLabel: string | null;
  vehiclePhoto: string | null;
  vehicleCount: number;
  status: string | null;
  customerName: string;
  street: string | null;
}>;

export function backdropStageFor(status: string | null | undefined): ValeterBackdropStage | null {
  switch (status) {
    case 'pending_payment':
    case 'confirmed':
      return 'gate';
    case 'en_route':
    case 'arrived':
      return 'road';
    case 'in_progress':
      return 'washing';
    case 'completed':
      return 'done';
    default:
      return null;
  }
}

/**
 * Trip chrome over the map. The drive keeps the live sat-nav map; every other stage swaps it for the
 * customer's real car (see ValeterJobScene).
 */
export default function ValeterStageBackdrop({
  stage,
  accent,
  job,
  topInset,
  bottomInset,
}: Readonly<{
  stage: ValeterBackdropStage | null;
  accent: string;
  gate: ValeterGateInput | null;
  trip: ValeterRoadInput | null;
  job: ValeterBackdropJob;
  topInset: number;
  bottomInset: number;
  hudRightInset?: number;
}>) {
  if (!stage) return null;
  if (job.status === 'en_route') {
    return (
      <LinearGradient
        pointerEvents="none"
        colors={['rgba(2,6,23,0.7)', 'rgba(2,6,23,0)']}
        style={[styles.scrim, { top: 0, height: topInset + 24 }]}
      />
    );
  }
  return <ValeterJobScene job={job} accent={accent} topInset={topInset} bottomInset={bottomInset} />;
}

const styles = StyleSheet.create({
  scrim: { position: 'absolute', left: 0, right: 0, zIndex: 12 },
});
