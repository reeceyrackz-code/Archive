import { useEffect, useRef, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { washJourneyProgress, type BookingJourney } from '../../../utils/washJourney';

/** Scenes draw from just under the journey HUD; all status text lives in the trip sheet. */
export function sceneTop(topInset: number) {
  return topInset + 52;
}

export function firstName(name: string, fallback = 'Customer') {
  return name.trim().split(/\s+/)[0] || fallback;
}

export function clock(sec: number) {
  const s = Math.max(0, Math.round(sec));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

export function formatTimeLeft(ms: number): string {
  if (ms <= 0) return 'Finishing';
  const mins = Math.ceil(ms / 60000);
  if (mins <= 1) return '<1 min';
  if (mins >= 60) {
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    const rest = m ? ` ${m}m` : '';
    return `${h}h${rest}`;
  }
  return `${mins} min`;
}

export function useNow(intervalMs = 1000) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), intervalMs);
    return () => clearInterval(id);
  }, [intervalMs]);
  return now;
}

/** Counts down locally between server updates so the timer never stalls. */
export function useCountdown(secondsLeft: number | null) {
  const deadline = useRef<number | null>(null);
  useNow(1000);
  if (secondsLeft != null) {
    const next = Date.now() + secondsLeft * 1000;
    if (deadline.current == null || Math.abs(deadline.current - next) > 2500) deadline.current = next;
  }
  return deadline.current != null ? Math.max(0, (deadline.current - Date.now()) / 1000) : null;
}

/** When the wash started, remembered per job so the journey survives app restarts. */
export function useWashStartedAt(jobId: string | null, updatedAt: string | null | undefined, isPreview: boolean, active: boolean) {
  const [startedAt, setStartedAt] = useState<number | null>(null);
  useEffect(() => {
    if (!active) return;
    if (isPreview || !jobId) {
      setStartedAt(Date.now());
      return;
    }
    let cancelled = false;
    const key = `wishawasher:washStartedAt:${jobId}`;
    void (async () => {
      let started = Number.NaN;
      try {
        const raw = await AsyncStorage.getItem(key);
        started = raw ? Number(raw) : Number.NaN;
      } catch {
        /* fall through to a fresh start time */
      }
      if (!Number.isFinite(started)) {
        const fromRow = updatedAt ? Date.parse(updatedAt) : Number.NaN;
        started = Number.isFinite(fromRow) && fromRow <= Date.now() ? fromRow : Date.now();
        try {
          await AsyncStorage.setItem(key, String(started));
        } catch {
          /* journey still runs for this session */
        }
      }
      if (!cancelled) setStartedAt(started);
    })();
    return () => {
      cancelled = true;
    };
  }, [jobId, updatedAt, isPreview, active]);
  return startedAt;
}

export type WashLive = Readonly<{
  startedAt: number | null;
  /** 0–1 of the estimated job time used so far (stays under 1 until the Pro marks the job complete). */
  progress: number;
  estimateMs: number;
  timeLeftMs: number | null;
}>;

/** The job clock: time on the job against the booking's estimate. No steps for the Pro to tick. */
export function useWashLive(
  journey: BookingJourney,
  opts: Readonly<{ jobId: string | null; updatedAt: string | null | undefined; isPreview: boolean; active: boolean }>
): WashLive {
  const startedAt = useWashStartedAt(opts.jobId, opts.updatedAt, opts.isPreview, opts.active);
  const nowMs = useNow(1000);
  const estimateMs = journey.estimateMs;
  return {
    startedAt,
    progress: opts.active && startedAt != null ? washJourneyProgress(startedAt, estimateMs, nowMs) : 0,
    estimateMs,
    timeLeftMs: startedAt == null ? null : startedAt + estimateMs - nowMs,
  };
}
