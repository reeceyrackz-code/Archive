import React from 'react';
import { StyleSheet, View, type StyleProp, type ViewStyle } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph } from '../../shared/ChromeGlyph';
import type { IconGlyphName } from '../../shared/iconGlyphTypes';

export type OrbPalette = {
  gradient: readonly [string, string, string];
  icon: string;
  rim: string;
  glow: string;
};

function parseHex(hex: string): [number, number, number] | null {
  const m = /^#?([0-9a-f]{3}|[0-9a-f]{6})(?:[0-9a-f]{2})?$/i.exec(hex.trim());
  if (!m) return null;
  let h = m[1]!;
  if (h.length === 3) h = h.split('').map((c) => c + c).join('');
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
}

const mix = (c: number, target: number, t: number) => Math.round(c + (target - c) * t);

/** Glass well palette derived from any hex accent. */
export function orbPalette(accent: string): OrbPalette {
  const rgb = parseHex(accent) ?? [56, 189, 248];
  const [r, g, b] = rgb;
  const rgba = (rr: number, gg: number, bb: number, a: number) => `rgba(${rr},${gg},${bb},${a})`;
  return {
    gradient: [
      rgba(r, g, b, 0.52),
      rgba(mix(r, 0, 0.15), mix(g, 0, 0.15), mix(b, 0, 0.15), 0.3),
      rgba(mix(r, 0, 0.75), mix(g, 0, 0.75), mix(b, 0, 0.7), 0.34),
    ],
    icon: rgba(mix(r, 255, 0.82), mix(g, 255, 0.82), mix(b, 255, 0.82), 1),
    rim: rgba(mix(r, 255, 0.35), mix(g, 255, 0.35), mix(b, 255, 0.35), 0.52),
    glow: parseHex(accent) ? accent : '#38BDF8',
  };
}

export default function GlassOrb({
  icon,
  accent,
  size = 44,
  glow = true,
  style,
}: Readonly<{
  icon: IconGlyphName;
  accent: string;
  size?: number;
  glow?: boolean;
  style?: StyleProp<ViewStyle>;
}>) {
  const p = orbPalette(accent);
  return (
    <View
      style={[
        styles.well,
        {
          width: size,
          height: size,
          borderRadius: size / 2,
          shadowColor: p.glow,
          shadowRadius: Math.max(4, size * 0.2),
          shadowOffset: { width: 0, height: Math.max(2, size * 0.08) },
          shadowOpacity: glow ? 0.32 : 0,
          elevation: glow ? 6 : 0,
        },
        style,
      ]}
    >
      <View style={[StyleSheet.absoluteFill, styles.clip, { borderRadius: size / 2 }]} pointerEvents="none">
        <LinearGradient colors={[...p.gradient]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} />
        <LinearGradient
          colors={['rgba(255,255,255,0.28)', 'rgba(255,255,255,0.04)', 'transparent']}
          start={{ x: 0.2, y: 0 }}
          end={{ x: 0.8, y: 1 }}
          style={StyleSheet.absoluteFill}
        />
      </View>
      <View pointerEvents="none" style={[styles.rim, { borderColor: p.rim, borderRadius: size / 2 }]} />
      <ChromeGlyph name={icon} size={Math.round(size * 0.5)} color={p.icon} />
    </View>
  );
}

const styles = StyleSheet.create({
  well: { alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(2,10,24,0.28)' },
  clip: { overflow: 'hidden' },
  rim: { ...StyleSheet.absoluteFill, borderWidth: 1 },
});
