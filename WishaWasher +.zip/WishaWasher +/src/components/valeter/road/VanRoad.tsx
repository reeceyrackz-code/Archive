import React, { useEffect, useMemo } from 'react';
import { Image, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import Animated, {
  Easing,
  Extrapolation,
  interpolate,
  interpolateColor,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withTiming,
  type SharedValue,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph } from '../../shared/ChromeGlyph';
import type { IconGlyphName } from '../../shared/iconGlyphTypes';
import GlassOrb from './GlassOrb';

const VAN_ART = require('../../../../assets/tracking-van-pin.png');
/** Art is a top-down van facing right; width / height. */
const VAN_RATIO = 300 / 143;

export type RoadLandmark = Readonly<{
  /** Unique per landmark; used as the React key. */
  id: string;
  accent: string;
  icon: IconGlyphName;
  label?: string;
  done?: boolean;
  dim?: boolean;
}>;

const DASH_W = 22;
const DASH_GAP = 26;
const DASH_PERIOD = DASH_W + DASH_GAP;
const MAX_MARKER = 44;
const MIN_MARKER = 30;
const MIN_ROAD = 52;
/** Space each stop needs beyond its orb: road gap + label gap + label line. */
const STOP_PAD = 8 + 5 + 16;

/** Van's fixed x and the spacing between stops, both relative to the window width. */
export function roadGeometry(width: number, stepRatio = 0.34) {
  return { vanX: width * 0.36, stepDist: width * stepRatio };
}

/**
 * Side-on road with the Wish-a-Wash van driving right. Advancing `progress` drives the van forward:
 * lane dashes scroll and roadside stops pass by above and below the road.
 */
export default function VanRoad({
  progress,
  landmarks,
  height,
  stepRatio = 0.34,
}: Readonly<{
  progress: SharedValue<number>;
  landmarks: readonly RoadLandmark[];
  height: number;
  stepRatio?: number;
}>) {
  const { width } = useWindowDimensions();
  const marker = Math.max(MIN_MARKER, Math.min(MAX_MARKER, Math.floor((height - MIN_ROAD - 2 * STOP_PAD) / 2)));
  const roadH = Math.max(MIN_ROAD, Math.min(92, height - 2 * (marker + STOP_PAD)));
  const roadY = height / 2;
  const vanW = Math.min(width * 0.38, roadH * 2.1);
  const vanH = vanW / VAN_RATIO;
  const { vanX, stepDist } = roadGeometry(width, stepRatio);
  const reach = 0.5 / stepRatio;
  const dashCount = Math.ceil(width / DASH_PERIOD) + 2;
  const accents = useMemo(() => landmarks.map((l) => l.accent), [landmarks]);
  const stops = useMemo(() => landmarks.map((_, i) => i), [landmarks]);

  const idle = useSharedValue(0);
  useEffect(() => {
    idle.value = withRepeat(
      withSequence(
        withTiming(1, { duration: 1400, easing: Easing.inOut(Easing.sin) }),
        withTiming(0, { duration: 1400, easing: Easing.inOut(Easing.sin) })
      ),
      -1
    );
  }, [idle]);

  const dashesStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: -((progress.value * stepDist) % DASH_PERIOD) }],
  }));

  const vanStyle = useAnimatedStyle(() => {
    const frac = progress.value - Math.floor(progress.value);
    const surge = Math.sin(frac * Math.PI);
    const dir = Math.floor(progress.value) % 2 === 0 ? 1 : -1;
    return {
      transform: [
        { translateX: surge * 16 },
        { translateY: surge * 3 * dir - idle.value * 1.2 },
        { rotate: `${surge * 2.2 * dir}deg` },
        { scale: 1 + surge * 0.04 },
      ],
    };
  });

  const glowStyle = useAnimatedStyle(() => ({
    backgroundColor: accents.length > 1 ? interpolateColor(progress.value, stops, accents) : (accents[0] ?? '#38BDF8'),
    opacity: 0.18 + idle.value * 0.07,
  }));

  const streakStyle = useAnimatedStyle(() => {
    const frac = progress.value - Math.floor(progress.value);
    return {
      opacity: Math.sin(frac * Math.PI) * 0.7,
      transform: [{ translateX: 20 - ((progress.value * stepDist * 1.6) % 60) }],
    };
  });

  return (
    <View style={[styles.root, { height }]} pointerEvents="none">
      <LinearGradient
        colors={['transparent', 'rgba(148,163,184,0.14)', 'rgba(148,163,184,0.14)', 'transparent']}
        locations={[0, 0.15, 0.85, 1]}
        start={{ x: 0, y: 0.5 }}
        end={{ x: 1, y: 0.5 }}
        style={[styles.road, { height: roadH, top: roadY - roadH / 2 }]}
      />

      <View style={[styles.dashClip, { top: roadY - 2, width }]}>
        <Animated.View style={[styles.dashRow, dashesStyle]}>
          {Array.from({ length: dashCount }, (_, i) => (
            <View key={i} style={[styles.dash, { opacity: dashOpacity(i * DASH_PERIOD, width) }]} />
          ))}
        </Animated.View>
      </View>

      {landmarks.map((l, i) => (
        <Stop
          key={l.id}
          index={i}
          landmark={l}
          progress={progress}
          vanX={vanX}
          stepDist={stepDist}
          roadY={roadY}
          roadH={roadH}
          marker={marker}
          reach={reach}
        />
      ))}

      <Animated.View
        style={[
          styles.glow,
          { width: vanW * 0.8, height: roadH * 0.75, left: vanX - vanW * 0.4, top: roadY - roadH * 0.375 },
          glowStyle,
        ]}
      />

      <Animated.View style={[styles.streaks, { left: vanX - vanW / 2 - 56, top: roadY - vanH / 2 + 4 }, streakStyle]}>
        <View style={styles.streak} />
        <View style={[styles.streak, styles.streakShort]} />
      </Animated.View>
      <Animated.View style={[styles.streaks, { left: vanX - vanW / 2 - 48, top: roadY + vanH / 2 - 14 }, streakStyle]}>
        <View style={[styles.streak, styles.streakShort]} />
        <View style={styles.streak} />
      </Animated.View>

      <Animated.View
        style={[styles.van, { width: vanW, height: vanH, left: vanX - vanW / 2, top: roadY - vanH / 2 }, vanStyle]}
      >
        <View style={[styles.vanShadow, { width: vanW * 0.92, height: vanH * 0.8, borderRadius: vanH * 0.3 }]} />
        <Image source={VAN_ART} style={styles.vanImage} resizeMode="contain" />
      </Animated.View>
    </View>
  );
}

function dashOpacity(x: number, width: number) {
  const edge = width * 0.18;
  if (x < edge) return Math.max(0, x / edge);
  if (x > width - edge) return Math.max(0, (width - x) / edge);
  return 1;
}

function Stop({
  index,
  landmark,
  progress,
  vanX,
  stepDist,
  roadY,
  roadH,
  marker,
  reach,
}: Readonly<{
  index: number;
  landmark: RoadLandmark;
  progress: SharedValue<number>;
  vanX: number;
  stepDist: number;
  roadY: number;
  roadH: number;
  marker: number;
  reach: number;
}>) {
  const above = index % 2 === 0;
  const y = above ? roadY - roadH / 2 - marker - 8 : roadY + roadH / 2 + 8;

  const style = useAnimatedStyle(() => {
    const d = index - progress.value;
    const r = d / reach;
    return {
      opacity: interpolate(r, [-1.2, -0.7, 0, 0.9, 1.4], [0, 0.55, 1, 0.55, 0], Extrapolation.CLAMP),
      transform: [
        { translateX: vanX + d * stepDist },
        { scale: interpolate(Math.abs(r), [0, 1], [1, 0.82], Extrapolation.CLAMP) },
      ],
    };
  });

  return (
    <Animated.View style={[styles.stop, { left: -marker / 2, top: y, width: marker, height: marker }, style]}>
      <View style={landmark.dim ? styles.dim : null}>
        <GlassOrb icon={landmark.icon} accent={landmark.accent} size={marker} />
      </View>
      {landmark.done ? (
        <View style={styles.doneBadge}>
          <ChromeGlyph name="checkmark" size={10} color="#04121F" />
        </View>
      ) : null}
      {landmark.label ? (
        <Text
          numberOfLines={1}
          style={[
            styles.stopLabel,
            { left: marker / 2 - 60 },
            above ? { bottom: marker + 5 } : { top: marker + 5 },
            landmark.dim && styles.dim,
          ]}
        >
          {landmark.label}
        </Text>
      ) : null}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  root: { width: '100%', overflow: 'hidden' },
  road: { position: 'absolute', left: 0, right: 0, borderRadius: 999 },
  dashClip: { position: 'absolute', left: 0, height: 4, overflow: 'hidden' },
  dashRow: { flexDirection: 'row' },
  dash: { width: DASH_W, height: 4, marginRight: DASH_GAP, borderRadius: 2, backgroundColor: 'rgba(248,250,252,0.35)' },
  stop: { position: 'absolute' },
  dim: { opacity: 0.42 },
  doneBadge: {
    position: 'absolute',
    right: -3,
    top: -3,
    width: 16,
    height: 16,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#34D399',
  },
  stopLabel: {
    position: 'absolute',
    width: 120,
    textAlign: 'center',
    color: 'rgba(226,232,240,0.85)',
    fontSize: 11,
    fontWeight: '700',
  },
  glow: { position: 'absolute', borderRadius: 999 },
  streaks: { position: 'absolute', gap: 6 },
  streak: { width: 46, height: 2, borderRadius: 1, backgroundColor: 'rgba(248,250,252,0.6)' },
  streakShort: { width: 28, marginLeft: 14 },
  van: { position: 'absolute', alignItems: 'center', justifyContent: 'center' },
  vanShadow: {
    position: 'absolute',
    backgroundColor: 'rgba(0,0,0,0.3)',
    transform: [{ translateY: 5 }],
    shadowColor: '#000',
    shadowOpacity: 0.6,
    shadowRadius: 12,
  },
  vanImage: { width: '100%', height: '100%' },
});
