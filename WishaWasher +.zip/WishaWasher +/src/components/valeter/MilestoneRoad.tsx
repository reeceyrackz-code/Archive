import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import Animated, {
  Easing,
  FadeIn,
  FadeOut,
  useAnimatedReaction,
  useAnimatedRef,
  useAnimatedScrollHandler,
  useSharedValue,
  withDelay,
  withTiming,
} from 'react-native-reanimated';
import { scheduleOnRN } from 'react-native-worklets';
import { ChromeGlyph } from '../shared/ChromeGlyph';
import type { IconGlyphName } from '../shared/iconGlyphTypes';
import { PressableScale } from '../shared/fit/FitKit';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import VanRoad, { roadGeometry, type RoadLandmark } from './road/VanRoad';
import GlassOrb, { orbPalette } from './road/GlassOrb';

export type MilestoneStop = Readonly<{
  key: string;
  /** Short caption on the road. */
  label: string;
  title: string;
  subtitle?: string;
  icon: IconGlyphName;
  accent: string;
  reached: boolean;
  /** e.g. "Ready to redeem" or "120 pts to go". */
  status: string;
  action?: Readonly<{
    label: string;
    icon?: IconGlyphName;
    onPress: () => void;
    busy?: boolean;
  }>;
}>;

const STEP_RATIO = 0.34;

/** Fractional stop index for `value` given ascending stop thresholds (first is usually 0). */
export function roadPosition(thresholds: readonly number[], value: number): number {
  for (let i = 1; i < thresholds.length; i++) {
    const hi = thresholds[i]!;
    if (value < hi) {
      const lo = thresholds[i - 1]!;
      return i - 1 + Math.max(0, (value - lo) / Math.max(1, hi - lo));
    }
  }
  return Math.max(0, thresholds.length - 1);
}

/**
 * Milestone journey: the Wish-a-Wash van drives along a road to the Pro's current spot,
 * then the road can be swiped to preview every stop ahead or behind.
 */
export default function MilestoneRoad({
  kicker,
  stops,
  position,
  ready,
  height = 210,
}: Readonly<{
  kicker: string;
  stops: readonly MilestoneStop[];
  /** Where the van rests, in stops (fractional between two stops). */
  position: number;
  /** Hold the drive-in until real data has loaded. */
  ready: boolean;
  height?: number;
}>) {
  const { width } = useWindowDimensions();
  const { stepDist } = roadGeometry(width, STEP_RATIO);
  const last = Math.max(0, stops.length - 1);
  const home = Math.min(last, Math.max(0, position));
  const goal = Math.min(last, Math.ceil(home - 0.001));

  const progress = useSharedValue(0);
  const driving = useSharedValue(true);
  const scrollRef = useAnimatedRef<Animated.ScrollView>();
  const [isDriving, setIsDriving] = useState(true);
  const [atHome, setAtHome] = useState(true);
  const [nearest, setNearest] = useState(0);
  const lastTick = useRef(0);

  const landmarks = useMemo<RoadLandmark[]>(
    () => stops.map((s) => ({ id: s.key, accent: s.accent, icon: s.icon, label: s.label, done: s.reached, dim: !s.reached })),
    [stops]
  );

  const tick = useCallback((i: number) => {
    setNearest(i);
    const now = Date.now();
    if (now - lastTick.current > 90) {
      lastTick.current = now;
      void hapticFeedback('light');
    }
  }, []);

  const finishDrive = useCallback(() => {
    scrollRef.current?.scrollTo({ x: home * stepDist, animated: false });
    driving.value = false;
    setIsDriving(false);
    setAtHome(true);
    void hapticFeedback('medium');
  }, [driving, home, scrollRef, stepDist]);

  useEffect(() => {
    if (!ready) return;
    driving.value = true;
    setIsDriving(true);
    const distance = Math.abs(home - progress.value);
    progress.value = withDelay(
      250,
      withTiming(home, { duration: Math.min(2600, 700 + distance * 420), easing: Easing.inOut(Easing.cubic) }, (finished) => {
        if (finished) scheduleOnRN(finishDrive);
      })
    );
  }, [ready, home, driving, progress, finishDrive]);

  useAnimatedReaction(
    () => Math.round(progress.value),
    (i, prev) => {
      if (prev !== null && i !== prev) scheduleOnRN(tick, i);
    }
  );

  const onScroll = useAnimatedScrollHandler((e) => {
    if (!driving.value) progress.value = e.contentOffset.x / stepDist;
  });

  const goHome = () => {
    void hapticFeedback('light');
    setAtHome(true);
    scrollRef.current?.scrollTo({ x: home * stepDist, animated: true });
  };

  const focus = Math.min(last, Math.max(0, atHome ? goal : nearest));
  const stop = stops[focus];

  return (
    <View style={styles.root}>
      <View style={styles.head}>
        <Text style={styles.kicker}>{kicker}</Text>
        {!atHome && !isDriving ? (
          <Animated.View entering={FadeIn.duration(160)} exiting={FadeOut.duration(120)}>
            <Pressable onPress={goHome} style={styles.homeChip} accessibilityLabel="Back to my spot" hitSlop={8}>
              <ChromeGlyph name="locate" size={12} color="#BAE6FD" />
              <Text style={styles.homeChipText}>My spot</Text>
            </Pressable>
          </Animated.View>
        ) : (
          <Text style={styles.hint}>Swipe the road</Text>
        )}
      </View>

      <View style={[styles.roadWrap, { width, height }]}>
        <VanRoad progress={progress} landmarks={landmarks} height={height} stepRatio={STEP_RATIO} />
        <Animated.ScrollView
          ref={scrollRef}
          horizontal
          style={StyleSheet.absoluteFill}
          contentContainerStyle={{ width: width + last * stepDist }}
          showsHorizontalScrollIndicator={false}
          scrollEnabled={!isDriving}
          snapToInterval={stepDist}
          decelerationRate="fast"
          scrollEventThrottle={16}
          onScroll={onScroll}
          onScrollBeginDrag={() => setAtHome(false)}
        />
      </View>

      {stop ? <StopCard key={stop.key} stop={stop} /> : null}
    </View>
  );
}

function StopAction({ action, palette }: Readonly<{ action: NonNullable<MilestoneStop['action']>; palette: ReturnType<typeof orbPalette> }>) {
  return (
    <PressableScale
      onPress={action.busy ? undefined : action.onPress}
      style={[styles.action, { backgroundColor: palette.gradient[1], shadowColor: palette.glow }]}
      accessibilityLabel={action.label}
    >
      {action.busy ? (
        <ActivityIndicator size="small" color="#F8FAFC" />
      ) : (
        <>
          {action.icon ? <ChromeGlyph name={action.icon} size={14} color="#F8FAFC" /> : null}
          <Text style={styles.actionText}>{action.label}</Text>
        </>
      )}
    </PressableScale>
  );
}

function StopCard({ stop }: Readonly<{ stop: MilestoneStop }>) {
  const palette = orbPalette(stop.accent);
  return (
    <Animated.View entering={FadeIn.duration(200)} style={styles.card}>
      <View style={styles.cardRow}>
        <GlassOrb icon={stop.icon} accent={stop.accent} size={38} />
        <View style={styles.cardText}>
          <Text style={styles.title} numberOfLines={1}>
            {stop.title}
          </Text>
          {stop.subtitle ? (
            <Text style={styles.subtitle} numberOfLines={3}>
              {stop.subtitle}
            </Text>
          ) : null}
        </View>
      </View>
      <View style={styles.cardFoot}>
        <View style={[styles.status, { backgroundColor: stop.reached ? 'rgba(52,211,153,0.14)' : palette.gradient[1] }]}>
          <ChromeGlyph
            name={stop.reached ? 'checkmark-circle' : 'flag-outline'}
            size={13}
            color={stop.reached ? '#6EE7B7' : palette.glow}
          />
          <Text style={[styles.statusText, { color: stop.reached ? '#A7F3D0' : '#E2E8F0' }]} numberOfLines={1}>
            {stop.status}
          </Text>
        </View>
        {stop.action ? <StopAction action={stop.action} palette={palette} /> : null}
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  root: { gap: 6 },
  head: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', minHeight: 24 },
  kicker: { color: 'rgba(186,230,253,0.8)', fontSize: 10.5, fontWeight: '800', letterSpacing: 1.2 },
  hint: { color: 'rgba(148,163,184,0.6)', fontSize: 11, fontWeight: '600' },
  homeChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    height: 24,
    borderRadius: 12,
    backgroundColor: 'rgba(56,189,248,0.16)',
  },
  homeChipText: { color: '#BAE6FD', fontSize: 11, fontWeight: '700' },
  roadWrap: { alignSelf: 'center' },
  card: { gap: 12, padding: 14, borderRadius: 22, backgroundColor: 'rgba(255,255,255,0.06)' },
  cardRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  cardText: { flex: 1, gap: 2 },
  title: { color: '#F8FAFC', fontSize: 15, fontWeight: '800' },
  subtitle: { color: 'rgba(203,213,225,0.75)', fontSize: 12, fontWeight: '500', lineHeight: 16 },
  cardFoot: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 },
  status: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 10, height: 28, borderRadius: 14, flexShrink: 1 },
  statusText: { fontSize: 12, fontWeight: '700', flexShrink: 1 },
  action: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 16,
    height: 36,
    borderRadius: 18,
    shadowOpacity: 0.35,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 0 },
  },
  actionText: { color: '#F8FAFC', fontSize: 13, fontWeight: '800' },
});
