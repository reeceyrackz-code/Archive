import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, type StyleProp, type ViewStyle } from 'react-native';
import { ChromeGlyph } from '../shared/ChromeGlyph';
import { PulseDot } from '../shared/fit/FitKit';
import {
  valeterStripeConnectService,
  type StripeConnectStatus,
} from '../../services/valeterStripeConnectService';

const GREEN = '#34D399';
const RED = '#F87171';

/** Green "Connected" once Stripe onboarding is completed, red "Not connected" otherwise. */
export default function StripeStatusPill({
  status,
  size = 'md',
  style,
}: Readonly<{ status: StripeConnectStatus | null | undefined; size?: 'sm' | 'md'; style?: StyleProp<ViewStyle> }>) {
  const connected = status === 'completed';
  const color = connected ? GREEN : RED;
  const sm = size === 'sm';
  return (
    <View
      style={[
        styles.pill,
        sm && styles.pillSm,
        { backgroundColor: `${color}22`, borderColor: `${color}77` },
        style,
      ]}
      accessibilityLabel={connected ? 'Stripe connected' : 'Stripe not connected'}
    >
      {connected ? (
        <ChromeGlyph name="checkmark-circle" size={sm ? 12 : 14} color={color} />
      ) : (
        <PulseDot color={color} size={sm ? 6 : 7} />
      )}
      <Text style={[styles.text, sm && styles.textSm, { color }]}>{connected ? 'Connected' : 'Not connected'}</Text>
    </View>
  );
}

/** Reads the valeter's Stripe Connect status once (null while loading). */
export function useValeterStripeStatus(userId: string | null | undefined) {
  const [status, setStatus] = useState<StripeConnectStatus | null>(null);
  useEffect(() => {
    if (!userId) return;
    let cancelled = false;
    valeterStripeConnectService
      .getStatus(userId)
      .then((s) => {
        if (!cancelled) setStatus(s.stripeConnectStatus ?? 'not_started');
      })
      .catch(() => {
        if (!cancelled) setStatus('not_started');
      });
    return () => {
      cancelled = true;
    };
  }, [userId]);
  return status;
}

const styles = StyleSheet.create({
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 999,
    borderWidth: 1,
  },
  pillSm: { gap: 5, paddingHorizontal: 8, paddingVertical: 3 },
  text: { fontSize: 12, fontWeight: '900', letterSpacing: 0.2 },
  textSm: { fontSize: 11 },
});
