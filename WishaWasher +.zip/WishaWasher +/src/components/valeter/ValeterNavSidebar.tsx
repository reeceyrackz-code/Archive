import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Platform,
  Image,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { usePathname, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import { LocationStyleIconBox } from '../shared/GradientIconBox';
import { accentToGradient } from '../../utils/accentGradient';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import type { IconGlyphName } from '../shared/iconGlyphTypes';
import { DASHBOARD_HEADER_HEIGHT } from '../shared/AppHeader';
import { isValeterDashboardRoute } from '../../utils/valeterNavigation';


export const VALETER_MAP_ROUTE = '/valeter/valeter-dashboard';

/** Bottom inset for valeter screens above the global sheet-style dock. */
export const VALETER_CONTENT_BOTTOM_PAD = 82;







type ValeterNavContextValue = {
  open: () => void;
  close: () => void;
  toggle: () => void;
  visible: boolean;
  jobRequestCount: number;
  setJobRequestCount: (count: number) => void;
  dashboardStats: ValeterNavDashboardStats;
  setDashboardStats: (stats: Partial<ValeterNavDashboardStats>) => void;
};

export type ValeterNavDashboardStats = {
  earningsToday: number;
  jobsToday: number;
  isOnline: boolean;
  verificationPercent: number;
  hasActiveJob: boolean;
};

const ValeterNavContext = createContext<ValeterNavContextValue | null>(null);

export function useValeterNav() {
  const ctx = useContext(ValeterNavContext);
  if (!ctx) {
    return {
      open: () => {},
      close: () => {},
      toggle: () => {},
      visible: false,
      jobRequestCount: 0,
      setJobRequestCount: () => {},
      dashboardStats: { earningsToday: 0, jobsToday: 0, isOnline: false, verificationPercent: 0, hasActiveJob: false },
      setDashboardStats: () => {},
    };
  }
  return ctx;
}

/** Sync live job-request count from the dashboard into the sidebar badges. */
export function useSyncValeterNavJobRequests(count: number) {
  const { setJobRequestCount } = useValeterNav();
  useEffect(() => {
    setJobRequestCount(count);
  }, [count, setJobRequestCount]);
}

export function useSyncValeterNavDashboardStats(stats: ValeterNavDashboardStats) {
  const { setDashboardStats } = useValeterNav();
  useEffect(() => {
    setDashboardStats(stats);
  }, [stats, setDashboardStats]);
}

export function ValeterMenuButton({ color, headerInline = false }: Readonly<{ color?: string; headerInline?: boolean }>) {
  const { toggle } = useValeterNav();
  const accent = color ?? '#F9FAFB';

  if (headerInline) {
    return (
      <TouchableOpacity
        onPress={async () => {
          await hapticFeedback('light');
          toggle();
        }}
        style={styles.headerInlineBtn}
        hitSlop={12}
        accessibilityRole="button"
        accessibilityLabel="Open menu"
      >
        <LocationStyleIconBox variant="inline" icon="menu" colors={accentToGradient(accent)} />
      </TouchableOpacity>
    );
  }

  return (
    <TouchableOpacity
      onPress={async () => {
        await hapticFeedback('light');
        toggle();
      }}
      style={styles.menuBtn}
      hitSlop={12}
      accessibilityRole="button"
      accessibilityLabel="Open menu"
    >
      <BlurView
        intensity={Platform.OS === 'ios' ? 48 : 64}
        tint="dark"
        style={StyleSheet.absoluteFill}
        {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
      />
      <LinearGradient
        colors={['rgba(255,255,255,0.14)', 'rgba(255,255,255,0.04)']}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <View style={[styles.menuBtnInner, { borderColor: `${accent}44` }]}>
        <Ionicons name="menu" size={22} color={accent} />
      </View>
    </TouchableOpacity>
  );
}

/** App mark — used as the header “home” control on valeter sub-pages. */
const APP_ICON = require('../../../assets/icon.png');

/** Return to map home — used in page headers on valeter sub-pages. */
export function ValeterMapHomeButton({ color, headerInline = false }: Readonly<{ color?: string; headerInline?: boolean }>) {
  const router = useRouter();
  const pathname = usePathname();
  const accent = color ?? '#F9FAFB';

  const goMap = async () => {
    await hapticFeedback('light');
    if (isValeterDashboardRoute(pathname || '')) return;
    router.dismissTo(VALETER_MAP_ROUTE);
  };

  if (headerInline) {
    return (
      <TouchableOpacity
        onPress={goMap}
        style={[styles.headerHomeRing, { borderColor: `${accent}AA` }]}
        hitSlop={12}
        accessibilityRole="button"
        accessibilityLabel="Back to home"
      >
        <Image source={APP_ICON} style={styles.headerAppIcon} resizeMode="cover" />
      </TouchableOpacity>
    );
  }

  return (
    <TouchableOpacity
      onPress={goMap}
      style={styles.menuBtn}
      hitSlop={12}
      accessibilityRole="button"
      accessibilityLabel="Back to home"
    >
      <BlurView
        intensity={Platform.OS === 'ios' ? 48 : 64}
        tint="dark"
        style={StyleSheet.absoluteFill}
        {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
      />
      <LinearGradient
        colors={['rgba(255,255,255,0.14)', 'rgba(255,255,255,0.04)']}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <View style={[styles.menuBtnInner, { borderColor: `${accent}44` }]}>
        <Image source={APP_ICON} style={styles.menuAppIcon} resizeMode="contain" />
      </View>
    </TouchableOpacity>
  );
}

/** Jobs + messages shortcuts on the map — right edge, outside the sidebar. */
export function ValeterMapQuickActions({
  accent,
  jobRequestCount = 0,
  messageCount = 0,
}: Readonly<{ accent: string; jobRequestCount?: number; messageCount?: number }>) {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const go = async (route: string) => {
    await hapticFeedback('light');
    router.push(route);
  };

  const items = [
    { id: 'jobs', icon: 'car' as IconGlyphName, route: '/valeter/valeter-dashboard?sheet=request', count: jobRequestCount, label: 'Job requests' },
    { id: 'messages', icon: 'chatbubbles' as IconGlyphName, route: '/valeter/inbox', count: messageCount, label: 'Messages' },
  ];

  return (
    <View style={[styles.mapQuickActions, { top: insets.top + DASHBOARD_HEADER_HEIGHT + 12 }]} pointerEvents="box-none">
      {items.map((item) => (
        <TouchableOpacity
          key={item.id}
          onPress={() => go(item.route)}
          style={[styles.mapQuickActionBtn, { borderColor: `${accent}40` }]}
          activeOpacity={0.88}
          accessibilityRole="button"
          accessibilityLabel={item.label}
        >
          <BlurView
            intensity={Platform.OS === 'ios' ? 52 : 68}
            tint="dark"
            style={StyleSheet.absoluteFill}
            {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
          />
          <LinearGradient
            colors={['rgba(255,255,255,0.14)', 'rgba(255,255,255,0.04)']}
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
          />
          <Ionicons name={item.icon} size={22} color={accent} />
          {item.count > 0 ? (
            <View style={[styles.mapQuickBadge, { backgroundColor: accent }]}>
              <Text style={styles.mapQuickBadgeText}>{item.count > 9 ? '9+' : item.count}</Text>
            </View>
          ) : null}
        </TouchableOpacity>
      ))}
    </View>
  );
}

/** Top-left map home on valeter sub-pages. */
export function ValeterFloatingMapHomeButton() {
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const accent = theme?.primary ?? '#38BDF8';
  return (
    <View style={[styles.floatingMenuWrap, { top: insets.top + 8 }]} pointerEvents="box-none">
      <ValeterMapHomeButton color={accent} />
    </View>
  );
}






export function ValeterNavProvider({ children }: Readonly<{ children: React.ReactNode }>) {
  const [jobRequestCount, setJobRequestCount] = useState(0);
  const [navStats, setNavStats] = useState<ValeterNavDashboardStats>({
    earningsToday: 0,
    jobsToday: 0,
    isOnline: false,
    verificationPercent: 0,
    hasActiveJob: false,
  });
  const router = useRouter();
  const pathname = usePathname();

  const goProfile = useCallback(() => {
    const route = '/valeter/profile/valeter-profile';
    if (pathname === route || pathname === `${route}/`) return;
    router.push(route as any);
  }, [router, pathname]);

  const open = useCallback(() => {
    goProfile();
  }, [goProfile]);
  const close = useCallback(() => {}, []);
  const toggle = useCallback(() => {
    goProfile();
  }, [goProfile]);

  const setDashboardStats = useCallback((patch: Partial<ValeterNavDashboardStats>) => {
    setNavStats((prev) => ({ ...prev, ...patch }));
  }, []);

  const ctx = useMemo(
    () => ({
      open,
      close,
      toggle,
      visible: false,
      jobRequestCount,
      setJobRequestCount,
      dashboardStats: navStats,
      setDashboardStats,
    }),
    [open, close, toggle, jobRequestCount, navStats, setDashboardStats]
  );

  return <ValeterNavContext.Provider value={ctx}>{children}</ValeterNavContext.Provider>;
}

const styles = StyleSheet.create({
  menuBtn: {
    width: 44,
    height: 44,
    borderRadius: 14,
    overflow: 'hidden',
  },
  menuBtnInner: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderRadius: 14,
  },
  headerInlineBtn: {
    width: 40,
    height: 40,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
    flexShrink: 0,
  },
  headerHomeRing: {
    width: 42,
    height: 42,
    borderRadius: 21,
    borderWidth: 2,
    padding: 2,
    flexShrink: 0,
  },
  headerAppIcon: {
    width: '100%',
    height: '100%',
    borderRadius: 17,
  },
  menuAppIcon: {
    width: 28,
    height: 28,
    borderRadius: 8,
  },
  floatingMenuWrap: {
    position: 'absolute',
    left: 16,
    zIndex: 100,
  },
  mapQuickActions: {
    position: 'absolute',
    right: 16,
    zIndex: 30,
    gap: 10,
    alignItems: 'center',
  },
  mapQuickActionBtn: {
    width: 48,
    height: 48,
    borderRadius: 14,
    borderWidth: 1,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
  },
  mapQuickBadge: {
    position: 'absolute',
    top: -4,
    right: -4,
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    paddingHorizontal: 4,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#0A1929',
  },
  mapQuickBadgeText: {
    color: '#0A1929',
    fontSize: 10,
    fontWeight: '900',
  },
});
