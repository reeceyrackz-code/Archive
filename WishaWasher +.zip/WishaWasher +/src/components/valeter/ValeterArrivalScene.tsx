import React, { useState } from 'react';
import { StyleSheet, View, type LayoutChangeEvent } from 'react-native';
import Reanimated, { FadeIn, FadeOut } from 'react-native-reanimated';
import DepotScene from './scene/DepotScene';
import DetailScene from './scene/DetailScene';
import RepairScene from './scene/RepairScene';
import StreetScene from './scene/StreetScene';
import WashScene from './scene/WashScene';
import type { JobKind, SceneProps } from './scene/sceneKit';

type Place = 'depot' | 'street' | 'driveway';

/** Stages that share a place keep the same scene so the van carries on from where it was. */
function placeFor(status: string | null): Place {
  if (status === 'arrived') return 'street';
  if (status === 'in_progress' || status === 'completed') return 'driveway';
  return 'depot';
}

/**
 * No car photo yet: a little top-down world for the job, one scene per stage (the drive itself is the map),
 * with the whole journey as a road along the top. Depot while it's paid for and ready, the customer's
 * street on arrival, then their drive set up for a wash, a detail or a repair.
 */
export default function ValeterArrivalScene({
  status,
  tone,
  accent,
  kind,
  first,
  carLabel,
}: Readonly<{ status: string | null; tone: string; accent: string; kind: JobKind; first: string; carLabel: string | null }>) {
  const [size, setSize] = useState<{ w: number; h: number } | null>(null);
  const onLayout = (e: LayoutChangeEvent) => {
    const { width, height } = e.nativeEvent.layout;
    if (size?.w !== width || size?.h !== height) setSize({ w: width, h: height });
  };
  const place = placeFor(status);

  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="box-none">
      <View style={styles.stage} onLayout={onLayout} pointerEvents="box-none">
        {size ? (
          <Reanimated.View
            key={place === 'driveway' ? `${place}-${kind}` : place}
            entering={FadeIn.duration(700)}
            exiting={FadeOut.duration(450)}
            style={StyleSheet.absoluteFill}
            pointerEvents="box-none"
          >
            <Scene place={place} kind={kind} w={size.w} h={size.h} status={status} tone={tone} accent={accent} first={first} carLabel={carLabel} />
          </Reanimated.View>
        ) : null}
      </View>
    </View>
  );
}

function Scene({ place, kind, ...props }: SceneProps & Readonly<{ place: Place; kind: JobKind }>) {
  if (place === 'street') return <StreetScene {...props} />;
  if (place === 'driveway') {
    if (kind === 'detail') return <DetailScene {...props} />;
    if (kind === 'repair') return <RepairScene {...props} />;
    return <WashScene {...props} />;
  }
  return <DepotScene {...props} />;
}

const styles = StyleSheet.create({
  stage: {
    flex: 1,
    marginHorizontal: 12,
    borderRadius: 28,
    overflow: 'hidden',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(255,255,255,0.16)',
  },
});
