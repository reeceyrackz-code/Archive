import React, { useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Easing,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';

const AUTH_MASCOT = require('../../../assets/auth-mascot.png');

const ORB = 184;
const RING = 6;
const CRADLE = ORB + 22;
const HALO = ORB + 110;
const OFFLINE_RED = '#F87171';
const OFFLINE_RING = ['#FECACA', '#EF4444', '#7F1D1D'] as const;
const GO_GREEN = ['#4ADE80', '#16A34A'] as const;

type Props = Readonly<{
  busy: boolean;
  disabled?: boolean;
  onPress: () => void;
  /** One-shot spin played by the dashboard when presence flips. */
  mascotSpin?: Animated.AnimatedInterpolation<string>;
  /** Sparkle layer rendered around the orb. */
  children?: React.ReactNode;
}>;

/** Map-centre "Go online" prompt shown while the valeter is offline. */
export default function GoOnlineHero({ busy, disabled = false, onPress, mascotSpin, children }: Props) {
  const idleSpin = useRef(new Animated.Value(0)).current;
  const pulse = useRef(new Animated.Value(0)).current;
  const float = useRef(new Animated.Value(0)).current;
  const pressScale = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    if (busy) return;
    idleSpin.setValue(0);
    const loop = Animated.loop(
      Animated.timing(idleSpin, { toValue: 1, duration: 6000, easing: Easing.linear, useNativeDriver: true })
    );
    loop.start();
    return () => loop.stop();
  }, [busy, idleSpin]);

  useEffect(() => {
    const pulseLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1, duration: 2200, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
        Animated.timing(pulse, { toValue: 0, duration: 0, useNativeDriver: true }),
      ])
    );
    const floatLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(float, { toValue: 1, duration: 1800, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
        Animated.timing(float, { toValue: 0, duration: 1800, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      ])
    );
    pulseLoop.start();
    floatLoop.start();
    return () => {
      pulseLoop.stop();
      floatLoop.stop();
    };
  }, [pulse, float]);

  const pressTo = (to: number) =>
    Animated.spring(pressScale, { toValue: to, friction: 6, tension: 200, useNativeDriver: true }).start();

  const idleRotate = idleSpin.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });
  const ringAScale = pulse.interpolate({ inputRange: [0, 1], outputRange: [1, 1.32] });
  const ringAOpacity = pulse.interpolate({ inputRange: [0, 0.15, 1], outputRange: [0.7, 0.5, 0] });
  const ringBScale = pulse.interpolate({ inputRange: [0, 0.4, 1], outputRange: [1, 1, 1.18] });
  const ringBOpacity = pulse.interpolate({ inputRange: [0, 0.4, 0.55, 1], outputRange: [0, 0, 0.45, 0] });
  const floatY = float.interpolate({ inputRange: [0, 1], outputRange: [0, -6] });

  return (
    <TouchableOpacity
      onPress={onPress}
      onPressIn={() => pressTo(0.95)}
      onPressOut={() => pressTo(1)}
      disabled={disabled || busy}
      activeOpacity={1}
      style={styles.root}
      accessibilityRole="button"
      accessibilityLabel="Go online"
      accessibilityState={{ busy }}
    >
      <Animated.View style={[styles.stage, { transform: [{ translateY: floatY }, { scale: pressScale }] }]}>
        <LinearGradient
          pointerEvents="none"
          colors={['rgba(239,68,68,0.30)', 'rgba(239,68,68,0)']}
          style={styles.halo}
        />
        <View pointerEvents="none" style={styles.cradle} />

        <Animated.View
          pointerEvents="none"
          style={[styles.pulseRing, { opacity: ringAOpacity, transform: [{ scale: ringAScale }] }]}
        />
        <Animated.View
          pointerEvents="none"
          style={[styles.pulseRing, styles.pulseRingSoft, { opacity: ringBOpacity, transform: [{ scale: ringBScale }] }]}
        />

        {children}

        <Animated.View style={[styles.orbShadow, mascotSpin ? { transform: [{ rotate: mascotSpin }] } : null]}>
          <LinearGradient colors={OFFLINE_RING} start={{ x: 0.2, y: 0 }} end={{ x: 0.8, y: 1 }} style={styles.ring}>
            <View style={styles.inner}>
              <Animated.Image
                source={AUTH_MASCOT}
                resizeMode="cover"
                style={[styles.mascot, { transform: [{ rotate: idleRotate }] }]}
              />
              <LinearGradient
                pointerEvents="none"
                colors={['rgba(255,255,255,0.40)', 'rgba(255,255,255,0)']}
                start={{ x: 0.3, y: 0 }}
                end={{ x: 0.5, y: 0.5 }}
                style={styles.gloss}
              />
              {busy ? (
                <View style={styles.busyOverlay}>
                  <ActivityIndicator color="#FFFFFF" />
                  <Text style={styles.busyText}>Updating…</Text>
                </View>
              ) : null}
            </View>
          </LinearGradient>
        </Animated.View>

        <View pointerEvents="none" style={styles.offlineChip}>
          <View style={styles.offlineDot} />
          <Text style={styles.offlineText}>Offline</Text>
        </View>
      </Animated.View>

      <LinearGradient colors={GO_GREEN} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.cta}>
        <View style={styles.ctaIcon}>
          <Ionicons name="power" size={15} color="#15803D" />
        </View>
        <Text style={styles.ctaText}>{busy ? 'Going online…' : 'Go online'}</Text>
      </LinearGradient>
      <Text style={styles.help}>Tap to start receiving wash requests</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  root: {
    alignItems: 'center',
  },
  stage: {
    width: HALO,
    height: CRADLE + 36,
    alignItems: 'center',
    justifyContent: 'center',
  },
  halo: {
    position: 'absolute',
    width: HALO,
    height: HALO,
    borderRadius: HALO / 2,
  },
  cradle: {
    position: 'absolute',
    width: CRADLE,
    height: CRADLE,
    borderRadius: CRADLE / 2,
    backgroundColor: 'rgba(6,14,26,0.78)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
  },
  pulseRing: {
    position: 'absolute',
    width: ORB,
    height: ORB,
    borderRadius: ORB / 2,
    borderWidth: 2.5,
    borderColor: OFFLINE_RED,
  },
  pulseRingSoft: {
    borderWidth: 1.5,
    borderColor: 'rgba(248,113,113,0.6)',
  },
  orbShadow: {
    width: ORB,
    height: ORB,
    borderRadius: ORB / 2,
    shadowColor: '#EF4444',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.55,
    shadowRadius: 24,
    elevation: 16,
  },
  ring: {
    flex: 1,
    borderRadius: ORB / 2,
    padding: RING,
  },
  inner: {
    flex: 1,
    borderRadius: (ORB - RING * 2) / 2,
    overflow: 'hidden',
    backgroundColor: '#0B2A4A',
  },
  mascot: {
    width: '100%',
    height: '100%',
  },
  gloss: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: '50%',
  },
  busyOverlay: {
    ...StyleSheet.absoluteFill,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: 'rgba(6,14,26,0.55)',
  },
  busyText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '800',
  },
  offlineChip: {
    position: 'absolute',
    top: (CRADLE + 36 - ORB) / 2 - 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 11,
    paddingVertical: 5,
    borderRadius: 999,
    backgroundColor: '#3B0D12',
    borderWidth: 1,
    borderColor: 'rgba(252,165,165,0.6)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
    elevation: 6,
  },
  offlineDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: OFFLINE_RED,
  },
  offlineText: {
    color: '#FECACA',
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 0.9,
    textTransform: 'uppercase',
  },
  cta: {
    marginTop: 2,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
    paddingLeft: 8,
    paddingRight: 22,
    height: 46,
    borderRadius: 23,
    shadowColor: '#22C55E',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.45,
    shadowRadius: 16,
    elevation: 10,
  },
  ctaIcon: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  ctaText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '900',
    letterSpacing: 0.3,
  },
  help: {
    marginTop: 10,
    color: 'rgba(226,232,240,0.75)',
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
    textShadowColor: 'rgba(0,0,0,0.5)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 3,
  },
});
