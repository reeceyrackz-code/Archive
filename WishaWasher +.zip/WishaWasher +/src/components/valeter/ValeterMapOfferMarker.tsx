import React, { useEffect, useRef } from 'react';
import { Animated, Easing, Image, StyleSheet, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { CAR_IMAGE } from '../../constants/washerAssets';

const AMBER = '#FBBF24';
const AMBER_DEEP = '#F59E0B';
const PULSE_MS = 1600;

function OfferPulse({ size }: Readonly<{ size: number }>) {
  const t = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const anim = Animated.loop(
      Animated.sequence([
        Animated.timing(t, { toValue: 1, duration: PULSE_MS, easing: Easing.out(Easing.quad), useNativeDriver: true }),
        Animated.timing(t, { toValue: 0, duration: 0, useNativeDriver: true }),
      ])
    );
    anim.start();
    return () => anim.stop();
  }, [t]);
  return (
    <Animated.View
      style={[
        styles.pulse,
        {
          width: size,
          height: size,
          borderRadius: size / 2,
          opacity: t.interpolate({ inputRange: [0, 1], outputRange: [0.7, 0] }),
          transform: [{ scale: t.interpolate({ inputRange: [0, 1], outputRange: [1, 2] }) }],
        },
      ]}
    />
  );
}

/** Customer pin for a live job offer: an amber car badge; the offer in focus is larger and pulses. */
export default function ValeterMapOfferMarker({ focused = false }: Readonly<{ focused?: boolean }>) {
  const pin = focused ? 50 : 36;
  const car = Math.round(pin * 0.66);
  const inner = pin - 10;

  return (
    <View style={styles.wrap} collapsable={false}>
      <View style={[styles.pinBox, { width: pin * 2, height: pin * 2 }]}>
        {focused ? <OfferPulse size={pin} /> : null}
        <LinearGradient
          colors={[AMBER, AMBER_DEEP]}
          style={[styles.pin, { width: pin, height: pin, borderRadius: pin / 2, borderWidth: focused ? 3 : 2 }]}
        >
          <View style={[styles.pinInner, { width: inner, height: inner, borderRadius: inner / 2 }]}>
            <Image source={CAR_IMAGE} style={{ width: car, height: car }} resizeMode="contain" />
          </View>
        </LinearGradient>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { alignItems: 'center' },
  pinBox: { alignItems: 'center', justifyContent: 'center' },
  pulse: { position: 'absolute', borderWidth: 2.5, borderColor: AMBER },
  pin: {
    alignItems: 'center',
    justifyContent: 'center',
    borderColor: '#FFFFFF',
    shadowColor: '#000',
    shadowOpacity: 0.4,
    shadowRadius: 5,
    shadowOffset: { width: 0, height: 3 },
    elevation: 6,
  },
  pinInner: { alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(10,25,41,0.9)' },
});
