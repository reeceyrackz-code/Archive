import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import Reanimated, { FadeIn, FadeOut } from 'react-native-reanimated';
import { ChromeGlyph as Ionicons, type IconGlyphName } from '../shared/ChromeGlyph';
import { turnPhrase, type RouteTurn } from '../../utils/routeTurnAhead';

const METRES_PER_MILE = 1609.344;

export function aheadText(metres: number) {
  const miles = metres / METRES_PER_MILE;
  if (miles >= 0.2) return `${miles.toFixed(1)} mi`;
  const yards = Math.max(10, Math.round((metres * 1.0936) / 10) * 10);
  return `${yards} yd`;
}

export function manoeuvre(turn: RouteTurn | null): Readonly<{ icon: IconGlyphName; text: string }> {
  if (!turn) return { icon: 'mci:arrow-up', text: 'Continue' };
  const a = Math.abs(turn.angle);
  const side = turn.angle > 0 ? 'right' : 'left';
  const text = turnPhrase(turn);
  if (a >= 150) return { icon: 'mci:arrow-u-left-top', text };
  if (a >= 60) return { icon: side === 'right' ? 'mci:arrow-right-top' : 'mci:arrow-left-top', text };
  return { icon: side === 'right' ? 'mci:arrow-top-right' : 'mci:arrow-top-left', text };
}

function bannerCopy({
  arrived,
  nearby,
  turn,
  street,
  manoeuvreText,
}: Readonly<{ arrived: boolean; nearby: boolean; turn: RouteTurn | null; street: string | null; manoeuvreText: string }>) {
  if (arrived) return { primary: "You've arrived", secondary: street ?? 'At the customer' };
  if (nearby) return { primary: "You're here", secondary: 'Hold the green button to mark arrived' };
  if (turn) return { primary: manoeuvreText, secondary: `in ${aheadText(turn.inMetres)}` };
  return { primary: manoeuvreText, secondary: street ? `towards ${street}` : 'to the customer' };
}

/** Sat-nav style instruction for the drive: next manoeuvre, distance to it, and time/distance to the customer. */
export default function ValeterNavBanner({
  phase,
  turn,
  etaMin,
  miles,
  street,
  accent,
  top,
  nearby = false,
  voiceMuted,
  onToggleVoice,
}: Readonly<{
  phase: 'en_route' | 'arrived';
  turn: RouteTurn | null;
  etaMin: number | null;
  miles: number | null;
  street: string | null;
  accent: string;
  top: number;
  /** Within ~100 m of the customer but not yet marked arrived. */
  nearby?: boolean;
  voiceMuted?: boolean;
  onToggleVoice?: () => void;
}>) {
  const arrived = phase === 'arrived';
  const here = arrived || nearby;
  const m = manoeuvre(turn);
  const icon: IconGlyphName = here ? 'mci:map-marker-check' : m.icon;
  const { primary, secondary } = bannerCopy({ arrived, nearby, turn, street, manoeuvreText: m.text });
  const trip = [etaMin == null ? null : `${Math.max(1, etaMin)} min`, miles == null ? null : `${miles.toFixed(1)} mi`].filter(Boolean).join(' · ');

  return (
    <Reanimated.View entering={FadeIn.duration(300)} exiting={FadeOut.duration(200)} pointerEvents="box-none" style={[styles.banner, { top }]}>
      <View style={[styles.icon, { backgroundColor: here ? '#10B981' : accent }]}>
        <Ionicons name={icon} size={26} color="#FFFFFF" />
      </View>
      <View style={styles.copy}>
        <Text style={styles.primary} numberOfLines={1}>
          {primary}
        </Text>
        <Text style={styles.secondary} numberOfLines={1}>
          {secondary}
        </Text>
      </View>
      {!here && trip ? <Text style={styles.trip}>{trip}</Text> : null}
      {onToggleVoice && !arrived ? (
        <Pressable
          onPress={onToggleVoice}
          hitSlop={8}
          style={styles.voiceBtn}
          accessibilityRole="button"
          accessibilityLabel={voiceMuted ? 'Turn voice guidance on' : 'Mute voice guidance'}
        >
          <Ionicons name={voiceMuted ? 'volume-mute' : 'volume-high'} size={18} color={voiceMuted ? 'rgba(203,213,225,0.6)' : '#F8FAFC'} />
        </Pressable>
      ) : null}
    </Reanimated.View>
  );
}

const styles = StyleSheet.create({
  banner: {
    position: 'absolute',
    left: 12,
    right: 12,
    zIndex: 13,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 10,
    paddingRight: 14,
    borderRadius: 16,
    backgroundColor: 'rgba(11,17,28,0.94)',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(255,255,255,0.12)',
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 6 },
    elevation: 6,
  },
  icon: { width: 46, height: 46, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  copy: { flex: 1, minWidth: 0 },
  primary: { color: '#F8FAFC', fontSize: 18, fontWeight: '700', letterSpacing: -0.3 },
  secondary: { marginTop: 1, color: 'rgba(203,213,225,0.85)', fontSize: 13, fontWeight: '500' },
  voiceBtn: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  trip: { color: '#F8FAFC', fontSize: 13, fontWeight: '600', fontVariant: ['tabular-nums'] },
});
