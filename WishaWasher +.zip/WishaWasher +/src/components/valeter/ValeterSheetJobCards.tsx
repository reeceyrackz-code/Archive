import React, { useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import Reanimated, { Easing, FadeInDown, useAnimatedStyle, useSharedValue, withRepeat, withTiming } from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import Svg, { Defs, LinearGradient as SvgGradient, Path, Stop } from 'react-native-svg';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import ValeterTrackingProgressRing from './ValeterTrackingProgressRing';
import { getServiceDisplayName } from '../../utils/serviceNameMapper';
import { getServiceIcon } from '../../constants/serviceIcons';
import { getActiveBookingStatusLabel, getStatusProgress } from '../../utils/trackingStatusHelpers';
import { isInstantBookingOffer } from '../../services/valeterScheduleConflict';
import { takeHome } from '../../utils/valeterEarnings';
import type { ValeterJobRequest } from './ValeterJobRequestOverlay';
import { DOCK_NOTCH_DEPTH, dockNotchedCardPath } from './ValeterDashboardFloatingDock';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import { lightMistElevated, lightMistInput } from '../../constants/accountThemes';

const CARD_RADIUS = 22;
const URGENT_SECONDS = 15;
const TIMER_AMBER = '#FBBF24';
const TIMER_RED = '#F87171';
const LIVE_GREEN = '#34D399';

export function formatGBP(value: number): string {
  return `£${(Number(value) || 0).toFixed(2)}`;
}

function useSheetCardTheme() {
  const { theme, mode } = useAccountTheme();
  const isLight = mode === 'light';
  return {
    isLight,
    textMain: theme.textPrimary ?? '#F8FAFC',
    textMuted: theme.textSecondary ?? 'rgba(248,250,252,0.7)',
    textSoft: 'rgba(248,250,252,0.5)',
    cardBg: isLight ? lightMistElevated : 'rgba(10,20,36,0.62)',
    cardBorder: isLight ? 'rgba(158,201,224,0.36)' : 'rgba(255,255,255,0.10)',
    chipBg: isLight ? lightMistInput : 'rgba(255,255,255,0.06)',
    chipBorder: isLight ? 'rgba(158,201,224,0.35)' : 'rgba(255,255,255,0.08)',
    moneyColor: theme.accentAlt ?? '#E8C547',
  };
}

function formatTime(seconds: number): string {
  const s = Math.max(0, Math.floor(seconds));
  return `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, '0')}`;
}

function formatClock(d: Date) {
  return d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
}

/** "Now" for instant jobs, otherwise "Today 14:00" / "Tomorrow 09:30" / "Tue 12 Oct 14:00". */
export function formatJobWhen(iso?: string | null): { instant: boolean; label: string } {
  if (isInstantBookingOffer(iso)) return { instant: true, label: 'Now' };
  const d = new Date(iso as string);
  const now = new Date();
  const sameDay = (a: Date, b: Date) =>
    a.getDate() === b.getDate() && a.getMonth() === b.getMonth() && a.getFullYear() === b.getFullYear();
  const tomorrow = new Date(now);
  tomorrow.setDate(now.getDate() + 1);
  if (sameDay(d, now)) return { instant: false, label: `Today ${formatClock(d)}` };
  if (sameDay(d, tomorrow)) return { instant: false, label: `Tomorrow ${formatClock(d)}` };
  const day = d.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' });
  return { instant: false, label: `${day} ${formatClock(d)}` };
}

/** "in 45 min" / "in 3h" / "in 2 days" / "now". */
export function formatRelativeWhen(iso?: string | null): string {
  if (!iso) return '';
  const mins = Math.round((new Date(iso).getTime() - Date.now()) / 60000);
  if (!Number.isFinite(mins)) return '';
  if (mins <= 0) return 'now';
  if (mins < 60) return `in ${mins} min`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `in ${hours}h`;
  const days = Math.round(hours / 24);
  return `in ${days} day${days === 1 ? '' : 's'}`;
}

function upcomingStatusChip(status?: string): { label: string; color: string } {
  switch (status) {
    case 'confirmed':
    case 'valeter_assigned':
      return { label: 'Confirmed', color: LIVE_GREEN };
    case 'pending_payment':
      return { label: 'Awaiting payment', color: TIMER_AMBER };
    case 'pending_valeter_acceptance':
      return { label: 'Awaiting you', color: TIMER_AMBER };
    default:
      return { label: 'Scheduled', color: '#60A5FA' };
  }
}

function CardSheen() {
  return (
    <LinearGradient
      pointerEvents="none"
      colors={['rgba(255,255,255,0.07)', 'rgba(255,255,255,0)']}
      style={styles.sheen}
    />
  );
}

/* ─────────────────────────── Resume (live job) ─────────────────────────── */

export function ValeterResumeJobCard({
  accent,
  status,
  serviceType,
  serviceName,
  customerName,
  onPress,
}: Readonly<{
  accent: string;
  status: string;
  serviceType?: string | null;
  serviceName?: string | null;
  customerName?: string;
  onPress: () => void;
}>) {
  const t = useSheetCardTheme();
  const stage = getActiveBookingStatusLabel(status);
  const service = getServiceDisplayName(serviceType ?? undefined, serviceName ?? undefined);
  return (
    <TouchableOpacity
      activeOpacity={0.88}
      onPress={() => {
        void hapticFeedback('light');
        onPress();
      }}
      style={[styles.card, styles.resumeCard, { backgroundColor: t.cardBg, borderColor: `${LIVE_GREEN}55` }]}
      accessibilityRole="button"
      accessibilityLabel={`Resume trip. ${stage.label}, ${service}`}
    >
      <LinearGradient
        pointerEvents="none"
        colors={[`${LIVE_GREEN}26`, `${LIVE_GREEN}00`]}
        start={{ x: 0, y: 0.5 }}
        end={{ x: 1, y: 0.5 }}
        style={StyleSheet.absoluteFill}
      />
      <ValeterTrackingProgressRing progress={getStatusProgress(status as any)} accent={LIVE_GREEN} size={42} pulse />
      <View style={styles.resumeCopy}>
        <View style={styles.resumeTitleRow}>
          <Text style={[styles.resumeTitle, { color: t.textMain }]}>Resume trip</Text>
          <View style={styles.liveChip}>
            <View style={styles.liveDot} />
            <Text style={styles.liveText}>LIVE</Text>
          </View>
        </View>
        <Text style={[styles.resumeSub, { color: t.textMuted }]} numberOfLines={1}>
          {stage.label} · {customerName ? `${customerName} · ` : ''}
          {service}
        </Text>
      </View>
      <View style={[styles.resumeArrow, { backgroundColor: accent }]}>
        <Ionicons name="arrow-forward" size={16} color="#0A1929" />
      </View>
    </TouchableOpacity>
  );
}

/* ─────────────────────────── Scheduled row ─────────────────────────── */

export type UpcomingJobCardProps = Readonly<{
  accent: string;
  serviceType?: string;
  serviceName?: string | null;
  scheduledAt?: string | null;
  status?: string;
  price: number;
  address?: string | null;
  selected?: boolean;
  onPress: () => void;
  onShowOnMap?: () => void;
}>;

export function ValeterUpcomingJobCard({
  accent,
  serviceType,
  serviceName,
  scheduledAt,
  status,
  price,
  address,
  selected = false,
  onPress,
  onShowOnMap,
}: UpcomingJobCardProps) {
  const t = useSheetCardTheme();
  const time = scheduledAt ? formatClock(new Date(scheduledAt)) : '—';
  const relative = formatRelativeWhen(scheduledAt);
  const chip = upcomingStatusChip(status);
  const service = getServiceDisplayName(serviceType, serviceName);

  return (
    <TouchableOpacity
      activeOpacity={0.9}
      onPress={() => {
        void hapticFeedback('light');
        onPress();
      }}
      style={[
        styles.card,
        styles.upcomingRow,
        {
          backgroundColor: selected ? `${accent}18` : t.cardBg,
          borderColor: selected ? `${accent}AA` : t.cardBorder,
        },
      ]}
      accessibilityRole="button"
      accessibilityLabel={`${service} at ${time}, ${formatGBP(price)}. Open details`}
    >
      <CardSheen />
      <View style={[styles.timeCol, { borderRightColor: t.cardBorder }]}>
        <Text style={[styles.timeText, { color: t.textMain }]}>{time}</Text>
        {relative ? <Text style={[styles.timeRel, { color: accent }]}>{relative}</Text> : null}
      </View>

      <View style={styles.upcomingCopy}>
        <View style={styles.serviceTitleRow}>
          <Ionicons name={getServiceIcon(serviceType, serviceName)} size={15} color={accent} />
          <Text style={[styles.upcomingTitle, { color: t.textMain }]} numberOfLines={1}>
            {service}
          </Text>
        </View>
        {address ? (
          <Text style={[styles.upcomingAddress, { color: t.textSoft }]} numberOfLines={1}>
            {address}
          </Text>
        ) : null}
        <View style={[styles.statusChip, { backgroundColor: `${chip.color}1F`, borderColor: `${chip.color}55` }]}>
          <View style={[styles.statusDot, { backgroundColor: chip.color }]} />
          <Text style={[styles.statusChipText, { color: chip.color }]}>{chip.label}</Text>
        </View>
      </View>

      <View style={styles.upcomingRight}>
        <Text style={[styles.upcomingPrice, { color: t.moneyColor }]}>{formatGBP(price)}</Text>
        {onShowOnMap ? (
          <TouchableOpacity
            onPress={() => {
              void hapticFeedback('light');
              onShowOnMap();
            }}
            hitSlop={8}
            style={[styles.mapBtn, { backgroundColor: t.chipBg, borderColor: `${accent}40` }]}
            accessibilityRole="button"
            accessibilityLabel="Show on map"
          >
            <Ionicons name="map-outline" size={15} color={accent} />
          </TouchableOpacity>
        ) : null}
      </View>
    </TouchableOpacity>
  );
}

/* ─────────────────────────── Job request (offer) ─────────────────────────── */

export type JobRequestCardProps = Readonly<{
  accent: string;
  job: ValeterJobRequest;
  requestIndex?: number;
  selected?: boolean;
  onFocusMap?: () => void;
}>;

function CountdownBar({ remaining, color, track }: Readonly<{ remaining: number; color: string; track: string }>) {
  const totalRef = useRef(Math.max(remaining, 1));
  if (remaining > totalRef.current) totalRef.current = remaining;
  const progress = useSharedValue(remaining / totalRef.current);
  useEffect(() => {
    progress.value = withTiming(Math.max(0, remaining / totalRef.current), {
      duration: 950,
      easing: Easing.linear,
    });
  }, [remaining, progress]);
  const fillStyle = useAnimatedStyle(() => ({ width: `${progress.value * 100}%` }));
  return (
    <View style={[styles.countdownTrack, { backgroundColor: track }]}>
      <Reanimated.View style={[styles.countdownFill, { backgroundColor: color }, fillStyle]} />
    </View>
  );
}

function initialsOf(name: string) {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return '?';
  const last = parts.length > 1 ? (parts.at(-1)?.[0] ?? '') : '';
  return ((parts[0]?.[0] ?? '') + last).toUpperCase();
}

/** Arrive time for instant jobs, or when to set off for booked ones. */
function journeyCue(scheduledAt: string | null | undefined, instant: boolean, drive = 0) {
  if (instant) {
    return { label: 'Arrive', value: drive > 0 ? `~${formatClock(new Date(Date.now() + drive * 60000))}` : 'ASAP' };
  }
  const at = new Date(scheduledAt as string);
  if (!Number.isFinite(at.getTime())) return null;
  if (drive <= 0) return { label: 'Start', value: formatClock(at) };
  return { label: 'Leave by', value: formatClock(new Date(at.getTime() - (drive + 5) * 60000)) };
}

function NewOfferTag({ color }: Readonly<{ color: string }>) {
  const pulse = useSharedValue(0);
  useEffect(() => {
    pulse.value = withRepeat(withTiming(1, { duration: 1100, easing: Easing.out(Easing.quad) }), -1, false);
  }, [pulse]);
  const ringStyle = useAnimatedStyle(() => ({
    opacity: 0.7 * (1 - pulse.value),
    transform: [{ scale: 1 + pulse.value * 1.6 }],
  }));
  return (
    <View style={styles.newTag}>
      <View style={styles.newDotWrap}>
        <Reanimated.View style={[styles.newDotRing, { backgroundColor: color }, ringStyle]} />
        <View style={[styles.newDot, { backgroundColor: color }]} />
      </View>
      <Text style={[styles.newTagText, { color }]}>NEW OFFER</Text>
    </View>
  );
}

function JourneyStrip({
  accent,
  t,
  distance,
  driveMin,
  cue,
  address,
}: Readonly<{
  accent: string;
  t: ReturnType<typeof useSheetCardTheme>;
  distance: number;
  driveMin?: number;
  cue: { label: string; value: string } | null;
  address: string;
}>) {
  const legParts = [driveMin != null ? `~${driveMin} min` : null, distance > 0 ? `${distance} mi` : null].filter(Boolean);
  return (
    <View style={[styles.journey, { backgroundColor: t.chipBg, borderColor: t.chipBorder }]}>
      <View style={styles.journeyTrack}>
        <View style={[styles.journeyNode, { backgroundColor: accent }]}>
          <Ionicons name="car-sport" size={11} color="#04121F" />
        </View>
        <View style={styles.journeyLine}>
          <View style={[styles.journeyDash, { borderColor: `${accent}88` }]} />
          {legParts.length > 0 ? (
            <View style={[styles.journeyLeg, { backgroundColor: t.isLight ? '#2A4660' : '#0F3B78', borderColor: `${accent}55` }]}>
              <Text style={[styles.journeyLegText, { color: t.textMain }]}>{legParts.join(' · ')}</Text>
            </View>
          ) : null}
        </View>
        <View style={[styles.journeyNode, styles.journeyNodeEnd, { borderColor: accent }]}>
          <Ionicons name="location" size={11} color={accent} />
        </View>
        {cue ? (
          <View style={styles.journeyCue}>
            <Text style={[styles.journeyCueLabel, { color: t.textSoft }]}>{cue.label.toUpperCase()}</Text>
            <Text style={[styles.journeyCueValue, { color: t.textMain }]}>{cue.value}</Text>
          </View>
        ) : null}
      </View>
      <Text style={[styles.journeyAddress, { color: t.textMuted }]} numberOfLines={1}>
        {address}
      </Text>
    </View>
  );
}

function EarningsSplit({ price, earn, accent, t }: Readonly<{ price: number; earn: number; accent: string; t: ReturnType<typeof useSheetCardTheme> }>) {
  const share = price > 0 ? Math.min(1, Math.max(0, earn / price)) : 0;
  return (
    <View style={styles.split}>
      <Text style={[styles.splitText, { color: t.textSoft }]} numberOfLines={1}>
        You keep <Text style={{ color: t.moneyColor }}>{Math.round(share * 100)}%</Text>
      </Text>
      <View style={[styles.splitTrack, { backgroundColor: t.isLight ? 'rgba(15,23,42,0.1)' : 'rgba(255,255,255,0.08)' }]}>
        <LinearGradient
          colors={[t.moneyColor, accent]}
          start={{ x: 0, y: 0.5 }}
          end={{ x: 1, y: 0.5 }}
          style={[styles.splitFill, { width: `${Math.round(share * 100)}%` }]}
        />
      </View>
    </View>
  );
}

/** Card fill + outline as one path so the bottom edge can curve up around the nav dock's hump. */
function OfferCardShape({
  id,
  width,
  height,
  fill,
  glow,
  border,
}: Readonly<{ id: string; width: number; height: number; fill: string; glow: string; border: string }>) {
  if (width <= 0 || height <= 0) return null;
  const d = dockNotchedCardPath(width, height, CARD_RADIUS, true);
  const glowId = `offerGlow-${id}`;
  return (
    <Svg pointerEvents="none" width={width} height={height} style={styles.shape}>
      <Defs>
        <SvgGradient id={glowId} x1="0" y1="0" x2="0.9" y2="0.8">
          <Stop offset="0" stopColor={glow} stopOpacity={0.24} />
          <Stop offset="1" stopColor={glow} stopOpacity={0} />
        </SvgGradient>
      </Defs>
      <Path d={d} fill={fill} />
      <Path d={d} fill={`url(#${glowId})`} />
      <Path d={d} fill="none" stroke={border} strokeWidth={1} />
    </Svg>
  );
}

export function ValeterJobRequestCard({ accent, job, requestIndex = 0, selected = false, onFocusMap }: JobRequestCardProps) {
  const t = useSheetCardTheme();
  const urgent = job.timeRemaining <= URGENT_SECONDS;
  const timerColor = urgent ? TIMER_RED : TIMER_AMBER;
  const when = formatJobWhen(job.scheduledAt);
  const earn = takeHome(job.price);
  const cue = journeyCue(job.scheduledAt, when.instant, job.driveTimeMinutes);
  const urgentBorder = urgent ? 'rgba(248,113,113,0.55)' : t.cardBorder;
  const borderColor = selected ? `${accent}AA` : urgentBorder;
  const [size, setSize] = useState({ w: 0, h: 0 });
  const measured = size.w > 0 && size.h > 0;
  const cardFill = t.isLight ? 'rgba(42,70,96,0.82)' : 'rgba(12,40,84,0.92)';

  return (
    <Reanimated.View entering={FadeInDown.springify().damping(16).delay(requestIndex * 60)}>
    <View
      onLayout={(e) => {
        const { width, height } = e.nativeEvent.layout;
        setSize((prev) =>
          Math.abs(prev.w - width) < 0.5 && Math.abs(prev.h - height) < 0.5 ? prev : { w: width, h: height }
        );
      }}
      style={[styles.offerCard, !measured && { backgroundColor: cardFill, borderRadius: CARD_RADIUS }]}
    >
      <OfferCardShape
        id={job.id}
        width={size.w}
        height={size.h}
        fill={cardFill}
        glow={accent}
        border={borderColor}
      />
      <CardSheen />
      <CountdownBar
        remaining={job.timeRemaining}
        color={timerColor}
        track={t.isLight ? 'rgba(15,23,42,0.08)' : 'rgba(255,255,255,0.06)'}
      />
      <TouchableOpacity
        activeOpacity={0.92}
        onPress={() => {
          void hapticFeedback('light');
          onFocusMap?.();
        }}
        style={styles.requestBody}
        accessibilityRole="button"
        accessibilityLabel={`${job.serviceName} for ${job.customerName}, ${when.label}. You earn ${formatGBP(earn)}. Show on map`}
      >
        <View style={styles.requestHeader}>
          <View style={styles.requestHeaderLeft}>
            <NewOfferTag color={when.instant ? LIVE_GREEN : accent} />
            <View
              style={[
                styles.whenChip,
                when.instant
                  ? { backgroundColor: 'rgba(52,211,153,0.16)', borderColor: 'rgba(52,211,153,0.45)' }
                  : { backgroundColor: `${accent}1C`, borderColor: `${accent}50` },
              ]}
            >
              <Ionicons name={when.instant ? 'flash' : 'calendar-outline'} size={12} color={when.instant ? LIVE_GREEN : accent} />
              <Text style={[styles.whenText, { color: when.instant ? '#A7F3D0' : t.textMain }]} numberOfLines={1}>
                {when.label}
              </Text>
            </View>
          </View>
          <View
            style={[
              styles.timer,
              {
                backgroundColor: urgent ? 'rgba(239,68,68,0.18)' : 'rgba(245,158,11,0.13)',
                borderColor: urgent ? 'rgba(248,113,113,0.45)' : 'rgba(251,191,36,0.3)',
              },
            ]}
          >
            <Ionicons name="time-outline" size={13} color={timerColor} />
            <Text style={[styles.timerText, { color: timerColor }]}>{formatTime(job.timeRemaining)}</Text>
          </View>
        </View>

        <View style={styles.requestHero}>
          <LinearGradient
            colors={[`${accent}55`, `${accent}1A`]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={[styles.requestIcon, { borderColor: `${accent}66` }]}
          >
            <Ionicons name={getServiceIcon(job.serviceName)} size={23} color="#F8FAFC" />
          </LinearGradient>
          <View style={styles.requestHeroCopy}>
            <Text style={[styles.requestTitle, { color: t.textMain }]} numberOfLines={1}>
              {job.serviceName}
            </Text>
            <View style={styles.requestCustomerRow}>
              <View style={[styles.customerAvatar, { backgroundColor: `${accent}2E`, borderColor: `${accent}66` }]}>
                <Text style={[styles.customerInitials, { color: t.textMain }]}>{initialsOf(job.customerName)}</Text>
              </View>
              <Text style={[styles.requestCustomer, { color: t.textMuted }]} numberOfLines={1}>
                {job.customerName}
              </Text>
            </View>
          </View>
          <View style={styles.requestEarn}>
            <Text style={[styles.requestEarnLabel, { color: t.textSoft }]}>YOU EARN</Text>
            <Text style={[styles.requestPrice, { color: t.moneyColor }]}>{formatGBP(earn)}</Text>
          </View>
        </View>

        <JourneyStrip
          accent={accent}
          t={t}
          distance={job.distance}
          driveMin={job.driveTimeMinutes}
          cue={cue}
          address={job.address}
        />

        <View style={styles.notchBand}>
          <EarningsSplit price={job.price} earn={earn} accent={accent} t={t} />
          <View style={styles.mapHint}>
            <Text style={[styles.mapHintText, { color: t.textSoft }]}>On map</Text>
            <Ionicons name="map-outline" size={13} color={accent} />
          </View>
        </View>
      </TouchableOpacity>
    </View>
    </Reanimated.View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: CARD_RADIUS,
    borderWidth: 1,
    overflow: 'hidden',
  },
  sheen: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 40,
  },
  serviceTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },

  resumeCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
    minHeight: 64,
  },
  resumeCopy: { flex: 1, minWidth: 0 },
  resumeTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  resumeTitle: { fontSize: 15, fontWeight: '800' },
  resumeSub: { fontSize: 12, fontWeight: '600', marginTop: 2 },
  resumeArrow: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
  },
  liveChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 7,
    paddingVertical: 2,
    borderRadius: 999,
    backgroundColor: 'rgba(16,185,129,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(52,211,153,0.45)',
  },
  liveDot: { width: 5, height: 5, borderRadius: 3, backgroundColor: LIVE_GREEN },
  liveText: { color: '#6EE7B7', fontSize: 9, fontWeight: '900', letterSpacing: 0.6 },

  upcomingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingRight: 12,
    minHeight: 76,
  },
  timeCol: {
    width: 70,
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'stretch',
    borderRightWidth: StyleSheet.hairlineWidth,
    marginRight: 12,
  },
  timeText: { fontSize: 17, fontWeight: '900', fontVariant: ['tabular-nums'], letterSpacing: -0.4 },
  timeRel: { fontSize: 10, fontWeight: '800', marginTop: 2 },
  upcomingCopy: { flex: 1, minWidth: 0, gap: 3 },
  upcomingTitle: { fontSize: 14, fontWeight: '800', flexShrink: 1 },
  upcomingAddress: { fontSize: 11.5, fontWeight: '600' },
  statusChip: {
    alignSelf: 'flex-start',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 7,
    paddingVertical: 2,
    borderRadius: 999,
    borderWidth: 1,
    marginTop: 1,
  },
  statusDot: { width: 5, height: 5, borderRadius: 3 },
  statusChipText: { fontSize: 10, fontWeight: '800' },
  upcomingRight: { alignItems: 'flex-end', gap: 6, marginLeft: 8 },
  upcomingPrice: { fontSize: 15, fontWeight: '900', fontVariant: ['tabular-nums'] },
  mapBtn: {
    width: 30,
    height: 30,
    borderRadius: 15,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },

  countdownTrack: { height: 3, width: '100%' },
  countdownFill: { height: '100%', borderTopRightRadius: 2, borderBottomRightRadius: 2 },
  requestBody: { paddingHorizontal: 13, paddingTop: 10, paddingBottom: 0 },
  offerCard: { borderTopLeftRadius: CARD_RADIUS, borderTopRightRadius: CARD_RADIUS, overflow: 'hidden' },
  shape: { position: 'absolute', top: 0, left: 0 },
  notchBand: {
    height: DOCK_NOTCH_DEPTH + 2,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 4,
  },
  requestHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 8,
    marginBottom: 10,
  },
  requestHeaderLeft: { flexDirection: 'row', alignItems: 'center', gap: 8, flexShrink: 1, minWidth: 0 },
  newTag: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  newDotWrap: { width: 8, height: 8, alignItems: 'center', justifyContent: 'center' },
  newDotRing: { position: 'absolute', width: 8, height: 8, borderRadius: 4 },
  newDot: { width: 7, height: 7, borderRadius: 3.5 },
  newTagText: { fontSize: 10, fontWeight: '900', letterSpacing: 0.9 },
  whenChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingVertical: 3,
    paddingHorizontal: 9,
    borderRadius: 999,
    borderWidth: 1,
    flexShrink: 1,
    minWidth: 0,
  },
  whenText: { fontSize: 11.5, fontWeight: '800', flexShrink: 1 },
  timer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingVertical: 4,
    paddingHorizontal: 9,
    borderRadius: 999,
    borderWidth: 1,
  },
  timerText: { fontSize: 13, fontWeight: '800', fontVariant: ['tabular-nums'] },
  requestHero: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  requestIcon: {
    width: 48,
    height: 48,
    borderRadius: 16,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  requestHeroCopy: { flex: 1, minWidth: 0 },
  requestTitle: { fontSize: 17, fontWeight: '800', letterSpacing: -0.2 },
  requestCustomerRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 4 },
  customerAvatar: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  customerInitials: { fontSize: 8.5, fontWeight: '900' },
  requestCustomer: { flex: 1, fontSize: 13, fontWeight: '600' },
  requestEarn: { alignItems: 'flex-end' },
  requestEarnLabel: { fontSize: 9, fontWeight: '800', letterSpacing: 0.9 },
  requestPrice: { fontSize: 24, fontWeight: '900', fontVariant: ['tabular-nums'], letterSpacing: -0.6 },
  journey: { marginTop: 11, borderRadius: 14, borderWidth: 1, paddingHorizontal: 10, paddingTop: 9, paddingBottom: 8, gap: 6 },
  journeyTrack: { flexDirection: 'row', alignItems: 'center' },
  journeyNode: { width: 22, height: 22, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  journeyNodeEnd: { borderWidth: 1.5, backgroundColor: 'rgba(255,255,255,0.06)' },
  journeyLine: { flex: 1, height: 22, justifyContent: 'center', alignItems: 'center', marginHorizontal: 4 },
  journeyDash: { position: 'absolute', left: 0, right: 0, top: 10, borderTopWidth: 1.5, borderStyle: 'dashed' },
  journeyLeg: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 999, borderWidth: 1 },
  journeyLegText: { fontSize: 11, fontWeight: '800', fontVariant: ['tabular-nums'] },
  journeyCue: { alignItems: 'flex-end', marginLeft: 10, minWidth: 54 },
  journeyCueLabel: { fontSize: 8.5, fontWeight: '900', letterSpacing: 0.8 },
  journeyCueValue: { fontSize: 14, fontWeight: '900', fontVariant: ['tabular-nums'] },
  journeyAddress: { fontSize: 11.5, fontWeight: '600' },
  split: { width: 84, gap: 4 },
  splitTrack: { width: '100%', height: 5, borderRadius: 3, overflow: 'hidden' },
  splitFill: { height: '100%', borderRadius: 3 },
  splitText: { fontSize: 10.5, fontWeight: '800', fontVariant: ['tabular-nums'] },
  mapHint: { width: 84, flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: 4 },
  mapHintText: { fontSize: 10.5, fontWeight: '800' },
});
