import React, { useMemo } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Reanimated, { FadeIn, FadeOut, ZoomIn } from 'react-native-reanimated';
import { ChromeGlyph as Ionicons, type IconGlyphName } from '../shared/ChromeGlyph';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { turnPhrase, type RouteTurn } from '../../utils/routeTurnAhead';
import ValeterDashboardChrome from './ValeterDashboardChrome';
import { aheadText, manoeuvre } from './ValeterNavBanner';

const GAP_TOP = 6;
const GAP_BOTTOM = 6;
const MAIN_H = 56;
const STRIP_H = 26;
const TILE = 40;
const HERE_GREEN = '#10B981';

/** Total chrome below the safe area while the directions header is showing. */
export function valeterNavHeaderTotalHeight(safeTop: number) {
  return safeTop + GAP_TOP + MAIN_H + STRIP_H + GAP_BOTTOM;
}

function clock(at: Date) {
  return `${at.getHours()}:${String(at.getMinutes()).padStart(2, '0')}`;
}

function arrivalClock(etaMin: number) {
  return clock(new Date(Date.now() + Math.max(1, etaMin) * 60000));
}

function instruction({
  turn,
  nearby,
  arrived,
  street,
  serviceNoun,
}: Readonly<{ turn: RouteTurn | null; nearby: boolean; arrived: boolean; street: string | null; serviceNoun: string }>): Readonly<{
  icon: IconGlyphName;
  big: string;
  small: string;
}> {
  if (arrived) return { icon: 'mci:flag-checkered', big: "You've arrived", small: `Hold the green button to start the ${serviceNoun}` };
  if (nearby) return { icon: 'mci:map-marker-check', big: "You're here", small: 'Hold the green button to mark arrived' };
  if (turn) return { icon: manoeuvre(turn).icon, big: aheadText(turn.inMetres), small: turnPhrase(turn) };
  return { icon: 'mci:arrow-up', big: 'Straight on', small: street ? `towards ${street}` : 'to your customer' };
}

/**
 * Sat-nav header for the drive to a job. Takes the map header's place while en route: the next
 * manoeuvre and distance to it up top, then time, distance and arrival time to the customer.
 * With `arrived` it settles into the finished state for the arrived step.
 */
export default function ValeterNavHeader({
  turn,
  etaMin,
  miles,
  street,
  accent,
  headerGradient,
  nearby = false,
  arrived = false,
  arrivedAt = null,
  serviceNoun = 'wash',
  voiceMuted,
  onToggleVoice,
  onOpenMaps,
}: Readonly<{
  turn: RouteTurn | null;
  etaMin: number | null;
  miles: number | null;
  street: string | null;
  accent: string;
  headerGradient: readonly [string, string];
  /** Within ~100 m of the customer but not yet marked arrived. */
  nearby?: boolean;
  /** Marked arrived: directions are done, the header confirms it instead. */
  arrived?: boolean;
  /** When the job was marked arrived (ISO), for the "Arrived 16:20" stamp. */
  arrivedAt?: string | null;
  /** What the Pro starts on arrival: "wash", "detail" or "repair". */
  serviceNoun?: string;
  voiceMuted?: boolean;
  onToggleVoice?: () => void;
  /** Hand the drive to Apple Maps / Google Maps / Waze. */
  onOpenMaps?: () => void;
}>) {
  const insets = useSafeAreaInsets();
  const step = instruction({ turn, nearby, arrived, street, serviceNoun });
  const tone = nearby || arrived ? HERE_GREEN : accent;
  const arrivedStamp = useMemo(() => {
    if (!arrived) return null;
    const at = arrivedAt ? new Date(arrivedAt) : new Date();
    return clock(Number.isNaN(at.getTime()) ? new Date() : at);
  }, [arrived, arrivedAt]);

  return (
    <Reanimated.View
      entering={FadeIn.duration(280)}
      exiting={FadeOut.duration(180)}
      style={[styles.wrap, { paddingTop: insets.top + GAP_TOP }]}
      pointerEvents="box-none"
    >
      <LinearGradient
        pointerEvents="none"
        colors={['rgba(6,14,24,0.78)', 'rgba(6,14,24,0.3)', 'transparent']}
        style={[styles.statusScrim, { height: insets.top + MAIN_H }]}
      />
      <View style={styles.card}>
        <View style={styles.chromeClip} pointerEvents="none">
          <ValeterDashboardChrome accent={accent} headerGradient={headerGradient} />
        </View>

        <View style={styles.main}>
          <Reanimated.View key={step.icon} entering={ZoomIn.duration(220)}>
            <LinearGradient colors={[tone, `${tone}B3`]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.tile}>
              <Ionicons name={step.icon} size={23} color="#FFFFFF" />
            </LinearGradient>
          </Reanimated.View>

          <View style={styles.copy} accessibilityLiveRegion="polite">
            <Text style={styles.big} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.75}>
              {step.big}
            </Text>
            <Text style={styles.small} numberOfLines={1}>
              {step.small}
            </Text>
          </View>

          {onOpenMaps && !arrived ? (
            <Pressable
              onPress={() => {
                void hapticFeedback('light');
                onOpenMaps();
              }}
              hitSlop={8}
              style={({ pressed }) => [styles.voice, styles.voiceOff, pressed && styles.pressed]}
              accessibilityRole="button"
              accessibilityLabel="Navigate with another maps app"
            >
              <Ionicons name="map" size={16} color="#F8FAFC" />
            </Pressable>
          ) : null}
          {onToggleVoice && !arrived ? (
            <Pressable
              onPress={() => {
                void hapticFeedback('light');
                onToggleVoice();
              }}
              hitSlop={8}
              style={({ pressed }) => [
                styles.voice,
                voiceMuted ? styles.voiceOff : { backgroundColor: `${accent}26`, borderColor: `${accent}66` },
                pressed && styles.pressed,
              ]}
              accessibilityRole="button"
              accessibilityLabel={voiceMuted ? 'Turn voice guidance on' : 'Mute voice guidance'}
            >
              <Ionicons
                name={voiceMuted ? 'volume-mute' : 'volume-high'}
                size={16}
                color={voiceMuted ? 'rgba(203,213,225,0.6)' : '#F8FAFC'}
              />
            </Pressable>
          ) : null}
        </View>

        <TripStrip arrivedStamp={arrivedStamp} etaMin={etaMin} miles={miles} street={street} tone={tone} />
      </View>
    </Reanimated.View>
  );
}

/** Bottom strip: time, distance and arrival clock while driving; the arrival stamp once there. */
function TripStrip({
  arrivedStamp,
  etaMin,
  miles,
  street,
  tone,
}: Readonly<{ arrivedStamp: string | null; etaMin: number | null; miles: number | null; street: string | null; tone: string }>) {
  const eta = etaMin != null && Number.isFinite(etaMin) ? etaMin : null;
  return (
    <View style={styles.strip}>
      {arrivedStamp ? (
        <View style={styles.stats}>
          <Ionicons name="checkmark-circle" size={14} color={HERE_GREEN} />
          <Text style={[styles.eta, { color: HERE_GREEN }]}>Arrived {arrivedStamp}</Text>
        </View>
      ) : (
        <View style={styles.stats}>
          <Text style={[styles.eta, { color: tone }]}>{eta == null ? '—' : `${Math.max(1, Math.round(eta))} min`}</Text>
          {miles == null ? null : (
            <>
              <View style={styles.dot} />
              <Text style={styles.stat}>{miles.toFixed(1)} mi</Text>
            </>
          )}
          {eta == null ? null : (
            <>
              <View style={styles.dot} />
              <Text style={styles.stat}>Arrive {arrivalClock(eta)}</Text>
            </>
          )}
        </View>
      )}
      {street ? (
        <View style={styles.dest}>
          <Ionicons name="flag" size={11} color="rgba(203,213,225,0.75)" />
          <Text style={styles.destText} numberOfLines={1}>
            {street}
          </Text>
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 20,
    paddingHorizontal: 12,
    paddingBottom: GAP_BOTTOM,
  },
  statusScrim: { position: 'absolute', top: 0, left: 0, right: 0 },
  card: {
    borderRadius: 24,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.2,
    shadowRadius: 18,
    elevation: 12,
  },
  chromeClip: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, borderRadius: 23, overflow: 'hidden', opacity: 0.6 },
  main: {
    height: MAIN_H,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 10,
  },
  tile: {
    width: TILE,
    height: TILE,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.22)',
  },
  copy: { flex: 1, minWidth: 0 },
  big: {
    color: '#F8FAFC',
    fontSize: 16,
    fontWeight: '900',
    letterSpacing: -0.3,
    fontVariant: ['tabular-nums'],
  },
  small: { marginTop: 1, color: 'rgba(226,232,240,0.88)', fontSize: 11.5, fontWeight: '700', letterSpacing: -0.1 },
  voice: {
    width: 34,
    height: 34,
    borderRadius: 17,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  voiceOff: { backgroundColor: 'rgba(255,255,255,0.06)', borderColor: 'rgba(255,255,255,0.12)' },
  pressed: { opacity: 0.7 },
  strip: {
    height: STRIP_H,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 14,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(255,255,255,0.12)',
    backgroundColor: 'rgba(2,6,23,0.16)',
    borderBottomLeftRadius: 23,
    borderBottomRightRadius: 23,
  },
  stats: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  eta: { fontSize: 11, fontWeight: '900', fontVariant: ['tabular-nums'] },
  stat: { color: '#E2E8F0', fontSize: 10.5, fontWeight: '700', fontVariant: ['tabular-nums'] },
  dot: { width: 3, height: 3, borderRadius: 1.5, backgroundColor: 'rgba(203,213,225,0.5)' },
  dest: { flex: 1, minWidth: 0, flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: 4 },
  destText: { flexShrink: 1, color: 'rgba(203,213,225,0.75)', fontSize: 10, fontWeight: '600' },
});
