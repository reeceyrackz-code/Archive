import React from 'react';
import { Alert, Linking, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import InfoBottomSheet from '../shared/InfoBottomSheet';
import { ChromeGlyph as Ionicons, type IconGlyphName } from '../shared/ChromeGlyph';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import { hapticFeedback } from '../../services/HapticFeedbackService';

type ProblemId = 'find' | 'noreply' | 'vehicle' | 'unsafe' | 'other';

const PROBLEMS: ReadonlyArray<{ id: ProblemId; icon: IconGlyphName; title: string; sub: string }> = [
  { id: 'find', icon: 'search-outline', title: "Can't find the customer", sub: 'Message them for directions or a gate code' },
  { id: 'noreply', icon: 'time-outline', title: "Customer isn't responding", sub: 'Support can reach them and step in' },
  { id: 'vehicle', icon: 'construct-outline', title: 'Vehicle or kit problem', sub: 'Breakdown, flat tyre, equipment failure' },
  { id: 'unsafe', icon: 'shield-outline', title: 'I feel unsafe', sub: 'Get help straight away' },
  { id: 'other', icon: 'help-circle-outline', title: 'Something else', sub: 'Talk to support' },
];

const DANGER = '#F87171';

/** Shown instead of Cancel once the valeter has set off: routes each problem to chat, support or emergency help. */
export default function ReportProblemSheet({
  visible,
  accent,
  chatLocked,
  onClose,
  onChat,
  onSupport,
}: Readonly<{
  visible: boolean;
  accent: string;
  chatLocked: boolean;
  onClose: () => void;
  onChat: () => void;
  onSupport: () => void;
}>) {
  const { theme } = useAccountTheme();
  const textMain = theme.textPrimary ?? '#F8FAFC';
  const textMuted = theme.textSecondary ?? 'rgba(248,250,252,0.65)';

  const handle = (id: ProblemId) => {
    void hapticFeedback('light');
    onClose();
    if (id === 'find' && !chatLocked) {
      onChat();
      return;
    }
    if (id === 'unsafe') {
      Alert.alert('Are you in danger?', 'If you or anyone else is in immediate danger, call 999.', [
        { text: 'Call 999', style: 'destructive', onPress: () => void Linking.openURL('tel:999') },
        { text: 'Contact support', onPress: onSupport },
        { text: 'Cancel', style: 'cancel' },
      ]);
      return;
    }
    onSupport();
  };

  return (
    <InfoBottomSheet visible={visible} onClose={onClose} title="Report a problem" accentColor={accent} variant="header" sizeToContent>
      <Text style={[styles.lead, { color: textMuted }]}>
        You can&apos;t cancel once you&apos;re on the way — tell us what&apos;s wrong and we&apos;ll help.
      </Text>
      <View style={styles.list}>
        {PROBLEMS.map((p, i) => {
          const tone = p.id === 'unsafe' ? DANGER : accent;
          return (
            <TouchableOpacity
              key={p.id}
              onPress={() => handle(p.id)}
              activeOpacity={0.7}
              style={[styles.row, i > 0 && styles.rowDivider]}
              accessibilityRole="button"
              accessibilityLabel={p.title}
            >
              <View style={[styles.icon, { backgroundColor: `${tone}1F` }]}>
                <Ionicons name={p.icon} size={18} color={tone} />
              </View>
              <View style={styles.copy}>
                <Text style={[styles.title, { color: p.id === 'unsafe' ? DANGER : textMain }]}>{p.title}</Text>
                <Text style={[styles.sub, { color: textMuted }]} numberOfLines={1}>
                  {p.sub}
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={16} color={textMuted} />
            </TouchableOpacity>
          );
        })}
      </View>
    </InfoBottomSheet>
  );
}

const styles = StyleSheet.create({
  lead: { fontSize: 13.5, lineHeight: 19, marginBottom: 12 },
  list: {
    borderRadius: 16,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(148,163,184,0.28)',
    overflow: 'hidden',
  },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 12, paddingHorizontal: 12 },
  rowDivider: { borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: 'rgba(148,163,184,0.22)' },
  icon: { width: 36, height: 36, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  copy: { flex: 1, minWidth: 0 },
  title: { fontSize: 15, fontWeight: '700' },
  sub: { fontSize: 12.5, marginTop: 2 },
});
