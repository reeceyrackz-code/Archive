import React, { useCallback, useEffect, useRef, useState } from 'react';
import { View, StyleSheet, Pressable, type LayoutChangeEvent } from 'react-native';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Reanimated, {
  Easing,
  Extrapolation,
  interpolate,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { scheduleOnRN } from 'react-native-worklets';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import { hapticFeedback } from '../../services/HapticFeedbackService';

const HEIGHT = 50;
const PAD = 4;
const THUMB = HEIGHT - PAD * 2;
const COMPLETE_AT = 0.86;

export type SlideToAcceptProps = Readonly<{
  label: string;
  accent: string;
  onAccept: () => void | Promise<void>;
  disabled?: boolean;
}>;

/** Drag the thumb to the end to confirm — prevents accidental accepts from pocket / mount taps. */
export default function SlideToAccept({ label, accent, onAccept, disabled = false }: SlideToAcceptProps) {
  const [trackWidth, setTrackWidth] = useState(0);
  const [accepted, setAccepted] = useState(false);
  const maxX = Math.max(0, trackWidth - THUMB - PAD * 2);
  const x = useSharedValue(0);
  const startX = useSharedValue(0);
  const passedHalf = useSharedValue(false);
  const shimmer = useSharedValue(0);
  const nudge = useSharedValue(0);

  useEffect(() => {
    shimmer.value = withRepeat(withTiming(1, { duration: 1800, easing: Easing.inOut(Easing.ease) }), -1, false);
  }, [shimmer]);

  const mountedRef = useRef(true);
  useEffect(() => () => {
    mountedRef.current = false;
  }, []);

  const fireAccept = useCallback(() => {
    setAccepted(true);
    void hapticFeedback('success');
    // If the card is still here afterwards the accept didn't go through — reset the slider.
    void Promise.resolve(onAccept()).finally(() => {
      setTimeout(() => {
        if (!mountedRef.current) return;
        setAccepted(false);
        x.value = withSpring(0, { damping: 16, stiffness: 220 });
        passedHalf.value = false;
      }, 600);
    });
  }, [onAccept, x, passedHalf]);

  const tick = useCallback(() => {
    void hapticFeedback('light');
  }, []);

  const pan = Gesture.Pan()
    .enabled(!disabled && !accepted && maxX > 0)
    .activeOffsetX(6)
    .failOffsetY([-14, 14])
    .onBegin(() => {
      startX.value = x.value;
    })
    .onUpdate((e) => {
      x.value = Math.min(maxX, Math.max(0, startX.value + e.translationX));
      const half = x.value > maxX * 0.5;
      if (half !== passedHalf.value) {
        passedHalf.value = half;
        scheduleOnRN(tick);
      }
    })
    .onEnd((e) => {
      const done = x.value >= maxX * COMPLETE_AT || (x.value > maxX * 0.55 && e.velocityX > 900);
      if (done) {
        x.value = withTiming(maxX, { duration: 120 });
        scheduleOnRN(fireAccept);
      } else {
        x.value = withSpring(0, { damping: 16, stiffness: 220 });
        passedHalf.value = false;
      }
    });

  const thumbStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: x.value + nudge.value }],
  }));

  const fillStyle = useAnimatedStyle(() => ({
    width: x.value + nudge.value + THUMB + PAD,
    opacity: interpolate(x.value, [0, maxX || 1], [0.35, 1], Extrapolation.CLAMP),
  }));

  const labelStyle = useAnimatedStyle(() => ({
    opacity: interpolate(x.value, [0, (maxX || 1) * 0.6], [1, 0], Extrapolation.CLAMP),
  }));

  const shimmerStyle = useAnimatedStyle(() => ({
    opacity: interpolate(shimmer.value, [0, 0.5, 1], [0.55, 1, 0.55]),
  }));

  const chevronStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: interpolate(shimmer.value, [0, 0.5, 1], [0, 3, 0]) }],
  }));

  /** Tap on the track = gentle nudge showing the gesture, not an accept. */
  const hint = () => {
    if (disabled || accepted) return;
    void hapticFeedback('light');
    nudge.value = withSequence(
      withTiming(Math.min(40, maxX * 0.3), { duration: 180, easing: Easing.out(Easing.cubic) }),
      withSpring(0, { damping: 10, stiffness: 200 })
    );
  };

  const onLayout = (e: LayoutChangeEvent) => setTrackWidth(e.nativeEvent.layout.width);

  return (
    <Pressable
      onPress={hint}
      onLayout={onLayout}
      style={[styles.track, { backgroundColor: `${accent}22`, borderColor: `${accent}55`, opacity: disabled ? 0.5 : 1 }]}
      accessibilityRole="adjustable"
      accessibilityLabel={label}
      accessibilityHint="Slide right to accept this job"
      accessibilityActions={[{ name: 'activate', label: 'Accept job' }]}
      onAccessibilityAction={(e) => {
        if (e.nativeEvent.actionName === 'activate' && !disabled && !accepted) fireAccept();
      }}
    >
      <Reanimated.View style={[styles.fill, { backgroundColor: accent }, fillStyle]} pointerEvents="none" />

      <Reanimated.View style={[styles.labelWrap, labelStyle]} pointerEvents="none">
        <Reanimated.Text style={[styles.label, shimmerStyle]} numberOfLines={1}>
          {accepted ? 'Accepting…' : label}
        </Reanimated.Text>
        <Reanimated.View style={chevronStyle}>
          <Ionicons name="chevron-forward" size={14} color="rgba(248,250,252,0.75)" />
        </Reanimated.View>
      </Reanimated.View>

      <GestureDetector gesture={pan}>
        <Reanimated.View style={[styles.thumb, thumbStyle]} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
          <View style={[styles.thumbInner, { backgroundColor: accent }]}>
            <Ionicons name={accepted ? 'checkmark' : 'arrow-forward'} size={20} color="#0A1929" />
          </View>
        </Reanimated.View>
      </GestureDetector>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  track: {
    flex: 1,
    height: HEIGHT,
    borderRadius: HEIGHT / 2,
    borderWidth: 1,
    justifyContent: 'center',
    overflow: 'hidden',
  },
  fill: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    borderRadius: HEIGHT / 2,
  },
  labelWrap: {
    position: 'absolute',
    left: THUMB + PAD * 2,
    right: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 2,
  },
  label: {
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '800',
    letterSpacing: 0.2,
    fontVariant: ['tabular-nums'],
  },
  thumb: {
    position: 'absolute',
    left: PAD,
    width: THUMB,
    height: THUMB,
  },
  thumbInner: {
    flex: 1,
    borderRadius: THUMB / 2,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 5,
  },
});
