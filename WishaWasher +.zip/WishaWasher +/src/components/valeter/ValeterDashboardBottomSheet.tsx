import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Dimensions,
  NativeSyntheticEvent,
  NativeScrollEvent,
  Animated,
  PanResponder,
  LayoutAnimation,
  type GestureResponderHandlers,
  type PanResponderGestureState,
} from 'react-native';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { HEADER_STYLE_CARD_GRADIENT } from '../../constants/bookingCardTheme';
import {
  ValeterJobRequestCard,
  ValeterResumeJobCard,
} from './ValeterSheetJobCards';
import type { ValeterJobRequest } from './ValeterJobRequestOverlay';
import { confirmDecline } from '../../utils/declineConfirm';
import ValeterDashboardChrome, { softenedTint } from './ValeterDashboardChrome';
import { ScrollView as GestureScrollView } from 'react-native-gesture-handler';
import Reanimated, {
  Easing,
  FadeIn,
  FadeInDown,
  FadeInRight,
  FadeOutDown,
  LinearTransition,
  ZoomOut,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withRepeat,
  withTiming,
} from 'react-native-reanimated';
import { PressableScale, SymbolGlyph } from '../shared/fit/FitKit';
import DefaultLoadingSkeleton from '../shared/DefaultLoadingSkeleton';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import type { IconGlyphName } from '../shared/iconGlyphTypes';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import ValeterDashboardFloatingDock, {
  VALETER_DOCK_ROW_HEIGHT,
  DOCK_CARD_OVERLAP,
  type DockOffer,
  type DockTrip,
  DOCK_SIDE_INSET,
} from './ValeterDashboardFloatingDock';

const { height: SCREEN_HEIGHT, width: SCREEN_WIDTH } = Dimensions.get('window');
/** Tall enough for request cards + Accept/Decline under them. */
const SHEET_HEIGHT_RATIO = 0.4;
const SHEET_PAD_H = 16;
const REQUEST_CARD_GAP = 10;
const REQUEST_CARD_WIDTH = SCREEN_WIDTH - DOCK_SIDE_INSET * 2;
/** Side inset that centres a card on screen, so its notch sits over the dock's hump. */
const REQUEST_CARD_INSET = DOCK_SIDE_INSET;
/** Page dots + notched offer card (Accept / Decline live in the dock). */
const OFFER_STACK_HEIGHT = 238;

export const VALETER_SHEET_FIXED_HEIGHT = Math.round(SCREEN_HEIGHT * SHEET_HEIGHT_RATIO);
/** Fallback tracking height before content measures; sheet hugs measured content. */
export const VALETER_TRACKING_SHEET_HEIGHT = Math.round(SCREEN_HEIGHT * 0.32);
/** Handle + swipe-hint chrome above embedded tracking content. */
export const VALETER_TRACKING_SHEET_CHROME = 36;
/** Nav dock row inside the sheet footer (excludes safe-area inset). */
export { VALETER_DOCK_ROW_HEIGHT };

/** Peek height while on-trip sheet is minimized (excludes dock footer). */
export const VALETER_TRIP_PEEK_BODY = 92;

export function valeterTripPeekSheetHeight(safeBottom: number) {
  return VALETER_TRIP_PEEK_BODY + VALETER_DOCK_ROW_HEIGHT + Math.max(safeBottom, 8);
}

/** Offers, or the live trip. Upcoming / current jobs live on the Activity screen. */
export type DashboardSheetPanel = 'tracking' | 'request';

export type ActiveJobRow = Readonly<{
  id: string;
  status: string;
  service_type?: string | null;
  service_name?: string | null;
  location_address?: string | null;
  location_lat?: number | null;
  location_lng?: number | null;
  price: number;
}>;

function RadarRing({ color, delay }: Readonly<{ color: string; delay: number }>) {
  const t = useSharedValue(0);
  useEffect(() => {
    t.value = withDelay(delay, withRepeat(withTiming(1, { duration: 2000, easing: Easing.out(Easing.quad) }), -1, false));
  }, [delay, t]);
  const style = useAnimatedStyle(() => ({
    opacity: 0.55 * (1 - t.value),
    transform: [{ scale: 0.4 + t.value * 1.1 }],
  }));
  return <Reanimated.View pointerEvents="none" style={[styles.radarRing, { borderColor: color }, style]} />;
}

/** Compact "listening for work" row — radar pulse beside a two-line message. */
function SearchingRow({
  accent,
  muted,
  title,
  subtitle,
  sf,
  ion,
}: Readonly<{
  accent: string;
  muted: string;
  title: string;
  subtitle: string;
  sf: React.ComponentProps<typeof SymbolGlyph>['sf'];
  ion: IconGlyphName;
}>) {
  return (
    <Reanimated.View entering={FadeIn.duration(300)} style={styles.searchingRow}>
      <View style={styles.radar}>
        <RadarRing color={accent} delay={0} />
        <RadarRing color={accent} delay={1000} />
        <View style={[styles.radarCore, { backgroundColor: `${accent}26`, borderColor: `${accent}55` }]}>
          <SymbolGlyph sf={sf} ion={ion} size={16} color={accent} />
        </View>
      </View>
      <View style={styles.searchingCopy}>
        <Text style={styles.searchingTitle} numberOfLines={1}>
          {title}
        </Text>
        <Text style={[styles.searchingSub, { color: muted }]} numberOfLines={1}>
          {subtitle}
        </Text>
      </View>
    </Reanimated.View>
  );
}

function ResumeTripCard({
  accent,
  job,
  customerName,
  onPress,
}: Readonly<{ accent: string; job: ActiveJobRow; customerName?: string; onPress: () => void }>) {
  return (
    <View style={styles.resumeWrap}>
      <ValeterResumeJobCard
        accent={accent}
        status={job.status}
        serviceType={job.service_type}
        serviceName={job.service_name}
        customerName={customerName}
        onPress={onPress}
      />
    </View>
  );
}

/** Offers empty state while offline — explains why nothing arrives and offers the toggle. */
function OfflineOffersRow({
  muted,
  busy,
  onGoOnline,
}: Readonly<{ muted: string; busy: boolean; onGoOnline?: () => void }>) {
  return (
    <Reanimated.View entering={FadeIn.duration(300)} style={styles.searchingRow}>
      <View style={[styles.offlineIcon]}>
        <Ionicons name="power" size={18} color="#F87171" />
      </View>
      <View style={styles.searchingCopy}>
        <Text style={styles.searchingTitle} numberOfLines={1}>
          You're offline
        </Text>
        <Text style={[styles.searchingSub, { color: muted }]} numberOfLines={1}>
          Go online to receive job offers
        </Text>
      </View>
      {onGoOnline ? (
        <PressableScale
          onPress={onGoOnline}
          disabled={busy}
          style={[styles.goOnlineBtn, busy && { opacity: 0.6 }]}
          accessibilityLabel="Go online"
        >
          <Ionicons name="power" size={13} color="#052e16" />
          <Text style={styles.goOnlineText}>{busy ? 'Updating' : 'Go online'}</Text>
        </PressableScale>
      ) : null}
    </Reanimated.View>
  );
}

function PageDots({ count, index, accent }: Readonly<{ count: number; index: number; accent: string }>) {
  if (count < 2) return null;
  return (
    <View style={styles.pageDots} pointerEvents="none">
      {Array.from({ length: count }, (_, i) => `page-${i}`).map((id, i) => (
        <View
          key={id}
          style={[
            styles.pageDot,
            i === index ? { width: 16, backgroundColor: accent } : { backgroundColor: 'rgba(255,255,255,0.25)' },
          ]}
        />
      ))}
    </View>
  );
}

const DECLINE_UNDO_MS = 4000;

function UndoCountdown({ color }: Readonly<{ color: string }>) {
  const p = useSharedValue(1);
  useEffect(() => {
    p.value = withTiming(0, { duration: DECLINE_UNDO_MS, easing: Easing.linear });
  }, [p]);
  const style = useAnimatedStyle(() => ({ width: `${p.value * 100}%` }));
  return (
    <View style={styles.undoTrack} pointerEvents="none">
      <Reanimated.View style={[styles.undoFill, { backgroundColor: color }, style]} />
    </View>
  );
}

/** Compact browse sheet when Offers is empty (no tall empty gap). */
export function valeterCompactBrowseSheetHeight(safeBottom: number, opts: { hasResume?: boolean } = {}) {
  const dockFooterHeight = VALETER_DOCK_ROW_HEIGHT + Math.max(safeBottom, 8);
  return (
    14 + // handle
    (opts.hasResume ? 74 : 0) +
    64 + // short empty line
    dockFooterHeight
  );
}

/** Offers with cards — the card hangs into the dock row and its notched edge wraps the hump. */
export function valeterOffersSheetHeight(safeBottom: number, opts: { hasResume?: boolean } = {}) {
  const dockFooterHeight = VALETER_DOCK_ROW_HEIGHT + Math.max(safeBottom, 8);
  return (
    12 + // handle chrome
    (opts.hasResume ? 74 : 0) +
    6 + // top pad
    OFFER_STACK_HEIGHT -
    DOCK_CARD_OVERLAP +
    dockFooterHeight
  );
}

type ValeterDashboardBottomSheetProps = Readonly<{
  accent: string;
  headerGradient?: readonly [string, string];
  panel?: DashboardSheetPanel;
  focusedJobId?: string | null;
  activeJob?: ActiveJobRow | null;
  activeJobLoading?: boolean;
  activeCustomerName?: string;
  jobRequests?: ValeterJobRequest[];
  jobRequestCount?: number;
  /** Live tracking UI for the Tracking tab (embedded). */
  trackingContent?: React.ReactNode;
  /** Measured height of embedded tracking content (card + actions). */
  trackingContentHeight?: number | null;
  onPanelChange: (panel: DashboardSheetPanel) => void;
  onFocusJobOnMap: (jobId: string, lat: number, lng: number) => void;
  onActiveJobPress: () => void;
  onAcceptJob: (jobId: string) => void | Promise<void>;
  onDeclineJob: (jobId: string) => void;
  refreshing?: boolean;
  onRefresh?: () => void;
  /** Swipe-down on tracking panel exits live tracking (only when trip is not locked). */
  onTrackingDismiss?: () => void;
  /** While true, trip stays locked — swipe minimizes for map instead of returning to Scheduled. */
  tripLocked?: boolean;
  tripMinimized?: boolean;
  onTripMinimizedChange?: (minimized: boolean) => void;
  /** Fired when the nav dock is tucked away / revealed during tracking. */
  onTrackingDockHiddenChange?: (hidden: boolean) => void;
  /** Rendered sheet height (px) — lets the map pad exactly to the sheet. */
  onSheetHeightChange?: (height: number) => void;
  /** Presence for the centre online button in the nav dock. */
  isOnline?: boolean;
  onlineBusy?: boolean;
  onToggleOnline?: () => void;
  /** Live job: dock becomes Home · Chat · hold-to-confirm next step · Cancel. */
  trip?: DockTrip | null;
  /** Tracking content is just the steps road over the dock: drop the sheet chrome so the map shows through. */
  roadOnly?: boolean;
}>;

const DOCK_TOGGLE_ANIMATION = LayoutAnimation.create(240, 'easeInEaseOut', 'opacity');
const TRACKING_PANEL_TOP_PAD = 8;
const TRACKING_PANEL_BOTTOM_GAP = 10;
/** The theme's sky tint is strong once the trip card stacks on the sheet's glass — keep under half of it. */
const TRACKING_TINT = 0.4;

type PendingDecline = { id: string; name: string } | null;
type TimerRef = React.RefObject<ReturnType<typeof setTimeout> | null>;
type FocusableJob = { id: string; location_lat?: number | null; location_lng?: number | null };

function clearDeclineTimer(timerRef: TimerRef) {
  if (timerRef.current) clearTimeout(timerRef.current);
  timerRef.current = null;
}

function pruneDeclinedIds(prev: string[], live: Set<string>) {
  const next = prev.filter((id) => live.has(id));
  return next.length === prev.length ? prev : next;
}

/** Declines wait a few seconds so an accidental tap can be undone. */
function useDeclineUndo(incomingJobRequests: ValeterJobRequest[], onDeclineJob: (jobId: string) => void) {
  const [pendingDecline, setPendingDecline] = useState<PendingDecline>(null);
  const [declinedIds, setDeclinedIds] = useState<string[]>([]);
  const declineTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pendingDeclineRef = useRef<string | null>(null);
  const onDeclineJobRef = useRef(onDeclineJob);
  onDeclineJobRef.current = onDeclineJob;

  const commitPendingDecline = useCallback(() => {
    clearDeclineTimer(declineTimerRef);
    const id = pendingDeclineRef.current;
    pendingDeclineRef.current = null;
    if (!id) return;
    setDeclinedIds((prev) => (prev.includes(id) ? prev : [...prev, id]));
    setPendingDecline(null);
    onDeclineJobRef.current(id);
  }, []);

  const requestDecline = useCallback(
    async (job: ValeterJobRequest) => {
      if (!(await confirmDecline(job.serviceName))) return;
      commitPendingDecline();
      void hapticFeedback('light');
      pendingDeclineRef.current = job.id;
      setPendingDecline({ id: job.id, name: job.serviceName });
      declineTimerRef.current = setTimeout(commitPendingDecline, DECLINE_UNDO_MS);
    },
    [commitPendingDecline]
  );

  const undoDecline = useCallback(() => {
    clearDeclineTimer(declineTimerRef);
    pendingDeclineRef.current = null;
    setPendingDecline(null);
    void hapticFeedback('success');
  }, []);

  useEffect(() => () => commitPendingDecline(), [commitPendingDecline]);

  /** Forget ids once the offer leaves the feed (declined, expired or taken). */
  useEffect(() => {
    const live = new Set(incomingJobRequests.map((j) => j.id));
    setDeclinedIds((prev) => pruneDeclinedIds(prev, live));
    if (pendingDeclineRef.current && !live.has(pendingDeclineRef.current)) {
      clearDeclineTimer(declineTimerRef);
      pendingDeclineRef.current = null;
      setPendingDecline(null);
    }
  }, [incomingJobRequests]);

  const jobRequests = useMemo(
    () =>
      incomingJobRequests.filter((j) => j.id !== pendingDecline?.id && !declinedIds.includes(j.id)),
    [declinedIds, incomingJobRequests, pendingDecline]
  );

  return { pendingDecline, jobRequests, requestDecline, undoDecline };
}

function useRequestCarousel(
  jobRequests: ValeterJobRequest[],
  onFocusJobOnMap: (jobId: string, lat: number, lng: number) => void
) {
  const [requestPage, setRequestPage] = useState(0);
  useEffect(() => {
    if (requestPage > Math.max(0, jobRequests.length - 1)) setRequestPage(Math.max(0, jobRequests.length - 1));
  }, [jobRequests.length, requestPage]);
  const requestScrollRef = useRef<ScrollView>(null);

  const focusJob = (job: FocusableJob) => {
    if (job.location_lat != null && job.location_lng != null) {
      onFocusJobOnMap(job.id, job.location_lat, job.location_lng);
    }
  };

  const handleRequestScrollEnd = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
    if (jobRequests.length === 0) return;
    const stride = REQUEST_CARD_WIDTH + REQUEST_CARD_GAP;
    const index = Math.min(
      jobRequests.length - 1,
      Math.max(0, Math.round(event.nativeEvent.contentOffset.x / stride))
    );
    setRequestPage(index);
    const job = jobRequests[index];
    if (job) focusJob(job);
  };

  return { requestPage, setRequestPage, requestScrollRef, focusJob, handleRequestScrollEnd };
}

function useFocusedRequestScroll(
  panel: DashboardSheetPanel,
  focusedJobId: string | null | undefined,
  jobRequests: ValeterJobRequest[],
  setRequestPage: (page: number) => void,
  requestScrollRef: React.RefObject<ScrollView | null>
) {
  useEffect(() => {
    if (panel !== 'request' || !focusedJobId || jobRequests.length === 0) return;
    const index = jobRequests.findIndex((j) => j.id === focusedJobId);
    if (index < 0) return;
    setRequestPage(index);
    requestScrollRef.current?.scrollTo({
      x: index * (REQUEST_CARD_WIDTH + REQUEST_CARD_GAP),
      animated: true,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [focusedJobId, jobRequests, panel]);
}

function useTrackingDock(panel: DashboardSheetPanel, hasTripStep: boolean) {
  const [trackingDockHidden, setTrackingDockHidden] = useState(panel === 'tracking' && !hasTripStep);
  const hiddenRef = useRef(trackingDockHidden);

  /** Swipe gestures only — LayoutAnimation is global, so it would also animate whatever else mounts that frame. */
  const setDockHiddenAnimated = useCallback((hidden: boolean) => {
    if (hiddenRef.current === hidden) return;
    hiddenRef.current = hidden;
    LayoutAnimation.configureNext(DOCK_TOGGLE_ANIMATION);
    setTrackingDockHidden(hidden);
  }, []);

  /** Tuck the nav dock away when a trip starts — unless it carries the trip controls. Not animated: the panel swaps in the same frame. */
  useEffect(() => {
    const hidden = panel === 'tracking' && !hasTripStep;
    hiddenRef.current = hidden;
    setTrackingDockHidden(hidden);
  }, [panel, hasTripStep]);

  return [trackingDockHidden, setDockHiddenAnimated] as const;
}

function useSheetReporting({
  panel,
  dockHidden,
  resolvedSheetHeight,
  tripMinimized,
  onTrackingDockHiddenChange,
  onSheetHeightChange,
  onTripMinimizedChange,
}: Readonly<{
  panel: DashboardSheetPanel;
  dockHidden: boolean;
  resolvedSheetHeight: number;
  tripMinimized: boolean;
  onTrackingDockHiddenChange?: (hidden: boolean) => void;
  onSheetHeightChange?: (height: number) => void;
  onTripMinimizedChange?: (minimized: boolean) => void;
}>) {
  useEffect(() => {
    onTrackingDockHiddenChange?.(dockHidden);
  }, [dockHidden, onTrackingDockHiddenChange]);

  useEffect(() => {
    onSheetHeightChange?.(resolvedSheetHeight);
  }, [resolvedSheetHeight, onSheetHeightChange]);

  useEffect(() => {
    if (panel === 'tracking' && tripMinimized) onTripMinimizedChange?.(false);
  }, [panel, tripMinimized, onTripMinimizedChange]);
}

function settleTrackingDrag(
  g: PanResponderGestureState,
  {
    dismissDrag,
    trackingDockHidden,
    hasTripStep,
    setDockHiddenAnimated,
  }: Readonly<{
    dismissDrag: Animated.Value;
    trackingDockHidden: boolean;
    hasTripStep: boolean;
    setDockHiddenAnimated: (hidden: boolean) => void;
  }>
) {
  const swipedUp = g.dy < -24 || (g.dy < -8 && g.vy < -0.25);
  const swipedDown =
    g.dy > VALETER_DOCK_ROW_HEIGHT * 0.5 || (g.dy > 12 && g.vy > 0.3);
  Animated.spring(dismissDrag, {
    toValue: 0,
    useNativeDriver: true,
    damping: 26,
    stiffness: 320,
  }).start();
  if (swipedUp && trackingDockHidden) {
    void hapticFeedback('light');
    setDockHiddenAnimated(false);
  } else if (swipedDown && !trackingDockHidden && !hasTripStep) {
    void hapticFeedback('light');
    setDockHiddenAnimated(true);
  }
}

function useSheetPanResponder({
  panel,
  trackingDockHidden,
  hasTripStep,
  setDockHiddenAnimated,
  onTrackingDismiss,
  onTripMinimizedChange,
  resolvedSheetHeight,
  tripLocked,
  tripMinimized,
}: Readonly<{
  panel: DashboardSheetPanel;
  trackingDockHidden: boolean;
  hasTripStep: boolean;
  setDockHiddenAnimated: (hidden: boolean) => void;
  onTrackingDismiss?: () => void;
  onTripMinimizedChange?: (minimized: boolean) => void;
  resolvedSheetHeight: number;
  tripLocked: boolean;
  tripMinimized: boolean;
}>) {
  const dismissDrag = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    dismissDrag.setValue(0);
  }, [dismissDrag, panel]);

  const panResponder = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => true,
        onMoveShouldSetPanResponder: (_, g) => Math.abs(g.dy) > 4 && Math.abs(g.dy) > Math.abs(g.dx),
        onPanResponderMove: (_, g) => {
          if (panel !== 'tracking') return;
          // Locked: the sheet only travels the dock's height (menu shown ↔ menu hidden).
          dismissDrag.setValue(
            trackingDockHidden || hasTripStep ? 0 : Math.max(0, Math.min(VALETER_DOCK_ROW_HEIGHT, g.dy))
          );
        },
        onPanResponderRelease: (_, g) => {
          if (panel !== 'tracking') return;
          settleTrackingDrag(g, { dismissDrag, trackingDockHidden, hasTripStep, setDockHiddenAnimated });
        },
      }),
    [
      dismissDrag,
      hasTripStep,
      onTrackingDismiss,
      onTripMinimizedChange,
      panel,
      resolvedSheetHeight,
      setDockHiddenAnimated,
      trackingDockHidden,
      tripLocked,
      tripMinimized,
    ]
  );

  return { dismissDrag, panResponder };
}

type SheetLayout = Readonly<{
  /** Quick way back to the live job from Offers. */
  resumeOnOffers: boolean;
  compactEmptyOffers: boolean;
  compactOffersWithCards: boolean;
  compact: boolean;
}>;

function deriveSheetLayout({
  panel,
  hasActive,
  activeJobLoading,
  requestCount,
}: Readonly<{
  panel: DashboardSheetPanel;
  hasActive: boolean;
  activeJobLoading: boolean;
  requestCount: number;
}>): SheetLayout {
  const resumeOnOffers = panel === 'request' && hasActive && !activeJobLoading;
  const compactEmptyOffers = panel === 'request' && requestCount === 0;
  const compactOffersWithCards = panel === 'request' && requestCount > 0;
  return {
    resumeOnOffers,
    compactEmptyOffers,
    compactOffersWithCards,
    compact: compactEmptyOffers || compactOffersWithCards,
  };
}

/** Nav dock lives in the sheet footer — reserve space so content isn't covered. */
function sheetDockFooterHeight(safeBottom: number) {
  return VALETER_DOCK_ROW_HEIGHT + Math.max(safeBottom, 8);
}

function browseSheetHeightFor(safeBottom: number) {
  return VALETER_SHEET_FIXED_HEIGHT + sheetDockFooterHeight(safeBottom);
}

function fallbackTrackingSheetHeight(trackingContentHeight: number | null, safeBottom: number) {
  const trackingBottomPad = Math.max(safeBottom, 8);
  const content =
    trackingContentHeight != null && trackingContentHeight > 0
      ? trackingContentHeight
      : VALETER_TRACKING_SHEET_HEIGHT - VALETER_TRACKING_SHEET_CHROME - trackingBottomPad;
  const measured = Math.min(
    Math.round(SCREEN_HEIGHT * 0.52),
    Math.max(
      220,
      Math.round(content + VALETER_TRACKING_SHEET_CHROME + trackingBottomPad + sheetDockFooterHeight(safeBottom))
    )
  );
  // Never shrink below the browse sheet — accepting an offer was collapsing the sheet.
  return Math.max(measured, browseSheetHeightFor(safeBottom));
}

type TrackingHeightInput = Readonly<{
  safeBottom: number;
  trackingContentHeight: number | null;
  trackingHandleHeight: number;
  bare: boolean;
  hasTrip: boolean;
}>;

/** Once the trip card is measured, hug it exactly so no empty band sits under it. */
function trackingHugSheetHeight({
  safeBottom,
  trackingContentHeight,
  trackingHandleHeight,
  bare,
  hasTrip,
}: TrackingHeightInput) {
  if (trackingContentHeight == null || trackingContentHeight <= 0) return null;
  if (!bare && trackingHandleHeight <= 0) return null;
  const handleH = bare ? 0 : trackingHandleHeight;
  const trackingTopPad = bare ? 0 : TRACKING_PANEL_TOP_PAD;
  const trackingBottomGap = hasTrip ? -DOCK_CARD_OVERLAP : TRACKING_PANEL_BOTTOM_GAP;
  return Math.min(
    Math.round(SCREEN_HEIGHT * 0.72),
    Math.round(
      handleH + trackingTopPad + trackingContentHeight + trackingBottomGap + sheetDockFooterHeight(safeBottom)
    )
  );
}

function resolveBaseSheetHeight(
  input: TrackingHeightInput &
    Readonly<{ panel: DashboardSheetPanel; tripPeek: boolean; layout: SheetLayout }>
) {
  const { panel, safeBottom, layout } = input;
  if (panel === 'tracking' && input.tripPeek) return valeterTripPeekSheetHeight(safeBottom);
  const offersOpts = { hasResume: layout.resumeOnOffers };
  if (layout.compactEmptyOffers) return valeterCompactBrowseSheetHeight(safeBottom, offersOpts);
  if (layout.compactOffersWithCards) return valeterOffersSheetHeight(safeBottom, offersOpts);
  if (panel !== 'tracking') return browseSheetHeightFor(safeBottom);
  return trackingHugSheetHeight(input) ?? fallbackTrackingSheetHeight(input.trackingContentHeight, safeBottom);
}

function TrackingHint({
  accent,
  muted,
  tripPeek,
  trackingDockHidden,
  hasTripStep,
  onTripMinimizedChange,
  setDockHiddenAnimated,
}: Readonly<{
  accent: string;
  muted: string;
  tripPeek: boolean;
  trackingDockHidden: boolean;
  hasTripStep: boolean;
  onTripMinimizedChange?: (minimized: boolean) => void;
  setDockHiddenAnimated: (hidden: boolean) => void;
}>) {
  if (tripPeek) {
    return (
      <TouchableOpacity
        style={styles.tripPeekRow}
        onPress={() => {
          void hapticFeedback('light');
          onTripMinimizedChange?.(false);
        }}
        activeOpacity={0.8}
        accessibilityRole="button"
        accessibilityLabel="Expand trip sheet"
      >
        <Ionicons name="navigate" size={14} color={accent} />
        <Text style={[styles.tripPeekText, { color: accent }]} numberOfLines={1}>
          On trip · Tap to expand
        </Text>
      </TouchableOpacity>
    );
  }
  if (trackingDockHidden) {
    return (
      <TouchableOpacity
        style={styles.swipeHintRow}
        onPress={() => {
          void hapticFeedback('light');
          setDockHiddenAnimated(false);
        }}
        hitSlop={{ top: 6, bottom: 6, left: 16, right: 16 }}
        activeOpacity={0.7}
        accessibilityRole="button"
        accessibilityLabel="Show navigation menu"
      >
        <Ionicons name="chevron-up" size={11} color={muted} />
        <Text style={[styles.swipeHint, styles.swipeHintInline, { color: muted }]}>
          Swipe up for menu
        </Text>
      </TouchableOpacity>
    );
  }
  if (hasTripStep) return null;
  return (
    <View style={styles.swipeHintRow}>
      <Ionicons name="chevron-down" size={11} color={muted} />
      <Text style={[styles.swipeHint, styles.swipeHintInline, { color: muted }]}>
        Swipe down to hide menu
      </Text>
    </View>
  );
}

function TrackingHandle({
  tripPeek,
  trackingHandleHeight,
  setTrackingHandleHeight,
  panHandlers,
  hint,
}: Readonly<{
  tripPeek: boolean;
  trackingHandleHeight: number;
  setTrackingHandleHeight: (height: number) => void;
  panHandlers: GestureResponderHandlers;
  hint: React.ReactNode;
}>) {
  return (
    <View
      style={[styles.handleTouch, tripPeek && styles.handleTouchPeek]}
      onLayout={(e) => {
        const h = Math.round(e.nativeEvent.layout.height);
        if (h > 0 && Math.abs(h - trackingHandleHeight) > 1) setTrackingHandleHeight(h);
      }}
      {...panHandlers}
    >
      <View style={[styles.handle, styles.handleColor]} />
      {hint}
    </View>
  );
}

function BrowseHandle() {
  return (
    <View style={styles.handleTouch}>
      <View style={[styles.handle, styles.handleColor]} />
    </View>
  );
}

function SheetHandles({
  panel,
  bare,
  trackingHandle,
  browseHandle,
}: Readonly<{
  panel: DashboardSheetPanel;
  bare: boolean;
  trackingHandle: React.ReactNode;
  browseHandle: React.ReactNode;
}>) {
  return (
    <>
      {!bare && panel === 'tracking' ? trackingHandle : null}
      {panel === 'tracking' ? null : browseHandle}
    </>
  );
}

function RequestPanel({
  accent,
  muted,
  layout,
  activeJob,
  activeCustomerName,
  onActiveJobPress,
  jobRequests,
  requestScrollRef,
  onRequestScrollEnd,
  focusedJobId,
  focusJob,
  requestPage,
  isOnline,
  onlineBusy,
  onToggleOnline,
}: Readonly<{
  accent: string;
  muted: string;
  layout: SheetLayout;
  activeJob?: ActiveJobRow | null;
  activeCustomerName: string;
  onActiveJobPress: () => void;
  jobRequests: ValeterJobRequest[];
  requestScrollRef: React.RefObject<ScrollView | null>;
  onRequestScrollEnd: (event: NativeSyntheticEvent<NativeScrollEvent>) => void;
  focusedJobId?: string | null;
  focusJob: (job: FocusableJob) => void;
  requestPage: number;
  isOnline: boolean;
  onlineBusy: boolean;
  onToggleOnline?: () => void;
}>) {
  const { compactEmptyOffers, compactOffersWithCards } = layout;
  const hasRequests = jobRequests.length > 0;
  return (
    <Reanimated.View
      key="panel-request"
      entering={FadeInRight.duration(260).easing(Easing.out(Easing.cubic))}
      style={[
        styles.panelFill,
        (compactEmptyOffers || compactOffersWithCards) && styles.panelFillResumeOnly,
        compactOffersWithCards && styles.panelFillOffers,
      ]}
    >
      {layout.resumeOnOffers && activeJob ? (
        <ResumeTripCard
          accent={accent}
          job={activeJob}
          customerName={activeCustomerName}
          onPress={onActiveJobPress}
        />
      ) : null}
      {jobRequests.length > 1 ? (
        <PageDots count={jobRequests.length} index={requestPage} accent={accent} />
      ) : null}
      {hasRequests ? (
        <GestureScrollView
          ref={requestScrollRef}
          horizontal
          nestedScrollEnabled
          style={styles.requestCarousel}
          showsHorizontalScrollIndicator={false}
          decelerationRate="fast"
          snapToInterval={REQUEST_CARD_WIDTH + REQUEST_CARD_GAP}
          snapToAlignment="start"
          disableIntervalMomentum
          contentContainerStyle={[styles.requestCarouselContent, styles.requestCarouselCompact]}
          onMomentumScrollEnd={onRequestScrollEnd}
          onScrollEndDrag={onRequestScrollEnd}
        >
          {jobRequests.map((job, index) => {
            const selected = focusedJobId === job.id;
            return (
              <Reanimated.View
                key={job.id}
                exiting={ZoomOut.duration(220)}
                layout={LinearTransition.springify().damping(18)}
                style={[styles.requestCardWrap, { width: REQUEST_CARD_WIDTH }]}
              >
                <ValeterJobRequestCard
                  accent={accent}
                  job={job}
                  requestIndex={index}
                  selected={selected}
                  onFocusMap={() => focusJob(job)}
                />
              </Reanimated.View>
            );
          })}
        </GestureScrollView>
      ) : null}
      {!hasRequests && !isOnline ? (
        <OfflineOffersRow muted={muted} busy={onlineBusy} onGoOnline={onToggleOnline} />
      ) : null}
      {!hasRequests && isOnline ? (
        <SearchingRow
          accent={accent}
          muted={muted}
          sf="dot.radiowaves.left.and.right"
          ion="radio-outline"
          title="Looking for jobs nearby"
          subtitle="New offers will pop up here"
        />
      ) : null}
    </Reanimated.View>
  );
}

function TrackingPanelBody({
  bare,
  trackingContent,
  loading,
  muted,
}: Readonly<{ bare: boolean; trackingContent: React.ReactNode; loading: boolean; muted: string }>) {
  if (trackingContent) {
    return (
      <View style={styles.trackingSlot} pointerEvents={bare ? 'box-none' : 'auto'}>
        {trackingContent}
      </View>
    );
  }
  if (loading) {
    return (
      <View style={styles.paddedBlock}>
        <DefaultLoadingSkeleton message="Opening tracking…" />
      </View>
    );
  }
  return (
    <View style={styles.emptyState}>
      <Ionicons name="navigate-outline" size={28} color={muted} />
      <Text style={[styles.emptyText, { color: muted }]}>
        Opening trip…
      </Text>
    </View>
  );
}

function TrackingPanel({
  tripPeek,
  bare,
  panHandlers,
  children,
}: Readonly<{
  tripPeek: boolean;
  bare: boolean;
  panHandlers: GestureResponderHandlers;
  children: React.ReactNode;
}>) {
  if (tripPeek) return null;
  const trackingPanHandlers = bare ? {} : panHandlers;
  return (
    <Reanimated.View
      key="panel-tracking"
      // Road-only mounts while the sheet re-hugs it; an interrupted entering animation leaves it invisible.
      entering={bare ? undefined : FadeInDown.springify().damping(18).stiffness(180)}
      pointerEvents={bare ? 'box-none' : 'auto'}
      style={[styles.panelFill, styles.panelFillTracking, bare && styles.panelFillBare]}
      {...trackingPanHandlers}
    >
      {children}
    </Reanimated.View>
  );
}

function SheetBody({
  panel,
  bare,
  compact,
  overDock,
  requestPanel,
  trackingPanel,
}: Readonly<{
  panel: DashboardSheetPanel;
  bare: boolean;
  compact: boolean;
  overDock: boolean;
  requestPanel: React.ReactNode;
  trackingPanel: React.ReactNode;
}>) {
  return (
    <View
      pointerEvents={bare ? 'box-none' : 'auto'}
      style={[styles.body, compact && styles.bodyResumeOnly, overDock ? styles.panelOverDock : null]}
    >
      {panel === 'tracking' ? trackingPanel : requestPanel}
    </View>
  );
}

function DeclineUndoBar({
  pendingDecline,
  hidden,
  accent,
  onUndo,
}: Readonly<{ pendingDecline: PendingDecline; hidden: boolean; accent: string; onUndo: () => void }>) {
  if (!pendingDecline || hidden) return null;
  return (
    <Reanimated.View
      key={pendingDecline.id}
      entering={FadeInDown.springify().damping(18)}
      exiting={FadeOutDown.duration(160)}
      style={styles.undoBar}
    >
      <Ionicons name="close-circle" size={18} color="#F87171" />
      <Text style={styles.undoText} numberOfLines={1}>
        Declined · {pendingDecline.name}
      </Text>
      <TouchableOpacity
        onPress={onUndo}
        hitSlop={8}
        style={[styles.undoBtn, { borderColor: `${accent}66` }]}
        accessibilityRole="button"
        accessibilityLabel="Undo decline"
      >
        <Ionicons name="arrow-undo" size={13} color={accent} />
        <Text style={[styles.undoBtnText, { color: accent }]}>Undo</Text>
      </TouchableOpacity>
      <UndoCountdown key={`c-${pendingDecline.id}`} color={accent} />
    </Reanimated.View>
  );
}

export default function ValeterDashboardBottomSheet({
  accent,
  headerGradient = HEADER_STYLE_CARD_GRADIENT,
  panel = 'request',
  focusedJobId,
  activeJob,
  activeJobLoading = false,
  activeCustomerName = 'Customer',
  jobRequests: incomingJobRequests = [],
  jobRequestCount = 0,
  trackingContent = null,
  trackingContentHeight = null,
  onPanelChange,
  onFocusJobOnMap,
  onActiveJobPress,
  onAcceptJob,
  onDeclineJob,
  onTrackingDismiss,
  tripLocked = false,
  tripMinimized = false,
  onTripMinimizedChange,
  onTrackingDockHiddenChange,
  onSheetHeightChange,
  isOnline = false,
  onlineBusy = false,
  onToggleOnline,
  trip = null,
  roadOnly = false,
}: ValeterDashboardBottomSheetProps) {
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const sheetMuted = theme.textSecondary ?? 'rgba(241,245,249,0.65)';

  const { pendingDecline, jobRequests, requestDecline, undoDecline } = useDeclineUndo(
    incomingJobRequests,
    onDeclineJob
  );
  const { requestPage, setRequestPage, requestScrollRef, focusJob, handleRequestScrollEnd } = useRequestCarousel(
    jobRequests,
    onFocusJobOnMap
  );

  const dockBottomPad = Math.max(insets.bottom, 8);
  const [trackingHandleHeight, setTrackingHandleHeight] = useState(0);
  const tripPeek = tripLocked && tripMinimized;
  const bare = panel === 'tracking' && roadOnly && !!trackingContent && !tripPeek;
  const hasActive = !!activeJob;
  const layout = deriveSheetLayout({
    panel,
    hasActive,
    activeJobLoading,
    requestCount: jobRequests.length,
  });
  const hasTripStep = !!trip;
  const [trackingDockHidden, setDockHiddenAnimated] = useTrackingDock(panel, hasTripStep);
  const dockHidden = panel === 'tracking' && trackingDockHidden;
  const baseSheetHeight = resolveBaseSheetHeight({
    panel,
    safeBottom: insets.bottom,
    trackingContentHeight,
    trackingHandleHeight,
    bare,
    hasTrip: hasTripStep,
    tripPeek,
    layout,
  });
  const resolvedSheetHeight = baseSheetHeight - (dockHidden ? VALETER_DOCK_ROW_HEIGHT : 0);

  useSheetReporting({
    panel,
    dockHidden,
    resolvedSheetHeight,
    tripMinimized,
    onTrackingDockHiddenChange,
    onSheetHeightChange,
    onTripMinimizedChange,
  });
  const requestBadge = Math.max(jobRequestCount, jobRequests.length);
  const { dismissDrag, panResponder } = useSheetPanResponder({
    panel,
    trackingDockHidden,
    hasTripStep,
    setDockHiddenAnimated,
    onTrackingDismiss,
    onTripMinimizedChange,
    resolvedSheetHeight,
    tripLocked,
    tripMinimized,
  });
  useFocusedRequestScroll(panel, focusedJobId, jobRequests, setRequestPage, requestScrollRef);

  const isTracking = panel === 'tracking';
  const showOffers = useCallback(() => onPanelChange('request'), [onPanelChange]);
  const offerInView = panel === 'request' ? jobRequests[Math.min(requestPage, jobRequests.length - 1)] : undefined;
  const dockOffer: DockOffer | null = useMemo(
    () =>
      offerInView
        ? { onAccept: () => void onAcceptJob(offerInView.id), onDecline: () => void requestDecline(offerInView) }
        : null,
    [offerInView, onAcceptJob, requestDecline]
  );
  const overDock = isTracking && !!trip && !!trackingContent && !tripMinimized;

  return (
    <Animated.View
      pointerEvents={bare ? 'box-none' : 'auto'}
      style={[
        styles.sheet,
        bare && styles.sheetBare,
        {
          height: resolvedSheetHeight,
          paddingBottom: 0,
          borderColor: `${accent}35`,
          // Keep tracking / compact sheets flush to the screen footer (no collapse lift).
          justifyContent: isTracking || layout.compact ? 'flex-end' : undefined,
          transform: [{ translateY: dismissDrag }],
        },
      ]}
    >
      {bare ? null : (
        <View style={styles.chromeLayer} pointerEvents="none">
          <ValeterDashboardChrome
            accent={accent}
            headerGradient={isTracking ? softenedTint(headerGradient, TRACKING_TINT) : headerGradient}
            liquid
          />
        </View>
      )}

      <SheetHandles
        panel={panel}
        bare={bare}
        trackingHandle={
          <TrackingHandle
            tripPeek={tripPeek}
            trackingHandleHeight={trackingHandleHeight}
            setTrackingHandleHeight={setTrackingHandleHeight}
            panHandlers={panResponder.panHandlers}
            hint={
              <TrackingHint
                accent={accent}
                muted={sheetMuted}
                tripPeek={tripPeek}
                trackingDockHidden={trackingDockHidden}
                hasTripStep={hasTripStep}
                onTripMinimizedChange={onTripMinimizedChange}
                setDockHiddenAnimated={setDockHiddenAnimated}
              />
            }
          />
        }
        browseHandle={<BrowseHandle />}
      />

      <SheetBody
        panel={panel}
        bare={bare}
        compact={layout.compact}
        overDock={overDock || (panel === 'request' && jobRequests.length > 0)}
        requestPanel={
          <RequestPanel
            accent={accent}
            muted={sheetMuted}
            layout={layout}
            activeJob={activeJob}
            activeCustomerName={activeCustomerName}
            onActiveJobPress={onActiveJobPress}
            jobRequests={jobRequests}
            requestScrollRef={requestScrollRef}
            onRequestScrollEnd={handleRequestScrollEnd}
            focusedJobId={focusedJobId}
            focusJob={focusJob}
            requestPage={requestPage}
            isOnline={isOnline}
            onlineBusy={onlineBusy}
            onToggleOnline={onToggleOnline}
          />
        }
        trackingPanel={
          <TrackingPanel tripPeek={tripPeek} bare={bare} panHandlers={panResponder.panHandlers}>
            <TrackingPanelBody
              bare={bare}
              trackingContent={trackingContent}
              loading={hasActive || activeJobLoading}
              muted={sheetMuted}
            />
          </TrackingPanel>
        }
      />

      <DeclineUndoBar pendingDecline={pendingDecline} hidden={isTracking} accent={accent} onUndo={undoDecline} />

      {/* App nav dock — pinned under sheet content (logo home + tabs). */}
      <View style={[styles.dockFooter, { paddingBottom: dockBottomPad }]}>
        {dockHidden ? null : (
          <Reanimated.View
            entering={FadeInDown.springify().damping(16).stiffness(220)}
            exiting={FadeOutDown.duration(160)}
          >
            <ValeterDashboardFloatingDock
              variant="tabBar"
              accent={accent}
              jobRequestCount={requestBadge}
              activeTab="jobs"
              onJobsPress={showOffers}
              offer={dockOffer}
              isOnline={isOnline}
              onlineBusy={onlineBusy}
              onToggleOnline={onToggleOnline}
              trip={trip}
            />
          </Reanimated.View>
        )}
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  sheet: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    borderWidth: StyleSheet.hairlineWidth,
    borderBottomWidth: 0,
    overflow: 'hidden',
    zIndex: 40,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -6 },
    shadowOpacity: 0.32,
    shadowRadius: 18,
    elevation: 28,
  },
  /** Fades only the sheet backdrop so cards and text stay fully opaque. */
  chromeLayer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    opacity: 0.72,
  },
  handleTouch: {
    alignItems: 'center',
    paddingTop: 6,
    paddingBottom: 2,
  },
  handleTouchPeek: {
    paddingTop: 10,
    paddingBottom: 10,
    flexGrow: 1,
    justifyContent: 'center',
  },
  handle: {
    width: 38,
    height: 5,
    borderRadius: 3,
  },
  handleColor: {
    backgroundColor: 'rgba(255,255,255,0.32)',
  },
  swipeHint: {
    marginTop: 4,
    fontSize: 10,
    fontWeight: '600',
    letterSpacing: 0.2,
  },
  swipeHintRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 4,
  },
  swipeHintInline: {
    marginTop: 0,
  },
  tripPeekRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    marginTop: 10,
    paddingHorizontal: 12,
    paddingVertical: 4,
  },
  tripPeekText: {
    fontSize: 13,
    fontWeight: '700',
  },
  resumeWrap: {
    marginHorizontal: SHEET_PAD_H,
    marginBottom: 10,
  },
  offlineIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(239,68,68,0.14)',
    borderWidth: 1,
    borderColor: 'rgba(248,113,113,0.4)',
  },
  goOnlineBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 13,
    paddingVertical: 9,
    borderRadius: 999,
    backgroundColor: '#22C55E',
  },
  goOnlineText: {
    color: '#052e16',
    fontSize: 13,
    fontWeight: '800',
  },
  pageDots: {
    flexDirection: 'row',
    alignSelf: 'center',
    alignItems: 'center',
    gap: 5,
    marginBottom: 8,
  },
  pageDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  undoBar: {
    position: 'absolute',
    top: 8,
    left: SHEET_PAD_H,
    right: SHEET_PAD_H,
    zIndex: 60,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingLeft: 12,
    paddingRight: 6,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(6,14,26,0.96)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.35,
    shadowRadius: 12,
    elevation: 12,
  },
  undoText: {
    flex: 1,
    color: '#F8FAFC',
    fontSize: 13,
    fontWeight: '700',
  },
  undoBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 999,
    borderWidth: 1,
  },
  undoBtnText: {
    fontSize: 13,
    fontWeight: '800',
  },
  undoTrack: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    height: 2,
  },
  undoFill: {
    height: '100%',
  },
  searchingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    paddingHorizontal: SHEET_PAD_H + 4,
    paddingVertical: 10,
  },
  radar: {
    width: 44,
    height: 44,
    alignItems: 'center',
    justifyContent: 'center',
  },
  radarRing: {
    position: 'absolute',
    width: 44,
    height: 44,
    borderRadius: 22,
    borderWidth: 1.5,
  },
  radarCore: {
    width: 32,
    height: 32,
    borderRadius: 16,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  searchingCopy: {
    flex: 1,
    minWidth: 0,
  },
  searchingTitle: {
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '800',
  },
  searchingSub: {
    fontSize: 12,
    fontWeight: '600',
    marginTop: 2,
  },
  body: {
    flex: 1,
    minHeight: 0,
    paddingBottom: 0,
  },
  bodyResumeOnly: {
    flexGrow: 0,
    flexShrink: 0,
    flex: 0,
  },
  dockFooter: {
    flexShrink: 0,
    backgroundColor: 'transparent',
  },
  panelFill: {
    flex: 1,
    minHeight: 0,
    justifyContent: 'flex-start',
  },
  panelFillResumeOnly: {
    flexGrow: 0,
    flexShrink: 0,
    flex: 0,
    justifyContent: 'flex-end',
    paddingBottom: 2,
  },
  /** Vertically center offer cards between browse tabs and nav dock. */
  panelFillOffers: {
    justifyContent: 'flex-end',
    paddingTop: 4,
    paddingBottom: 0,
  },
  /** Sit tracking cards under the swipe-exit hint with a small offset. */
  panelFillTracking: {
    justifyContent: 'flex-start',
    paddingTop: TRACKING_PANEL_TOP_PAD,
    paddingBottom: 0,
  },
  panelFillBare: { paddingTop: 0 },
  sheetBare: { borderWidth: 0, shadowOpacity: 0, elevation: 0, backgroundColor: 'transparent' },
  /** Trip card hangs into the dock row so its notched edge wraps the hump. */
  panelOverDock: {
    marginBottom: -DOCK_CARD_OVERLAP,
  },
  trackingSlot: {
    flexGrow: 0,
    flexShrink: 0,
    width: '100%',
    paddingTop: 0,
    paddingBottom: 0,
  },
  requestCarousel: {
    flexGrow: 0,
    flexShrink: 1,
  },
  requestCarouselContent: {
    paddingHorizontal: REQUEST_CARD_INSET,
    gap: REQUEST_CARD_GAP,
    alignItems: 'flex-start',
    paddingBottom: 0,
  },
  requestCarouselCompact: {
    alignItems: 'flex-end',
    paddingTop: 2,
    paddingBottom: 0,
  },
  requestCardWrap: {
    flexGrow: 0,
    flexShrink: 0,
    gap: 10,
  },
  paddedBlock: {
    paddingHorizontal: SHEET_PAD_H,
    gap: 10,
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingVertical: 28,
    paddingHorizontal: SHEET_PAD_H + 8,
    minHeight: 140,
  },
  emptyText: {
    color: 'rgba(249,250,251,0.4)',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
    lineHeight: 20,
  },
});
