import React, { useMemo, useState } from 'react';
import {
  Dimensions,
  ScrollView,
  StyleSheet,
  Text,
  View,
  type NativeScrollEvent,
  type NativeSyntheticEvent,
} from 'react-native';
import Reanimated, { FadeIn, FadeInDown, LinearTransition } from 'react-native-reanimated';
import { ChromeGlyph as Ionicons } from '../../shared/ChromeGlyph';
import { PressableScale, PulseDot } from '../../shared/fit/FitKit';
import { ValeterResumeJobCard, ValeterUpcomingJobCard } from '../ValeterSheetJobCards';
import type { ActiveJob } from '../../dashboard/powerfulDriver/types';
import type { ActivityJob } from './useValeterActivity';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const PAD_H = 16;
const CARD_GAP = 10;
const PEEK_CARD_WIDTH = Math.min(SCREEN_WIDTH - PAD_H * 2 - 28, 340);
const FULL_CARD_WIDTH = SCREEN_WIDTH - PAD_H * 2;
const UP_NEXT_MAX = 6;
const WEEK_DAYS = 7;
const MAX_DOTS = 3;
const TEXT_MAIN = '#F8FAFC';

function dayKey(d: Date) {
  return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
}

function startOfDay(d: Date) {
  const s = new Date(d);
  s.setHours(0, 0, 0, 0);
  return s;
}

function dayLabel(iso: string, today: Date) {
  const d = new Date(iso);
  const tomorrow = new Date(today);
  tomorrow.setDate(today.getDate() + 1);
  if (dayKey(d) === dayKey(today)) return 'Today';
  if (dayKey(d) === dayKey(tomorrow)) return 'Tomorrow';
  return d.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'short' });
}

function jobsLabel(n: number) {
  return `${n} job${n === 1 ? '' : 's'}`;
}

export function SectionHeader({
  title,
  meta,
  muted,
  live = false,
}: Readonly<{ title: string; meta?: string; muted: string; live?: boolean }>) {
  return (
    <View style={styles.sectionHeader}>
      <View style={styles.sectionTitleRow}>
        {live ? <PulseDot color="#34D399" size={7} /> : null}
        <Text style={[styles.sectionTitle, { color: muted }]}>{title.toUpperCase()}</Text>
      </View>
      {meta ? <Text style={[styles.sectionMeta, { color: muted }]}>{meta}</Text> : null}
    </View>
  );
}

/** The live job, or a quiet nudge back to the map when there isn't one. */
export function NowSection({
  accent,
  muted,
  job,
  customerName,
  onResume,
  onFindWork,
}: Readonly<{
  accent: string;
  muted: string;
  job: ActiveJob | null;
  customerName: string;
  onResume: (jobId: string) => void;
  onFindWork: () => void;
}>) {
  return (
    <Reanimated.View entering={FadeInDown.duration(260)} style={styles.section}>
      <SectionHeader title="Now" muted={muted} live={!!job} />
      <View style={styles.padded}>
        {job ? (
          <ValeterResumeJobCard
            accent={accent}
            status={job.status}
            serviceType={job.service_type}
            serviceName={job.service_name}
            customerName={customerName}
            onPress={() => onResume(job.id)}
          />
        ) : (
          <View style={[styles.idleRow, { borderColor: `${accent}30` }]}>
            <Ionicons name="moon-outline" size={18} color={muted} />
            <Text style={[styles.idleText, { color: muted }]} numberOfLines={1}>
              No live job right now
            </Text>
            <PressableScale
              onPress={onFindWork}
              style={[styles.idleBtn, { backgroundColor: `${accent}22`, borderColor: `${accent}66` }]}
              accessibilityLabel="Find work on the map"
            >
              <Text style={[styles.idleBtnText, { color: accent }]}>Find work</Text>
            </PressableScale>
          </View>
        )}
      </View>
    </Reanimated.View>
  );
}

/** Next few bookings as a snapping swipe row, each tagged with its day. */
export function UpNextRow({
  accent,
  muted,
  jobs,
  onOpenJob,
}: Readonly<{
  accent: string;
  muted: string;
  jobs: ActivityJob[];
  onOpenJob: (job: ActivityJob) => void;
}>) {
  const [page, setPage] = useState(0);
  const items = jobs.slice(0, UP_NEXT_MAX);
  const today = useMemo(() => startOfDay(new Date()), []);
  if (items.length === 0) return null;
  const cardWidth = items.length > 1 ? PEEK_CARD_WIDTH : FULL_CARD_WIDTH;
  const stride = cardWidth + CARD_GAP;

  const onScrollEnd = (e: NativeSyntheticEvent<NativeScrollEvent>) => {
    const next = Math.round(e.nativeEvent.contentOffset.x / stride);
    setPage(Math.min(items.length - 1, Math.max(0, next)));
  };

  return (
    <Reanimated.View entering={FadeInDown.delay(60).duration(260)} style={styles.section}>
      <SectionHeader title="Up next" meta={jobsLabel(jobs.length)} muted={muted} />
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        decelerationRate="fast"
        snapToInterval={stride}
        snapToAlignment="start"
        disableIntervalMomentum
        contentContainerStyle={styles.rowContent}
        onMomentumScrollEnd={onScrollEnd}
      >
        {items.map((job) => (
          <View key={job.id} style={[styles.rowCard, { width: cardWidth }]}>
            <Text style={[styles.rowDay, { color: muted }]} numberOfLines={1}>
              {dayLabel(job.scheduled_at, today)}
            </Text>
            <ValeterUpcomingJobCard
              accent={accent}
              serviceType={job.service_type ?? undefined}
              serviceName={job.service_name}
              scheduledAt={job.scheduled_at}
              status={job.status}
              price={job.price}
              address={job.location_address}
              onPress={() => onOpenJob(job)}
            />
          </View>
        ))}
      </ScrollView>
      {items.length > 1 ? (
        <View style={styles.dots} pointerEvents="none">
          {items.map((job, i) => (
            <View
              key={job.id}
              style={[styles.dot, i === page ? { width: 16, backgroundColor: accent } : styles.dotIdle]}
            />
          ))}
        </View>
      ) : null}
    </Reanimated.View>
  );
}

type DayPill = Readonly<{ key: string; top: string; bottom: string; jobs: ActivityJob[] }>;

function buildWeek(jobs: ActivityJob[]): DayPill[] {
  const today = startOfDay(new Date());
  const days: DayPill[] = [];
  const byDay = new Map<string, ActivityJob[]>();
  for (const job of jobs) {
    const k = dayKey(new Date(job.scheduled_at));
    byDay.set(k, [...(byDay.get(k) ?? []), job]);
  }
  for (let i = 0; i < WEEK_DAYS; i++) {
    const d = new Date(today);
    d.setDate(today.getDate() + i);
    const k = dayKey(d);
    days.push({
      key: k,
      top: i === 0 ? 'Today' : d.toLocaleDateString('en-GB', { weekday: 'short' }),
      bottom: String(d.getDate()),
      jobs: byDay.get(k) ?? [],
    });
  }
  const weekEnd = new Date(today);
  weekEnd.setDate(today.getDate() + WEEK_DAYS);
  const later = jobs.filter((j) => new Date(j.scheduled_at) >= weekEnd);
  if (later.length > 0) days.push({ key: 'later', top: 'Later', bottom: '+', jobs: later });
  return days;
}

function WeekPill({
  day,
  selected,
  accent,
  muted,
  onPress,
}: Readonly<{ day: DayPill; selected: boolean; accent: string; muted: string; onPress: () => void }>) {
  const count = day.jobs.length;
  return (
    <PressableScale
      onPress={onPress}
      style={[
        styles.pill,
        selected
          ? { backgroundColor: `${accent}26`, borderColor: `${accent}AA` }
          : { backgroundColor: 'rgba(255,255,255,0.05)', borderColor: 'rgba(255,255,255,0.1)' },
      ]}
      accessibilityLabel={`${day.top} ${day.bottom}, ${jobsLabel(count)}`}
    >
      <Text style={[styles.pillTop, { color: selected ? accent : muted }]}>{day.top}</Text>
      <Text style={[styles.pillBottom, { color: selected ? TEXT_MAIN : muted }]}>{day.bottom}</Text>
      <View style={styles.pillDots}>
        {day.jobs.slice(0, MAX_DOTS).map((job) => (
          <View key={job.id} style={[styles.pillDot, { backgroundColor: selected ? accent : muted }]} />
        ))}
      </View>
    </PressableScale>
  );
}

/** Week at a glance: day pills with job dots, and the chosen day's bookings underneath. */
export function WeekAgenda({
  accent,
  muted,
  jobs,
  onOpenJob,
}: Readonly<{
  accent: string;
  muted: string;
  jobs: ActivityJob[];
  onOpenJob: (job: ActivityJob) => void;
}>) {
  const week = useMemo(() => buildWeek(jobs), [jobs]);
  const firstBusy = week.find((d) => d.jobs.length > 0)?.key ?? week[0]?.key;
  const [picked, setPicked] = useState<string | null>(null);
  const selectedKey = picked && week.some((d) => d.key === picked) ? picked : firstBusy;
  const selected = week.find((d) => d.key === selectedKey) ?? week[0];

  return (
    <Reanimated.View entering={FadeInDown.delay(120).duration(260)} style={styles.section}>
      <SectionHeader title="This week" muted={muted} />
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.pillRow}>
        {week.map((day) => (
          <WeekPill
            key={day.key}
            day={day}
            selected={day.key === selected?.key}
            accent={accent}
            muted={muted}
            onPress={() => setPicked(day.key)}
          />
        ))}
      </ScrollView>
      <Reanimated.View key={selected?.key} entering={FadeIn.duration(200)} style={styles.agenda}>
        {selected && selected.jobs.length > 0 ? (
          selected.jobs.map((job) => (
            <Reanimated.View key={job.id} layout={LinearTransition.springify().damping(18)}>
              <ValeterUpcomingJobCard
                accent={accent}
                serviceType={job.service_type ?? undefined}
                serviceName={job.service_name}
                scheduledAt={job.scheduled_at}
                status={job.status}
                price={job.price}
                address={job.location_address}
                onPress={() => onOpenJob(job)}
              />
            </Reanimated.View>
          ))
        ) : (
          <View style={styles.agendaEmpty}>
            <Ionicons name="calendar-clear-outline" size={18} color={muted} />
            <Text style={[styles.agendaEmptyText, { color: muted }]}>Nothing booked this day</Text>
          </View>
        )}
      </Reanimated.View>
    </Reanimated.View>
  );
}

const styles = StyleSheet.create({
  section: {
    marginBottom: 22,
  },
  padded: {
    paddingHorizontal: PAD_H,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: PAD_H + 4,
    marginBottom: 8,
  },
  sectionTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
  },
  sectionTitle: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.9,
  },
  sectionMeta: {
    fontSize: 11,
    fontWeight: '600',
  },
  idleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderRadius: 18,
    borderWidth: 1,
    backgroundColor: 'rgba(255,255,255,0.04)',
  },
  idleText: {
    flex: 1,
    fontSize: 14,
    fontWeight: '600',
  },
  idleBtn: {
    paddingHorizontal: 13,
    paddingVertical: 8,
    borderRadius: 999,
    borderWidth: 1,
  },
  idleBtnText: {
    fontSize: 13,
    fontWeight: '800',
  },
  rowContent: {
    paddingHorizontal: PAD_H,
    gap: CARD_GAP,
    alignItems: 'flex-start',
  },
  rowCard: {
    gap: 6,
  },
  rowDay: {
    fontSize: 12,
    fontWeight: '700',
    paddingHorizontal: 4,
  },
  dots: {
    flexDirection: 'row',
    alignSelf: 'center',
    alignItems: 'center',
    gap: 5,
    marginTop: 10,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  dotIdle: {
    backgroundColor: 'rgba(255,255,255,0.25)',
  },
  pillRow: {
    paddingHorizontal: PAD_H,
    gap: 8,
  },
  pill: {
    width: 54,
    paddingVertical: 9,
    borderRadius: 16,
    borderWidth: 1,
    alignItems: 'center',
    gap: 2,
  },
  pillTop: {
    fontSize: 11,
    fontWeight: '700',
  },
  pillBottom: {
    fontSize: 17,
    fontWeight: '800',
    fontVariant: ['tabular-nums'],
  },
  pillDots: {
    flexDirection: 'row',
    gap: 3,
    height: 5,
    marginTop: 2,
  },
  pillDot: {
    width: 5,
    height: 5,
    borderRadius: 2.5,
  },
  agenda: {
    paddingHorizontal: PAD_H,
    paddingTop: 12,
    gap: 10,
  },
  agendaEmpty: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 14,
    paddingHorizontal: 4,
  },
  agendaEmptyText: {
    fontSize: 13,
    fontWeight: '600',
  },
});
