import { useCallback, useMemo, useState } from 'react';
import { useFocusEffect } from 'expo-router';
import { useAuth } from '../../../providers/enhanced-auth-context';
import { useActiveJob, useRecentBookings } from '../../dashboard/powerfulDriver/useDashboardData';
import type { ActiveJob, YourJobSheetItem } from '../../dashboard/powerfulDriver/types';

export type ActivityJob = YourJobSheetItem & Readonly<{ scheduled_at: string; price: number }>;

const CLOSED_STATUSES = new Set(['completed', 'cancelled', 'valeter_timeout']);

/** A booking that is only on the calendar belongs in "Up next", not "Now". */
function currentJobFrom(activeJob: ActiveJob | null): ActiveJob | null {
  if (!activeJob || activeJob.status === 'scheduled') return null;
  return activeJob;
}

function toUpcoming(bookings: any[], currentId: string | null, now: number): ActivityJob[] {
  return bookings
    .filter((b) => {
      if (!b?.scheduled_at || b.id === currentId) return false;
      if (CLOSED_STATUSES.has(String(b.status))) return false;
      return new Date(b.scheduled_at).getTime() > now;
    })
    .map((b) => ({ ...b, price: Number(b.price ?? 0), _type: 'upcoming' }) as ActivityJob)
    .sort((a, b) => new Date(a.scheduled_at).getTime() - new Date(b.scheduled_at).getTime());
}

/** Current + upcoming jobs for the Activity screen, refreshed whenever the screen gains focus. */
export function useValeterActivity() {
  const { user } = useAuth();
  const userId = user?.id;
  const { recentBookings, loadRecentBookings } = useRecentBookings(userId);
  const { activeJob, displayCustomerName, loadActiveJob } = useActiveJob(userId);
  const [loaded, setLoaded] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    await Promise.all([loadRecentBookings(), loadActiveJob()]);
    setLoaded(true);
  }, [loadActiveJob, loadRecentBookings]);

  useFocusEffect(
    useCallback(() => {
      void load();
    }, [load])
  );

  const refresh = useCallback(async () => {
    setRefreshing(true);
    try {
      await load();
    } finally {
      setRefreshing(false);
    }
  }, [load]);

  const currentJob = currentJobFrom(activeJob);
  const upcoming = useMemo(
    () => toUpcoming(recentBookings, currentJob?.id ?? null, Date.now()),
    [recentBookings, currentJob?.id]
  );

  return {
    currentJob,
    customerName: displayCustomerName,
    upcoming,
    loading: !loaded && !!userId,
    refreshing,
    refresh,
  };
}
