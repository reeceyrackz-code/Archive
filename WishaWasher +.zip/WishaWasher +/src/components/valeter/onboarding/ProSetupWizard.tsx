/**
 * Post-signup Pro setup, one small question per screen so nothing needs scrolling.
 * Visual language mirrors the customer app's profile setup (van road hero, unboxed panel, pill CTA).
 * Persists through the same services the profile / documents / terms screens already use.
 */
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  BackHandler,
  Image,
  Pressable,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  View,
  useWindowDimensions,
  type TextInputProps,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import Animated, {
  Easing,
  FadeIn,
  FadeInDown,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { ChromeGlyph } from '../../shared/ChromeGlyph';
import type { IconGlyphName } from '../../shared/iconGlyphTypes';
import BubbleBackground from '../../shared/BubbleBackground';
import KeyboardSafeView from '../../shared/KeyboardSafeView';
import { toast } from '../../shared/ToastHost';
import OnboardingCarRoad, { type RoadLandmark } from '../../onboarding/OnboardingCarRoad';
import { useAuth } from '../../../providers/enhanced-auth-context';
import { supabase } from '../../../lib/supabase';
import { hapticFeedback } from '../../../services/HapticFeedbackService';
import { termsAgreementService, type TermsMode } from '../../../services/termsAgreementService';
import {
  valeterDocumentsSupabaseService,
  type UploadedDocument,
} from '../../../services/ValeterDocumentsSupabaseService';
import {
  VALETER_INSURANCE_ALERT_MESSAGE,
  showValeterInsuranceRequiredAlert,
  valeterInsuranceDetailsComplete,
} from '../../../utils/valeterInsuranceQuestionnaire';
import { uploadValeterProfilePhoto } from '../../../utils/valeterProfilePhoto';
import { PasswordStrength } from '../../auth/AuthKit';

const SKY = '#38BDF8';
const BLUE = '#60A5FA';
const GOLD = '#F59E0B';
const VIOLET = '#A78BFA';
const PINK = '#F472B6';
const GREEN = '#34D399';
const ERROR = '#F87171';

const IMAGE_MEDIA_TYPES: any =
  (ImagePicker as any)?.MediaType?.Images ? [(ImagePicker as any).MediaType.Images] : undefined;

type YesNo = 'yes' | 'no';
type AgreeKey = 'keepCustomers' | 'keepCalendarAvailability' | 'shareContactDetails';
type SectionId = 'welcome' | 'account' | 'about' | 'photo' | 'work' | 'docs' | 'agree';

const SECTIONS: Record<SectionId, { label: string; accent: string }> = {
  welcome: { label: "You're in", accent: SKY },
  account: { label: 'Your account', accent: BLUE },
  about: { label: 'About you', accent: SKY },
  photo: { label: 'Photo', accent: VIOLET },
  work: { label: 'How you work', accent: GOLD },
  docs: { label: 'Verification', accent: PINK },
  agree: { label: 'Ground rules', accent: GREEN },
};
const SETUP_SECTION_ORDER: SectionId[] = ['welcome', 'about', 'photo', 'work', 'docs', 'agree'];
const SIGNUP_SECTION_ORDER: SectionId[] = ['welcome', 'account', 'about', 'photo', 'work', 'docs', 'agree'];

type DocDef = { id: string; name: string; description: string; icon: IconGlyphName; optional?: boolean };
type AgreeDef = { key: AgreeKey; text: string; icon: IconGlyphName };

const VERIFY_DOCS: readonly DocDef[] = [
  { id: 'driving_license', name: 'Driving Licence', description: 'Valid UK driving licence', icon: 'car' },
  {
    id: 'id_proof',
    name: 'Passport/Birth certificate',
    description: 'Valid passport photo page or birth certificate',
    icon: 'id-card',
  },
  { id: 'public_liability', name: 'Public Liability Insurance', description: 'Minimum £2M coverage', icon: 'document-text' },
  { id: 'dbs_check', name: 'DBS Check', description: 'Enhanced DBS certificate', icon: 'shield-checkmark', optional: true },
];

const AGREEMENTS: readonly AgreeDef[] = [
  {
    key: 'keepCustomers',
    text: 'Do you agree to keep all customers you gain from Wish a Washer on the Wish a Washer app?',
    icon: 'people',
  },
  {
    key: 'keepCalendarAvailability',
    text: 'It is your responsibility to keep your calendar availability up to date. Do you accept this responsibility?',
    icon: 'calendar',
  },
  {
    key: 'shareContactDetails',
    text: 'Do you agree to not share or promote your personal contact details to customers on the Wish a Washer app?',
    icon: 'chatbubbles',
  },
];

type Step = Readonly<{
  id: string;
  kind:
    | 'welcome'
    | 'name'
    | 'email'
    | 'password'
    | 'contact'
    | 'business'
    | 'photo'
    | 'mode'
    | 'insurance'
    | 'insuranceDetails'
    | 'doc'
    | 'agree';
  section: SectionId;
  title: string;
  hint: string;
  icon: IconGlyphName;
  doc?: DocDef;
  agree?: AgreeDef;
}>;

const NAME_STEP: Step = {
  id: 'name',
  kind: 'name',
  section: 'about',
  title: 'What should customers call you?',
  hint: 'Shown on your profile, bookings and messages.',
  icon: 'person',
};

const PROFILE_STEPS: readonly Step[] = [
  { id: 'contact', kind: 'contact', section: 'about', title: 'How can we reach you?', hint: 'We only use this for job updates. Customers never see it.', icon: 'call' },
  { id: 'business', kind: 'business', section: 'about', title: 'Trading under a business name?', hint: 'Optional. Shown on your Pro profile if you add one.', icon: 'briefcase' },
  { id: 'photo', kind: 'photo', section: 'photo', title: 'Put a face to the name', hint: 'Customers see this when you accept their booking. A clear, friendly photo builds trust.', icon: 'camera' },
  { id: 'mode', kind: 'mode', section: 'work', title: 'How do you operate?', hint: 'You can change this later in your settings.', icon: 'car-sport' },
  { id: 'insurance', kind: 'insurance', section: 'work', title: 'Do you have business insurance?', hint: 'Business insurance is required to join the platform.', icon: 'umbrella' },
  { id: 'insuranceDetails', kind: 'insuranceDetails', section: 'work', title: 'Your insurance details', hint: 'Exactly as they appear on your policy.', icon: 'document-text' },
  ...VERIFY_DOCS.map<Step>((doc) => ({
    id: `doc-${doc.id}`,
    kind: 'doc',
    section: 'docs',
    title: doc.name,
    hint: `${doc.description}. Snap a clear photo, our team reviews it within 24 hours.`,
    icon: doc.icon,
    doc,
  })),
  ...AGREEMENTS.map<Step>((agree, i) => ({
    id: `agree-${agree.key}`,
    kind: 'agree',
    section: 'agree',
    title: `Agreement ${i + 1} of ${AGREEMENTS.length}`,
    hint: agree.text,
    icon: agree.icon,
    agree,
  })),
];

const SETUP_STEPS: readonly Step[] = [
  {
    id: 'welcome',
    kind: 'welcome',
    section: 'welcome',
    title: "Let's get your Pro account ready",
    hint: 'A few quick questions so customers know who you are and we can start sending you jobs.',
    icon: 'sparkles',
  },
  NAME_STEP,
  ...PROFILE_STEPS,
];

const SIGNUP_STEPS: readonly Step[] = [
  {
    id: 'welcome',
    kind: 'welcome',
    section: 'welcome',
    title: 'Become a Car Care Pro',
    hint: 'Create your account and set up your Pro profile in one go. One quick question per screen.',
    icon: 'sparkles',
  },
  { ...NAME_STEP, section: 'account' },
  { id: 'email', kind: 'email', section: 'account', title: "What's your email?", hint: "You'll use this to sign in. We'll send booking updates here too.", icon: 'mail' },
  { id: 'password', kind: 'password', section: 'account', title: 'Create a password', hint: 'At least 6 characters. Mix in numbers and symbols to make it stronger.', icon: 'lock-closed' },
  ...PROFILE_STEPS,
];

type Bullet = { icon: IconGlyphName; title: string; text: string };
const SETUP_BULLETS: ReadonlyArray<Bullet> = [
  { icon: 'person', title: 'About you', text: 'Name and contact details' },
  { icon: 'camera', title: 'Profile photo', text: 'So customers know who is coming' },
  { icon: 'car-sport', title: 'How you work', text: 'Mobile or fixed site, plus insurance' },
  { icon: 'shield-checkmark', title: 'Verification', text: 'Licence, ID and liability cover' },
];
const SIGNUP_BULLETS: ReadonlyArray<Bullet> = [
  { icon: 'lock-closed', title: 'Your account', text: 'Name, email and a password' },
  ...SETUP_BULLETS.slice(1),
];

const MODE_OPTIONS: ReadonlyArray<{ value: TermsMode; label: string; body: string; icon: IconGlyphName }> = [
  { value: 'mobile_based', label: 'Mobile', body: 'I travel to customers', icon: 'car-sport' },
  { value: 'physical', label: 'Fixed site', body: 'Customers come to me', icon: 'business' },
];

type DocStatus = 'missing' | 'pending' | 'approved' | 'rejected';

const DOC_STATUS: Record<DocStatus, { label: string; color: string }> = {
  missing: { label: 'Not uploaded yet', color: 'rgba(226,232,240,0.55)' },
  pending: { label: 'Uploaded · in review', color: '#FBBF24' },
  approved: { label: 'Approved', color: GREEN },
  rejected: { label: 'Rejected · please re-upload', color: ERROR },
};

function docStatusOf(doc?: UploadedDocument): DocStatus {
  if (!doc) return 'missing';
  if (doc.verificationStatus === 'approved') return 'approved';
  if (doc.verificationStatus === 'rejected') return 'rejected';
  return 'pending';
}

async function pickImage(source: 'camera' | 'library', square: boolean): Promise<string | null> {
  const perm =
    source === 'camera'
      ? await ImagePicker.requestCameraPermissionsAsync()
      : await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (perm.status !== 'granted') {
    toast.error(
      source === 'camera' ? 'Allow camera access to take a photo.' : 'Allow photo library access to choose a photo.',
      'Permission needed'
    );
    return null;
  }
  const opts = {
    mediaTypes: IMAGE_MEDIA_TYPES,
    quality: 0.8,
    allowsEditing: square,
    ...(square ? { aspect: [1, 1] as [number, number] } : {}),
  };
  const result =
    source === 'camera' ? await ImagePicker.launchCameraAsync(opts) : await ImagePicker.launchImageLibraryAsync(opts);
  if (result.canceled || !result.assets?.[0]?.uri) return null;
  return result.assets[0].uri;
}

/** Underline input, matching the customer profile setup name field. */
function LineField({
  icon,
  accent,
  valid,
  optional,
  label,
  editable = true,
  ...rest
}: TextInputProps &
  Readonly<{ icon: IconGlyphName; accent: string; valid?: boolean; optional?: boolean; label: string }>) {
  const [focused, setFocused] = useState(false);
  return (
    <View style={styles.lineBlock}>
      <Text style={styles.lineLabel}>
        {label}
        {optional ? <Text style={styles.optional}>  Optional</Text> : null}
      </Text>
      <View style={[styles.lineField, focused && { borderBottomColor: accent }]}>
        <ChromeGlyph name={icon} size={20} color={focused ? accent : 'rgba(148,163,184,0.8)'} />
        <TextInput
          {...rest}
          editable={editable}
          style={[styles.lineInput, !editable && styles.lineInputLocked]}
          placeholderTextColor="rgba(148,163,184,0.6)"
          selectionColor={accent}
          onFocus={(e) => {
            setFocused(true);
            rest.onFocus?.(e);
          }}
          onBlur={(e) => {
            setFocused(false);
            rest.onBlur?.(e);
          }}
        />
        {!editable ? <ChromeGlyph name="lock-closed" size={16} color="rgba(148,163,184,0.7)" /> : null}
        {editable && valid ? <ChromeGlyph name="checkmark-circle" size={22} color={GREEN} /> : null}
      </View>
    </View>
  );
}

/** Unboxed selectable row: icon, title, subtitle and a radio on the right. */
function OptionRow({
  icon,
  title,
  body,
  selected,
  accent,
  onPress,
}: Readonly<{
  icon: IconGlyphName;
  title: string;
  body?: string;
  selected: boolean;
  accent: string;
  onPress: () => void;
}>) {
  return (
    <Pressable
      onPress={() => {
        void hapticFeedback('light');
        onPress();
      }}
      style={styles.optionRow}
      accessibilityRole="radio"
      accessibilityState={{ selected }}
      accessibilityLabel={title}
    >
      <ChromeGlyph name={icon} size={22} color={selected ? accent : 'rgba(148,163,184,0.8)'} style={styles.bulletIcon} />
      <View style={styles.flex}>
        <Text style={[styles.optionTitle, !selected && styles.optionTitleOff]}>{title}</Text>
        {body ? <Text style={styles.bulletText}>{body}</Text> : null}
      </View>
      <View style={[styles.radioRing, selected && { borderColor: accent }]}>
        {selected ? <View style={[styles.radioDot, { backgroundColor: accent }]} /> : null}
      </View>
    </Pressable>
  );
}

function SourceButtons({
  accent,
  disabled,
  onPick,
}: Readonly<{ accent: string; disabled?: boolean; onPick: (s: 'camera' | 'library') => void }>) {
  return (
    <View style={styles.sourceRow}>
      <Pressable style={styles.sourcePill} onPress={() => onPick('camera')} disabled={disabled}>
        <ChromeGlyph name="camera-outline" size={18} color={accent} />
        <Text style={styles.sourceText}>Camera</Text>
      </Pressable>
      <Pressable style={styles.sourcePill} onPress={() => onPick('library')} disabled={disabled}>
        <ChromeGlyph name="images-outline" size={18} color={accent} />
        <Text style={styles.sourceText}>Library</Text>
      </Pressable>
    </View>
  );
}

function NextButton({
  accent,
  label,
  icon,
  onPress,
  disabled,
  loading,
}: Readonly<{
  accent: string;
  label: string;
  icon: IconGlyphName;
  onPress: () => void;
  disabled?: boolean;
  loading?: boolean;
}>) {
  const scale = useSharedValue(1);
  const pressStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  const inactive = disabled || loading;
  return (
    <Animated.View style={[styles.nextWrap, { shadowColor: accent }, inactive && styles.nextOff, pressStyle]}>
      <Pressable
        onPress={onPress}
        disabled={inactive}
        onPressIn={() => {
          scale.value = withSpring(0.96, { damping: 18, stiffness: 320 });
        }}
        onPressOut={() => {
          scale.value = withSpring(1, { damping: 14, stiffness: 260 });
        }}
        style={styles.nextBtn}
        accessibilityRole="button"
        accessibilityLabel={label}
        accessibilityState={{ disabled: !!inactive }}
      >
        <LinearGradient colors={[accent, `${accent}CC`]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} />
        <LinearGradient
          colors={['rgba(255,255,255,0.28)', 'rgba(255,255,255,0)']}
          start={{ x: 0.5, y: 0 }}
          end={{ x: 0.5, y: 1 }}
          style={styles.nextSheen}
        />
        {loading ? (
          <ActivityIndicator color="#fff" />
        ) : (
          <>
            <Animated.Text key={label} entering={FadeInDown.duration(220)} style={styles.nextText}>
              {label}
            </Animated.Text>
            <View style={styles.nextIcon}>
              <ChromeGlyph name={icon} size={18} color="#fff" />
            </View>
          </>
        )}
      </Pressable>
    </Animated.View>
  );
}

function ProgressSegment({ fill: target, color }: Readonly<{ fill: number; color: string }>) {
  const w = useSharedValue(target);
  useEffect(() => {
    w.value = withTiming(target, { duration: 380 });
  }, [target, w]);
  const fill = useAnimatedStyle(() => ({ width: `${w.value * 100}%` }));
  return (
    <View style={styles.segmentTrack}>
      <Animated.View style={[styles.segmentFill, { backgroundColor: color }, fill]} />
    </View>
  );
}

export default function ProSetupWizard({
  version,
  continuePath,
  blockedPath,
  preview = false,
  signup = false,
  onClose,
  onSignIn,
}: Readonly<{
  version: string;
  continuePath: string;
  blockedPath: string;
  /** Walk-through only: nothing is loaded or saved. */
  preview?: boolean;
  /** Starts with name, email and password, creating the account before the profile steps. */
  signup?: boolean;
  onClose?: () => void;
  onSignIn?: () => void;
}>) {
  const { user, updateUser, register } = useAuth();
  const STEPS = signup ? SIGNUP_STEPS : SETUP_STEPS;
  const SECTION_ORDER = signup ? SIGNUP_SECTION_ORDER : SETUP_SECTION_ORDER;
  const firstProfileStep = STEPS.findIndex((s) => s.kind === 'contact');
  const insets = useSafeAreaInsets();
  const { width: windowW, height: windowH } = useWindowDimensions();
  const scrollRef = useRef<ScrollView>(null);
  const heroHeight = Math.round(Math.min(Math.max(windowH * 0.24, 150), 220));

  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [step, setStep] = useState(0);

  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [registered, setRegistered] = useState(false);
  const [nameError, setNameError] = useState<string | null>(null);

  const [photoUrl, setPhotoUrl] = useState<string | null>(null);
  const [photoUploading, setPhotoUploading] = useState(false);

  const [accountMode, setAccountMode] = useState<TermsMode>('mobile_based');
  const [hasInsurance, setHasInsurance] = useState<YesNo | null>(null);
  const [insuranceProvider, setInsuranceProvider] = useState('');
  const [insuranceType, setInsuranceType] = useState('');
  const [policyNumber, setPolicyNumber] = useState('');

  const [docs, setDocs] = useState<UploadedDocument[]>([]);
  const [docUploading, setDocUploading] = useState<string | null>(null);

  const [agreements, setAgreements] = useState<Record<AgreeKey, YesNo | null>>({
    keepCustomers: null,
    keepCalendarAvailability: null,
    shareContactDetails: null,
  });

  const current = STEPS[step]!;
  const isLast = step === STEPS.length - 1;
  const accent = SECTIONS[current.section].accent;

  const roadProgress = useSharedValue(0);
  useEffect(() => {
    roadProgress.value = withTiming(step, { duration: 900, easing: Easing.inOut(Easing.cubic) });
  }, [step, roadProgress]);

  const loadDocs = useCallback(async () => {
    if (!user?.id) return;
    try {
      setDocs(await valeterDocumentsSupabaseService.listUserDocuments(user.id));
    } catch {
      // documents table may be unavailable; uploads still work
    }
  }, [user?.id]);

  useEffect(() => {
    if (preview || !user?.id) {
      setLoading(false);
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const [record, profileRes] = await Promise.all([
          termsAgreementService.load('valeter', user.id),
          supabase
            .from('valeter_profiles')
            .select('full_name, business_name, profile_photo_url')
            .eq('user_id', user.id)
            .maybeSingle(),
        ]);
        if (cancelled) return;
        if (record.status === 'accepted') {
          router.replace(continuePath as any);
          return;
        }
        const d = record.details || {};
        if (d.account_mode === 'physical') setAccountMode('physical');
        if (d.hasBusinessInsurance === 'yes' || d.hasBusinessInsurance === 'no') setHasInsurance(d.hasBusinessInsurance);
        if (typeof d.insuranceProvider === 'string') setInsuranceProvider(d.insuranceProvider);
        if (typeof d.insuranceType === 'string') setInsuranceType(d.insuranceType);
        if (typeof d.policyNumber === 'string') setPolicyNumber(d.policyNumber);

        const p = (profileRes.data ?? null) as
          | { full_name?: string | null; business_name?: string | null; profile_photo_url?: string | null }
          | null;
        const existingName = (p?.full_name || user.name || '').trim();
        setFullName((prev) => prev.trim() || (existingName === 'Car Care Pro' ? '' : existingName));
        setBusinessName((prev) => prev || (p?.business_name ?? ''));
        setPhotoUrl((prev) => prev || p?.profile_photo_url || user.profilePicture || null);
        setPhone((prev) => prev || (user.phone ?? ''));
      } catch (e) {
        console.warn('[ProSetupWizard] load error:', e);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    void loadDocs();
    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  const goTo = useCallback((next: number) => {
    setNameError(null);
    setStep(next);
    scrollRef.current?.scrollTo({ y: 0, animated: false });
  }, []);

  const minStep = signup && registered ? firstProfileStep : 0;

  const back = useCallback(() => {
    if (busy) return true;
    if (step <= minStep) return minStep > 0;
    void hapticFeedback('light');
    goTo(step - 1);
    return true;
  }, [busy, goTo, minStep, step]);

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', back);
    return () => sub.remove();
  }, [back]);

  const saveAbout = async () => {
    if (preview || !user?.id) return;
    const name = fullName.trim();
    const { error } = await supabase
      .from('valeter_profiles')
      .upsert(
        { user_id: user.id, full_name: name, business_name: businessName.trim() || null },
        { onConflict: 'user_id' }
      );
    if (error) throw error;
    await updateUser({ name, ...(phone.trim() ? { phone: phone.trim() } : {}) });
  };

  const createAccount = async (): Promise<boolean> => {
    if (preview || registered) return true;
    const ok = await register({
      email: email.trim(),
      name: fullName.trim(),
      userType: 'valeter',
      password,
    });
    if (!ok) {
      await hapticFeedback('error');
      setNameError("We couldn't create your account. This email may already be registered.");
      return false;
    }
    setRegistered(true);
    await hapticFeedback('success');
    return true;
  };

  const choosePhoto = async (source: 'camera' | 'library') => {
    if ((!preview && !user?.id) || photoUploading) return;
    try {
      await hapticFeedback('light');
      const uri = await pickImage(source, true);
      if (!uri) return;
      if (preview || !user?.id) {
        setPhotoUrl(uri);
        return;
      }
      setPhotoUploading(true);
      const url = await uploadValeterProfilePhoto(user.id, uri, fullName);
      setPhotoUrl(url);
      try {
        await valeterDocumentsSupabaseService.uploadPhotoDocument({
          userId: user.id,
          docTypeId: 'profile_photo',
          docName: 'Profile Photo',
          description: 'Clear face shot on plain background',
          localUri: uri,
        });
      } catch (e) {
        console.warn('[ProSetupWizard] profile photo document copy failed:', e);
      }
      await hapticFeedback('success');
    } catch (e: any) {
      toast.error(e?.message || 'Please try again.', 'Upload failed');
    } finally {
      setPhotoUploading(false);
    }
  };

  const uploadDoc = async (doc: DocDef, source: 'camera' | 'library') => {
    if ((!preview && !user?.id) || docUploading) return;
    await hapticFeedback('light');
    const uri = await pickImage(source, false);
    if (!uri) return;
    if (preview || !user?.id) {
      setDocs((prev) => [
        ...prev.filter((d) => d.docTypeId !== doc.id),
        {
          id: doc.id,
          userId: 'preview',
          docTypeId: doc.id,
          name: doc.name,
          uri,
          type: 'photo',
          uploadDate: new Date(),
          verificationStatus: 'pending',
        },
      ]);
      return;
    }
    try {
      setDocUploading(doc.id);
      await valeterDocumentsSupabaseService.uploadPhotoDocument({
        userId: user.id,
        docTypeId: doc.id,
        docName: doc.name,
        description: doc.description,
        localUri: uri,
      });
      await loadDocs();
      await hapticFeedback('success');
    } catch (e: any) {
      toast.error(e?.message || 'Unable to upload this document right now.', 'Upload failed');
    } finally {
      setDocUploading(null);
    }
  };

  const finish = async () => {
    if (preview || !user?.id) {
      onClose?.();
      if (preview) toast.info('That’s the full Pro setup. Nothing was saved.', 'Preview finished');
      return;
    }
    await termsAgreementService.saveQuestionnaire('valeter', user.id, version, {
      questionnaire_type: 'account_setup_questionnaire',
      account_mode: accountMode,
      keepCustomers: agreements.keepCustomers,
      keepCalendarAvailability: agreements.keepCalendarAvailability,
      shareContactDetails: agreements.shareContactDetails,
      hasBusinessInsurance: hasInsurance,
      insuranceProvider: insuranceProvider.trim(),
      insuranceType: insuranceType.trim(),
      policyNumber: policyNumber.trim(),
    });
    try {
      await updateUser({ valeterOnboarded: true });
    } catch {
      // non-blocking
    }
    await hapticFeedback('success');
    router.replace(continuePath as any);
  };

  const decline = () => {
    if (preview) {
      onClose?.();
      return;
    }
    if (!user?.id || busy) return;
    Alert.alert(
      'Decline agreements?',
      "You won't be able to use your Pro account unless you accept these.",
      [
        { text: 'Go back', style: 'cancel' },
        {
          text: 'Decline',
          style: 'destructive',
          onPress: async () => {
            try {
              setBusy(true);
              await termsAgreementService.decline('valeter', user.id, version, {
                questionnaire_type: 'account_setup_questionnaire',
                account_mode: accountMode,
              });
              router.replace(blockedPath as any);
            } catch (e: any) {
              toast.error(e?.message || 'Please try again.');
            } finally {
              setBusy(false);
            }
          },
        },
      ]
    );
  };

  const insuranceReady = valeterInsuranceDetailsComplete(hasInsurance, insuranceProvider, insuranceType, policyNumber);
  const docMap = useMemo(() => new Map(docs.map((d) => [d.docTypeId, d])), [docs]);
  const firstName = fullName.trim().split(/\s+/)[0] ?? '';
  const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());

  const landmarks = useMemo<RoadLandmark[]>(
    () =>
      STEPS.map((s, i) => {
        const a = SECTIONS[s.section].accent;
        if (i === STEPS.length - 1) return { accent: a, finish: true };
        if (s.kind === 'photo' && photoUrl) return { accent: a, image: { uri: photoUrl } };
        return { accent: a, icon: s.icon };
      }),
    [photoUrl]
  );

  const sectionFill = useMemo(
    () =>
      SECTION_ORDER.map((sec) => {
        const idx = STEPS.map((s, i) => (s.section === sec ? i : -1)).filter((i) => i >= 0);
        const done = idx.filter((i) => i <= step).length;
        return idx.length ? done / idx.length : 0;
      }),
    [step]
  );

  const currentDocStatus = current.doc ? docStatusOf(docMap.get(current.doc.id)) : 'missing';

  const cta = ((): { title: string; disabled: boolean } => {
    switch (current.kind) {
      case 'welcome':
        return { title: "Let's go", disabled: false };
      case 'name':
        return { title: 'Continue', disabled: fullName.trim().length < 2 };
      case 'email':
        return { title: 'Continue', disabled: !emailValid };
      case 'password':
        return {
          title: preview || registered ? 'Continue' : 'Create account',
          disabled: !registered && password.length < 6,
        };
      case 'business':
        return { title: businessName.trim() ? 'Continue' : 'Skip', disabled: false };
      case 'photo':
        return { title: photoUploading ? 'Uploading…' : 'Continue', disabled: !photoUrl || photoUploading };
      case 'insurance':
        return { title: 'Continue', disabled: hasInsurance === null };
      case 'insuranceDetails':
        return { title: 'Continue', disabled: !insuranceReady };
      case 'doc':
        return {
          title: currentDocStatus === 'missing' ? (current.doc?.optional ? 'Skip' : "I'll do this later") : 'Continue',
          disabled: !!docUploading,
        };
      case 'agree':
        return {
          title: isLast ? (preview ? 'Finish preview' : 'Finish setup') : 'Continue',
          disabled: !current.agree || agreements[current.agree.key] === null,
        };
      default:
        return { title: 'Continue', disabled: false };
    }
  })();

  const onPrimary = async () => {
    if (busy) return;
    await hapticFeedback('medium');
    if (current.kind === 'name' && fullName.trim().length < 2) {
      setNameError('Please enter your full name');
      return;
    }
    if (current.kind === 'email' && !emailValid) {
      setNameError('Please enter a valid email address');
      return;
    }
    if (current.kind === 'password' && !registered && password.length < 6) {
      setNameError('Password must be at least 6 characters');
      return;
    }
    if (current.kind === 'insurance' && hasInsurance !== 'yes') {
      showValeterInsuranceRequiredAlert();
      return;
    }
    try {
      setBusy(true);
      if (current.kind === 'password' && !(await createAccount())) return;
      if (current.kind === 'business') await saveAbout();
      if (isLast) {
        await finish();
        return;
      }
      goTo(step + 1);
    } catch (e: any) {
      toast.error(e?.message || 'Something went wrong. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  const renderBody = () => {
    switch (current.kind) {
      case 'welcome':
        return (
          <>
            <View style={styles.bullets}>
              {(signup ? SIGNUP_BULLETS : SETUP_BULLETS).map((b) => (
                <View key={b.title} style={styles.bulletRow}>
                  <ChromeGlyph name={b.icon} size={21} color={accent} style={styles.bulletIcon} />
                  <View style={styles.flex}>
                    <Text style={styles.bulletTitle} numberOfLines={1}>{b.title}</Text>
                    <Text style={styles.bulletText} numberOfLines={1}>{b.text}</Text>
                  </View>
                </View>
              ))}
            </View>
            <View style={styles.chips}>
              {[signup ? 'About 4 minutes' : 'About 3 minutes', 'Saved as you go'].map((c) => (
                <View key={c} style={styles.chip}>
                  <ChromeGlyph name="checkmark" size={15} color={accent} />
                  <Text style={styles.chipText}>{c}</Text>
                </View>
              ))}
            </View>
          </>
        );

      case 'name':
        return (
          <View style={styles.fields}>
            <LineField
              label="Full name"
              icon="person-outline"
              accent={accent}
              value={fullName}
              onChangeText={(v) => {
                setFullName(v);
                if (nameError) setNameError(null);
              }}
              placeholder="Full name"
              autoCapitalize="words"
              autoComplete="name"
              textContentType="name"
              returnKeyType="next"
              onSubmitEditing={() => void onPrimary()}
              valid={fullName.trim().length >= 2}
            />
            {firstName.length > 1 ? (
              <Animated.View entering={FadeIn.duration(200)} style={styles.greetChip}>
                <ChromeGlyph name="sparkles" size={14} color="#F8D70C" />
                <Text style={styles.greetText}>Hi {firstName}, nice to meet you</Text>
              </Animated.View>
            ) : null}
          </View>
        );

      case 'email':
        return (
          <View style={styles.fields}>
            <LineField
              label="Email address"
              icon="mail-outline"
              accent={accent}
              value={email}
              onChangeText={(v) => {
                setEmail(v);
                if (nameError) setNameError(null);
              }}
              placeholder="you@example.com"
              autoCapitalize="none"
              autoCorrect={false}
              keyboardType="email-address"
              autoComplete="email"
              textContentType="emailAddress"
              returnKeyType="next"
              onSubmitEditing={() => void onPrimary()}
              valid={emailValid}
            />
          </View>
        );

      case 'password':
        if (registered) {
          return (
            <View style={styles.trustRow}>
              <ChromeGlyph name="checkmark-circle" size={16} color={GREEN} />
              <Text style={styles.trustText}>Account created. Next, let's finish your Pro profile.</Text>
            </View>
          );
        }
        return (
          <View style={styles.fields}>
            <LineField
              label="Password"
              icon="lock-closed-outline"
              accent={accent}
              value={password}
              onChangeText={(v) => {
                setPassword(v);
                if (nameError) setNameError(null);
              }}
              placeholder="At least 6 characters"
              secureTextEntry={!showPassword}
              autoCapitalize="none"
              autoCorrect={false}
              autoComplete="password-new"
              textContentType="newPassword"
              passwordRules="minlength: 6;"
              returnKeyType="go"
              onSubmitEditing={() => void onPrimary()}
              valid={password.length >= 6}
            />
            <View style={styles.passwordMeta}>
              <View style={styles.flex}>
                <PasswordStrength password={password} />
              </View>
              <Pressable onPress={() => setShowPassword((v) => !v)} hitSlop={10} style={styles.showToggle}>
                <ChromeGlyph name={showPassword ? 'eye-off-outline' : 'eye-outline'} size={16} color={accent} />
                <Text style={[styles.showToggleText, { color: accent }]}>{showPassword ? 'Hide' : 'Show'}</Text>
              </Pressable>
            </View>
          </View>
        );

      case 'contact':
        return (
          <View style={styles.fields}>
            <LineField
              label="Email address"
              icon="mail-outline"
              accent={accent}
              value={user?.email || email.trim() || (preview ? 'you@example.com' : '')}
              editable={false}
            />
            <LineField
              label="Mobile number"
              optional
              icon="call-outline"
              accent={accent}
              value={phone}
              onChangeText={setPhone}
              placeholder="07…"
              keyboardType="phone-pad"
              autoComplete="tel"
              textContentType="telephoneNumber"
            />
          </View>
        );

      case 'business':
        return (
          <View style={styles.fields}>
            <LineField
              label="Business name"
              optional
              icon="briefcase-outline"
              accent={accent}
              value={businessName}
              onChangeText={setBusinessName}
              placeholder="e.g. Shine Mobile Valeting"
              autoCapitalize="words"
              returnKeyType="done"
              onSubmitEditing={() => void onPrimary()}
              valid={!!businessName.trim()}
            />
          </View>
        );

      case 'photo':
        return (
          <View style={styles.mediaBlock}>
            <SourceButtons accent={accent} disabled={photoUploading} onPick={(s) => void choosePhoto(s)} />
            <View style={styles.trustRow}>
              {photoUploading ? (
                <ActivityIndicator size="small" color={accent} />
              ) : (
                <ChromeGlyph
                  name={photoUrl ? 'checkmark-circle' : 'information-circle'}
                  size={15}
                  color={photoUrl ? GREEN : 'rgba(226,232,240,0.55)'}
                />
              )}
              <Text style={styles.trustText}>
                {photoUploading
                  ? 'Uploading your photo…'
                  : photoUrl
                    ? 'Photo added. Look for it on the road above.'
                    : 'Face clearly visible, plain background, no sunglasses.'}
              </Text>
            </View>
          </View>
        );

      case 'mode':
        return (
          <View style={styles.options}>
            {MODE_OPTIONS.map((opt) => (
              <OptionRow
                key={opt.value}
                icon={opt.icon}
                title={opt.label}
                body={opt.body}
                selected={accountMode === opt.value}
                accent={accent}
                onPress={() => setAccountMode(opt.value)}
              />
            ))}
          </View>
        );

      case 'insurance':
        return (
          <View style={styles.options}>
            <OptionRow icon="checkmark-circle" title="Yes" body="I'm insured for valeting work" selected={hasInsurance === 'yes'} accent={accent} onPress={() => setHasInsurance('yes')} />
            <OptionRow icon="close-circle" title="No" body="Not yet" selected={hasInsurance === 'no'} accent={ERROR} onPress={() => setHasInsurance('no')} />
            {hasInsurance === 'no' ? (
              <Animated.View entering={FadeIn.duration(200)} style={styles.errorRow}>
                <ChromeGlyph name="alert-circle" size={16} color={ERROR} />
                <Text style={styles.errorText}>{VALETER_INSURANCE_ALERT_MESSAGE}</Text>
              </Animated.View>
            ) : null}
          </View>
        );

      case 'insuranceDetails':
        return (
          <View style={styles.fieldsTight}>
            <LineField label="Insurance provider" icon="business-outline" accent={accent} value={insuranceProvider} onChangeText={setInsuranceProvider} placeholder="e.g. Aviva" valid={!!insuranceProvider.trim()} />
            <LineField label="Type of cover" icon="umbrella-outline" accent={accent} value={insuranceType} onChangeText={setInsuranceType} placeholder="e.g. Public liability" valid={!!insuranceType.trim()} />
            <LineField label="Policy number" icon="document-text-outline" accent={accent} value={policyNumber} onChangeText={setPolicyNumber} placeholder="Policy number" autoCapitalize="characters" valid={!!policyNumber.trim()} />
          </View>
        );

      case 'doc': {
        const doc = current.doc!;
        const meta = DOC_STATUS[currentDocStatus];
        const uploaded = docMap.get(doc.id);
        const uploading = docUploading === doc.id;
        return (
          <View style={styles.mediaBlock}>
            <View style={styles.docPreviewRow}>
              {uploaded?.uri ? (
                <Image source={{ uri: uploaded.uri }} style={styles.docThumb} />
              ) : (
                <View style={[styles.docThumb, styles.docThumbEmpty]}>
                  <ChromeGlyph name={doc.icon} size={26} color="rgba(226,232,240,0.45)" />
                </View>
              )}
              <View style={styles.flex}>
                <View style={styles.statusRow}>
                  {uploading ? (
                    <ActivityIndicator size="small" color={accent} />
                  ) : (
                    <View style={[styles.statusDot, { backgroundColor: meta.color }]} />
                  )}
                  <Text style={[styles.statusText, { color: meta.color }]}>{uploading ? 'Uploading…' : meta.label}</Text>
                </View>
                {doc.optional ? <Text style={styles.bulletText}>Optional, but it helps you stand out.</Text> : null}
              </View>
            </View>
            {currentDocStatus !== 'approved' ? (
              <SourceButtons accent={accent} disabled={!!docUploading} onPick={(s) => void uploadDoc(doc, s)} />
            ) : null}
            <View style={styles.trustRow}>
              <ChromeGlyph name="shield-checkmark" size={14} color={GREEN} />
              <Text style={styles.trustText}>Stored securely. You can also do this later in Profile → Documents.</Text>
            </View>
          </View>
        );
      }

      case 'agree': {
        const key = current.agree!.key;
        return (
          <View style={styles.options}>
            <OptionRow icon="checkmark-circle" title="Yes, I agree" selected={agreements[key] === 'yes'} accent={accent} onPress={() => setAgreements((p) => ({ ...p, [key]: 'yes' }))} />
            <OptionRow icon="close-circle" title="No" selected={agreements[key] === 'no'} accent={ERROR} onPress={() => setAgreements((p) => ({ ...p, [key]: 'no' }))} />
            {isLast ? (
              <Text style={styles.footnote}>
                By finishing you confirm you've read and agree to our{' '}
                <Text style={styles.link} onPress={() => router.push('/terms-of-service' as any)}>Terms of Service</Text>
                {' & '}
                <Text style={styles.link} onPress={() => router.push('/privacy-policy' as any)}>Privacy Policy</Text>
              </Text>
            ) : null}
          </View>
        );
      }

      default:
        return null;
    }
  };

  const secondary =
    signup && onSignIn && !registered && step <= firstProfileStep - 2
      ? { label: 'I already have an account', onPress: onSignIn, danger: false }
      : current.kind === 'photo' && !photoUrl
      ? { label: 'Skip for now', onPress: () => goTo(step + 1), danger: false }
      : isLast
        ? { label: 'Decline', onPress: decline, danger: true }
        : null;

  const isAgree = current.kind === 'agree';
  const canExit = signup && !preview && step === 0 && !!onClose;

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />
      <LinearGradient colors={['#0C2740', '#081B2E', '#050F1C']} style={StyleSheet.absoluteFill} pointerEvents="none" />
      <BubbleBackground accountType="valeter" />

      <View style={[styles.topBar, { paddingTop: insets.top + 6 }]}>
        <Pressable
          onPress={canExit ? onClose : back}
          disabled={step <= minStep && !canExit}
          hitSlop={12}
          style={[styles.topBack, step <= minStep && !canExit && styles.hidden]}
          accessibilityLabel={canExit ? 'Back to sign up' : 'Previous step'}
        >
          <ChromeGlyph name="chevron-back" size={24} color="#F8FAFC" />
        </Pressable>
        <View style={styles.segments}>
          {SECTION_ORDER.map((sec, i) => (
            <ProgressSegment key={sec} fill={sectionFill[i]!} color={SECTIONS[sec].accent} />
          ))}
        </View>
        {preview ? (
          <Pressable onPress={onClose} hitSlop={10} style={styles.exitBtn} accessibilityLabel="Exit preview">
            <ChromeGlyph name="close" size={18} color="#F8FAFC" />
          </Pressable>
        ) : (
          <Text style={styles.stepCount}>
            {step + 1}/{STEPS.length}
          </Text>
        )}
      </View>

      {preview ? (
        <Animated.View entering={FadeIn.delay(200)} style={styles.previewBadge}>
          <ChromeGlyph name="flask" size={12} color="#FDE68A" />
          <Text style={styles.previewText}>Preview: nothing is saved</Text>
        </Animated.View>
      ) : null}

      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator color={SKY} />
        </View>
      ) : (
        <KeyboardSafeView>
          <ScrollView
            ref={scrollRef}
            style={styles.flex}
            contentContainerStyle={styles.scrollContent}
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
            bounces={false}
          >
            <OnboardingCarRoad
              progress={roadProgress}
              landmarks={landmarks}
              height={heroHeight}
              style={{ width: windowW, marginHorizontal: -18 }}
            />

            <Animated.View key={current.id} entering={FadeInDown.springify().damping(16)} style={styles.panel}>
              <View style={styles.kickerRow}>
                <View style={styles.kickerWrap}>
                  <View style={[styles.kickerDot, { backgroundColor: accent }]} />
                  <Text style={[styles.kicker, { color: accent }]}>{SECTIONS[current.section].label.toUpperCase()}</Text>
                </View>
                <Text style={styles.panelCount}>
                  {step + 1} of {STEPS.length}
                </Text>
              </View>
              {isAgree ? (
                <>
                  <Text style={styles.agreeCount}>{current.title}</Text>
                  <Text style={styles.agreeQuestion}>{current.hint}</Text>
                </>
              ) : (
                <>
                  <Text style={styles.title}>
                    {current.kind === 'welcome' && firstName.length > 1 ? `Hi ${firstName}, let's get you ready` : current.title}
                  </Text>
                  <Text style={styles.hint}>{current.hint}</Text>
                </>
              )}

              {renderBody()}

              {nameError ? (
                <View style={styles.errorRow}>
                  <ChromeGlyph name="alert-circle" size={16} color={ERROR} />
                  <Text style={styles.errorText}>{nameError}</Text>
                </View>
              ) : null}
            </Animated.View>
          </ScrollView>

          <View style={[styles.footer, { paddingBottom: Math.max(insets.bottom, 14) + 4 }]}>
            <View style={styles.footerRow}>
              {step > minStep ? (
                <Animated.View entering={FadeIn}>
                  <Pressable
                    onPress={back}
                    style={({ pressed }) => [styles.backBtn, pressed && styles.pressed]}
                    accessibilityLabel="Previous step"
                  >
                    <ChromeGlyph name="chevron-back" size={22} color="#F8FAFC" />
                  </Pressable>
                </Animated.View>
              ) : null}
              <NextButton
                accent={accent}
                label={cta.title}
                icon={isLast ? 'rocket' : 'arrow-forward'}
                onPress={() => void onPrimary()}
                disabled={cta.disabled}
                loading={busy}
              />
            </View>
            {secondary ? (
              <Pressable onPress={secondary.onPress} disabled={busy} hitSlop={8} style={styles.skipBtn}>
                <Text style={[styles.skipText, secondary.danger && styles.skipDanger]}>{secondary.label}</Text>
              </Pressable>
            ) : null}
          </View>
        </KeyboardSafeView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#061525' },
  flex: { flex: 1 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  hidden: { opacity: 0 },

  topBar: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, gap: 12 },
  topBack: { width: 32, height: 32, alignItems: 'center', justifyContent: 'center' },
  segments: { flex: 1, flexDirection: 'row', gap: 6 },
  segmentTrack: {
    flex: 1,
    height: 4,
    borderRadius: 999,
    backgroundColor: 'rgba(148,163,184,0.18)',
    overflow: 'hidden',
  },
  segmentFill: { height: '100%', borderRadius: 999 },
  passwordMeta: { flexDirection: 'row', alignItems: 'center', gap: 12, marginTop: -6 },
  showToggle: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingVertical: 4 },
  showToggleText: { fontSize: 13, fontWeight: '800' },
  stepCount: { minWidth: 36, textAlign: 'right', color: 'rgba(226,232,240,0.7)', fontSize: 12, fontWeight: '800' },
  exitBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(148,163,184,0.18)',
  },
  previewBadge: { alignSelf: 'center', flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 8 },
  previewText: { color: '#FDE68A', fontSize: 12, fontWeight: '700' },

  scrollContent: { flexGrow: 1, paddingHorizontal: 18, paddingTop: 4, paddingBottom: 8 },
  panel: { width: '100%', paddingHorizontal: 6 },
  kickerRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 },
  kickerWrap: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  kickerDot: { width: 6, height: 6, borderRadius: 3 },
  kicker: { fontSize: 12, fontWeight: '800', letterSpacing: 1.6 },
  panelCount: { color: 'rgba(226,232,240,0.5)', fontSize: 12, fontWeight: '700' },
  title: { color: '#F8FAFC', fontSize: 24, fontWeight: '800', letterSpacing: -0.5, lineHeight: 29 },
  hint: { marginTop: 6, color: 'rgba(226,232,240,0.65)', fontSize: 14, fontWeight: '500', lineHeight: 20 },
  agreeCount: { color: 'rgba(226,232,240,0.55)', fontSize: 13, fontWeight: '700' },
  agreeQuestion: { marginTop: 6, color: '#F8FAFC', fontSize: 20, fontWeight: '800', lineHeight: 26, letterSpacing: -0.3 },

  bullets: { marginTop: 20, gap: 14 },
  bulletRow: { flexDirection: 'row', alignItems: 'center', gap: 14 },
  bulletIcon: { width: 24, textAlign: 'center' },
  bulletTitle: { color: '#F8FAFC', fontSize: 13, fontWeight: '700' },
  bulletText: { marginTop: 1, color: 'rgba(226,232,240,0.6)', fontSize: 12, fontWeight: '500' },
  chips: { marginTop: 18, flexDirection: 'row', flexWrap: 'wrap', columnGap: 18, rowGap: 10 },
  chip: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  chipText: { color: 'rgba(241,245,249,0.85)', fontSize: 13, fontWeight: '600' },

  fields: { marginTop: 20, gap: 18 },
  fieldsTight: { marginTop: 14, gap: 10 },
  lineBlock: { gap: 2 },
  lineLabel: { color: 'rgba(226,232,240,0.55)', fontSize: 11, fontWeight: '800', letterSpacing: 1, textTransform: 'uppercase' },
  optional: { color: 'rgba(226,232,240,0.4)', fontSize: 11, fontWeight: '700', textTransform: 'none', letterSpacing: 0 },
  lineField: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    height: 50,
    borderBottomWidth: 2,
    borderBottomColor: 'rgba(148,163,184,0.25)',
  },
  lineInput: { flex: 1, color: '#F8FAFC', fontSize: 18, fontWeight: '700', paddingVertical: 0 },
  lineInputLocked: { color: 'rgba(226,232,240,0.55)', fontSize: 16 },
  greetChip: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  greetText: { color: '#FDE68A', fontSize: 13, fontWeight: '700' },

  mediaBlock: { alignItems: 'flex-start', marginTop: 16 },
  sourceRow: { flexDirection: 'row', gap: 22 },
  sourcePill: { flexDirection: 'row', alignItems: 'center', gap: 8, height: 40, paddingRight: 8 },
  sourceText: { color: '#E0F2FE', fontSize: 14, fontWeight: '800' },
  trustRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 12 },
  trustText: { flexShrink: 1, color: 'rgba(226,232,240,0.65)', fontSize: 13, fontWeight: '600' },

  docPreviewRow: { flexDirection: 'row', alignItems: 'center', gap: 14, marginBottom: 10, alignSelf: 'stretch' },
  docThumb: { width: 84, height: 60, borderRadius: 12 },
  docThumbEmpty: {
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1.5,
    borderStyle: 'dashed',
    borderColor: 'rgba(148,163,184,0.4)',
  },
  statusRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  statusDot: { width: 8, height: 8, borderRadius: 4 },
  statusText: { fontSize: 14, fontWeight: '800' },

  options: { marginTop: 14 },
  optionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    paddingVertical: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'rgba(148,163,184,0.25)',
  },
  optionTitle: { color: '#F8FAFC', fontSize: 16, fontWeight: '800' },
  optionTitleOff: { color: 'rgba(241,245,249,0.75)' },
  radioRing: {
    width: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 2,
    borderColor: 'rgba(148,163,184,0.5)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  radioDot: { width: 10, height: 10, borderRadius: 5 },

  footnote: { marginTop: 14, color: 'rgba(226,232,240,0.55)', fontSize: 12, lineHeight: 18 },
  link: { color: SKY, fontWeight: '800' },

  errorRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 14 },
  errorText: { flexShrink: 1, color: '#FCA5A5', fontSize: 13, fontWeight: '600', lineHeight: 18 },

  footer: { paddingHorizontal: 18, paddingTop: 8, gap: 2 },
  footerRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  backBtn: {
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(148,163,184,0.12)',
  },
  pressed: { transform: [{ scale: 0.95 }] },
  nextWrap: {
    flex: 1,
    borderRadius: 28,
    shadowOpacity: 0.45,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 6 },
    elevation: 8,
  },
  nextOff: { opacity: 0.45, shadowOpacity: 0 },
  nextBtn: {
    height: 56,
    borderRadius: 28,
    overflow: 'hidden',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
  },
  nextSheen: { position: 'absolute', left: 0, right: 0, top: 0, height: 28 },
  nextText: { color: '#fff', fontSize: 16, fontWeight: '700', letterSpacing: -0.2 },
  nextIcon: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
  skipBtn: { alignSelf: 'center', paddingVertical: 10, paddingHorizontal: 16 },
  skipText: { color: 'rgba(226,232,240,0.7)', fontWeight: '700', fontSize: 14 },
  skipDanger: { color: '#FCA5A5' },
});
