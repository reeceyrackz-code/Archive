import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  Pressable,
  Animated,
  PanResponder,
  Dimensions,
  ActivityIndicator,
} from 'react-native';
import Reanimated, {
  Easing,
  FadeIn,
  FadeInDown,
  ZoomIn,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withTiming,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter, type Href } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import { lightMistElevated, lightMistPanel } from '../../constants/accountThemes';
import { supabase } from '../../lib/supabase';
import {
  DAILY_GOAL_OPTIONS,
  VALETER_PLATFORM_FEE_RATE,
  setValeterDailyGoal,
  startOfMonth,
  startOfToday,
  startOfWeek,
  takeHome,
  useValeterDailyGoal,
} from '../../utils/valeterEarnings';

const { height: SCREEN_H } = Dimensions.get('window');
const MONEY = '#E8C547';
const DAY_LABELS = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
const BAR_MAX_H = 84;

type CompletedRow = { price: number | null; completed_at: string | null };

type Summary = {
  today: number;
  week: number;
  month: number;
  todayJobs: number;
  monthJobs: number;
  weekDays: number[];
};

function summarise(rows: CompletedRow[]): Summary {
  const today = startOfToday().getTime();
  const week = startOfWeek().getTime();
  const month = startOfMonth().getTime();
  const out: Summary = { today: 0, week: 0, month: 0, todayJobs: 0, monthJobs: 0, weekDays: [0, 0, 0, 0, 0, 0, 0] };
  rows.forEach((r) => {
    if (!r.completed_at) return;
    const t = new Date(r.completed_at).getTime();
    if (!Number.isFinite(t)) return;
    const net = takeHome(Number(r.price) || 0);
    if (t >= month) {
      out.month += net;
      out.monthJobs += 1;
    }
    if (t >= week) {
      out.week += net;
      const dayIndex = Math.min(6, Math.floor((t - week) / 86_400_000));
      out.weekDays[dayIndex] += net;
    }
    if (t >= today) {
      out.today += net;
      out.todayJobs += 1;
    }
  });
  return out;
}

function AnimatedMoney({ value, style }: Readonly<{ value: number; style: any }>) {
  const anim = useRef(new Animated.Value(0)).current;
  const [display, setDisplay] = useState(0);
  useEffect(() => {
    const id = anim.addListener(({ value: v }) => setDisplay(v));
    Animated.timing(anim, { toValue: value, duration: 800, useNativeDriver: false }).start();
    return () => anim.removeListener(id);
  }, [anim, value]);
  return <Text style={style}>£{display.toFixed(2)}</Text>;
}

function GoalBar({ progress, color }: Readonly<{ progress: number; color: string }>) {
  const p = useSharedValue(0);
  useEffect(() => {
    p.value = withTiming(Math.min(1, progress), { duration: 900, easing: Easing.out(Easing.cubic) });
  }, [p, progress]);
  const style = useAnimatedStyle(() => ({ width: `${p.value * 100}%` }));
  return (
    <View style={styles.goalTrack}>
      <Reanimated.View style={[styles.goalFill, { backgroundColor: color }, style]} />
    </View>
  );
}

function WeekBar({
  value,
  max,
  isToday,
  index,
  accent,
}: Readonly<{ value: number; max: number; isToday: boolean; index: number; accent: string }>) {
  const h = useSharedValue(0);
  useEffect(() => {
    const target = max > 0 ? Math.max(value > 0 ? 6 : 3, (value / max) * BAR_MAX_H) : 3;
    h.value = withDelay(index * 60, withTiming(target, { duration: 600, easing: Easing.out(Easing.back(1.4)) }));
  }, [h, index, max, value]);
  const style = useAnimatedStyle(() => ({ height: h.value }));
  return (
    <Reanimated.View
      style={[
        styles.bar,
        { backgroundColor: isToday ? MONEY : value > 0 ? `${accent}AA` : 'rgba(148,163,184,0.25)' },
        style,
      ]}
    />
  );
}

export type ValeterEarningsSheetProps = Readonly<{
  visible: boolean;
  userId: string | null | undefined;
  accent: string;
  onClose: () => void;
}>;

export default function ValeterEarningsSheet({ visible, userId, accent, onClose }: ValeterEarningsSheetProps) {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { theme, mode } = useAccountTheme();
  const isLight = mode === 'light';
  const textMain = theme.textPrimary ?? '#F8FAFC';
  const textMuted = theme.textSecondary ?? 'rgba(248,250,252,0.7)';
  const panel = isLight ? lightMistPanel : 'rgba(11,20,36,0.98)';
  const tileBg = isLight ? lightMistElevated : 'rgba(255,255,255,0.05)';
  const goal = useValeterDailyGoal();

  const [loading, setLoading] = useState(false);
  const [summary, setSummary] = useState<Summary | null>(null);
  const translateY = useRef(new Animated.Value(SCREEN_H)).current;

  useEffect(() => {
    if (!visible) return;
    translateY.setValue(SCREEN_H);
    Animated.spring(translateY, { toValue: 0, useNativeDriver: true, damping: 24, stiffness: 260 }).start();
    if (!userId) return;
    let active = true;
    setLoading(true);
    const since = new Date(Math.min(startOfWeek().getTime(), startOfMonth().getTime()));
    void (async () => {
      const { data } = await supabase
        .from('bookings')
        .select('price, completed_at')
        .eq('valeter_id', userId)
        .eq('status', 'completed')
        .gte('completed_at', since.toISOString());
      if (!active) return;
      setSummary(summarise((data as CompletedRow[] | null) ?? []));
      setLoading(false);
    })();
    return () => {
      active = false;
    };
  }, [visible, userId, translateY]);

  const dismiss = useMemo(
    () => () => {
      Animated.timing(translateY, { toValue: SCREEN_H, duration: 220, useNativeDriver: true }).start(() => onClose());
    },
    [onClose, translateY]
  );

  const panResponder = useMemo(
    () =>
      PanResponder.create({
        onMoveShouldSetPanResponder: (_, g) => g.dy > 6 && Math.abs(g.dy) > Math.abs(g.dx),
        onPanResponderMove: (_, g) => translateY.setValue(Math.max(0, g.dy)),
        onPanResponderRelease: (_, g) => {
          if (g.dy > 110 || g.vy > 0.9) {
            dismiss();
            return;
          }
          Animated.spring(translateY, { toValue: 0, useNativeDriver: true, damping: 22, stiffness: 300 }).start();
        },
      }),
    [dismiss, translateY]
  );

  if (!visible) return null;

  const todayNet = summary?.today ?? 0;
  const progress = goal > 0 ? todayNet / goal : 0;
  const remaining = Math.max(0, goal - todayNet);
  const goalHit = remaining <= 0 && todayNet > 0;
  const todayIndex = (new Date().getDay() + 6) % 7;
  const weekMax = Math.max(...(summary?.weekDays ?? [0]), 1);
  const avgPerJob = summary && summary.monthJobs > 0 ? summary.month / summary.monthJobs : 0;
  const feePct = Math.round(VALETER_PLATFORM_FEE_RATE * 100);

  const backdropOpacity = translateY.interpolate({
    inputRange: [0, SCREEN_H * 0.6],
    outputRange: [1, 0],
    extrapolate: 'clamp',
  });

  return (
    <Modal visible transparent animationType="none" onRequestClose={dismiss} statusBarTranslucent>
      <View style={styles.root}>
        <Animated.View style={[StyleSheet.absoluteFill, styles.backdrop, { opacity: backdropOpacity }]}>
          <Pressable style={StyleSheet.absoluteFill} onPress={dismiss} accessibilityLabel="Close earnings" />
        </Animated.View>

        <Animated.View
          style={[
            styles.sheet,
            {
              backgroundColor: panel,
              borderColor: `${MONEY}45`,
              paddingBottom: Math.max(18, insets.bottom + 12),
              transform: [{ translateY }],
            },
          ]}
        >
          <LinearGradient colors={[`${MONEY}26`, `${MONEY}00`]} style={styles.glow} pointerEvents="none" />

          <View {...panResponder.panHandlers}>
            <View style={styles.handleRow}>
              <View style={[styles.handle, { backgroundColor: `${MONEY}70` }]} />
            </View>
            <View style={styles.header}>
              <View style={styles.headerIcon}>
                <Ionicons name="wallet" size={18} color={MONEY} />
              </View>
              <View style={styles.headerCopy}>
                <Text style={[styles.title, { color: textMain }]}>Earnings</Text>
                <Text style={[styles.subtitle, { color: textMuted }]}>
                  Take-home after the {feePct}% platform fee
                </Text>
              </View>
              <Pressable onPress={dismiss} hitSlop={12} style={[styles.closeBtn, { backgroundColor: tileBg }]}>
                <Ionicons name="close" size={18} color={textMuted} />
              </Pressable>
            </View>
          </View>

          {loading && !summary ? (
            <View style={styles.loading}>
              <ActivityIndicator color={MONEY} />
            </View>
          ) : (
            <Reanimated.View entering={FadeIn.duration(220)}>
              <View style={[styles.todayCard, { backgroundColor: tileBg, borderColor: `${MONEY}35` }]}>
                <View style={styles.todayTop}>
                  <Text style={[styles.eyebrow, { color: textMuted }]}>TODAY</Text>
                  <Text style={[styles.todayJobs, { color: textMuted }]}>
                    {summary?.todayJobs ?? 0} job{summary?.todayJobs === 1 ? '' : 's'}
                  </Text>
                </View>
                <AnimatedMoney value={todayNet} style={styles.todayValue} />
                <GoalBar progress={progress} color={goalHit ? '#34D399' : MONEY} />
                <View style={styles.goalRow}>
                  {goalHit ? (
                    <Reanimated.View entering={ZoomIn.springify()} style={styles.goalHitRow}>
                      <Ionicons name="trophy" size={13} color="#34D399" />
                      <Text style={[styles.goalText, { color: '#34D399' }]}>£{goal} goal reached — nice work</Text>
                    </Reanimated.View>
                  ) : (
                    <Text style={[styles.goalText, { color: textMuted }]}>
                      £{remaining.toFixed(0)} to your £{goal} daily goal
                    </Text>
                  )}
                </View>
                <View style={styles.goalChips}>
                  {DAILY_GOAL_OPTIONS.map((g) => {
                    const active = g === goal;
                    return (
                      <Pressable
                        key={g}
                        onPress={() => {
                          void hapticFeedback('light');
                          void setValeterDailyGoal(g);
                        }}
                        style={[
                          styles.goalChip,
                          {
                            backgroundColor: active ? MONEY : 'transparent',
                            borderColor: active ? MONEY : 'rgba(148,163,184,0.35)',
                          },
                        ]}
                        accessibilityRole="button"
                        accessibilityState={{ selected: active }}
                        accessibilityLabel={`Set daily goal to £${g}`}
                      >
                        <Text style={[styles.goalChipText, { color: active ? '#0A1929' : textMuted }]}>£{g}</Text>
                      </Pressable>
                    );
                  })}
                </View>
              </View>

              <View style={[styles.weekCard, { backgroundColor: tileBg }]}>
                <View style={styles.weekHeader}>
                  <Text style={[styles.eyebrow, { color: textMuted }]}>THIS WEEK</Text>
                  <Text style={[styles.weekTotal, { color: MONEY }]}>£{(summary?.week ?? 0).toFixed(2)}</Text>
                </View>
                <View style={styles.bars}>
                  {(summary?.weekDays ?? [0, 0, 0, 0, 0, 0, 0]).map((v, i) => (
                    <View key={i} style={styles.barCol}>
                      <View style={styles.barSlot}>
                        <WeekBar value={v} max={weekMax} isToday={i === todayIndex} index={i} accent={accent} />
                      </View>
                      <Text
                        style={[
                          styles.barLabel,
                          { color: i === todayIndex ? MONEY : textMuted },
                          i === todayIndex && styles.barLabelToday,
                        ]}
                      >
                        {DAY_LABELS[i]}
                      </Text>
                    </View>
                  ))}
                </View>
              </View>

              <View style={styles.tiles}>
                {[
                  { label: 'This month', value: `£${(summary?.month ?? 0).toFixed(2)}`, icon: 'calendar' as const },
                  { label: 'Jobs this month', value: String(summary?.monthJobs ?? 0), icon: 'checkmark-done' as const },
                  { label: 'Avg per job', value: `£${avgPerJob.toFixed(2)}`, icon: 'trending-up' as const },
                ].map((tile, i) => (
                  <Reanimated.View
                    key={tile.label}
                    entering={FadeInDown.delay(120 + i * 60).springify().damping(18)}
                    style={[styles.tile, { backgroundColor: tileBg }]}
                  >
                    <Ionicons name={tile.icon} size={14} color={accent} />
                    <Text style={[styles.tileValue, { color: textMain }]} numberOfLines={1}>
                      {tile.value}
                    </Text>
                    <Text style={[styles.tileLabel, { color: textMuted }]} numberOfLines={1}>
                      {tile.label}
                    </Text>
                  </Reanimated.View>
                ))}
              </View>

              <Pressable
                onPress={() => {
                  void hapticFeedback('light');
                  onClose();
                  router.push('/valeter/features/job-history' as Href);
                }}
                style={({ pressed }) => [styles.historyBtn, { borderColor: `${accent}55`, opacity: pressed ? 0.8 : 1 }]}
              >
                <Text style={[styles.historyText, { color: accent }]}>Full earnings history</Text>
                <Ionicons name="chevron-forward" size={16} color={accent} />
              </Pressable>
            </Reanimated.View>
          )}
        </Animated.View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, justifyContent: 'flex-end' },
  backdrop: { backgroundColor: 'rgba(2,10,22,0.72)' },
  sheet: {
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderWidth: 1,
    borderBottomWidth: 0,
    paddingTop: 8,
    paddingHorizontal: 18,
    overflow: 'hidden',
  },
  glow: { position: 'absolute', top: 0, left: 0, right: 0, height: 160 },
  handleRow: { alignItems: 'center', paddingTop: 2, paddingBottom: 10 },
  handle: { width: 44, height: 5, borderRadius: 3 },
  header: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 14 },
  headerIcon: {
    width: 40,
    height: 40,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: `${MONEY}22`,
    borderWidth: 1,
    borderColor: `${MONEY}50`,
  },
  headerCopy: { flex: 1, minWidth: 0 },
  title: { fontSize: 20, fontWeight: '900', letterSpacing: -0.3 },
  subtitle: { fontSize: 12, fontWeight: '600', marginTop: 2 },
  closeBtn: { width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  loading: { height: 260, alignItems: 'center', justifyContent: 'center' },
  todayCard: { borderRadius: 20, borderWidth: 1, padding: 16, marginBottom: 10 },
  todayTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  eyebrow: { fontSize: 10, fontWeight: '800', letterSpacing: 1.1 },
  todayJobs: { fontSize: 12, fontWeight: '700' },
  todayValue: {
    color: MONEY,
    fontSize: 38,
    fontWeight: '900',
    letterSpacing: -1,
    marginTop: 2,
    marginBottom: 10,
    fontVariant: ['tabular-nums'],
  },
  goalTrack: { height: 8, borderRadius: 4, backgroundColor: 'rgba(148,163,184,0.18)', overflow: 'hidden' },
  goalFill: { height: '100%', borderRadius: 4 },
  goalRow: { marginTop: 8, minHeight: 18 },
  goalHitRow: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  goalText: { fontSize: 12, fontWeight: '700' },
  goalChips: { flexDirection: 'row', gap: 6, marginTop: 10 },
  goalChip: { flex: 1, paddingVertical: 6, borderRadius: 10, borderWidth: 1, alignItems: 'center' },
  goalChipText: { fontSize: 12, fontWeight: '800' },
  weekCard: { borderRadius: 20, padding: 14, marginBottom: 10 },
  weekHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  weekTotal: { fontSize: 16, fontWeight: '900', fontVariant: ['tabular-nums'] },
  bars: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end' },
  barCol: { flex: 1, alignItems: 'center', gap: 6 },
  barSlot: { height: BAR_MAX_H, justifyContent: 'flex-end' },
  bar: { width: 18, borderRadius: 6 },
  barLabel: { fontSize: 11, fontWeight: '700' },
  barLabelToday: { fontWeight: '900' },
  tiles: { flexDirection: 'row', gap: 8, marginBottom: 12 },
  tile: { flex: 1, borderRadius: 16, paddingVertical: 12, paddingHorizontal: 10, gap: 4 },
  tileValue: { fontSize: 16, fontWeight: '900', fontVariant: ['tabular-nums'] },
  tileLabel: { fontSize: 10, fontWeight: '700' },
  historyBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    minHeight: 48,
    borderRadius: 16,
    borderWidth: 1.5,
  },
  historyText: { fontSize: 15, fontWeight: '800' },
});
