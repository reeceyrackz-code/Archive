import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  ActivityIndicator,
  Linking,
  Platform,
} from 'react-native';
import Reanimated, { FadeInDown } from 'react-native-reanimated';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import InfoBottomSheet from '../shared/InfoBottomSheet';
import UkNumberPlate from '../shared/UkNumberPlate';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { supabase } from '../../lib/supabase';
import { getServiceDisplayName } from '../../utils/serviceNameMapper';
import { getServiceIcon } from '../../constants/serviceIcons';
import { fetchProfileById, type CustomerProfileRow } from '../../utils/customerProfiles';
import type { BookingVehicleItem, ValeterTrackingJob } from '../../hooks/useValeterJobTracking';

const ANDROID_BLUR =
  Platform.OS === 'android' ? ({ experimentalBlurMethod: 'dimezisBlurView' as const } as const) : {};

type GlyphName = React.ComponentProps<typeof Ionicons>['name'];

export type ValeterCustomerProfileSheetProps = Readonly<{
  visible: boolean;
  onClose: () => void;
  accent: string;
  valeterId: string | null;
  customerId: string | null;
  customerName: string;
  customerPhotoUri?: string | null;
  job: ValeterTrackingJob | null;
  statusMessage?: string | null;
  vehicles?: BookingVehicleItem[];
  etaMinutes?: number | null;
  distanceMi?: number | null;
  onChat?: () => void;
  /** Sample numbers for the dashboard preview (no customer to look up). */
  sampleStats?: CustomerStats;
}>;

type CustomerStats = {
  withYou: number;
  platformWashes: number;
};

function formatScheduledAt(iso?: string | null): string | null {
  if (!iso) return null;
  try {
    return new Date(iso).toLocaleString(undefined, { weekday: 'short', day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' });
  } catch {
    return null;
  }
}

function vehicleTitle(v: BookingVehicleItem): string {
  return [v.make, v.model].filter(Boolean).join(' ').trim() || 'Vehicle';
}

function initialsOf(name: string) {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  return ((parts[0]?.[0] ?? '') + (parts.length > 1 ? parts.at(-1)?.[0] ?? '' : '')).toUpperCase() || '?';
}

/** How this customer relates to the Pro — the one line that matters before knocking on the door. */
function relationship(stats: CustomerStats | null, first: string): { label: string; icon: GlyphName; tone: string } | null {
  if (!stats) return null;
  // `withYou` includes the current booking.
  const before = Math.max(0, stats.withYou - 1);
  if (before >= 2) return { label: `Regular · ${before} jobs with you`, icon: 'star', tone: '#FBBF24' };
  if (before === 1) return { label: `Returning · booked you before`, icon: 'refresh', tone: '#34D399' };
  if (stats.platformWashes === 0) return { label: `${first}'s first ever booking`, icon: 'sparkles', tone: '#A78BFA' };
  return { label: `New to you · ${stats.platformWashes} washes on Wish-A-Wash`, icon: 'person-add-outline', tone: '#7DD3FC' };
}

function jobDetails(
  job: ValeterTrackingJob | null,
  serviceLabel: string,
  etaMinutes: number | null,
  distanceMi: number | null
): { key: string; icon: GlyphName; label: string; value: string }[] {
  const scheduledLabel = formatScheduledAt(job?.scheduled_at);
  const distanceSuffix = distanceMi == null ? '' : ` · ${distanceMi} mi`;
  const etaLabel = etaMinutes == null ? null : `${etaMinutes} min away${distanceSuffix}`;
  const rows: { key: string; icon: GlyphName; label: string; value: string }[] = [
    { key: 'service', icon: getServiceIcon(serviceLabel), label: 'Service', value: serviceLabel },
  ];
  if (scheduledLabel) rows.push({ key: 'when', icon: 'calendar-outline', label: 'Booked for', value: scheduledLabel });
  if (etaLabel) rows.push({ key: 'eta', icon: 'navigate-outline', label: 'Distance', value: etaLabel });
  if (job?.location_address) rows.push({ key: 'where', icon: 'location-outline', label: 'Address', value: job.location_address });
  return rows;
}

function Glass({ children, style }: Readonly<{ children: React.ReactNode; style?: object }>) {
  return (
    <View style={[styles.glass, style]}>
      <BlurView intensity={Platform.OS === 'ios' ? 30 : 48} tint="dark" style={StyleSheet.absoluteFill} {...ANDROID_BLUR} />
      <LinearGradient
        colors={['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.02)']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      {children}
    </View>
  );
}

function DetailRow({
  icon,
  label,
  value,
  accent,
  textMain,
  textMuted,
  last,
}: Readonly<{ icon: GlyphName; label: string; value: string; accent: string; textMain: string; textMuted: string; last?: boolean }>) {
  return (
    <View style={[styles.detailRow, !last && styles.detailDivider]}>
      <View style={[styles.detailIcon, { backgroundColor: `${accent}1F` }]}>
        <Ionicons name={icon} size={15} color={accent} />
      </View>
      <View style={styles.detailCopy}>
        <Text style={[styles.detailLabel, { color: textMuted }]}>{label}</Text>
        <Text style={[styles.detailValue, { color: textMain }]} numberOfLines={2}>
          {value}
        </Text>
      </View>
    </View>
  );
}

function VehicleCard({ v, accent, textMain, textMuted }: Readonly<{ v: BookingVehicleItem; accent: string; textMain: string; textMuted: string }>) {
  if (v.photo) {
    return (
      <View style={styles.vehiclePhotoCard}>
        <Image source={{ uri: v.photo }} style={StyleSheet.absoluteFill} resizeMode="cover" />
        <LinearGradient colors={['rgba(3,6,14,0)', 'rgba(3,6,14,0.88)']} style={styles.vehicleShade} />
        <View style={styles.vehicleOverlay}>
          <View style={styles.vehicleOverlayCopy}>
            <Text style={styles.vehicleOverlayName} numberOfLines={1}>
              {vehicleTitle(v)}
            </Text>
            {v.colour ? <Text style={styles.vehicleOverlayMeta}>{v.colour}</Text> : null}
          </View>
          {v.registration ? <UkNumberPlate reg={v.registration} size="sm" /> : null}
        </View>
      </View>
    );
  }
  return (
    <Glass style={styles.vehicleRow}>
      <View style={[styles.vehicleIcon, { backgroundColor: `${accent}1F` }]}>
        <Ionicons name="car-sport-outline" size={20} color={accent} />
      </View>
      <View style={styles.detailCopy}>
        <Text style={[styles.vehicleName, { color: textMain }]} numberOfLines={1}>
          {vehicleTitle(v)}
        </Text>
        <Text style={[styles.detailLabel, { color: textMuted }]} numberOfLines={1}>
          {v.colour || 'Details on file'}
        </Text>
      </View>
      {v.registration ? <UkNumberPlate reg={v.registration} size="sm" /> : null}
    </Glass>
  );
}

function ProfileHero({
  name,
  photoUri,
  rel,
  statusMessage,
  accent,
  textMain,
  textMuted,
}: Readonly<{
  name: string;
  photoUri: string | null;
  rel: ReturnType<typeof relationship>;
  statusMessage: string | null;
  accent: string;
  textMain: string;
  textMuted: string;
}>) {
  return (
    <Reanimated.View entering={FadeInDown.duration(380)} style={styles.hero}>
      <View style={[styles.avatarRing, { borderColor: rel?.tone ?? `${accent}80` }]}>
        {photoUri ? (
          <Image source={{ uri: photoUri }} style={styles.avatar} resizeMode="cover" />
        ) : (
          <LinearGradient colors={[`${accent}55`, `${accent}18`]} style={styles.avatarFallback}>
            <Text style={styles.initials}>{initialsOf(name)}</Text>
          </LinearGradient>
        )}
      </View>
      <Text style={[styles.name, { color: textMain }]} numberOfLines={1}>
        {name}
      </Text>
      {rel ? (
        <View style={[styles.relPill, { backgroundColor: `${rel.tone}1A`, borderColor: `${rel.tone}55` }]}>
          <Ionicons name={rel.icon} size={12} color={rel.tone} />
          <Text style={[styles.relText, { color: rel.tone }]} numberOfLines={1}>
            {rel.label}
          </Text>
        </View>
      ) : (
        <ActivityIndicator size="small" color={accent} style={styles.relLoading} />
      )}
      {statusMessage ? (
        <View style={styles.statusRow}>
          <View style={[styles.statusDot, { backgroundColor: accent }]} />
          <Text style={[styles.statusText, { color: textMuted }]} numberOfLines={1}>
            {statusMessage}
          </Text>
        </View>
      ) : null}
    </Reanimated.View>
  );
}

export default function ValeterCustomerProfileSheet({
  visible,
  onClose,
  accent,
  valeterId,
  customerId,
  customerName,
  customerPhotoUri = null,
  job,
  statusMessage = null,
  vehicles = [],
  etaMinutes = null,
  distanceMi = null,
  onChat,
  sampleStats,
}: ValeterCustomerProfileSheetProps) {
  const { theme } = useAccountTheme();
  const textMain = theme.textPrimary ?? '#F1F5F9';
  const textMuted = theme.textSecondary ?? 'rgba(241,245,249,0.62)';
  const moneyColor = theme.accentAlt ?? '#E8C547';

  const [profile, setProfile] = useState<CustomerProfileRow | null>(null);
  const [stats, setStats] = useState<CustomerStats | null>(null);
  const [loadingMeta, setLoadingMeta] = useState(false);

  const loadMeta = useCallback(async () => {
    if (!customerId) {
      setProfile(null);
      setStats(null);
      return;
    }
    setLoadingMeta(true);
    try {
      const [p, withYouRes, platformRes] = await Promise.all([
        fetchProfileById(customerId),
        valeterId
          ? supabase
              .from('bookings')
              .select('id', { count: 'exact', head: true })
              .eq('user_id', customerId)
              .eq('valeter_id', valeterId)
          : Promise.resolve({ count: 0, error: null }),
        supabase
          .from('bookings')
          .select('id', { count: 'exact', head: true })
          .eq('user_id', customerId)
          .eq('status', 'completed'),
      ]);
      setProfile(p);
      setStats({
        withYou: withYouRes.count ?? 0,
        platformWashes: platformRes.count ?? 0,
      });
    } catch {
      setProfile(null);
      setStats({ withYou: 0, platformWashes: 0 });
    } finally {
      setLoadingMeta(false);
    }
  }, [customerId, valeterId]);

  useEffect(() => {
    if (!visible) return;
    void loadMeta();
  }, [visible, loadMeta]);

  const displayName = useMemo(() => {
    const fromProfile = (profile?.full_name || profile?.name || '').trim();
    return fromProfile || customerName || 'Customer';
  }, [customerName, profile?.full_name, profile?.name]);

  const first = displayName.split(/\s+/)[0] || 'Customer';
  const shownStats = sampleStats ?? stats;
  const rel = relationship(shownStats, first);
  const serviceLabel = job ? getServiceDisplayName(job.service_type, job.service_name) : 'Booking';
  const priceLabel = job ? `£${Number(job.price ?? 0).toFixed(2)}` : '—';
  const phone = profile?.phone?.trim() || null;
  const details = jobDetails(job, serviceLabel, etaMinutes, distanceMi);

  const stat = (value: number | undefined) => (loadingMeta && !shownStats ? null : String(value ?? '—'));

  const handleChat = async () => {
    await hapticFeedback('light');
    onClose();
    onChat?.();
  };

  const handleCall = async () => {
    if (!phone) return;
    await hapticFeedback('light');
    void Linking.openURL(`tel:${phone.replaceAll(/[^\d+]/g, '')}`);
  };

  return (
    <InfoBottomSheet
      visible={visible}
      onClose={onClose}
      title="Customer"
      accentColor={accent}
      variant="header"
      contentMaxHeight="88%"
      sizeToContent
    >
      <View style={styles.root}>
        <ProfileHero
          name={displayName}
          photoUri={customerPhotoUri}
          rel={rel}
          statusMessage={statusMessage}
          accent={accent}
          textMain={textMain}
          textMuted={textMuted}
        />

        {onChat || phone ? (
          <Reanimated.View entering={FadeInDown.delay(60).duration(380)} style={styles.actions}>
            {onChat ? (
              <TouchableOpacity style={[styles.primaryBtn, { backgroundColor: accent }]} onPress={handleChat} activeOpacity={0.88}>
                <Ionicons name="chatbubble-ellipses" size={18} color="#04121F" />
                <Text style={styles.primaryText}>Message {first}</Text>
              </TouchableOpacity>
            ) : null}
            {phone ? (
              <TouchableOpacity
                style={[styles.iconBtn, { borderColor: `${accent}55` }]}
                onPress={handleCall}
                activeOpacity={0.88}
                accessibilityLabel={`Call ${first}`}
              >
                <Ionicons name="call" size={19} color={accent} />
              </TouchableOpacity>
            ) : null}
          </Reanimated.View>
        ) : null}

        <Reanimated.View entering={FadeInDown.delay(110).duration(380)} style={styles.stats}>
          <Glass style={styles.statTile}>
            <Text style={[styles.statValue, { color: textMain }]}>{stat(shownStats?.withYou) ?? '…'}</Text>
            <Text style={[styles.statLabel, { color: textMuted }]}>Jobs with you</Text>
          </Glass>
          <Glass style={styles.statTile}>
            <Text style={[styles.statValue, { color: textMain }]}>{stat(shownStats?.platformWashes) ?? '…'}</Text>
            <Text style={[styles.statLabel, { color: textMuted }]}>Washes done</Text>
          </Glass>
          <Glass style={styles.statTile}>
            <Text style={[styles.statValue, { color: moneyColor }]} numberOfLines={1} adjustsFontSizeToFit>
              {priceLabel}
            </Text>
            <Text style={[styles.statLabel, { color: textMuted }]}>This job</Text>
          </Glass>
        </Reanimated.View>

        {details.length > 0 ? (
          <Reanimated.View entering={FadeInDown.delay(160).duration(380)}>
            <Glass style={styles.detailsCard}>
              {details.map((d, i) => (
                <DetailRow
                  key={d.key}
                  icon={d.icon}
                  label={d.label}
                  value={d.value}
                  accent={accent}
                  textMain={textMain}
                  textMuted={textMuted}
                  last={i === details.length - 1}
                />
              ))}
            </Glass>
          </Reanimated.View>
        ) : null}

        {vehicles.length > 0 ? (
          <Reanimated.View entering={FadeInDown.delay(210).duration(380)} style={styles.vehicleSection}>
            <Text style={[styles.sectionLabel, { color: textMuted }]}>
              {vehicles.length > 1 ? `${vehicles.length} vehicles` : 'Vehicle'}
            </Text>
            {vehicles.map((v) => (
              <VehicleCard key={v.id} v={v} accent={accent} textMain={textMain} textMuted={textMuted} />
            ))}
          </Reanimated.View>
        ) : null}
      </View>
    </InfoBottomSheet>
  );
}

const styles = StyleSheet.create({
  root: { gap: 14, paddingBottom: 6 },
  glass: {
    borderRadius: 18,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(255,255,255,0.14)',
    overflow: 'hidden',
  },

  hero: { alignItems: 'center', gap: 8, paddingTop: 4 },
  avatarRing: { width: 92, height: 92, borderRadius: 46, borderWidth: 2, padding: 3, marginBottom: 2 },
  avatar: { width: '100%', height: '100%', borderRadius: 43 },
  avatarFallback: { flex: 1, borderRadius: 43, alignItems: 'center', justifyContent: 'center' },
  initials: { color: '#F8FAFC', fontSize: 28, fontWeight: '800', letterSpacing: 0.5 },
  name: { fontSize: 23, fontWeight: '800', letterSpacing: -0.4, maxWidth: '90%' },
  relPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 11,
    paddingVertical: 5,
    borderRadius: 999,
    borderWidth: 1,
    maxWidth: '92%',
  },
  relText: { fontSize: 12, fontWeight: '700', flexShrink: 1 },
  relLoading: { height: 26 },
  statusRow: { flexDirection: 'row', alignItems: 'center', gap: 6, maxWidth: '90%' },
  statusDot: { width: 6, height: 6, borderRadius: 3 },
  statusText: { fontSize: 12, fontWeight: '600', flexShrink: 1 },

  actions: { flexDirection: 'row', gap: 10 },
  primaryBtn: {
    flex: 1,
    height: 52,
    borderRadius: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  primaryText: { color: '#04121F', fontSize: 15, fontWeight: '800' },
  iconBtn: {
    width: 52,
    height: 52,
    borderRadius: 16,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
  },

  stats: { flexDirection: 'row', gap: 8 },
  statTile: { flex: 1, paddingVertical: 12, paddingHorizontal: 10, alignItems: 'center', gap: 2 },
  statValue: { fontSize: 20, fontWeight: '800', letterSpacing: -0.4 },
  statLabel: { fontSize: 10.5, fontWeight: '600' },

  detailsCard: { paddingHorizontal: 12 },
  detailRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 11 },
  detailDivider: { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: 'rgba(255,255,255,0.1)' },
  detailIcon: { width: 32, height: 32, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  detailCopy: { flex: 1, minWidth: 0, gap: 2 },
  detailLabel: { fontSize: 11, fontWeight: '600' },
  detailValue: { fontSize: 14, fontWeight: '700', lineHeight: 19 },

  vehicleSection: { gap: 10 },
  sectionLabel: { fontSize: 11, fontWeight: '700', letterSpacing: 0.4, textTransform: 'uppercase', paddingLeft: 2 },
  vehiclePhotoCard: {
    height: 150,
    borderRadius: 18,
    overflow: 'hidden',
    backgroundColor: '#05080F',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(255,255,255,0.14)',
  },
  vehicleShade: { position: 'absolute', left: 0, right: 0, bottom: 0, height: 90 },
  vehicleOverlay: {
    position: 'absolute',
    left: 14,
    right: 14,
    bottom: 12,
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 10,
  },
  vehicleOverlayCopy: { flex: 1, minWidth: 0 },
  vehicleOverlayName: { color: '#F8FAFC', fontSize: 16, fontWeight: '800' },
  vehicleOverlayMeta: { color: 'rgba(226,232,240,0.8)', fontSize: 12, fontWeight: '600', marginTop: 1 },
  vehicleRow: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 12 },
  vehicleIcon: { width: 40, height: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  vehicleName: { fontSize: 14, fontWeight: '700' },
});
