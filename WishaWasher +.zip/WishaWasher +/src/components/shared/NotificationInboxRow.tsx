import React from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import ReanimatedSwipeable from 'react-native-gesture-handler/ReanimatedSwipeable';
import { ChromeGlyph as Ionicons } from './ChromeGlyph';
import type { IconGlyphName } from './iconGlyphTypes';
import { hapticFeedback } from '../../services/HapticFeedbackService';

export type NotificationInboxGlyph = IconGlyphName;

export type NotificationInboxRowProps = {
  title: string;
  message: string;
  timeLine: string;
  icon: NotificationInboxGlyph;
  accentColor: string;
  onPress?: () => void;
  onDismiss?: () => void;
  showChevron?: boolean;
  chevronAccentColor?: string;
  dismissMode?: 'icon' | 'swipe';
  /** Soft accent rail for urgent items. */
  priorityUrgent?: boolean;
  priorityColor?: string;
  /** Muted, non-interactive row (e.g. completed jobs). */
  disabled?: boolean;
};

/**
 * Lightweight notification feed row — soft icon, text-first, swipe to dismiss.
 */
export function NotificationInboxRow({
  title,
  message,
  timeLine,
  icon,
  accentColor,
  onPress,
  onDismiss,
  showChevron = false,
  chevronAccentColor,
  dismissMode = 'swipe',
  priorityUrgent = false,
  priorityColor = '#F87171',
  disabled = false,
}: Readonly<NotificationInboxRowProps>) {
  const chevron = chevronAccentColor ?? accentColor;
  const safeTitle = (title || '').trim() || 'Notification';
  const safeMessage = (message || '').trim() || 'Tap to view details';
  const safeTimeLine = (timeLine || '').trim() || 'Just now';
  const canPress = Boolean(onPress) && !disabled;
  const tone = disabled ? '#94A3B8' : accentColor;

  const renderCard = () => (
    <Pressable
      onPress={canPress ? onPress : undefined}
      disabled={!canPress}
      style={({ pressed }) => [
        styles.row,
        disabled && styles.rowDisabled,
        pressed && canPress && styles.rowPressed,
      ]}
    >
      {priorityUrgent && !disabled ? (
        <View style={[styles.urgentRail, { backgroundColor: priorityColor }]} />
      ) : null}

      <View style={[styles.iconOrb, { backgroundColor: `${tone}16` }]}>
        <Ionicons name={icon} size={17} color={tone} />
      </View>

      <View style={styles.body}>
        <View style={styles.titleRow}>
          <Text
            style={[styles.title, disabled && styles.titleDisabled]}
            numberOfLines={1}
          >
            {safeTitle}
          </Text>
          <Text style={[styles.time, disabled && styles.timeDisabled]} numberOfLines={1}>
            {safeTimeLine}
          </Text>
        </View>
        <Text
          style={[styles.message, disabled && styles.messageDisabled]}
          numberOfLines={2}
        >
          {safeMessage}
        </Text>
        {priorityUrgent && !disabled ? (
          <Text style={[styles.urgentLabel, { color: priorityColor }]}>Urgent</Text>
        ) : null}
      </View>

      {showChevron && canPress ? (
        <Ionicons name="chevron-forward" size={16} color={`${chevron}88`} style={styles.chevron} />
      ) : null}

      {onDismiss && dismissMode === 'icon' ? (
        <Pressable
          style={({ pressed }) => [styles.dismissBtn, pressed && styles.dismissPressed]}
          onPress={async () => {
            await hapticFeedback('light');
            onDismiss();
          }}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
          accessibilityLabel="Dismiss notification"
        >
          <Ionicons name="close" size={16} color="rgba(248,250,252,0.35)" />
        </Pressable>
      ) : null}
    </Pressable>
  );

  if (onDismiss && dismissMode === 'swipe') {
    return (
      <ReanimatedSwipeable
        containerStyle={styles.swipeable}
        overshootRight={false}
        renderRightActions={() => (
          <Pressable
            style={({ pressed }) => [styles.swipeDelete, pressed && styles.swipeDeletePressed]}
            onPress={async () => {
              await hapticFeedback('light');
              onDismiss();
            }}
            accessibilityLabel="Dismiss notification"
          >
            <Ionicons name="trash-outline" size={18} color="#FECACA" />
          </Pressable>
        )}
      >
        {renderCard()}
      </ReanimatedSwipeable>
    );
  }

  return renderCard();
}

/** Map business feed types to glyph + accent (hex) for {@link NotificationInboxRow}. */
export function businessNotificationIconAccent(
  type: 'booking' | 'booking_update' | 'team_request' | 'team_update',
  themePrimary: string
): { icon: NotificationInboxGlyph; accent: string } {
  switch (type) {
    case 'booking':
      return { icon: 'calendar-outline', accent: themePrimary };
    case 'booking_update':
      return { icon: 'sync-outline', accent: '#60A5FA' };
    case 'team_request':
      return { icon: 'person-add-outline', accent: '#34D399' };
    case 'team_update':
      return { icon: 'people-outline', accent: '#A78BFA' };
    default:
      return { icon: 'notifications-outline', accent: themePrimary };
  }
}

const styles = StyleSheet.create({
  swipeable: {
    overflow: 'hidden',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 2,
    gap: 12,
    minHeight: 72,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'rgba(255,255,255,0.07)',
  },
  rowPressed: {
    opacity: 0.72,
  },
  rowDisabled: {
    opacity: 0.48,
  },
  urgentRail: {
    position: 'absolute',
    left: 0,
    top: 18,
    bottom: 18,
    width: 2.5,
    borderRadius: 2,
  },
  iconOrb: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  body: {
    flex: 1,
    minWidth: 0,
    gap: 3,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: 10,
  },
  title: {
    flex: 1,
    minWidth: 0,
    color: 'rgba(248,250,252,0.96)',
    fontSize: 14,
    fontWeight: '600',
    letterSpacing: -0.1,
    lineHeight: 19,
  },
  titleDisabled: {
    color: 'rgba(248,250,252,0.4)',
  },
  time: {
    color: 'rgba(148,163,184,0.85)',
    fontSize: 11,
    fontWeight: '500',
    flexShrink: 0,
  },
  timeDisabled: {
    color: 'rgba(148,163,184,0.45)',
  },
  message: {
    color: 'rgba(203,213,225,0.72)',
    fontSize: 13,
    fontWeight: '400',
    lineHeight: 18,
  },
  messageDisabled: {
    color: 'rgba(148,163,184,0.4)',
  },
  urgentLabel: {
    marginTop: 2,
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.6,
    textTransform: 'uppercase',
  },
  chevron: {
    marginLeft: 2,
  },
  dismissBtn: {
    width: 28,
    height: 28,
    alignItems: 'center',
    justifyContent: 'center',
  },
  dismissPressed: {
    opacity: 0.6,
  },
  swipeDelete: {
    width: 64,
    marginLeft: 4,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(239,68,68,0.14)',
    borderRadius: 12,
  },
  swipeDeletePressed: {
    opacity: 0.8,
  },
});
