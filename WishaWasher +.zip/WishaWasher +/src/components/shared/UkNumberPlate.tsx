import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

const PLATE_YELLOW = '#F5C518';

const SIZES = {
  sm: { height: 24, minWidth: 92, font: 14, band: 12, bandFont: 6, spacing: 1 },
  md: { height: 40, minWidth: 168, font: 26, band: 20, bandFont: 8, spacing: 2 },
  lg: { height: 52, minWidth: 220, font: 34, band: 20, bandFont: 8, spacing: 2 },
} as const;

/** "AB12CDE" → "AB12 CDE" (current UK format); anything else is just upper-cased. */
export function formatUkReg(reg: string) {
  const r = reg.replace(/\s+/g, '').toUpperCase();
  return /^[A-Z]{2}\d{2}[A-Z]{3}$/.test(r) ? `${r.slice(0, 4)} ${r.slice(4)}` : r;
}

export default function UkNumberPlate({ reg, size = 'md' }: Readonly<{ reg: string; size?: keyof typeof SIZES }>) {
  const s = SIZES[size];
  return (
    <View style={[styles.plate, { height: s.height, minWidth: s.minWidth, borderRadius: s.height * 0.15 }]}>
      <View style={[styles.band, { width: s.band }]}>
        <Text style={[styles.bandText, { fontSize: s.bandFont }]}>UK</Text>
      </View>
      <Text
        style={[styles.text, { fontSize: s.font, letterSpacing: s.spacing, paddingHorizontal: s.height * 0.3 }]}
        numberOfLines={1}
        adjustsFontSizeToFit
      >
        {formatUkReg(reg)}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  plate: {
    flexDirection: 'row',
    alignItems: 'stretch',
    alignSelf: 'flex-start',
    overflow: 'hidden',
    backgroundColor: PLATE_YELLOW,
    borderWidth: 1.5,
    borderColor: 'rgba(0,0,0,0.55)',
    shadowColor: '#000',
    shadowOpacity: 0.45,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
  },
  band: { backgroundColor: '#0B3D91', alignItems: 'center', justifyContent: 'flex-end', paddingBottom: 3 },
  bandText: { color: '#F8FAFC', fontWeight: '800' },
  text: {
    flex: 1,
    alignSelf: 'center',
    textAlign: 'center',
    color: '#0A0A0A',
    fontWeight: '800',
    fontVariant: ['tabular-nums'],
  },
});
