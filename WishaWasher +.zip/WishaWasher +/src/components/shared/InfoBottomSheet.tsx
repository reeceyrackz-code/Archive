/**
 * Shared info bottom sheet – supports light/dark theme.
 */
import React, { useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  Pressable,
  TouchableOpacity,
  ScrollView,
  Platform,
  Dimensions,
  type ViewStyle,
} from 'react-native';
import { ChromeGlyph as Ionicons } from './ChromeGlyph';
import { HEADER_STYLE_CARD_BORDER } from '../../constants/bookingCardTheme';
import { colors } from '../../constants/colors';
import { useAccountTheme } from './AccountThemeProvider';
import BusinessSheetBackground from './BusinessSheetBackground';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import KeyboardSafeView from './KeyboardSafeView';
import { KEYBOARD_SCROLL_PROPS, useKeyboardHeight } from '../../hooks/useKeyboardHeight';

const SKY = colors.SKY;

export interface InfoBottomSheetProps {
  visible: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  accentColor?: string;
  footer?: React.ReactNode;
  contentMaxHeight?: string;
  /** When 'linkedin', uses light background, dark text. When 'header', uses header-matching gradient with more opacity, light text. */
  variant?: 'default' | 'linkedin' | 'header';
  /** Sheet height follows content (capped by contentMaxHeight) instead of always filling the max. */
  sizeToContent?: boolean;
  contentContainerStyle?: ViewStyle;
}

function resolveMaxHeight(contentMaxHeight: string, windowH: number): number {
  if (contentMaxHeight.endsWith('%')) {
    const pct = Number.parseFloat(contentMaxHeight);
    if (Number.isFinite(pct)) return (pct / 100) * windowH;
  }
  const px = Number.parseFloat(contentMaxHeight);
  return Number.isFinite(px) ? px : windowH * 0.85;
}

type SheetVariant = NonNullable<InfoBottomSheetProps['variant']>;

function handleStyle(variant: SheetVariant, accent: string, isLight: boolean): ViewStyle {
  if (variant === 'linkedin') return styles.handleLinkedIn;
  if (variant === 'header' || !isLight) return { backgroundColor: `${accent}50` };
  return { backgroundColor: 'rgba(100,116,139,0.35)' };
}

function useSheetChrome(variant: SheetVariant, accentColor: string) {
  const { theme } = useAccountTheme();
  if (variant === 'linkedin') {
    return { title: '#000000', close: '#666666', border: '#EBEBEB', handle: styles.handleLinkedIn };
  }
  const sheetBorder = theme.glassBorder ?? HEADER_STYLE_CARD_BORDER;
  return {
    title: theme.textPrimary ?? '#F9FAFB',
    close: theme.textSecondary ?? 'rgba(249,250,251,0.9)',
    border: variant !== 'header' && accentColor !== SKY ? `${accentColor}40` : sheetBorder,
    handle: handleStyle(variant, accentColor || theme.primary || SKY, theme.mode === 'light'),
  };
}

/** Max height, kept fully above the keyboard (with a small gap) while it's open. */
function useSheetMaxHeight(contentMaxHeight: string, keyboardHeight: number) {
  return useMemo(() => {
    const windowH = Dimensions.get('window').height;
    const base = resolveMaxHeight(contentMaxHeight, windowH);
    if (keyboardHeight <= 0) return base;
    return Math.max(280, Math.min(base, windowH - keyboardHeight - 8));
  }, [contentMaxHeight, keyboardHeight]);
}

/** Light mode = reference style (muted blue–navy) → same glass sheet + light text. */
export default function InfoBottomSheet({
  visible,
  onClose,
  title,
  children,
  accentColor = SKY,
  footer,
  contentMaxHeight = '85%',
  variant = 'default',
  sizeToContent = false,
  contentContainerStyle,
}: Readonly<InfoBottomSheetProps>) {
  const insets = useSafeAreaInsets();
  const linkedIn = variant === 'linkedin';
  const headerStyle = variant === 'header';
  const chrome = useSheetChrome(variant, accentColor);
  const keyboardHeight = useKeyboardHeight(visible);
  const sheetMaxHeight = useSheetMaxHeight(contentMaxHeight, keyboardHeight);
  const footerPadBottom = keyboardHeight > 0 ? 12 : Math.max(24, insets.bottom + 12);

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      statusBarTranslucent
      onRequestClose={onClose}
    >
      <KeyboardSafeView style={styles.kav} enabled={visible} padAndroid={false}>
        <View style={styles.overlay}>
          <Pressable style={StyleSheet.absoluteFill} onPress={onClose} />
          <Pressable
            style={[
              styles.content,
              linkedIn && styles.contentLinkedIn,
              headerStyle && styles.contentHeader,
              {
                maxHeight: sheetMaxHeight as ViewStyle['maxHeight'],
                ...(sizeToContent
                  ? {}
                  : { height: sheetMaxHeight as ViewStyle['height'] }),
                marginBottom: Platform.OS === 'android' ? keyboardHeight : 0,
                borderColor: chrome.border,
              },
            ]}
            onPress={(e) => e.stopPropagation()}
          >
            {!linkedIn ? <BusinessSheetBackground /> : null}
            <View style={[styles.handle, chrome.handle]} />
            <View style={[styles.header, linkedIn && styles.headerLinkedIn, headerStyle && styles.headerHeader]}>
              <Text style={[styles.title, { color: chrome.title }, linkedIn && styles.titleLinkedIn]}>{title}</Text>
              <TouchableOpacity
                onPress={onClose}
                hitSlop={12}
                accessibilityLabel="Close"
                accessibilityRole="button"
                style={CLOSE_BTN_STYLE[variant]}
              >
                <Ionicons name="close" size={variant === 'default' ? 24 : 22} color={chrome.close} />
              </TouchableOpacity>
            </View>
            <View style={sizeToContent ? styles.scrollWrapHug : styles.scrollWrap}>
              <ScrollView
                showsVerticalScrollIndicator={!linkedIn}
                bounces={true}
                {...KEYBOARD_SCROLL_PROPS}
                style={sizeToContent ? undefined : styles.scroll}
                contentContainerStyle={[
                  styles.scrollContent,
                  SCROLL_CONTENT_STYLE[variant],
                  sizeToContent && styles.scrollContentHug,
                  contentContainerStyle,
                ]}
              >
                {children}
              </ScrollView>
            </View>
            {footer ? (
              <View style={[styles.footer, FOOTER_STYLE[variant], { paddingBottom: footerPadBottom }]}>{footer}</View>
            ) : null}
          </Pressable>
        </View>
      </KeyboardSafeView>
    </Modal>
  );
}

const SCROLL_CONTENT_STYLE: Record<SheetVariant, ViewStyle | undefined> = {
  default: undefined,
  linkedin: { paddingHorizontal: 20 },
  header: { paddingHorizontal: 20 },
};

const FOOTER_STYLE: Record<SheetVariant, ViewStyle | undefined> = {
  default: undefined,
  linkedin: { borderTopColor: '#EBEBEB' },
  header: { borderTopColor: 'rgba(255,255,255,0.12)' },
};

const CLOSE_BTN_STYLE: Record<SheetVariant, ViewStyle | undefined> = {
  default: undefined,
  linkedin: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  header: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
};

const styles = StyleSheet.create({
  kav: {
    flex: 1,
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.72)',
    justifyContent: 'flex-end',
  },
  content: {
    width: '100%',
    backgroundColor: 'transparent',
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderWidth: 1,
    overflow: 'hidden',
  },
  contentLinkedIn: {
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 16,
  },
  contentHeader: {
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 16,
  },
  headerHeader: {
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.12)',
    paddingBottom: 14,
    marginBottom: 0,
  },
  handleLinkedIn: {
    width: 36,
    height: 4,
    backgroundColor: '#DADADA',
    borderRadius: 2,
  },
  headerLinkedIn: {
    borderBottomWidth: 1,
    borderBottomColor: '#EBEBEB',
    paddingBottom: 14,
    marginBottom: 0,
  },
  titleLinkedIn: {
    fontSize: 20,
    fontWeight: '600',
  },
  handle: {
    width: 36,
    height: 3,
    borderRadius: 2,
    alignSelf: 'center',
    marginTop: 10,
    marginBottom: 14,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 22,
    paddingTop: 8,
    paddingBottom: 14,
  },
  title: {
    color: '#F9FAFB',
    fontSize: 19,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  scrollWrap: {
    flex: 1,
    minHeight: 0,
  },
  scrollWrapHug: {
    flexGrow: 0,
    flexShrink: 1,
  },
  scroll: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 22,
    paddingBottom: 36,
    flexGrow: 1,
  },
  scrollContentHug: {
    flexGrow: 0,
    paddingBottom: 18,
  },
  footer: {
    paddingHorizontal: 22,
    paddingTop: 14,
    borderTopWidth: 1,
    borderTopColor: 'rgba(148,163,184,0.18)',
  },
});

/** LinkedIn variant: light background, dark text – use for content when variant="linkedin". */
export const infoBottomSheetLinkedInStyles = StyleSheet.create({
  block: { marginBottom: 20 },
  blockTitle: { color: '#000000', fontSize: 16, fontWeight: '600', marginBottom: 4 },
  blockSubtitle: { color: '#666666', fontSize: 13, marginBottom: 12, lineHeight: 18 },
  list: { backgroundColor: '#FFFFFF', borderRadius: 8, borderWidth: 1, borderColor: '#EBEBEB', overflow: 'hidden' },
  listItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: 14, paddingHorizontal: 16, borderBottomWidth: 1, borderBottomColor: '#EBEBEB' },
  listItemLast: { borderBottomWidth: 0 },
  listItemIcon: { width: 36, height: 36, borderRadius: 18, backgroundColor: '#E7F3FF', alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  listItemLabel: { color: '#666666', fontSize: 14, fontWeight: '500', minWidth: 100 },
  listItemValue: { flex: 1, color: '#000000', fontSize: 15, fontWeight: '600' },
  listItemValueAccent: { fontSize: 17, fontWeight: '700', color: '#0A66C2' },
  reviewBlock: { marginTop: 12, padding: 16, borderRadius: 8, backgroundColor: '#F3F2EF', borderWidth: 1, borderColor: '#EBEBEB' },
  reviewLabel: { color: '#666666', fontSize: 12, fontWeight: '600', marginBottom: 6 },
  reviewText: { color: '#000000', fontSize: 14, fontStyle: 'italic', lineHeight: 20 },
  saveBtn: { backgroundColor: '#0A66C2', borderRadius: 24, paddingVertical: 14, alignItems: 'center', justifyContent: 'center' },
  saveBtnText: { color: '#FFFFFF', fontSize: 16, fontWeight: '600' },
});

/** Header variant: header-matching gradient, light text – use for content when variant="header". */
export const infoBottomSheetHeaderStyles = StyleSheet.create({
  list: { backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: 8, borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)', overflow: 'hidden' },
  listItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: 14, paddingHorizontal: 16, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.08)', backgroundColor: 'transparent' },
  listItemLast: { borderBottomWidth: 0 },
  listItemIcon: { width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(135,206,235,0.2)', alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  listItemLabel: { color: 'rgba(249,250,251,0.85)', fontSize: 14, fontWeight: '500', minWidth: 100 },
  listItemValue: { flex: 1, color: '#F9FAFB', fontSize: 15, fontWeight: '600' },
  listItemValueAccent: { fontSize: 17, fontWeight: '700', color: SKY },
  reviewBlock: { marginTop: 12, padding: 16, borderRadius: 8, backgroundColor: 'rgba(255,255,255,0.06)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)' },
  reviewLabel: { color: 'rgba(249,250,251,0.7)', fontSize: 12, fontWeight: '600', marginBottom: 6 },
  reviewText: { color: '#F9FAFB', fontSize: 14, fontStyle: 'italic', lineHeight: 20 },
  saveBtn: { borderRadius: 24, paddingVertical: 14, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  saveBtnText: { color: '#FFFFFF', fontSize: 16, fontWeight: '600' },
});

/** Shared content styles – match customer app (avatar, name, stats, sections, info rows). */
export const infoBottomSheetContentStyles = StyleSheet.create({
  avatar: { alignItems: 'center', marginBottom: 12 },
  avatarImg: { width: 88, height: 88, borderRadius: 44, borderWidth: 2, borderColor: SKY },
  avatarInner: { width: 88, height: 88, borderRadius: 44, backgroundColor: 'rgba(135,206,235,0.15)', borderWidth: 2, borderColor: SKY, alignItems: 'center', justifyContent: 'center' },
  hubIcon: { width: 76, height: 76 },
  name: { color: '#F9FAFB', fontSize: 20, fontWeight: '800', textAlign: 'center', marginBottom: 4 },
  org: { color: 'rgba(255,255,255,0.7)', fontSize: 14, textAlign: 'center', marginBottom: 8 },
  joinedRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, marginBottom: 16 },
  joinedText: { color: SKY, fontSize: 13, fontWeight: '600' },
  stats: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, justifyContent: 'center', marginBottom: 24 },
  stat: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  statText: { color: '#E5E7EB', fontSize: 14, fontWeight: '600' },
  section: { marginTop: 8 },
  sectionTitle: { color: '#F9FAFB', fontSize: 16, fontWeight: '700', marginBottom: 12 },
  addressRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, marginBottom: 16 },
  address: { color: 'rgba(255,255,255,0.8)', fontSize: 14, flex: 1 },
  reviewItem: { padding: 12, marginBottom: 8, borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.06)', borderWidth: 1, borderColor: 'rgba(148,163,184,0.15)' },
  reviewHeader: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 6 },
  reviewRating: { color: '#FBBF24', fontSize: 14, fontWeight: '700' },
  reviewText: { color: '#E5E7EB', fontSize: 14, lineHeight: 20 },
  reviewsPlaceholder: { padding: 24, borderRadius: 14, backgroundColor: 'rgba(255,255,255,0.05)', borderWidth: 1, borderColor: 'rgba(148,163,184,0.15)', alignItems: 'center', gap: 8 },
  placeholderText: { color: 'rgba(148,163,184,0.7)', fontSize: 13, fontWeight: '500' },
  infoRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  infoText: { color: 'rgba(241,245,249,0.9)', fontSize: 13, flex: 1 },
  infoModalSection: { marginTop: 4 },
  infoModalSectionTitle: { fontSize: 14, fontWeight: '700', marginBottom: 8, color: '#F9FAFB' },
});
