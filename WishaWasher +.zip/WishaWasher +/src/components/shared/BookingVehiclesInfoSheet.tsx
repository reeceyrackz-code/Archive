import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  Pressable,
  Image,
  Dimensions,
  FlatList,
  Animated,
  PanResponder,
  type NativeSyntheticEvent,
  type NativeScrollEvent,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from './ChromeGlyph';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { useAccountTheme } from './AccountThemeProvider';
import { lightMistElevated, lightMistPanel } from '../../constants/accountThemes';
import { resolveCustomerProfilePictureUrl } from '../../utils/customerProfiles';

export type BookingVehicleGalleryItem = {
  id: string;
  make?: string | null;
  model?: string | null;
  registration?: string | null;
  colour?: string | null;
  photo?: string | null;
};

const { width: SCREEN_W, height: SCREEN_H } = Dimensions.get('window');
const CARD_GAP = 12;
const CARD_W = Math.min(SCREEN_W - 48, 360);
const DISMISS_DISTANCE = 110;
const DISMISS_VELOCITY = 0.9;

const COLOUR_SWATCHES: Record<string, string> = {
  black: '#111827',
  white: '#F9FAFB',
  silver: '#C0C5CE',
  grey: '#6B7280',
  gray: '#6B7280',
  red: '#DC2626',
  blue: '#2563EB',
  navy: '#1E3A8A',
  green: '#16A34A',
  yellow: '#FACC15',
  orange: '#F97316',
  brown: '#78350F',
  beige: '#D6C7A1',
  gold: '#D4AF37',
  purple: '#7C3AED',
  pink: '#EC4899',
  bronze: '#9C6B30',
  maroon: '#7F1D1D',
};

function swatchForColour(colour?: string | null): string | null {
  if (!colour) return null;
  const key = colour.toLowerCase();
  const match = Object.keys(COLOUR_SWATCHES).find((name) => key.includes(name));
  return match ? COLOUR_SWATCHES[match] : null;
}

function titleForVehicle(v: BookingVehicleGalleryItem): string {
  const name = [v.make, v.model].filter(Boolean).join(' ').trim();
  return name || v.registration || 'Vehicle';
}

function NumberPlate({ registration }: Readonly<{ registration: string }>) {
  return (
    <View style={styles.plate} accessibilityLabel={`Registration ${registration}`}>
      <View style={styles.plateBand}>
        <Text style={styles.plateBandText}>UK</Text>
      </View>
      <Text style={styles.plateText} numberOfLines={1}>
        {registration.toUpperCase()}
      </Text>
    </View>
  );
}

function DetailTile({
  icon,
  label,
  value,
  accent,
  textMain,
  textMuted,
  background,
  swatch,
}: Readonly<{
  icon: React.ComponentProps<typeof Ionicons>['name'];
  label: string;
  value: string;
  accent: string;
  textMain: string;
  textMuted: string;
  background: string;
  swatch?: string | null;
}>) {
  return (
    <View style={[styles.tile, { backgroundColor: background, borderColor: `${accent}22` }]}>
      <View style={styles.tileLabelRow}>
        <Ionicons name={icon} size={12} color={accent} />
        <Text style={[styles.tileLabel, { color: textMuted }]}>{label}</Text>
      </View>
      <View style={styles.tileValueRow}>
        {swatch ? <View style={[styles.swatch, { backgroundColor: swatch }]} /> : null}
        <Text style={[styles.tileValue, { color: textMain }]} numberOfLines={1}>
          {value}
        </Text>
      </View>
    </View>
  );
}

export default function BookingVehiclesInfoSheet({
  visible,
  onClose,
  accent,
  vehicles,
}: Readonly<{
  visible: boolean;
  onClose: () => void;
  accent: string;
  vehicles: BookingVehicleGalleryItem[];
}>) {
  const insets = useSafeAreaInsets();
  const { theme, mode } = useAccountTheme();
  const isLight = mode === 'light';
  const textMain = theme.textPrimary ?? '#F8FAFC';
  const textMuted = theme.textSecondary ?? 'rgba(248,250,252,0.7)';
  const panel = isLight ? lightMistPanel : 'rgba(11,20,36,0.98)';
  const elevated = isLight ? lightMistElevated : 'rgba(255,255,255,0.06)';
  const list = useMemo(() => (vehicles.length > 0 ? vehicles : []), [vehicles]);
  const [index, setIndex] = useState(0);
  const listRef = useRef<FlatList<BookingVehicleGalleryItem>>(null);
  const translateY = useRef(new Animated.Value(SCREEN_H)).current;

  useEffect(() => {
    if (!visible) return;
    setIndex(0);
    translateY.setValue(SCREEN_H);
    Animated.spring(translateY, {
      toValue: 0,
      useNativeDriver: true,
      damping: 24,
      stiffness: 260,
      mass: 0.9,
    }).start();
  }, [visible, translateY]);

  const dismiss = useMemo(
    () => () => {
      Animated.timing(translateY, { toValue: SCREEN_H, duration: 220, useNativeDriver: true }).start(() => onClose());
    },
    [onClose, translateY]
  );

  const panResponder = useMemo(
    () =>
      PanResponder.create({
        onMoveShouldSetPanResponder: (_, g) => g.dy > 6 && Math.abs(g.dy) > Math.abs(g.dx),
        onPanResponderMove: (_, g) => translateY.setValue(Math.max(0, g.dy)),
        onPanResponderRelease: (_, g) => {
          if (g.dy > DISMISS_DISTANCE || g.vy > DISMISS_VELOCITY) {
            void hapticFeedback('light');
            dismiss();
            return;
          }
          Animated.spring(translateY, { toValue: 0, useNativeDriver: true, damping: 22, stiffness: 300 }).start();
        },
      }),
    [dismiss, translateY]
  );

  if (!visible) return null;

  const onScrollEnd = (e: NativeSyntheticEvent<NativeScrollEvent>) => {
    const x = e.nativeEvent.contentOffset.x;
    const next = Math.round(x / (CARD_W + CARD_GAP));
    if (next !== index) {
      setIndex(Math.max(0, Math.min(list.length - 1, next)));
      void hapticFeedback('light');
    }
  };

  const backdropOpacity = translateY.interpolate({
    inputRange: [0, SCREEN_H * 0.6],
    outputRange: [1, 0],
    extrapolate: 'clamp',
  });

  return (
    <Modal visible={visible} transparent animationType="none" onRequestClose={dismiss} statusBarTranslucent>
      <View style={styles.root}>
        <Animated.View style={[StyleSheet.absoluteFill, styles.backdrop, { opacity: backdropOpacity }]}>
          <Pressable style={StyleSheet.absoluteFill} onPress={dismiss} accessibilityLabel="Close vehicle info" />
        </Animated.View>

        <Animated.View
          style={[
            styles.sheet,
            {
              backgroundColor: panel,
              borderColor: `${accent}40`,
              paddingBottom: Math.max(18, insets.bottom + 12),
              transform: [{ translateY }],
            },
          ]}
        >
          <LinearGradient
            colors={[`${accent}22`, `${accent}00`]}
            style={styles.sheetGlow}
            pointerEvents="none"
          />

          <View {...panResponder.panHandlers}>
            <View style={styles.handleRow}>
              <View style={[styles.handle, { backgroundColor: `${accent}66` }]} />
            </View>

            <View style={styles.header}>
              <View style={[styles.headerIcon, { backgroundColor: `${accent}22`, borderColor: `${accent}45` }]}>
                <Ionicons name="car-sport" size={18} color={accent} />
              </View>
              <View style={styles.headerCopy}>
                <Text style={[styles.headerTitle, { color: textMain }]}>Vehicle info</Text>
                <Text style={[styles.headerSub, { color: textMuted }]}>
                  {list.length <= 1
                    ? '1 vehicle on this job'
                    : `${list.length} vehicles on this job · swipe to browse`}
                </Text>
              </View>
              <Pressable
                onPress={dismiss}
                hitSlop={12}
                style={[styles.closeBtn, { backgroundColor: elevated }]}
                accessibilityLabel="Close"
              >
                <Ionicons name="close" size={18} color={textMuted} />
              </Pressable>
            </View>
          </View>

          {list.length === 0 ? (
            <View style={[styles.empty, { backgroundColor: elevated, borderColor: `${accent}22` }]}>
              <View style={[styles.emptyIcon, { backgroundColor: `${accent}18` }]}>
                <Ionicons name="car-outline" size={30} color={accent} />
              </View>
              <Text style={[styles.emptyTitle, { color: textMain }]}>No vehicle details yet</Text>
              <Text style={[styles.emptyText, { color: textMuted }]}>
                Ask the customer in chat if you need the make or registration.
              </Text>
            </View>
          ) : (
            <>
              <FlatList
                ref={listRef}
                data={list}
                keyExtractor={(item) => item.id}
                horizontal
                pagingEnabled={false}
                decelerationRate="fast"
                snapToInterval={CARD_W + CARD_GAP}
                snapToAlignment="start"
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={[
                  styles.galleryContent,
                  list.length === 1 && { paddingHorizontal: (SCREEN_W - CARD_W) / 2 },
                ]}
                onMomentumScrollEnd={onScrollEnd}
                renderItem={({ item, index: i }) => {
                  const photo = resolveCustomerProfilePictureUrl(item.photo) || item.photo || null;
                  const active = i === index;
                  const swatch = swatchForColour(item.colour);
                  return (
                    <View
                      style={[
                        styles.vehicleCard,
                        {
                          width: CARD_W,
                          borderColor: active ? `${accent}70` : `${accent}24`,
                          backgroundColor: elevated,
                          opacity: active || list.length === 1 ? 1 : 0.72,
                        },
                      ]}
                    >
                      <View style={styles.photoWrap}>
                        {photo ? (
                          <Image source={{ uri: photo }} style={styles.photo} resizeMode="cover" />
                        ) : (
                          <LinearGradient
                            colors={[`${accent}50`, `${accent}14`, 'rgba(10,25,41,0.95)']}
                            style={styles.photoFallback}
                          >
                            <Ionicons name="car-sport" size={58} color="rgba(248,250,252,0.92)" />
                            <Text style={styles.photoFallbackText}>No photo added</Text>
                          </LinearGradient>
                        )}
                        <LinearGradient
                          colors={['rgba(2,10,22,0)', 'rgba(2,10,22,0.85)']}
                          style={styles.photoShade}
                          pointerEvents="none"
                        />
                        {list.length > 1 ? (
                          <View style={styles.counter}>
                            <Text style={styles.counterText}>
                              {i + 1} / {list.length}
                            </Text>
                          </View>
                        ) : null}
                        <View style={styles.photoCaption}>
                          <Text style={styles.vehicleTitle} numberOfLines={2}>
                            {titleForVehicle(item)}
                          </Text>
                        </View>
                      </View>

                      <View style={styles.cardBody}>
                        {item.registration ? <NumberPlate registration={item.registration} /> : null}
                        <View style={styles.tiles}>
                          {item.make ? (
                            <DetailTile
                              icon="ribbon-outline"
                              label="MAKE"
                              value={item.make}
                              accent={accent}
                              textMain={textMain}
                              textMuted={textMuted}
                              background={isLight ? 'rgba(255,255,255,0.5)' : 'rgba(255,255,255,0.04)'}
                            />
                          ) : null}
                          {item.model ? (
                            <DetailTile
                              icon="car-outline"
                              label="MODEL"
                              value={item.model}
                              accent={accent}
                              textMain={textMain}
                              textMuted={textMuted}
                              background={isLight ? 'rgba(255,255,255,0.5)' : 'rgba(255,255,255,0.04)'}
                            />
                          ) : null}
                          {item.colour ? (
                            <DetailTile
                              icon="color-palette-outline"
                              label="COLOUR"
                              value={item.colour}
                              swatch={swatch}
                              accent={accent}
                              textMain={textMain}
                              textMuted={textMuted}
                              background={isLight ? 'rgba(255,255,255,0.5)' : 'rgba(255,255,255,0.04)'}
                            />
                          ) : null}
                        </View>
                      </View>
                    </View>
                  );
                }}
              />

              {list.length > 1 ? (
                <View style={styles.dots}>
                  {list.map((v, i) => (
                    <Pressable
                      key={v.id}
                      hitSlop={8}
                      onPress={() => {
                        listRef.current?.scrollToOffset({ offset: i * (CARD_W + CARD_GAP), animated: true });
                        setIndex(i);
                        void hapticFeedback('light');
                      }}
                      style={[
                        styles.dot,
                        {
                          backgroundColor: i === index ? accent : `${accent}35`,
                          width: i === index ? 20 : 8,
                        },
                      ]}
                    />
                  ))}
                </View>
              ) : null}
            </>
          )}

          <Pressable
            onPress={dismiss}
            style={({ pressed }) => [
              styles.doneBtn,
              { backgroundColor: accent, opacity: pressed ? 0.85 : 1 },
            ]}
            accessibilityRole="button"
          >
            <Text style={styles.doneText}>Done</Text>
          </Pressable>
        </Animated.View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  backdrop: {
    backgroundColor: 'rgba(2, 10, 22, 0.72)',
  },
  sheet: {
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderWidth: 1,
    borderBottomWidth: 0,
    paddingTop: 8,
    maxHeight: '90%',
    overflow: 'hidden',
  },
  sheetGlow: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 140,
  },
  handleRow: { alignItems: 'center', paddingTop: 2, paddingBottom: 10 },
  handle: { width: 44, height: 5, borderRadius: 3 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 18,
    marginBottom: 14,
  },
  headerIcon: {
    width: 40,
    height: 40,
    borderRadius: 14,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerCopy: { flex: 1, minWidth: 0 },
  headerTitle: { fontSize: 20, fontWeight: '900', letterSpacing: -0.3 },
  headerSub: { fontSize: 12, fontWeight: '600', marginTop: 2 },
  closeBtn: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
  },
  galleryContent: {
    paddingHorizontal: 18,
    gap: CARD_GAP,
    paddingBottom: 6,
  },
  vehicleCard: {
    borderRadius: 22,
    borderWidth: 1.5,
    overflow: 'hidden',
  },
  photoWrap: {
    width: '100%',
    height: 200,
    backgroundColor: 'rgba(0,0,0,0.25)',
  },
  photo: { width: '100%', height: '100%' },
  photoFallback: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingBottom: 30,
  },
  photoFallbackText: {
    color: 'rgba(248,250,252,0.75)',
    fontSize: 12,
    fontWeight: '700',
  },
  photoShade: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    height: 96,
  },
  photoCaption: {
    position: 'absolute',
    left: 14,
    right: 14,
    bottom: 12,
  },
  vehicleTitle: {
    color: '#F8FAFC',
    fontSize: 22,
    fontWeight: '900',
    letterSpacing: -0.4,
    textShadowColor: 'rgba(0,0,0,0.45)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 4,
  },
  counter: {
    position: 'absolute',
    top: 12,
    right: 12,
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 5,
    backgroundColor: 'rgba(2,10,22,0.6)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
  },
  counterText: { color: '#F8FAFC', fontSize: 12, fontWeight: '800', fontVariant: ['tabular-nums'] },
  cardBody: {
    padding: 14,
    gap: 12,
  },
  plate: {
    flexDirection: 'row',
    alignSelf: 'flex-start',
    alignItems: 'stretch',
    backgroundColor: '#FACC15',
    borderRadius: 8,
    borderWidth: 1.5,
    borderColor: '#111827',
    overflow: 'hidden',
  },
  plateBand: {
    backgroundColor: '#1D4ED8',
    paddingHorizontal: 6,
    justifyContent: 'flex-end',
    paddingBottom: 4,
  },
  plateBandText: { color: '#FACC15', fontSize: 9, fontWeight: '900' },
  plateText: {
    color: '#111827',
    fontSize: 22,
    fontWeight: '900',
    letterSpacing: 2,
    paddingHorizontal: 14,
    paddingVertical: 5,
    fontVariant: ['tabular-nums'],
  },
  tiles: {
    flexDirection: 'row',
    gap: 8,
  },
  tile: {
    flex: 1,
    minWidth: 0,
    borderRadius: 14,
    borderWidth: 1,
    paddingVertical: 9,
    paddingHorizontal: 10,
    gap: 4,
  },
  tileLabelRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  tileLabel: { fontSize: 9, fontWeight: '800', letterSpacing: 0.8 },
  tileValueRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  tileValue: { fontSize: 14, fontWeight: '800', flexShrink: 1 },
  swatch: {
    width: 12,
    height: 12,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.5)',
  },
  dots: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 6,
    paddingTop: 12,
  },
  dot: {
    height: 8,
    borderRadius: 999,
  },
  empty: {
    marginHorizontal: 18,
    borderRadius: 20,
    borderWidth: 1,
    paddingVertical: 28,
    paddingHorizontal: 24,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  emptyIcon: {
    width: 60,
    height: 60,
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
  },
  emptyTitle: { fontSize: 16, fontWeight: '800' },
  emptyText: { fontSize: 13, fontWeight: '600', textAlign: 'center', lineHeight: 18 },
  doneBtn: {
    marginHorizontal: 18,
    marginTop: 16,
    minHeight: 50,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  doneText: { color: '#0A1929', fontSize: 16, fontWeight: '800' },
});
