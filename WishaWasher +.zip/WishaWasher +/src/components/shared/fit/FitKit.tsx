/**
 * Building blocks for "no vertical scroll" screens: lists page sideways in
 * chunks sized to the space available, filters use a sliding segmented pill.
 */
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  LayoutChangeEvent,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
  type StyleProp,
  type TextStyle,
  type ViewStyle,
} from 'react-native';
import Reanimated, {
  Easing,
  Extrapolation,
  FadeInDown,
  FadeOut,
  LinearTransition,
  interpolate,
  useAnimatedRef,
  useAnimatedScrollHandler,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSpring,
  withTiming,
  type SharedValue,
} from 'react-native-reanimated';
import { SymbolView, type SFSymbol } from 'expo-symbols';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ChromeGlyph } from '../ChromeGlyph';
import type { IconGlyphName } from '../iconGlyphTypes';
import { hapticFeedback } from '../../../services/HapticFeedbackService';
import { useValeterHeaderContentOffset } from '../../valeter/ValeterScreenHeader';
import { VALETER_DOCK_ROW_HEIGHT } from '../../valeter/ValeterDashboardFloatingDock';

/** Top / bottom padding that keeps content clear of the valeter header and global dock. */
export function useValeterFitInsets(gap = 8) {
  const insets = useSafeAreaInsets();
  const top = useValeterHeaderContentOffset(gap);
  const bottom = VALETER_DOCK_ROW_HEIGHT + Math.max(insets.bottom, 8) + 10;
  return { top, bottom };
}

/** SF Symbol on iOS, Ionicons everywhere else. */
export function SymbolGlyph({
  sf,
  ion,
  size = 20,
  color = '#F9FAFB',
  weight,
}: Readonly<{
  sf: SFSymbol;
  ion: IconGlyphName;
  size?: number;
  color?: string;
  weight?: 'regular' | 'medium' | 'semibold' | 'bold';
}>) {
  if (Platform.OS !== 'ios') return <ChromeGlyph name={ion} size={size} color={color} />;
  return (
    <SymbolView
      name={sf}
      size={size}
      tintColor={color}
      weight={weight}
      type="hierarchical"
      fallback={<ChromeGlyph name={ion} size={size} color={color} />}
    />
  );
}

/** Pressable that springs down slightly while held. */
export function PressableScale({
  children,
  onPress,
  onLongPress,
  disabled,
  style,
  fill = false,
  haptic = true,
  scaleTo = 0.96,
  accessibilityLabel,
  accessibilityRole = 'button',
}: Readonly<{
  children: React.ReactNode;
  onPress?: () => void;
  onLongPress?: () => void;
  disabled?: boolean;
  style?: StyleProp<ViewStyle>;
  /** Stretch to fill the parent (fixed-height list rows / grid cells). */
  fill?: boolean;
  haptic?: boolean;
  scaleTo?: number;
  accessibilityLabel?: string;
  accessibilityRole?: 'button' | 'tab' | 'link';
}>) {
  const scale = useSharedValue(1);
  const animatedStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  return (
    <Pressable
      onPress={() => {
        if (haptic) void hapticFeedback('light');
        onPress?.();
      }}
      onLongPress={onLongPress}
      disabled={disabled}
      style={fill ? styles.fill : undefined}
      onPressIn={() => {
        scale.value = withSpring(scaleTo, { damping: 18, stiffness: 420 });
      }}
      onPressOut={() => {
        scale.value = withSpring(1, { damping: 14, stiffness: 320 });
      }}
      accessibilityRole={accessibilityRole}
      accessibilityLabel={accessibilityLabel}
    >
      <Reanimated.View style={[style, animatedStyle, disabled && styles.disabled]}>{children}</Reanimated.View>
    </Pressable>
  );
}

/** Number that eases from its previous value to the new one. */
export function CountUpText({
  value,
  style,
  format = (n) => Math.round(n).toLocaleString(),
  duration = 700,
}: Readonly<{
  value: number;
  style?: StyleProp<TextStyle>;
  format?: (n: number) => string;
  duration?: number;
}>) {
  const [shown, setShown] = useState(0);
  const fromRef = useRef(0);
  useEffect(() => {
    const from = fromRef.current;
    const start = Date.now();
    let frame = 0;
    const tick = () => {
      const t = Math.min(1, (Date.now() - start) / duration);
      const eased = 1 - Math.pow(1 - t, 3);
      const next = from + (value - from) * eased;
      setShown(next);
      if (t < 1) frame = requestAnimationFrame(tick);
      else fromRef.current = value;
    };
    frame = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(frame);
      fromRef.current = value;
    };
  }, [value, duration]);
  return <Text style={style}>{format(shown)}</Text>;
}

export type Segment<K extends string> = Readonly<{
  key: K;
  label: string;
  icon?: IconGlyphName;
  count?: number;
}>;

/** Segmented control with a spring-sliding selection pill. */
export function SegmentedPills<K extends string>({
  segments,
  value,
  onChange,
  accent,
  height = 40,
  style,
}: Readonly<{
  segments: readonly Segment<K>[];
  value: K;
  onChange: (key: K) => void;
  accent: string;
  height?: number;
  style?: StyleProp<ViewStyle>;
}>) {
  const [width, setWidth] = useState(0);
  const pad = 3;
  const slot = width > 0 ? (width - pad * 2) / Math.max(segments.length, 1) : 0;
  const index = Math.max(0, segments.findIndex((s) => s.key === value));
  const x = useSharedValue(0);

  useEffect(() => {
    x.value = withSpring(index * slot, { damping: 20, stiffness: 260, mass: 0.7 });
  }, [index, slot, x]);

  const pillStyle = useAnimatedStyle(() => ({ transform: [{ translateX: x.value }] }));

  return (
    <View
      style={[styles.segTrack, { height, borderRadius: height / 2 }, style]}
      onLayout={(e) => setWidth(e.nativeEvent.layout.width)}
    >
      {slot > 0 ? (
        <Reanimated.View
          pointerEvents="none"
          style={[
            styles.segPill,
            {
              left: pad,
              top: pad,
              width: slot,
              height: height - pad * 2,
              borderRadius: (height - pad * 2) / 2,
              backgroundColor: `${accent}2E`,
              borderColor: `${accent}66`,
            },
            pillStyle,
          ]}
        />
      ) : null}
      {segments.map((s) => {
        const active = s.key === value;
        const color = active ? accent : 'rgba(241,245,249,0.6)';
        return (
          <Pressable
            key={s.key}
            style={styles.segItem}
            onPress={() => {
              if (active) return;
              void hapticFeedback('light');
              onChange(s.key);
            }}
            accessibilityRole="tab"
            accessibilityState={{ selected: active }}
            accessibilityLabel={s.label}
          >
            {s.icon ? <ChromeGlyph name={s.icon} size={14} color={color} /> : null}
            <Text style={[styles.segLabel, { color }, active && styles.segLabelActive]} numberOfLines={1}>
              {s.label}
            </Text>
            {s.count != null && s.count > 0 ? (
              <View style={[styles.segCount, { backgroundColor: active ? accent : 'rgba(241,245,249,0.16)' }]}>
                <Text style={[styles.segCountText, { color: active ? '#0A1929' : '#F1F5F9' }]}>
                  {s.count > 99 ? '99+' : s.count}
                </Text>
              </View>
            ) : null}
          </Pressable>
        );
      })}
    </View>
  );
}

/** Small dot with an expanding ring — marks live / urgent items. */
export function PulseDot({ color, size = 8 }: Readonly<{ color: string; size?: number }>) {
  const t = useSharedValue(0);
  useEffect(() => {
    t.value = withRepeat(withTiming(1, { duration: 1400, easing: Easing.out(Easing.quad) }), -1, false);
  }, [t]);
  const ring = useAnimatedStyle(() => ({
    opacity: 0.6 * (1 - t.value),
    transform: [{ scale: 1 + t.value * 1.6 }],
  }));
  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <Reanimated.View
        style={[{ position: 'absolute', width: size, height: size, borderRadius: size / 2, backgroundColor: color }, ring]}
      />
      <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: color }} />
    </View>
  );
}

/** Centred empty state with a softly breathing icon orb. */
export function BreathingEmpty({
  accent,
  sf,
  ion,
  title,
  subtitle,
  actionLabel,
  onAction,
}: Readonly<{
  accent: string;
  sf: SFSymbol;
  ion: IconGlyphName;
  title: string;
  subtitle?: string;
  actionLabel?: string;
  onAction?: () => void;
}>) {
  const t = useSharedValue(0);
  useEffect(() => {
    t.value = withRepeat(withTiming(1, { duration: 2200, easing: Easing.inOut(Easing.sin) }), -1, true);
  }, [t]);
  const glow = useAnimatedStyle(() => ({
    opacity: 0.25 + t.value * 0.35,
    transform: [{ scale: 0.9 + t.value * 0.25 }],
  }));
  const orb = useAnimatedStyle(() => ({ transform: [{ translateY: -4 * t.value }] }));
  return (
    <Reanimated.View entering={FadeInDown.springify().damping(18)} style={styles.emptyWrap}>
      <View style={styles.emptyOrbWrap}>
        <Reanimated.View style={[styles.emptyGlow, { backgroundColor: accent }, glow]} />
        <Reanimated.View style={[styles.emptyOrb, { borderColor: `${accent}55`, backgroundColor: `${accent}1F` }, orb]}>
          <SymbolGlyph sf={sf} ion={ion} size={34} color={accent} />
        </Reanimated.View>
      </View>
      <Text style={styles.emptyTitle}>{title}</Text>
      {subtitle ? <Text style={styles.emptySub}>{subtitle}</Text> : null}
      {actionLabel && onAction ? (
        <PressableScale onPress={onAction} style={[styles.emptyBtn, { backgroundColor: accent }]}>
          <Text style={styles.emptyBtnText}>{actionLabel}</Text>
        </PressableScale>
      ) : null}
    </Reanimated.View>
  );
}

function PageDot({
  index,
  scrollX,
  pageWidth,
  accent,
}: Readonly<{ index: number; scrollX: SharedValue<number>; pageWidth: number; accent: string }>) {
  const style = useAnimatedStyle(() => {
    const pos = pageWidth > 0 ? scrollX.value / pageWidth : 0;
    const d = Math.abs(pos - index);
    return {
      width: interpolate(d, [0, 1], [18, 6], Extrapolation.CLAMP),
      opacity: interpolate(d, [0, 1], [1, 0.35], Extrapolation.CLAMP),
    };
  });
  return <Reanimated.View style={[styles.dot, { backgroundColor: accent }, style]} />;
}

const DOTS_HEIGHT = 20;

/**
 * Fills its parent, works out how many fixed-height rows fit, and pages the
 * rest sideways — so the screen itself never scrolls vertically.
 */
export function FitPager<T>({
  items,
  rowHeight,
  gap = 10,
  accent,
  keyExtractor,
  renderItem,
  empty,
  resetKey,
  style,
}: Readonly<{
  items: readonly T[];
  rowHeight: number;
  gap?: number;
  accent: string;
  keyExtractor: (item: T) => string;
  renderItem: (item: T, index: number) => React.ReactNode;
  empty?: React.ReactNode;
  resetKey?: string;
  style?: StyleProp<ViewStyle>;
}>) {
  const [size, setSize] = useState({ w: 0, h: 0 });
  const scrollX = useSharedValue(0);
  const scrollRef = useAnimatedRef<Reanimated.ScrollView>();

  const onLayout = useCallback((e: LayoutChangeEvent) => {
    const { width, height } = e.nativeEvent.layout;
    setSize((prev) =>
      Math.abs(prev.w - width) < 1 && Math.abs(prev.h - height) < 1 ? prev : { w: width, h: height }
    );
  }, []);

  const perPage = useMemo(() => {
    if (size.h <= 0) return 0;
    const fitsAll = Math.floor((size.h + gap) / (rowHeight + gap));
    if (items.length <= fitsAll) return Math.max(1, fitsAll);
    return Math.max(1, Math.floor((size.h - DOTS_HEIGHT + gap) / (rowHeight + gap)));
  }, [size.h, gap, rowHeight, items.length]);

  const pages = useMemo(() => {
    if (perPage <= 0) return [] as T[][];
    const out: T[][] = [];
    for (let i = 0; i < items.length; i += perPage) out.push(items.slice(i, i + perPage) as T[]);
    return out;
  }, [items, perPage]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ x: 0, animated: false });
    scrollX.value = 0;
  }, [resetKey, scrollRef, scrollX]);

  const onScroll = useAnimatedScrollHandler((e) => {
    scrollX.value = e.contentOffset.x;
  });

  const pageKeys = pages.map((page) => `page-${keyExtractor(page[0])}`);
  const ready = items.length > 0 && size.w > 0 && perPage > 0;

  return (
    <View style={[styles.pagerRoot, style]} onLayout={onLayout}>
      {items.length === 0 ? (empty ?? null) : null}
      {ready ? (
        <>
          <Reanimated.ScrollView
            ref={scrollRef}
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            onScroll={onScroll}
            scrollEventThrottle={16}
            style={styles.pagerScroll}
          >
            {pages.map((page, p) => (
              <View key={pageKeys[p]} style={{ width: size.w, gap }}>
                {page.map((item, i) => (
                  <Reanimated.View
                    key={keyExtractor(item)}
                    entering={FadeInDown.delay(Math.min(i, 8) * 45).springify().damping(18)}
                    exiting={FadeOut.duration(160)}
                    layout={LinearTransition.springify().damping(20)}
                    style={{ height: rowHeight }}
                  >
                    {renderItem(item, p * perPage + i)}
                  </Reanimated.View>
                ))}
              </View>
            ))}
          </Reanimated.ScrollView>
          {pages.length > 1 ? (
            <View style={styles.dotsRow} pointerEvents="none">
              {pageKeys.map((key, i) => (
                <PageDot key={`dot-${key}`} index={i} scrollX={scrollX} pageWidth={size.w} accent={accent} />
              ))}
            </View>
          ) : null}
        </>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  disabled: { opacity: 0.5 },
  fill: { flex: 1 },
  segTrack: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 3,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  segPill: {
    position: 'absolute',
    borderWidth: 1,
  },
  segItem: {
    flex: 1,
    height: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 5,
    paddingHorizontal: 4,
  },
  segLabel: { fontSize: 13, fontWeight: '600', letterSpacing: 0.1 },
  segLabelActive: { fontWeight: '800' },
  segCount: {
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    paddingHorizontal: 5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  segCountText: { fontSize: 10, fontWeight: '800' },
  pagerRoot: { flex: 1, minHeight: 0 },
  pagerScroll: { flex: 1 },
  dotsRow: {
    height: DOTS_HEIGHT,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 5,
  },
  dot: { height: 6, borderRadius: 3 },
  emptyWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 32, gap: 10 },
  emptyOrbWrap: { width: 120, height: 120, alignItems: 'center', justifyContent: 'center', marginBottom: 6 },
  emptyGlow: { position: 'absolute', width: 120, height: 120, borderRadius: 60 },
  emptyOrb: {
    width: 84,
    height: 84,
    borderRadius: 42,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyTitle: { color: '#F8FAFC', fontSize: 20, fontWeight: '800', letterSpacing: -0.3, textAlign: 'center' },
  emptySub: { color: 'rgba(203,213,225,0.8)', fontSize: 14, lineHeight: 20, textAlign: 'center' },
  emptyBtn: { marginTop: 8, paddingHorizontal: 22, paddingVertical: 12, borderRadius: 999 },
  emptyBtnText: { color: '#0A1929', fontSize: 15, fontWeight: '800' },
});
