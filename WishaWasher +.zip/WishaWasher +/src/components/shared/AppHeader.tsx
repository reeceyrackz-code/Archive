import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  StatusBar,
  Image,
  Animated,
  type LayoutChangeEvent,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ChromeGlyph as Ionicons } from './ChromeGlyph';
import { router, usePathname } from 'expo-router';
import { colors } from '../../constants/colors';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { AccountType } from '../../constants/accountThemes';
import { useAccountTheme } from './AccountThemeProvider';
import { hasValeterMapHomeNavigation } from '../../utils/valeterNavigation';
import ValeterDashboardChrome from '../valeter/ValeterDashboardChrome';
import GlassSurface from './GlassSurface';

/** Floating glass card geometry (shared with the valeter map header). */
const CARD_GAP_TOP = 6;
const CARD_MARGIN_H = 12;
const CARD_RADIUS = 24;
const CARD_H = 60;
const DASHBOARD_CARD_PAD_V = 10;
const BTN = 40;

// Header content heights (not including safe area or padding)
export const HEADER_CONTENT_HEIGHT = CARD_H;
export const DASHBOARD_HEADER_CONTENT_HEIGHT = 88;
// Total header heights below the safe area, including the gap under the card.
export const HEADER_HEIGHT = CARD_GAP_TOP + CARD_H + 14; // = 80
export const DASHBOARD_HEADER_HEIGHT =
  CARD_GAP_TOP + DASHBOARD_HEADER_CONTENT_HEIGHT + DASHBOARD_CARD_PAD_V * 2 + 10; // = 124

/** Total dashboard header height from screen top (safe area + chrome). */
export const dashboardHeaderTotalHeight = (safeAreaTop: number) => safeAreaTop + DASHBOARD_HEADER_HEIGHT;

/** Total default header height from screen top (safe area + chrome). */
export const headerTotalHeight = (safeAreaTop: number) => safeAreaTop + HEADER_HEIGHT;

// Padding below header chrome — add insets.top in scroll content for flush-top screens.
export const HEADER_CONTENT_GAP = 16;
export const HEADER_CONTENT_OFFSET = DASHBOARD_HEADER_HEIGHT + 40;
export const DASHBOARD_HEADER_CONTENT_OFFSET = DASHBOARD_HEADER_HEIGHT + 40;

interface AppHeaderProps {
  title: string;
  subtitle?: string;
  onBack?: () => void;
  leftAction?: React.ReactNode;
  rightAction?: React.ReactNode;
  variant?: 'default' | 'dashboard';
  /** Kept for callers; every header now renders as the floating glass card. */
  fullWidth?: boolean;
  /** Kept for callers; the card always sits just below the safe area. */
  flushTop?: boolean;
  dashboardFlat?: boolean;
  dashboardInlineRightAction?: boolean;
  accountType?: AccountType;
  showBack?: boolean;
  points?: number;
  businessName?: string;
  businessAddress?: string;
  businessRating?: number;
  showOnlineStatus?: boolean;
  onlineStatusAnim?: Animated.Value;
  profilePicture?: string | null;
  notificationCount?: number;
  onNotificationPress?: () => void;
  todayRevenue?: number;
  todayJobs?: number;
  lastJob?: string | null;
  isOnline?: boolean;
  AnimatedCounter?: React.ComponentType<{ value: number; style?: any }>;
  onSubtitlePress?: () => void;
  scrollY?: Animated.Value;
  enableScrollAnimation?: boolean;
}

/** `#RRGGBB` + alpha; anything else falls back to the default navy. */
function withAlpha(color: string | undefined, alpha: number): string {
  const a = Math.round(Math.max(0, Math.min(1, alpha)) * 255)
    .toString(16)
    .padStart(2, '0');
  if (color && /^#[0-9a-f]{6}$/i.test(color)) return `${color}${a}`;
  return `rgba(6,14,24,${alpha})`;
}

function HeaderBackButton({ onPress, iconColor }: Readonly<{ onPress: () => void; iconColor: string }>) {
  return (
    <TouchableOpacity onPress={onPress} activeOpacity={0.8} hitSlop={8} accessibilityRole="button" accessibilityLabel="Back">
      <GlassSurface style={styles.glassBtn} interactive fallbackColor="rgba(10,25,41,0.6)">
        <Ionicons name="chevron-back" size={20} color={iconColor} />
      </GlassSurface>
    </TouchableOpacity>
  );
}

function HeaderAvatar({
  uri,
  accent,
  onPress,
  notificationCount,
}: Readonly<{
  uri: string;
  accent: string;
  onPress: () => void;
  notificationCount?: number;
}>) {
  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={0.85}
      style={[styles.avatarRing, { borderColor: `${accent}AA` }]}
      accessibilityRole="button"
      accessibilityLabel={
        notificationCount && notificationCount > 0 ? `${notificationCount} notifications` : 'Profile'
      }
    >
      <View style={styles.avatarInner}>
        <Image source={{ uri }} style={styles.avatarImg} resizeMode="cover" />
      </View>
      {notificationCount !== undefined && notificationCount > 0 ? (
        <View style={styles.badge}>
          <Text style={styles.badgeText}>{notificationCount > 99 ? '99+' : notificationCount}</Text>
        </View>
      ) : null}
    </TouchableOpacity>
  );
}

export default function AppHeader({
  title,
  subtitle,
  onBack,
  leftAction,
  rightAction,
  variant = 'default',
  fullWidth: _fullWidth,
  flushTop: _flushTop,
  dashboardFlat: _dashboardFlat,
  dashboardInlineRightAction: _dashboardInlineRightAction,
  accountType: _accountType,
  showBack = true,
  points,
  businessName,
  businessAddress,
  businessRating: _businessRating,
  showOnlineStatus: _showOnlineStatus,
  onlineStatusAnim,
  profilePicture,
  notificationCount,
  onNotificationPress,
  todayRevenue: _todayRevenue,
  todayJobs: _todayJobs,
  lastJob: _lastJob,
  isOnline,
  AnimatedCounter: _AnimatedCounter,
  onSubtitlePress,
  scrollY: _scrollY,
  enableScrollAnimation: _enableScrollAnimation,
}: Readonly<AppHeaderProps>) {
  const insets = useSafeAreaInsets();
  const pathname = usePathname() ?? '';
  const effectiveShowBack = showBack && !hasValeterMapHomeNavigation(pathname);
  const { theme } = useAccountTheme();

  const accent = theme.primary || colors.navActive;
  const textMain = theme.textPrimary ?? '#F1F5F9';
  const textMuted = theme.textSecondary ?? 'rgba(241,245,249,0.6)';
  const bg = theme.headerBackground || theme.background || ['#0A1929', '#0F2236'];
  const chromeGradient: readonly [string, string] = [bg[0], bg[1] ?? bg[0]];
  const isDashboard = variant === 'dashboard';

  const handleBack = async () => {
    await hapticFeedback('light');
    if (onBack) {
      onBack();
      return;
    }
    if ((router as any).canGoBack?.()) {
      router.back();
    } else {
      router.replace('/');
    }
  };

  const leftSlot = (() => {
    if (leftAction) return leftAction;
    if (isDashboard && profilePicture) {
      return (
        <HeaderAvatar
          uri={profilePicture}
          accent={accent}
          onPress={onNotificationPress || handleBack}
          notificationCount={notificationCount}
        />
      );
    }
    if (effectiveShowBack) {
      return <HeaderBackButton onPress={handleBack} iconColor={textMain} />;
    }
    return null;
  })();

  const subtitleText = subtitle || (isDashboard ? businessAddress : undefined);

  const subtitleNode = subtitleText ? (
    <TouchableOpacity
      onPress={onSubtitlePress}
      disabled={!onSubtitlePress}
      activeOpacity={0.7}
      hitSlop={{ top: 6, bottom: 6 }}
      style={[styles.subtitleRow, isDashboard && styles.centerSelf]}
    >
      <Text style={[styles.subtitle, { color: accent }]} numberOfLines={1}>
        {subtitleText}
      </Text>
      {onSubtitlePress ? <Ionicons name="chevron-down" size={11} color={accent} /> : null}
    </TouchableOpacity>
  ) : null;

  const hasRight = points !== undefined || (!isDashboard && !!profilePicture) || rightAction != null;
  const rightSlot = (
    <>
      {points !== undefined ? (
        <View style={styles.pointsBadge}>
          <Ionicons name="trophy" size={13} color="#FFD700" />
          <Text style={styles.pointsText}>{points}</Text>
        </View>
      ) : null}
      {!isDashboard && profilePicture ? (
        <HeaderAvatar
          uri={profilePicture}
          accent={accent}
          onPress={onNotificationPress || handleBack}
          notificationCount={notificationCount}
        />
      ) : null}
      {rightAction ?? null}
    </>
  );

  if (!isDashboard) {
    return (
      <FloatingHeaderBar
        title={title}
        subtitleNode={subtitleNode}
        leftSlot={leftSlot}
        rightSlot={hasRight ? rightSlot : null}
        textMain={textMain}
        fadeBase={bg[0]}
      />
    );
  }

  return (
    <>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />
      <View style={[styles.wrapper, { paddingTop: insets.top + CARD_GAP_TOP }]} pointerEvents="box-none">
        <LinearGradient
          pointerEvents="none"
          colors={['rgba(6,14,24,0.72)', 'rgba(6,14,24,0.28)', 'transparent']}
          style={[styles.statusScrim, { height: insets.top + CARD_H * 0.9 }]}
        />

        <View style={[styles.card, { minHeight: DASHBOARD_HEADER_CONTENT_HEIGHT + DASHBOARD_CARD_PAD_V * 2 }]}>
          <View style={styles.chromeClip} pointerEvents="none">
            <ValeterDashboardChrome accent={accent} headerGradient={chromeGradient} />
            <LinearGradient colors={['rgba(255,255,255,0.10)', 'transparent']} style={styles.cardSheen} />
          </View>

          <View style={[styles.row, styles.dashboardRow]}>
            <View style={[styles.side, styles.sideLeft]}>{leftSlot}</View>

            <View style={styles.dashboardTitleCol} pointerEvents="box-none">
              <Text style={[styles.kicker, styles.centerText, { color: textMuted }]} numberOfLines={1}>
                Overview
              </Text>
              <Text style={[styles.dashboardTitle, { color: textMain }]} numberOfLines={1}>
                {title || businessName || ' '}
              </Text>
              {subtitleNode}
              {isOnline === undefined ? null : <OnlineStatusChip isOnline={isOnline} anim={onlineStatusAnim} />}
            </View>

            <View style={[styles.side, styles.sideRight]}>{rightSlot}</View>
          </View>
        </View>
      </View>
    </>
  );
}

/** Standard page header: floating glass back / action buttons over a theme-coloured fade. */
function FloatingHeaderBar({
  title,
  subtitleNode,
  leftSlot,
  rightSlot,
  textMain,
  fadeBase,
}: Readonly<{
  title: string;
  subtitleNode: React.ReactNode;
  leftSlot: React.ReactNode;
  rightSlot: React.ReactNode;
  textMain: string;
  fadeBase: string | undefined;
}>) {
  const insets = useSafeAreaInsets();
  const [sideW, setSideW] = useState({ left: 0, right: 0 });
  const measureSide = (side: 'left' | 'right') => (e: LayoutChangeEvent) => {
    const w = Math.round(e.nativeEvent.layout.width);
    setSideW((prev) => (prev[side] === w ? prev : { ...prev, [side]: w }));
  };
  const titlePad = Math.max(sideW.left, sideW.right) + 10;

  return (
    <>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />
      <View style={[styles.wrapper, { paddingTop: insets.top + CARD_GAP_TOP }]} pointerEvents="box-none">
        <LinearGradient
          pointerEvents="none"
          colors={[withAlpha(fadeBase, 0.96), withAlpha(fadeBase, 0.82), withAlpha(fadeBase, 0)]}
          locations={[0, 0.62, 1]}
          style={[styles.headerFade, { height: insets.top + HEADER_HEIGHT + 18 }]}
        />

        <View style={styles.bar} pointerEvents="box-none">
          <View style={[styles.titleWrap, { left: titlePad, right: titlePad }]} pointerEvents="box-none">
            <Text style={[styles.barTitle, { color: textMain }]} numberOfLines={1} ellipsizeMode="tail">
              {title || ' '}
            </Text>
            {subtitleNode ? <View style={styles.centerSelf}>{subtitleNode}</View> : null}
          </View>

          <View style={styles.barSide} onLayout={measureSide('left')} pointerEvents="box-none">
            {leftSlot}
          </View>
          <View style={styles.barSpacer} pointerEvents="none" />
          <View style={styles.barSide} onLayout={measureSide('right')} pointerEvents="box-none">
            {rightSlot ? (
              <GlassSurface style={styles.glassPill} fallbackColor="rgba(10,25,41,0.6)">
                {rightSlot}
              </GlassSurface>
            ) : null}
          </View>
        </View>
      </View>
    </>
  );
}

function OnlineStatusChip({ isOnline, anim }: Readonly<{ isOnline: boolean; anim?: Animated.Value }>) {
  const pulse = anim
    ? {
        transform: [{ scale: anim }],
        opacity: anim.interpolate({ inputRange: [1, 1.3], outputRange: [1, 0.4] }),
      }
    : null;
  return (
    <View
      style={[
        styles.statusChip,
        isOnline
          ? { backgroundColor: 'rgba(16,185,129,0.16)', borderColor: 'rgba(74,222,128,0.5)' }
          : { backgroundColor: 'rgba(248,113,113,0.14)', borderColor: 'rgba(248,113,113,0.5)' },
      ]}
    >
      <Animated.View style={[styles.statusDot, { backgroundColor: isOnline ? '#4ADE80' : '#F87171' }, pulse]} />
      <Text style={[styles.statusText, { color: isOnline ? '#BBF7D0' : '#FECACA' }]}>
        {isOnline ? 'Open for bookings' : 'Offline'}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    paddingHorizontal: CARD_MARGIN_H,
  },
  statusScrim: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
  },
  card: {
    borderRadius: CARD_RADIUS,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.32,
    shadowRadius: 18,
    elevation: 12,
  },
  chromeClip: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    borderRadius: CARD_RADIUS - 1,
    overflow: 'hidden',
  },
  cardSheen: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: CARD_H / 2,
  },
  row: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    gap: 10,
  },
  dashboardRow: {
    paddingVertical: DASHBOARD_CARD_PAD_V,
    gap: 6,
  },
  headerFade: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
  },
  bar: {
    height: CARD_H,
    flexDirection: 'row',
    alignItems: 'center',
  },
  barSide: {
    flexDirection: 'row',
    alignItems: 'center',
    flexShrink: 0,
  },
  barSpacer: {
    flex: 1,
  },
  titleWrap: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
  barTitle: {
    fontSize: 17,
    fontWeight: '800',
    letterSpacing: -0.3,
    textAlign: 'center',
    includeFontPadding: false,
  },
  glassBtn: {
    width: BTN + 4,
    height: BTN + 4,
    borderRadius: (BTN + 4) / 2,
    alignItems: 'center',
    justifyContent: 'center',
  },
  glassPill: {
    minWidth: BTN + 4,
    height: BTN + 4,
    borderRadius: (BTN + 4) / 2,
    paddingHorizontal: 2,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
  },
  subtitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    marginTop: 2,
    maxWidth: '100%',
  },
  centerSelf: {
    alignSelf: 'center',
  },
  subtitle: {
    fontSize: 11.5,
    fontWeight: '700',
    flexShrink: 1,
    includeFontPadding: false,
  },
  side: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  sideLeft: {
    justifyContent: 'flex-start',
  },
  sideRight: {
    justifyContent: 'flex-end',
  },
  dashboardTitleCol: {
    flex: 3,
    minWidth: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
  kicker: {
    fontSize: 9.5,
    fontWeight: '700',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  centerText: {
    textAlign: 'center',
  },
  dashboardTitle: {
    fontSize: 22,
    fontWeight: '900',
    letterSpacing: -0.5,
    textAlign: 'center',
    marginTop: 1,
  },
  avatarRing: {
    width: BTN + 2,
    height: BTN + 2,
    borderRadius: (BTN + 2) / 2,
    borderWidth: 2,
    padding: 2,
  },
  avatarInner: {
    flex: 1,
    borderRadius: BTN / 2,
    overflow: 'hidden',
  },
  avatarImg: {
    width: '100%',
    height: '100%',
  },
  badge: {
    position: 'absolute',
    top: -3,
    right: -3,
    minWidth: 17,
    height: 17,
    paddingHorizontal: 4,
    borderRadius: 9,
    backgroundColor: '#EF4444',
    borderWidth: 1.5,
    borderColor: '#0A1929',
    alignItems: 'center',
    justifyContent: 'center',
  },
  badgeText: {
    color: '#FFFFFF',
    fontSize: 9,
    fontWeight: '900',
  },
  pointsBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    height: 30,
    paddingHorizontal: 10,
    borderRadius: 15,
    backgroundColor: 'rgba(255,215,0,0.14)',
    borderWidth: 1,
    borderColor: 'rgba(255,215,0,0.35)',
  },
  pointsText: {
    color: '#FFD700',
    fontSize: 12,
    fontWeight: '800',
  },
  statusChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    marginTop: 5,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 999,
    borderWidth: 1,
  },
  statusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  statusText: {
    fontSize: 9.5,
    fontWeight: '900',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
});
