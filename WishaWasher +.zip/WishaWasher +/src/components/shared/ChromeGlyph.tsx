import React from 'react';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import type { StyleProp, TextStyle, ViewStyle } from 'react-native';
import type { IconGlyphName, IoniconName, MciName } from './iconGlyphTypes';

export type { IconGlyphName };

export type ChromeGlyphProps = {
  name: IconGlyphName;
  size?: number;
  color?: string;
  style?: StyleProp<ViewStyle | TextStyle>;
};

/**
 * Flat vector icon glyph. Previously rendered each glyph inside frosted "chrome"
 * (a bordered gradient box); now renders a plain borderless glyph so icons look
 * clean and consistent app-wide. Still exported as `ChromeGlyph` and commonly
 * used via `import { ChromeGlyph as Ionicons }` so existing call sites keep working.
 */
export function ChromeGlyph({ name, size = 20, color = '#F9FAFB', style }: Readonly<ChromeGlyphProps>) {
  if (name.startsWith('mci:')) {
    return <MaterialCommunityIcons name={name.slice(4) as MciName} size={size} color={color} style={style} />;
  }
  return <Ionicons name={name as IoniconName} size={size} color={color} style={style} />;
}
