import React, { useEffect, useId, useMemo } from 'react';
import { StyleSheet, View, useWindowDimensions } from 'react-native';
import Reanimated, {
  Easing,
  useAnimatedStyle,
  useReducedMotion,
  useSharedValue,
  withDelay,
  withRepeat,
  withTiming,
} from 'react-native-reanimated';
import Svg, { Circle, Defs, Ellipse, LinearGradient, RadialGradient, Stop } from 'react-native-svg';
import { AccountType, getAccountTheme } from '../../constants/accountThemes';
import { colors } from '../../constants/colors';
import { useAccountTheme } from './AccountThemeProvider';

interface BubbleBackgroundProps {
  accountType?: AccountType;
  bubbleCount?: number;
}

type BubbleSpec = {
  size: number;
  x: number;
  /** 0 = far (small, faint, slow) … 1 = near. */
  depth: number;
  riseMs: number;
  swayMs: number;
  swayAmp: number;
  wobbleMs: number;
  phase: number;
  tint: string;
};

/** Deterministic 0..1 noise so the layout is stable across renders and screens. */
function seeded(i: number, salt: number) {
  const s = Math.sin(i * 12.9898 + salt * 78.233) * 43758.5453;
  return s - Math.floor(s);
}

function SoapBubble({ size, tint, isLight }: Readonly<{ size: number; tint: string; isLight: boolean }>) {
  const id = useId().replaceAll(':', '');
  const r = size / 2;
  const rimAlpha = isLight ? 0.55 : 0.42;
  return (
    <Svg width={size} height={size}>
      <Defs>
        <RadialGradient id={`body${id}`} cx="50%" cy="50%" r="50%">
          <Stop offset="0" stopColor={tint} stopOpacity={0} />
          <Stop offset="0.62" stopColor={tint} stopOpacity={isLight ? 0.05 : 0.04} />
          <Stop offset="0.86" stopColor={tint} stopOpacity={isLight ? 0.2 : 0.16} />
          <Stop offset="1" stopColor={tint} stopOpacity={rimAlpha} />
        </RadialGradient>
        <LinearGradient id={`iri${id}`} x1="0" y1="0" x2="1" y2="1">
          <Stop offset="0" stopColor="#7DD3FC" stopOpacity={0.9} />
          <Stop offset="0.35" stopColor="#C4B5FD" stopOpacity={0.7} />
          <Stop offset="0.65" stopColor="#F9A8D4" stopOpacity={0.55} />
          <Stop offset="1" stopColor="#FDE68A" stopOpacity={0.75} />
        </LinearGradient>
        <RadialGradient id={`glint${id}`} cx="50%" cy="50%" r="50%">
          <Stop offset="0" stopColor="#FFFFFF" stopOpacity={0.85} />
          <Stop offset="1" stopColor="#FFFFFF" stopOpacity={0} />
        </RadialGradient>
      </Defs>
      <Circle cx={r} cy={r} r={r - 0.5} fill={`url(#body${id})`} />
      <Circle
        cx={r}
        cy={r}
        r={r - Math.max(0.8, size * 0.02)}
        fill="none"
        stroke={`url(#iri${id})`}
        strokeWidth={Math.max(0.8, size * 0.025)}
        strokeOpacity={0.55}
      />
      <Ellipse
        cx={r * 0.62}
        cy={r * 0.55}
        rx={r * 0.26}
        ry={r * 0.16}
        fill={`url(#glint${id})`}
        transform={`rotate(-35 ${r * 0.62} ${r * 0.55})`}
      />
      <Circle cx={r * 1.42} cy={r * 1.4} r={Math.max(0.8, r * 0.06)} fill="#FFFFFF" fillOpacity={0.45} />
    </Svg>
  );
}

function FloatingBubble({
  spec,
  screenH,
  isLight,
  still,
}: Readonly<{ spec: BubbleSpec; screenH: number; isLight: boolean; still: boolean }>) {
  const rise = useSharedValue(0);
  const sway = useSharedValue(0);
  const wobble = useSharedValue(0);

  useEffect(() => {
    if (still) return;
    const linear = { easing: Easing.linear };
    const smooth = { easing: Easing.inOut(Easing.sin) };
    rise.value = withRepeat(withTiming(1, { duration: spec.riseMs, ...linear }), -1, false);
    sway.value = withDelay(
      spec.phase * spec.swayMs,
      withRepeat(withTiming(1, { duration: spec.swayMs, ...smooth }), -1, true)
    );
    wobble.value = withRepeat(withTiming(1, { duration: spec.wobbleMs, ...smooth }), -1, true);
  }, [still, spec, rise, sway, wobble]);

  const baseOpacity = 0.35 + spec.depth * 0.55;
  const travel = screenH + spec.size * 2.5;

  const style = useAnimatedStyle(() => {
    const p = (rise.value + spec.phase) % 1;
    const fadeIn = Math.min(1, p / 0.08);
    const fadeOut = Math.min(1, (1 - p) / 0.18);
    const w = wobble.value - 0.5;
    return {
      opacity: baseOpacity * fadeIn * fadeOut,
      transform: [
        { translateY: screenH + spec.size - p * travel },
        { translateX: (sway.value - 0.5) * 2 * spec.swayAmp },
        { rotate: `${w * 10}deg` },
        { scaleX: 1 + w * 0.06 },
        { scaleY: 1 - w * 0.06 },
      ],
    };
  });

  const stillStyle = { opacity: baseOpacity * 0.8, transform: [{ translateY: screenH * (1 - spec.phase) }] };

  return (
    <Reanimated.View
      style={[styles.bubble, { left: spec.x, width: spec.size, height: spec.size }, still ? stillStyle : style]}
    >
      <SoapBubble size={spec.size} tint={spec.tint} isLight={isLight} />
    </Reanimated.View>
  );
}

export default function BubbleBackground({ accountType = 'valeter', bubbleCount = 7 }: Readonly<BubbleBackgroundProps>) {
  const accountContext = useAccountTheme();
  const { width, height } = useWindowDimensions();
  const reduceMotion = useReducedMotion();
  const theme = accountContext.theme ?? getAccountTheme(accountType, accountContext.mode);
  const primary = theme.primary || colors.SKY || '#38BDF8';
  const amber = theme.accentAlt || '#E8C547';
  const isLight = accountContext.mode === 'light';

  const specs = useMemo<BubbleSpec[]>(() => {
    const n = Math.max(1, bubbleCount);
    const lane = width / n;
    return Array.from({ length: n }, (_, i) => {
      const depth = seeded(i, 1);
      const size = 22 + depth * 58;
      return {
        size,
        depth,
        x: Math.min(width - size * 0.6, Math.max(-size * 0.4, lane * i + seeded(i, 2) * lane - size / 2)),
        riseMs: 26000 - depth * 10000 + seeded(i, 3) * 6000,
        swayMs: 3800 + seeded(i, 4) * 3000,
        swayAmp: 8 + depth * 18,
        wobbleMs: 1600 + seeded(i, 5) * 1400,
        phase: seeded(i, 6),
        tint: isLight && i % 3 === 1 ? amber : primary,
      };
    }).sort((a, b) => a.depth - b.depth);
  }, [bubbleCount, width, isLight, primary, amber]);

  return (
    <View style={styles.container} pointerEvents="none">
      {specs.map((spec) => (
        <FloatingBubble
          key={`${spec.x.toFixed(1)}-${spec.size.toFixed(1)}`}
          spec={spec}
          screenH={height}
          isLight={isLight}
          still={reduceMotion}
        />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 0,
    overflow: 'hidden',
  },
  bubble: { position: 'absolute', top: 0 },
});
