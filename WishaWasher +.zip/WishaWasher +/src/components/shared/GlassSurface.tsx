/**
 * Native Liquid Glass on iOS 26+, translucent card fallback everywhere else.
 */
import React from 'react';
import { Platform, StyleSheet, View, type StyleProp, type ViewStyle } from 'react-native';
import { GlassView, isLiquidGlassAvailable } from 'expo-glass-effect';

const LIQUID_GLASS = Platform.OS === 'ios' && isLiquidGlassAvailable();

type GlassSurfaceProps = Readonly<{
  children?: React.ReactNode;
  style?: StyleProp<ViewStyle>;
  tintColor?: string;
  borderColor?: string;
  interactive?: boolean;
  fallbackColor?: string;
}>;

export const hasLiquidGlass = LIQUID_GLASS;

export default function GlassSurface({
  children,
  style,
  tintColor,
  borderColor = 'rgba(255,255,255,0.12)',
  interactive = false,
  fallbackColor = 'rgba(255,255,255,0.05)',
}: GlassSurfaceProps) {
  if (LIQUID_GLASS) {
    return (
      <GlassView
        style={[styles.base, style]}
        glassEffectStyle="regular"
        tintColor={tintColor}
        isInteractive={interactive}
        colorScheme="dark"
      >
        {children}
      </GlassView>
    );
  }
  return (
    <View style={[styles.base, styles.fallback, { borderColor, backgroundColor: fallbackColor }, style]}>
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  base: {
    overflow: 'hidden',
  },
  fallback: {
    borderWidth: 1,
  },
});
