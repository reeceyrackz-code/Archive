/**
 * App-wide toast: call `showToast(...)` from anywhere; <ToastHost /> is mounted once in the root layout.
 * On iOS it renders in a FullWindowOverlay so it also appears above open modals / sheets.
 */
import React, { useCallback, useEffect, useState } from 'react';
import { Platform, StyleSheet, View } from 'react-native';
import { FullWindowOverlay } from 'react-native-screens';
import InlineToast, { type ToastKind, type ToastState } from './InlineToast';

type Listener = (toast: ToastState) => void;
const listeners = new Set<Listener>();

export function showToast(kind: ToastKind, message: string, title?: string) {
  const toast: ToastState = { kind, message, title };
  listeners.forEach((l) => l(toast));
}

export const toast = {
  success: (message: string, title?: string) => showToast('success', message, title),
  error: (message: string, title?: string) => showToast('error', message, title),
  info: (message: string, title?: string) => showToast('info', message, title),
};

export default function ToastHost() {
  const [current, setCurrent] = useState<ToastState>(null);

  useEffect(() => {
    const l: Listener = (t) => setCurrent(t);
    listeners.add(l);
    return () => {
      listeners.delete(l);
    };
  }, []);

  const hide = useCallback(() => setCurrent(null), []);

  const content = (
    <View style={StyleSheet.absoluteFill} pointerEvents="none">
      <InlineToast key={current ? `${current.kind}-${current.title}-${current.message}` : 'none'} toast={current} onHide={hide} />
    </View>
  );

  if (Platform.OS === 'ios') return <FullWindowOverlay>{content}</FullWindowOverlay>;
  return content;
}
