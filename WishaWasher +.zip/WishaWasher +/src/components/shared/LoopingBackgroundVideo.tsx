/**
 * Full-bleed looping muted background video (replaces expo-av Video backgrounds).
 */
import React, { useEffect } from 'react';
import { StyleSheet, type StyleProp, type ViewStyle } from 'react-native';
import { useEventListener } from 'expo';
import { useVideoPlayer, VideoView, type VideoSource } from 'expo-video';

type LoopingBackgroundVideoProps = Readonly<{
  source: VideoSource;
  style?: StyleProp<ViewStyle>;
  onReady?: () => void;
}>;

export default function LoopingBackgroundVideo({
  source,
  style,
  onReady,
}: LoopingBackgroundVideoProps) {
  const player = useVideoPlayer(source, (p) => {
    p.loop = true;
    p.muted = true;
    p.play();
  });

  useEventListener(player, 'statusChange', ({ status }) => {
    if (status === 'readyToPlay') onReady?.();
  });

  useEffect(() => {
    player.loop = true;
    player.muted = true;
    if (!player.playing) player.play();
  }, [player]);

  return (
    <VideoView
      player={player}
      style={[styles.fill, style]}
      contentFit="cover"
      nativeControls={false}
    />
  );
}

const styles = StyleSheet.create({
  fill: {
    ...StyleSheet.absoluteFill,
  },
});
