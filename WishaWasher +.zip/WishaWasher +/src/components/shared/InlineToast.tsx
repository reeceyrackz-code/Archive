/**
 * Lightweight top toast — replaces blocking alerts for quick confirmations.
 */
import React, { useEffect } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Animated, { FadeInUp, FadeOutUp } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ChromeGlyph as Ionicons } from './ChromeGlyph';
import GlassSurface from './GlassSurface';

export type ToastKind = 'success' | 'error' | 'info';
export type ToastState = { kind: ToastKind; message: string; title?: string } | null;

type InlineToastProps = Readonly<{
  toast: ToastState;
  onHide: () => void;
  durationMs?: number;
}>;

const KIND_STYLE: Record<ToastKind, { color: string; tint: string; icon: 'checkmark-circle' | 'alert-circle' | 'information-circle' }> = {
  success: { color: '#4ADE80', tint: 'rgba(16,185,129,0.25)', icon: 'checkmark-circle' },
  error: { color: '#F87171', tint: 'rgba(239,68,68,0.25)', icon: 'alert-circle' },
  info: { color: '#7DD3FC', tint: 'rgba(56,189,248,0.22)', icon: 'information-circle' },
};

export default function InlineToast({ toast, onHide, durationMs }: InlineToastProps) {
  const insets = useSafeAreaInsets();
  const hasTitle = !!toast?.title;
  const visibleMs = durationMs ?? (hasTitle || (toast?.message.length ?? 0) > 60 ? 3600 : 2200);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(onHide, visibleMs);
    return () => clearTimeout(t);
  }, [toast, onHide, visibleMs]);

  if (!toast) return null;
  const { color, tint, icon } = KIND_STYLE[toast.kind];

  return (
    <Animated.View
      entering={FadeInUp.springify().damping(16)}
      exiting={FadeOutUp.duration(220)}
      style={[styles.wrap, { top: insets.top + 10 }]}
      pointerEvents="none"
    >
      <GlassSurface
        style={hasTitle ? styles.card : styles.pill}
        tintColor={tint}
        borderColor={`${color}55`}
        fallbackColor="rgba(10,25,41,0.94)"
      >
        <View style={[styles.row, hasTitle && styles.rowCard]}>
          <Ionicons name={icon} size={hasTitle ? 20 : 18} color={color} />
          <View style={styles.copy}>
            {hasTitle ? (
              <Text style={styles.title} numberOfLines={1}>
                {toast.title}
              </Text>
            ) : null}
            <Text style={hasTitle ? styles.body : styles.text} numberOfLines={hasTitle ? 4 : 2}>
              {toast.message}
            </Text>
          </View>
        </View>
      </GlassSurface>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    position: 'absolute',
    left: 20,
    right: 20,
    zIndex: 100,
    alignItems: 'center',
  },
  pill: {
    borderRadius: 999,
  },
  card: {
    borderRadius: 20,
    alignSelf: 'stretch',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 10,
    paddingHorizontal: 16,
  },
  rowCard: {
    alignItems: 'flex-start',
    gap: 10,
    paddingVertical: 12,
  },
  copy: {
    flexShrink: 1,
  },
  text: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '700',
    flexShrink: 1,
  },
  title: {
    color: '#F9FAFB',
    fontSize: 14.5,
    fontWeight: '800',
  },
  body: {
    color: 'rgba(249,250,251,0.82)',
    fontSize: 13,
    fontWeight: '600',
    marginTop: 2,
    lineHeight: 18,
  },
});
