import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';

export type IoniconName = keyof typeof Ionicons.glyphMap;
export type MciName = keyof typeof MaterialCommunityIcons.glyphMap;

/**
 * Shared glyph name for `ChromeGlyph` / `GradientIconBox`: an Ionicons name, or a
 * Material Community Icons name prefixed with `mci:` (e.g. `mci:car-wash`), matching the customer app.
 */
export type IconGlyphName = IoniconName | `mci:${MciName}`;
