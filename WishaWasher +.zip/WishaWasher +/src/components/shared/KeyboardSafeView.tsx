/**
 * Wraps screens/sheets so the software keyboard never covers focused inputs.
 * iOS: KeyboardAvoidingView padding. Android: bottom inset from keyboard height.
 */
import React from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  View,
  StyleSheet,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import { useKeyboardHeight } from '../../hooks/useKeyboardHeight';

export type KeyboardSafeViewProps = Readonly<{
  children: React.ReactNode;
  /** Extra offset (e.g. header height) for KeyboardAvoidingView. */
  offset?: number;
  enabled?: boolean;
  /** Apply keyboard height as bottom padding on Android. Default true. */
  padAndroid?: boolean;
  style?: StyleProp<ViewStyle>;
  contentStyle?: StyleProp<ViewStyle>;
}>;

export default function KeyboardSafeView({
  children,
  offset = 0,
  enabled = true,
  padAndroid = true,
  style,
  contentStyle,
}: KeyboardSafeViewProps) {
  const keyboardHeight = useKeyboardHeight(enabled);

  if (!enabled) {
    return <View style={[{ flex: 1 }, style, contentStyle]}>{children}</View>;
  }

  return (
    <KeyboardAvoidingView
      style={[styles.flex, style]}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={offset}
    >
      <View
        style={[
          styles.flex,
          contentStyle,
          padAndroid && Platform.OS === 'android' && keyboardHeight > 0
            ? { paddingBottom: keyboardHeight }
            : null,
        ]}
      >
        {children}
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: {
    flex: 1,
  },
});
