import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Image, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Reanimated, {
  Easing,
  FadeIn,
  interpolate,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withRepeat,
  withSequence,
  withSpring,
  withTiming,
  type SharedValue,
} from 'react-native-reanimated';
import { scheduleOnRN } from 'react-native-worklets';
import { LinearGradient } from 'expo-linear-gradient';
import { hapticFeedback } from '../../services/HapticFeedbackService';

const LOGO = require('../../../assets/icon-auth.png');

/** Must match the native splash (`app.config.ts` → expo-splash-screen) for a seamless handoff. */
export const SPLASH_BG = '#0F3B78';
const LOGO_SIZE = 220;
const SKY = '#38BDF8';
const GOLD = '#FDE68A';

const BURST_COLORS = [GOLD, SKY, '#E0F2FE'];

const MESSAGES = ['Warming up the van…', 'Filling the buckets…', 'Polishing the wand…', 'Almost there…'];

type BubbleSpec = { id: string; x: number; size: number; delay: number; duration: number; drift: number };

function RisingBubble({ spec, height }: Readonly<{ spec: BubbleSpec; height: number }>) {
  const t = useSharedValue(0);
  useEffect(() => {
    t.value = withDelay(
      spec.delay,
      withRepeat(withTiming(1, { duration: spec.duration, easing: Easing.linear }), -1, false)
    );
  }, [spec, t]);
  const style = useAnimatedStyle(() => ({
    opacity: interpolate(t.value, [0, 0.1, 0.8, 1], [0, 0.55, 0.35, 0]),
    transform: [
      { translateY: interpolate(t.value, [0, 1], [height + 20, height * 0.15]) },
      { translateX: Math.sin(t.value * Math.PI * 2) * spec.drift },
      { scale: interpolate(t.value, [0, 1], [0.6, 1.1]) },
    ],
  }));
  return (
    <Reanimated.View
      pointerEvents="none"
      style={[
        styles.bubble,
        { left: spec.x, width: spec.size, height: spec.size, borderRadius: spec.size / 2 },
        style,
      ]}
    />
  );
}

/** One sparkle/bubble flying out of the logo when it's tapped. */
function BurstParticle({
  burst,
  angle,
  distance,
  color,
  size,
}: Readonly<{ burst: SharedValue<number>; angle: number; distance: number; color: string; size: number }>) {
  const style = useAnimatedStyle(() => {
    const p = burst.value;
    return {
      opacity: p <= 0 || p >= 1 ? 0 : interpolate(p, [0, 0.15, 1], [0, 1, 0]),
      transform: [
        { translateX: Math.cos(angle) * distance * p },
        { translateY: Math.sin(angle) * distance * p - p * 20 },
        { scale: interpolate(p, [0, 0.3, 1], [0.3, 1.2, 0.5]) },
      ],
    };
  });
  return (
    <Reanimated.View
      pointerEvents="none"
      style={[styles.particle, { width: size, height: size, borderRadius: size / 2, backgroundColor: color }, style]}
    />
  );
}

function Twinkle({ x, y, delay, size }: Readonly<{ x: number; y: number; delay: number; size: number }>) {
  const t = useSharedValue(0);
  useEffect(() => {
    t.value = withDelay(
      delay,
      withRepeat(
        withSequence(
          withTiming(1, { duration: 700, easing: Easing.out(Easing.quad) }),
          withTiming(0, { duration: 900, easing: Easing.in(Easing.quad) })
        ),
        -1,
        false
      )
    );
  }, [delay, t]);
  const style = useAnimatedStyle(() => ({
    opacity: t.value,
    transform: [{ scale: 0.4 + t.value * 0.8 }, { rotate: `${t.value * 45}deg` }],
  }));
  return (
    <Reanimated.Text pointerEvents="none" style={[styles.twinkle, { left: x, top: y, fontSize: size }, style]}>
      ✦
    </Reanimated.Text>
  );
}

/**
 * Glossy finish over the splash blue: lit top, a soft diagonal sheen, a slow light sweep and a
 * darker rim. Fades in from the flat native splash colour so the handoff stays seamless.
 */
function GlossBackdrop({ intro, height }: Readonly<{ intro: SharedValue<number>; height: number }>) {
  const sweep = useSharedValue(0);
  useEffect(() => {
    sweep.value = withDelay(
      900,
      withRepeat(withTiming(1, { duration: 4200, easing: Easing.inOut(Easing.cubic) }), -1, false)
    );
  }, [sweep]);
  const fadeStyle = useAnimatedStyle(() => ({ opacity: intro.value }));
  const sweepStyle = useAnimatedStyle(() => ({
    opacity: interpolate(sweep.value, [0, 0.15, 0.55, 0.7, 1], [0, 0.9, 0.9, 0, 0]),
    transform: [{ translateY: interpolate(sweep.value, [0, 0.7, 1], [-height * 0.6, height * 0.9, height * 0.9]) }, { rotate: '-18deg' }],
  }));
  return (
    <Reanimated.View pointerEvents="none" style={[StyleSheet.absoluteFill, fadeStyle]}>
      <LinearGradient
        colors={['#2D6BC4', '#1A4C98', SPLASH_BG, '#0A2C5E']}
        locations={[0, 0.32, 0.62, 1]}
        style={StyleSheet.absoluteFill}
      />
      <LinearGradient
        colors={['rgba(255,255,255,0.28)', 'rgba(255,255,255,0.08)', 'rgba(255,255,255,0)']}
        locations={[0, 0.22, 0.42]}
        start={{ x: 0.1, y: 0 }}
        end={{ x: 0.7, y: 0.6 }}
        style={StyleSheet.absoluteFill}
      />
      <Reanimated.View style={[styles.sweep, sweepStyle]}>
        <LinearGradient
          colors={['rgba(255,255,255,0)', 'rgba(255,255,255,0.10)', 'rgba(255,255,255,0)']}
          style={StyleSheet.absoluteFill}
        />
      </Reanimated.View>
      <View style={styles.reflection} />
      <LinearGradient
        colors={['rgba(4,18,40,0)', 'rgba(4,18,40,0.45)']}
        locations={[0.55, 1]}
        style={StyleSheet.absoluteFill}
      />
    </Reanimated.View>
  );
}

export default function AnimatedSplash({
  ready,
  onMounted,
  onFinish,
}: Readonly<{
  /** App has finished booting — splash plays its exit and calls `onFinish`. */
  ready: boolean;
  /** First layout — safe to hide the native splash now. */
  onMounted?: () => void;
  onFinish: () => void;
}>) {
  const { width, height } = useWindowDimensions();
  const [messageIndex, setMessageIndex] = useState(0);
  const [showHint, setShowHint] = useState(false);
  const mountedRef = useRef(false);
  const exitingRef = useRef(false);

  const intro = useSharedValue(0);
  const squish = useSharedValue(1);
  const wiggle = useSharedValue(0);
  const dragX = useSharedValue(0);
  const dragY = useSharedValue(0);
  const burst = useSharedValue(0);
  const progress = useSharedValue(0);
  const exit = useSharedValue(0);

  const bubbles = useMemo<BubbleSpec[]>(
    () =>
      Array.from({ length: 12 }, (_, i) => ({
        id: `bubble-${i}`,
        x: ((i * 37) % 100) / 100 * (width - 30) + 6,
        size: 6 + ((i * 7) % 14),
        delay: (i * 430) % 3000,
        duration: 4200 + ((i * 613) % 2600),
        drift: 8 + ((i * 5) % 14),
      })),
    [width]
  );

  const particles = useMemo(
    () =>
      Array.from({ length: 12 }, (_, i) => ({
        id: `burst-${i}`,
        angle: (i / 12) * Math.PI * 2,
        distance: 120 + (i % 3) * 30,
        color: BURST_COLORS[i % 3],
        size: 6 + (i % 4) * 2,
      })),
    []
  );

  useEffect(() => {
    intro.value = withTiming(1, { duration: 700, easing: Easing.out(Easing.cubic) });
    progress.value = withTiming(0.82, { duration: 2400, easing: Easing.out(Easing.cubic) });
    const hint = setTimeout(() => setShowHint(true), 900);
    const msg = setInterval(() => setMessageIndex((i) => (i + 1) % MESSAGES.length), 1100);
    return () => {
      clearTimeout(hint);
      clearInterval(msg);
    };
  }, [intro, progress]);

  const finish = useCallback(() => onFinish(), [onFinish]);

  /** Logo has painted — the native splash can go without a flash. */
  const announceMounted = useCallback(() => {
    if (mountedRef.current) return;
    mountedRef.current = true;
    onMounted?.();
  }, [onMounted]);

  useEffect(() => {
    const fallback = setTimeout(announceMounted, 800);
    return () => clearTimeout(fallback);
  }, [announceMounted]);

  useEffect(() => {
    if (!ready || exitingRef.current) return;
    exitingRef.current = true;
    progress.value = withTiming(1, { duration: 320, easing: Easing.out(Easing.quad) });
    exit.value = withDelay(
      360,
      withTiming(1, { duration: 520, easing: Easing.in(Easing.cubic) }, (done) => {
        if (done) scheduleOnRN(finish);
      })
    );
  }, [exit, finish, progress, ready]);

  const pop = useCallback(() => {
    void hapticFeedback('light');
  }, []);

  const tap = Gesture.Tap().onEnd(() => {
    squish.value = withSequence(
      withTiming(0.86, { duration: 90 }),
      withSpring(1, { damping: 5, stiffness: 260 })
    );
    wiggle.value = withSequence(
      withTiming(1, { duration: 80 }),
      withTiming(-1, { duration: 120 }),
      withTiming(0.5, { duration: 100 }),
      withSpring(0, { damping: 6 })
    );
    burst.value = 0;
    burst.value = withTiming(1, { duration: 750, easing: Easing.out(Easing.cubic) });
    scheduleOnRN(pop);
  });

  const pan = Gesture.Pan()
    .onChange((e) => {
      dragX.value += e.changeX;
      dragY.value += e.changeY;
    })
    .onEnd(() => {
      dragX.value = withSpring(0, { damping: 7, stiffness: 140 });
      dragY.value = withSpring(0, { damping: 7, stiffness: 140 });
      scheduleOnRN(pop);
    });

  const gesture = Gesture.Exclusive(pan, tap);

  const rootStyle = useAnimatedStyle(() => ({ opacity: 1 - exit.value }));

  const logoStyle = useAnimatedStyle(() => {
    const stretch = Math.min(0.12, Math.hypot(dragX.value, dragY.value) / 1200);
    return {
      transform: [
        { translateX: dragX.value },
        { translateY: dragY.value - exit.value * 30 },
        { rotate: `${wiggle.value * 8 + dragX.value / 40}deg` },
        { scaleX: squish.value * (1 + stretch) * (1 + exit.value * 0.18) },
        { scaleY: (2 - squish.value) * (1 - stretch * 0.6) * (1 + exit.value * 0.18) },
      ],
    };
  });

  const chromeStyle = useAnimatedStyle(() => ({
    opacity: intro.value,
    transform: [{ translateY: (1 - intro.value) * 16 }],
  }));

  const barStyle = useAnimatedStyle(() => ({ width: `${progress.value * 100}%` }));

  return (
    <Reanimated.View style={[styles.root, rootStyle]}>
      <GlossBackdrop intro={intro} height={height} />

      <Reanimated.View pointerEvents="none" style={[StyleSheet.absoluteFill, chromeStyle]}>
        {bubbles.map((b) => (
          <RisingBubble key={b.id} spec={b} height={height} />
        ))}
      </Reanimated.View>

      <View style={styles.center} pointerEvents="box-none">

        {particles.map((p) => (
          <BurstParticle key={p.id} burst={burst} angle={p.angle} distance={p.distance} color={p.color} size={p.size} />
        ))}

        <GestureDetector gesture={gesture}>
          <Reanimated.View
            style={[styles.logoWrap, logoStyle]}
            accessible
            accessibilityRole="image"
            accessibilityLabel="Wish-a-Wash"
            accessibilityHint="Tap or drag for a little magic"
          >
            <Image source={LOGO} style={styles.logo} resizeMode="contain" onLoad={announceMounted} />
            <Twinkle x={LOGO_SIZE * 0.72} y={LOGO_SIZE * 0.14} delay={500} size={16} />
            <Twinkle x={LOGO_SIZE * 0.84} y={LOGO_SIZE * 0.3} delay={1100} size={12} />
            <Twinkle x={LOGO_SIZE * 0.12} y={LOGO_SIZE * 0.24} delay={1700} size={10} />
          </Reanimated.View>
        </GestureDetector>
      </View>

      <Reanimated.View pointerEvents="none" style={[styles.footer, chromeStyle]}>
        {showHint ? (
          <Reanimated.Text entering={FadeIn.duration(400)} style={styles.hint}>
            Tap the bubble ✨
          </Reanimated.Text>
        ) : (
          <Text style={styles.hint}> </Text>
        )}
        <View style={styles.barTrack}>
          <Reanimated.View style={[styles.barFill, barStyle]}>
            <LinearGradient
              colors={[SKY, '#7DD3FC', GOLD]}
              start={{ x: 0, y: 0.5 }}
              end={{ x: 1, y: 0.5 }}
              style={StyleSheet.absoluteFill}
            />
          </Reanimated.View>
        </View>
        <Reanimated.Text key={ready ? 'ready' : messageIndex} entering={FadeIn.duration(260)} style={styles.message}>
          {ready ? 'Ready!' : MESSAGES[messageIndex]}
        </Reanimated.Text>
      </Reanimated.View>
    </Reanimated.View>
  );
}

const styles = StyleSheet.create({
  root: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 9999,
    elevation: 9999,
    backgroundColor: SPLASH_BG,
  },
  sweep: {
    position: 'absolute',
    left: -120,
    right: -120,
    top: 0,
    height: 140,
  },
  reflection: {
    position: 'absolute',
    top: -180,
    left: -80,
    right: -80,
    height: 360,
    borderBottomLeftRadius: 400,
    borderBottomRightRadius: 400,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  center: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoWrap: {
    width: LOGO_SIZE,
    height: LOGO_SIZE,
  },
  logo: {
    width: LOGO_SIZE,
    height: LOGO_SIZE,
  },
  twinkle: {
    position: 'absolute',
    color: GOLD,
    textShadowColor: 'rgba(253,230,138,0.8)',
    textShadowRadius: 8,
  },
  particle: {
    position: 'absolute',
  },
  bubble: {
    position: 'absolute',
    top: 0,
    borderWidth: 1,
    borderColor: 'rgba(186,230,253,0.55)',
    backgroundColor: 'rgba(125,211,252,0.10)',
  },
  footer: {
    position: 'absolute',
    left: 48,
    right: 48,
    bottom: 72,
    alignItems: 'center',
    gap: 10,
  },
  hint: {
    color: 'rgba(224,242,254,0.7)',
    fontSize: 13,
    fontWeight: '700',
  },
  barTrack: {
    width: '100%',
    maxWidth: 220,
    height: 5,
    borderRadius: 3,
    backgroundColor: 'rgba(255,255,255,0.10)',
    overflow: 'hidden',
  },
  barFill: {
    height: '100%',
    borderRadius: 3,
    overflow: 'hidden',
  },
  message: {
    color: 'rgba(224,242,254,0.75)',
    fontSize: 12.5,
    fontWeight: '600',
  },
});
