import type { useAccountTheme } from '../../shared/AccountThemeProvider';
import { lightMistElevated, lightMistPanel } from '../../../constants/accountThemes';
import { HEADER_STYLE_CARD_GRADIENT } from '../../../constants/bookingCardTheme';
import { themeBackgroundGradient } from '../../../utils/themeGradient';

type AccountTheme = ReturnType<typeof useAccountTheme>['theme'];

/** Colours the dashboard derives from the account theme. */
export function dashboardPalette(theme: AccountTheme) {
  const isLight = theme.mode === 'light';
  return {
    isLight,
    textMain: theme.textPrimary ?? '#F1F5F9',
    textMuted: theme.textSecondary ?? 'rgba(241,245,249,0.7)',
    sheetMist: isLight ? lightMistElevated : '#0F2847',
    sheetCardMist: isLight ? lightMistPanel : 'rgba(255,255,255,0.06)',
    accentText: theme.primary || '#7EB8D4',
    moneyGold: theme.accentAlt ?? '#E8C547',
    headerGradientStops: themeBackgroundGradient(theme?.headerBackground, HEADER_STYLE_CARD_GRADIENT),
    accent: theme.primary || '#3B82F6',
  };
}

export type DashboardPalette = ReturnType<typeof dashboardPalette>;
