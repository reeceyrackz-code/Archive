import React from 'react';
import { Image, Modal, Pressable, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { BlurView } from 'expo-blur';
import { ChromeGlyph as Ionicons } from '../../shared/ChromeGlyph';
import { LocationStyleIconBox } from '../../shared/GradientIconBox';
import ValeterDashboardChrome from '../../valeter/ValeterDashboardChrome';
import { hapticFeedback } from '../../../services/HapticFeedbackService';
import { accentToGradient } from '../../../utils/accentGradient';
import { getServiceDisplayName } from '../../../utils/serviceNameMapper';
import { yourJobStatusSubtitle } from './bookingHelpers';
import type { DashboardPalette } from './palette';
import type { YourJobSheetItem } from './types';

type Props = Readonly<{
  job: YourJobSheetItem | null;
  palette: DashboardPalette;
  bottomInset: number;
  onClose: () => void;
  onViewTrip: (jobId: string) => void;
}>;

/** Your job detail bottom sheet */
export default function YourJobSheetModal({ job, palette, bottomInset, onClose, onViewTrip }: Props) {
  const { accent, isLight, sheetMist, headerGradientStops } = palette;
  return (
    <Modal visible={!!job} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.yourJobSheetContainer}>
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose}>
          <BlurView intensity={40} tint="dark" style={StyleSheet.absoluteFill} />
        </Pressable>
        <View
          style={[
            styles.yourJobSheet,
            {
              paddingBottom: Math.max(bottomInset, 24),
              backgroundColor: sheetMist,
              borderColor: isLight ? 'rgba(232,197,71,0.28)' : 'rgba(255,255,255,0.1)',
              overflow: 'hidden',
            },
          ]}
          pointerEvents="box-none"
        >
          <ValeterDashboardChrome accent={accent} headerGradient={headerGradientStops} />
          {job ? <YourJobSheetBody job={job} palette={palette} onClose={onClose} onViewTrip={onViewTrip} /> : null}
        </View>
      </View>
    </Modal>
  );
}

function YourJobSheetBody({
  job,
  palette,
  onClose,
  onViewTrip,
}: Readonly<{
  job: YourJobSheetItem;
  palette: DashboardPalette;
  onClose: () => void;
  onViewTrip: (jobId: string) => void;
}>) {
  const { accent, isLight, textMain, textMuted, accentText, sheetCardMist } = palette;
  return (
    <>
      <View style={[styles.yourJobSheetHandle, isLight && { backgroundColor: 'rgba(11,31,54,0.28)' }]} />
      <View style={styles.yourJobSheetHeader}>
        <Text style={[styles.yourJobSheetTitle, { color: textMain }]}>
          {getServiceDisplayName(job.service_type, job.service_name) || job.service_name || 'Job'}
        </Text>
        <Text style={[styles.yourJobSheetSubtitle, { color: accentText }]}>{yourJobStatusSubtitle(job)}</Text>
      </View>
      <View style={styles.yourJobSheetPhotoHero}>
        {job.customer_photo ? (
          <Image
            source={{ uri: job.customer_photo }}
            style={[styles.yourJobSheetPhotoHeroImg, { borderColor: `${accent}55` }]}
            resizeMode="cover"
          />
        ) : (
          <View
            style={[
              styles.yourJobSheetPhotoHeroImg,
              styles.yourJobSheetPhotoHeroPlaceholder,
              {
                borderColor: `${accent}40`,
                backgroundColor: sheetCardMist,
              },
            ]}
          >
            <Ionicons name="person" size={40} color={accent} />
          </View>
        )}
      </View>
      <View style={[styles.yourJobSheetCustomer, { backgroundColor: sheetCardMist }]}>
        <View style={styles.yourJobSheetCustomerText}>
          <Text style={[styles.yourJobSheetCustomerLabel, { color: textMuted }]}>Customer</Text>
          <Text style={[styles.yourJobSheetCustomerName, { color: textMain }]} numberOfLines={2}>
            {job.customer_name || 'Customer'}
          </Text>
        </View>
      </View>
      <YourJobSheetDetails job={job} palette={palette} />
      <View style={styles.yourJobSheetActions}>
        <TouchableOpacity
          style={[
            styles.yourJobSheetCloseBtn,
            {
              borderColor: `${accent}50`,
              backgroundColor: sheetCardMist,
            },
          ]}
          onPress={() => {
            void hapticFeedback('light');
            onClose();
          }}
          activeOpacity={0.85}
        >
          <Text style={[styles.yourJobSheetCloseBtnText, { color: accentText }]}>Close</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.yourJobSheetViewBtn, { backgroundColor: accent }]}
          onPress={() => {
            void hapticFeedback('light');
            onClose();
            onViewTrip(job.id);
          }}
          activeOpacity={0.85}
        >
          <Ionicons name="navigate" size={18} color="#fff" />
          <Text style={styles.yourJobSheetViewBtnText}>View trip</Text>
        </TouchableOpacity>
      </View>
    </>
  );
}

function YourJobSheetDetails({ job, palette }: Readonly<{ job: YourJobSheetItem; palette: DashboardPalette }>) {
  const { accent, textMain, textMuted, moneyGold } = palette;
  return (
    <ScrollView style={styles.yourJobSheetScroll} showsVerticalScrollIndicator={false}>
      {job.scheduled_at ? (
        <View style={styles.yourJobSheetRow}>
          <Ionicons name="calendar-outline" size={20} color={accent} />
          <Text style={[styles.yourJobSheetLabel, { color: textMuted }]}>Scheduled</Text>
          <Text style={[styles.yourJobSheetValue, { color: textMain }]}>
            {new Date(job.scheduled_at).toLocaleString('en-GB', {
              day: 'numeric',
              month: 'short',
              year: 'numeric',
              hour: '2-digit',
              minute: '2-digit',
            })}
          </Text>
        </View>
      ) : null}
      {job.location_address ? (
        <View style={styles.yourJobSheetRow}>
          <Ionicons name="location-outline" size={20} color={accent} />
          <Text style={[styles.yourJobSheetLabel, { color: textMuted }]}>Address</Text>
          <Text style={[styles.yourJobSheetValue, { color: textMain }]}>{job.location_address}</Text>
        </View>
      ) : null}
      <View style={styles.yourJobSheetRow}>
        <LocationStyleIconBox variant="inline" icon="wallet-outline" colors={accentToGradient(accent)} />
        <Text style={[styles.yourJobSheetLabel, { color: textMuted }]}>Price</Text>
        <Text style={[styles.yourJobSheetValue, styles.yourJobSheetPrice, { color: moneyGold }]}>
          £{Number(job.price || 0).toFixed(2)}
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  yourJobSheetContainer: { flex: 1, justifyContent: 'flex-end' },
  yourJobSheet: {
    backgroundColor: '#0F2847',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingHorizontal: 24,
    paddingTop: 12,
    maxHeight: '85%',
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  yourJobSheetHandle: {
    width: 40,
    height: 5,
    backgroundColor: 'rgba(255,255,255,0.25)',
    borderRadius: 3,
    alignSelf: 'center',
    marginBottom: 20,
  },
  yourJobSheetHeader: { marginBottom: 12 },
  yourJobSheetPhotoHero: { alignItems: 'center', marginBottom: 14 },
  yourJobSheetPhotoHeroImg: {
    width: 96,
    height: 96,
    borderRadius: 48,
    borderWidth: 2,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  yourJobSheetPhotoHeroPlaceholder: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  yourJobSheetTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 4,
  },
  yourJobSheetSubtitle: { fontSize: 14, fontWeight: '600' },
  yourJobSheetCustomer: {
    marginBottom: 18,
    paddingVertical: 12,
    paddingHorizontal: 14,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 16,
  },
  yourJobSheetCustomerText: { flex: 1, minWidth: 0 },
  yourJobSheetCustomerLabel: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 4,
  },
  yourJobSheetCustomerName: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '700',
  },
  yourJobSheetScroll: { maxHeight: 280, marginBottom: 16 },
  yourJobSheetRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 14,
  },
  yourJobSheetLabel: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '600',
    minWidth: 90,
  },
  yourJobSheetValue: {
    flex: 1,
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '600',
  },
  yourJobSheetPrice: { fontSize: 18, fontWeight: '800' },
  yourJobSheetActions: { flexDirection: 'row', gap: 12 },
  yourJobSheetCloseBtn: {
    flex: 1,
    paddingVertical: 16,
    borderRadius: 14,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  yourJobSheetCloseBtnText: { fontSize: 16, fontWeight: '700' },
  yourJobSheetViewBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    borderRadius: 14,
  },
  yourJobSheetViewBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});
