import React from 'react';
import { router } from 'expo-router';
import ReportProblemSheet from '../../valeter/ReportProblemSheet';
import CancelJobReasonSheet from '../../valeter/CancelJobReasonSheet';
import ValeterCustomerProfileSheet from '../../valeter/ValeterCustomerProfileSheet';
import ValeterEarningsSheet from '../../valeter/ValeterEarningsSheet';
import NavAppPickerSheet from '../../valeter/NavAppPickerSheet';
import { isChatLockedUntilPaid } from '../../../utils/trackingStatusHelpers';
import type { DashboardUiState } from './useDashboardSession';
import type { TrackingState } from './types';

type Props = Readonly<{
  userId: string | undefined;
  accent: string;
  ui: DashboardUiState;
  tracking: TrackingState;
  isTrackingMode: boolean;
  closeTracking: () => void;
}>;

function coord(v: number | string | null | undefined) {
  return v == null ? null : Number(v);
}

/** Earnings, report-a-problem, cancel-reason, customer-profile and navigation-app sheets. */
export default function DashboardSheets({
  userId,
  accent,
  ui,
  tracking,
  isTrackingMode,
  closeTracking,
}: Props) {
  const tripSheets = isTrackingMode;
  const trip = tracking;
  const job = tracking.job;

  return (
    <>
      <ValeterEarningsSheet
        visible={ui.earningsSheetVisible}
        userId={userId}
        accent={accent}
        onClose={() => ui.setEarningsSheetVisible(false)}
      />

      <ReportProblemSheet
        visible={ui.reportSheetOpen && tripSheets}
        accent={accent}
        chatLocked={isChatLockedUntilPaid(trip.status)}
        onClose={() => ui.setReportSheetOpen(false)}
        onChat={tracking.handleChat}
        onSupport={() => router.push('/valeter/support/help-support' as any)}
      />
      <CancelJobReasonSheet
        visible={ui.cancelSheetOpen && tripSheets}
        accent={accent}
        customerName={trip.customerName}
        onClose={() => ui.setCancelSheetOpen(false)}
        onConfirm={tracking.cancelWithReason}
        onCancelled={() => {
          ui.setCancelSheetOpen(false);
          closeTracking();
        }}
      />
      <ValeterCustomerProfileSheet
        visible={ui.customerProfileOpen && isTrackingMode}
        onClose={() => ui.setCustomerProfileOpen(false)}
        accent={accent}
        valeterId={userId ?? null}
        customerId={tracking.job?.user_id ?? null}
        customerName={trip.customerName}
        customerPhotoUri={tracking.customerPhotoUrl}
        job={job}
        statusMessage={trip.statusMessage}
        vehicles={trip.bookingVehicles}
        etaMinutes={trip.etaMinutes}
        distanceMi={trip.distanceMi}
        onChat={tracking.handleChat}
      />
      <NavAppPickerSheet
        enabled={tripSheets}
        status={trip.status}
        jobId={job?.id ?? null}
        destination={{
          address: job?.location_address,
          latitude: coord(job?.location_lat),
          longitude: coord(job?.location_lng),
        }}
        accent={accent}
      />
    </>
  );
}
