import React from 'react';
import { Animated, Pressable, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../../shared/ChromeGlyph';
import GoOnlineHero from '../../valeter/GoOnlineHero';
import ValeterStageBackdrop, { type ValeterBackdropStage } from '../../valeter/ValeterStageBackdrop';
import { valeterMapHeaderTotalHeight } from '../../valeter/ValeterMapHeader';
import { hapticFeedback } from '../../../services/HapticFeedbackService';
import type { RouteTurn } from '../../../utils/routeTurnAhead';
import { STATUS_SPARKLE_ORBITS } from './constants';
import { stageGate, stageJob, stageTrip, type HeaderTrip } from './tripHelpers';
import type { HeroMorph } from './useStatusAnimations';

/** Offline tint, top scrim and the online/offline colour flash over the map. */
export function MapOverlays({
  tintOpacity,
  flashColor,
  flashOpacity,
}: Readonly<{
  tintOpacity: Animated.AnimatedInterpolation<number>;
  flashColor: string;
  flashOpacity: Animated.Value;
}>) {
  return (
    <>
      <Animated.View
        pointerEvents="none"
        style={[StyleSheet.absoluteFill, styles.mapOfflineTint, { opacity: tintOpacity }]}
      />
      <LinearGradient
        colors={['rgba(15,59,120,0.4)', 'transparent', 'transparent']}
        style={styles.mapTopScrim}
        pointerEvents="none"
      />
      <View pointerEvents="none" style={StyleSheet.absoluteFill}>
        <Animated.View
          style={[
            StyleSheet.absoluteFill,
            {
              backgroundColor: flashColor,
              opacity: flashOpacity,
            },
          ]}
        />
      </View>
    </>
  );
}

function StatusSparkles({ anims, accent }: Readonly<{ anims: Animated.Value[]; accent: string }>) {
  return (
    <View style={styles.statusSparkleLayer} pointerEvents="none">
      {STATUS_SPARKLE_ORBITS.map((orbit, index) => {
        const anim = anims[index];
        const tx = anim.interpolate({
          inputRange: [0, 1],
          outputRange: [0, orbit.dx],
        });
        const ty = anim.interpolate({
          inputRange: [0, 1],
          outputRange: [0, orbit.dy],
        });
        const sparkOpacity = anim.interpolate({
          inputRange: [0, 0.2, 0.8, 1],
          outputRange: [0, 1, 0.7, 0],
        });
        const sparkScale = anim.interpolate({
          inputRange: [0, 0.45, 1],
          outputRange: [0.2, 1, 0.35],
        });
        return (
          <Animated.View
            key={`status-spark-${orbit.dx}-${orbit.dy}`}
            style={[
              styles.statusSparkle,
              {
                width: orbit.size,
                height: orbit.size,
                borderRadius: orbit.size / 2,
                backgroundColor: accent,
                opacity: sparkOpacity,
                transform: [{ translateX: tx }, { translateY: ty }, { scale: sparkScale }],
              },
            ]}
          />
        );
      })}
    </View>
  );
}

/** Floating go-online button; morphs up into the header once online. Hidden during a trip. */
export function StatusHeroOverlay({
  visible,
  isOnline,
  topInset,
  sheetBottomPad,
  morph,
  busy,
  onPress,
  mascotSpin,
  sparkleAnims,
  accent,
}: Readonly<{
  visible: boolean;
  isOnline: boolean;
  topInset: number;
  sheetBottomPad: number;
  morph: HeroMorph;
  busy: boolean;
  onPress: () => void;
  mascotSpin: Animated.AnimatedInterpolation<string>;
  sparkleAnims: Animated.Value[];
  accent: string;
}>) {
  if (!visible) return null;
  return (
    <Animated.View
      pointerEvents={isOnline ? 'none' : 'box-none'}
      style={[
        styles.statusHeroFloating,
        {
          top: valeterMapHeaderTotalHeight(topInset),
          bottom: Math.max(sheetBottomPad * 0.45, 80),
          opacity: morph.heroMorphOpacity,
          transform: [
            { translateY: morph.heroMorphTranslateY },
            { scale: morph.heroMorphScale },
            { rotate: morph.heroMorphRotate },
          ],
        },
      ]}
    >
      <GoOnlineHero busy={busy} disabled={isOnline} onPress={onPress} mascotSpin={mascotSpin}>
        <StatusSparkles anims={sparkleAnims} accent={accent} />
      </GoOnlineHero>
    </Animated.View>
  );
}

/** Trip chrome over the map (payment gate, road HUD, wash checklist). */
export function DashboardStageBackdrop({
  headerTrip,
  stage,
  accent,
  selfPhoto,
  turn,
  nearby,
  voiceMuted,
  onToggleVoice,
  street,
  topInset,
  bottomInset,
}: Readonly<{
  headerTrip: HeaderTrip;
  stage: ValeterBackdropStage | null;
  accent: string;
  selfPhoto: string | null;
  turn: RouteTurn | null;
  nearby: boolean;
  voiceMuted: boolean;
  onToggleVoice: () => void;
  street: string | null;
  topInset: number;
  bottomInset: number;
}>) {
  return (
    <ValeterStageBackdrop
      stage={stage}
      accent={accent}
      hudRightInset={12}
      gate={stageGate(headerTrip, selfPhoto)}
      trip={stageTrip(headerTrip, { selfPhoto, turn, nearby, voiceMuted, onToggleVoice })}
      job={stageJob(headerTrip, street)}
      topInset={valeterMapHeaderTotalHeight(topInset)}
      bottomInset={bottomInset}
    />
  );
}

/** Shown once the valeter pans away from the follow camera. */
export function RecenterButton({
  navFollow,
  followVan,
  bottom,
  onRecenter,
}: Readonly<{
  navFollow: boolean;
  followVan: boolean;
  bottom: number;
  onRecenter: () => void;
}>) {
  if (!navFollow || followVan) return null;
  return (
    <Pressable
      onPress={() => {
        void hapticFeedback('light');
        onRecenter();
      }}
      hitSlop={8}
      style={[styles.recenter, { bottom: bottom + 14 }]}
      accessibilityRole="button"
      accessibilityLabel="Re-centre on your van"
    >
      <Ionicons name="navigate" size={15} color="#F8FAFC" />
      <Text style={styles.recenterText}>Re-centre</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  recenter: {
    position: 'absolute',
    right: 14,
    zIndex: 14,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    height: 38,
    paddingHorizontal: 14,
    borderRadius: 19,
    backgroundColor: 'rgba(11,17,28,0.94)',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(255,255,255,0.16)',
  },
  recenterText: { color: '#F8FAFC', fontSize: 13, fontWeight: '600' },
  statusHeroFloating: {
    position: 'absolute',
    left: 0,
    right: 0,
    zIndex: 15,
    alignItems: 'center',
    justifyContent: 'center',
  },
  mapTopScrim: {
    ...StyleSheet.absoluteFill,
    bottom: '55%',
  },
  mapOfflineTint: {
    backgroundColor: 'rgba(0, 0, 0, 0.72)',
    zIndex: 10,
  },
  statusSparkleLayer: {
    ...StyleSheet.absoluteFill,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'visible',
    zIndex: 4,
  },
  statusSparkle: {
    position: 'absolute',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
