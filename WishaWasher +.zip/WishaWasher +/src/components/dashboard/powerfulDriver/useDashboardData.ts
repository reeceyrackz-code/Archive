import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AppState } from 'react-native';
import { supabase } from '../../../lib/supabase';
import { hapticFeedback } from '../../../services/HapticFeedbackService';
import { notifyValeterJobRequest } from '../../../services/valeterJobPhoneNotifications';
import { useSyncValeterNavDashboardStats } from '../../valeter/ValeterNavSidebar';
import { getServiceDisplayName } from '../../../utils/serviceNameMapper';
import { fetchProfileById, fetchProfilesByIds, resolveCustomerAvatarsForUserIds } from '../../../utils/customerProfiles';
import {
  isInstantBookingOffer,
  loadValeterScheduleBlocks,
  offerOverlapsSchedule,
  valeterHasLiveJob,
} from '../../../services/valeterScheduleConflict';
import {
  advanceJobRequestTimers,
  compareEnrichedBookings,
  handleJobRequestInsert,
  handleJobRequestUpdate,
  haversineMi,
  loadValeterName,
  optionalNumberCoord,
  recentBookingStillVisible,
} from './bookingHelpers';
import { ACTIVE_JOB_STATUSES, REQUEST_POLL_MS, REQUEST_TIMEOUT_SECONDS } from './constants';
import type { ActiveJob, JobRequest, JobRequestBooking, SetState, TodayStats } from './types';

export function useRecentBookings(userId: string | undefined) {
  const [recentBookings, setRecentBookings] = useState<any[]>([]);

  const loadRecentBookings = useCallback(async () => {
    if (!userId) return;
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select(
          'id, service_type, service_name, status, price, scheduled_at, location_address, user_id, created_at, completed_at, updated_at'
        )
        .eq('valeter_id', userId)
        .in('status', [
          'completed',
          'confirmed',
          'in_progress',
          'scheduled',
          'pending_payment',
          'en_route',
          'arrived',
          'pending_valeter_acceptance',
          'valeter_assigned',
        ])
        .limit(40);

      if (error) {
        console.warn('[Dashboard] loadRecentBookings error:', error);
        setRecentBookings([]);
        return;
      }
      if (!data?.length) {
        setRecentBookings([]);
        return;
      }

      const ids = [
        ...new Set(
          data
            .map((b: { user_id?: string | null }) => b.user_id)
            .filter((id): id is string => typeof id === 'string' && id.length > 0)
        ),
      ];
      const profiles = await fetchProfilesByIds(ids);
      const photos = ids.length > 0 ? resolveCustomerAvatarsForUserIds(ids, profiles) : new Map();
      const now = Date.now();
      const thirtyMs = 30 * 24 * 60 * 60 * 1000;

      const enriched = data
        .map((b: Record<string, unknown>) => {
          const uid = typeof b.user_id === 'string' ? b.user_id : null;
          const p = uid ? profiles.get(uid) : undefined;
          return {
            ...b,
            customer_name: p?.full_name || p?.name || 'Customer',
            customer_photo: uid ? photos.get(uid) ?? null : null,
          };
        })
        .filter((b: Record<string, unknown>) => recentBookingStillVisible(b, thirtyMs));

      enriched.sort((a, b) => compareEnrichedBookings(a, b, now));

      setRecentBookings(enriched);
    } catch (e) {
      console.warn('[Dashboard] loadRecentBookings error:', e);
      setRecentBookings([]);
    }
  }, [userId]);

  return { recentBookings, loadRecentBookings };
}

export function useDashboardStats(userId: string | undefined) {
  const [todayStats, setTodayStats] = useState<TodayStats>({
    hoursOnline: '0h 0m',
    jobsCompleted: 0,
    earnings: 0,
  });
  const [profileName, setProfileName] = useState<string>('Car Care Pro');

  const loadTodayStats = useCallback(async () => {
    if (!userId) return;
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    const todayEnd = new Date(todayStart);
    todayEnd.setDate(todayEnd.getDate() + 1);
    const { data } = await supabase
      .from('bookings')
      .select('id, status, price, completed_at')
      .eq('valeter_id', userId)
      .eq('status', 'completed')
      .gte('completed_at', todayStart.toISOString())
      .lt('completed_at', todayEnd.toISOString());
    const completedToday = data || [];
    const earningsToday = completedToday.reduce((sum: number, b: any) => sum + (Number(b.price) || 0), 0);
    setTodayStats({
      hoursOnline: '0h 0m',
      jobsCompleted: completedToday.length,
      earnings: Math.round(earningsToday * 100) / 100,
    });
  }, [userId]);

  return { todayStats, setTodayStats, profileName, setProfileName, loadTodayStats };
}

export function useActiveJob(userId: string | undefined) {
  const [activeJob, setActiveJob] = useState<ActiveJob | null>(null);
  const [activeJobLoading, setActiveJobLoading] = useState(false);
  const [customerNameActive, setCustomerNameActive] = useState<string>('Customer');

  const loadActiveJob = useCallback(async () => {
    if (!userId) return;
    try {
      setActiveJobLoading(true);
      const { data, error } = await supabase
        .from('bookings')
        .select('id,status,service_type,service_name,location_address,location_lat,location_lng,price,user_id')
        .eq('valeter_id', userId)
        .in('status', ACTIVE_JOB_STATUSES as any)
        .order('request_sent_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error || !data) {
        setActiveJob(null);
        return;
      }

      const lat = optionalNumberCoord(data.location_lat);
      const lng = optionalNumberCoord(data.location_lng);

      setActiveJob({
        id: data.id,
        status: data.status,
        service_type: data.service_type,
        service_name: data.service_name ?? null,
        location_address: data.location_address ?? null,
        location_lat: lat,
        location_lng: lng,
        price: Number(data.price ?? 0),
        user_id: data.user_id ?? null,
      });

      if (data.user_id) {
        const profile = await fetchProfileById(data.user_id);
        const raw =
          profile?.full_name?.trim() ||
          profile?.name?.trim() ||
          (profile?.email ? String(profile.email).split('@')[0] : '') ||
          '';
        setCustomerNameActive(raw.trim() || 'Customer');
      } else {
        setCustomerNameActive('Customer');
      }
    } catch (e) {
      console.warn('[Dashboard] loadActiveJob error:', e);
      setActiveJob(null);
    } finally {
      setActiveJobLoading(false);
    }
  }, [userId]);

  return {
    activeJob,
    activeJobLoading,
    displayCustomerName: activeJob != null ? customerNameActive : 'Customer',
    loadActiveJob,
  };
}

export function useNavDashboardStatsSync(todayStats: TodayStats, isOnline: boolean, activeJob: ActiveJob | null) {
  const navDashboardStats = useMemo(
    () => ({
      earningsToday: todayStats.earnings,
      jobsToday: todayStats.jobsCompleted,
      isOnline,
      verificationPercent: 80,
      hasActiveJob: !!activeJob,
    }),
    [todayStats.earnings, todayStats.jobsCompleted, isOnline, activeJob]
  );
  useSyncValeterNavDashboardStats(navDashboardStats);
}

function useValeterJobRequestRealtime(
  userId: string | undefined,
  isOnline: boolean,
  loadJobRequests: () => void,
  setJobRequests: SetState<JobRequest[]>,
  onNewRequest?: () => void
) {
  useEffect(() => {
    if (!userId || !isOnline) return;

    const channel = supabase
      .channel(`job-requests-${userId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'bookings',
          filter: `valeter_id=eq.${userId}`,
        },
        (payload) => {
          const booking = payload.new as JobRequestBooking;
          handleJobRequestInsert(userId, booking, loadJobRequests, onNewRequest).catch(() => undefined);
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'bookings',
          filter: `valeter_id=eq.${userId}`,
        },
        (payload) => {
          const booking = payload.new as JobRequestBooking;
          handleJobRequestUpdate(userId, booking, loadJobRequests, setJobRequests, onNewRequest);
        }
      )
      .subscribe((status) => {
        // Re-sync after (re)connecting so offers sent while the socket was down still appear.
        if (status === 'SUBSCRIBED') loadJobRequests();
        else if (__DEV__ && status !== 'CLOSED') console.warn('[Dashboard] job-requests realtime:', status);
      });

    return () => {
      void supabase.removeChannel(channel);
    };
  }, [userId, isOnline, loadJobRequests, setJobRequests, onNewRequest]);
}

/**
 * Safety net for realtime: re-check offers on a short interval while online and as soon as the
 * app returns to the foreground (sockets drop while the phone sleeps).
 */
function useJobRequestCatchUp(userId: string | undefined, isOnline: boolean, loadJobRequests: () => void) {
  useEffect(() => {
    if (!userId || !isOnline) return;
    const poll = setInterval(loadJobRequests, REQUEST_POLL_MS);
    const sub = AppState.addEventListener('change', (state) => {
      if (state === 'active') loadJobRequests();
    });
    return () => {
      clearInterval(poll);
      sub.remove();
    };
  }, [userId, isOnline, loadJobRequests]);
}

/**
 * Buzz and phone alert once per newly seen offer, however it arrived (realtime, catch-up or refresh).
 * The alert service de-dupes per booking, so a realtime alert for the same offer isn't repeated.
 */
function useNewOfferAlert(userId: string | undefined, jobRequests: JobRequest[]) {
  const seenRef = useRef<Set<string>>(new Set());
  useEffect(() => {
    const seen = seenRef.current;
    const fresh = jobRequests.filter((r) => !seen.has(r.id));
    if (fresh.length === 0) return;
    for (const r of fresh) seen.add(r.id);
    void hapticFeedback('medium');
    for (const r of fresh) {
      notifyValeterJobRequest({
        bookingId: r.id,
        serviceName: r.serviceName,
        price: r.price,
        locationAddress: r.address,
        userId,
      }).catch(() => undefined);
    }
  }, [userId, jobRequests]);
}

function useValeterJobRequestCountdown(
  jobRequests: JobRequest[],
  handleJobTimeout: (jobId: string) => void,
  setJobRequests: SetState<JobRequest[]>
) {
  useEffect(() => {
    if (jobRequests.length === 0) return;

    const interval = setInterval(() => {
      setJobRequests((prev) => advanceJobRequestTimers(prev, handleJobTimeout));
    }, 1000);

    return () => clearInterval(interval);
  }, [jobRequests, handleJobTimeout, setJobRequests]);
}

function toJobRequest(
  r: any,
  nowSec: number,
  vLat: number | null | undefined,
  vLng: number | null | undefined,
  profilesMap: Map<string, any>
): JobRequest {
  const sentAt = r.request_sent_at || r.created_at;
  const endSec = sentAt
    ? Math.floor(new Date(sentAt).getTime() / 1000) + REQUEST_TIMEOUT_SECONDS
    : nowSec + REQUEST_TIMEOUT_SECONDS;
  const timeRemaining = Math.max(0, endSec - nowSec);
  let distance = 0;
  let driveTimeMinutes: number | undefined;
  if (vLat != null && vLng != null && r.location_lat != null && r.location_lng != null) {
    distance = Math.round(haversineMi(vLat, vLng, r.location_lat, r.location_lng) * 10) / 10;
    driveTimeMinutes = Math.round(distance * 2);
  }
  const profile = r.user_id ? profilesMap.get(r.user_id) : null;
  const customerName = profile?.full_name?.trim() || 'Customer';
  return {
    id: r.id,
    serviceName: getServiceDisplayName(r.service_type, r.service_name),
    distance,
    driveTimeMinutes,
    price: Number(r.price) || 0,
    customerName,
    address: r.location_address || '',
    timeRemaining,
    location_lat: optionalNumberCoord(r.location_lat),
    location_lng: optionalNumberCoord(r.location_lng),
    scheduledAt: r.scheduled_at ?? null,
    requestSentAt: r.request_sent_at || r.created_at || null,
    serviceType: typeof r.service_type === 'string' ? r.service_type : undefined,
    serviceNameRaw: r.service_name ?? null,
  };
}

/** Pending offers: initial load, realtime inserts/updates and the per-second accept countdown. */
export function useJobRequestsFeed(userId: string | undefined, isOnline: boolean, activeJobStatus: string | undefined) {
  const [jobRequests, setJobRequests] = useState<JobRequest[]>([]);

  const loadJobRequests = useCallback(async () => {
    if (!userId) return;
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select(
          'id, service_name, service_type, location_address, location_lat, location_lng, price, scheduled_at, request_sent_at, created_at, user_id'
        )
        .eq('valeter_id', userId)
        .eq('status', 'pending_valeter_acceptance')
        .order('request_sent_at', { ascending: false })
        .limit(20);

      if (error) throw error;

      const rows = data || [];
      const userIds = [...new Set(rows.map((r: any) => r.user_id).filter(Boolean))] as string[];
      const { commitmentWindows, externalBusy } = await loadValeterScheduleBlocks(userId);
      const [presenceRes, profilesMap] = await Promise.all([
        supabase.from('valeter_presence').select('last_lat, last_lng').eq('user_id', userId).maybeSingle(),
        fetchProfilesByIds(userIds),
      ]);
      const vLat = presenceRes.data?.last_lat;
      const vLng = presenceRes.data?.last_lng;

      const nowSec = Math.floor(Date.now() / 1000);
      const onLiveJob = await valeterHasLiveJob(userId);
      const list: JobRequest[] = rows.map((r: any) => toJobRequest(r, nowSec, vLat, vLng, profilesMap));
      const listFiltered = list.filter((req) => {
        // Mid active job: hide instant “jobs now”; keep scheduled when calendar is free
        if (onLiveJob && isInstantBookingOffer(req.scheduledAt)) return false;
        return !offerOverlapsSchedule(
          req.scheduledAt,
          req.requestSentAt,
          req.serviceType,
          req.serviceNameRaw ?? undefined,
          commitmentWindows,
          externalBusy
        );
      });
      setJobRequests(listFiltered);
    } catch (e) {
      console.warn('[Dashboard] loadJobRequests error', e);
      setJobRequests([]);
    }
  }, [userId]);

  // Load job requests when online (initial + when going online); refresh when leaving a live job
  useEffect(() => {
    if (!userId || !isOnline) return;
    void loadJobRequests();
  }, [userId, isOnline, loadJobRequests, activeJobStatus]);

  useValeterJobRequestRealtime(userId, isOnline, loadJobRequests, setJobRequests);
  useJobRequestCatchUp(userId, isOnline, loadJobRequests);
  useNewOfferAlert(userId, jobRequests);

  const handleJobTimeout = async (jobId: string) => {
    try {
      await supabase.from('bookings').update({ status: 'valeter_timeout' }).eq('id', jobId);
    } catch (e) {
      console.error('Timeout update failed:', e);
    }
  };

  useValeterJobRequestCountdown(jobRequests, handleJobTimeout, setJobRequests);

  return { jobRequests, setJobRequests, loadJobRequests };
}

/** Pull-to-refresh: reloads name, active job, offers, today's stats and recent bookings. */
export function useDashboardRefresh(
  o: Readonly<{
    userId: string | undefined;
    userName: string | null | undefined;
    setProfileName: (name: string) => void;
    loadActiveJob: () => Promise<void>;
    loadJobRequests: () => Promise<void>;
    loadTodayStats: () => Promise<void>;
    loadRecentBookings: () => Promise<void>;
  }>
) {
  const [refreshing, setRefreshing] = useState(false);

  const onRefresh = async () => {
    setRefreshing(true);
    try {
      if (o.userId) {
        const name = await loadValeterName(o.userId, o.userName);
        o.setProfileName(name);
        await o.loadActiveJob();
        await o.loadJobRequests();
        await o.loadTodayStats();
        await o.loadRecentBookings();
      }
      await new Promise((resolve) => setTimeout(resolve, 700));
    } finally {
      setRefreshing(false);
    }
  };

  return { refreshing, onRefresh };
}
