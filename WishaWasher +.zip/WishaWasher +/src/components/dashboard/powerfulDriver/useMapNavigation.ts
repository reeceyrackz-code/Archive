import type React from 'react';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Easing } from 'react-native';
import type MapView from 'react-native-maps';
import { AnimatedRegion } from 'react-native-maps';
import {
  bearingBetween,
  distanceToRoute,
  metresBetween,
  remainingRoute,
  routeHeading,
  routeTurnAhead,
  streetFromAddress,
  type RouteTurn,
} from '../../../utils/routeTurnAhead';
import { useVoiceGuidance } from '../../../hooks/useVoiceGuidance';
import useNavLocation from '../../../hooks/useNavLocation';
import { hapticFeedback } from '../../../services/HapticFeedbackService';
import { fetchDrivingRoute } from '../../../utils/drivingRoute';
import { computeMapJobEta } from '../../valeter/ValeterMapJobMarker';
import type { DashboardSheetPanel } from '../../valeter/ValeterDashboardBottomSheet';
import { valeterMapHeaderTotalHeight } from '../../valeter/ValeterMapHeader';
import { valeterNavHeaderTotalHeight } from '../../valeter/ValeterNavHeader';
import { toast } from '../../shared/ToastHost';
import {
  ARRIVE_ENTER_M,
  ARRIVE_EXIT_M,
  NAV_COURSE_MIN_SPEED,
  NAV_HEADING_DEADBAND,
  NAV_PITCH,
  NAV_STEP_MS,
  NAV_TURN_CLOSE_M,
  NAV_VIEW,
  OFF_ROUTE_M,
  REROUTE_MS,
  HOME_ZOOM_DELTA,
  MIN_FIT_DELTA,
} from './constants';
import { pointAhead, type HeaderTrip } from './tripHelpers';
import type { ActiveJob, Coords, JobRequest, LatLng, SetState, TrackingState } from './types';

type MapRef = React.RefObject<MapView | null>;
type NavFix = ReturnType<typeof useNavLocation>;
export type MapPadding = { top: number; bottom: number; left: number; right: number };
type JobPoint = Readonly<{ id: string; location_lat?: number | null; location_lng?: number | null }>;

/** Where the Pro sits on the idle map: their picked work base when set, otherwise live GPS. */
export function useHomeCoords(gps: Coords, base: Readonly<{ lat: number; lng: number }> | null): Coords {
  const baseLat = base?.lat;
  const baseLng = base?.lng;
  return useMemo(() => {
    if (baseLat == null || baseLng == null) return gps;
    return { latitude: baseLat, longitude: baseLng, altitude: null, accuracy: 0, altitudeAccuracy: null, heading: null, speed: null };
  }, [gps, baseLat, baseLng]);
}

export function useMapOrigin(coords: Coords) {
  const mapOrigin = useMemo(() => {
    if (coords?.latitude != null && coords?.longitude != null) {
      return { lat: coords.latitude, lng: coords.longitude };
    }
    return null;
  }, [coords?.latitude, coords?.longitude]);

  const jobMapEta = useCallback(
    (jobLat: number, jobLng: number) => {
      if (!mapOrigin) return null;
      return computeMapJobEta(mapOrigin.lat, mapOrigin.lng, jobLat, jobLng);
    },
    [mapOrigin]
  );

  return { mapOrigin, jobMapEta };
}

export function useMapPadding(topInset: number, sheetBottomPad: number, navHeaderShown: boolean): MapPadding {
  return useMemo(
    () => ({
      top: (navHeaderShown ? valeterNavHeaderTotalHeight(topInset) : valeterMapHeaderTotalHeight(topInset)) + 8,
      bottom: sheetBottomPad + 12,
      left: 20,
      right: 20,
    }),
    [topInset, sheetBottomPad, navHeaderShown]
  );
}

function jobPoint(job: JobPoint | null | undefined) {
  if (job?.location_lat != null && job?.location_lng != null) {
    return { lat: job.location_lat, lng: job.location_lng };
  }
  return null;
}

function findFocusedTarget(
  focusedJobId: string | null,
  activeJob: ActiveJob | null,
  jobRequests: readonly JobRequest[],
  upcomingJobs: readonly JobPoint[]
) {
  if (focusedJobId == null) return null;
  const active = activeJob?.id === focusedJobId ? jobPoint(activeJob) : null;
  if (active) return active;
  const request = jobPoint(jobRequests.find((j) => j.id === focusedJobId));
  if (request) return request;
  return jobPoint(upcomingJobs.find((j) => j.id === focusedJobId));
}

/** Which job the map is focused on, and the driving route to it. */
export function useFocusedJob(
  o: Readonly<{
    coords: Coords;
    isTrackingMode: boolean;
    sheetPanel: DashboardSheetPanel;
    focusedJobId: string | null;
    setFocusedJobId: SetState<string | null>;
    displayActiveJob: ActiveJob | null;
    displayJobRequests: JobRequest[];
    displayUpcomingJobs: any[];
  }>
) {
  const { coords, isTrackingMode, sheetPanel, focusedJobId, setFocusedJobId } = o;
  const { displayActiveJob, displayJobRequests, displayUpcomingJobs } = o;
  const [focusedDrivingRoute, setFocusedDrivingRoute] = useState<LatLng[] | null>(null);

  const focusedRouteTarget = useMemo(
    () => findFocusedTarget(focusedJobId, displayActiveJob, displayJobRequests, displayUpcomingJobs),
    [focusedJobId, displayActiveJob, displayJobRequests, displayUpcomingJobs]
  );

  useEffect(() => {
    if (isTrackingMode || focusedRouteTarget == null || coords?.latitude == null || coords?.longitude == null) {
      setFocusedDrivingRoute(null);
      return;
    }

    let cancelled = false;
    void (async () => {
      const route = await fetchDrivingRoute(
        coords.latitude,
        coords.longitude,
        focusedRouteTarget.lat,
        focusedRouteTarget.lng
      );
      if (cancelled) return;
      setFocusedDrivingRoute(route && route.coordinates.length > 1 ? route.coordinates : null);
    })();

    return () => {
      cancelled = true;
    };
  }, [
    isTrackingMode,
    focusedRouteTarget?.lat,
    focusedRouteTarget?.lng,
    coords?.latitude,
    coords?.longitude,
  ]);

  useEffect(() => {
    if (sheetPanel === 'request') {
      const firstRequest = displayJobRequests.find((r) => r.location_lat != null && r.location_lng != null);
      if (firstRequest) {
        setFocusedJobId((current) => {
          if (current && displayJobRequests.some((r) => r.id === current)) return current;
          return firstRequest.id;
        });
      } else {
        setFocusedJobId(null);
      }
      return;
    }
    if (sheetPanel === 'tracking') {
      if (displayActiveJob?.id && displayActiveJob.location_lat != null && displayActiveJob.location_lng != null) {
        setFocusedJobId(displayActiveJob.id);
      }
      return;
    }
    if (displayActiveJob?.id && displayActiveJob.location_lat != null && displayActiveJob.location_lng != null) {
      setFocusedJobId((current) => {
        if (current && displayJobRequests.some((r) => r.id === current)) return displayActiveJob.id;
        return current ?? displayActiveJob.id;
      });
      return;
    }
    const firstUpcoming = displayUpcomingJobs.find((j) => j.location_lat != null && j.location_lng != null);
    if (firstUpcoming) {
      setFocusedJobId((current) => current ?? firstUpcoming.id);
      return;
    }
    setFocusedJobId(null);
  }, [
    sheetPanel,
    displayJobRequests,
    displayActiveJob?.id,
    displayActiveJob?.location_lat,
    displayActiveJob?.location_lng,
    displayUpcomingJobs,
  ]);

  return { focusedRouteTarget, focusedDrivingRoute };
}

/** Route planned from live GPS while driving (replaces the one planned from the stored origin). */
function useLiveReroute(
  o: Readonly<{
    liveDriving: boolean;
    navFix: NavFix;
    navDest: LatLng | null | undefined;
    navPos: LatLng | null;
    navRoute: LatLng[] | null | undefined;
    liveRoute: LatLng[] | null;
    setLiveRoute: SetState<LatLng[] | null>;
  }>
) {
  const { liveDriving, navFix, navDest, navPos, navRoute, liveRoute, setLiveRoute } = o;
  const lastRerouteRef = useRef(0);

  useEffect(() => {
    if (!liveDriving) setLiveRoute(null);
  }, [liveDriving]);
  const offRouteM = liveDriving ? distanceToRoute(navPos, navRoute) : null;
  useEffect(() => {
    if (!liveDriving || !navFix || !navDest) return;
    const offRoute = offRouteM != null && offRouteM > OFF_ROUTE_M;
    if (liveRoute && !offRoute) return;
    const now = Date.now();
    if (now - lastRerouteRef.current < REROUTE_MS) return;
    lastRerouteRef.current = now;
    void fetchDrivingRoute(navFix.latitude, navFix.longitude, navDest.latitude, navDest.longitude)
      .then((r) => {
        if (r && r.coordinates.length > 1) setLiveRoute(r.coordinates);
      })
      .catch(() => {});
  }, [liveDriving, navFix, navDest, liveRoute, offRouteM]);
}

/** Close to the customer (with hysteresis), plus a one-off haptic + toast on arrival. */
function useNearCustomer(driving: boolean, navPos: LatLng | null, navDest: LatLng | null | undefined) {
  const [nearCustomer, setNearCustomer] = useState(false);
  const customerDistM = driving && navPos && navDest ? metresBetween(navPos, navDest) : null;
  useEffect(() => {
    if (customerDistM == null) {
      setNearCustomer(false);
      return;
    }
    setNearCustomer((was) => (was ? customerDistM < ARRIVE_EXIT_M : customerDistM < ARRIVE_ENTER_M));
  }, [customerDistM]);
  const wasNearRef = useRef(false);
  useEffect(() => {
    if (nearCustomer && !wasNearRef.current) {
      void hapticFeedback('success');
      toast.info("You're at the customer — hold the green button to mark arrived");
    }
    wasNearRef.current = nearCustomer;
  }, [nearCustomer]);
  return nearCustomer;
}

/** Driving state for the trip: route, GPS position, next turn, arrival and voice guidance. */
export function useTripNavigation(
  o: Readonly<{
    headerTrip: HeaderTrip;
    coords: Coords;
    isTrackingMode: boolean;
    tracking: TrackingState;
    focusedDrivingRoute: LatLng[] | null;
  }>
) {
  const { headerTrip, coords, isTrackingMode, tracking, focusedDrivingRoute } = o;
  const [liveRoute, setLiveRoute] = useState<LatLng[] | null>(null);

  const driving = isTrackingMode && tracking.status === 'en_route';
  const liveDriving = driving;
  const navRoute = liveRoute ?? tracking.routeCoordinates;
  const navDest = tracking.customerCoords;

  const mapRouteCoords = useMemo(() => {
    if (isTrackingMode && tracking.routeCoordinates && tracking.routeCoordinates.length > 1) {
      return tracking.routeCoordinates;
    }
    return focusedDrivingRoute;
  }, [isTrackingMode, tracking.routeCoordinates, focusedDrivingRoute]);

  /* While driving, position comes from navigation-grade GPS (~1/s); the slow app-wide fix is the fallback. */
  const navFix = useNavLocation(driving);
  const navPos = useMemo(() => {
    if (navFix) return { latitude: navFix.latitude, longitude: navFix.longitude };
    if (coords?.latitude != null && coords?.longitude != null)
      return { latitude: coords.latitude, longitude: coords.longitude };
    return null;
  }, [navFix, coords?.latitude, coords?.longitude]);

  const routeTurn = useMemo(() => (driving ? routeTurnAhead(navPos, navRoute) : null), [driving, navRoute, navPos]);

  useLiveReroute({ liveDriving, navFix, navDest, navPos, navRoute, liveRoute, setLiveRoute });
  /** While driving, only the road still ahead is drawn. */
  const routeAhead = useMemo(() => (driving ? remainingRoute(navPos, navRoute) : null), [driving, navPos, navRoute]);
  const customerStreet = useMemo(() => streetFromAddress(headerTrip.address), [headerTrip.address]);

  const nearCustomer = useNearCustomer(driving, navPos, navDest);
  const voice = useVoiceGuidance({
    active: driving,
    turn: routeTurn,
    nearby: nearCustomer,
    street: customerStreet,
  });

  return {
    driving,
    navRoute,
    navDest,
    navFix,
    navPos,
    mapRouteCoords,
    routeTurn,
    routeAhead,
    customerStreet,
    nearCustomer,
    voice,
  };
}

/** Sat-nav camera: tilted and heading-up, following the van while driving to the customer. */
export function useNavFollowCamera(
  o: Readonly<{
    mapRef: MapRef;
    driving: boolean;
    navPos: LatLng | null;
    navFix: NavFix;
    navRoute: LatLng[] | null | undefined;
    navDest: LatLng | null | undefined;
    routeTurn: RouteTurn | null;
  }>
) {
  const { mapRef, driving, navPos, navFix, navRoute, navDest, routeTurn } = o;
  const navFollow = driving && navPos != null;
  const [followVan, setFollowVan] = useState(true);
  const navHeadingRef = useRef(0);
  /** False until the first follow shot, which swoops in slowly from the overview like Uber does. */
  const navEngagedRef = useRef(false);
  const navHeading = useMemo(() => {
    if (!navFollow) return null;
    /* GPS course is only trustworthy on the move; below ~7 mph fall back to the route's direction. */
    if (navFix?.course != null && (navFix.speed ?? 0) >= NAV_COURSE_MIN_SPEED) return navFix.course;
    return routeHeading(navPos, navRoute) ?? bearingBetween(navPos, navDest);
  }, [navFollow, navFix, navPos, navRoute, navDest]);
  /** Where the map camera points, so the van can be drawn facing its real direction of travel on screen. */
  const [mapHeading, setMapHeading] = useState(0);
  const syncMapHeading = useCallback(() => {
    void mapRef.current
      ?.getCamera()
      .then((cam) => setMapHeading(cam.heading ?? 0))
      .catch(() => {});
  }, []);
  const vanScreenHeading = navHeading == null ? null : navHeading - mapHeading;
  useEffect(() => {
    if (navFollow) setFollowVan(true);
  }, [navFollow]);
  useEffect(() => {
    if (!navFollow || !followVan) navEngagedRef.current = false;
  }, [navFollow, followVan]);
  const turnClose = routeTurn != null && routeTurn.inMetres <= NAV_TURN_CLOSE_M;
  useEffect(() => {
    if (!navFollow || !followVan || !navPos) return;
    if (
      navHeading != null &&
      Math.abs(((navHeading - navHeadingRef.current + 540) % 360) - 180) >= NAV_HEADING_DEADBAND
    ) {
      navHeadingRef.current = navHeading;
    }
    const view = turnClose ? NAV_VIEW.turn : NAV_VIEW.cruise;
    mapRef.current?.animateCamera(
      {
        center: pointAhead(navPos.latitude, navPos.longitude, navHeadingRef.current, view.lookAheadM),
        pitch: NAV_PITCH,
        heading: navHeadingRef.current,
        zoom: view.zoom,
        altitude: view.altitude,
      },
      { duration: navEngagedRef.current ? NAV_STEP_MS : 1800 }
    );
    navEngagedRef.current = true;
    setMapHeading(navHeadingRef.current);
  }, [navFollow, followVan, navPos, navHeading, turnClose]);

  /* The van glides between GPS fixes over the same time the camera does, so it never jumps. */
  const vanRegion = useRef(
    new AnimatedRegion({
      latitude: 0,
      longitude: 0,
      latitudeDelta: 0,
      longitudeDelta: 0,
    })
  ).current;
  const vanPlacedRef = useRef(false);
  useEffect(() => {
    if (!navFollow || !navPos) {
      vanPlacedRef.current = false;
      return;
    }
    const to = { ...navPos, latitudeDelta: 0, longitudeDelta: 0 };
    if (!vanPlacedRef.current) {
      vanRegion.setValue(to);
      vanPlacedRef.current = true;
      return;
    }
    vanRegion
      .timing({
        ...to,
        toValue: 0,
        duration: NAV_STEP_MS,
        easing: Easing.linear,
        useNativeDriver: false,
      })
      .start();
  }, [navFollow, navPos, vanRegion]);

  return { navFollow, followVan, setFollowVan, syncMapHeading, vanScreenHeading, vanRegion };
}

/** Camera during the trip: close on the customer once there, otherwise framing the whole route. */
export function useTripCamera(
  o: Readonly<{
    mapRef: MapRef;
    isTrackingMode: boolean;
    tripStatus: string | null | undefined;
    navDest: LatLng | null | undefined;
    customerCoords: LatLng | null | undefined;
    navFollow: boolean;
    mapRouteCoords: LatLng[] | null;
    mapPadding: MapPadding;
  }>
) {
  const { mapRef, isTrackingMode, navDest, navFollow, mapRouteCoords, mapPadding } = o;
  /* Once at the customer the camera stays close on their address rather than pulling back to the whole route. */
  const atCustomer = isTrackingMode && (o.tripStatus === 'arrived' || o.tripStatus === 'in_progress');
  const lastDestRef = useRef<LatLng | null>(null);
  if (navDest) lastDestRef.current = navDest;
  const customerSpot = o.customerCoords ?? lastDestRef.current;
  const customerLat = customerSpot?.latitude;
  const customerLng = customerSpot?.longitude;
  useEffect(() => {
    if (!atCustomer || navFollow || customerLat == null || customerLng == null) return;
    mapRef.current?.animateCamera(
      {
        center: { latitude: customerLat, longitude: customerLng },
        zoom: NAV_VIEW.turn.zoom,
        altitude: NAV_VIEW.turn.altitude,
      },
      { duration: 900 }
    );
  }, [atCustomer, navFollow, customerLat, customerLng]);

  useEffect(() => {
    if (atCustomer || !isTrackingMode || navFollow || !mapRouteCoords || mapRouteCoords.length < 2) return;
    const map = mapRef.current;
    if (!map) return;
    map.animateCamera({ pitch: 0, heading: 0 }, { duration: 350 });
    const fit = setTimeout(
      () =>
        map.fitToCoordinates(mapRouteCoords, {
          edgePadding: mapPadding,
          animated: true,
        }),
      380
    );
    return () => clearTimeout(fit);
  }, [atCustomer, isTrackingMode, navFollow, mapRouteCoords, mapPadding]);
}

export function useFocusJobOnMap(
  mapRef: MapRef,
  mapFocusPinnedRef: React.RefObject<boolean>,
  setFocusedJobId: SetState<string | null>,
  coords: Coords
) {
  return useCallback(
    (jobId: string, lat: number, lng: number) => {
      mapFocusPinnedRef.current = true;
      setFocusedJobId(jobId);
      void hapticFeedback('light');
      const vLat = coords?.latitude;
      const vLng = coords?.longitude;
      if (vLat != null && vLng != null) {
        const minLat = Math.min(lat, vLat);
        const maxLat = Math.max(lat, vLat);
        const minLng = Math.min(lng, vLng);
        const maxLng = Math.max(lng, vLng);
        mapRef.current?.animateToRegion(
          {
            latitude: (minLat + maxLat) / 2,
            longitude: (minLng + maxLng) / 2,
            latitudeDelta: Math.max((maxLat - minLat) * 2.8, MIN_FIT_DELTA),
            longitudeDelta: Math.max((maxLng - minLng) * 2.8, MIN_FIT_DELTA),
          },
          450
        );
      } else {
        mapRef.current?.animateToRegion(
          {
            latitude: lat,
            longitude: lng,
            latitudeDelta: HOME_ZOOM_DELTA,
            longitudeDelta: HOME_ZOOM_DELTA,
          },
          450
        );
      }
    },
    [coords?.latitude, coords?.longitude]
  );
}
