import { supabase } from '../../../lib/supabase';
import {
  isInstantBookingOffer,
  valeterHasLiveJob,
  valeterScheduleAllowsJobOffer,
} from '../../../services/valeterScheduleConflict';
import { notifyValeterJobRequest } from '../../../services/valeterJobPhoneNotifications';
import type { JobRequest, JobRequestBooking, SetState, YourJobSheetItem } from './types';

export function haversineMi(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 3959;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function isUpcomingBookingRow(b: Record<string, unknown>, now: number): boolean {
  const scheduledAt = typeof b.scheduled_at === 'string' ? b.scheduled_at : null;
  if (!scheduledAt) return false;
  if (new Date(scheduledAt).getTime() <= now) return false;
  const s = typeof b.status === 'string' ? b.status : '';
  return !['completed', 'cancelled', 'valeter_timeout'].includes(s);
}

function bookingSortTimestamp(row: Record<string, unknown>): number {
  if (typeof row.scheduled_at === 'string') return new Date(row.scheduled_at).getTime();
  if (typeof row.created_at === 'string') return new Date(row.created_at).getTime();
  return 0;
}

export function compareEnrichedBookings(a: Record<string, unknown>, b: Record<string, unknown>, now: number): number {
  const aUp = isUpcomingBookingRow(a, now);
  const bUp = isUpcomingBookingRow(b, now);
  if (aUp && !bUp) return -1;
  if (!aUp && bUp) return 1;
  if (aUp && bUp) return bookingSortTimestamp(a) - bookingSortTimestamp(b);
  return bookingSortTimestamp(b) - bookingSortTimestamp(a);
}

export function optionalNumberCoord(value: unknown): number | null {
  return value == null ? null : Number(value);
}

export function yourJobStatusSubtitle(job: YourJobSheetItem): string {
  if (job._type === 'upcoming') return 'Upcoming';
  if (job.status === 'completed') return 'Completed';
  if (job.status === 'in_progress') return 'Active';
  return 'Confirmed';
}

export function recentBookingStillVisible(b: Record<string, unknown>, thirtyMs: number): boolean {
  const st = typeof b.status === 'string' ? b.status.toLowerCase() : '';
  if (st !== 'completed' && st !== 'valeter_timeout') return true;
  const ref =
    (typeof b.completed_at === 'string' ? b.completed_at : null) ||
    (typeof b.updated_at === 'string' ? b.updated_at : null) ||
    (typeof b.created_at === 'string' ? b.created_at : null);
  if (!ref) return true;
  const t = new Date(ref).getTime();
  if (!Number.isFinite(t)) return true;
  return Date.now() - t <= thirtyMs;
}

async function notifyJobRequestIfAllowed(userId: string, booking: JobRequestBooking): Promise<void> {
  if (isInstantBookingOffer(booking.scheduled_at) && (await valeterHasLiveJob(userId))) {
    return;
  }
  const ok = await valeterScheduleAllowsJobOffer(userId, booking);
  if (!ok) return;
  await notifyValeterJobRequest({
    bookingId: booking.id,
    serviceName: booking.service_name,
    price: booking.price,
    locationAddress: booking.location_address,
    userId,
  });
}

export async function handleJobRequestInsert(
  userId: string,
  booking: JobRequestBooking,
  loadJobRequests: () => void,
  onNewRequest?: () => void
): Promise<void> {
  if (booking.status !== 'pending_valeter_acceptance') return;
  loadJobRequests();
  onNewRequest?.();
  await notifyJobRequestIfAllowed(userId, booking);
}

export function handleJobRequestUpdate(
  userId: string,
  booking: JobRequestBooking,
  loadJobRequests: () => void,
  setJobRequests: SetState<JobRequest[]>,
  onNewRequest?: () => void
): void {
  if (booking.status === 'pending_valeter_acceptance') {
    loadJobRequests();
    onNewRequest?.();
    notifyJobRequestIfAllowed(userId, booking).catch(() => undefined);
    return;
  }
  setJobRequests((prev) => prev.filter((r) => r.id !== booking.id));
}

export function advanceJobRequestTimers(prev: JobRequest[], onTimeout: (jobId: string) => void): JobRequest[] {
  return prev
    .map((req) => {
      if (req.timeRemaining <= 1) {
        onTimeout(req.id);
        return { ...req, timeRemaining: 0 };
      }
      return { ...req, timeRemaining: req.timeRemaining - 1 };
    })
    .filter((req) => req.timeRemaining > 0);
}

export async function loadValeterName(userId: string, authName: string | null | undefined) {
  // 1) valeter_profiles.full_name (primary - saved from profile page)
  try {
    const { data: vp } = await supabase
      .from('valeter_profiles')
      .select('full_name')
      .eq('user_id', userId)
      .maybeSingle();

    const name = (vp?.full_name || '').trim();
    if (name) return name;
  } catch {}

  // 2) profiles.full_name (fallback)
  try {
    const { data: p } = await supabase
      .from('profiles')
      .select('full_name')
      .eq('id', userId)
      .maybeSingle();

    const name = (p?.full_name || '').trim();
    if (name) return name;
  } catch {}

  // 3) auth context / fallback
  const maybe = (authName || '').trim();
  if (maybe) return maybe;

  return 'Car Care Pro';
}
