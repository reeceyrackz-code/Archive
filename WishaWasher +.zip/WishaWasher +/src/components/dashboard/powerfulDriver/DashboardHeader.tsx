import React from 'react';
import { router } from 'expo-router';
import ValeterMapHeader from '../../valeter/ValeterMapHeader';
import ValeterNavHeader from '../../valeter/ValeterNavHeader';
import { requestNavAppPicker } from '../../valeter/NavAppPickerSheet';
import { hapticFeedback } from '../../../services/HapticFeedbackService';
import { getServiceTrackingCategory } from '../../../utils/serviceNameMapper';
import { takeHome } from '../../../utils/valeterEarnings';
import type { RouteTurn } from '../../../utils/routeTurnAhead';
import { SERVICE_NOUN } from './constants';
import type { HeaderTrip } from './tripHelpers';
import type { TodayStats } from './types';

type Props = Readonly<{
  navHeaderShown: boolean;
  headerTrip: HeaderTrip;
  accent: string;
  headerGradient: React.ComponentProps<typeof ValeterMapHeader>['headerGradient'];
  turn: RouteTurn | null;
  street: string | null;
  nearby: boolean;
  voiceMuted: boolean;
  onToggleVoice: () => void;
  profileName: string;
  locationLabel: string;
  profilePictureUri: string | null | undefined;
  todayStats: TodayStats;
  dailyGoal: React.ComponentProps<typeof ValeterMapHeader>['dailyGoal'];
  onEarningsPress: () => void;
  jobRequestCount: number;
  isOnline: boolean;
  onLocationPress: () => void;
  onCustomerPress: (() => void) | undefined;
}>;

/** Sat-nav header for the drive and arrival; the profile / customer header otherwise. */
export default function DashboardHeader(p: Props) {
  const { headerTrip, accent, headerGradient } = p;
  if (p.navHeaderShown) {
    const arrived = headerTrip.status === 'arrived';
    return (
      <ValeterNavHeader
        turn={p.turn}
        etaMin={headerTrip.etaMinutes}
        miles={headerTrip.distanceMi}
        street={p.street}
        accent={accent}
        headerGradient={headerGradient}
        nearby={p.nearby}
        arrived={arrived}
        arrivedAt={arrived ? headerTrip.updatedAt : null}
        serviceNoun={SERVICE_NOUN[getServiceTrackingCategory(headerTrip.serviceType, headerTrip.serviceName)]}
        voiceMuted={p.voiceMuted}
        onToggleVoice={p.onToggleVoice}
        onOpenMaps={requestNavAppPicker}
      />
    );
  }
  return (
    <ValeterMapHeader
      profileName={p.profileName}
      locationLabel={p.locationLabel}
      profilePictureUri={p.profilePictureUri}
      earnings={takeHome(p.todayStats.earnings)}
      jobsCompleted={p.todayStats.jobsCompleted}
      dailyGoal={p.dailyGoal}
      onEarningsPress={p.onEarningsPress}
      jobRequestCount={p.isOnline ? p.jobRequestCount : 0}
      isOnline={p.isOnline}
      accent={accent}
      headerGradient={headerGradient}
      onProfilePress={() => {
        void hapticFeedback('light');
        router.push('/valeter/profile/valeter-profile' as any);
      }}
      onLocationPress={() => {
        void hapticFeedback('light');
        p.onLocationPress();
      }}
      onNotificationsPress={() => router.push('/valeter/notifications')}
      trackingMode={headerTrip.active}
      trackingCustomerName={headerTrip.customerName}
      trackingLocationLabel={headerTrip.address}
      trackingCustomerPhotoUri={headerTrip.photo}
      trackingEtaMinutes={headerTrip.etaMinutes}
      trackingPrice={headerTrip.price}
      trackingPaymentSecondsLeft={headerTrip.paymentSecondsLeft}
      trackingVehicleLabel={headerTrip.vehicleLabel}
      trackingVehicleReg={headerTrip.vehicleReg}
      trackingVehicleCount={headerTrip.vehicleCount}
      onCustomerPress={p.onCustomerPress}
    />
  );
}
