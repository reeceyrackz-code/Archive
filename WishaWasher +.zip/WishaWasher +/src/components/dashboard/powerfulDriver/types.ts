import type React from 'react';
import type { LocationObjectCoords } from 'expo-location';
import type { MarkerAnimated } from 'react-native-maps';
import type { useValeterJobTracking } from '../../../hooks/useValeterJobTracking';

export type TrackingState = ReturnType<typeof useValeterJobTracking>;

export type LatLng = { latitude: number; longitude: number };
export type Coords = LocationObjectCoords | null;

/** AnimatedRegion is the documented input for MarkerAnimated, but the library's types don't line up. */
export type VanCoordinate = React.ComponentProps<typeof MarkerAnimated>['coordinate'];

export type ActiveJob = {
  id: string;
  status: string;
  service_type: string;
  service_name: string | null;
  location_address: string | null;
  location_lat: number | null;
  location_lng: number | null;
  price: number;
  user_id: string | null;
};

export type YourJobSheetItem = {
  id: string;
  service_type?: string | null;
  service_name?: string | null;
  customer_photo?: string | null;
  customer_name?: string | null;
  scheduled_at?: string | null;
  location_address?: string | null;
  price?: number | string | null;
  _type?: string;
  status?: string;
};

export interface JobRequest {
  id: string;
  serviceName: string;
  distance: number;
  driveTimeMinutes?: number;
  price: number;
  customerName: string;
  address: string;
  timeRemaining: number;
  location_lat: number | null;
  location_lng: number | null;
  scheduledAt?: string | null;
  requestSentAt?: string | null;
  serviceType?: string;
  serviceNameRaw?: string | null;
}

export interface TodayStats {
  hoursOnline: string;
  jobsCompleted: number;
  earnings: number;
}

export type JobRequestBooking = {
  id: string;
  status?: string;
  service_name?: string | null;
  price?: number | null;
  location_address?: string | null;
  scheduled_at?: string | null;
  request_sent_at?: string | null;
  created_at?: string | null;
  service_type?: string | null;
};

export type SetState<T> = React.Dispatch<React.SetStateAction<T>>;
