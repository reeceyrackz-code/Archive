import type React from 'react';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { router, useLocalSearchParams } from 'expo-router';
import { supabase } from '../../../lib/supabase';
import { hapticFeedback } from '../../../services/HapticFeedbackService';
import { useValeterJobTracking } from '../../../hooks/useValeterJobTracking';
import { useSyncValeterNavJobRequests } from '../../valeter/ValeterNavSidebar';
import type { DashboardSheetPanel } from '../../valeter/ValeterDashboardBottomSheet';
import { backdropStageFor } from '../../valeter/ValeterStageBackdrop';
import { isActiveTripJobStatus, isInstantBookingOffer, isLiveJobStatus } from '../../../services/valeterScheduleConflict';
import { buildHeaderTrip, sheetLayout, type SheetLayoutInput } from './tripHelpers';
import type { ActiveJob, Coords, JobRequest, SetState, TrackingState, YourJobSheetItem } from './types';

/** Sheet / trip UI state shared across the dashboard. */
export function useDashboardUiState() {
  const [selectedYourJob, setSelectedYourJob] = useState<YourJobSheetItem | null>(null);
  const [focusedJobId, setFocusedJobId] = useState<string | null>(null);
  const [trackingJobId, setTrackingJobId] = useState<string | null>(null);
  /** After "Jobs list", skip auto-reopening tracking for this job until user opens it again. */
  const trackingDismissedJobIdRef = useRef<string | null>(null);
  /** User tapped a job pin/card — keep map on that focus until cleared. */
  const mapFocusPinnedRef = useRef(false);
  const openTracking = useCallback((jobId: string) => {
    trackingDismissedJobIdRef.current = null;
    setTrackingJobId(jobId);
  }, []);
  const [trackingSheetHeight, setTrackingSheetHeight] = useState<number | null>(null);
  const [sheetPanel, setSheetPanel] = useState<DashboardSheetPanel>('request');
  const [tripMinimized, setTripMinimized] = useState(false);
  const [trackingDockHidden, setTrackingDockHidden] = useState(false);
  const [renderedSheetHeight, setRenderedSheetHeight] = useState<number | null>(null);
  const [earningsSheetVisible, setEarningsSheetVisible] = useState(false);
  const [customerProfileOpen, setCustomerProfileOpen] = useState(false);
  const [cancelSheetOpen, setCancelSheetOpen] = useState(false);
  const [reportSheetOpen, setReportSheetOpen] = useState(false);

  return {
    selectedYourJob,
    setSelectedYourJob,
    focusedJobId,
    setFocusedJobId,
    trackingJobId,
    setTrackingJobId,
    trackingDismissedJobIdRef,
    mapFocusPinnedRef,
    openTracking,
    trackingSheetHeight,
    setTrackingSheetHeight,
    sheetPanel,
    setSheetPanel,
    tripMinimized,
    setTripMinimized,
    trackingDockHidden,
    setTrackingDockHidden,
    renderedSheetHeight,
    setRenderedSheetHeight,
    earningsSheetVisible,
    setEarningsSheetVisible,
    customerProfileOpen,
    setCustomerProfileOpen,
    cancelSheetOpen,
    setCancelSheetOpen,
    reportSheetOpen,
    setReportSheetOpen,
  };
}

export type DashboardUiState = ReturnType<typeof useDashboardUiState>;

export function useDashboardRouteParams() {
  const routeParams = useLocalSearchParams<{
    trackingJobId?: string;
    sheet?: string | string[];
    /** Changes on every dock tap so re-opening the same sheet still applies. */
    sheetAt?: string;
  }>();
  const trackingParamId =
    typeof routeParams.trackingJobId === 'string' && routeParams.trackingJobId !== 'undefined'
      ? routeParams.trackingJobId
      : null;
  const sheetParamRaw = routeParams.sheet;
  const sheetParam = Array.isArray(sheetParamRaw) ? sheetParamRaw[0] : sheetParamRaw;
  return { trackingParamId, sheetParam, sheetAt: routeParams.sheetAt };
}

/** The tracked trip: live job tracking, deep links into it, and the active-job realtime channel. */
export function useTrackingSession(
  o: Readonly<{
    userId: string | undefined;
    coords: Coords;
    ui: DashboardUiState;
    trackingParamId: string | null;
    sheetParam: string | undefined;
    sheetAt?: string;
    activeJob: ActiveJob | null;
    loadActiveJob: () => Promise<void>;
    loadRecentBookings: () => Promise<void>;
  }>
) {
  const { userId, coords, trackingParamId, sheetParam, sheetAt, activeJob, loadActiveJob, loadRecentBookings } = o;
  const {
    trackingJobId,
    setTrackingJobId,
    trackingDismissedJobIdRef,
    setTrackingSheetHeight,
    setTripMinimized,
    sheetPanel,
    setSheetPanel,
    openTracking,
  } = o.ui;

  const closeTracking = useCallback(() => {
    setTrackingJobId((current) => {
      if (current) trackingDismissedJobIdRef.current = current;
      return null;
    });
    setTrackingSheetHeight(null);
    setTripMinimized(false);
    setSheetPanel('request');
    if (trackingParamId) {
      router.setParams({ trackingJobId: undefined });
    }
  }, [trackingParamId]);

  const tracking = useValeterJobTracking(trackingJobId, userId ?? null, {
    onClose: closeTracking,
    onJobUpdated: () => {
      void loadActiveJob();
      void loadRecentBookings();
    },
    originLat: coords?.latitude,
    originLng: coords?.longitude,
  });

  /** Resume links (Activity screen, notifications) open the trip sheet for that job. */
  useEffect(() => {
    if (!trackingParamId) return;
    setSheetPanel('tracking');
    openTracking(trackingParamId);
  }, [trackingParamId, sheetAt, openTracking]);

  /** Each dock tap applies once; later job updates must not re-open the sheet it asked for. */
  const appliedSheetRef = useRef<string | null>(null);
  useEffect(() => {
    if (sheetParam !== 'upcoming' && sheetParam !== 'request') return;
    const key = `${sheetParam}:${sheetAt ?? ''}`;
    if (appliedSheetRef.current === key) return;
    appliedSheetRef.current = key;
    // Older links still ask for the scheduled sheet — that lives on its own screen now.
    if (sheetParam === 'upcoming') {
      router.push('/valeter/activity');
      return;
    }
    // Don't yank the valeter out of an active accepted trip.
    if (trackingJobId || (activeJob && isActiveTripJobStatus(activeJob.status))) return;
    setSheetPanel(sheetParam);
  }, [sheetParam, sheetAt, trackingJobId, activeJob?.id, activeJob?.status]);

  useEffect(() => {
    if (sheetPanel !== 'tracking') setTripMinimized(false);
  }, [sheetPanel]);

  useEffect(() => {
    if (!userId) return;
    void loadActiveJob();
    const channel = supabase
      .channel(`valeter-active-job-${userId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'bookings',
          filter: `valeter_id=eq.${userId}`,
        },
        () => {
          void loadActiveJob();
        }
      )
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [userId, loadActiveJob]);

  return { tracking, closeTracking };
}

/** Upcoming jobs and the offers still shown, plus auto-opening the trip when a job goes live. */
export function useJobQueue(
  o: Readonly<{
    recentBookings: any[];
    activeJob: ActiveJob | null;
    trackingJobId: string | null;
    trackingDismissedJobIdRef: React.RefObject<string | null>;
    openTracking: (jobId: string) => void;
    setSheetPanel: SetState<DashboardSheetPanel>;
    jobRequests: JobRequest[];
    setJobRequests: SetState<JobRequest[]>;
    isOnline: boolean;
  }>
) {
  const { recentBookings, activeJob, trackingJobId, trackingDismissedJobIdRef, openTracking, setSheetPanel } = o;
  const { jobRequests, setJobRequests } = o;

  const upcomingJobs = useMemo(() => {
    const now = Date.now();
    return recentBookings
      .filter((b: any) => {
        if (!b.scheduled_at || new Date(b.scheduled_at).getTime() <= now) return false;
        const s = String(b.status);
        return !['completed', 'cancelled', 'valeter_timeout'].includes(s);
      })
      .slice(0, 8);
  }, [recentBookings]);

  // Live-job gating uses real bookings only
  const isOnLiveJob = isLiveJobStatus(activeJob?.status);

  useEffect(() => {
    if (trackingJobId) return;
    if (!activeJob?.id) return;
    if (trackingDismissedJobIdRef.current === activeJob.id) return;
    if (isActiveTripJobStatus(activeJob.status)) {
      setSheetPanel('tracking');
      openTracking(activeJob.id);
    }
  }, [activeJob, trackingJobId, openTracking]);

  // Drop instant “jobs now” as soon as a live job starts (scheduled offers stay if calendar-free)
  useEffect(() => {
    if (!isLiveJobStatus(activeJob?.status)) return;
    setJobRequests((prev) => prev.filter((r) => !isInstantBookingOffer(r.scheduledAt)));
  }, [activeJob?.status, activeJob?.id]);

  const displayJobRequests = useMemo(() => {
    if (!isOnLiveJob) return jobRequests;
    return jobRequests.filter((r) => !isInstantBookingOffer(r.scheduledAt));
  }, [jobRequests, isOnLiveJob]);

  useSyncValeterNavJobRequests(o.isOnline ? displayJobRequests.length : 0);

  return { displayUpcomingJobs: upcomingJobs, displayJobRequests };
}

/** Whether the trip chrome is up, and the customer details the header / backdrop show for it. */
export function useTripMode(
  o: Readonly<{
    tracking: TrackingState;
    trackingJobId: string | null;
    sheetPanel: DashboardSheetPanel;
    setCustomerProfileOpen: SetState<boolean>;
  }>
) {
  const { tracking, setCustomerProfileOpen } = o;
  const trackingReady = o.trackingJobId != null && !!tracking.job && !tracking.loading;
  /** Full tracking chrome (header + sheet) only while the Tracking tab is active. */
  const isTrackingMode = o.sheetPanel === 'tracking' && trackingReady;

  /** Customer details for the header during a trip. */
  const headerTrip = useMemo(
    () => buildHeaderTrip(tracking, isTrackingMode),
    [isTrackingMode, tracking]
  );
  const backdropStage = backdropStageFor(headerTrip.status);

  useEffect(() => {
    if (!isTrackingMode) setCustomerProfileOpen(false);
  }, [isTrackingMode]);

  /* Sat-nav header replaces the customer header for the drive and the arrived step. */
  const navHeaderShown = headerTrip.active && (headerTrip.status === 'en_route' || headerTrip.status === 'arrived');

  return { isTrackingMode, headerTrip, backdropStage, navHeaderShown };
}

export function useSheetLayout(o: SheetLayoutInput) {
  return sheetLayout(o);
}

export function useTripPanelHandlers(
  displayActiveJob: ActiveJob | null,
  setSheetPanel: SetState<DashboardSheetPanel>,
  openTracking: (jobId: string) => void
) {
  const handleOpenTrip = () => {
    if (!displayActiveJob?.id) return;
    void hapticFeedback('light');
    setSheetPanel('tracking');
    openTracking(displayActiveJob.id);
  };

  const handleSheetPanelChange = useCallback(
    (next: DashboardSheetPanel) => {
      // Tracking is trip mode — only entered via Accept / Resume / deep link, not as a browse tab.
      if (next === 'tracking') {
        if (displayActiveJob?.id) {
          setSheetPanel('tracking');
          openTracking(displayActiveJob.id);
        }
        return;
      }
      // Stay locked in trip until the job completes or is cancelled.
      if (displayActiveJob && isActiveTripJobStatus(displayActiveJob.status)) {
        return;
      }
      setSheetPanel(next);
    },
    [displayActiveJob, openTracking]
  );

  return { handleOpenTrip, handleSheetPanelChange };
}
