import {
  VALETER_SHEET_FIXED_HEIGHT,
  VALETER_DOCK_ROW_HEIGHT,
  valeterTripPeekSheetHeight,
  valeterCompactBrowseSheetHeight,
  valeterOffersSheetHeight,
} from '../../valeter/ValeterDashboardBottomSheet';
import type { DashboardSheetPanel } from '../../valeter/ValeterDashboardBottomSheet';
import type { DockTrip, DockTripAction } from '../../valeter/ValeterDashboardFloatingDock';
import type { ValeterGateInput, ValeterRoadInput, ValeterBackdropJob } from '../../valeter/ValeterStageBackdrop';
import type { RouteTurn } from '../../../utils/routeTurnAhead';
import { isChatLockedUntilPaid } from '../../../utils/trackingStatusHelpers';
import { isActiveTripJobStatus } from '../../../services/valeterScheduleConflict';
import { takeHome } from '../../../utils/valeterEarnings';
import { toast } from '../../shared/ToastHost';
import { STEP_ICONS } from './constants';
import type { TrackingState } from './types';

/** The live tracked job's details for the header. */
function tripSource(tracking: TrackingState) {
  return {
    customerName: tracking.customerName,
    photo: tracking.customerPhotoUrl,
    etaMinutes: tracking.etaMinutes,
    distanceMi: tracking.distanceMi,
    job: tracking.job,
    details: tracking.vehicleDetails,
    vehicles: tracking.bookingVehicles,
    jobVehicle: tracking.job,
  };
}

function tripVehicle(src: ReturnType<typeof tripSource>) {
  const first = src.vehicles?.[0];
  const make = src.details?.make ?? first?.make ?? src.jobVehicle?.vehicle_make ?? null;
  const model = src.details?.model ?? first?.model ?? src.jobVehicle?.vehicle_model ?? null;
  const reg = src.details?.registration ?? first?.registration ?? src.jobVehicle?.vehicle_registration ?? null;
  const label = [make, model].filter(Boolean).join(' ').trim() || null;
  const hasVehicle = Boolean(label || reg);
  return {
    vehicleLabel: label,
    vehicleReg: reg,
    vehicleColour: src.details?.colour ?? first?.colour ?? null,
    vehiclePhoto: (src.details && 'photo' in src.details ? src.details.photo : null) || first?.photo || src.jobVehicle?.vehicle_photo || null,
    vehicleCount: Math.max(src.vehicles?.length ?? 0, Number(hasVehicle)),
  };
}

function tripPaymentSeconds(tracking: TrackingState, isTrackingMode: boolean) {
  if (isTrackingMode && tracking.status === 'pending_payment') return tracking.paymentSecondsLeft;
  return null;
}

export function dockStep(
  next: { label: string; action: () => void } | null | undefined,
  status: string | null | undefined
): DockTripAction | null {
  if (!next) return null;
  return {
    label: next.label,
    icon: STEP_ICONS[status ?? ''] ?? 'arrow-forward',
    onConfirm: next.action,
  };
}

export function dockWaiting(status: string | null | undefined): DockTrip['waiting'] {
  if (status === 'pending_payment')
    return {
      label: 'Awaiting pay',
      icon: 'hourglass-outline',
      color: '#FBBF24',
    };
  if (status === 'completed') return { label: 'Job done', icon: 'sparkles', color: '#4ADE80' };
  return null;
}

function addOnIdsText(raw: unknown): string | null {
  if (Array.isArray(raw)) return raw.join(',');
  return typeof raw === 'string' ? raw : null;
}

/** Customer details for the header during a trip. */
export function buildHeaderTrip(tracking: TrackingState, isTrackingMode: boolean) {
  const src = tripSource(tracking);
  const job = src.job;
  const rawPrice = job?.price;
  const price = rawPrice != null && rawPrice !== '' ? Number(rawPrice) : Number.NaN;
  return {
    active: isTrackingMode,
    customerName: src.customerName,
    photo: src.photo,
    address: job?.location_address ?? undefined,
    etaMinutes: src.etaMinutes,
    distanceMi: src.distanceMi,
    status: isTrackingMode ? tracking.status : null,
    jobId: job?.id ?? null,
    serviceType: job?.service_type ?? null,
    serviceName: job?.service_name ?? null,
    washType: job?.wash_type ?? null,
    addOnIds: addOnIdsText(job?.add_on_ids),
    updatedAt: job?.updated_at ?? null,
    price: Number.isFinite(price) ? price : null,
    paymentSecondsLeft: tripPaymentSeconds(tracking, isTrackingMode),
    ...tripVehicle(src),
  };
}

export type HeaderTrip = ReturnType<typeof buildHeaderTrip>;

/** Height the map keeps clear for the trip sheet, before it has measured itself. */
function trackingSheetPad(
  o: Readonly<{
    tripLocked: boolean;
    tripMinimized: boolean;
    trackingSheetHeight: number | null;
    trackingDockHidden: boolean;
    bottomInset: number;
  }>
) {
  const dock = o.trackingDockHidden ? 0 : VALETER_DOCK_ROW_HEIGHT;
  if (o.tripLocked && o.tripMinimized) {
    return valeterTripPeekSheetHeight(o.bottomInset) - (VALETER_DOCK_ROW_HEIGHT - dock);
  }
  return (
    Math.max(VALETER_SHEET_FIXED_HEIGHT, o.trackingSheetHeight ?? VALETER_SHEET_FIXED_HEIGHT) +
    dock +
    Math.max(o.bottomInset, 8)
  );
}

/** Height the map keeps clear for the offers sheet. */
function browseSheetPad(
  o: Readonly<{
    compactEmptyOffers: boolean;
    compactOffersWithCards: boolean;
    hasResume: boolean;
    bottomInset: number;
  }>
) {
  const opts = { hasResume: o.hasResume };
  if (o.compactEmptyOffers) return valeterCompactBrowseSheetHeight(o.bottomInset, opts);
  if (o.compactOffersWithCards) return valeterOffersSheetHeight(o.bottomInset, opts);
  return VALETER_SHEET_FIXED_HEIGHT + VALETER_DOCK_ROW_HEIGHT + Math.max(o.bottomInset, 8);
}

export type SheetLayoutInput = Readonly<{
  sheetPanel: DashboardSheetPanel;
  activeJob: Readonly<{ status: string }> | null;
  activeJobLoading: boolean;
  requestCount: number;
  isTrackingMode: boolean;
  renderedSheetHeight: number | null;
  tripMinimized: boolean;
  trackingSheetHeight: number | null;
  trackingDockHidden: boolean;
  bottomInset: number;
}>;

/** Whether the trip is locked in, and how much of the map the sheet covers. */
export function sheetLayout(o: SheetLayoutInput) {
  const tripLocked = !!(o.activeJob && isActiveTripJobStatus(o.activeJob.status));
  const sheetBottomPad = o.isTrackingMode
    ? (o.renderedSheetHeight ??
      trackingSheetPad({
        tripLocked,
        tripMinimized: o.tripMinimized,
        trackingSheetHeight: o.trackingSheetHeight,
        trackingDockHidden: o.trackingDockHidden,
        bottomInset: o.bottomInset,
      }))
    : browseSheetPad({
        compactEmptyOffers: o.sheetPanel === 'request' && o.requestCount === 0,
        compactOffersWithCards: o.sheetPanel === 'request' && o.requestCount > 0,
        hasResume: o.sheetPanel === 'request' && !!o.activeJob && !o.activeJobLoading,
        bottomInset: o.bottomInset,
      });
  return { tripLocked, sheetBottomPad };
}

type MaybePoint = Readonly<{ location_lat?: number | null; location_lng?: number | null }> | null | undefined;

/** The valeter plus every job with a location, for fitting the overview map. */
export function jobPlotPoints(
  coords: Readonly<{ latitude?: number | null; longitude?: number | null }> | null | undefined,
  active: MaybePoint,
  jobs: readonly MaybePoint[]
) {
  const plot: { latitude: number; longitude: number }[] = [];
  if (coords?.latitude != null && coords?.longitude != null)
    plot.push({ latitude: coords.latitude, longitude: coords.longitude });
  for (const j of [active, ...jobs]) {
    if (j?.location_lat != null && j?.location_lng != null)
      plot.push({ latitude: j.location_lat, longitude: j.location_lng });
  }
  return plot;
}

/** The point `metres` ahead of (lat, lng) along a compass heading. */
export function pointAhead(latitude: number, longitude: number, headingDeg: number, metres: number) {
  const h = (headingDeg * Math.PI) / 180;
  const mPerDegLat = 111_320;
  const mPerDegLng = mPerDegLat * Math.cos((latitude * Math.PI) / 180);
  return {
    latitude: latitude + (metres * Math.cos(h)) / mPerDegLat,
    longitude: longitude + (metres * Math.sin(h)) / Math.max(1, mPerDegLng),
  };
}

export function tripEarned(price: number | null) {
  return price != null ? takeHome(price) : null;
}

/** Payment gate card shown while the customer pays (or just has). */
export function stageGate(trip: HeaderTrip, selfPhoto: string | null): ValeterGateInput | null {
  if (trip.status !== 'pending_payment' && trip.status !== 'confirmed') return null;
  return {
    phase: trip.status === 'confirmed' ? 'paid' : 'payment',
    secondsLeft: trip.paymentSecondsLeft,
    earned: tripEarned(trip.price),
    customerName: trip.customerName,
    customerPhoto: trip.photo ?? null,
    selfPhoto,
  };
}

export function stageTrip(
  trip: HeaderTrip,
  o: Readonly<{
    selfPhoto: string | null;
    turn: RouteTurn | null;
    nearby: boolean;
    voiceMuted: boolean;
    onToggleVoice: () => void;
  }>
): ValeterRoadInput | null {
  if (trip.status !== 'en_route' && trip.status !== 'arrived') return null;
  return {
    phase: trip.status,
    etaMin: trip.etaMinutes,
    miles: trip.distanceMi,
    customerName: trip.customerName,
    customerPhoto: trip.photo ?? null,
    selfPhoto: o.selfPhoto,
    turn: o.turn,
    nearby: o.nearby,
    voiceMuted: o.voiceMuted,
    onToggleVoice: o.onToggleVoice,
  };
}

export function stageJob(trip: HeaderTrip, street: string | null): ValeterBackdropJob {
  return {
    id: trip.jobId,
    serviceType: trip.serviceType,
    serviceName: trip.serviceName,
    washType: trip.washType,
    addOnIds: trip.addOnIds,
    updatedAt: trip.updatedAt,
    earned: tripEarned(trip.price),
    isPreview: false,
    vehicleReg: trip.vehicleReg,
    vehicleColour: trip.vehicleColour,
    vehicleLabel: trip.vehicleLabel,
    vehiclePhoto: trip.vehiclePhoto,
    vehicleCount: trip.vehicleCount,
    status: trip.status ?? null,
    customerName: trip.customerName,
    street,
  };
}

type LiveDockInput = Readonly<{
  tracking: TrackingState;
  nearCustomer: boolean;
  tripLocked: boolean;
  minimizeTrip: () => void;
  closeTracking: () => void;
  openCancel: () => void;
  openReport: () => void;
}>;

function liveDockTrip(o: LiveDockInput): DockTrip {
  const { tracking } = o;
  const chatLocked = isChatLockedUntilPaid(tracking.status);
  const step = dockStep(tracking.nextAction, tracking.status);
  return {
    step:
      step && o.nearCustomer && tracking.status === 'en_route' ? { ...step, label: "You're here", icon: 'flag' } : step,
    waiting: dockWaiting(tracking.status),
    onHome: o.tripLocked ? o.minimizeTrip : o.closeTracking,
    chatLocked,
    onChat: chatLocked
      ? () => toast.info(`Chat unlocks once ${tracking.customerName || 'the customer'} has paid`)
      : tracking.handleChat,
    canCancel: tracking.canCancel,
    cancelling: tracking.cancelling,
    onCancel: tracking.canCancel ? o.openCancel : o.openReport,
  };
}

/** Step / chat / cancel controls on the floating dock while the trip sheet is showing. */
export function buildDockTrip(o: LiveDockInput & Readonly<{ trackingContentShown: boolean }>): DockTrip | null {
  return o.trackingContentShown ? liveDockTrip(o) : null;
}

export function trackingDismissHandler(tripLocked: boolean, closeTracking: () => void): (() => void) | undefined {
  return tripLocked ? undefined : closeTracking;
}

export function customerPressHandler(isTrackingMode: boolean, openProfile: () => void): (() => void) | undefined {
  return isTrackingMode ? openProfile : undefined;
}
