import { colors } from '../../../constants/colors';
import type { IconGlyphName } from '../../shared/iconGlyphTypes';

export const SKY = colors.SKY ?? '#38BDF8';
/*
 * Follow camera while driving. Google Maps reads zoom, Apple Maps reads altitude (metres).
 * The camera aims `lookAheadM` in front of the van so the van sits low on screen with the road ahead in view;
 * it pulls out on straights and closes in once a turn is near.
 */
/* Both map SDKs cap tilt (Google at 67.5°, Apple lower when the camera is high), so the camera stays close to keep it. */
export const NAV_PITCH = 67;
/** Sat-nav route line — bright enough to read on a tilted, dark map. */
export const NAV_ROUTE_BLUE = '#38BDF8';
export const NAV_TURN_CLOSE_M = 200;
/** GPS fixes arrive about once a second; camera and van glide over the same time. */
export const NAV_STEP_MS = 1000;
/** ~7 mph: below this the GPS course wanders, so the route direction is used instead. */
export const NAV_COURSE_MIN_SPEED = 3;
/** Ignore heading wobble smaller than this so the map doesn't twitch. */
export const NAV_HEADING_DEADBAND = 4;
export const NAV_VIEW = {
  cruise: { zoom: 18.3, altitude: 170, lookAheadM: 55 },
  turn: { zoom: 19, altitude: 110, lookAheadM: 32 },
} as const;


export const STEP_ICONS: Partial<Record<string, IconGlyphName>> = {
  pending_valeter_acceptance: 'checkmark',
  confirmed: 'navigate',
  scheduled: 'navigate',
  en_route: 'flag',
  arrived: 'play',
  in_progress: 'checkmark-done',
};

export const SERVICE_NOUN = { wash: 'wash', detailing: 'detail', repair: 'repair' } as const;

/** Within this distance of the customer the step button prompts "You're here"; leaves again past the exit radius. */
export const ARRIVE_ENTER_M = 100;
/** Re-plan when the van strays this far from the line, at most once per REROUTE_MS. */
export const OFF_ROUTE_M = 60;
export const REROUTE_MS = 15000;
export const ARRIVE_EXIT_M = 160;

export const STATUS_SPARKLE_ORBITS = [
  { dx: 44, dy: -44, delay: 0, size: 12 },
  { dx: -46, dy: -30, delay: 40, size: 10 },
  { dx: 52, dy: 26, delay: 80, size: 11 },
  { dx: -34, dy: 48, delay: 120, size: 9 },
  { dx: 0, dy: -56, delay: 160, size: 13 },
  { dx: 0, dy: 58, delay: 200, size: 9 },
] as const;

// All statuses that count as "active" — card disappears only when completed or cancelled
export const ACTIVE_JOB_STATUSES = [
  'pending_payment',
  'scheduled',
  'confirmed',
  'en_route',
  'arrived',
  'in_progress',
] as const;

/** Street-level map span (degrees) for the Pro on their own — about 275 m across, like a driver app. */
export const HOME_ZOOM_DELTA = 0.0025;
/** Close street view after the Pro picks a work location — a few roads either side. */
export const STREET_ZOOM_DELTA = 0.0028;
/** How long that street view holds before job pins can reframe the map again. */
export const STREET_HOLD_MS = 12000;
/** Tightest span when framing the Pro together with job pins. */
export const MIN_FIT_DELTA = 0.008;

export const REQUEST_TIMEOUT_SECONDS = 300; // 5 min to accept
/** While online, offers are re-checked this often in case a realtime event was missed. */
export const REQUEST_POLL_MS = 8000;
