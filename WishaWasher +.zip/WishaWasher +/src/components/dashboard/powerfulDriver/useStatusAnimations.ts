import type React from 'react';
import { useCallback, useEffect, useRef, useState } from 'react';
import { Animated, Dimensions, Easing } from 'react-native';
import { STATUS_SPARKLE_ORBITS } from './constants';

function useStatusRingAnimations(
  isOnline: boolean,
  statusRingPulse: Animated.Value,
  statusSheenAnim: Animated.Value,
  statusRingLoopRef: React.RefObject<Animated.CompositeAnimation | null>,
  statusSheenLoopRef: React.RefObject<Animated.CompositeAnimation | null>
) {
  useEffect(() => {
    statusRingLoopRef.current?.stop?.();
    statusSheenLoopRef.current?.stop?.();
    statusRingPulse.setValue(0);
    statusRingLoopRef.current = Animated.loop(
      Animated.sequence([
        Animated.timing(statusRingPulse, {
          toValue: 1,
          duration: isOnline ? 1800 : 2200,
          easing: Easing.out(Easing.cubic),
          useNativeDriver: true,
        }),
        Animated.timing(statusRingPulse, {
          toValue: 0,
          duration: 0,
          useNativeDriver: true,
        }),
      ])
    );
    statusRingLoopRef.current.start();

    if (isOnline) {
      statusSheenAnim.setValue(0);
      statusSheenLoopRef.current = Animated.loop(
        Animated.timing(statusSheenAnim, {
          toValue: 1,
          duration: 5400,
          easing: Easing.linear,
          useNativeDriver: true,
        })
      );
      statusSheenLoopRef.current.start();
    } else {
      statusSheenAnim.setValue(0);
    }

    return () => {
      statusRingLoopRef.current?.stop?.();
      statusSheenLoopRef.current?.stop?.();
    };
  }, [isOnline, statusRingPulse, statusSheenAnim, statusRingLoopRef, statusSheenLoopRef]);
}

function useStatusMorphAnimation(isOnline: boolean, loadingPresence: boolean, statusMorphAnim: Animated.Value) {
  useEffect(() => {
    if (loadingPresence) return;
    Animated.timing(statusMorphAnim, {
      toValue: isOnline ? 1 : 0,
      duration: isOnline ? 640 : 520,
      easing: Easing.inOut(Easing.cubic),
      useNativeDriver: true,
    }).start();
  }, [isOnline, loadingPresence, statusMorphAnim]);
}

function heroMorph(statusMorphAnim: Animated.Value) {
  return {
    heroMorphOpacity: statusMorphAnim.interpolate({
      inputRange: [0, 0.55, 1],
      outputRange: [1, 0.35, 0],
    }),
    heroMorphScale: statusMorphAnim.interpolate({
      inputRange: [0, 1],
      outputRange: [1, 0.22],
    }),
    heroMorphTranslateY: statusMorphAnim.interpolate({
      inputRange: [0, 1],
      outputRange: [0, -(Dimensions.get('window').height * 0.34)],
    }),
    heroMorphRotate: statusMorphAnim.interpolate({
      inputRange: [0, 1],
      outputRange: ['0deg', '420deg'],
    }),
    mapOfflineTintOpacity: statusMorphAnim.interpolate({
      inputRange: [0, 1],
      outputRange: [1, 0],
    }),
  };
}

export type HeroMorph = ReturnType<typeof heroMorph>;

/** Go-online ring pulse, sheen, flash, sparkles, mascot spin and the hero → header morph. */
export function useStatusAnimations(isOnline: boolean, loadingPresence: boolean, initialOnline: boolean | null) {
  const statusRingPulse = useRef(new Animated.Value(0)).current;
  const statusRingLoopRef = useRef<Animated.CompositeAnimation | null>(null);
  const statusSheenAnim = useRef(new Animated.Value(0)).current;
  const statusSheenLoopRef = useRef<Animated.CompositeAnimation | null>(null);
  const statusFlashOpacity = useRef(new Animated.Value(0)).current;
  const statusMascotSpinAnim = useRef(new Animated.Value(0)).current;
  const statusMorphAnim = useRef(new Animated.Value(initialOnline ? 1 : 0)).current;
  const [statusFlashColor, setStatusFlashColor] = useState<string>('#10B981');
  const statusSparkleAnims = useRef<Animated.Value[]>(
    Array.from({ length: STATUS_SPARKLE_ORBITS.length }, () => new Animated.Value(0))
  ).current;

  useStatusRingAnimations(isOnline, statusRingPulse, statusSheenAnim, statusRingLoopRef, statusSheenLoopRef);

  useStatusMorphAnimation(isOnline, loadingPresence, statusMorphAnim);

  const playStatusFlash = (nextOnline: boolean) => {
    setStatusFlashColor(nextOnline ? '#10B981' : '#EF4444');
    statusFlashOpacity.stopAnimation();
    statusFlashOpacity.setValue(0);
    Animated.sequence([
      Animated.timing(statusFlashOpacity, {
        toValue: 0.28,
        duration: 220,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),
      Animated.timing(statusFlashOpacity, {
        toValue: 0.16,
        duration: 160,
        easing: Easing.inOut(Easing.quad),
        useNativeDriver: true,
      }),
      Animated.timing(statusFlashOpacity, {
        toValue: 0,
        duration: 700,
        easing: Easing.in(Easing.quad),
        useNativeDriver: true,
      }),
    ]).start();
  };

  const playStatusSparkles = useCallback(() => {
    statusSparkleAnims.forEach((anim, index) => {
      anim.stopAnimation();
      anim.setValue(0);
      Animated.sequence([
        Animated.delay(STATUS_SPARKLE_ORBITS[index].delay),
        Animated.timing(anim, {
          toValue: 1,
          duration: 850,
          easing: Easing.out(Easing.cubic),
          useNativeDriver: true,
        }),
      ]).start(() => {
        anim.setValue(0);
      });
    });
  }, [statusSparkleAnims]);

  const playMascotSpin = useCallback(() => {
    statusMascotSpinAnim.stopAnimation();
    statusMascotSpinAnim.setValue(0);
    Animated.timing(statusMascotSpinAnim, {
      toValue: 1,
      duration: 560,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start(() => {
      statusMascotSpinAnim.setValue(0);
    });
  }, [statusMascotSpinAnim]);

  return {
    statusFlashColor,
    statusFlashOpacity,
    statusSparkleAnims,
    playStatusFlash,
    playStatusSparkles,
    playMascotSpin,
    statusMascotSpin: statusMascotSpinAnim.interpolate({
      inputRange: [0, 1],
      outputRange: ['0deg', '360deg'],
    }),
    ...heroMorph(statusMorphAnim),
  };
}
