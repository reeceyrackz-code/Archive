import React from 'react';
import ValeterDashboardBottomSheet, { type DashboardSheetPanel } from '../../valeter/ValeterDashboardBottomSheet';
import ValeterJobTrackingSheet from '../../valeter/ValeterJobTrackingSheet';
import {
  buildDockTrip,
  customerPressHandler,
  trackingDismissHandler,
  tripEarned,
  type HeaderTrip,
} from './tripHelpers';
import type { DashboardUiState } from './useDashboardSession';
import type { ActiveJob, JobRequest, TrackingState } from './types';

type BottomSheetProps = React.ComponentProps<typeof ValeterDashboardBottomSheet>;
type SheetGradient = React.ComponentProps<typeof ValeterJobTrackingSheet>['sheetGradient'];

type TrackingContentInput = Readonly<{
  trackingJobId: string | null;
  tracking: TrackingState;
  accent: string;
  headerGradientStops: SheetGradient;
  headerTrip: HeaderTrip;
  closeTracking: () => void;
  setTrackingSheetHeight: (height: number | null) => void;
}>;

/** The trip sheet body for the live tracked job. */
function trackingSheetContent(o: TrackingContentInput): React.ReactNode {
  const { tracking, accent, headerGradientStops, headerTrip } = o;
  const earnedOnTrip = tripEarned(headerTrip.price);
  if (!o.trackingJobId || !tracking.job) return null;
  return (
    <ValeterJobTrackingSheet
      embedded
      accent={accent}
      sheetGradient={headerGradientStops}
      job={tracking.job}
      status={tracking.status}
      statusMessage={tracking.statusMessage}
      customerName={tracking.customerName}
      vehicleDetails={tracking.vehicleDetails}
      bookingVehicles={tracking.bookingVehicles}
      etaMinutes={tracking.etaMinutes}
      distanceMi={tracking.distanceMi}
      stages={tracking.stages}
      stageProgressPercent={tracking.stageProgressPercent}
      onChat={tracking.handleChat}
      onClose={o.closeTracking}
      onMeasuredHeight={o.setTrackingSheetHeight}
      infoSheetVisible={tracking.infoSheetVisible}
      onOpenInfo={() => tracking.setInfoSheetVisible(true)}
      onCloseInfo={() => tracking.setInfoSheetVisible(false)}
      paymentSecondsLeft={headerTrip.paymentSecondsLeft}
      earned={earnedOnTrip}
    />
  );
}

function isTrackingContentShown(ui: DashboardUiState, tracking: TrackingState) {
  return ui.sheetPanel === 'tracking' && !!ui.trackingJobId && !!tracking.job;
}

/** Everything the trip side of the bottom sheet, dock and header needs. */
export function tripSheetBindings(
  o: TrackingContentInput &
    Readonly<{
      ui: DashboardUiState;
      isTrackingMode: boolean;
      tripLocked: boolean;
      nearCustomer: boolean;
    }>
) {
  const { ui, tracking, headerTrip } = o;
  const trackingContentShown = isTrackingContentShown(ui, tracking);
  return {
    trackingContent: trackingSheetContent(o),
    trackingContentHeight: trackingContentShown ? ui.trackingSheetHeight : null,
    roadOnly: trackingContentShown && headerTrip.status === 'en_route',
    dockTrip: buildDockTrip({
      trackingContentShown,
      tracking,
      nearCustomer: o.nearCustomer,
      tripLocked: o.tripLocked,
      minimizeTrip: () => ui.setTripMinimized(true),
      closeTracking: o.closeTracking,
      openCancel: () => ui.setCancelSheetOpen(true),
      openReport: () => ui.setReportSheetOpen(true),
    }),
    trackingDismiss: trackingDismissHandler(o.tripLocked, o.closeTracking),
    customerPress: customerPressHandler(o.isTrackingMode, () => ui.setCustomerProfileOpen(true)),
  };
}

type SheetSource = Pick<
  BottomSheetProps,
  | 'panel'
  | 'focusedJobId'
  | 'activeJob'
  | 'activeJobLoading'
  | 'activeCustomerName'
  | 'jobRequests'
  | 'jobRequestCount'
  | 'onPanelChange'
  | 'tripLocked'
  | 'tripMinimized'
  | 'isOnline'
  | 'onlineBusy'
  | 'onToggleOnline'
  | 'onFocusJobOnMap'
  | 'onActiveJobPress'
  | 'onAcceptJob'
  | 'onDeclineJob'
  | 'refreshing'
  | 'onRefresh'
>;

type LiveSheetInput = Readonly<{
  ui: DashboardUiState;
  activeJob: ActiveJob | null;
  activeJobLoading: boolean;
  activeCustomerName: string;
  jobRequests: JobRequest[];
  onPanelChange: (next: DashboardSheetPanel) => void;
  tripLocked: boolean;
  isOnline: boolean;
  onlineBusy: boolean;
  onToggleOnline: () => void;
  onFocusJobOnMap: (jobId: string, lat: number, lng: number) => void;
  onActiveJobPress: () => void;
  onAcceptJob: (jobId: string) => Promise<void>;
  onDeclineJob: (jobId: string) => Promise<void>;
  refreshing: boolean;
  onRefresh: () => Promise<void>;
}>;

function liveSheetSource(l: LiveSheetInput): SheetSource {
  return {
    panel: l.ui.sheetPanel,
    focusedJobId: l.ui.focusedJobId,
    activeJob: l.activeJob,
    activeJobLoading: l.activeJobLoading,
    activeCustomerName: l.activeCustomerName,
    jobRequests: l.jobRequests,
    jobRequestCount: l.jobRequests.length,
    onPanelChange: l.onPanelChange,
    tripLocked: l.tripLocked,
    tripMinimized: l.ui.tripMinimized,
    isOnline: l.isOnline,
    onlineBusy: l.onlineBusy,
    onToggleOnline: l.onToggleOnline,
    onFocusJobOnMap: l.onFocusJobOnMap,
    onActiveJobPress: l.onActiveJobPress,
    onAcceptJob: l.onAcceptJob,
    onDeclineJob: l.onDeclineJob,
    refreshing: l.refreshing,
    onRefresh: l.onRefresh,
  };
}

/** Bottom-sheet data for the live dashboard. */
export const bottomSheetSource = liveSheetSource;
