import React, { useState } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { ChromeGlyph as Ionicons } from '../../shared/ChromeGlyph';
import InfoBottomSheet from '../../shared/InfoBottomSheet';
import { SKY } from './constants';
import type { LocationPickerState } from './useDashboardActions';

const GREEN = '#34D399';

function CurrentSpot({ picker }: Readonly<{ picker: LocationPickerState }>) {
  const usingGps = picker.workBase == null;
  const label = picker.workBase?.label ?? picker.gpsLabel ?? 'Finding you…';
  return (
    <View style={styles.current}>
      <View style={[styles.currentIcon, { backgroundColor: usingGps ? 'rgba(52,211,153,0.16)' : 'rgba(135,206,235,0.18)' }]}>
        <Ionicons name={usingGps ? 'navigate' : 'location'} size={22} color={usingGps ? GREEN : SKY} />
      </View>
      <View style={styles.copy}>
        <Text style={styles.kicker}>GETTING JOBS AROUND</Text>
        <Text style={styles.currentLabel} numberOfLines={1}>
          {label}
        </Text>
      </View>
      <View style={[styles.badge, { backgroundColor: usingGps ? 'rgba(52,211,153,0.16)' : 'rgba(135,206,235,0.16)' }]}>
        <View style={[styles.badgeDot, { backgroundColor: usingGps ? GREEN : SKY }]} />
        <Text style={[styles.badgeText, { color: usingGps ? '#A7F3D0' : '#BAE6FD' }]}>{usingGps ? 'Live GPS' : 'Set spot'}</Text>
      </View>
    </View>
  );
}

function SearchField({ picker }: Readonly<{ picker: LocationPickerState }>) {
  const { locationSearchQuery: query, setLocationSearchQuery: setQuery, locationSearching: searching } = picker;
  const [focused, setFocused] = useState(false);
  const canSearch = query.trim().length > 0 && !searching;
  return (
    <View style={[styles.search, focused && styles.searchFocused]}>
      <Ionicons name="search" size={18} color={focused ? SKY : 'rgba(203,213,225,0.6)'} />
      <TextInput
        style={styles.searchInput}
        placeholder="Postcode, street or town"
        placeholderTextColor="rgba(203,213,225,0.45)"
        value={query}
        onChangeText={setQuery}
        onSubmitEditing={() => void picker.handleSearchLocation()}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        returnKeyType="search"
        autoCorrect={false}
      />
      {query.length > 0 && !searching ? (
        <Pressable onPress={() => setQuery('')} hitSlop={10} accessibilityLabel="Clear search">
          <Ionicons name="close-circle" size={18} color="rgba(203,213,225,0.55)" />
        </Pressable>
      ) : null}
      <Pressable
        onPress={() => void picker.handleSearchLocation()}
        disabled={!canSearch}
        style={({ pressed }) => [styles.go, !canSearch && styles.goDisabled, pressed && styles.pressed]}
        accessibilityLabel="Set this location"
      >
        {searching ? <ActivityIndicator size="small" color="#04121F" /> : <Text style={styles.goText}>Set</Text>}
      </Pressable>
    </View>
  );
}

function GpsRow({ picker, busy }: Readonly<{ picker: LocationPickerState; busy: boolean }>) {
  const active = picker.workBase == null;
  return (
    <Pressable
      onPress={() => void picker.handleUseCurrentLocation()}
      disabled={busy}
      style={({ pressed }) => [styles.row, active && styles.rowActive, pressed && styles.pressed]}
      accessibilityRole="button"
      accessibilityLabel="Use my live location"
    >
      <View style={[styles.rowIcon, { backgroundColor: GREEN }]}>
        <Ionicons name="navigate" size={18} color="#04121F" />
      </View>
      <View style={styles.copy}>
        <Text style={styles.rowTitle}>Use my live location</Text>
        <Text style={styles.rowSub} numberOfLines={1}>
          Jobs follow you as you move
        </Text>
      </View>
      {busy ? <ActivityIndicator size="small" color={GREEN} /> : null}
      {!busy && active ? <Ionicons name="checkmark-circle" size={20} color={GREEN} /> : null}
      {!busy && !active ? <Ionicons name="chevron-forward" size={18} color="rgba(203,213,225,0.5)" /> : null}
    </Pressable>
  );
}

function RecentRows({ picker }: Readonly<{ picker: LocationPickerState }>) {
  if (picker.recentBases.length === 0) return null;
  const current = picker.workBase?.label.toLowerCase();
  return (
    <>
      <Text style={styles.section}>RECENT</Text>
      {picker.recentBases.map((b) => {
        const active = b.label.toLowerCase() === current;
        return (
          <Pressable
            key={b.label.toLowerCase()}
            onPress={() => void picker.handlePickRecent(b)}
            style={({ pressed }) => [styles.row, active && styles.rowActiveSky, pressed && styles.pressed]}
            accessibilityRole="button"
            accessibilityLabel={`Get jobs around ${b.label}`}
          >
            <View style={[styles.rowIcon, styles.rowIconMuted]}>
              <Ionicons name="time-outline" size={18} color="#E2E8F0" />
            </View>
            <Text style={[styles.rowTitle, styles.copy]} numberOfLines={1}>
              {b.label}
            </Text>
            {active ? (
              <Ionicons name="checkmark-circle" size={20} color={SKY} />
            ) : (
              <Ionicons name="chevron-forward" size={18} color="rgba(203,213,225,0.5)" />
            )}
          </Pressable>
        );
      })}
    </>
  );
}

export default function LocationPickerModal({
  picker,
  locationLoading,
}: Readonly<{
  picker: LocationPickerState;
  locationLoading: boolean;
}>) {
  return (
    <InfoBottomSheet
      visible={picker.showLocationPicker}
      onClose={() => picker.setShowLocationPicker(false)}
      title="Where do you want jobs?"
      accentColor={SKY}
      variant="header"
      sizeToContent
    >
      <View style={styles.root}>
        <CurrentSpot picker={picker} />
        <SearchField picker={picker} />
        <GpsRow picker={picker} busy={picker.locating || locationLoading} />
        <RecentRows picker={picker} />
        <View style={styles.hint}>
          <Ionicons name="information-circle-outline" size={14} color="rgba(203,213,225,0.6)" />
          <Text style={styles.hintText}>Customers near this spot see you while you're online. Your map shows it too.</Text>
        </View>
      </View>
    </InfoBottomSheet>
  );
}

const styles = StyleSheet.create({
  root: { gap: 10, paddingBottom: 8 },
  copy: { flex: 1, minWidth: 0 },
  pressed: { opacity: 0.75 },

  current: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 14,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.22)',
    backgroundColor: 'rgba(135,206,235,0.07)',
    marginBottom: 4,
  },
  currentIcon: { width: 46, height: 46, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  kicker: { color: 'rgba(186,230,253,0.75)', fontSize: 10.5, fontWeight: '800', letterSpacing: 1.1, marginBottom: 3 },
  currentLabel: { color: '#F8FAFC', fontSize: 17, fontWeight: '800' },
  badge: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 9, paddingVertical: 5, borderRadius: 999 },
  badgeDot: { width: 6, height: 6, borderRadius: 3 },
  badgeText: { fontSize: 11, fontWeight: '800' },

  search: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    height: 54,
    paddingLeft: 14,
    paddingRight: 6,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  searchFocused: { borderColor: `${SKY}AA`, backgroundColor: 'rgba(135,206,235,0.08)' },
  searchInput: { flex: 1, color: '#F8FAFC', fontSize: 16, fontWeight: '600', paddingVertical: 0 },
  go: { height: 42, paddingHorizontal: 16, borderRadius: 12, backgroundColor: SKY, alignItems: 'center', justifyContent: 'center' },
  goDisabled: { opacity: 0.4 },
  goText: { color: '#04121F', fontSize: 14, fontWeight: '800' },

  section: { color: 'rgba(203,213,225,0.6)', fontSize: 10.5, fontWeight: '800', letterSpacing: 1.1, marginTop: 6, marginLeft: 4 },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 12,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    backgroundColor: 'rgba(255,255,255,0.04)',
  },
  rowActive: { borderColor: 'rgba(52,211,153,0.5)', backgroundColor: 'rgba(52,211,153,0.08)' },
  rowActiveSky: { borderColor: `${SKY}88`, backgroundColor: 'rgba(135,206,235,0.08)' },
  rowIcon: { width: 38, height: 38, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  rowIconMuted: { backgroundColor: 'rgba(255,255,255,0.08)' },
  rowTitle: { color: '#F8FAFC', fontSize: 15, fontWeight: '800' },
  rowSub: { color: 'rgba(203,213,225,0.75)', fontSize: 12, fontWeight: '600', marginTop: 2 },

  hint: { flexDirection: 'row', alignItems: 'flex-start', gap: 6, paddingHorizontal: 4, paddingTop: 4 },
  hintText: { flex: 1, color: 'rgba(203,213,225,0.6)', fontSize: 12, fontWeight: '600', lineHeight: 17 },
});
