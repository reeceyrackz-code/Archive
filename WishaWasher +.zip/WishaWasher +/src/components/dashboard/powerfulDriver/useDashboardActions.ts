import { useCallback, useEffect, useState } from 'react';
import * as Location from 'expo-location';
import { supabase } from '../../../lib/supabase';
import { hapticFeedback } from '../../../services/HapticFeedbackService';
import { valeterStripeConnectService } from '../../../services/valeterStripeConnectService';
import {
  assertNoScheduleConflictForOffer,
  isInstantBookingOffer,
  valeterHasLiveJob,
} from '../../../services/valeterScheduleConflict';
import { syncValeterExternalCalendarBusyToSupabase } from '../../../services/valeterExternalCalendarBusy';
import { ensureValeterOnlineReady } from '../../../utils/valeterOnlineReadiness';
import {
  clearWorkBase,
  loadRecentBases,
  loadWorkBase,
  needsAreaName,
  placeName,
  presenceCoords,
  saveWorkBase,
  type WorkBase,
} from '../../../utils/valeterWorkBase';
import type { DashboardSheetPanel } from '../../valeter/ValeterDashboardBottomSheet';
import { toast } from '../../shared/ToastHost';
import type { JobRequest, SetState } from './types';

/** Online / offline toggle, gated on Stripe Connect and a ready profile. */
export function usePresenceToggle(
  o: Readonly<{
    userId: string | undefined;
    isOnline: boolean;
    setIsOnline: SetState<boolean>;
    loadingPresence: boolean;
    toggling: boolean;
    setToggling: SetState<boolean>;
    playStatusSparkles: () => void;
    playMascotSpin: () => void;
    playStatusFlash: (nextOnline: boolean) => void;
  }>
) {
  const { userId, isOnline, setIsOnline, loadingPresence, toggling, setToggling } = o;

  const ensureStripeConnectComplete = useCallback(async () => {
    if (!userId) return false;
    try {
      const stripeStatus = await valeterStripeConnectService.getStatus(userId);
      if (stripeStatus.stripeConnectStatus === 'completed') {
        return true;
      }
    } catch (error) {
      console.warn('[presence] stripe status check failed:', error);
    }
    toast.error('Complete Stripe Connect before you go online or accept washes.', 'Stripe Connect required');
    return false;
  }, [userId]);

  const goOnlineWithLocation = async () => {
    const uid = userId;
    if (!uid) throw new Error('not-signed-in');
    const coords = await presenceCoords(uid, true);
    if (!coords) {
      toast.error('Location permission is required to go online so customers can find you.', 'Permission needed');
      throw new Error('location-permission-denied');
    }

    const { error } = await supabase.rpc('update_my_presence', {
      p_is_online: true,
      p_last_lat: coords.lat,
      p_last_lng: coords.lng,
    });
    if (error) throw error;
    syncValeterExternalCalendarBusyToSupabase(uid, true).catch(() => undefined);
  };

  const goOffline = async () => {
    const { error } = await supabase.rpc('set_online', { p_is_online: false });
    if (error) throw error;
  };

  const toggleOnline = async () => {
    try {
      if (!userId) return;
      setToggling(true);
      await hapticFeedback('medium');

      if (isOnline) {
        await goOffline();
      } else {
        await goOnlineWithLocation();
      }

      setIsOnline(!isOnline);
    } catch (e) {
      console.error('[presence] toggle error', e);
      toast.error('Could not update your online status. Try again.');
    } finally {
      setToggling(false);
    }
  };

  const handleToggleOnline = async () => {
    if (loadingPresence || toggling) return;
    if (!isOnline) {
      if (!userId) return;
      const canGoOnline = await ensureStripeConnectComplete();
      if (!canGoOnline) return;
      const profileReady = await ensureValeterOnlineReady(userId);
      if (!profileReady) return;
      o.playStatusSparkles();
      o.playMascotSpin();
    }
    o.playStatusFlash(!isOnline);
    await toggleOnline();
  };

  return { handleToggleOnline, ensureStripeConnectComplete };
}

/** Accept / decline a pending offer. */
export function useJobOfferActions(
  o: Readonly<{
    userId: string | undefined;
    jobRequests: JobRequest[];
    setJobRequests: SetState<JobRequest[]>;
    ensureStripeConnectComplete: () => Promise<boolean>;
    setSheetPanel: SetState<DashboardSheetPanel>;
    openTracking: (jobId: string) => void;
    loadActiveJob: () => Promise<void>;
  }>
) {
  const { userId, jobRequests, setJobRequests } = o;

  const handleAcceptJob = async (jobId: string) => {
    if (!userId) return;
    try {
      const canAccept = await o.ensureStripeConnectComplete();
      if (!canAccept) return;
      await hapticFeedback('medium');
      const req = jobRequests.find((r) => r.id === jobId);
      if (isInstantBookingOffer(req?.scheduledAt) && (await valeterHasLiveJob(userId))) {
        toast.info(
          'Finish or cancel your current job before accepting jobs now. Scheduled bookings are still available when that time is free on your calendar.',
          'On a job'
        );
        setJobRequests((prev) => prev.filter((r) => !isInstantBookingOffer(r.scheduledAt)));
        return;
      }
      const gate = await assertNoScheduleConflictForOffer(userId, {
        scheduled_at: req?.scheduledAt,
        request_sent_at: req?.requestSentAt,
        service_type: req?.serviceType,
        service_name: req?.serviceNameRaw,
      });
      if (!gate.ok) {
        toast.error(gate.message, 'Schedule clash');
        return;
      }
      const { error } = await supabase
        .from('bookings')
        .update({
          valeter_id: userId,
          status: 'pending_payment',
          valeter_response_at: new Date().toISOString(),
        })
        .eq('id', jobId);

      if (error) throw error;

      setJobRequests((prev) => prev.filter((r) => r.id !== jobId));
      o.setSheetPanel('tracking');
      o.openTracking(jobId);
      await o.loadActiveJob();
    } catch (e: any) {
      toast.error(e.message || 'Failed to accept job');
    }
  };

  const handleDeclineJob = async (jobId: string) => {
    try {
      await hapticFeedback('light');
      const { error } = await supabase
        .from('bookings')
        .update({
          status: 'valeter_declined',
          valeter_response_at: new Date().toISOString(),
        })
        .eq('id', jobId);

      if (error) throw error;
      setJobRequests((prev) => prev.filter((r) => r.id !== jobId));
    } catch (e: any) {
      toast.error(e.message || 'Failed to decline job');
    }
  };

  return { handleAcceptJob, handleDeclineJob };
}

/** Location picker sheet: use GPS, or geocode a typed place. */
export function useLocationPicker(
  o: Readonly<{
    userId: string | undefined;
    isOnline: boolean;
    cityLabel: string | null | undefined;
    refresh: () => Promise<unknown>;
  }>
) {
  const { userId, isOnline, refresh } = o;
  const [showLocationPicker, setShowLocationPicker] = useState(false);
  const [workBase, setWorkBase] = useState<WorkBase | null>(null);
  const [locationSearchQuery, setLocationSearchQuery] = useState('');
  const [locationSearching, setLocationSearching] = useState(false);
  const [locating, setLocating] = useState(false);
  const [recentBases, setRecentBases] = useState<WorkBase[]>([]);
  /** Bumped whenever the Pro picks a spot, so the map can fly there. */
  const [flyTo, setFlyTo] = useState<Readonly<{ lat: number; lng: number; at: number }> | null>(null);

  const displayLocationLabel = workBase?.label ?? o.cityLabel ?? 'Set location';

  useEffect(() => {
    if (!userId) return;
    let alive = true;
    Promise.all([loadWorkBase(userId), loadRecentBases(userId)])
      .then(async ([base, recent]) => {
        if (!alive) return;
        setWorkBase(base);
        setRecentBases(recent);
        if (!base || !needsAreaName(base.label)) return;
        const name = await placeName(base.lat, base.lng);
        if (!alive || !name) return;
        const named = { ...base, label: name };
        setWorkBase(named);
        setRecentBases(await saveWorkBase(userId, named));
      })
      .catch(() => undefined);
    return () => {
      alive = false;
    };
  }, [userId]);

  const applyBase = async (base: WorkBase) => {
    setWorkBase(base);
    setFlyTo({ lat: base.lat, lng: base.lng, at: Date.now() });
    if (userId) setRecentBases(await saveWorkBase(userId, base));
    if (userId && isOnline) {
      await supabase.rpc('update_my_presence', {
        p_is_online: true,
        p_last_lat: Number(base.lat.toFixed(6)),
        p_last_lng: Number(base.lng.toFixed(6)),
      });
    }
    setShowLocationPicker(false);
    setLocationSearchQuery('');
    void hapticFeedback('success');
    toast.success(
      isOnline ? `You'll now get jobs around ${base.label}.` : `You'll get jobs around ${base.label} when you go online.`,
      'Work location set'
    );
  };

  const handlePickRecent = async (base: WorkBase) => {
    try {
      await applyBase(base);
    } catch (e) {
      console.warn('[Dashboard] pick recent location error', e);
      toast.error('Could not set that location. Try again.');
    }
  };

  const handleUseCurrentLocation = async () => {
    try {
      setLocating(true);
      await hapticFeedback('light');
      setWorkBase(null);
      if (userId) await clearWorkBase(userId);
      const { status } = await Location.getForegroundPermissionsAsync();
      if (status !== 'granted') {
        const req = await Location.requestForegroundPermissionsAsync();
        if (req.status !== 'granted') {
          toast.error('Location permission is required to use current location.', 'Permission needed');
          return;
        }
      }
      const loc = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });
      const lat = Number(loc.coords.latitude.toFixed(6));
      const lng = Number(loc.coords.longitude.toFixed(6));
      setFlyTo({ lat, lng, at: Date.now() });
      if (userId && isOnline) {
        await supabase.rpc('update_my_presence', {
          p_is_online: true,
          p_last_lat: lat,
          p_last_lng: lng,
        });
      }
      await refresh();
      setShowLocationPicker(false);
      toast.success("You'll get jobs around wherever you are.", 'Using your GPS');
    } catch (e) {
      console.warn('[Dashboard] use current location error', e);
      toast.error('Could not get current location. Try again.');
    } finally {
      setLocating(false);
    }
  };

  const handleSearchLocation = async () => {
    const query = locationSearchQuery.trim();
    if (!query) return;
    try {
      setLocationSearching(true);
      await hapticFeedback('light');
      const results = await Location.geocodeAsync(query);
      if (results && results.length > 0) {
        const { latitude: lat, longitude: lng } = results[0];
        const label = (await placeName(lat, lng)) ?? query;
        await applyBase({ label, lat, lng });
      } else {
        toast.error('No location found for that address. Try a different search.', 'No results');
      }
    } catch (e) {
      console.warn('[Dashboard] geocode error', e);
      toast.error('Could not find that location. Try again.');
    } finally {
      setLocationSearching(false);
    }
  };

  return {
    showLocationPicker,
    setShowLocationPicker,
    locationSearchQuery,
    setLocationSearchQuery,
    locationSearching,
    locating,
    workBase,
    recentBases,
    flyTo,
    gpsLabel: o.cityLabel ?? null,
    displayLocationLabel,
    handleUseCurrentLocation,
    handleSearchLocation,
    handlePickRecent,
  };
}

export type LocationPickerState = ReturnType<typeof useLocationPicker>;
