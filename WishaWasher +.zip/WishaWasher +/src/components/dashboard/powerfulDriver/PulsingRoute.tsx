import React, { useEffect, useMemo, useState } from 'react';
import { Polyline } from 'react-native-maps';

type LatLng = { latitude: number; longitude: number };

const TRAVEL_MS = 1800;
const REST_MS = 500;
const FRAME_MS = 50;
/** Comet length as a share of the whole route. */
const TAIL = 0.14;

function metres(a: LatLng, b: LatLng) {
  const dLat = (b.latitude - a.latitude) * 111_320;
  const dLng = (b.longitude - a.longitude) * 111_320 * Math.cos((a.latitude * Math.PI) / 180);
  return Math.hypot(dLat, dLng);
}

/** Cumulative distance along the route, normalised to 0..1 at each vertex. */
function routeStops(coords: readonly LatLng[]): number[] {
  const acc = [0];
  for (let i = 1; i < coords.length; i++) acc.push(acc[i - 1] + metres(coords[i - 1], coords[i]));
  const total = acc.at(-1) || 1;
  return acc.map((d) => d / total);
}

function pointAt(coords: readonly LatLng[], stops: readonly number[], t: number): { point: LatLng; index: number } {
  let i = 1;
  while (i < stops.length - 1 && stops[i] < t) i++;
  const span = stops[i] - stops[i - 1] || 1;
  const k = Math.min(1, Math.max(0, (t - stops[i - 1]) / span));
  const a = coords[i - 1];
  const b = coords[i];
  return {
    point: { latitude: a.latitude + (b.latitude - a.latitude) * k, longitude: a.longitude + (b.longitude - a.longitude) * k },
    index: i,
  };
}

/** The slice of the route between two progress values, cut at exact points so the comet glides smoothly. */
function sliceRoute(coords: readonly LatLng[], stops: readonly number[], from: number, to: number): LatLng[] {
  const start = pointAt(coords, stops, from);
  const end = pointAt(coords, stops, to);
  return [start.point, ...coords.slice(start.index, end.index), end.point];
}

/**
 * Preview route to a focused job: a soft glow under the line and a bright comet that runs along
 * the real road path from the Pro to the customer, on repeat.
 */
export default function PulsingRoute({ coordinates, accent }: Readonly<{ coordinates: LatLng[]; accent: string }>) {
  const stops = useMemo(() => routeStops(coordinates), [coordinates]);
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const started = Date.now();
    const cycle = TRAVEL_MS + REST_MS;
    const id = setInterval(() => {
      const elapsed = (Date.now() - started) % cycle;
      setPhase(Math.min(1 + TAIL, (elapsed / TRAVEL_MS) * (1 + TAIL)));
    }, FRAME_MS);
    return () => clearInterval(id);
  }, [coordinates]);

  const head = Math.min(1, phase);
  const tail = Math.max(0, phase - TAIL);
  const comet = head - tail > 0.002 ? sliceRoute(coordinates, stops, tail, head) : null;

  return (
    <>
      <Polyline coordinates={coordinates} strokeColor={`${accent}40`} strokeWidth={9} lineJoin="round" lineCap="round" zIndex={1} />
      <Polyline coordinates={coordinates} strokeColor={accent} strokeWidth={3} lineJoin="round" lineCap="round" zIndex={2} />
      {comet ? (
        <>
          <Polyline coordinates={comet} strokeColor={`${accent}88`} strokeWidth={10} lineJoin="round" lineCap="round" zIndex={3} />
          <Polyline coordinates={comet} strokeColor="#FFFFFF" strokeWidth={4} lineJoin="round" lineCap="round" zIndex={4} />
        </>
      ) : null}
    </>
  );
}
