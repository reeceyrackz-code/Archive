// app/valeter/PowerfulDriverDashboard.tsx
import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { View, StyleSheet, StatusBar, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import MapView, { AnimatedRegion, Marker, MarkerAnimated, Polygon, Polyline, Region } from 'react-native-maps';
import { useAuth } from '../../providers/enhanced-auth-context';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import { supabase } from '../../lib/supabase';
import { presenceCoords } from '../../utils/valeterWorkBase';
import useLiveLocation from '../../hooks/useLiveLocation';
import ValeterDashboardBottomSheet from '../valeter/ValeterDashboardBottomSheet';
import type { DashboardSheetPanel } from '../valeter/ValeterDashboardBottomSheet';
import { useValeterDailyGoal } from '../../utils/valeterEarnings';
import { registerPushToken } from '../../services/registerPushToken';
import { preparePhoneNotifications } from '../../services/valeterJobPhoneNotifications';
import { MASCOT_MAP_STYLE } from '../../constants/mapStyles';
import { MAP_LOCKED_DARK } from '../../constants/mapConstants';

/**
 * Apple Maps ignores custom styles, so the mascot navy is laid over the whole world as a polygon.
 * Overlays draw above roads but below labels, markers and routes, so those stay crisp.
 */
const MAP_TINT = 'rgba(15,59,120,0.42)';
const MAP_TINT_RING = [-180, -90, 0, 90, 179.9]
  .map((longitude) => ({ latitude: 85, longitude }))
  .concat([179.9, 90, 0, -90, -180].map((longitude) => ({ latitude: -85, longitude })));
import ValeterMapJobMarker from '../valeter/ValeterMapJobMarker';
import ValeterVanMarker from '../valeter/ValeterVanMarker';
import ValeterMapDroplet from '../valeter/ValeterMapDroplet';
import PulsingRoute from './powerfulDriver/PulsingRoute';
import ValeterMapOfferMarker from '../valeter/ValeterMapOfferMarker';
import {
  HOME_ZOOM_DELTA,
  MIN_FIT_DELTA,
  NAV_ROUTE_BLUE,
  STREET_HOLD_MS,
  STREET_ZOOM_DELTA,
} from './powerfulDriver/constants';
import { loadValeterName } from './powerfulDriver/bookingHelpers';
import { dashboardPalette } from './powerfulDriver/palette';
import { jobPlotPoints } from './powerfulDriver/tripHelpers';
import { useStatusAnimations } from './powerfulDriver/useStatusAnimations';
import {
  useActiveJob,
  useDashboardRefresh,
  useDashboardStats,
  useJobRequestsFeed,
  useNavDashboardStatsSync,
  useRecentBookings,
} from './powerfulDriver/useDashboardData';
import {
  useDashboardRouteParams,
  useDashboardUiState,
  useJobQueue,
  useSheetLayout,
  useTrackingSession,
  useTripMode,
  useTripPanelHandlers,
} from './powerfulDriver/useDashboardSession';
import {
  useFocusJobOnMap,
  useFocusedJob,
  useHomeCoords,
  useMapOrigin,
  useMapPadding,
  useNavFollowCamera,
  useTripCamera,
  useTripNavigation,
  type MapPadding,
} from './powerfulDriver/useMapNavigation';
import { useJobOfferActions, useLocationPicker, usePresenceToggle } from './powerfulDriver/useDashboardActions';
import { bottomSheetSource, tripSheetBindings } from './powerfulDriver/tripSheet';
import {
  DashboardStageBackdrop,
  MapOverlays,
  RecenterButton,
  StatusHeroOverlay,
} from './powerfulDriver/DashboardOverlays';
import DashboardHeader from './powerfulDriver/DashboardHeader';
import DashboardSheets from './powerfulDriver/DashboardSheets';
import LocationPickerModal from './powerfulDriver/LocationPickerModal';
import YourJobSheetModal from './powerfulDriver/YourJobSheetModal';
import type {
  ActiveJob,
  Coords,
  JobRequest,
  LatLng,
  SetState,
  TodayStats,
  VanCoordinate,
} from './powerfulDriver/types';

const VAN_MARKER_W = 64;
const VAN_MIN_W = 40;
const VAN_MAX_W = 120;
const VAN_SIZE_STEP = 4;
const AUTO_RECENTRE_MS = 2500;

/** Van width for the current zoom: grows as the map zooms in, in coarse steps so markers rarely re-render. */
function vanWidthForDelta(latitudeDelta: number): number {
  if (!Number.isFinite(latitudeDelta) || latitudeDelta <= 0) return VAN_MARKER_W;
  const raw = VAN_MARKER_W * (HOME_ZOOM_DELTA / latitudeDelta) ** 0.4;
  const clamped = Math.min(VAN_MAX_W, Math.max(VAN_MIN_W, raw));
  return Math.round(clamped / VAN_SIZE_STEP) * VAN_SIZE_STEP;
}

/** Survives dashboard remounts so returning to home doesn't flash "offline" while presence reloads. */
let lastKnownPresence: { userId: string; online: boolean } | null = null;

function cachedOnline(userId: string | undefined): boolean | null {
  if (!userId || lastKnownPresence?.userId !== userId) return null;
  return lastKnownPresence.online;
}

function usePresenceState(userId: string | undefined) {
  const [isOnline, setIsOnline] = useState(() => cachedOnline(userId) ?? false);
  const [loadingPresence, setLoadingPresence] = useState(() => cachedOnline(userId) === null);
  const [toggling, setToggling] = useState(false);
  return { isOnline, setIsOnline, loadingPresence, setLoadingPresence, toggling, setToggling };
}

type PresenceState = ReturnType<typeof usePresenceState>;

/** Initial name / stats / presence load, the presence realtime channel, push setup and a location refresh. */
function usePresenceLifecycle(
  o: Readonly<{
    userId: string | undefined;
    userName: string | null | undefined;
    presence: PresenceState;
    loadRecentBookings: () => Promise<void>;
    setProfileName: SetState<string>;
    setTodayStats: SetState<TodayStats>;
  }>
) {
  const { userId, userName, loadRecentBookings, setProfileName, setTodayStats } = o;
  const { isOnline, setIsOnline, loadingPresence, setLoadingPresence } = o.presence;

  // Load initial online status + subscribe to realtime
  useEffect(() => {
    if (!userId) return;
    let mounted = true;

    void (async () => {
      setLoadingPresence(true);

      // ✅ Name at top should be the valeter's name
      const name = await loadValeterName(userId, userName);
      if (mounted) setProfileName(name);

      // Load recent bookings and today's earnings (real data from jobs)
      const todayStart = new Date();
      todayStart.setHours(0, 0, 0, 0);
      const todayEnd = new Date(todayStart);
      todayEnd.setDate(todayEnd.getDate() + 1);

      const [todayRes] = await Promise.all([
        supabase
          .from('bookings')
          .select('id, status, price, scheduled_at')
          .eq('valeter_id', userId)
          .gte('scheduled_at', todayStart.toISOString())
          .lt('scheduled_at', todayEnd.toISOString()),
        loadRecentBookings(),
      ]);

      if (mounted && todayRes.data) {
        const completedToday = (todayRes.data as any[]).filter((b) => b.status === 'completed');
        const earningsToday = completedToday.reduce((sum: number, b: any) => sum + (Number(b.price) || 0), 0);
        setTodayStats({
          hoursOnline: '0h 0m',
          jobsCompleted: completedToday.length,
          earnings: Math.round(earningsToday * 100) / 100,
        });
      }

      // presence
      const { data, error } = await supabase
        .from('valeter_presence')
        .select('is_online')
        .eq('user_id', userId)
        .maybeSingle();

      if (!mounted) return;
      if (error) console.warn('[presence] read error', error);

      setIsOnline(!!data?.is_online);
      setLoadingPresence(false);
    })();

    const channel = supabase
      .channel('presence-self')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'valeter_presence',
          filter: `user_id=eq.${userId}`,
        },
        (payload) => {
          const row: any = payload.new ?? payload.old;
          if (row && typeof row.is_online === 'boolean') setIsOnline(row.is_online);
        }
      )
      .subscribe();

    return () => {
      mounted = false;
      void supabase.removeChannel(channel);
    };
  }, [userId, loadRecentBookings]);

  useEffect(() => {
    if (userId && !loadingPresence) lastKnownPresence = { userId, online: isOnline };
  }, [userId, isOnline, loadingPresence]);

  useEffect(() => {
    if (!userId) return;
    preparePhoneNotifications().catch(() => undefined);
    registerPushToken().catch(() => undefined);
  }, [userId]);

  // When valeter is already online (e.g. after login), refresh their location once so map/jobs show current position
  const locationRefreshedOnMount = useRef(false);
  useEffect(() => {
    if (!userId || !isOnline || loadingPresence || locationRefreshedOnMount.current) return;
    locationRefreshedOnMount.current = true;
    void (async () => {
      try {
        const coords = await presenceCoords(userId, false);
        if (!coords) return;
        await supabase.rpc('update_my_presence', {
          p_is_online: true,
          p_last_lat: coords.lat,
          p_last_lng: coords.lng,
        });
      } catch (e) {
        console.warn('[ValeterDashboard] Refresh location on load failed:', e);
      }
    })();
  }, [userId, isOnline, loadingPresence]);
}

type MapJob = Readonly<{ id: string; location_lat?: number | null; location_lng?: number | null }>;

/** Starting region: the valeter plus every job pin, or London when nothing is known yet. */
function dashboardRegion(
  coords: Coords,
  activeJob: ActiveJob | null,
  jobRequests: readonly JobRequest[],
  upcomingJobs: readonly MapJob[]
): Region {
    const points: { lat: number; lng: number }[] = [];
    if (coords?.latitude != null && coords?.longitude != null) {
      points.push({ lat: coords.latitude, lng: coords.longitude });
    }
  for (const job of [activeJob, ...jobRequests, ...upcomingJobs]) {
    if (job?.location_lat != null && job?.location_lng != null) {
        points.push({ lat: job.location_lat, lng: job.location_lng });
      }
  }
    if (points.length === 0) {
      const fallback = { lat: 51.5074, lng: -0.1278 };
      return {
        latitude: fallback.lat,
        longitude: fallback.lng,
        latitudeDelta: 0.08,
        longitudeDelta: 0.08,
      };
    }
    if (points.length === 1) {
      return {
        latitude: points[0].lat,
        longitude: points[0].lng,
      latitudeDelta: HOME_ZOOM_DELTA,
      longitudeDelta: HOME_ZOOM_DELTA,
      };
    }
    const minLat = Math.min(...points.map((p) => p.lat));
    const maxLat = Math.max(...points.map((p) => p.lat));
    const minLng = Math.min(...points.map((p) => p.lng));
    const maxLng = Math.max(...points.map((p) => p.lng));
    return {
      latitude: (minLat + maxLat) / 2,
      longitude: (minLng + maxLng) / 2,
    latitudeDelta: Math.max((maxLat - minLat) * 2.6, MIN_FIT_DELTA),
    longitudeDelta: Math.max((maxLng - minLng) * 2.6, MIN_FIT_DELTA),
  };
}

/** Overview camera off-trip: stay on a pinned job, fit every queued job, or recentre on the valeter. */
function useOverviewCamera(
  o: Readonly<{
    mapRef: React.RefObject<MapView | null>;
    mapFocusPinnedRef: React.RefObject<boolean>;
    /** Until this timestamp the camera stays on the street the Pro just picked. */
    streetHoldUntilRef: React.RefObject<number>;
    isTrackingMode: boolean;
    navFollow: boolean;
    sheetPanel: DashboardSheetPanel;
    focusedJobStillValid: boolean;
    coords: Coords;
    displayActiveJob: ActiveJob | null;
    displayJobRequests: JobRequest[];
    displayUpcomingJobs: any[];
    mapPadding: MapPadding;
    /** Bumped when the map should snap back after the Pro moved it by hand. */
    recentreTick: number;
  }>
) {
  const { mapRef, mapFocusPinnedRef, isTrackingMode, navFollow, sheetPanel, focusedJobStillValid, coords } = o;
  const { displayActiveJob, displayJobRequests, displayUpcomingJobs, mapPadding, streetHoldUntilRef, recentreTick } = o;

  const hasQueuedMapJobs = useMemo(() => {
    if (displayActiveJob?.location_lat != null && displayActiveJob?.location_lng != null) return true;
    if (displayJobRequests.some((r) => r.location_lat != null && r.location_lng != null)) return true;
    if (displayUpcomingJobs.some((j) => j.location_lat != null && j.location_lng != null)) return true;
    return false;
  }, [displayActiveJob, displayJobRequests, displayUpcomingJobs]);

  useEffect(() => {
    if (isTrackingMode || navFollow) return;
    const map = mapRef.current;
    if (!map) return;
    if (Date.now() < streetHoldUntilRef.current) return;

    // Keep camera on an explicitly focused job (or tracking tab with active pin)
    if (mapFocusPinnedRef.current && focusedJobStillValid) return;
    if (sheetPanel === 'tracking' && focusedJobStillValid) return;

    // Idle: nothing queued → recenter on valeter
    if (!hasQueuedMapJobs) {
      mapFocusPinnedRef.current = false;
      if (coords?.latitude != null && coords?.longitude != null) {
        map.animateToRegion(
          {
            latitude: coords.latitude,
            longitude: coords.longitude,
            latitudeDelta: HOME_ZOOM_DELTA,
            longitudeDelta: HOME_ZOOM_DELTA,
          },
          400
        );
      }
      return;
    }

    const plot = jobPlotPoints(coords, displayActiveJob, [...displayJobRequests, ...displayUpcomingJobs]);
    if (plot.length >= 2) {
      map.fitToCoordinates(plot, { edgePadding: mapPadding, animated: true });
    } else if (plot.length === 1) {
      map.animateToRegion({ ...plot[0], latitudeDelta: HOME_ZOOM_DELTA, longitudeDelta: HOME_ZOOM_DELTA }, 400);
    }
  }, [
    isTrackingMode,
    navFollow,
    sheetPanel,
    focusedJobStillValid,
    hasQueuedMapJobs,
    coords?.latitude,
    coords?.longitude,
    displayActiveJob?.id,
    displayActiveJob?.location_lat,
    displayActiveJob?.location_lng,
    displayJobRequests,
    displayUpcomingJobs,
    mapPadding,
    recentreTick,
  ]);
}

/** After the Pro pans or pinches the map, glide back to them once they've left it alone for a few seconds. */
function useAutoRecentre(navFollow: boolean, setFollowVan: SetState<boolean>) {
  const [recentreTick, setRecentreTick] = useState(0);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const navFollowRef = useRef(navFollow);
  navFollowRef.current = navFollow;

  useEffect(
    () => () => {
      if (timer.current) clearTimeout(timer.current);
    },
    []
  );

  const onUserMovedMap = useCallback(() => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => {
      timer.current = null;
      if (navFollowRef.current) setFollowVan(true);
      else setRecentreTick((t) => t + 1);
    }, AUTO_RECENTRE_MS);
  }, [setFollowVan]);

  return { recentreTick, onUserMovedMap };
}

/** Fly to the spot the Pro just picked, zoomed into the street, and hold there briefly. */
function useStreetFlyTo(
  o: Readonly<{
    mapRef: React.RefObject<MapView | null>;
    flyTo: Readonly<{ lat: number; lng: number; at: number }> | null;
    blocked: boolean;
    mapFocusPinnedRef: React.RefObject<boolean>;
    setFocusedJobId: (id: string | null) => void;
    streetHoldUntilRef: React.RefObject<number>;
  }>
) {
  const { mapRef, flyTo, blocked, mapFocusPinnedRef, setFocusedJobId, streetHoldUntilRef } = o;
  useEffect(() => {
    if (!flyTo || blocked) return;
    mapFocusPinnedRef.current = false;
    setFocusedJobId(null);
    streetHoldUntilRef.current = Date.now() + STREET_HOLD_MS;
        mapRef.current?.animateToRegion(
      { latitude: flyTo.lat, longitude: flyTo.lng, latitudeDelta: STREET_ZOOM_DELTA, longitudeDelta: STREET_ZOOM_DELTA },
      700
    );
    // Only a new pick should move the camera.
  }, [flyTo?.at]); // eslint-disable-line react-hooks/exhaustive-deps
}

type MapOrigin = { lat: number; lng: number } | null;
type JobEta = ReturnType<ReturnType<typeof useMapOrigin>['jobMapEta']>;

function VanMarkers({
  width,
  navFollow,
  vanRegion,
  vanScreenHeading,
  mapOrigin,
  accent,
  onTrip,
}: Readonly<{
  width: number;
  onTrip: boolean;
  navFollow: boolean;
  vanRegion: AnimatedRegion;
  vanScreenHeading: number | null;
  mapOrigin: MapOrigin;
  accent: string;
}>) {
  return (
    <>
      {navFollow ? (
        <MarkerAnimated
          coordinate={vanRegion as unknown as VanCoordinate}
          anchor={{ x: 0.5, y: 0.5 }}
          title="You"
          tracksViewChanges
          zIndex={10}
        >
          <ValeterVanMarker accent={accent} width={width} heading={vanScreenHeading} />
        </MarkerAnimated>
      ) : null}
      {mapOrigin && !navFollow ? (
          <Marker
            coordinate={{ latitude: mapOrigin.lat, longitude: mapOrigin.lng }}
            anchor={{ x: 0.5, y: 0.5 }}
            title="You"
            tracksViewChanges
            zIndex={10}
          >
          {onTrip ? (
            <ValeterVanMarker accent={accent} width={width} />
          ) : (
            <ValeterMapDroplet accent={accent} size={width} />
          )}
          </Marker>
        ) : null}
    </>
  );
}

function RouteLines({
  routeAhead,
  mapRouteCoords,
  accent,
  isTrackingMode,
}: Readonly<{
  routeAhead: LatLng[] | null;
  mapRouteCoords: LatLng[] | null;
  accent: string;
  isTrackingMode: boolean;
}>) {
  const routeWidth = isTrackingMode ? 5 : 3;
  return (
    <>
      {routeAhead ? (
        <>
          <Polyline
            coordinates={routeAhead}
            strokeColor="rgba(3,18,38,0.85)"
            strokeWidth={12}
            lineJoin="round"
            lineCap="round"
            zIndex={1}
          />
          <Polyline
            coordinates={routeAhead}
            strokeColor={NAV_ROUTE_BLUE}
            strokeWidth={7}
            lineJoin="round"
            lineCap="round"
            zIndex={2}
          />
        </>
      ) : null}
      {!routeAhead && !isTrackingMode && mapRouteCoords ? <PulsingRoute coordinates={mapRouteCoords} accent={accent} /> : null}
      {!routeAhead && isTrackingMode && mapRouteCoords ? (
          <Polyline
            coordinates={mapRouteCoords}
            strokeColor={accent}
          strokeWidth={routeWidth}
            lineJoin="round"
            lineCap="round"
          />
        ) : null}
    </>
  );
}

function JobMarkers({
  accent,
  upcomingJobs,
  activeJob,
  jobRequests,
  focusedJobId,
  jobMapEta,
  focusJobOnMap,
}: Readonly<{
  accent: string;
  upcomingJobs: any[];
  activeJob: ActiveJob | null;
  jobRequests: JobRequest[];
  focusedJobId: string | null;
  jobMapEta: (jobLat: number, jobLng: number) => JobEta;
  focusJobOnMap: (jobId: string, lat: number, lng: number) => void;
}>) {
  const upcomingPins = upcomingJobs.filter(
    (job) => job.location_lat != null && job.location_lng != null && job.id !== activeJob?.id
  );
  const requestPins = jobRequests.filter(
    (req) => req.location_lat != null && req.location_lng != null && req.id !== activeJob?.id
  );
  return (
    <>
      {upcomingPins.map((job) => {
        const eta = jobMapEta(job.location_lat, job.location_lng);
        return (
          <Marker
            key={`upcoming-${job.id}`}
            coordinate={{ latitude: job.location_lat, longitude: job.location_lng }}
            anchor={{ x: 0.5, y: 1 }}
            tracksViewChanges
            onPress={() => focusJobOnMap(job.id, job.location_lat, job.location_lng)}
          >
            <ValeterMapJobMarker
              accent={accent}
              ringColor="rgba(148,163,184,0.28)"
              size="sm"
              focused={focusedJobId === job.id}
              etaMinutes={eta?.etaMinutes}
              distanceMi={eta?.distanceMi}
              label="Owner"
            />
          </Marker>
        );
      })}

      {activeJob?.location_lat != null && activeJob?.location_lng != null ? (
        <Marker
          coordinate={{ latitude: activeJob.location_lat, longitude: activeJob.location_lng }}
          anchor={{ x: 0.5, y: 1 }}
          tracksViewChanges
          onPress={() => focusJobOnMap(activeJob.id, activeJob.location_lat!, activeJob.location_lng!)}
        >
          <ValeterMapJobMarker
            accent={accent}
            ringColor="rgba(16,185,129,0.35)"
            size="lg"
            focused={focusedJobId === activeJob.id}
            etaMinutes={jobMapEta(activeJob.location_lat, activeJob.location_lng)?.etaMinutes}
            distanceMi={jobMapEta(activeJob.location_lat, activeJob.location_lng)?.distanceMi}
            label="Owner"
          />
        </Marker>
      ) : null}

      {requestPins.map((req) => {
        const lat = req.location_lat as number;
        const lng = req.location_lng as number;
        return (
          <Marker
            key={`request-${req.id}`}
            coordinate={{ latitude: lat, longitude: lng }}
            anchor={{ x: 0.5, y: 0.5 }}
            tracksViewChanges
            onPress={() => focusJobOnMap(req.id, lat, lng)}
            zIndex={focusedJobId === req.id ? 9 : 5}
          >
            <ValeterMapOfferMarker focused={focusedJobId === req.id} />
          </Marker>
        );
      })}
    </>
  );
}

type DashboardMapProps = Readonly<{
  mapRef: React.RefObject<MapView | null>;
  initialRegion: Region;
  mapPadding: MapPadding;
  mapOrigin: MapOrigin;
  navFollow: boolean;
  followVan: boolean;
  setFollowVan: SetState<boolean>;
  onUserMovedMap: () => void;
  syncMapHeading: () => void;
  vanRegion: AnimatedRegion;
  vanScreenHeading: number | null;
  accent: string;
  routeAhead: LatLng[] | null;
  mapRouteCoords: LatLng[] | null;
  isTrackingMode: boolean;
  upcomingJobs: any[];
  activeJob: ActiveJob | null;
  jobRequests: JobRequest[];
  focusedJobId: string | null;
  jobMapEta: (jobLat: number, jobLng: number) => JobEta;
  focusJobOnMap: (jobId: string, lat: number, lng: number) => void;
}>;

function DashboardMap(p: DashboardMapProps) {
  const freeCamera = p.navFollow && !p.followVan;
  const [vanWidth, setVanWidth] = useState(() => vanWidthForDelta(p.initialRegion.latitudeDelta));
  const onRegionChange = (region: Region) => {
    const next = vanWidthForDelta(region.latitudeDelta);
    setVanWidth((prev) => (prev === next ? prev : next));
  };
  return (
    <MapView
      ref={p.mapRef}
      style={StyleSheet.absoluteFill}
      initialRegion={p.initialRegion}
      mapPadding={p.mapPadding}
      showsUserLocation={!p.mapOrigin}
      showsMyLocationButton={false}
      customMapStyle={MASCOT_MAP_STYLE}
      userInterfaceStyle={MAP_LOCKED_DARK}
      onPanDrag={() => {
        if (p.navFollow) p.setFollowVan(false);
        p.onUserMovedMap();
      }}
      onTouchEnd={p.onUserMovedMap}
      onRegionChange={onRegionChange}
      onRegionChangeComplete={freeCamera ? p.syncMapHeading : undefined}
    >
      {Platform.OS === 'ios' ? (
        <Polygon coordinates={MAP_TINT_RING} fillColor={MAP_TINT} strokeWidth={0} strokeColor="transparent" tappable={false} />
      ) : null}
      <VanMarkers
        width={vanWidth}
        onTrip={p.isTrackingMode}
        navFollow={p.navFollow}
        vanRegion={p.vanRegion}
        vanScreenHeading={p.vanScreenHeading}
        mapOrigin={p.mapOrigin}
        accent={p.accent}
      />
      <RouteLines
        routeAhead={p.routeAhead}
        mapRouteCoords={p.mapRouteCoords}
        accent={p.accent}
        isTrackingMode={p.isTrackingMode}
      />
      <JobMarkers
        accent={p.accent}
        upcomingJobs={p.upcomingJobs}
        activeJob={p.activeJob}
        jobRequests={p.jobRequests}
        focusedJobId={p.focusedJobId}
        jobMapEta={p.jobMapEta}
        focusJobOnMap={p.focusJobOnMap}
      />
    </MapView>
  );
}

export default function PowerfulDriverDashboard() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const palette = dashboardPalette(theme);
  const { accent, headerGradientStops } = palette;
  const userId = user?.id;

  const presence = usePresenceState(userId);
  const { recentBookings, loadRecentBookings } = useRecentBookings(userId);
  const stats = useDashboardStats(userId);
  const active = useActiveJob(userId);
  const { activeJob: displayActiveJob, activeJobLoading, loadActiveJob } = active;
  const ui = useDashboardUiState();
  const dailyGoal = useValeterDailyGoal();
  const { trackingParamId, sheetParam, sheetAt } = useDashboardRouteParams();

  const { coords, cityLabel, loading: locationLoading, refresh } = useLiveLocation();

  const status = useStatusAnimations(presence.isOnline, presence.loadingPresence, cachedOnline(userId));

  usePresenceLifecycle({
    userId,
    userName: user?.name,
    presence,
    loadRecentBookings,
    setProfileName: stats.setProfileName,
    setTodayStats: stats.setTodayStats,
  });

  useNavDashboardStatsSync(stats.todayStats, presence.isOnline, displayActiveJob);

  const { jobRequests, setJobRequests, loadJobRequests } = useJobRequestsFeed(
    userId,
    presence.isOnline,
    displayActiveJob?.status
  );

  const location = useLocationPicker({ userId, isOnline: presence.isOnline, cityLabel, refresh });

  const { tracking, closeTracking } = useTrackingSession({
    userId,
    coords,
    ui,
    trackingParamId,
    sheetParam,
    sheetAt,
    activeJob: displayActiveJob,
    loadActiveJob,
    loadRecentBookings,
  });

  const { refreshing, onRefresh } = useDashboardRefresh({
    userId,
    userName: user?.name,
    setProfileName: stats.setProfileName,
    loadActiveJob,
    loadJobRequests,
    loadTodayStats: stats.loadTodayStats,
    loadRecentBookings,
  });

  const { displayUpcomingJobs, displayJobRequests } = useJobQueue({
    recentBookings,
    activeJob: displayActiveJob,
    trackingJobId: ui.trackingJobId,
    trackingDismissedJobIdRef: ui.trackingDismissedJobIdRef,
    openTracking: ui.openTracking,
    setSheetPanel: ui.setSheetPanel,
    jobRequests,
    setJobRequests,
    isOnline: presence.isOnline,
  });

  const trip = useTripMode({
    tracking,
    trackingJobId: ui.trackingJobId,
    sheetPanel: ui.sheetPanel,
    setCustomerProfileOpen: ui.setCustomerProfileOpen,
  });
  const { isTrackingMode, headerTrip } = trip;

  const mapCoords = useHomeCoords(coords, isTrackingMode ? null : location.workBase);
  const { mapOrigin, jobMapEta } = useMapOrigin(mapCoords);

  const layout = useSheetLayout({
    sheetPanel: ui.sheetPanel,
    activeJob: displayActiveJob,
    activeJobLoading,
    requestCount: displayJobRequests.length,
    isTrackingMode,
    renderedSheetHeight: ui.renderedSheetHeight,
    tripMinimized: ui.tripMinimized,
    trackingSheetHeight: ui.trackingSheetHeight,
    trackingDockHidden: ui.trackingDockHidden,
    bottomInset: insets.bottom,
  });
  const { tripLocked, sheetBottomPad } = layout;

  const mapRef = useRef<MapView | null>(null);
  const mapPadding = useMapPadding(insets.top, sheetBottomPad, trip.navHeaderShown);

  const dashboardMapRegion = useMemo(
    () => dashboardRegion(mapCoords, displayActiveJob, displayJobRequests, displayUpcomingJobs),
    [mapCoords, displayActiveJob, displayJobRequests, displayUpcomingJobs]
  );

  const { focusedRouteTarget, focusedDrivingRoute } = useFocusedJob({
    coords: mapCoords,
    isTrackingMode,
    sheetPanel: ui.sheetPanel,
    focusedJobId: ui.focusedJobId,
    setFocusedJobId: ui.setFocusedJobId,
    displayActiveJob,
    displayJobRequests,
    displayUpcomingJobs,
  });

  const nav = useTripNavigation({
    headerTrip,
    coords,
    isTrackingMode,
    tracking,
    focusedDrivingRoute,
  });

  const follow = useNavFollowCamera({
    mapRef,
    driving: nav.driving,
    navPos: nav.navPos,
    navFix: nav.navFix,
    navRoute: nav.navRoute,
    navDest: nav.navDest,
    routeTurn: nav.routeTurn,
  });

  const streetHoldUntilRef = useRef(0);
  const { recentreTick, onUserMovedMap } = useAutoRecentre(follow.navFollow, follow.setFollowVan);
  useOverviewCamera({
    recentreTick,
    mapRef,
    mapFocusPinnedRef: ui.mapFocusPinnedRef,
    streetHoldUntilRef,
    isTrackingMode,
    navFollow: follow.navFollow,
    sheetPanel: ui.sheetPanel,
    focusedJobStillValid: focusedRouteTarget != null,
    coords: mapCoords,
    displayActiveJob,
    displayJobRequests,
    displayUpcomingJobs,
    mapPadding,
  });

  useStreetFlyTo({
    mapRef,
    flyTo: location.flyTo,
    blocked: isTrackingMode || follow.navFollow,
    mapFocusPinnedRef: ui.mapFocusPinnedRef,
    setFocusedJobId: ui.setFocusedJobId,
    streetHoldUntilRef,
  });

  useTripCamera({
    mapRef,
    isTrackingMode,
    tripStatus: headerTrip.status,
    navDest: nav.navDest,
    customerCoords: tracking.customerCoords,
    navFollow: follow.navFollow,
    mapRouteCoords: nav.mapRouteCoords,
    mapPadding,
  });

  const focusJobOnMap = useFocusJobOnMap(mapRef, ui.mapFocusPinnedRef, ui.setFocusedJobId, mapCoords);
  const { handleOpenTrip, handleSheetPanelChange } = useTripPanelHandlers(
    displayActiveJob,
    ui.setSheetPanel,
    ui.openTracking
  );

  const { handleToggleOnline, ensureStripeConnectComplete } = usePresenceToggle({
    ...presence,
    userId,
    playStatusSparkles: status.playStatusSparkles,
    playMascotSpin: status.playMascotSpin,
    playStatusFlash: status.playStatusFlash,
  });
  const { handleAcceptJob, handleDeclineJob } = useJobOfferActions({
    userId,
    jobRequests,
    setJobRequests,
    ensureStripeConnectComplete,
    setSheetPanel: ui.setSheetPanel,
    openTracking: ui.openTracking,
    loadActiveJob,
  });

  const onlineBusy = presence.loadingPresence || presence.toggling;
  const selfPhoto = user?.profilePicture ?? null;
  const sheetInset = ui.renderedSheetHeight ?? sheetBottomPad;

  const tripBindings = tripSheetBindings({
    trackingJobId: ui.trackingJobId,
    tracking,
    accent,
    headerGradientStops,
    headerTrip,
    closeTracking,
    setTrackingSheetHeight: ui.setTrackingSheetHeight,
    ui,
    isTrackingMode,
    tripLocked,
    nearCustomer: nav.nearCustomer,
  });

  const sheetSource = bottomSheetSource({
    ui,
    activeJob: displayActiveJob,
    activeJobLoading,
    activeCustomerName: active.displayCustomerName,
    jobRequests: displayJobRequests,
    onPanelChange: handleSheetPanelChange,
    tripLocked,
    isOnline: presence.isOnline,
    onlineBusy,
    onToggleOnline: handleToggleOnline,
    onFocusJobOnMap: focusJobOnMap,
    onActiveJobPress: handleOpenTrip,
    onAcceptJob: handleAcceptJob,
    onDeclineJob: handleDeclineJob,
    refreshing,
    onRefresh,
  });

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />
      <DashboardMap
        mapRef={mapRef}
        initialRegion={dashboardMapRegion}
        mapPadding={mapPadding}
        mapOrigin={mapOrigin}
        navFollow={follow.navFollow}
        followVan={follow.followVan}
        setFollowVan={follow.setFollowVan}
        onUserMovedMap={onUserMovedMap}
        syncMapHeading={follow.syncMapHeading}
        vanRegion={follow.vanRegion}
        vanScreenHeading={follow.vanScreenHeading}
        accent={accent}
        routeAhead={nav.routeAhead}
        mapRouteCoords={nav.mapRouteCoords}
        isTrackingMode={isTrackingMode}
        upcomingJobs={displayUpcomingJobs}
        activeJob={displayActiveJob}
        jobRequests={displayJobRequests}
        focusedJobId={ui.focusedJobId}
        jobMapEta={jobMapEta}
        focusJobOnMap={focusJobOnMap}
      />
      <MapOverlays
        tintOpacity={status.mapOfflineTintOpacity}
        flashColor={status.statusFlashColor}
        flashOpacity={status.statusFlashOpacity}
      />

      <StatusHeroOverlay
        visible={!isTrackingMode}
        isOnline={presence.isOnline}
        topInset={insets.top}
        sheetBottomPad={sheetBottomPad}
        morph={status}
        busy={onlineBusy}
        onPress={handleToggleOnline}
        mascotSpin={status.statusMascotSpin}
        sparkleAnims={status.statusSparkleAnims}
        accent={accent}
      />

      <DashboardStageBackdrop
        headerTrip={headerTrip}
        stage={trip.backdropStage}
        accent={accent}
        selfPhoto={selfPhoto}
        turn={nav.routeTurn}
        nearby={nav.nearCustomer}
        voiceMuted={nav.voice.muted}
        onToggleVoice={nav.voice.toggleMuted}
        street={nav.customerStreet}
        topInset={insets.top}
        bottomInset={sheetInset}
      />
      <RecenterButton
        navFollow={follow.navFollow}
        followVan={follow.followVan}
        bottom={sheetInset}
        onRecenter={() => follow.setFollowVan(true)}
      />

      <DashboardHeader
        navHeaderShown={trip.navHeaderShown}
        headerTrip={headerTrip}
        accent={accent}
        headerGradient={headerGradientStops}
        turn={nav.routeTurn}
        street={nav.customerStreet}
        nearby={nav.nearCustomer}
        voiceMuted={nav.voice.muted}
        onToggleVoice={nav.voice.toggleMuted}
        profileName={stats.profileName}
        locationLabel={location.displayLocationLabel}
        profilePictureUri={user?.profilePicture}
        todayStats={stats.todayStats}
        dailyGoal={dailyGoal}
        onEarningsPress={() => ui.setEarningsSheetVisible(true)}
        jobRequestCount={displayJobRequests.length}
        isOnline={presence.isOnline}
        onLocationPress={() => location.setShowLocationPicker(true)}
        onCustomerPress={tripBindings.customerPress}
      />

      <DashboardSheets
        userId={userId}
              accent={accent}
        ui={ui}
        tracking={tracking}
        isTrackingMode={isTrackingMode}
        closeTracking={closeTracking}
      />

      <ValeterDashboardBottomSheet
          accent={accent}
        headerGradient={headerGradientStops}
        {...sheetSource}
        onTrackingDismiss={tripBindings.trackingDismiss}
        onTripMinimizedChange={ui.setTripMinimized}
        onTrackingDockHiddenChange={ui.setTrackingDockHidden}
        onSheetHeightChange={ui.setRenderedSheetHeight}
        trip={tripBindings.dockTrip}
        roadOnly={tripBindings.roadOnly}
        trackingContent={tripBindings.trackingContent}
        trackingContentHeight={tripBindings.trackingContentHeight}
      />

      <LocationPickerModal picker={location} locationLoading={locationLoading} />

      <YourJobSheetModal
        job={ui.selectedYourJob}
        palette={palette}
        bottomInset={insets.bottom}
        onClose={() => ui.setSelectedYourJob(null)}
        onViewTrip={ui.openTracking}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0F3B78' },
});
