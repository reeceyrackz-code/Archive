/**
 * Shared building blocks for the auth screens: glass fields, CTA, inline notices,
 * password strength meter and an animated, drag-to-dismiss sheet.
 */
import React, { forwardRef, useEffect, useState } from 'react';
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  useWindowDimensions,
  type StyleProp,
  type TextInputProps,
  type ViewStyle,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons as BrandGlyph } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Gesture, GestureDetector, GestureHandlerRootView } from 'react-native-gesture-handler';
import Animated, {
  Easing,
  FadeIn,
  FadeInDown,
  FadeOut,
  interpolateColor,
  runOnJS,
  useAnimatedStyle,
  useSharedValue,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import Svg, { Path } from 'react-native-svg';
import { hapticFeedback } from '../../services/HapticFeedbackService';

export const AUTH_BRAND = '#9EC9E0';
export const AUTH_STEEL = '#3A7AAD';
const ERROR = '#F87171';
const SUCCESS = '#4ADE80';

type GlyphName = React.ComponentProps<typeof BrandGlyph>['name'];

const blurProps = Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {};

/** Pressable with a springy scale-down; each instance owns its own animation. */
export function AuthPress({
  onPress,
  disabled,
  style,
  children,
  haptic = true,
  fill,
  accessibilityLabel,
}: Readonly<{
  onPress?: () => void;
  disabled?: boolean;
  style?: StyleProp<ViewStyle>;
  children: React.ReactNode;
  haptic?: boolean;
  /** Let the pressable grow inside a row (flex: 1). */
  fill?: boolean;
  accessibilityLabel?: string;
}>) {
  const s = useSharedValue(1);
  const anim = useAnimatedStyle(() => ({ transform: [{ scale: s.value }] }));
  return (
    <Pressable
      onPress={() => {
        if (haptic) void hapticFeedback('light');
        onPress?.();
      }}
      onPressIn={() => {
        s.value = withSpring(0.97, { damping: 18, stiffness: 420 });
      }}
      onPressOut={() => {
        s.value = withSpring(1, { damping: 14, stiffness: 320 });
      }}
      disabled={disabled}
      style={fill ? styles.flex : undefined}
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel}
      accessibilityState={{ disabled: !!disabled }}
    >
      <Animated.View style={[style, anim]}>{children}</Animated.View>
    </Pressable>
  );
}

/** Primary glass CTA used across login, signup, forgot and reset. */
export function AuthCta({
  title,
  icon = 'arrow-forward',
  leadingIcon,
  onPress,
  loading,
  disabled,
  style,
}: Readonly<{
  title: string;
  icon?: GlyphName | null;
  leadingIcon?: GlyphName;
  onPress: () => void;
  loading?: boolean;
  disabled?: boolean;
  style?: StyleProp<ViewStyle>;
}>) {
  const inactive = disabled || loading;
  return (
    <AuthPress
      onPress={onPress}
      disabled={inactive}
      haptic={false}
      style={[styles.cta, disabled && !loading && styles.ctaDisabled, style]}
      accessibilityLabel={title}
    >
      <View style={styles.ctaInner}>
        <BlurView intensity={Platform.OS === 'ios' ? 40 : 28} tint="light" style={StyleSheet.absoluteFill} {...blurProps} />
        <LinearGradient
          colors={['rgba(158,201,224,0.5)', 'rgba(58,122,173,0.42)']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
        />
        <LinearGradient
          colors={['rgba(255,255,255,0.42)', 'rgba(255,255,255,0.06)', 'transparent']}
          locations={[0, 0.45, 1]}
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
        />
        <View style={styles.ctaContent}>
          {loading ? (
            <ActivityIndicator color="#F8FAFC" />
          ) : (
            <>
              {leadingIcon ? <BrandGlyph name={leadingIcon} size={18} color="#F8FAFC" /> : null}
              <Text style={styles.ctaText}>{title}</Text>
              {icon ? <BrandGlyph name={icon} size={18} color="#F8FAFC" /> : null}
            </>
          )}
        </View>
      </View>
    </AuthPress>
  );
}

type AuthFieldProps = TextInputProps &
  Readonly<{
    icon: GlyphName;
    /** Adds a show / hide toggle and masks the value. */
    password?: boolean;
    invalid?: boolean;
    /** Small trailing check when the value is valid (e.g. passwords match). */
    valid?: boolean;
  }>;

/** Glass text field with animated focus ring, error state and optional password toggle. */
export const AuthField = forwardRef<TextInput, AuthFieldProps>(function AuthField(
  { icon, password, invalid, valid, onFocus, onBlur, style, ...rest },
  ref
) {
  const [hidden, setHidden] = useState(true);
  const focus = useSharedValue(0);
  const ring = useAnimatedStyle(() => ({
    borderColor: invalid
      ? ERROR
      : interpolateColor(focus.value, [0, 1], ['rgba(255,255,255,0.16)', AUTH_BRAND]),
    backgroundColor: interpolateColor(focus.value, [0, 1], ['rgba(255,255,255,0.08)', 'rgba(158,201,224,0.14)']),
  }));
  const iconColor = invalid ? ERROR : 'rgba(226,240,250,0.75)';

  return (
    <Animated.View style={[styles.field, ring]}>
      <View style={styles.fieldIcon}>
        <BrandGlyph name={icon} size={19} color={iconColor} />
      </View>
      <TextInput
        ref={ref}
        placeholderTextColor="rgba(226,240,250,0.42)"
        selectionColor={AUTH_BRAND}
        secureTextEntry={password ? hidden : undefined}
        onFocus={(e) => {
          focus.value = withTiming(1, { duration: 180 });
          onFocus?.(e);
        }}
        onBlur={(e) => {
          focus.value = withTiming(0, { duration: 180 });
          onBlur?.(e);
        }}
        style={[styles.fieldInput, style]}
        {...rest}
      />
      {valid ? (
        <Animated.View entering={FadeIn.duration(160)} exiting={FadeOut.duration(120)} style={styles.fieldTrail}>
          <BrandGlyph name="checkmark-circle" size={19} color={SUCCESS} />
        </Animated.View>
      ) : null}
      {password ? (
        <Pressable
          onPress={() => setHidden((h) => !h)}
          hitSlop={10}
          style={styles.fieldTrail}
          accessibilityLabel={hidden ? 'Show password' : 'Hide password'}
        >
          <BrandGlyph name={hidden ? 'eye-outline' : 'eye-off-outline'} size={19} color="rgba(226,240,250,0.75)" />
        </Pressable>
      ) : null}
    </Animated.View>
  );
});

/** Inline error / success banner that nudges sideways each time the message changes. */
export function AuthNotice({
  kind = 'error',
  message,
}: Readonly<{ kind?: 'error' | 'success' | 'info'; message: string | null | undefined }>) {
  const x = useSharedValue(0);
  useEffect(() => {
    if (!message || kind !== 'error') return;
    x.value = withSequence(
      withTiming(-7, { duration: 50 }),
      withTiming(7, { duration: 70 }),
      withTiming(-4, { duration: 60 }),
      withTiming(0, { duration: 60 })
    );
  }, [message, kind, x]);
  const shake = useAnimatedStyle(() => ({ transform: [{ translateX: x.value }] }));
  if (!message) return null;
  const color = kind === 'error' ? ERROR : kind === 'success' ? SUCCESS : AUTH_BRAND;
  const icon: GlyphName = kind === 'error' ? 'alert-circle' : kind === 'success' ? 'checkmark-circle' : 'information-circle';
  return (
    <Animated.View entering={FadeInDown.duration(200)} exiting={FadeOut.duration(150)}>
      <Animated.View style={[styles.notice, { borderColor: `${color}55`, backgroundColor: `${color}1A` }, shake]}>
        <BrandGlyph name={icon} size={17} color={color} />
        <Text style={styles.noticeText}>{message}</Text>
      </Animated.View>
    </Animated.View>
  );
}

function strengthOf(pw: string) {
  let score = 0;
  if (pw.length >= 6) score++;
  if (pw.length >= 10) score++;
  if (/[a-z]/.test(pw) && /[A-Z]/.test(pw)) score++;
  if (/\d/.test(pw) && /[^A-Za-z0-9]/.test(pw)) score++;
  else if (/\d|[^A-Za-z0-9]/.test(pw) && score < 4) score += pw.length >= 8 ? 1 : 0;
  return Math.min(4, score);
}

const STRENGTH = [
  { label: 'Too short', color: ERROR },
  { label: 'Weak', color: '#FB923C' },
  { label: 'Okay', color: '#FBBF24' },
  { label: 'Good', color: '#A3E635' },
  { label: 'Strong', color: SUCCESS },
];

/** Four-segment strength meter; purely visual — validation rules live in the screen. */
export function PasswordStrength({ password }: Readonly<{ password: string }>) {
  if (!password) return null;
  const score = password.length < 6 ? 0 : Math.max(1, strengthOf(password));
  const s = STRENGTH[score]!;
  return (
    <Animated.View entering={FadeIn.duration(180)} style={styles.strength}>
      <View style={styles.strengthBars}>
        {[1, 2, 3, 4].map((i) => (
          <View
            key={i}
            style={[styles.strengthBar, { backgroundColor: i <= Math.max(score, 1) ? s.color : 'rgba(255,255,255,0.14)' }]}
          />
        ))}
      </View>
      <Text style={[styles.strengthLabel, { color: s.color }]}>{s.label}</Text>
    </Animated.View>
  );
}

/**
 * Bottom sheet for auth flows: backdrop fades, sheet springs up, drag the header down to dismiss.
 * Sized to its content (up to ~92% of the screen) and lifts above the keyboard.
 */
export function AuthSheet({
  visible,
  onClose,
  title,
  subtitle,
  icon,
  children,
}: Readonly<{
  visible: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  icon?: GlyphName;
  children: React.ReactNode;
}>) {
  const insets = useSafeAreaInsets();
  const { height: H } = useWindowDimensions();
  const [mounted, setMounted] = useState(visible);
  const ty = useSharedValue(H);
  const fade = useSharedValue(0);

  useEffect(() => {
    if (visible) {
      setMounted(true);
      return;
    }
    fade.value = withTiming(0, { duration: 200 });
    ty.value = withTiming(H, { duration: 240, easing: Easing.in(Easing.cubic) }, (done) => {
      if (done) runOnJS(setMounted)(false);
    });
  }, [visible, H, fade, ty]);

  useEffect(() => {
    if (!mounted || !visible) return;
    ty.value = H;
    fade.value = withTiming(1, { duration: 220 });
    ty.value = withSpring(0, { damping: 22, stiffness: 210, mass: 0.9 });
  }, [mounted, visible, H, fade, ty]);

  const drag = Gesture.Pan()
    .activeOffsetY(8)
    .onUpdate((e) => {
      ty.value = Math.max(0, e.translationY);
    })
    .onEnd((e) => {
      if (e.translationY > 110 || e.velocityY > 900) runOnJS(onClose)();
      else ty.value = withSpring(0, { damping: 20, stiffness: 240 });
    });

  const sheetStyle = useAnimatedStyle(() => ({ transform: [{ translateY: ty.value }] }));
  const backdropStyle = useAnimatedStyle(() => ({ opacity: fade.value }));

  return (
    <Modal visible={mounted} transparent animationType="none" statusBarTranslucent onRequestClose={onClose}>
      <GestureHandlerRootView style={styles.flex}>
        <Animated.View style={[StyleSheet.absoluteFill, styles.backdrop, backdropStyle]}>
          <Pressable style={StyleSheet.absoluteFill} onPress={onClose} accessibilityLabel="Close" />
        </Animated.View>
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={styles.sheetHost}
          pointerEvents="box-none"
        >
          <Animated.View style={[styles.sheet, { maxHeight: H * 0.92 }, sheetStyle]}>
            <BlurView intensity={Platform.OS === 'ios' ? 40 : 24} tint="dark" style={StyleSheet.absoluteFill} {...blurProps} />
            <View style={styles.sheetTint} pointerEvents="none" />
            <LinearGradient
              colors={['rgba(158,201,224,0.22)', 'rgba(158,201,224,0.04)', 'transparent']}
              style={styles.sheetGlow}
              pointerEvents="none"
            />
            <GestureDetector gesture={drag}>
              <View style={styles.sheetHead}>
                <View style={styles.handle} />
                <View style={styles.headRow}>
                  {icon ? (
                    <View style={styles.headIcon}>
                      <LinearGradient
                        colors={['rgba(158,201,224,0.45)', 'rgba(58,122,173,0.35)']}
                        style={StyleSheet.absoluteFill}
                      />
                      <BrandGlyph name={icon} size={20} color="#F8FAFC" />
                    </View>
                  ) : null}
                  <View style={styles.flex}>
                    <Text style={styles.eyebrow}>CAR CARE PRO</Text>
                    <Text style={styles.title} numberOfLines={1} adjustsFontSizeToFit>
                      {title}
                    </Text>
                  </View>
                  <Pressable onPress={onClose} hitSlop={12} style={styles.close} accessibilityLabel="Close">
                    <BrandGlyph name="close" size={18} color="#F8FAFC" />
                  </Pressable>
                </View>
                {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
              </View>
            </GestureDetector>
            <ScrollView
              keyboardShouldPersistTaps="handled"
              keyboardDismissMode="interactive"
              showsVerticalScrollIndicator={false}
              bounces={false}
              contentContainerStyle={[styles.sheetBody, { paddingBottom: Math.max(insets.bottom, 16) + 12 }]}
            >
              {children}
            </ScrollView>
          </Animated.View>
        </KeyboardAvoidingView>
      </GestureHandlerRootView>
    </Modal>
  );
}

/** Official multicolour Google "G" mark. */
export function GoogleG({ size = 18 }: Readonly<{ size?: number }>) {
  return (
    <Svg width={size} height={size} viewBox="0 0 48 48">
      <Path
        fill="#EA4335"
        d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
      />
      <Path
        fill="#4285F4"
        d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
      />
      <Path
        fill="#FBBC05"
        d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
      />
      <Path
        fill="#34A853"
        d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
      />
    </Svg>
  );
}

/** Small text link row ("Forgot password?", "Remembered it? Sign in"). */
export function AuthLink({
  label,
  onPress,
  align = 'center',
}: Readonly<{ label: string; onPress: () => void; align?: 'center' | 'flex-end' }>) {
  return (
    <Pressable onPress={onPress} hitSlop={8} style={[styles.link, { alignSelf: align }]} accessibilityRole="link">
      {({ pressed }) => <Text style={[styles.linkText, pressed && { opacity: 0.6 }]}>{label}</Text>}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  cta: {
    borderRadius: 18,
    shadowColor: AUTH_BRAND,
    shadowOpacity: 0.32,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 6 },
    elevation: 6,
  },
  ctaDisabled: { opacity: 0.5, shadowOpacity: 0 },
  ctaInner: {
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.45)',
  },
  ctaContent: {
    minHeight: 54,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingHorizontal: 18,
  },
  ctaText: { color: '#F8FAFC', fontSize: 15.5, fontWeight: '800', letterSpacing: 0.3 },

  field: {
    flexDirection: 'row',
    alignItems: 'center',
    minHeight: 52,
    borderRadius: 16,
    borderWidth: 1,
    marginBottom: 12,
  },
  fieldIcon: { width: 46, alignItems: 'center', justifyContent: 'center' },
  fieldInput: { flex: 1, color: '#F8FAFC', fontSize: 15.5, fontWeight: '600', paddingVertical: 14, paddingRight: 12 },
  fieldTrail: { width: 40, alignItems: 'center', justifyContent: 'center', alignSelf: 'stretch' },

  notice: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 9,
    paddingHorizontal: 13,
    paddingVertical: 11,
    borderRadius: 14,
    borderWidth: 1,
    marginBottom: 12,
  },
  noticeText: { flex: 1, color: '#F1F5F9', fontSize: 13.5, fontWeight: '600', lineHeight: 19 },

  strength: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: -4, marginBottom: 12, paddingHorizontal: 2 },
  strengthBars: { flex: 1, flexDirection: 'row', gap: 5 },
  strengthBar: { flex: 1, height: 4, borderRadius: 2 },
  strengthLabel: { fontSize: 12, fontWeight: '800', minWidth: 62, textAlign: 'right' },

  backdrop: { backgroundColor: 'rgba(4,14,28,0.6)' },
  sheetHost: { flex: 1, justifyContent: 'flex-end' },
  sheet: {
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    overflow: 'hidden',
    borderWidth: 1,
    borderBottomWidth: 0,
    borderColor: 'rgba(255,255,255,0.22)',
    backgroundColor: 'rgba(8,24,40,0.86)',
  },
  sheetTint: { ...StyleSheet.absoluteFill, backgroundColor: 'rgba(12,42,72,0.3)' },
  sheetGlow: { position: 'absolute', left: 0, right: 0, top: 0, height: 140 },
  sheetHead: { paddingHorizontal: 22, paddingTop: 10, paddingBottom: 6 },
  handle: {
    alignSelf: 'center',
    width: 40,
    height: 5,
    borderRadius: 3,
    backgroundColor: 'rgba(255,255,255,0.35)',
    marginBottom: 14,
  },
  headRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  headIcon: {
    width: 44,
    height: 44,
    borderRadius: 14,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.28)',
  },
  eyebrow: { color: AUTH_BRAND, fontSize: 10.5, fontWeight: '800', letterSpacing: 1.3 },
  title: { color: '#F8FAFC', fontSize: 22, fontWeight: '900', letterSpacing: -0.3, marginTop: 1 },
  close: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.12)',
  },
  subtitle: { color: 'rgba(226,240,250,0.72)', fontSize: 14, lineHeight: 20, fontWeight: '600', marginTop: 12 },
  sheetBody: { paddingHorizontal: 22, paddingTop: 14 },

  link: { paddingVertical: 6 },
  linkText: { color: AUTH_BRAND, fontSize: 14, fontWeight: '700' },
});
