import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Animated, { FadeIn, ZoomIn } from 'react-native-reanimated';
import { Ionicons as BrandGlyph } from '@expo/vector-icons';
import { useAuth } from '../../providers/enhanced-auth-context';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { AUTH_BRAND, AuthCta, AuthField, AuthLink, AuthNotice, AuthSheet } from './AuthKit';

type Props = Readonly<{
  visible: boolean;
  onClose: () => void;
  initialEmail?: string;
  onBackToSignIn?: () => void;
}>;

export default function ForgotPasswordSheet({
  visible,
  onClose,
  initialEmail = '',
  onBackToSignIn,
}: Props) {
  const { resetPassword } = useAuth();
  const [email, setEmail] = useState(initialEmail);
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!visible) return;
    setEmail(initialEmail);
    setSent(false);
    setError(null);
    setSending(false);
  }, [visible, initialEmail]);

  const handleSend = async () => {
    await hapticFeedback('medium');
    const trimmed = email.trim().toLowerCase();
    if (!trimmed.includes('@')) {
      setError('Enter a valid email address.');
      return;
    }
    setError(null);
    setSending(true);
    try {
      await resetPassword(trimmed);
      await hapticFeedback('success');
      setSent(true);
    } catch (e: any) {
      setError(
        e?.message ||
          'Couldn’t send reset email. Try again, or email Admin@wishawashapp.com for help.'
      );
    } finally {
      setSending(false);
    }
  };

  const backToSignIn = async () => {
    await hapticFeedback('light');
    onClose();
    onBackToSignIn?.();
  };

  return (
    <AuthSheet
      visible={visible}
      onClose={onClose}
      title={sent ? 'Check your inbox' : 'Forgot password?'}
      subtitle={
        sent
          ? undefined
          : 'Enter the email on your CCP account and we’ll send you a link to choose a new password.'
      }
      icon={sent ? 'mail-open-outline' : 'key-outline'}
    >
      {sent ? (
        <Animated.View entering={FadeIn.duration(220)} style={styles.sent}>
          <Animated.View entering={ZoomIn.springify().damping(14)} style={styles.sentBadge}>
            <BrandGlyph name="paper-plane" size={30} color="#F8FAFC" />
          </Animated.View>
          <Text style={styles.sentBody}>If an account exists for</Text>
          <Text style={styles.sentEmail} numberOfLines={1} adjustsFontSizeToFit>
            {email.trim().toLowerCase()}
          </Text>
          <Text style={styles.sentBody}>we’ve sent a reset link. Open it on this phone to set a new password.</Text>
          <AuthCta title="Back to sign in" onPress={() => void backToSignIn()} style={styles.sentCta} />
          <AuthLink
            label="Use a different email"
            onPress={() => {
              void hapticFeedback('light');
              setSent(false);
              setError(null);
            }}
          />
        </Animated.View>
      ) : (
        <>
          <AuthField
            icon="mail-outline"
            placeholder="Email address"
            value={email}
            onChangeText={(v) => {
              setEmail(v);
              if (error) setError(null);
            }}
            autoCapitalize="none"
            autoCorrect={false}
            keyboardType="email-address"
            autoComplete="email"
            textContentType="emailAddress"
            autoFocus
            returnKeyType="send"
            onSubmitEditing={() => void handleSend()}
            invalid={!!error}
          />
          <AuthNotice message={error} />
          <AuthCta
            title="Send reset link"
            icon="paper-plane-outline"
            onPress={() => void handleSend()}
            loading={sending}
            disabled={!email.trim()}
          />
          <View style={styles.footer}>
            <AuthLink label="Remembered it? Sign in" onPress={() => void backToSignIn()} />
          </View>
        </>
      )}
    </AuthSheet>
  );
}

const styles = StyleSheet.create({
  sent: { alignItems: 'center', paddingTop: 4 },
  sentBadge: {
    width: 72,
    height: 72,
    borderRadius: 36,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(158,201,224,0.25)',
    borderWidth: 1,
    borderColor: `${AUTH_BRAND}88`,
    marginBottom: 16,
  },
  sentBody: {
    color: 'rgba(226,240,250,0.75)',
    fontSize: 14,
    lineHeight: 20,
    fontWeight: '600',
    textAlign: 'center',
  },
  sentEmail: {
    color: '#F8FAFC',
    fontSize: 16,
    fontWeight: '900',
    marginVertical: 4,
    maxWidth: '100%',
  },
  sentCta: { alignSelf: 'stretch', marginTop: 20, marginBottom: 8 },
  footer: { marginTop: 12 },
});
