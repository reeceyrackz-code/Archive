/**
 * Shared cinematic auth gate: video + brand hero + bottom actions sheet.
 */
import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Platform,
  StatusBar,
  Image,
  Modal,
  useWindowDimensions,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { router } from 'expo-router';
import { Ionicons as BrandGlyph } from '@expo/vector-icons';
import { AUTH_PAGES_VIDEO } from '../../../assets/authExports';
import { AUTH_GRADIENT_COLORS } from '../../constants/authStyles';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import LoopingBackgroundVideo from '../shared/LoopingBackgroundVideo';
import { AuthCta, AuthPress, AuthSheet, GoogleG } from './AuthKit';
import ProSetupWizard from '../valeter/onboarding/ProSetupWizard';
const AUTH_MASCOT = require('../../../assets/auth-mascot.png');
const STEEL = '#3A7AAD';
const BRAND_LABEL = 'Wish-a-Washer';
const BRAND_ARC_TEXT = 'WISH a WASHER';
/** Same arc colours as the customer app: sky letters, brand-yellow italic "a". */
const BRAND_ARC_BLUE = '#87CEEB';
const BRAND_YELLOW = '#F8D70C';
const ARC_TRACKING = 0.16;
const GLYPH_WIDTH: Record<string, number> = {
  W: 1,
  I: 0.34,
  S: 0.66,
  H: 0.76,
  A: 0.74,
  E: 0.64,
  R: 0.72,
  a: 0.6,
  ' ': 0.42,
};

/** Customer-app proportions: letters ~11.6% of the badge, centred ~9.6% of it outside the rim. */
const ARC_FONT_RATIO = 0.116;
const ARC_GAP_RATIO = 0.0965;
const arcRadius = (diameter: number) => diameter / 2 + diameter * ARC_GAP_RATIO;

/** Letters fanned along an arc over the top of a circle of `diameter`, centred at (cx, cy). */
function CurvedBrandTitle({
  text,
  color,
  diameter,
  letterSize,
  width,
  height,
  cx,
  cy,
}: Readonly<{
  text: string;
  color: string;
  diameter: number;
  letterSize: number;
  width: number;
  height: number;
  cx: number;
  cy: number;
}>) {
  const chars = Array.from(text);
  const radius = arcRadius(diameter);
  const box = letterSize * 1.4;
  const advances = chars.map((ch) => ((GLYPH_WIDTH[ch] ?? 0.7) + ARC_TRACKING) * letterSize);
  const accentIndex = text.indexOf(' a ') + 1;
  // Centre the arc on the accent "a" so it sits at the crown.
  const before = advances.slice(0, accentIndex).reduce((s, w) => s + w, 0);
  let run = accentIndex > 0 ? -(before + advances[accentIndex]! / 2) : -advances.reduce((s, w) => s + w, 0) / 2;

  return (
    <View style={[styles.curveLayer, { width, height }]} pointerEvents="none">
      {chars.map((char, index) => {
        const mid = run + advances[index]! / 2;
        run += advances[index]!;
        if (char === ' ') return null;
        const theta = mid / radius;
        const accent = index === accentIndex;
        return (
          <View
            key={`brand-char-${index}`}
            style={[
              styles.arcGlyph,
              {
                width: box,
                height: box,
                left: cx + radius * Math.sin(theta) - box / 2,
                top: cy - radius * Math.cos(theta) - box / 2,
                transform: [{ rotate: `${(theta * 180) / Math.PI}deg` }],
              },
            ]}
          >
            <Text
              allowFontScaling={false}
              style={[
                styles.arcChar,
                { fontSize: letterSize, lineHeight: letterSize * 1.2, color },
                accent && styles.arcCharAccent,
              ]}
            >
              {char}
            </Text>
          </View>
        );
      })}
    </View>
  );
}

export type AuthGateMode = 'login' | 'signup';

type AuthGateShellProps = Readonly<{
  mode: AuthGateMode;
  tagline: string;
  emailSheetTitle: string;
  emailSheetSubtitle?: string;
  emailSheetOpen: boolean;
  onOpenEmailSheet: () => void;
  onCloseEmailSheet: () => void;
  onApple: () => void;
  onGoogle: () => void;
  emailSheetChildren: React.ReactNode;
  loading?: boolean;
  /** Replaces the default "New here? / Already have an account?" footer link. */
  altLink?: Readonly<{ prompt: string; label: string; onPress: () => void }>;
}>;

export default function AuthGateShell({
  mode,
  tagline,
  emailSheetTitle,
  emailSheetSubtitle,
  emailSheetOpen,
  onOpenEmailSheet,
  onCloseEmailSheet,
  onApple,
  onGoogle,
  emailSheetChildren,
  loading = false,
  altLink,
}: AuthGateShellProps) {
  const insets = useSafeAreaInsets();
  const showApple = Platform.OS === 'ios';
  const { width: winW } = useWindowDimensions();
  const mascotD = Math.round(Math.min(winW * 0.46, 200));
  const letter = Math.max(15, Math.round(mascotD * ARC_FONT_RATIO));
  const topPad = Math.ceil(arcRadius(mascotD) - mascotD / 2 + letter * 0.7 + 2);
  const stageW = Math.round(arcRadius(mascotD) * 2 + letter * 2);
  const stage = {
    w: stageW,
    h: topPad + mascotD + 4,
    cx: stageW / 2,
    cy: topPad + mascotD / 2,
    letter,
  };
  const [sheetH, setSheetH] = useState(0);
  const [previewOpen, setPreviewOpen] = useState(false);
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(36)).current;
  const sheetSlide = useRef(new Animated.Value(48)).current;
  const videoOpacity = useRef(new Animated.Value(0)).current;
  const logoGlow = useRef(new Animated.Value(0.92)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 720, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0, duration: 720, useNativeDriver: true }),
      Animated.timing(sheetSlide, { toValue: 0, duration: 780, delay: 120, useNativeDriver: true }),
    ]).start();
  }, [fadeAnim, sheetSlide, slideAnim]);

  useEffect(() => {
    const pulse = Animated.loop(
      Animated.sequence([
        Animated.timing(logoGlow, { toValue: 1, duration: 2600, useNativeDriver: true }),
        Animated.timing(logoGlow, { toValue: 0.86, duration: 2600, useNativeDriver: true }),
      ])
    );
    pulse.start();
    return () => {
      pulse.stop();
    };
  }, [logoGlow]);

  const handleVideoLoad = () => {
    Animated.timing(videoOpacity, {
      toValue: 1,
      duration: 700,
      useNativeDriver: true,
    }).start();
  };

  const goAlt = async () => {
    await hapticFeedback('light');
    if (altLink) altLink.onPress();
    else if (mode === 'login') router.push('/auth/signup' as any);
    else router.replace('/auth/login');
  };

  return (
    <View style={styles.root}>
      <StatusBar translucent backgroundColor="transparent" barStyle="light-content" />

      <Animated.View style={[StyleSheet.absoluteFill, { opacity: videoOpacity }]}>
        <LoopingBackgroundVideo source={AUTH_PAGES_VIDEO} onReady={handleVideoLoad} />
      </Animated.View>
      <LinearGradient colors={[...AUTH_GRADIENT_COLORS]} style={StyleSheet.absoluteFill} pointerEvents="none" />
      <LinearGradient
        colors={['rgba(12,42,72,0.35)', 'rgba(6,22,40,0.72)', 'rgba(3,12,24,0.97)']}
        locations={[0.18, 0.52, 1]}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <View style={[styles.blueWash, StyleSheet.absoluteFill]} pointerEvents="none" />

      <Animated.View style={[styles.previewWrap, { top: insets.top + 10, opacity: fadeAnim }]}>
        <AuthPress onPress={() => setPreviewOpen(true)} style={styles.previewBtn} accessibilityLabel="Preview Pro setup">
          <BrandGlyph name="play-circle" size={16} color="#E0F2FE" />
          <Text style={styles.previewText}>How it works</Text>
        </AuthPress>
      </Animated.View>

      <View style={[styles.heroWrap, { paddingTop: insets.top + 50, paddingBottom: sheetH ? sheetH + 16 : 360 }]}>
        <Animated.View
          style={[
            styles.brandBlock,
            { opacity: fadeAnim, transform: [{ translateY: slideAnim }] },
          ]}
        >
          <View style={{ width: stage.w, height: stage.h }}>
            <Animated.View
              style={[
                styles.mascotWrap,
                {
                  width: mascotD,
                  height: mascotD,
                  borderRadius: mascotD / 2,
                  left: stage.cx - mascotD / 2,
                  top: stage.cy - mascotD / 2,
                  transform: [
                    { translateY: logoGlow.interpolate({ inputRange: [0.86, 1], outputRange: [3, -3] }) },
                  ],
                },
              ]}
            >
              <Image source={AUTH_MASCOT} resizeMode="cover" style={styles.mascot} />
              <LinearGradient
                colors={['rgba(255,255,255,0.28)', 'rgba(255,255,255,0)']}
                start={{ x: 0.2, y: 0 }}
                end={{ x: 0.5, y: 0.45 }}
                style={StyleSheet.absoluteFill}
                pointerEvents="none"
              />
            </Animated.View>
            <CurvedBrandTitle
              text={BRAND_ARC_TEXT}
              color={BRAND_ARC_BLUE}
              diameter={mascotD}
              letterSize={stage.letter}
              width={stage.w}
              height={stage.h}
              cx={stage.cx}
              cy={stage.cy}
            />
          </View>
          <Text style={styles.tagline}>{tagline}</Text>
        </Animated.View>
      </View>

      <Animated.View
        style={[
          styles.sheetWrap,
          {
            opacity: fadeAnim,
            transform: [{ translateY: sheetSlide }],
          },
        ]}
      >
        <View
          style={[styles.sheetOuter, { paddingBottom: Math.max(insets.bottom, 16) }]}
          onLayout={(e) => setSheetH(e.nativeEvent.layout.height)}
        >
          <BlurView
            intensity={Platform.OS === 'ios' ? 32 : 22}
            tint="dark"
            style={StyleSheet.absoluteFill}
            {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
          />
          <View style={styles.sheetBlueTint} pointerEvents="none" />
          <LinearGradient
            colors={['rgba(255,255,255,0.14)', 'rgba(255,255,255,0.02)', 'transparent']}
            style={styles.sheetSheen}
            pointerEvents="none"
          />
          <View style={styles.sheetContent}>
          <View style={styles.sheetHandle} />

          <View style={styles.socialStack}>
            {showApple ? (
              <AuthPress
                onPress={onApple}
                disabled={loading}
                style={[styles.socialBtn, styles.socialApple]}
                accessibilityLabel="Continue with Apple"
              >
                <View style={styles.socialIcon}>
                  <BrandGlyph name="logo-apple" size={22} color="#FFFFFF" style={styles.appleGlyph} />
                </View>
                <Text style={[styles.socialText, styles.socialAppleText]}>Continue with Apple</Text>
              </AuthPress>
            ) : null}
            <AuthPress
              onPress={onGoogle}
              disabled={loading}
              style={[styles.socialBtn, styles.socialGoogle]}
              accessibilityLabel="Continue with Google"
            >
              <View style={styles.socialIcon}>
                <GoogleG size={20} />
              </View>
              <Text style={[styles.socialText, styles.socialGoogleText]}>Continue with Google</Text>
            </AuthPress>
          </View>

          <View style={styles.dividerRow}>
            <View style={styles.dividerLine} />
            <Text style={styles.dividerText}>or</Text>
            <View style={styles.dividerLine} />
          </View>

          <AuthCta
            title={mode === 'login' ? 'Sign in with email' : 'Sign up with email'}
            leadingIcon="mail-outline"
            icon={null}
            onPress={onOpenEmailSheet}
            disabled={loading}
          />

          <Text style={styles.trustText}>
            By continuing, you agree to{' '}
            <Text style={styles.trustLink} onPress={() => router.push('/terms-of-service')}>
              Terms
            </Text>
            {' & '}
            <Text style={styles.trustLink} onPress={() => router.push('/privacy-policy')}>
              Privacy Policy
            </Text>
          </Text>

          <View style={styles.altRow}>
            <Text style={styles.altText}>
              {altLink ? `${altLink.prompt} ` : mode === 'login' ? 'New here? ' : 'Already have an account? '}
            </Text>
            <TouchableOpacity onPress={goAlt} activeOpacity={0.8}>
              <Text style={styles.altLink}>
                {altLink ? altLink.label : mode === 'login' ? 'Create an account' : 'Sign in'}
              </Text>
            </TouchableOpacity>
          </View>

          <Text style={styles.footer}>{BRAND_LABEL}</Text>
          </View>
        </View>
      </Animated.View>

      <Modal
        visible={previewOpen}
        animationType="slide"
        presentationStyle="fullScreen"
        onRequestClose={() => setPreviewOpen(false)}
      >
        <ProSetupWizard
          preview
          signup
          version="v1.0"
          continuePath="/auth/login"
          blockedPath="/auth/login"
          onClose={() => setPreviewOpen(false)}
        />
      </Modal>

      <AuthSheet
        visible={emailSheetOpen}
        onClose={onCloseEmailSheet}
        title={emailSheetTitle}
        subtitle={emailSheetSubtitle}
        icon={mode === 'login' ? 'log-in-outline' : 'person-add-outline'}
      >
        {emailSheetChildren}
      </AuthSheet>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#061525',
  },
  blueWash: {
    backgroundColor: 'rgba(10,40,72,0.28)',
  },
  heroWrap: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 28,
  },
  brandBlock: {
    alignItems: 'center',
  },
  previewWrap: {
    position: 'absolute',
    right: 16,
    zIndex: 20,
  },
  previewBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    height: 34,
    paddingHorizontal: 13,
    borderRadius: 17,
    backgroundColor: 'rgba(158,201,224,0.18)',
    borderWidth: 1,
    borderColor: 'rgba(158,201,224,0.4)',
  },
  previewText: {
    color: '#E0F2FE',
    fontSize: 13,
    fontWeight: '800',
  },
  mascotWrap: {
    position: 'absolute',
    overflow: 'hidden',
    backgroundColor: '#1D5FD0',
  },
  mascot: {
    width: '100%',
    height: '100%',
  },
  curveLayer: {
    position: 'absolute',
    left: 0,
    top: 0,
    overflow: 'visible',
  },
  arcGlyph: {
    position: 'absolute',
    alignItems: 'center',
    justifyContent: 'center',
  },
  arcChar: {
    fontWeight: '900',
    textAlign: 'center',
    includeFontPadding: false,
  },
  arcCharAccent: {
    color: BRAND_YELLOW,
    fontStyle: 'italic',
  },
  tagline: {
    marginTop: 8,
    color: BRAND_YELLOW,
    fontSize: 15,
    fontWeight: '700',
    textAlign: 'center',
    lineHeight: 22,
    letterSpacing: 0.2,
    maxWidth: 320,
    paddingHorizontal: 12,
  },
  sheetWrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'transparent',
  },
  sheetOuter: {
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    overflow: 'hidden',
    borderTopWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  sheetBlueTint: {
    ...StyleSheet.absoluteFill,
    backgroundColor: 'rgba(12,42,72,0.22)',
  },
  sheetSheen: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    height: 48,
  },
  sheetContent: {
    paddingHorizontal: 22,
    paddingTop: 10,
  },
  sheetHandle: {
    alignSelf: 'center',
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(255,255,255,0.4)',
    marginBottom: 16,
  },
  dividerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 14,
  },
  dividerLine: {
    flex: 1,
    height: StyleSheet.hairlineWidth,
    backgroundColor: 'rgba(255,255,255,0.28)',
  },
  dividerText: {
    marginHorizontal: 12,
    color: 'rgba(255,255,255,0.62)',
    fontSize: 12,
    fontWeight: '700',
  },
  socialStack: {
    gap: 10,
  },
  socialBtn: {
    height: 54,
    borderRadius: 18,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  socialIcon: {
    position: 'absolute',
    left: 18,
    width: 24,
    alignItems: 'center',
  },
  socialApple: {
    backgroundColor: '#000000',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.35)',
  },
  socialGoogle: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#DADCE0',
  },
  socialText: {
    fontSize: 15.5,
    fontWeight: '600',
    letterSpacing: 0.1,
  },
  socialAppleText: {
    color: '#FFFFFF',
  },
  socialGoogleText: {
    color: '#1F1F1F',
  },
  appleGlyph: {
    marginTop: -2,
  },
  trustText: {
    marginTop: 18,
    color: 'rgba(255,255,255,0.62)',
    fontSize: 12,
    lineHeight: 18,
    textAlign: 'center',
  },
  trustLink: {
    color: STEEL,
    fontWeight: '800',
    textDecorationLine: 'underline',
  },
  altRow: {
    marginTop: 14,
    flexDirection: 'row',
    justifyContent: 'center',
    flexWrap: 'wrap',
  },
  altText: {
    color: 'rgba(255,255,255,0.78)',
    fontSize: 13,
    fontWeight: '600',
  },
  altLink: {
    color: STEEL,
    fontSize: 13,
    fontWeight: '900',
  },
  footer: {
    marginTop: 14,
    marginBottom: 2,
    textAlign: 'center',
    color: 'rgba(255,255,255,0.42)',
    fontSize: 11,
    fontWeight: '700',
  },
});
