import React, { useMemo } from 'react';
import {
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import Animated, { FadeIn, SlideInDown } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import BusinessSheetBackground from '../shared/BusinessSheetBackground';
import GlassSurface, { hasLiquidGlass } from '../shared/GlassSurface';
import KeyboardSafeView from '../shared/KeyboardSafeView';
import ContinueCTAButton from '../ui/ContinueCTAButton';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import type { VehicleSize } from '../../pricing/pricingEngine';

const SIZE_LABEL: Record<VehicleSize, string> = {
  SMALL: 'Small',
  MEDIUM: 'Medium',
  LARGE: 'Large',
  XL: 'XL',
  XXL: 'XXL',
};

const QUICK_ADJUST = [-5, -1, 1, 5] as const;

function parseMoney(raw: string | undefined): number {
  const cleaned = (raw ?? '').replaceAll(',', '').trim();
  const n = Number.parseFloat(cleaned);
  return Number.isFinite(n) ? Math.max(0, n) : 0;
}

function formatMoney(n: number): string {
  return Number.isInteger(n) ? String(n) : n.toFixed(2);
}

type ServicePricingSheetProps = Readonly<{
  visible: boolean;
  title: string;
  tier?: string;
  tierHex: string;
  accent: string;
  sizes: VehicleSize[];
  draft: Record<VehicleSize, string> | null;
  borderColor: string;
  onChangeDraft: (next: Record<VehicleSize, string>) => void;
  onClose: () => void;
  onSave: () => void;
}>;

export default function ServicePricingSheet({
  visible,
  title,
  tier,
  tierHex,
  accent,
  sizes,
  draft,
  borderColor,
  onChangeDraft,
  onClose,
  onSave,
}: ServicePricingSheetProps) {
  const insets = useSafeAreaInsets();

  const range = useMemo(() => {
    if (!draft) return null;
    const values = sizes.map((s) => parseMoney(draft[s]));
    return { min: Math.min(...values), max: Math.max(...values) };
  }, [draft, sizes]);

  const step = (size: VehicleSize, delta: number) => {
    if (!draft) return;
    hapticFeedback('soft');
    const next = Math.max(0, parseMoney(draft[size]) + delta);
    onChangeDraft({ ...draft, [size]: formatMoney(next) });
  };

  const adjustAll = (delta: number) => {
    if (!draft) return;
    hapticFeedback('light');
    const next = { ...draft };
    for (const size of sizes) next[size] = formatMoney(Math.max(0, parseMoney(draft[size]) + delta));
    onChangeDraft(next);
  };

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose} statusBarTranslucent>
      <KeyboardSafeView style={styles.flex} padAndroid>
        <View style={styles.root}>
          <Pressable style={StyleSheet.absoluteFill} onPress={onClose}>
            <Animated.View entering={FadeIn.duration(200)} style={styles.backdrop} />
          </Pressable>

          <Animated.View entering={SlideInDown.springify().damping(20)} style={styles.sheetWrap}>
            <GlassSurface
              style={[styles.sheet, { paddingBottom: Math.max(insets.bottom, 20) }]}
              tintColor="rgba(10,25,41,0.55)"
              borderColor={borderColor}
              fallbackColor="transparent"
            >
              {hasLiquidGlass ? null : <BusinessSheetBackground />}
              <View style={styles.handle} />

              <View style={styles.header}>
                <View style={styles.headerText}>
                  {tier ? (
                    <Text style={[styles.kicker, { color: tierHex }]}>{tier} tier</Text>
                  ) : null}
                  <Text style={styles.title} numberOfLines={1}>
                    {title}
                  </Text>
                  {range ? (
                    <Text style={styles.subtitle}>
                      £{range.min.toFixed(2)} – £{range.max.toFixed(2)} across vehicle sizes
                    </Text>
                  ) : null}
                </View>
                <TouchableOpacity onPress={onClose} hitSlop={12} style={styles.closeBtn} accessibilityLabel="Close">
                  <Ionicons name="close" size={20} color="rgba(249,250,251,0.85)" />
                </TouchableOpacity>
              </View>

              <View style={styles.quickRow}>
                <Text style={styles.quickLabel}>All sizes</Text>
                <View style={styles.quickChips}>
                  {QUICK_ADJUST.map((delta) => (
                    <TouchableOpacity
                      key={delta}
                      onPress={() => adjustAll(delta)}
                      style={[styles.chip, { borderColor: `${accent}55`, backgroundColor: `${accent}18` }]}
                      activeOpacity={0.75}
                    >
                      <Text style={[styles.chipText, { color: accent }]}>
                        {delta > 0 ? `+£${delta}` : `−£${Math.abs(delta)}`}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              <ScrollView style={styles.body} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
                {draft
                  ? sizes.map((size) => (
                      <View key={size} style={styles.row}>
                        <Text style={styles.sizeLabel}>{SIZE_LABEL[size]}</Text>
                        <View style={styles.stepper}>
                          <TouchableOpacity
                            onPress={() => step(size, -1)}
                            style={styles.stepBtn}
                            hitSlop={6}
                            accessibilityLabel={`Decrease ${SIZE_LABEL[size]} price`}
                          >
                            <Ionicons name="remove" size={18} color="#F9FAFB" />
                          </TouchableOpacity>
                          <View style={[styles.inputWrap, { borderColor: `${accent}44` }]}>
                            <Text style={styles.currency}>£</Text>
                            <TextInput
                              style={styles.input}
                              value={draft[size]}
                              onChangeText={(text) => onChangeDraft({ ...draft, [size]: text })}
                              keyboardType={Platform.OS === 'ios' ? 'decimal-pad' : 'numeric'}
                              placeholder="0.00"
                              placeholderTextColor="rgba(255,255,255,0.35)"
                              selectTextOnFocus
                            />
                          </View>
                          <TouchableOpacity
                            onPress={() => step(size, 1)}
                            style={styles.stepBtn}
                            hitSlop={6}
                            accessibilityLabel={`Increase ${SIZE_LABEL[size]} price`}
                          >
                            <Ionicons name="add" size={18} color="#F9FAFB" />
                          </TouchableOpacity>
                        </View>
                      </View>
                    ))
                  : null}
              </ScrollView>

              <ContinueCTAButton title="Apply prices" onPress={onSave} accentColor={accent} style={styles.cta} />
            </GlassSurface>
          </Animated.View>
        </View>
      </KeyboardSafeView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  root: { flex: 1, justifyContent: 'flex-end' },
  backdrop: { flex: 1, backgroundColor: 'rgba(5,13,20,0.72)' },
  sheetWrap: { width: '100%' },
  sheet: {
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    paddingHorizontal: 20,
    paddingTop: 12,
    maxHeight: '85%',
  },
  handle: {
    width: 40,
    height: 5,
    borderRadius: 5,
    backgroundColor: 'rgba(255,255,255,0.26)',
    alignSelf: 'center',
    marginBottom: 14,
  },
  header: { flexDirection: 'row', alignItems: 'flex-start', gap: 12, marginBottom: 16 },
  headerText: { flex: 1, minWidth: 0 },
  kicker: { fontSize: 11, fontWeight: '800', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 4 },
  title: { color: '#F9FAFB', fontSize: 20, fontWeight: '800' },
  subtitle: { color: 'rgba(249,250,251,0.68)', fontSize: 13, fontWeight: '600', marginTop: 4 },
  closeBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
  },
  quickRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.08)',
  },
  quickLabel: { color: 'rgba(249,250,251,0.72)', fontSize: 13, fontWeight: '700' },
  quickChips: { flexDirection: 'row', gap: 6 },
  chip: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 999, borderWidth: 1 },
  chipText: { fontSize: 12, fontWeight: '800' },
  body: { maxHeight: 340 },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.08)',
  },
  sizeLabel: { color: '#F9FAFB', fontSize: 15, fontWeight: '700' },
  stepper: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  stepBtn: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
  },
  inputWrap: {
    width: 96,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 10,
    paddingVertical: 8,
  },
  currency: { color: 'rgba(249,250,251,0.65)', fontSize: 14, marginRight: 4 },
  input: { color: '#F9FAFB', fontSize: 15, fontWeight: '700', flex: 1, padding: 0 },
  cta: { marginTop: 14 },
});
