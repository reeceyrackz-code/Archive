import React, { useEffect } from 'react';
import { Pressable, StyleSheet, Switch, Text, View } from 'react-native';
import Animated, {
  FadeIn,
  FadeInDown,
  LinearTransition,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import type { IconGlyphName } from '../shared/iconGlyphTypes';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import GlassSurface from '../shared/GlassSurface';

type ServiceTierCardProps = Readonly<{
  index: number;
  name: string;
  description: string;
  tier: string;
  enabled: boolean;
  minPrice: number;
  maxPrice: number;
  tierHex: string;
  tierIcon: IconGlyphName;
  accent: string;
  textMain: string;
  muted: string;
  glassBorder: string;
  edited: boolean;
  onToggle: () => void;
  onEdit: () => void;
}>;

export default function ServiceTierCard({
  index,
  name,
  description,
  tier,
  enabled,
  minPrice,
  maxPrice,
  tierHex,
  tierIcon,
  accent,
  textMain,
  muted,
  glassBorder,
  edited,
  onToggle,
  onEdit,
}: ServiceTierCardProps) {
  const active = useSharedValue(enabled ? 1 : 0);
  const press = useSharedValue(1);

  useEffect(() => {
    active.value = withTiming(enabled ? 1 : 0, { duration: 260 });
  }, [enabled, active]);

  const cardStyle = useAnimatedStyle(() => ({
    opacity: 0.55 + active.value * 0.45,
    transform: [{ scale: press.value * (0.98 + active.value * 0.02) }],
  }));

  const iconNode = (
    <View style={[styles.symbolBox, { backgroundColor: `${tierHex}26`, borderColor: `${tierHex}66` }]}>
      <Ionicons name={tierIcon} size={22} color={tierHex} />
    </View>
  );

  return (
    <Animated.View
      entering={FadeInDown.delay(index * 70).springify().damping(18)}
      layout={LinearTransition.springify()}
      style={cardStyle}
    >
      <Pressable
        onPress={onEdit}
        onPressIn={() => {
          press.value = withSpring(0.97, { damping: 18, stiffness: 320 });
        }}
        onPressOut={() => {
          press.value = withSpring(1, { damping: 14, stiffness: 260 });
        }}
        accessibilityRole="button"
        accessibilityLabel={`Edit pricing for ${name}`}
      >
        <GlassSurface
          style={styles.card}
          tintColor={`${tierHex}18`}
          borderColor={glassBorder}
          interactive
        >
          <View style={[styles.tierStripe, { backgroundColor: tierHex }]} />
          <View style={styles.top}>
            <View style={styles.lead}>
              {iconNode}
              <View style={styles.titles}>
                <View style={styles.titleLine}>
                  <Text style={[styles.title, { color: textMain }]} numberOfLines={2}>
                    {name}
                  </Text>
                  <View style={[styles.badge, { backgroundColor: `${tierHex}35`, borderColor: tierHex }]}>
                    <Text style={styles.badgeText}>{tier}</Text>
                  </View>
                </View>
                <Text style={[styles.sub, { color: muted }]} numberOfLines={2}>
                  {description}
                </Text>
              </View>
            </View>
            <Switch
              value={enabled}
              onValueChange={onToggle}
              trackColor={{ false: 'rgba(255,255,255,0.15)', true: accent }}
              thumbColor={enabled ? '#FFFFFF' : '#9CA3AF'}
              ios_backgroundColor="rgba(255,255,255,0.15)"
            />
          </View>

          <View style={[styles.footer, { borderTopColor: 'rgba(255,255,255,0.08)' }]}>
            <Animated.Text
              key={`${minPrice}-${maxPrice}`}
              entering={FadeIn.duration(320)}
              style={[styles.range, { color: textMain }]}
            >
              £{minPrice.toFixed(2)} – £{maxPrice.toFixed(2)}
            </Animated.Text>
            <View style={styles.footerRight}>
              {edited ? (
                <Animated.View entering={FadeIn} style={[styles.editedDot, { backgroundColor: accent }]} />
              ) : null}
              <Text style={[styles.editHint, { color: accent }]}>{enabled ? 'Edit prices' : 'Disabled'}</Text>
              <Ionicons name="chevron-forward" size={16} color={accent} />
            </View>
          </View>
        </GlassSurface>
      </Pressable>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 20,
    paddingTop: 16,
    paddingHorizontal: 16,
    paddingBottom: 12,
  },
  tierStripe: {
    position: 'absolute',
    left: 0,
    top: 16,
    bottom: 16,
    width: 3,
    borderTopRightRadius: 3,
    borderBottomRightRadius: 3,
    opacity: 0.85,
  },
  top: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  lead: { flexDirection: 'row', alignItems: 'center', flex: 1, gap: 12, minWidth: 0 },
  symbolBox: {
    width: 44,
    height: 44,
    borderRadius: 14,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  titles: { flex: 1, minWidth: 0 },
  titleLine: { flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' },
  title: { fontSize: 16, fontWeight: '800', flexShrink: 1 },
  sub: { fontSize: 13, fontWeight: '600', marginTop: 5, lineHeight: 18 },
  badge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
    borderWidth: 1,
  },
  badgeText: {
    color: '#F9FAFB',
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 14,
    paddingTop: 12,
    borderTopWidth: 1,
  },
  range: { fontSize: 16, fontWeight: '800', letterSpacing: -0.2 },
  footerRight: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  editedDot: { width: 7, height: 7, borderRadius: 4, marginRight: 4 },
  editHint: { fontSize: 13, fontWeight: '700' },
});
