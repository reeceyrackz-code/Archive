import { useEffect, useMemo } from 'react';
import {
  Image,
  StyleSheet,
  View,
  useWindowDimensions,
  type ImageSourcePropType,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import Animated, {
  Easing,
  Extrapolation,
  interpolate,
  interpolateColor,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withTiming,
  type SharedValue,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import GlassOrb from '../valeter/road/GlassOrb';
import type { IconGlyphName } from '../shared/iconGlyphTypes';
import { VALETER_VAN_ASPECT, VALETER_VAN_IMAGE } from '../../constants/washerAssets';

export type RoadLandmark = Readonly<{
  accent: string;
  icon?: IconGlyphName;
  image?: ImageSourcePropType;
  /** Draws a chequered finish line across the road at this stop. */
  finish?: boolean;
}>;

type Props = Readonly<{
  /** Current position in steps (0 = first stop); fractional while moving. */
  progress: SharedValue<number>;
  landmarks: readonly RoadLandmark[];
  height: number;
  style?: StyleProp<ViewStyle>;
}>;

const DASH_W = 22;
const DASH_GAP = 26;
const DASH_PERIOD = DASH_W + DASH_GAP;
const MARKER = 44;
const STEP_RATIO = 0.5;

/**
 * Top-down road with the Pro's branded van driving right. Advancing `progress` drives the car forward:
 * lane dashes scroll, roadside stops pass by and the last stop can be a finish line.
 */
export default function OnboardingCarRoad({ progress, landmarks, height, style }: Props) {
  const { width } = useWindowDimensions();
  const roadH = Math.max(64, Math.min(110, height - 2 * (MARKER + 18)));
  const roadY = height / 2;
  const vanW = Math.min(roadH * 0.66 * VALETER_VAN_ASPECT, width * 0.38);
  const vanH = vanW / VALETER_VAN_ASPECT;
  const carX = width * 0.36;
  const stepDist = width * STEP_RATIO;
  const reach = 0.5 / STEP_RATIO;
  const dashCount = Math.ceil(width / DASH_PERIOD) + 2;
  const accents = useMemo(() => landmarks.map((l) => l.accent), [landmarks]);
  const stops = useMemo(() => landmarks.map((_, i) => i), [landmarks]);

  const idle = useSharedValue(0);
  useEffect(() => {
    idle.value = withRepeat(
      withSequence(
        withTiming(1, { duration: 1400, easing: Easing.inOut(Easing.sin) }),
        withTiming(0, { duration: 1400, easing: Easing.inOut(Easing.sin) })
      ),
      -1
    );
  }, [idle]);

  const dashesStyle = useAnimatedStyle(() => {
    const offset = (progress.value * stepDist) % DASH_PERIOD;
    return { transform: [{ translateX: -offset }] };
  });

  const carStyle = useAnimatedStyle(() => {
    const frac = progress.value - Math.floor(progress.value);
    const surge = Math.sin(frac * Math.PI);
    const dir = Math.floor(progress.value) % 2 === 0 ? 1 : -1;
    return {
      transform: [
        { translateX: surge * 18 },
        { translateY: surge * 4 * dir - idle.value * 1.5 },
        { rotate: `${surge * 2.5 * dir}deg` },
        { scale: 1 + surge * 0.04 },
      ],
    };
  });

  const glowStyle = useAnimatedStyle(() => ({
    backgroundColor:
      accents.length > 1 ? interpolateColor(progress.value, stops, accents) : (accents[0] ?? '#38BDF8'),
    opacity: 0.16 + idle.value * 0.06,
  }));

  const streakStyle = useAnimatedStyle(() => {
    const frac = progress.value - Math.floor(progress.value);
    const surge = Math.sin(frac * Math.PI);
    return {
      opacity: surge * 0.7,
      transform: [{ translateX: 20 - ((progress.value * stepDist * 1.6) % 60) }],
    };
  });

  const carLen = vanW;

  return (
    <View style={[{ height }, styles.root, style]} pointerEvents="none">
      <LinearGradient
        colors={['transparent', 'rgba(148,163,184,0.12)', 'rgba(148,163,184,0.12)', 'transparent']}
        locations={[0, 0.15, 0.85, 1]}
        start={{ x: 0, y: 0.5 }}
        end={{ x: 1, y: 0.5 }}
        style={[styles.road, { height: roadH, top: roadY - roadH / 2 }]}
      />

      <View style={[styles.dashClip, { top: roadY - 2, width }]}>
        <Animated.View style={[styles.dashRow, dashesStyle]}>
          {Array.from({ length: dashCount }, (_, i) => (
            <View key={i} style={[styles.dash, { opacity: dashOpacity(i * DASH_PERIOD, width) }]} />
          ))}
        </Animated.View>
      </View>

      {landmarks.map((l, i) => (
        <Stop
          key={i}
          index={i}
          landmark={l}
          progress={progress}
          carX={carX}
          stepDist={stepDist}
          roadY={roadY}
          roadH={roadH}
          noseX={carLen / 2 + 4}
          reach={reach}
        />
      ))}

      <Animated.View
        style={[
          styles.glow,
          { width: carLen * 0.6, height: roadH * 0.8, left: carX - carLen * 0.3, top: roadY - roadH * 0.4 },
          glowStyle,
        ]}
      />

      <Animated.View
        style={[styles.streaks, { left: carX - carLen / 2 - 56, top: roadY - roadH / 2 + 6 }, streakStyle]}
      >
        <View style={styles.streak} />
        <View style={[styles.streak, styles.streakShort]} />
      </Animated.View>
      <Animated.View
        style={[styles.streaks, { left: carX - carLen / 2 - 48, top: roadY + roadH / 2 - 16 }, streakStyle]}
      >
        <View style={[styles.streak, styles.streakShort]} />
        <View style={styles.streak} />
      </Animated.View>

      <Animated.View
        style={[
          styles.car,
          { width: vanW, height: vanH, left: carX - vanW / 2, top: roadY - vanH / 2 },
          carStyle,
        ]}
      >
        <View style={[styles.carShadow, { width: vanW * 0.9, height: vanH * 0.82, borderRadius: vanH * 0.3 }]} />
        <Image source={VALETER_VAN_IMAGE} style={styles.carImage} resizeMode="contain" />
      </Animated.View>
    </View>
  );
}

function dashOpacity(x: number, width: number) {
  const edge = width * 0.18;
  if (x < edge) return Math.max(0, x / edge);
  if (x > width - edge) return Math.max(0, (width - x) / edge);
  return 1;
}

function Stop({
  index,
  landmark,
  progress,
  carX,
  stepDist,
  roadY,
  roadH,
  noseX,
  reach,
}: Readonly<{
  index: number;
  landmark: RoadLandmark;
  progress: SharedValue<number>;
  carX: number;
  stepDist: number;
  roadY: number;
  roadH: number;
  noseX: number;
  reach: number;
}>) {
  const above = index % 2 === 0;
  const y = landmark.finish
    ? roadY - roadH / 2
    : above
      ? roadY - roadH / 2 - MARKER - 8
      : roadY + roadH / 2 + 8;

  const style = useAnimatedStyle(() => {
    const d = index - progress.value;
    const r = d / reach;
    return {
      opacity: interpolate(r, [-1.2, -0.7, 0, 0.9, 1.4], [0, 0.55, 1, 0.55, 0], Extrapolation.CLAMP),
      transform: [
        { translateX: carX + d * stepDist },
        { scale: interpolate(Math.abs(r), [0, 1], [1, 0.82], Extrapolation.CLAMP) },
      ],
    };
  });

  if (landmark.finish) {
    return (
      <Animated.View style={[styles.finish, { height: roadH, left: noseX, top: y }, style]}>
        {[0, 1].map((col) => (
          <View key={col} style={styles.finishCol}>
            {Array.from({ length: Math.ceil(roadH / 12) }, (_, r) => (
              <View key={r} style={[styles.finishCell, (col + r) % 2 === 0 && styles.finishCellOn]} />
            ))}
          </View>
        ))}
      </Animated.View>
    );
  }

  return (
    <Animated.View style={[styles.stop, { left: -MARKER / 2, top: y }, style]}>
      {landmark.image ? (
        <View style={[styles.stopImage, { shadowColor: landmark.accent }]}>
          <Image source={landmark.image} style={StyleSheet.absoluteFill} resizeMode="cover" />
        </View>
      ) : (
        <GlassOrb icon={landmark.icon ?? 'ellipse'} accent={landmark.accent} size={MARKER} />
      )}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  root: { width: '100%', overflow: 'hidden' },
  road: { position: 'absolute', left: 0, right: 0, borderRadius: 999 },
  dashClip: { position: 'absolute', left: 0, height: 4, overflow: 'hidden' },
  dashRow: { flexDirection: 'row' },
  dash: {
    width: DASH_W,
    height: 4,
    marginRight: DASH_GAP,
    borderRadius: 2,
    backgroundColor: 'rgba(248,250,252,0.35)',
  },
  stop: { position: 'absolute', width: MARKER, height: MARKER },
  stopImage: {
    width: MARKER,
    height: MARKER,
    borderRadius: MARKER * 0.3,
    overflow: 'hidden',
    shadowOpacity: 0.5,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
  },
  finish: { position: 'absolute', width: 24, flexDirection: 'row', overflow: 'hidden', borderRadius: 4 },
  finishCol: { width: 12 },
  finishCell: { width: 12, height: 12, backgroundColor: 'rgba(2,10,24,0.35)' },
  finishCellOn: { backgroundColor: 'rgba(248,250,252,0.55)' },
  glow: { position: 'absolute', borderRadius: 999 },
  streaks: { position: 'absolute', gap: 6 },
  streak: { width: 46, height: 2, borderRadius: 1, backgroundColor: 'rgba(248,250,252,0.6)' },
  streakShort: { width: 28, marginLeft: 14 },
  car: { position: 'absolute', alignItems: 'center', justifyContent: 'center' },
  carShadow: {
    position: 'absolute',
    backgroundColor: 'rgba(0,0,0,0.35)',
    transform: [{ translateY: 6 }],
    shadowColor: '#000',
    shadowOpacity: 0.6,
    shadowRadius: 14,
  },
  carImage: { width: '100%', height: '100%' },
});
