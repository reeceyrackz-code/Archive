import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { avatarTint, initialsOf, type ChatPalette } from './chatTheme';

export const CHAT_HEADER_ROW = 58;

export function ChatAvatar({ name, size, online = false, ring }: Readonly<{ name: string; size: number; online?: boolean; ring?: string }>) {
  const tint = avatarTint(name);
  return (
    <View style={{ width: size, height: size }}>
      <View style={[styles.avatar, { width: size, height: size, borderRadius: size / 2, borderColor: ring ?? 'transparent', borderWidth: ring ? 2 : 0 }]}>
        <LinearGradient colors={[tint, `${tint}99`]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} />
        <Text style={[styles.avatarText, { fontSize: size * 0.36 }]}>{initialsOf(name)}</Text>
      </View>
      {online ? <View style={[styles.onlineDot, { width: size * 0.28, height: size * 0.28, borderRadius: size * 0.14 }]} /> : null}
    </View>
  );
}

function IconButton({ icon, color, onPress, label }: Readonly<{ icon: 'call' | 'trash-outline' | 'chevron-back'; color: string; onPress: () => void; label: string }>) {
  return (
    <Pressable
      onPress={() => {
        void hapticFeedback('light');
        onPress();
      }}
      hitSlop={8}
      style={({ pressed }) => [styles.iconBtn, pressed && styles.pressed]}
      accessibilityRole="button"
      accessibilityLabel={label}
    >
      <Ionicons name={icon} size={icon === 'chevron-back' ? 26 : 21} color={color} />
    </Pressable>
  );
}

export default function ChatHeader({
  title,
  subtitle,
  accent,
  palette,
  isLight,
  onBack,
  onCall,
  onDelete,
}: Readonly<{
  title: string;
  subtitle?: string;
  accent: string;
  palette: ChatPalette;
  isLight: boolean;
  onBack: () => void;
  onCall: () => void;
  onDelete?: () => void;
}>) {
  const insets = useSafeAreaInsets();
  return (
    <View style={[styles.wrap, { paddingTop: insets.top, borderBottomColor: palette.chromeBorder }]}>
      <BlurView intensity={40} tint={isLight ? 'light' : 'dark'} style={StyleSheet.absoluteFill} />
      <View style={[StyleSheet.absoluteFill, { backgroundColor: palette.chrome }]} />
      <View style={styles.row}>
        <IconButton icon="chevron-back" color={accent} onPress={onBack} label="Back" />
        <ChatAvatar name={title} size={38} online />
        <View style={styles.copy}>
          <Text style={[styles.title, { color: palette.text }]} numberOfLines={1}>
            {title}
          </Text>
          <Text style={[styles.sub, { color: palette.muted }]} numberOfLines={1}>
            {subtitle || 'Online'}
          </Text>
        </View>
        {onDelete ? <IconButton icon="trash-outline" color={accent} onPress={onDelete} label="Delete chat" /> : null}
        <IconButton icon="call" color={accent} onPress={onCall} label="Call" />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 10,
    overflow: 'hidden',
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  row: { height: CHAT_HEADER_ROW, flexDirection: 'row', alignItems: 'center', gap: 10, paddingLeft: 4, paddingRight: 8 },
  copy: { flex: 1, minWidth: 0 },
  title: { fontSize: 16.5, fontWeight: '800', letterSpacing: -0.2 },
  sub: { fontSize: 12.5, fontWeight: '600', marginTop: 1 },
  iconBtn: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  pressed: { opacity: 0.6 },
  avatar: { overflow: 'hidden', alignItems: 'center', justifyContent: 'center' },
  avatarText: { color: '#FFFFFF', fontWeight: '900', letterSpacing: 0.4 },
  onlineDot: { position: 'absolute', right: -1, bottom: -1, backgroundColor: '#34D399', borderWidth: 2, borderColor: '#0A1622' },
});
