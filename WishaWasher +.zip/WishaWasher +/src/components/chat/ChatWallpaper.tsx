import React, { memo } from 'react';
import { StyleSheet, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Svg, { Circle, Defs, G, Path, Pattern, Rect } from 'react-native-svg';

const TILE = 132;

/** Faint doodle tile behind the thread: bubbles, droplets, sparkles and chat marks. */
function ChatWallpaper({ wall, doodle, glow }: Readonly<{ wall: string; doodle: string; glow: string }>) {
  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill}>
      <View style={[StyleSheet.absoluteFill, { backgroundColor: wall }]} />
      <LinearGradient colors={[`${glow}1F`, 'transparent', `${glow}12`]} locations={[0, 0.5, 1]} style={StyleSheet.absoluteFill} />
      <Svg width="100%" height="100%">
        <Defs>
          <Pattern id="wawDoodle" width={TILE} height={TILE} patternUnits="userSpaceOnUse">
            <G stroke={doodle} strokeWidth={1.6} fill="none" strokeLinecap="round" strokeLinejoin="round">
              <Path d="M14 18 h22 a6 6 0 0 1 6 6 v10 a6 6 0 0 1 -6 6 h-12 l-7 6 v-6 h-3 a6 6 0 0 1 -6 -6 v-10 a6 6 0 0 1 6 -6 z" />
              <Path d="M86 12 c5 8 9 12 9 17 a9 9 0 0 1 -18 0 c0 -5 4 -9 9 -17 z" />
              <Path d="M104 62 l3 8 l8 3 l-8 3 l-3 8 l-3 -8 l-8 -3 l8 -3 z" />
              <Circle cx={30} cy={84} r={9} />
              <Circle cx={44} cy={96} r={5} />
              <Path d="M62 108 c4 6 7 9 7 13 a7 7 0 0 1 -14 0 c0 -4 3 -7 7 -13 z" />
              <Path d="M58 52 l2 5 l5 2 l-5 2 l-2 5 l-2 -5 l-5 -2 l5 -2 z" />
              <Path d="M92 104 h18 a5 5 0 0 1 5 5 v6 a5 5 0 0 1 -5 5 h-4 l-5 5 v-5 h-9 a5 5 0 0 1 -5 -5 v-6 a5 5 0 0 1 5 -5 z" />
              <Circle cx={118} cy={30} r={3} />
              <Circle cx={8} cy={120} r={3} />
            </G>
          </Pattern>
        </Defs>
        <Rect width="100%" height="100%" fill="url(#wawDoodle)" />
      </Svg>
    </View>
  );
}

export default memo(ChatWallpaper);
