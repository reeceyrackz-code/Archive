/**
 * Shared chat thread for valeter and business: WhatsApp-style bubbles with tails and grouping,
 * frosted header and composer, keyboard-following input, quick replies and a jump-to-latest button.
 */
import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Alert,
  ActivityIndicator,
  Keyboard,
  Platform,
  Pressable,
  type NativeScrollEvent,
  type NativeSyntheticEvent,
} from 'react-native';
import Reanimated, { FadeIn, FadeOut, ZoomIn, ZoomOut, useAnimatedKeyboard, useAnimatedStyle } from 'react-native-reanimated';
import { Ionicons as Glyph } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import { useGlobalTheme } from '../shared/GlobalThemeContext';
import { colors } from '../../constants/colors';
import { supabase } from '../../lib/supabase';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { parseBookingPaymentRequestPayload, type BookingPaymentRequestPayload } from '../../services/bookingPaymentRequestService';
import BubbleBackground from '../shared/BubbleBackground';
import ChatWallpaper from './ChatWallpaper';
import ChatHeader, { CHAT_HEADER_ROW, ChatAvatar } from './ChatHeader';
import ChatComposer, { ComposerLocked } from './ChatComposer';
import MessageBubble from './MessageBubble';
import { chatPalette, dayLabel, type ChatPalette } from './chatTheme';
import type { ChatMessage, MessageType } from './chatTypes';

export type { ChatMessage, MessageType } from './chatTypes';

const DEFAULT_ACCENT = colors.SKY;
/** Messages from the same side within this gap share one bubble group. */
const GROUP_GAP_MS = 5 * 60 * 1000;
const FAB_SHOW_PX = 260;

export interface ChatThreadViewProps {
  bookingId?: string | null;
  currentUserId?: string | null;
  currentUserRole?: 'customer' | 'valeter' | 'business' | null;
  title: string;
  subtitle?: string;
  onBack: () => void;
  onCall: () => void;
  onAttachImage?: () => void;
  onRequestPayment?: () => void;
  onPaymentRequestPay?: (request: BookingPaymentRequestPayload, messageId: string) => void;
  onDelete?: () => void;
  accentColor?: string;
  backgroundColor?: string;
  /** Initial messages (e.g. from DB). Omit or pass [] for no mock data. */
  initialMessages?: ChatMessage[];
  /** When true, hide composer (e.g. completed job until customer messages). */
  composerLocked?: boolean;
  composerLockHint?: string;
  /** One-tap phrases shown above an empty composer. */
  quickReplies?: readonly string[];
}

function sameGroup(a: ChatMessage | undefined, b: ChatMessage | undefined) {
  if (!a || !b || a.isFromMe !== b.isFromMe) return false;
  if (dayLabel(a.at) !== dayLabel(b.at)) return false;
  if (!a.at || !b.at) return true;
  return Math.abs(new Date(b.at).getTime() - new Date(a.at).getTime()) < GROUP_GAP_MS;
}

function DayChip({ label, palette }: Readonly<{ label: string; palette: ChatPalette }>) {
  return (
    <View style={[styles.dayChip, { backgroundColor: palette.chip }]}>
      <Text style={[styles.dayChipText, { color: palette.chipText }]}>{label}</Text>
    </View>
  );
}

function PrivacyNotice({ name, palette }: Readonly<{ name: string; palette: ChatPalette }>) {
  return (
    <View style={[styles.notice, { backgroundColor: palette.notice }]}>
      <Glyph name="lock-closed" size={12} color={palette.noticeText} />
      <Text style={[styles.noticeText, { color: palette.noticeText }]}>
        Messages are private to this booking. Only you and {name} can see them.
      </Text>
    </View>
  );
}

function EmptyHello({ name, subtitle, palette }: Readonly<{ name: string; subtitle?: string; palette: ChatPalette }>) {
  return (
    <Reanimated.View entering={FadeIn.duration(260)} style={[styles.hello, { backgroundColor: palette.chip }]}>
      <ChatAvatar name={name} size={64} />
      <Text style={[styles.helloTitle, { color: palette.text }]}>Say hello to {name}</Text>
      <Text style={[styles.helloSub, { color: palette.muted }]}>{subtitle ? `${subtitle} · ` : ''}Tap a quick reply below or type a message.</Text>
    </Reanimated.View>
  );
}

export default function ChatThreadView({
  bookingId,
  currentUserId,
  currentUserRole,
  title,
  subtitle,
  onBack,
  onCall,
  onAttachImage,
  onRequestPayment,
  onPaymentRequestPay,
  onDelete,
  accentColor,
  backgroundColor: backgroundColorProp,
  initialMessages = [],
  composerLocked = false,
  composerLockHint,
  quickReplies,
}: ChatThreadViewProps) {
  const insets = useSafeAreaInsets();
  const { mode } = useGlobalTheme();
  const { theme } = useAccountTheme();
  const isLight = mode === 'light';
  const palette = chatPalette(isLight);

  const accent = accentColor ?? theme?.primary ?? DEFAULT_ACCENT;
  const wall = isLight ? palette.wall : (backgroundColorProp ?? palette.wall);

  const [inputText, setInputText] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages);
  const [loadingMessages, setLoadingMessages] = useState(Boolean(bookingId));
  const [showFab, setShowFab] = useState(false);
  const [unseen, setUnseen] = useState(0);
  const scrollRef = useRef<ScrollView>(null);
  const nearBottomRef = useRef(true);
  const baseCountRef = useRef<number | null>(bookingId ? null : initialMessages.length);
  const isBookingChat = Boolean(bookingId);

  const scrollToEnd = useCallback((animated = true) => {
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated }), 60);
  }, []);

  const appendLocalMessage = (message: ChatMessage) => {
    setMessages((prev) => [...prev, message]);
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 120);
  };

  const mapDbRowToMessage = (row: {
    id: string;
    sender_id?: string | null;
    message_type?: string | null;
    content?: string | null;
    media_url?: string | null;
    voice_duration_seconds?: number | null;
    created_at?: string | null;
  }): ChatMessage => {
    const created = row.created_at ? new Date(row.created_at) : new Date();
    const type = (row.message_type as MessageType) || 'text';
    const paymentRequest = type === 'payment_request' ? parseBookingPaymentRequestPayload(row.content ?? null) : null;
    return {
      id: row.id,
      isFromMe: !!currentUserId && row.sender_id === currentUserId,
      type,
      content: row.content ?? undefined,
      mediaUri: row.media_url ?? undefined,
      voiceDurationSeconds: row.voice_duration_seconds ?? undefined,
      paymentRequest,
      time: created.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
      at: created.toISOString(),
    };
  };

  useEffect(() => {
    if (!isBookingChat) {
      setMessages(initialMessages);
      setLoadingMessages(false);
      return;
    }

    let mounted = true;
    (async () => {
      try {
        setLoadingMessages(true);
        setMessages(initialMessages);
        const { data, error } = await supabase
          .from('booking_messages')
          .select('id, sender_id, message_type, content, media_url, voice_duration_seconds, created_at')
          .eq('booking_id', bookingId)
          .order('created_at', { ascending: true });

        if (error) {
          if (__DEV__) {
            console.warn('[ChatThreadView] load messages error:', error.message);
          }
          return;
        }

        if (!mounted) return;
        const next = (data || []).map((row: any) => mapDbRowToMessage(row));
        setMessages(initialMessages.length > 0 ? [...initialMessages, ...next] : next);
      } catch (error) {
        if (__DEV__) {
          console.warn('[ChatThreadView] load messages exception:', error);
        }
      } finally {
        if (mounted) setLoadingMessages(false);
      }
    })();

    const channel = supabase
      .channel(`booking-messages-${bookingId}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'booking_messages', filter: `booking_id=eq.${bookingId}` },
        (payload) => {
          const row = payload.new as any;
          if (!row?.id) return;
          const next = mapDbRowToMessage(row);
          setMessages((prev) => (prev.some((msg) => msg.id === next.id) ? prev : [...prev, next]));
        }
      )
      .subscribe();

    return () => {
      mounted = false;
      supabase.removeChannel(channel);
    };
    // We intentionally load once per booking and keep live inserts only.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bookingId, currentUserId, isBookingChat]);

  /* Only messages that arrive after the first load animate in. */
  useEffect(() => {
    if (!loadingMessages && baseCountRef.current == null) baseCountRef.current = messages.length;
  }, [loadingMessages, messages.length]);

  const prevCountRef = useRef(messages.length);
  useEffect(() => {
    const added = messages.length - prevCountRef.current;
    prevCountRef.current = messages.length;
    if (added <= 0) return;
    const latest = messages.at(-1);
    if (latest?.isFromMe || nearBottomRef.current) scrollToEnd();
    else setUnseen((n) => n + added);
  }, [messages, scrollToEnd]);

  useEffect(() => {
    const evt = Platform.OS === 'ios' ? 'keyboardWillShow' : 'keyboardDidShow';
    const sub = Keyboard.addListener(evt, () => scrollToEnd());
    return () => sub.remove();
  }, [scrollToEnd]);

  const handleSend = async () => {
    const text = inputText.trim();
    if (!text) return;

    if (!isBookingChat) {
      const now = new Date();
      appendLocalMessage({
        id: String(Date.now()),
        isFromMe: true,
        type: 'text',
        content: text,
        time: now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
        at: now.toISOString(),
      });
      setInputText('');
      return;
    }

    if (!currentUserId || !bookingId) return;
    try {
      const { data, error } = await supabase
        .from('booking_messages')
        .insert({
          booking_id: bookingId,
          sender_id: currentUserId,
          sender_role: currentUserRole ?? 'unknown',
          message_type: 'text',
          content: text,
        })
        .select('id, sender_id, message_type, content, media_url, voice_duration_seconds, created_at')
        .single();

      if (error) throw error;

      if (data?.id) {
        const next = mapDbRowToMessage(data as any);
        setMessages((prev) => (prev.some((msg) => msg.id === next.id) ? prev : [...prev, next]));
      }

      setInputText('');
      setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 120);
    } catch (error: any) {
      Alert.alert('Message failed', error?.message || 'Could not send message right now.');
    }
  };

  const onScroll = (e: NativeSyntheticEvent<NativeScrollEvent>) => {
    const { contentOffset, contentSize, layoutMeasurement } = e.nativeEvent;
    const fromBottom = contentSize.height - (contentOffset.y + layoutMeasurement.height);
    nearBottomRef.current = fromBottom < 80;
    if (nearBottomRef.current && unseen > 0) setUnseen(0);
    const show = fromBottom > FAB_SHOW_PX;
    if (show !== showFab) setShowFab(show);
  };

  const keyboard = useAnimatedKeyboard();
  const safeBottom = Math.max(insets.bottom, 8);
  const liftStyle = useAnimatedStyle(() => ({ paddingBottom: keyboard.height.value }));
  const spacerStyle = useAnimatedStyle(() => ({ height: keyboard.height.value > 0 ? 8 : safeBottom }));

  const rows = useMemo(() => {
    const base = baseCountRef.current ?? Number.POSITIVE_INFINITY;
    return messages.map((msg, i) => {
      const prev = messages[i - 1];
      const next = messages[i + 1];
      const day = dayLabel(msg.at);
      return {
        msg,
        day: !prev || dayLabel(prev.at) !== day ? day : null,
        first: !sameGroup(prev, msg),
        last: !sameGroup(msg, next),
        animate: i >= base,
      };
    });
  }, [messages]);

  const contentTop = insets.top + CHAT_HEADER_ROW + 10;
  const lockHint = composerLockHint || 'Messaging is locked until the customer sends a message for this completed job.';

  let body: React.ReactNode;
  if (loadingMessages) {
    body = (
      <View style={styles.loading}>
        <ActivityIndicator size="small" color={accent} />
        <Text style={[styles.loadingText, { color: palette.muted }]}>Loading conversation…</Text>
      </View>
    );
  } else if (messages.length === 0) {
    body = <EmptyHello name={title} subtitle={subtitle} palette={palette} />;
  } else {
    body = rows.map(({ msg, day, first, last, animate }) => (
      <React.Fragment key={msg.id}>
        {day ? <DayChip label={day} palette={palette} /> : null}
        <MessageBubble
          msg={msg}
          first={first}
          last={last}
          animate={animate}
          accent={accent}
          palette={palette}
          onPaymentRequestPay={onPaymentRequestPay}
        />
      </React.Fragment>
    ));
  }

  return (
    <View style={[styles.container, { backgroundColor: wall }]}>
      <ChatWallpaper wall={wall} doodle={palette.doodle} glow={accent} />
      <BubbleBackground accountType={currentUserRole === 'business' ? 'business' : 'valeter'} bubbleCount={5} />

      <Reanimated.View style={[styles.column, liftStyle]}>
        <ScrollView
          ref={scrollRef}
          style={styles.flex}
          contentContainerStyle={[styles.content, { paddingTop: contentTop }]}
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode="interactive"
          onContentSizeChange={() => {
            if (nearBottomRef.current) scrollRef.current?.scrollToEnd({ animated: false });
          }}
          onScroll={onScroll}
          scrollEventThrottle={32}
          showsVerticalScrollIndicator={false}
        >
          <PrivacyNotice name={title} palette={palette} />
          {body}
        </ScrollView>

        {showFab ? (
          <Reanimated.View entering={ZoomIn.duration(160)} exiting={ZoomOut.duration(140)} style={styles.fabWrap}>
            <Pressable
              onPress={() => {
                void hapticFeedback('light');
                setUnseen(0);
                scrollToEnd();
              }}
              style={({ pressed }) => [styles.fab, { backgroundColor: palette.chip, borderColor: palette.chromeBorder }, pressed && styles.pressed]}
              accessibilityLabel="Jump to latest message"
            >
              <Glyph name="chevron-down" size={22} color={palette.text} />
            </Pressable>
            {unseen > 0 ? (
              <Reanimated.View entering={FadeIn} exiting={FadeOut} style={[styles.fabBadge, { backgroundColor: accent }]}>
                <Text style={styles.fabBadgeText}>{unseen}</Text>
              </Reanimated.View>
            ) : null}
          </Reanimated.View>
        ) : null}

        {composerLocked ? (
          <View style={styles.lockedWrap}>
            <ComposerLocked hint={lockHint} accent={accent} palette={palette} />
            <Reanimated.View style={spacerStyle} />
          </View>
        ) : (
          <View>
            <ChatComposer
              value={inputText}
              onChange={setInputText}
              onSend={() => void handleSend()}
              sendDisabled={isBookingChat && !currentUserId}
              accent={accent}
              palette={palette}
              isLight={isLight}
              quickReplies={quickReplies}
              onAttachImage={onAttachImage}
              onRequestPayment={onRequestPayment}
            />
            <Reanimated.View style={[spacerStyle, { backgroundColor: palette.chrome }]} />
          </View>
        )}
      </Reanimated.View>

      <ChatHeader
        title={title}
        subtitle={subtitle}
        accent={accent}
        palette={palette}
        isLight={isLight}
        onBack={onBack}
        onCall={onCall}
        onDelete={onDelete}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  column: { flex: 1 },
  flex: { flex: 1 },
  content: { paddingBottom: 12 },
  dayChip: {
    alignSelf: 'center',
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: 10,
    marginTop: 14,
    marginBottom: 4,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 2,
    shadowOffset: { width: 0, height: 1 },
  },
  dayChipText: { fontSize: 12, fontWeight: '700' },
  notice: {
    alignSelf: 'center',
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 6,
    maxWidth: '86%',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 12,
    marginBottom: 4,
  },
  noticeText: { flexShrink: 1, fontSize: 12, lineHeight: 16, fontWeight: '600', textAlign: 'center' },
  loading: { alignItems: 'center', paddingTop: 60, gap: 12 },
  loadingText: { fontSize: 14, fontWeight: '600' },
  hello: { alignSelf: 'center', alignItems: 'center', gap: 8, marginTop: 40, paddingHorizontal: 24, paddingVertical: 22, borderRadius: 22, maxWidth: '84%' },
  helloTitle: { fontSize: 18, fontWeight: '800', textAlign: 'center', marginTop: 6 },
  helloSub: { fontSize: 13.5, lineHeight: 19, textAlign: 'center', fontWeight: '500' },
  fabWrap: { position: 'absolute', right: 12, bottom: 96 },
  fab: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: StyleSheet.hairlineWidth,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.25,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 2 },
  },
  fabBadge: { position: 'absolute', top: -6, right: -4, minWidth: 20, height: 20, borderRadius: 10, paddingHorizontal: 5, alignItems: 'center', justifyContent: 'center' },
  fabBadgeText: { color: '#04121F', fontSize: 11, fontWeight: '900' },
  lockedWrap: { paddingTop: 8 },
  pressed: { opacity: 0.7 },
});
