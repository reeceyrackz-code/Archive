export type ChatPalette = Readonly<{
  wall: string;
  doodle: string;
  sent: string;
  received: string;
  text: string;
  textOnSent: string;
  meta: string;
  metaOnSent: string;
  chrome: string;
  chromeBorder: string;
  field: string;
  fieldBorder: string;
  muted: string;
  chip: string;
  chipText: string;
  notice: string;
  noticeText: string;
}>;

const DARK: ChatPalette = {
  wall: '#0A1622',
  doodle: 'rgba(148,197,233,0.07)',
  sent: '#12557A',
  received: '#1A2836',
  text: '#EEF4FA',
  textOnSent: '#F4FAFF',
  meta: 'rgba(170,190,210,0.75)',
  metaOnSent: 'rgba(214,236,250,0.72)',
  chrome: 'rgba(10,22,34,0.72)',
  chromeBorder: 'rgba(255,255,255,0.08)',
  field: 'rgba(255,255,255,0.07)',
  fieldBorder: 'rgba(255,255,255,0.1)',
  muted: 'rgba(170,190,210,0.75)',
  chip: 'rgba(26,40,54,0.92)',
  chipText: 'rgba(214,226,238,0.85)',
  notice: 'rgba(251,191,36,0.1)',
  noticeText: 'rgba(253,224,150,0.9)',
};

const LIGHT: ChatPalette = {
  wall: '#E8F0F6',
  doodle: 'rgba(30,80,120,0.07)',
  sent: '#CDE9FB',
  received: '#FFFFFF',
  text: '#0F2740',
  textOnSent: '#0B2236',
  meta: 'rgba(15,39,64,0.5)',
  metaOnSent: 'rgba(15,39,64,0.55)',
  chrome: 'rgba(240,246,251,0.82)',
  chromeBorder: 'rgba(15,39,64,0.08)',
  field: '#FFFFFF',
  fieldBorder: 'rgba(15,39,64,0.1)',
  muted: 'rgba(15,39,64,0.55)',
  chip: 'rgba(255,255,255,0.92)',
  chipText: 'rgba(15,39,64,0.7)',
  notice: 'rgba(251,191,36,0.16)',
  noticeText: '#7A5A00',
};

/** One-tap phrases a Pro sends most on the way to, and at, a job. */
export const VALETER_QUICK_REPLIES = [
  'On my way 🚐',
  'Running 5 mins late',
  "I've arrived 👋",
  'Where shall I park?',
  'Can you leave the car unlocked?',
  'All done! ✨',
] as const;

export function chatPalette(isLight: boolean): ChatPalette {
  return isLight ? LIGHT : DARK;
}

export function initialsOf(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return '?';
  const first = parts[0]?.[0] ?? '';
  const last = parts.length > 1 ? (parts.at(-1)?.[0] ?? '') : '';
  return (first + last).toUpperCase();
}

const AVATAR_HUES = ['#38BDF8', '#34D399', '#A78BFA', '#F472B6', '#FBBF24', '#60A5FA', '#2DD4BF', '#FB923C'];

/** Stable colour per name, so each contact keeps the same avatar tint. */
export function avatarTint(name: string): string {
  let h = 0;
  for (const ch of name) h = (h * 31 + (ch.codePointAt(0) ?? 0)) >>> 0;
  return AVATAR_HUES[h % AVATAR_HUES.length]!;
}

export function dayLabel(iso: string | undefined): string {
  if (!iso) return 'Today';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return 'Today';
  const today = new Date();
  const startOf = (x: Date) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const diff = Math.round((startOf(today) - startOf(d)) / 86400000);
  if (diff === 0) return 'Today';
  if (diff === 1) return 'Yesterday';
  if (diff < 7) return d.toLocaleDateString('en-GB', { weekday: 'long' });
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: d.getFullYear() === today.getFullYear() ? undefined : 'numeric' });
}
