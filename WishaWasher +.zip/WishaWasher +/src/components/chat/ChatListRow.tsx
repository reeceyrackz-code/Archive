import React from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { Ionicons as Glyph } from '@expo/vector-icons';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { PulseDot } from '../shared/fit/FitKit';
import { ChatAvatar } from './ChatHeader';

const TEXT = '#F4F8FC';
const MUTED = 'rgba(190,206,222,0.72)';
const LINE = 'rgba(255,255,255,0.08)';

export type ChatListRowProps = Readonly<{
  name: string;
  time: string;
  preview: string;
  /** Last message was mine: show read ticks before the preview. */
  fromMe?: boolean;
  status?: Readonly<{ label: string; color: string; live: boolean }>;
  unread?: number;
  accent: string;
  last?: boolean;
  onPress: () => void;
  onLongPress?: () => void;
}>;

export default function ChatListRow({ name, time, preview, fromMe, status, unread = 0, accent, last, onPress, onLongPress }: ChatListRowProps) {
  const hasUnread = unread > 0;
  return (
    <Pressable
      onPress={() => {
        void hapticFeedback('light');
        onPress();
      }}
      onLongPress={onLongPress}
      style={({ pressed }) => [styles.row, pressed && styles.pressed]}
      accessibilityRole="button"
      accessibilityLabel={`Chat with ${name}`}
    >
      <ChatAvatar name={name} size={54} ring={status?.color} />
      <View style={[styles.body, !last && styles.divider]}>
        <View style={styles.top}>
          <Text style={styles.name} numberOfLines={1}>
            {name}
          </Text>
          <Text style={[styles.time, hasUnread && { color: accent, fontWeight: '800' }]}>{time}</Text>
        </View>
        <View style={styles.bottom}>
          <View style={styles.previewRow}>
            {status ? (
              <View style={[styles.status, { backgroundColor: `${status.color}22` }]}>
                {status.live ? <PulseDot color={status.color} size={5} /> : <View style={[styles.dot, { backgroundColor: status.color }]} />}
                <Text style={[styles.statusText, { color: status.color }]}>{status.label}</Text>
              </View>
            ) : null}
            {fromMe ? <Glyph name="checkmark-done" size={15} color="#53BDEB" /> : null}
            <Text style={[styles.preview, hasUnread && styles.previewUnread]} numberOfLines={1}>
              {preview}
            </Text>
          </View>
          {hasUnread ? (
            <View style={[styles.badge, { backgroundColor: accent }]}>
              <Text style={styles.badgeText}>{unread > 99 ? '99+' : unread}</Text>
            </View>
          ) : null}
        </View>
      </View>
    </Pressable>
  );
}

export function ChatSearchBar({ value, onChange, placeholder = 'Search' }: Readonly<{ value: string; onChange: (v: string) => void; placeholder?: string }>) {
  return (
    <View style={styles.search}>
      <Glyph name="search" size={17} color={MUTED} />
      <TextInput
        value={value}
        onChangeText={onChange}
        placeholder={placeholder}
        placeholderTextColor={MUTED}
        style={styles.searchInput}
        autoCorrect={false}
        returnKeyType="search"
      />
      {value ? (
        <Pressable onPress={() => onChange('')} hitSlop={10} accessibilityLabel="Clear search">
          <Glyph name="close-circle" size={17} color={MUTED} />
        </Pressable>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: 13, paddingLeft: 14 },
  pressed: { backgroundColor: 'rgba(255,255,255,0.05)' },
  body: { flex: 1, minWidth: 0, paddingVertical: 12, paddingRight: 14, gap: 4 },
  divider: { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: LINE },
  top: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  name: { flex: 1, color: TEXT, fontSize: 16.5, fontWeight: '800', letterSpacing: -0.2 },
  time: { color: MUTED, fontSize: 12, fontWeight: '600', fontVariant: ['tabular-nums'] },
  bottom: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  previewRow: { flex: 1, minWidth: 0, flexDirection: 'row', alignItems: 'center', gap: 6 },
  status: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 7, paddingVertical: 2.5, borderRadius: 999 },
  dot: { width: 5, height: 5, borderRadius: 2.5 },
  statusText: { fontSize: 10.5, fontWeight: '800' },
  preview: { flex: 1, minWidth: 0, color: MUTED, fontSize: 14, fontWeight: '500' },
  previewUnread: { color: TEXT, fontWeight: '700' },
  badge: { minWidth: 22, height: 22, borderRadius: 11, paddingHorizontal: 6, alignItems: 'center', justifyContent: 'center' },
  badgeText: { color: '#04121F', fontSize: 12, fontWeight: '900' },
  search: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    height: 40,
    paddingHorizontal: 12,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  searchInput: { flex: 1, color: TEXT, fontSize: 15.5, fontWeight: '500', paddingVertical: 0 },
});
