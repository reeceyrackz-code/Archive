import type { BookingPaymentRequestPayload } from '../../services/bookingPaymentRequestService';

export type MessageType = 'text' | 'image' | 'voice' | 'payment_request';

export type ChatMessage = {
  id: string;
  isFromMe: boolean;
  type: MessageType;
  content?: string;
  mediaUri?: string;
  voiceDurationSeconds?: number;
  paymentRequest?: BookingPaymentRequestPayload | null;
  time: string;
  /** ISO timestamp; drives day separators and bubble grouping. */
  at?: string;
};
