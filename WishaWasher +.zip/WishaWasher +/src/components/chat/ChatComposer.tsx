import React, { useRef, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { BlurView } from 'expo-blur';
import Reanimated, { FadeIn, FadeInDown, FadeOut, FadeOutDown } from 'react-native-reanimated';
import { Ionicons as Glyph } from '@expo/vector-icons';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import type { ChatPalette } from './chatTheme';

type GlyphName = React.ComponentProps<typeof Glyph>['name'];
type TrayItem = Readonly<{ key: string; label: string; icon: GlyphName; color: string; onPress: () => void }>;

function TrayTile({ item, palette, onDone }: Readonly<{ item: TrayItem; palette: ChatPalette; onDone: () => void }>) {
  return (
    <Pressable
      onPress={() => {
        void hapticFeedback('light');
        onDone();
        item.onPress();
      }}
      style={({ pressed }) => [styles.tile, pressed && styles.pressed]}
      accessibilityRole="button"
      accessibilityLabel={item.label}
    >
      <View style={[styles.tileIcon, { backgroundColor: item.color }]}>
        <Glyph name={item.icon} size={22} color="#FFFFFF" />
      </View>
      <Text style={[styles.tileLabel, { color: palette.text }]}>{item.label}</Text>
    </Pressable>
  );
}

function QuickReplies({
  replies,
  accent,
  palette,
  onPick,
}: Readonly<{ replies: readonly string[]; accent: string; palette: ChatPalette; onPick: (reply: string) => void }>) {
  return (
    <Reanimated.View entering={FadeIn.duration(180)} exiting={FadeOut.duration(120)}>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.replies} keyboardShouldPersistTaps="handled">
        {replies.map((r) => (
          <Pressable
            key={r}
            onPress={() => {
              void hapticFeedback('light');
              onPick(r);
            }}
            style={({ pressed }) => [styles.reply, { borderColor: `${accent}55`, backgroundColor: `${accent}14` }, pressed && styles.pressed]}
          >
            <Text style={[styles.replyText, { color: palette.text }]}>{r}</Text>
          </Pressable>
        ))}
      </ScrollView>
    </Reanimated.View>
  );
}

export default function ChatComposer({
  value,
  onChange,
  onSend,
  sendDisabled,
  accent,
  palette,
  isLight,
  quickReplies,
  onAttachImage,
  onRequestPayment,
}: Readonly<{
  value: string;
  onChange: (text: string) => void;
  onSend: () => void;
  sendDisabled?: boolean;
  accent: string;
  palette: ChatPalette;
  isLight: boolean;
  quickReplies?: readonly string[];
  onAttachImage?: () => void;
  onRequestPayment?: () => void;
}>) {
  const [trayOpen, setTrayOpen] = useState(false);
  const inputRef = useRef<TextInput>(null);
  const canSend = value.trim().length > 0;

  const tray: TrayItem[] = [];
  if (onAttachImage) tray.push({ key: 'photo', label: 'Photo', icon: 'camera', color: '#EC4899', onPress: onAttachImage });
  if (onRequestPayment) tray.push({ key: 'charge', label: 'Extra charge', icon: 'wallet', color: '#10B981', onPress: onRequestPayment });

  const showReplies = !trayOpen && !canSend && (quickReplies?.length ?? 0) > 0;

  return (
    <View style={[styles.wrap, { borderTopColor: palette.chromeBorder }]}>
      <BlurView intensity={40} tint={isLight ? 'light' : 'dark'} style={StyleSheet.absoluteFill} />
      <View style={[StyleSheet.absoluteFill, { backgroundColor: palette.chrome }]} />

      {trayOpen && tray.length > 0 ? (
        <Reanimated.View entering={FadeInDown.duration(200)} exiting={FadeOutDown.duration(150)} style={styles.tray}>
          {tray.map((item) => (
            <TrayTile key={item.key} item={item} palette={palette} onDone={() => setTrayOpen(false)} />
          ))}
        </Reanimated.View>
      ) : null}

      {showReplies && quickReplies ? (
        <QuickReplies
          replies={quickReplies}
          accent={accent}
          palette={palette}
          onPick={(r) => {
            onChange(r);
            inputRef.current?.focus();
          }}
        />
      ) : null}

      <View style={styles.row}>
        {tray.length > 0 ? (
          <Pressable
            onPress={() => {
              void hapticFeedback('light');
              setTrayOpen((o) => !o);
            }}
            style={({ pressed }) => [styles.plus, pressed && styles.pressed]}
            accessibilityRole="button"
            accessibilityLabel={trayOpen ? 'Close attachments' : 'Attach'}
          >
            <Glyph name={trayOpen ? 'close' : 'add'} size={28} color={accent} />
          </Pressable>
        ) : null}

        <View style={[styles.field, { backgroundColor: palette.field, borderColor: palette.fieldBorder }]}>
          <TextInput
            ref={inputRef}
            style={[styles.input, { color: palette.text }]}
            placeholder="Message"
            placeholderTextColor={palette.muted}
            value={value}
            onChangeText={onChange}
            onFocus={() => setTrayOpen(false)}
            multiline
            maxLength={500}
          />
          {onAttachImage && !canSend ? (
            <Pressable onPress={onAttachImage} hitSlop={8} style={styles.inFieldBtn} accessibilityLabel="Send a photo">
              <Glyph name="camera-outline" size={22} color={palette.muted} />
            </Pressable>
          ) : null}
        </View>

        <Pressable
          onPress={() => {
            void hapticFeedback('light');
            onSend();
          }}
          disabled={sendDisabled || !canSend}
          style={({ pressed }) => [styles.action, { backgroundColor: accent }, !canSend && styles.actionIdle, pressed && styles.pressed]}
          accessibilityRole="button"
          accessibilityLabel="Send"
        >
          <Glyph name="send" size={18} color="#04121F" style={styles.sendNudge} />
        </Pressable>
      </View>
    </View>
  );
}

export function ComposerLocked({ hint, accent, palette }: Readonly<{ hint: string; accent: string; palette: ChatPalette }>) {
  return (
    <View style={[styles.locked, { backgroundColor: palette.chip, borderColor: palette.chromeBorder }]}>
      <Glyph name="lock-closed" size={16} color={accent} />
      <Text style={[styles.lockedText, { color: palette.muted }]}>{hint}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { overflow: 'hidden', borderTopWidth: StyleSheet.hairlineWidth, paddingTop: 8 },
  tray: { flexDirection: 'row', gap: 18, paddingHorizontal: 18, paddingTop: 6, paddingBottom: 14 },
  tile: { alignItems: 'center', gap: 6, width: 72 },
  tileIcon: { width: 54, height: 54, borderRadius: 27, alignItems: 'center', justifyContent: 'center' },
  tileLabel: { fontSize: 12, fontWeight: '700' },
  replies: { gap: 8, paddingHorizontal: 10, paddingBottom: 8 },
  reply: { paddingHorizontal: 13, paddingVertical: 7, borderRadius: 999, borderWidth: 1 },
  replyText: { fontSize: 13.5, fontWeight: '700' },
  row: { flexDirection: 'row', alignItems: 'flex-end', gap: 6, paddingHorizontal: 6 },
  plus: { width: 40, height: 44, alignItems: 'center', justifyContent: 'center' },
  field: {
    flex: 1,
    minWidth: 0,
    flexDirection: 'row',
    alignItems: 'flex-end',
    borderRadius: 22,
    borderWidth: StyleSheet.hairlineWidth,
    paddingLeft: 14,
    paddingRight: 6,
    minHeight: 44,
  },
  input: { flex: 1, minWidth: 0, maxHeight: 120, fontSize: 16.5, lineHeight: 21, paddingTop: 11, paddingBottom: 11 },
  inFieldBtn: { width: 36, height: 44, alignItems: 'center', justifyContent: 'center' },
  action: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  actionIdle: { opacity: 0.4 },
  sendNudge: { marginLeft: 2 },
  pressed: { opacity: 0.7 },
  locked: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginHorizontal: 12,
    paddingVertical: 13,
    paddingHorizontal: 16,
    borderRadius: 18,
    borderWidth: StyleSheet.hairlineWidth,
  },
  lockedText: { flex: 1, fontSize: 13, lineHeight: 18, fontWeight: '600' },
});
