import React, { memo, useState } from 'react';
import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Reanimated, { FadeIn, FadeInUp, FadeOut, LinearTransition } from 'react-native-reanimated';
import Svg, { Path } from 'react-native-svg';
import { Ionicons as Glyph } from '@expo/vector-icons';
import type { BookingPaymentRequestPayload, BookingPaymentRequestStatus } from '../../services/bookingPaymentRequestService';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import type { ChatPalette } from './chatTheme';
import type { ChatMessage } from './chatTypes';

const RADIUS = 18;
const TIGHT = 6;
const READ_BLUE = '#53BDEB';

function formatMoney(amount: number, currency = 'gbp') {
  return new Intl.NumberFormat('en-GB', { style: 'currency', currency: currency.toUpperCase() }).format(amount);
}

function paymentStatusMeta(status: BookingPaymentRequestStatus | undefined, accent: string) {
  switch (status) {
    case 'paid':
      return { label: 'Paid', color: '#34D399', icon: 'checkmark-circle' as const };
    case 'failed':
      return { label: 'Failed', color: '#F87171', icon: 'close-circle' as const };
    case 'declined':
      return { label: 'Declined', color: '#94A3B8', icon: 'remove-circle' as const };
    case 'cancelled':
      return { label: 'Cancelled', color: '#94A3B8', icon: 'ban' as const };
    default:
      return { label: 'Awaiting payment', color: accent, icon: 'time-outline' as const };
  }
}

function Tail({ mine, color }: Readonly<{ mine: boolean; color: string }>) {
  return (
    <Svg width={9} height={14} style={mine ? styles.tailMine : styles.tailTheirs}>
      <Path d={mine ? 'M0 0 H9 Q5 3 0 13 Z' : 'M9 0 H0 Q4 3 9 13 Z'} fill={color} />
    </Svg>
  );
}

function Meta({ time, mine, color, overMedia = false }: Readonly<{ time: string; mine: boolean; color: string; overMedia?: boolean }>) {
  return (
    <View style={[styles.meta, overMedia && styles.metaOverMedia]}>
      <Text style={[styles.metaTime, { color: overMedia ? '#FFFFFF' : color }]}>{time}</Text>
      {mine ? <Glyph name="checkmark-done" size={15} color={overMedia ? '#FFFFFF' : READ_BLUE} /> : null}
    </View>
  );
}

/** Invisible copy of the meta row so the last text line leaves room for the time, WhatsApp-style. */
function MetaSpacer({ time, mine }: Readonly<{ time: string; mine: boolean }>) {
  return <Text style={styles.metaSpacer}>{`  ${time}${mine ? '   ' : ''}  `}</Text>;
}

type StatusMeta = ReturnType<typeof paymentStatusMeta>;
type PayHandler = (request: BookingPaymentRequestPayload, messageId: string) => void;

function WalletHead({
  open,
  status,
  text,
  soft,
  onToggle,
}: Readonly<{ open: boolean; status: StatusMeta; text: string; soft: string; onToggle: () => void }>) {
  return (
    <Pressable
      onPress={onToggle}
      style={({ pressed }) => [styles.walletHead, pressed && styles.pressed]}
      accessibilityRole="button"
      accessibilityState={{ expanded: open }}
      accessibilityLabel={open ? 'Hide extra charge details' : 'Show extra charge details'}
    >
      <View style={[styles.walletIcon, { backgroundColor: `${status.color}26`, borderColor: `${status.color}55` }]}>
        <Glyph name="wallet" size={17} color={status.color} />
      </View>
      <View style={styles.walletCopy}>
        <Text style={[styles.walletTitle, { color: text }]}>Extra charge</Text>
        <View style={styles.walletStatus}>
          <View style={[styles.walletDot, { backgroundColor: status.color }]} />
          <Text style={[styles.walletStatusText, { color: soft }]}>{status.label}</Text>
        </View>
      </View>
      <Glyph name={open ? 'chevron-up' : 'chevron-down'} size={16} color={soft} />
    </Pressable>
  );
}

function WalletDetails({
  request,
  status,
  accent,
  text,
  soft,
  onPay,
}: Readonly<{ request: BookingPaymentRequestPayload; status: StatusMeta; accent: string; text: string; soft: string; onPay?: () => void }>) {
  const currency = request.currency || 'gbp';
  const awaitingPayout = request.payoutStatus === 'pending' && request.status === 'paid';
  return (
    <Reanimated.View entering={FadeIn.duration(180)} exiting={FadeOut.duration(120)} style={styles.walletBody}>
      <LinearGradient colors={[`${status.color}24`, 'transparent']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.payGlow} />
      <Text style={[styles.payAmount, { color: text }]}>{formatMoney(request.amount, currency)}</Text>
      {request.reason ? <Text style={[styles.payReason, { color: text }]}>{request.reason}</Text> : null}
      {request.note ? <Text style={[styles.payNote, { color: soft }]}>{request.note}</Text> : null}
      <View style={[styles.payDivider, { backgroundColor: soft }]} />
      <Text style={[styles.payMeta, { color: soft }]}>
        Fee {formatMoney(request.platformFee ?? 0, currency)} · Pro receives {formatMoney(request.valeterShare ?? 0, currency)}
      </Text>
      {awaitingPayout ? <Text style={[styles.payMeta, { color: soft }]}>Payout releases when the job is marked complete.</Text> : null}
      {onPay ? (
        <Pressable onPress={onPay} style={({ pressed }) => [styles.payBtn, { backgroundColor: accent }, pressed && styles.pressed]}>
          <Glyph name="lock-closed" size={14} color="#04121F" />
          <Text style={styles.payBtnText}>Pay {formatMoney(request.amount, currency)}</Text>
        </Pressable>
      ) : null}
    </Reanimated.View>
  );
}

/** Extra charge folded into a small wallet; tapping it opens the price, reason and pay details. */
function PaymentWallet({
  msg,
  request,
  accent,
  palette,
  mine,
  onPay,
}: Readonly<{
  msg: ChatMessage;
  request: BookingPaymentRequestPayload;
  accent: string;
  palette: ChatPalette;
  mine: boolean;
  onPay?: PayHandler;
}>) {
  const [open, setOpen] = useState(false);
  const status = paymentStatusMeta(request.status, accent);
  const text = mine ? palette.textOnSent : palette.text;
  const soft = mine ? palette.metaOnSent : palette.meta;
  const canPay = !mine && request.status === 'pending' && onPay;
  const toggle = () => {
    void hapticFeedback('light');
    setOpen((o) => !o);
  };
  return (
    <View style={[styles.wallet, open && styles.walletOpen]}>
      <WalletHead open={open} status={status} text={text} soft={soft} onToggle={toggle} />
      {open ? (
        <WalletDetails
          request={request}
          status={status}
          accent={accent}
          text={text}
          soft={soft}
          onPay={canPay ? () => onPay(request, msg.id) : undefined}
        />
      ) : null}
    </View>
  );
}

type BodyProps = Readonly<{ msg: ChatMessage; mine: boolean; textColor: string; metaColor: string }>;

function TextBody({ msg, mine, textColor, metaColor }: BodyProps) {
  return (
    <View style={styles.textPad}>
      <Text style={[styles.text, { color: textColor }]}>
        {msg.content}
        <MetaSpacer time={msg.time} mine={mine} />
      </Text>
      <Meta time={msg.time} mine={mine} color={metaColor} />
    </View>
  );
}

function ImageBody({ msg, mine, textColor, metaColor }: BodyProps) {
  const hasCaption = Boolean(msg.content) && msg.content !== 'IMAGE';
  return (
    <View>
      {msg.mediaUri ? (
        <Image source={{ uri: msg.mediaUri }} style={styles.image} resizeMode="cover" />
      ) : (
        <View style={[styles.image, styles.imageEmpty]}>
          <Glyph name="image-outline" size={34} color={metaColor} />
        </View>
      )}
      {hasCaption ? (
        <View style={styles.captionPad}>
          <Text style={[styles.text, { color: textColor }]}>
            {msg.content}
            <MetaSpacer time={msg.time} mine={mine} />
          </Text>
          <Meta time={msg.time} mine={mine} color={metaColor} />
        </View>
      ) : (
        <>
          <LinearGradient colors={['transparent', 'rgba(0,0,0,0.45)']} style={styles.imageShade} pointerEvents="none" />
          <Meta time={msg.time} mine={mine} color={metaColor} overMedia />
        </>
      )}
    </View>
  );
}

function LegacyVoiceBody({ msg, mine, metaColor }: BodyProps) {
  return (
    <View style={styles.textPad}>
      <Text style={[styles.legacyVoice, { color: metaColor }]}>
        Voice message
        <MetaSpacer time={msg.time} mine={mine} />
      </Text>
      <Meta time={msg.time} mine={mine} color={metaColor} />
    </View>
  );
}

function BubbleBody(
  props: BodyProps & Readonly<{ accent: string; palette: ChatPalette; onPaymentRequestPay?: PayHandler }>
) {
  const { msg, mine, metaColor, accent, palette, onPaymentRequestPay } = props;
  if (msg.type === 'payment_request' && msg.paymentRequest) {
    return (
      <View style={styles.paymentPad}>
        <PaymentWallet msg={msg} request={msg.paymentRequest} accent={accent} palette={palette} mine={mine} onPay={onPaymentRequestPay} />
        <Meta time={msg.time} mine={mine} color={metaColor} />
      </View>
    );
  }
  if (msg.type === 'image') return <ImageBody {...props} />;
  if (msg.type === 'voice') return <LegacyVoiceBody {...props} />;
  if (msg.type === 'text') return <TextBody {...props} />;
  return null;
}

function bubbleLook(mine: boolean, first: boolean, last: boolean, palette: ChatPalette) {
  const top = first ? 0 : TIGHT;
  const bottom = last ? RADIUS : TIGHT;
  if (mine) {
    return {
      bg: palette.sent,
      textColor: palette.textOnSent,
      metaColor: palette.metaOnSent,
      corners: { borderTopRightRadius: top, borderBottomRightRadius: bottom },
    };
  }
  return {
    bg: palette.received,
    textColor: palette.text,
    metaColor: palette.meta,
    corners: { borderTopLeftRadius: top, borderBottomLeftRadius: bottom },
  };
}

function MessageBubble({
  msg,
  first,
  last,
  animate,
  accent,
  palette,
  onPaymentRequestPay,
}: Readonly<{
  msg: ChatMessage;
  /** First of a run from the same sender: gets the tail. */
  first: boolean;
  last: boolean;
  animate: boolean;
  accent: string;
  palette: ChatPalette;
  onPaymentRequestPay?: PayHandler;
}>) {
  const mine = msg.isFromMe;
  const { bg, textColor, metaColor, corners } = bubbleLook(mine, first, last, palette);
  const isPayment = msg.type === 'payment_request' && Boolean(msg.paymentRequest);

  return (
    <Reanimated.View
      entering={animate ? FadeInUp.springify().damping(18).stiffness(220) : undefined}
      layout={isPayment ? LinearTransition.springify().damping(20) : undefined}
      style={[styles.row, mine ? styles.rowMine : styles.rowTheirs, { marginTop: first ? 8 : 2 }]}
    >
      <View style={[styles.bubble, { backgroundColor: bg }, corners, msg.type === 'image' && styles.bubbleMedia]}>
        {first ? <Tail mine={mine} color={bg} /> : null}
        <BubbleBody
          msg={msg}
          mine={mine}
          textColor={textColor}
          metaColor={metaColor}
          accent={accent}
          palette={palette}
          onPaymentRequestPay={onPaymentRequestPay}
        />
      </View>
    </Reanimated.View>
  );
}

export default memo(MessageBubble);

const styles = StyleSheet.create({
  row: { maxWidth: '80%' },
  rowMine: { alignSelf: 'flex-end', marginRight: 8 },
  rowTheirs: { alignSelf: 'flex-start', marginLeft: 8 },
  bubble: {
    borderRadius: RADIUS,
    shadowColor: '#000',
    shadowOpacity: 0.12,
    shadowRadius: 2,
    shadowOffset: { width: 0, height: 1 },
    elevation: 1,
  },
  bubbleMedia: { padding: 3 },
  tailMine: { position: 'absolute', top: 0, right: -8 },
  tailTheirs: { position: 'absolute', top: 0, left: -8 },
  textPad: { paddingHorizontal: 11, paddingTop: 7, paddingBottom: 7 },
  text: { fontSize: 16, lineHeight: 21.5, letterSpacing: -0.1 },
  meta: { position: 'absolute', right: 9, bottom: 5, flexDirection: 'row', alignItems: 'center', gap: 3 },
  metaOverMedia: { right: 10, bottom: 8 },
  metaTime: { fontSize: 11, fontWeight: '500', fontVariant: ['tabular-nums'] },
  metaSpacer: { fontSize: 11, color: 'transparent' },
  image: { width: 236, height: 236, borderRadius: 15 },
  imageEmpty: { alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(0,0,0,0.18)' },
  imageShade: { position: 'absolute', left: 0, right: 0, bottom: 0, height: 56, borderBottomLeftRadius: 15, borderBottomRightRadius: 15 },
  captionPad: { paddingHorizontal: 8, paddingTop: 6, paddingBottom: 6, width: 236 },
  legacyVoice: { fontSize: 15, lineHeight: 21, fontStyle: 'italic' },
  paymentPad: { padding: 4, paddingBottom: 20 },
  wallet: { width: 200, borderRadius: 14, overflow: 'hidden' },
  walletOpen: { width: 256 },
  walletHead: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 8, paddingVertical: 7 },
  walletIcon: {
    width: 36,
    height: 36,
    borderRadius: 11,
    borderWidth: StyleSheet.hairlineWidth,
    alignItems: 'center',
    justifyContent: 'center',
  },
  walletCopy: { flex: 1, minWidth: 0, gap: 2 },
  walletTitle: { fontSize: 14.5, fontWeight: '800' },
  walletStatus: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  walletDot: { width: 6, height: 6, borderRadius: 3 },
  walletStatusText: { fontSize: 11.5, fontWeight: '700' },
  walletBody: { paddingHorizontal: 10, paddingTop: 4, paddingBottom: 10, gap: 6, borderRadius: 12, overflow: 'hidden' },
  payGlow: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 },
  payAmount: { fontSize: 28, fontWeight: '900', letterSpacing: -0.8, marginTop: 4 },
  payReason: { fontSize: 14.5, lineHeight: 20, fontWeight: '600' },
  payNote: { fontSize: 13, lineHeight: 18, fontStyle: 'italic' },
  payDivider: { height: StyleSheet.hairlineWidth, opacity: 0.5, marginVertical: 4 },
  payMeta: { fontSize: 11.5, lineHeight: 16, fontWeight: '600' },
  payBtn: { marginTop: 6, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, borderRadius: 12, paddingVertical: 12 },
  payBtnText: { color: '#04121F', fontSize: 15, fontWeight: '900' },
  pressed: { opacity: 0.8 },
});
