/**
 * Asset requires rooted from the top-level assets folder so Metro resolves consistently.
 */
export const CAR_IMAGE = require('../../assets/car.png');
/** The Pro's branded van (top-down, facing right, 288×145). */
export const VALETER_VAN_IMAGE = require('../../assets/tracking-van-pin.png');
export const VALETER_VAN_ASPECT = 288 / 145;
export const ICON = require('../../assets/icon.png');

export const CERAMIC_DETAIL_IMAGE = require('../../assets/Ceramic.png');
export const SOFTOP_DETAIL_IMAGE = require('../../assets/Softop.png');
export const MOULD_DETAIL_IMAGE = require('../../assets/mould.png');
export const HEADLIGHT_DETAIL_IMAGE = require('../../assets/headlight.png');
