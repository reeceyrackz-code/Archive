/**
 * Central exports for washer app assets. Re-exports from src/constants/appAssetExports.
 * Use CAR_IMAGE for customer/job map markers and VALETER_VAN_IMAGE for the Pro's van.
 */
export { CAR_IMAGE, VALETER_VAN_IMAGE, VALETER_VAN_ASPECT } from './appAssetExports';
