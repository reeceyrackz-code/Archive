/**
 * Service, add-on and category icons. Mirrors the customer app's `ServiceTierSpongeIcon`
 * mapping so a service shows the same glyph on both sides of a booking.
 */
import type { ImageSourcePropType } from 'react-native';
import type { IconGlyphName } from '../components/shared/iconGlyphTypes';
import { LEGACY_ECO_SERVICE_ID_MAP } from './serviceOptions';
import {
  CERAMIC_DETAIL_IMAGE,
  HEADLIGHT_DETAIL_IMAGE,
  MOULD_DETAIL_IMAGE,
  SOFTOP_DETAIL_IMAGE,
} from './appAssetExports';
import {
  getServiceDisplayName,
  getServiceTrackingCategory,
  type ServiceTrackingCategory,
} from '../utils/serviceNameMapper';

export const SERVICE_CATEGORY_ICON: Record<ServiceTrackingCategory, IconGlyphName> = {
  wash: 'mci:car-wash',
  detailing: 'mci:auto-fix',
  repair: 'mci:wrench',
};

export const WASH_SCOPE_ICON: Record<'exterior' | 'interior', IconGlyphName> = {
  exterior: 'mci:car-wash',
  interior: 'mci:car-seat',
};

const SERVICE_ICONS: Record<string, IconGlyphName> = {
  'bronze-wash': 'mci:car-wash',
  'silver-wash': 'mci:spray',
  'gold-wash': 'mci:shimmer',
  'platinum-wash': 'mci:crown',
  'emerald-wash': 'mci:diamond-stone',
  'ceramic-coating': 'mci:shield-car',
  'machine-polishing': 'mci:auto-fix',
  'soft-top-restoration': 'mci:car-convertible',
  'mould-removal': 'mci:bacteria-outline',
  'headlight-restoration': 'mci:car-light-high',
  'scratch-removal': 'mci:brush',
  'paint-chip-repair': 'mci:format-paint',
  'trim-restoration': 'mci:car-door',
  'leather-repair': 'mci:car-seat',
  'maintenance-pack': 'mci:wrench-cog',
  'maintenance-check': 'mci:wrench-cog',
};

/** Keyword fallbacks for names, tier keys (`gold`, `PLATINUM`) and older ids (`repair-trim`). */
const SERVICE_KEYWORDS: ReadonlyArray<readonly [RegExp, IconGlyphName]> = [
  [/ceramic/, 'mci:shield-car'],
  [/polish/, 'mci:auto-fix'],
  [/soft.?top|softop/, 'mci:car-convertible'],
  [/mou?ld|odou?r/, 'mci:bacteria-outline'],
  [/headlight/, 'mci:car-light-high'],
  [/scratch/, 'mci:brush'],
  [/chip|paint/, 'mci:format-paint'],
  [/trim/, 'mci:car-door'],
  [/leather|upholster/, 'mci:car-seat'],
  [/maintenance/, 'mci:wrench-cog'],
  [/emerald|diamond/, 'mci:diamond-stone'],
  [/platinum/, 'mci:crown'],
  [/gold/, 'mci:shimmer'],
  [/silver/, 'mci:spray'],
  [/bronze/, 'mci:car-wash'],
  [/interior/, 'mci:car-seat'],
];

function normalize(v: string): string {
  return v.trim().toLowerCase().replaceAll('_', '-');
}

/** Lead icon for a wash tier, detail or repair. Accepts an id, tier key or display name. */
export function getServiceIcon(serviceIdOrName?: string | null, serviceName?: string | null): IconGlyphName {
  const candidates = [serviceIdOrName, serviceName, getServiceDisplayName(serviceIdOrName, serviceName)]
    .filter((v): v is string => !!v && !!v.trim())
    .map(normalize);
  for (const raw of candidates) {
    const id = LEGACY_ECO_SERVICE_ID_MAP[raw] ?? raw;
    if (SERVICE_ICONS[id]) return SERVICE_ICONS[id]!;
  }
  for (const text of candidates) {
    for (const [re, icon] of SERVICE_KEYWORDS) if (re.test(text)) return icon;
  }
  return SERVICE_CATEGORY_ICON[getServiceTrackingCategory(serviceIdOrName, serviceName)];
}

/** Branded photo for the detail services that have one (ceramic, soft top, mould, headlight). */
export function getServiceImage(serviceIdOrName?: string | null): ImageSourcePropType | null {
  const t = normalize(serviceIdOrName ?? '');
  if (t.includes('ceramic-spray')) return null;
  if (t.includes('ceramic')) return CERAMIC_DETAIL_IMAGE;
  if (/soft.?top|softop/.test(t)) return SOFTOP_DETAIL_IMAGE;
  if (/mou?ld/.test(t)) return MOULD_DETAIL_IMAGE;
  if (t.includes('headlight')) return HEADLIGHT_DETAIL_IMAGE;
  return null;
}

const ADD_ON_ICONS: Record<string, IconGlyphName> = {
  'pet-hair': 'mci:paw',
  'stain-removal': 'mci:water-off',
  'vomit-removal': 'mci:emoticon-sick',
  'biohazard-removal': 'mci:biohazard',
  'engine-bay': 'mci:engine',
  'headlight-restoration': 'mci:car-light-high',
  'seat-shampoo': 'mci:vacuum',
  'ceramic-spray': 'mci:spray-bottle',
  'floor-mats-carpet-shampoo': 'mci:rug',
  'clay-bar-treatment': 'mci:texture-box',
  'iron-tar-decontamination': 'mci:blur',
  'wiper-blade-install': 'mci:wiper',
  'coolant-top-up': 'mci:car-coolant-level',
  'oil-level-check': 'mci:oil-level',
  'screen-wash-refill': 'mci:wiper-wash',
};

const ADD_ON_KEYWORDS: ReadonlyArray<readonly [RegExp, IconGlyphName]> = [
  [/pet|hair/, 'mci:paw'],
  [/stain/, 'mci:water-off'],
  [/vomit|sick/, 'mci:emoticon-sick'],
  [/biohazard/, 'mci:biohazard'],
  [/engine/, 'mci:engine'],
  [/headlight/, 'mci:car-light-high'],
  [/seat|shampoo/, 'mci:vacuum'],
  [/ceramic|spray/, 'mci:spray-bottle'],
  [/mat|carpet/, 'mci:rug'],
  [/clay/, 'mci:texture-box'],
  [/iron|tar/, 'mci:blur'],
  [/wiper/, 'mci:wiper'],
  [/coolant/, 'mci:car-coolant-level'],
  [/oil/, 'mci:oil-level'],
  [/screen.?wash/, 'mci:wiper-wash'],
];

/** Add-on glyph by id (or name), matching the customer app's add-on rows. */
export function getAddOnIcon(addOnIdOrName?: string | null): IconGlyphName {
  const t = normalize(addOnIdOrName ?? '');
  if (ADD_ON_ICONS[t]) return ADD_ON_ICONS[t]!;
  for (const [re, icon] of ADD_ON_KEYWORDS) if (re.test(t)) return icon;
  return 'mci:plus-circle-outline';
}
