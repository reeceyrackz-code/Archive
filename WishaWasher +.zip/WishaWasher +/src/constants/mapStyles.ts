/**
 * Dark / futuristic map style for premium map views (business locations, bookings).
 * Use with MapView customMapStyle.
 */
export const DARK_MAP_STYLE = [
  { elementType: 'geometry', stylers: [{ color: '#1a1f2e' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#1a1f2e' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#4a5568' }] },
  { featureType: 'administrative.locality', elementType: 'labels.text.fill', stylers: [{ color: '#7dd3fc' }] },
  { featureType: 'poi', elementType: 'labels.text.fill', stylers: [{ color: '#7dd3fc' }] },
  { featureType: 'poi.park', elementType: 'geometry', stylers: [{ color: '#1e293b' }] },
  { featureType: 'poi.park', elementType: 'labels.text.fill', stylers: [{ color: '#5eead4' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#334155' }] },
  { featureType: 'road', elementType: 'geometry.stroke', stylers: [{ color: '#1e293b' }] },
  { featureType: 'road', elementType: 'labels.text.fill', stylers: [{ color: '#64748b' }] },
  { featureType: 'road.highway', elementType: 'geometry', stylers: [{ color: '#475569' }] },
  { featureType: 'road.highway', elementType: 'geometry.stroke', stylers: [{ color: '#1e293b' }] },
  { featureType: 'road.highway', elementType: 'labels.text.fill', stylers: [{ color: '#94a3b8' }] },
  { featureType: 'transit', elementType: 'geometry', stylers: [{ color: '#334155' }] },
  { featureType: 'transit.station', elementType: 'labels.text.fill', stylers: [{ color: '#7dd3fc' }] },
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#0f172a' }] },
  { featureType: 'water', elementType: 'labels.text.fill', stylers: [{ color: '#475569' }] },
  { featureType: 'water', elementType: 'labels.text.stroke', stylers: [{ color: '#0f172a' }] },
];

/** Valeter dashboard map in the mascot navy (#0F3B78) used by the splash and dark theme. Google provider only. */
export const MASCOT_MAP_STYLE = [
  { elementType: 'geometry', stylers: [{ color: '#0f3b78' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#0c3166' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#9cc3ee' }] },
  { featureType: 'administrative.locality', elementType: 'labels.text.fill', stylers: [{ color: '#bae6fd' }] },
  { featureType: 'poi', elementType: 'labels.text.fill', stylers: [{ color: '#7dd3fc' }] },
  { featureType: 'poi.park', elementType: 'geometry', stylers: [{ color: '#124a7a' }] },
  { featureType: 'poi.park', elementType: 'labels.text.fill', stylers: [{ color: '#5eead4' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#2a5fa8' }] },
  { featureType: 'road', elementType: 'geometry.stroke', stylers: [{ color: '#0c3166' }] },
  { featureType: 'road', elementType: 'labels.text.fill', stylers: [{ color: '#a5c8f0' }] },
  { featureType: 'road.highway', elementType: 'geometry', stylers: [{ color: '#3b74c4' }] },
  { featureType: 'road.highway', elementType: 'geometry.stroke', stylers: [{ color: '#0c3166' }] },
  { featureType: 'road.highway', elementType: 'labels.text.fill', stylers: [{ color: '#dbeafe' }] },
  { featureType: 'transit', elementType: 'geometry', stylers: [{ color: '#1d4f94' }] },
  { featureType: 'transit.station', elementType: 'labels.text.fill', stylers: [{ color: '#7dd3fc' }] },
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#0a2c5e' }] },
  { featureType: 'water', elementType: 'labels.text.fill', stylers: [{ color: '#7aa6d8' }] },
  { featureType: 'water', elementType: 'labels.text.stroke', stylers: [{ color: '#0a2c5e' }] },
];
