import { useEffect, useState } from 'react';
import * as Location from 'expo-location';

export type NavFix = Readonly<{
  latitude: number;
  longitude: number;
  /** GPS course over ground in degrees (0 = north), or null when the phone can't tell (e.g. standing still). */
  course: number | null;
  /** Metres per second, or null when unknown. */
  speed: number | null;
}>;

/**
 * Navigation-grade GPS (about once a second) while `active`, e.g. only during the drive to a job.
 * The app-wide location watcher stays slow to save battery; this one stops as soon as `active` turns off.
 */
export default function useNavLocation(active: boolean): NavFix | null {
  const [fix, setFix] = useState<NavFix | null>(null);

  useEffect(() => {
    if (!active) {
      setFix(null);
      return;
    }
    let cancelled = false;
    let sub: Location.LocationSubscription | null = null;
    void (async () => {
      try {
        const { status } = await Location.getForegroundPermissionsAsync();
        if (cancelled || status !== 'granted') return;
        sub = await Location.watchPositionAsync(
          { accuracy: Location.Accuracy.BestForNavigation, timeInterval: 1000, distanceInterval: 2 },
          ({ coords }) => {
            const course = coords.heading != null && coords.heading >= 0 ? coords.heading : null;
            const speed = coords.speed != null && coords.speed >= 0 ? coords.speed : null;
            setFix({ latitude: coords.latitude, longitude: coords.longitude, course, speed });
          }
        );
        if (cancelled) sub.remove();
      } catch (e) {
        console.warn('[useNavLocation] watch error', e);
      }
    })();
    return () => {
      cancelled = true;
      sub?.remove();
    };
  }, [active]);

  return fix;
}
