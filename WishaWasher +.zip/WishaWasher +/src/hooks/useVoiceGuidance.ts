import { useCallback, useEffect, useRef, useState } from 'react';
import * as Speech from 'expo-speech';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { turnPhrase, type RouteTurn } from '../utils/routeTurnAhead';

const MUTE_KEY = 'wishawasher:navVoiceMuted';
/** Early heads-up distance for a bend, and the "turn now" distance. */
const FAR_M = 250;
const NEAR_M = 60;
const SPEECH = { language: 'en-GB', rate: 1 } as const;

function spokenDistance(metres: number) {
  const yards = metres * 1.0936;
  if (yards >= 350) return `${(metres / 1609.344).toFixed(1)} miles`;
  return `${Math.max(50, Math.round(yards / 50) * 50)} yards`;
}

type Announced = { phrase: string; lastM: number; far: boolean; near: boolean };

/**
 * Spoken sat-nav prompts while driving to the customer: a heads-up ~250 m before each bend,
 * "turn now" at ~60 m, and an arrival call-out. Mute choice persists across jobs.
 */
export function useVoiceGuidance({
  active,
  turn,
  nearby,
  street,
}: Readonly<{ active: boolean; turn: RouteTurn | null; nearby: boolean; street: string | null }>) {
  const [muted, setMuted] = useState(false);
  const mutedRef = useRef(false);

  useEffect(() => {
    void AsyncStorage.getItem(MUTE_KEY).then((v) => {
      mutedRef.current = v === '1';
      setMuted(v === '1');
    });
  }, []);

  const say = useCallback((text: string) => {
    if (mutedRef.current) return;
    void Speech.stop();
    Speech.speak(text, SPEECH);
  }, []);

  const toggleMuted = useCallback(() => {
    const next = !mutedRef.current;
    mutedRef.current = next;
    setMuted(next);
    void AsyncStorage.setItem(MUTE_KEY, next ? '1' : '0');
    if (next) void Speech.stop();
    else Speech.speak('Voice guidance on', SPEECH);
  }, []);

  const startedRef = useRef(false);
  useEffect(() => {
    if (!active) {
      if (startedRef.current) void Speech.stop();
      startedRef.current = false;
      return;
    }
    if (startedRef.current) return;
    startedRef.current = true;
    say(street ? `Starting route to ${street}` : 'Starting route to the customer');
  }, [active, street, say]);

  const announcedRef = useRef<Announced | null>(null);
  useEffect(() => {
    if (!active || nearby || !turn) return;
    const phrase = turnPhrase(turn);
    let a = announcedRef.current;
    /* A different manoeuvre, or the distance jumping back up, means we've moved on to the next bend. */
    if (a?.phrase !== phrase || turn.inMetres > a.lastM + 60) {
      a = { phrase, lastM: turn.inMetres, far: false, near: false };
      announcedRef.current = a;
    }
    a.lastM = turn.inMetres;
    if (!a.near && turn.inMetres <= NEAR_M) {
      a.near = true;
      a.far = true;
      say(phrase);
    } else if (!a.far && turn.inMetres <= FAR_M && turn.inMetres > NEAR_M + 40) {
      a.far = true;
      say(`In ${spokenDistance(turn.inMetres)}, ${phrase.toLowerCase()}`);
    }
  }, [active, nearby, turn, say]);

  const arrivedRef = useRef(false);
  useEffect(() => {
    if (!active) {
      arrivedRef.current = false;
      return;
    }
    if (nearby && !arrivedRef.current) {
      arrivedRef.current = true;
      say("You've arrived. Hold the button to mark arrived.");
    }
  }, [active, nearby, say]);

  useEffect(
    () => () => {
      void Speech.stop();
    },
    []
  );

  return { muted, toggleMuted };
}
