// src/providers/enhanced-auth-context.tsx
import React, { createContext, useContext, useEffect, useMemo, useRef, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Linking from 'expo-linking';
import { supabase } from '../lib/supabase';
import type { Session, User as SbUser } from '@supabase/supabase-js';
import { normalizeUserType } from '../utils/authRole';

/* ---------------- Types ---------------- */

export interface Organization {
  id: string;
  name: string;
  registrationNumber?: string;
  address?: string;
  contactEmail: string;
  contactPhone?: string;
  isVerified: boolean;
  insuranceVerified: boolean;
  licenseVerified: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  userType: 'customer' | 'valeter' | 'organization';
  organizationId?: string;
  organizationType?: 'independent' | 'registered';
  profilePicture?: string;
  isVerified: boolean;
  verificationType: 'none' | 'profile' | 'car';
  totalWashes: number;
  tier: 'bronze' | 'silver' | 'gold' | 'platinum';
  tierPoints: number;
  joinDate: string;
  /** Valeter welcome onboarding: set via auth metadata `valeterOnboardingCompleted` */
  valeterOnboarded?: boolean;
  /** Alias for `valeterOnboarded` */
  isValeterOnboarded?: boolean;
  /** Business welcome onboarding: set via auth metadata `businessOnboardingCompleted` */
  businessOnboarded?: boolean;
  /** Alias for `businessOnboarded` (used by `app/index.tsx`) */
  isBusinessOnboarded?: boolean;
}

interface AuthContextType {
  user: User | null;
  /** True while we’re bootstrapping session/profile OR mid-auth mutations. */
  isLoading: boolean;
  /** True when the role (userType) is reliable; use this for routing. */
  authReady: boolean;

  login: (email: string, password: string) => Promise<boolean>;
  loginWithGoogle: () => Promise<boolean>;
  loginWithApple: (
    credential: {
      identityToken?: string | null;
      nonce?: string | null;
      fullName?: { givenName?: string | null; familyName?: string | null; middleName?: string | null } | null;
    },
    seed?: Partial<User>
  ) => Promise<boolean>;
  logout: () => Promise<void>;
  register: (userData: Partial<Omit<User, 'id' | 'joinDate'>> & {
    password: string;
    isIndividualValeter?: boolean;
    organizationId?: string;
    /** NEW: for org signups */
    orgName?: string;
    contactName?: string;
  }) => Promise<boolean>;
  registerWithApple: (
    credential: {
      identityToken?: string | null;
      nonce?: string | null;
      fullName?: { givenName?: string | null; familyName?: string | null; middleName?: string | null } | null;
    },
    seed?: Partial<User>
  ) => Promise<boolean>;
  registerWithGoogle: (seed?: Partial<User>) => Promise<boolean>;
  updateUser: (updates: Partial<User>) => Promise<void>;
  updatePassword: (currentPassword: string, newPassword: string) => Promise<void>;
  updateProfile: (updates: Partial<User>) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  autoLoginCustomer: () => Promise<void>;
  autoLoginValeter: () => Promise<void>;
  hasAdminAccess: () => boolean;
  isBusinessOwner: () => boolean;
  markWelcomeSeen: (userType: 'customer' | 'valeter') => Promise<void>;
  hasSeenWelcome: (userType: 'customer' | 'valeter') => Promise<boolean>;
  isIndividualValeter: () => boolean;
  isOrganizationValeter: () => boolean;
  requiresIndividualDocuments: () => boolean;
  requiresOrganizationDocuments: () => boolean;
  getOrganization: () => Organization | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);
const SESSION_KEY = 'user_session';

/* ---------------- Utils ---------------- */

function withTimeout<T>(p: Promise<T>, ms: number, label: string): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const t = setTimeout(() => {
      console.warn(`[Auth TIMEOUT] ${label} timed out after ${ms}ms`);
      reject(new Error(`timeout:${label}`));
    }, ms);
    p.then(v => { clearTimeout(t); resolve(v); })
     .catch(e => { clearTimeout(t); reject(e); });
  });
}

/**
 * Helper function to check if an error is a refresh token error
 */
function isRefreshTokenError(error: any): boolean {
  if (!error) return false;
  const message = error.message || error.toString() || '';
  return (
    message.includes('Invalid Refresh Token') ||
    message.includes('Refresh Token Not Found') ||
    message.includes('refresh_token_not_found') ||
    error.name === 'AuthApiError'
  );
}

/**
 * Helper function to clear invalid session data
 */
async function clearInvalidSession(): Promise<void> {
  try {
    // Clear Supabase session storage
    await supabase.auth.signOut();
  } catch (signOutError) {
    console.warn('[Auth] signOut during clearInvalidSession:', signOutError);
  }
  // Clear our cached session
  await AsyncStorage.removeItem(SESSION_KEY);
  // Clear all Supabase auth-related keys from AsyncStorage
  try {
    const keys = await AsyncStorage.getAllKeys();
    const supabaseKeys = keys.filter(key => 
      key.startsWith('sb-') || 
      key.includes('supabase') || 
      key.includes('auth-token')
    );
    if (supabaseKeys.length > 0) {
      await AsyncStorage.multiRemove(supabaseKeys);
    }
  } catch (clearError) {
    console.warn('[Auth] Error clearing Supabase keys:', clearError);
  }
}

/* ---------------- Helpers ---------------- */

const KNOWN_CUSTOMER_EMAILS = new Set(
  ([
    // 'deanlingard@yahoo.co.uk',
    // 'customer@test.com',
  ] as string[]).map((e) => e.toLowerCase()),
);

const KNOWN_VALETER_EMAILS = new Set(
  ([
    // 'lingardodeano@gmail.com',
    // 'valeter@test.com',
  ] as string[]).map((e) => e.toLowerCase()),
);

type ProfileLike = {
  user_type?: string | null;
  full_name?: string | null;
  phone?: string | null;
  organization_id?: string | null;
  organization_type?: string | null;
  profile_picture?: string | null;
  is_verified?: boolean | null;
  verification_type?: string | null;
  total_washes?: number | null;
  tier?: string | null;
  tier_points?: number | null;
  created_at?: string | null;
} | null;

const toAppUser = (sbUser: SbUser, profile: ProfileLike): User => {
  const md = sbUser.user_metadata ?? {};
  const email = (sbUser.email ?? '').toLowerCase();
  const valeterOnboardingDone = !!(md.valeterOnboardingCompleted ?? md.valeterOnboarded);
  const businessOnboardingDone = !!(md.businessOnboardingCompleted ?? md.businessOnboarded);

  let role: User['userType'];
  if (KNOWN_CUSTOMER_EMAILS.has(email)) {
    role = 'customer';
  } else if (KNOWN_VALETER_EMAILS.has(email)) {
    role = 'valeter';
  } else {
    role = (normalizeUserType(profile?.user_type ?? md.userType, 'customer') ?? 'customer') as User['userType'];
  }

  const name = String(profile?.full_name ?? md.full_name ?? md.name ?? '');
  const phoneVal = profile?.phone ?? md.phone;
  const orgId = profile?.organization_id ?? md.organizationId;
  const orgTypeRaw = profile?.organization_type ?? md.organizationType;
  const orgType =
    orgTypeRaw === 'independent' || orgTypeRaw === 'registered' ? orgTypeRaw : undefined;
  const profilePic = profile?.profile_picture ?? md.profilePicture;

  const base: User = {
    id: sbUser.id,
    email: sbUser.email ?? '',
    name,
    userType: role,
    isVerified: !!profile?.is_verified,
    verificationType: (profile?.verification_type ?? 'none') as User['verificationType'],
    totalWashes: profile?.total_washes ?? 0,
    tier: (profile?.tier ?? 'bronze') as User['tier'],
    tierPoints: profile?.tier_points ?? 0,
    joinDate: (profile?.created_at ?? sbUser.created_at ?? new Date().toISOString()),
    valeterOnboarded: valeterOnboardingDone,
    isValeterOnboarded: valeterOnboardingDone,
    businessOnboarded: businessOnboardingDone,
    isBusinessOnboarded: businessOnboardingDone,
  };

  if (typeof phoneVal === 'string' && phoneVal.length > 0) {
    base.phone = phoneVal;
  }
  if (typeof orgId === 'string' && orgId.length > 0) {
    base.organizationId = orgId;
  }
  if (orgType !== undefined) {
    base.organizationType = orgType;
  }
  if (typeof profilePic === 'string' && profilePic.length > 0) {
    base.profilePicture = profilePic;
  }

  return base;
};

const normalizeCachedAppUser = (cachedUser: User): User => {
  const normalizedUserType = normalizeUserType(cachedUser.userType, 'customer') ?? 'customer';
  if (normalizedUserType === cachedUser.userType) {
    return cachedUser;
  }
  return {
    ...cachedUser,
    userType: normalizedUserType,
    businessOnboarded: cachedUser.businessOnboarded,
    isBusinessOnboarded: cachedUser.isBusinessOnboarded,
  };
};

const upsertProfile = async (sbUser: SbUser, seed?: Partial<User>) => {
  // Build payload, but OMIT user_type unless we actually have one.
  const payload: Record<string, any> = {
    id: sbUser.id,
    email: sbUser.email,
  };

  const name =
    seed?.name ??
    sbUser.user_metadata?.full_name ??
    sbUser.user_metadata?.name ??
    null;
  if (name) payload.full_name = name;

  const phone = seed?.phone ?? sbUser.user_metadata?.phone ?? null;
  if (phone) payload.phone = phone;

  const resolvedUserType = normalizeUserType(seed?.userType ?? sbUser.user_metadata?.userType, null);
  if (resolvedUserType) payload.user_type = resolvedUserType; // <— only set if known

  // Other fields: only set if defined — don’t blast defaults onto existing rows
  if (typeof seed?.isVerified === 'boolean') payload.is_verified = seed.isVerified;
  if (seed?.verificationType) payload.verification_type = seed.verificationType;
  if (typeof seed?.totalWashes === 'number') payload.total_washes = seed.totalWashes;
  if (seed?.tier) payload.tier = seed.tier;
  if (typeof seed?.tierPoints === 'number') payload.tier_points = seed.tierPoints;

  const orgId = seed?.organizationId ?? sbUser.user_metadata?.organizationId;
  if (orgId !== undefined && orgId !== null) payload.organization_id = orgId;

  const orgType = seed?.organizationType ?? sbUser.user_metadata?.organizationType;
  if (orgType !== undefined && orgType !== null) payload.organization_type = orgType;

  // INSERT ONLY; ignore duplicates. This will NOT overwrite existing rows.
  const { error } = await supabase.from('profiles').upsert(payload, {
    onConflict: 'id',
    ignoreDuplicates: true,
  });

  if (error) console.warn('[Auth] profiles insert-if-not-exists error:', error.message);
};

function nameFromAppleFullName(fullName?: {
  givenName?: string | null;
  familyName?: string | null;
  middleName?: string | null;
} | null): string | null {
  const parts = [fullName?.givenName, fullName?.middleName, fullName?.familyName]
    .map((part) => String(part ?? '').trim())
    .filter(Boolean);
  if (parts.length === 0) return null;
  return parts.join(' ');
}

async function ensureValeterBootstrapRows(sbUser: SbUser, seed?: Partial<User>) {
  const email = (sbUser.email ?? '').toLowerCase();
  const resolvedRole = normalizeUserType(seed?.userType ?? sbUser.user_metadata?.userType, null);
  if (resolvedRole !== 'valeter') return;

  const fullName =
    String(seed?.name ?? sbUser.user_metadata?.full_name ?? sbUser.user_metadata?.name ?? '').trim() || 'Car Care Pro';

  const { data: existingProfile, error: existingError } = await supabase
    .from('valeter_profiles')
    .select('user_id')
    .eq('user_id', sbUser.id)
    .maybeSingle();

  if (existingError && existingError.code !== 'PGRST116') {
    console.warn('[Auth] valeter_profiles lookup error:', existingError.message);
  }

  if (!existingProfile) {
    const { error: insertError } = await supabase.from('valeter_profiles').insert({
      user_id: sbUser.id,
      full_name: fullName,
      bio: 'Professional mobile car care pro',
      experience: '0 years',
    } as any);

    if (insertError) {
      console.warn('[Auth] valeter_profiles bootstrap insert error:', insertError.message);
    }
  }

  const { error: roleError } = await supabase
    .from('profiles')
    .update({ role: 'valeter', user_type: 'valeter' })
    .eq('id', sbUser.id);

  if (roleError) {
    console.warn('[Auth] profiles role bootstrap update error:', roleError.message);
  }

  if (email) {
    await supabase.auth.updateUser({ data: { userType: 'valeter' } });
  }
}

const fetchProfile = async (userId: string): Promise<ProfileLike> => {
  const { data: profileData, error: profileError } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .maybeSingle();

  if (profileError) {
    console.warn('[Auth DEBUG] fetchProfile (profiles) error:', profileError.message);
  }

  const mergedData = {
    ...profileData,
    user_type: profileData?.user_type ?? null,
  };

  return mergedData as ProfileLike;
};

function authMetadataPatchFromUserUpdates(updates: Partial<User>): Record<string, unknown> {
  const md: Record<string, unknown> = {};
  if (updates.name) md.full_name = updates.name;
  if (updates.phone) md.phone = updates.phone;
  const normalizedUserType = normalizeUserType(updates.userType, null);
  if (normalizedUserType) md.userType = normalizedUserType;
  if (updates.organizationId) md.organizationId = updates.organizationId;
  if (updates.organizationType) md.organizationType = updates.organizationType;
  if (updates.profilePicture) md.profilePicture = updates.profilePicture;
  if (typeof updates.valeterOnboarded === 'boolean') {
    md.valeterOnboardingCompleted = updates.valeterOnboarded;
  }
  if (typeof updates.businessOnboarded === 'boolean') {
    md.businessOnboardingCompleted = updates.businessOnboarded;
  }
  return md;
}

function profileRowPatchFromUserUpdates(updates: Partial<User>): Record<string, unknown> {
  const patch: Record<string, unknown> = {};
  if (updates.name) patch.full_name = updates.name;
  if (updates.phone) patch.phone = updates.phone;
  const normalizedUserType = normalizeUserType(updates.userType, null);
  if (normalizedUserType) patch.user_type = normalizedUserType;
  if (updates.organizationId) patch.organization_id = updates.organizationId;
  if (updates.organizationType) patch.organization_type = updates.organizationType;
  if (updates.profilePicture) patch.profile_picture = updates.profilePicture;
  if (typeof updates.isVerified === 'boolean') patch.is_verified = updates.isVerified;
  if (updates.verificationType) patch.verification_type = updates.verificationType;
  if (typeof updates.totalWashes === 'number') patch.total_washes = updates.totalWashes;
  if (updates.tier) patch.tier = updates.tier;
  if (typeof updates.tierPoints === 'number') patch.tier_points = updates.tierPoints;
  return patch;
}

/** Create & link organization after first login (email confirmation safe). */
async function ensureOrgAfterLogin(u: SbUser) {
  const md = u.user_metadata ?? {};
  const isOrgUser = normalizeUserType(md.userType, null) === 'organization';
  const hasOrgId = !!md.organizationId;

  if (!isOrgUser || hasOrgId) return;

  const orgName = md.pendingOrgName ?? 'Organization';
  const contactName = md.pendingContactName ?? md.full_name ?? 'Owner';

  // 1) Create organization
  const { data: orgRow, error: orgErr } = await supabase
    .from('organizations')
    .insert({
      name: orgName,
      contact_name: contactName,
      contact_email: u.email,
      //created_by: u.id,
      //business_type: 'valeting',
    })
    .select('id')
    .maybeSingle();

  if (orgErr || !orgRow?.id) {
    console.warn('[Auth DEBUG] ensureOrgAfterLogin: org insert failed:', orgErr?.message);
    return;
  }

  const orgId = orgRow.id as string;

  // 2) Link profile
  const { error: profErr } = await supabase
    .from('profiles')
    .update({ organization_id: orgId, user_type: 'organization' })
    .eq('id', u.id);

  if (profErr) {
    console.warn('[Auth DEBUG] ensureOrgAfterLogin: profile link failed:', profErr.message);
    return;
  }

  // 3) Update auth metadata
  await supabase.auth.updateUser({
    data: {
      organizationId: orgId,
      pendingOrgName: null,
      pendingContactName: null,
    },
  });
}

/** Ref-like box with a mutable `.current` (structural typing for `useRef` results). */
type BooleanRefBox = { current: boolean };

type AuthBootstrapCtx = Readonly<{
  getMounted: () => boolean;
  setUser: React.Dispatch<React.SetStateAction<User | null>>;
  setAuthReady: React.Dispatch<React.SetStateAction<boolean>>;
  setIsLoading: React.Dispatch<React.SetStateAction<boolean>>;
  bootDoneRef: BooleanRefBox;
}>;

function applyKnownEmailUserTypeOverrideBootstrap(enriched: User, email: string, userId: string): User {
  if (KNOWN_CUSTOMER_EMAILS.has(email) && enriched.userType !== 'customer') {
    supabase
      .from('profiles')
      .update({ user_type: 'customer' })
      .eq('id', userId)
      .then(() => {
        supabase.auth.updateUser({ data: { userType: 'customer' } });
      });
    return { ...enriched, userType: 'customer' };
  }
  if (KNOWN_VALETER_EMAILS.has(email) && enriched.userType !== 'valeter') {
    supabase
      .from('profiles')
      .update({ user_type: 'valeter' })
      .eq('id', userId)
      .then(() => {
        supabase.auth.updateUser({ data: { userType: 'valeter' } });
      });
    return { ...enriched, userType: 'valeter' };
  }
  return enriched;
}

async function bootstrapTryProfileEnrich(
  sessionUser: NonNullable<Session['user']>,
  mdHasRole: boolean,
  ctx: AuthBootstrapCtx
): Promise<void> {
  const { getMounted, setUser, setAuthReady } = ctx;
  try {
    const profile = await withTimeout(fetchProfile(sessionUser.id), 3000, 'fetchProfile(bootstrap)');
    const enriched = toAppUser(sessionUser, profile);
    const email = (sessionUser.email ?? '').toLowerCase();
    const finalUser = applyKnownEmailUserTypeOverrideBootstrap(enriched, email, sessionUser.id);
    if (normalizeUserType(finalUser.userType, null) === 'valeter') {
      await ensureValeterBootstrapRows(sessionUser, finalUser);
    }
    await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(finalUser));
    if (getMounted()) {
      setUser(finalUser);
      setAuthReady(true);
    }
  } catch (e: any) {
    console.warn('[Auth DEBUG] bootstrap profile fetch failed:', e?.message || e);
    if (!mdHasRole) {
      const cached = await AsyncStorage.getItem(SESSION_KEY);
      if (cached && getMounted()) {
        const cachedUser = normalizeCachedAppUser(JSON.parse(cached) as User);
        setUser(cachedUser);
        setAuthReady(!!cachedUser?.userType);
      } else {
        setAuthReady(true);
      }
    }
  }
}

async function bootstrapWithSession(s: Session, ctx: AuthBootstrapCtx): Promise<void> {
  const user = s.user;
  if (!user) {
    return;
  }
  const { getMounted, setUser, setAuthReady } = ctx;
  const md = user.user_metadata ?? {};
  const mdHasRole = normalizeUserType(md.userType, null) !== null;

  if (mdHasRole) {
    const minimal = toAppUser(user, null);
    if (getMounted()) {
      setUser(minimal);
      await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(minimal));
      setAuthReady(true);
    }
  }

  await bootstrapTryProfileEnrich(user, mdHasRole, ctx);
}

async function bootstrapNoSession(ctx: AuthBootstrapCtx): Promise<void> {
  const { getMounted, setUser, setAuthReady } = ctx;
  const cached = await AsyncStorage.getItem(SESSION_KEY);
  if (cached && getMounted()) {
    const cachedUser = normalizeCachedAppUser(JSON.parse(cached) as User);
    setUser(cachedUser);
    setAuthReady(true);
  } else if (getMounted()) {
    setUser(null);
    setAuthReady(true);
  }
}

async function bootstrapOuterCatch(e: any, ctx: AuthBootstrapCtx): Promise<void> {
  const { getMounted, setUser, setAuthReady, setIsLoading } = ctx;
  if (isRefreshTokenError(e)) {
    console.warn('[Auth] Refresh token error during getSession, clearing session');
    await clearInvalidSession();
    if (getMounted()) {
      setUser(null);
      setAuthReady(true);
      setIsLoading(false);
    }
    return;
  }

  console.warn('[Auth WARN] getSession failed:', e?.message || e);
  const cached = await AsyncStorage.getItem(SESSION_KEY);
  if (cached && getMounted()) {
    const cachedUser = normalizeCachedAppUser(JSON.parse(cached) as User);
    setUser(cachedUser);
    setAuthReady(true);
  } else if (getMounted()) {
    setUser(null);
    setAuthReady(true);
  }
}

async function runInitialAuthBootstrap(ctx: AuthBootstrapCtx): Promise<void> {
  const { getMounted, setUser, setAuthReady, setIsLoading, bootDoneRef } = ctx;
  setIsLoading(true);
  setAuthReady(false);

  try {
    const { data, error: sessionError } = await withTimeout(supabase.auth.getSession(), 3000, 'getSession');

    if (sessionError && isRefreshTokenError(sessionError)) {
      console.warn('[Auth] Invalid refresh token detected, clearing session');
      await clearInvalidSession();
      if (getMounted()) {
        setUser(null);
        setAuthReady(true);
        setIsLoading(false);
        return;
      }
    }

    const s: Session | null = data?.session ?? null;
    if (s?.user) {
      await bootstrapWithSession(s, ctx);
    } else {
      await bootstrapNoSession(ctx);
    }
  } catch (e: any) {
    await bootstrapOuterCatch(e, ctx);
  } finally {
    if (getMounted()) {
      setIsLoading(false);
      bootDoneRef.current = true;
    }
  }
}

type AuthStateSideEffectCtx = Readonly<{
  getMounted: () => boolean;
  loginInProgressRef: BooleanRefBox;
  setUser: React.Dispatch<React.SetStateAction<User | null>>;
  setAuthReady: React.Dispatch<React.SetStateAction<boolean>>;
}>;

async function applyOnChangeEmailCorrections(sbUser: SbUser, enriched: User): Promise<User> {
  const email = (sbUser.email ?? '').toLowerCase();
  if (KNOWN_CUSTOMER_EMAILS.has(email) && enriched.userType !== 'customer') {
    await supabase.from('profiles').update({ user_type: 'customer' }).eq('id', sbUser.id);
    await supabase.auth.updateUser({ data: { userType: 'customer' } });
    const correctedProfile = await fetchProfile(sbUser.id);
    return toAppUser(sbUser, correctedProfile);
  }
  if (KNOWN_VALETER_EMAILS.has(email) && enriched.userType !== 'valeter') {
    await supabase.from('profiles').update({ user_type: 'valeter' }).eq('id', sbUser.id);
    await supabase.auth.updateUser({ data: { userType: 'valeter' } });
    const correctedProfile = await fetchProfile(sbUser.id);
    return toAppUser(sbUser, correctedProfile);
  }
  return enriched;
}

async function authStateTryEnrichProfile(newSession: Session, mdHasRole: boolean, ctx: AuthStateSideEffectCtx): Promise<void> {
  const { getMounted, setUser, setAuthReady } = ctx;
  const sbUser = newSession.user;
  if (!sbUser) {
    return;
  }
  try {
    const profile = await withTimeout(fetchProfile(sbUser.id), 3000, 'fetchProfile(onChange)');
    let enriched = toAppUser(sbUser, profile);
    enriched = await applyOnChangeEmailCorrections(sbUser, enriched);
    if (normalizeUserType(enriched.userType, null) === 'valeter') {
      await ensureValeterBootstrapRows(sbUser, enriched);
    }
    await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(enriched));
    if (getMounted()) {
      setUser(enriched);
      setAuthReady(true);
    }
  } catch (e: any) {
    if (isRefreshTokenError(e)) {
      console.warn('[Auth] Refresh token error in onAuthStateChange, clearing session');
      await clearInvalidSession();
      if (getMounted()) {
        setUser(null);
        setAuthReady(true);
      }
      return;
    }

    console.warn('[Auth DEBUG] onAuthStateChange enrich failed:', e?.message || e);
    if (!mdHasRole) {
      const cached = await AsyncStorage.getItem(SESSION_KEY);
      if (cached && getMounted()) {
        const cachedUser = JSON.parse(cached) as User;
        setUser(cachedUser);
        setAuthReady(!!cachedUser?.userType);
      } else if (getMounted()) {
        setAuthReady(true);
      }
    }
  }
}

async function runAuthStateChangeSideEffect(
  event: string,
  newSession: Session | null,
  ctx: AuthStateSideEffectCtx
): Promise<void> {
  const { getMounted, loginInProgressRef, setUser, setAuthReady } = ctx;

  try {
    if (event === 'TOKEN_REFRESHED' && !newSession) {
      console.warn('[Auth] Token refresh failed, clearing session');
      await clearInvalidSession();
      if (getMounted()) {
        setUser(null);
        setAuthReady(true);
      }
      return;
    }

    if (!newSession?.user) {
      await AsyncStorage.removeItem(SESSION_KEY);
      setUser(null);
      setAuthReady(true);
      return;
    }

    if (event === 'SIGNED_IN') {
      await ensureOrgAfterLogin(newSession.user);
    }

    if (loginInProgressRef.current) {
      return;
    }

    const md = newSession.user.user_metadata ?? {};
    const mdHasRole = normalizeUserType(md.userType, null) !== null;

    if (mdHasRole) {
      const minimal = toAppUser(newSession.user, null);
      await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(minimal));
      setUser(minimal);
      setAuthReady(true);
    } else {
      setAuthReady(false);
    }

    await authStateTryEnrichProfile(newSession, mdHasRole, ctx);
  } catch (e: any) {
    if (isRefreshTokenError(e)) {
      console.warn('[Auth] Refresh token error in onAuthStateChange handler, clearing session');
      await clearInvalidSession();
      if (getMounted()) {
        setUser(null);
        setAuthReady(true);
      }
      return;
    }

    console.warn('[Auth DEBUG] onAuthStateChange handler error:', e?.message || e);
    setAuthReady(true);
  }
}

/* ---------------- Provider ---------------- */

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);

  // isLoading: true while bootstrapping + while any auth action runs.
  const [isLoading, setIsLoading] = useState(true);

  // authReady: true when we know userType reliably (metadata OR profile),
  // OR when there’s no logged-in user.
  const [authReady, setAuthReady] = useState(false);

  // prevent double-setting on boot
  const bootDoneRef = useRef(false);
  // Track if login is in progress to prevent race conditions with onAuthStateChange
  const loginInProgressRef = useRef(false);

  // initial session + listener
  useEffect(() => {
    let mounted = true;

    (async () => {
      await runInitialAuthBootstrap({
        getMounted: () => mounted,
        setUser,
        setAuthReady,
        setIsLoading,
        bootDoneRef,
      });
    })();

    const authStateCtx: AuthStateSideEffectCtx = {
      getMounted: () => mounted,
      loginInProgressRef,
      setUser,
      setAuthReady,
    };

    const { data: sub } = supabase.auth.onAuthStateChange((event, newSession) => {
      void runAuthStateChangeSideEffect(event, newSession, authStateCtx);
    });

    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  /* -------- API -------- */

  const finalizeAuthUser = async (sbUser: SbUser, seed?: Partial<User>): Promise<boolean> => {
    try {
      await upsertProfile(sbUser, seed);
      const profile = await withTimeout(fetchProfile(sbUser.id), 3000, 'fetchProfile(finalizeAuthUser)');
      const appUser = toAppUser(sbUser, profile);
      if (normalizeUserType(appUser.userType, null) === 'valeter') {
        await ensureValeterBootstrapRows(sbUser, appUser);
      }
      await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(appUser));
      setUser(appUser);
      setAuthReady(true);
      return true;
    } catch (e: any) {
      console.warn('[Auth DEBUG] finalizeAuthUser error:', e?.message || e);
      return false;
    }
  };

  const waitForOAuthRedirect = (timeoutMs = 90000): Promise<string> => {
    return new Promise((resolve, reject) => {
      let done = false;
      const clean = () => { sub.remove(); clearTimeout(t); };
      const finish = (url: string) => { if (done) return; done = true; clean(); resolve(url); };
      const sub = Linking.addEventListener('url', ({ url }) => {
        if (url?.startsWith('wawv://')) finish(url);
      });
      const t = setTimeout(() => {
        if (done) return; done = true; clean();
        reject(new Error('oauth_redirect_timeout'));
      }, timeoutMs);
      Linking.getInitialURL().then((url) => { if (url?.startsWith('wawv://')) finish(url); }).catch(() => {});
    });
  };

  const completeOAuthFromUrl = async (url: string): Promise<SbUser | null> => {
    const parsed = Linking.parse(url);
    const qp = (parsed.queryParams ?? {}) as Record<string, string | undefined>;
    if (qp.error_description || qp.error) throw new Error(qp.error_description || qp.error || 'OAuth failed');
    if (qp.access_token && qp.refresh_token) {
      const { data, error } = await supabase.auth.setSession({ access_token: qp.access_token, refresh_token: qp.refresh_token });
      if (error) throw error;
      return data.user ?? null;
    }
    if (qp.code) {
      const { data, error } = await supabase.auth.exchangeCodeForSession(qp.code);
      if (error) throw error;
      return data.user ?? null;
    }
    return null;
  };

  const loginWithGoogle = async (): Promise<boolean> => {
    setIsLoading(true);
    setAuthReady(false);
    try {
      const redirectTo = Linking.createURL('auth/callback');
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo,
          skipBrowserRedirect: true,
          queryParams: { access_type: 'offline', prompt: 'consent' },
        },
      });
      if (error || !data?.url) { setAuthReady(true); return false; }
      await Linking.openURL(data.url);
      const callbackUrl = await waitForOAuthRedirect();
      const sbUser = await completeOAuthFromUrl(callbackUrl);
      if (!sbUser) { setAuthReady(true); return false; }
      return await finalizeAuthUser(sbUser, { userType: 'valeter' });
    } catch (e: any) {
      console.warn('[Auth DEBUG] loginWithGoogle error:', e?.message || e);
      setAuthReady(true);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const loginWithApple = async (
    credential: {
      identityToken?: string | null;
      nonce?: string | null;
      fullName?: { givenName?: string | null; familyName?: string | null; middleName?: string | null } | null;
    },
    seed?: Partial<User>
  ): Promise<boolean> => {
    const token = credential?.identityToken;
    if (!token) return false;
    setIsLoading(true);
    setAuthReady(false);
    try {
      const idTokenPayload = credential?.nonce
        ? { provider: 'apple' as const, token, nonce: credential.nonce }
        : { provider: 'apple' as const, token };
      const { data, error } = await supabase.auth.signInWithIdToken({
        ...idTokenPayload,
      });
      if (error || !data?.user) {
        setAuthReady(true);
        return false;
      }
      const appleName = nameFromAppleFullName(credential?.fullName);
      const mergedSeed: Partial<User> = { ...(seed || {}) };
      if (appleName && !mergedSeed.name) mergedSeed.name = appleName;
      if (!mergedSeed.userType) mergedSeed.userType = 'valeter';
      return await finalizeAuthUser(data.user, Object.keys(mergedSeed).length ? mergedSeed : undefined);
    } catch (e: any) {
      console.warn('[Auth DEBUG] loginWithApple error:', e?.message || e);
      setAuthReady(true);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const registerWithGoogle = async (seed?: Partial<User>): Promise<boolean> => {
    const ok = await loginWithGoogle();
    if (!ok) return false;
    const { data } = await supabase.auth.getUser();
    const sbUser = data.user;
    if (sbUser) {
      const userType = seed?.userType ?? 'valeter';
      await supabase.auth.updateUser({ data: { userType } });
      await finalizeAuthUser(sbUser, { ...seed, userType });
    }
    return true;
  };

  const registerWithApple = async (
    credential: {
      identityToken?: string | null;
      nonce?: string | null;
      fullName?: { givenName?: string | null; familyName?: string | null; middleName?: string | null } | null;
    },
    seed?: Partial<User>
  ): Promise<boolean> => {
    const appleName = nameFromAppleFullName(credential?.fullName);
    const mergedSeed: Partial<User> = { ...(seed || {}) };
    if (appleName && !mergedSeed.name) mergedSeed.name = appleName;
    if (!mergedSeed.userType) mergedSeed.userType = 'valeter';

    const ok = await loginWithApple(credential, mergedSeed);
    if (!ok) return false;
    const current = await supabase.auth.getUser();
    const sbUser = current.data.user;
    if (sbUser) {
      await supabase.auth.updateUser({ data: { userType: 'valeter' } });
      await finalizeAuthUser(sbUser, { ...mergedSeed, userType: 'valeter' });
    }
    return true;
  };

  const login = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true);
    setAuthReady(false);
    loginInProgressRef.current = true;
    try {
      const { data, error } = await withTimeout(
        supabase.auth.signInWithPassword({ email, password }),
        5000,
        'signInWithPassword'
      );
      if (error || !data.user) {
        setAuthReady(true);
        return false;
      }

      // Minimal now if metadata has role
      const md = data.user.user_metadata ?? {};
      const mdHasRole = normalizeUserType(md.userType, null) !== null;
      if (mdHasRole) {
        const minimal = toAppUser(data.user, null);
        await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(minimal));
        setUser(minimal);
        setAuthReady(true);
      }

      // Enrich in background
      (async () => {
        try {
          let profile = await withTimeout(fetchProfile(data.user.id), 3000, 'fetchProfile(login)');
          if (!profile) {
            await upsertProfile(data.user);
            profile = await withTimeout(fetchProfile(data.user.id), 3000, 'fetchProfile(login:rehydrate)');
          }
          const enriched = toAppUser(data.user, profile);
          if (normalizeUserType(enriched.userType, null) === 'valeter') {
            await ensureValeterBootstrapRows(data.user, enriched);
          }
          
          // Automatic correction: if email-based override changed the role, update database
          const email = (data.user.email ?? '').toLowerCase();
          const shouldBeCustomer = KNOWN_CUSTOMER_EMAILS.has(email);
          const shouldBeValeter = KNOWN_VALETER_EMAILS.has(email);
          
          if (shouldBeCustomer && enriched.userType !== 'customer') {
            // Update profile table
            await supabase
              .from('profiles')
              .update({ user_type: 'customer' })
              .eq('id', data.user.id);
            // Update auth metadata
            await supabase.auth.updateUser({
              data: { userType: 'customer' }
            });
            // Re-fetch and update user
            const correctedProfile = await fetchProfile(data.user.id);
            const corrected = toAppUser(data.user, correctedProfile);
            await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(corrected));
            setUser(corrected);
            setAuthReady(true);
          } else if (shouldBeValeter && enriched.userType !== 'valeter') {
            // Update profile table
            await supabase
              .from('profiles')
              .update({ user_type: 'valeter' })
              .eq('id', data.user.id);
            // Update auth metadata
            await supabase.auth.updateUser({
              data: { userType: 'valeter' }
            });
            // Re-fetch and update user
            const correctedProfile = await fetchProfile(data.user.id);
            const corrected = toAppUser(data.user, correctedProfile);
            await ensureValeterBootstrapRows(data.user, corrected);
            await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(corrected));
            setUser(corrected);
            setAuthReady(true);
          } else {
          await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(enriched));
          setUser(enriched);
          setAuthReady(true);
          }
        } catch (e: any) {
          console.warn('[Auth DEBUG] login enrichment failed:', e?.message || e);
          if (!mdHasRole) {
            setAuthReady(true);
          }
        }
      })();

      return true;
    } catch (e: any) {
      console.warn('[Auth DEBUG] login error:', e?.message || e);
      setAuthReady(true);
      loginInProgressRef.current = false;
      return false;
    } finally {
      setIsLoading(false);
      // Clear login flag after a short delay to allow state to settle
      setTimeout(() => {
        loginInProgressRef.current = false;
      }, 500);
    }
  };

  const logout = async (): Promise<void> => {
    setIsLoading(true);
    setAuthReady(false);
    try {
      await withTimeout(supabase.auth.signOut(), 3000, 'signOut');
      await AsyncStorage.removeItem(SESSION_KEY);
      setUser(null);
    } catch (e: any) {
      console.warn('[Auth DEBUG] logout error:', e?.message || e);
    } finally {
      setIsLoading(false);
      setAuthReady(true);
    }
  };

  const register: AuthContextType['register'] = async (userData) => {
    setIsLoading(true);
    setAuthReady(false);
    try {
      const {
        email, password, name, phone, userType,
        organizationId, organizationType, profilePicture,
        orgName, contactName,
      } = userData;

      if (!email || !password) {
        return false;
      }

      // With email confirmation ON, we only stash intent here.
      const { data, error } = await withTimeout(
        supabase.auth.signUp({
          email: String(email),
          password: String(password),
          options: {
            emailRedirectTo: Linking.createURL('/auth/callback'),
            data: {
              full_name: contactName ?? name, // human's name
              name: contactName ?? name,
              phone,
              userType,
              organizationId,      // probably null for org sign-up
              organizationType,
              profilePicture,
              // used post-login
              pendingOrgName: userType === 'organization' ? (orgName ?? name) : null,
              pendingContactName: userType === 'organization' ? (contactName ?? name) : null,
            },
          },
        }),
        5000,
        'signUp'
      );
      if (error) {
        setAuthReady(true);
        return false;
      }

      if (data.user) {
        const registeredUser = data.user;
        // Minimal now if metadata has role
        const md = registeredUser.user_metadata ?? {};
        const mdHasRole = normalizeUserType(md.userType, null) !== null;
        if (mdHasRole) {
          const minimal = toAppUser(registeredUser, null);
          await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(minimal));
          setUser(minimal);
          setAuthReady(true);
        }

        // Enrich later (profile upsert with whatever we have)
        (async () => {
          try {
            const profileSeed: Partial<User> = {
              name: contactName ?? name,
              userType,
              verificationType: 'none',
              isVerified: false,
              totalWashes: 0,
              tier: 'bronze',
              tierPoints: 0,
            };
            if (typeof phone === 'string' && phone.length > 0) {
              profileSeed.phone = phone;
            }
            if (typeof organizationId === 'string' && organizationId.length > 0) {
              profileSeed.organizationId = organizationId;
            }
            if (organizationType === 'independent' || organizationType === 'registered') {
              profileSeed.organizationType = organizationType;
            }
            if (typeof profilePicture === 'string' && profilePicture.length > 0) {
              profileSeed.profilePicture = profilePicture;
            }
            await upsertProfile(registeredUser, profileSeed);
            const profile = await withTimeout(fetchProfile(registeredUser.id), 3000, 'fetchProfile(register)');
            const enriched = toAppUser(registeredUser, profile);
            if (normalizeUserType(enriched.userType, null) === 'valeter') {
              await ensureValeterBootstrapRows(registeredUser, enriched);
            }
            await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(enriched));
            setUser(enriched);
            setAuthReady(true);
          } catch (e: any) {
            console.warn('[Auth DEBUG] register enrichment failed:', e?.message || e);
            if (!mdHasRole) {
              setAuthReady(true);
            }
          }
        })();
      } else {
        setAuthReady(true);
      }

      return true;
    } catch (e: any) {
      console.warn('[Auth DEBUG] register error:', e?.message || e);
      setAuthReady(true);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const updateUser = async (updates: Partial<User>): Promise<void> => {
    if (!user) {
      return;
    }

    const md = authMetadataPatchFromUserUpdates(updates);
    const patch = profileRowPatchFromUserUpdates(updates);

    try {
      setIsLoading(true);
      if (Object.keys(md).length) {
        await withTimeout(supabase.auth.updateUser({ data: md }), 3000, 'updateUser(auth)');
      }

      if (Object.keys(patch).length) {
        const profileUpdate = supabase.from('profiles').update(patch).eq('id', user.id);
        await withTimeout(Promise.resolve(profileUpdate), 4000, 'updateProfile(row)');
      }

      const { data } = await withTimeout(supabase.auth.getUser(), 3000, 'getUser(refresh)');
      const profile = data.user ? await withTimeout(fetchProfile(data.user.id), 3000, 'fetchProfile(refresh)') : null;
      const appUser = data.user ? toAppUser(data.user, profile) : null;
      if (appUser) await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(appUser));
      setUser(appUser);
    } catch (e: any) {
      console.warn('[Auth DEBUG] updateUser error:', e?.message || e);
    } finally {
      setIsLoading(false);
    }
  };

  const updatePassword = async (_currentPassword: string, newPassword: string): Promise<void> => {
    const { error } = await withTimeout(supabase.auth.updateUser({ password: newPassword }), 3000, 'updatePassword');
    if (error) {
      console.warn('[Auth DEBUG] updatePassword error:', error.message);
      throw error;
    }
  };

  const updateProfile = async (updates: Partial<User>): Promise<void> => updateUser(updates);

  const resetPassword = async (email: string): Promise<void> => {
    const { error } = await withTimeout(
      supabase.auth.resetPasswordForEmail(email, {
        redirectTo: Linking.createURL('/auth/reset-password'),
      }),
      3000,
      'resetPassword'
    );
    if (error) {
      console.warn('[Auth DEBUG] resetPassword error:', error.message);
      throw error;
    }
  };

  const autoLoginCustomer = async () => {
    // await login('customer@test.com', 'password123');
  };
  const autoLoginValeter = async () => {
    // await login('valeter@test.com', 'password123');
  };

  const hasAdminAccess = (): boolean => (user?.email?.toLowerCase?.() ?? '') === 'admin@wishawashapp.com';
  const isBusinessOwner = (): boolean => normalizeUserType(user?.userType, null) === 'organization';

  const markWelcomeSeen = async (userType: 'customer' | 'valeter') => {
    await AsyncStorage.setItem(`welcome_seen_${userType}`, 'true');
  };
  const hasSeenWelcome = async (userType: 'customer' | 'valeter') => {
    const seen = await AsyncStorage.getItem(`welcome_seen_${userType}`);
    return seen === 'true';
  };

  const isIndividualValeter = (): boolean =>
    normalizeUserType(user?.userType, null) === 'valeter' && user?.organizationType !== 'registered';

  const isOrganizationValeter = (): boolean =>
    normalizeUserType(user?.userType, null) === 'valeter' && user?.organizationType === 'registered';

  const requiresIndividualDocuments = (): boolean =>
    normalizeUserType(user?.userType, null) === 'valeter' && !user?.isVerified && user?.organizationType !== 'registered';

  const requiresOrganizationDocuments = (): boolean =>
    normalizeUserType(user?.userType, null) === 'valeter' && user?.organizationType === 'registered' && !user?.isVerified;

  const getOrganization = (): Organization | null => {
    if (!user?.organizationId) return null;
    return {
      id: user.organizationId,
      name: 'Organization',
      contactEmail: user.email,
      isVerified: false,
      insuranceVerified: false,
      licenseVerified: false,
      createdAt: new Date(),
      updatedAt: new Date(),
    } as Organization;
  };

  const value: AuthContextType = useMemo(() => ({
    user,
    isLoading,
    authReady,

    login,
    loginWithGoogle,
    loginWithApple,
    logout,
    register,
    registerWithApple,
    registerWithGoogle,
    updateUser,
    updatePassword,
    updateProfile,
    resetPassword,
    autoLoginCustomer,
    autoLoginValeter,
    hasAdminAccess,
    isBusinessOwner,
    markWelcomeSeen,
    hasSeenWelcome,
    isIndividualValeter,
    isOrganizationValeter,
    requiresIndividualDocuments,
    requiresOrganizationDocuments,
    getOrganization,
  }), [user, isLoading, authReady]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = (): AuthContextType => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
};

export default AuthProvider;
