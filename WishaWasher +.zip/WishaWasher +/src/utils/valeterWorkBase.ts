import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Location from 'expo-location';

/** A place the Pro picked in the header to receive jobs from, instead of live GPS. */
export type WorkBase = Readonly<{ label: string; lat: number; lng: number }>;

const keyFor = (userId: string) => `valeter_work_base_v1:${userId}`;

const round = (n: number) => Number(n.toFixed(6));

export async function loadWorkBase(userId: string): Promise<WorkBase | null> {
  try {
    const raw = await AsyncStorage.getItem(keyFor(userId));
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<WorkBase>;
    if (typeof parsed.label !== 'string' || !Number.isFinite(parsed.lat) || !Number.isFinite(parsed.lng)) return null;
    return { label: parsed.label, lat: parsed.lat as number, lng: parsed.lng as number };
  } catch {
    return null;
  }
}

const UK_POSTCODE = /^[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}$|^[A-Z]{1,2}\d[A-Z\d]?$/i;

export function looksLikePostcode(text: string): boolean {
  return UK_POSTCODE.test(text.trim());
}

/** Area name for a point, e.g. "Shoreditch"; null when the geocoder has nothing useful. */
export async function placeName(lat: number, lng: number): Promise<string | null> {
  try {
    const [entry] = await Location.reverseGeocodeAsync({ latitude: lat, longitude: lng });
    if (!entry) return null;
    const candidates = [entry.district, entry.subregion, entry.city, entry.region];
    return candidates.find((p): p is string => !!p && !looksLikePostcode(p)) ?? null;
  } catch {
    return null;
  }
}

/** Saved labels that should be swapped for the bare area name (typed postcodes, or older "Area, Town"). */
export function needsAreaName(label: string): boolean {
  return looksLikePostcode(label) || label.includes(',');
}

const recentKeyFor = (userId: string) => `valeter_work_base_recent_v1:${userId}`;
const MAX_RECENT = 4;

export async function loadRecentBases(userId: string): Promise<WorkBase[]> {
  try {
    const raw = await AsyncStorage.getItem(recentKeyFor(userId));
    const list = raw ? (JSON.parse(raw) as WorkBase[]) : [];
    return Array.isArray(list)
      ? list.filter((b) => typeof b?.label === 'string' && Number.isFinite(b.lat) && Number.isFinite(b.lng))
      : [];
  } catch {
    return [];
  }
}

export async function saveWorkBase(userId: string, base: WorkBase): Promise<WorkBase[]> {
  const clean = { label: base.label, lat: round(base.lat), lng: round(base.lng) };
  await AsyncStorage.setItem(keyFor(userId), JSON.stringify(clean));
  const prev = await loadRecentBases(userId);
  const same = (b: WorkBase) =>
    b.label.toLowerCase() === clean.label.toLowerCase() || (b.lat === clean.lat && b.lng === clean.lng);
  const recent = [clean, ...prev.filter((b) => !same(b))].slice(0, MAX_RECENT);
  await AsyncStorage.setItem(recentKeyFor(userId), JSON.stringify(recent)).catch(() => undefined);
  return recent;
}

export async function clearWorkBase(userId: string): Promise<void> {
  await AsyncStorage.removeItem(keyFor(userId));
}

/**
 * Coordinates to publish as the Pro's presence: the picked work base when set, otherwise live GPS.
 * Returns null when there's no base and location permission isn't granted.
 */
export async function presenceCoords(userId: string, askPermission: boolean): Promise<{ lat: number; lng: number } | null> {
  const base = await loadWorkBase(userId);
  if (base) return { lat: base.lat, lng: base.lng };
  let { status } = await Location.getForegroundPermissionsAsync();
  if (status !== 'granted' && askPermission) {
    ({ status } = await Location.requestForegroundPermissionsAsync());
  }
  if (status !== 'granted') return null;
  const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
  return { lat: round(loc.coords.latitude), lng: round(loc.coords.longitude) };
}
