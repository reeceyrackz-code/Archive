import { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

/** Platform fee taken from each booking (matches StripePaymentService). */
export const VALETER_PLATFORM_FEE_RATE = 0.05;

export function takeHome(gross: number): number {
  const net = (Number(gross) || 0) * (1 - VALETER_PLATFORM_FEE_RATE);
  return Math.round(net * 100) / 100;
}

export const DAILY_GOAL_OPTIONS = [50, 100, 150, 200, 250] as const;
const DEFAULT_DAILY_GOAL = 100;
const GOAL_KEY = 'valeter_daily_goal_v1';

let cachedGoal: number | null = null;
const listeners = new Set<(goal: number) => void>();

async function readGoal(): Promise<number> {
  if (cachedGoal != null) return cachedGoal;
  try {
    const raw = await AsyncStorage.getItem(GOAL_KEY);
    const parsed = raw ? Number(raw) : Number.NaN;
    cachedGoal = Number.isFinite(parsed) && parsed > 0 ? parsed : DEFAULT_DAILY_GOAL;
  } catch {
    cachedGoal = DEFAULT_DAILY_GOAL;
  }
  return cachedGoal;
}

export async function setValeterDailyGoal(goal: number): Promise<void> {
  cachedGoal = goal;
  listeners.forEach((fn) => fn(goal));
  try {
    await AsyncStorage.setItem(GOAL_KEY, String(goal));
  } catch {
    /* preference only */
  }
}

/** Daily take-home goal (device preference), shared between header and earnings sheet. */
export function useValeterDailyGoal(): number {
  const [goal, setGoal] = useState<number>(cachedGoal ?? DEFAULT_DAILY_GOAL);
  useEffect(() => {
    let active = true;
    void readGoal().then((g) => {
      if (active) setGoal(g);
    });
    listeners.add(setGoal);
    return () => {
      active = false;
      listeners.delete(setGoal);
    };
  }, []);
  return goal;
}

export function startOfToday(): Date {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}

/** Monday 00:00 of the current week. */
export function startOfWeek(): Date {
  const d = startOfToday();
  const day = (d.getDay() + 6) % 7;
  d.setDate(d.getDate() - day);
  return d;
}

export function startOfMonth(): Date {
  const d = startOfToday();
  d.setDate(1);
  return d;
}
