import * as FileSystem from 'expo-file-system/legacy';
import { supabase } from '../lib/supabase';

const BUCKET = 'valeter_documents';

function extAndMime(uri: string) {
  const clean = (uri || '').split('?')[0];
  const extRaw = (clean.split('.').pop() || 'jpg').toLowerCase();
  const ext = extRaw === 'jpg' ? 'jpeg' : extRaw;
  let mime = 'image/jpeg';
  if (ext === 'png') mime = 'image/png';
  else if (ext === 'webp') mime = 'image/webp';
  else if (ext === 'heic') mime = 'image/heic';
  else if (ext === 'heif') mime = 'image/heif';
  return { extRaw, mime };
}

function base64ToBytes(base64: string) {
  const binary = globalThis.atob ? globalThis.atob(base64) : Buffer.from(base64, 'base64').toString('binary');
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.codePointAt(i) ?? 0;
  return bytes;
}

/** Same storage path + profile columns the Pro profile screen writes when changing the photo. */
export async function uploadValeterProfilePhoto(userId: string, uri: string, fullName: string): Promise<string> {
  const { extRaw, mime } = extAndMime(uri);
  const path = `profiles/${userId}/profile_${userId}_${Date.now()}.${extRaw || 'jpg'}`;
  const base64 = await FileSystem.readAsStringAsync(uri, { encoding: 'base64' as any });

  const { data, error } = await supabase.storage.from(BUCKET).upload(path, base64ToBytes(base64), {
    contentType: mime,
    upsert: true,
  });
  if (error) throw error;

  const { data: pub } = supabase.storage.from(BUCKET).getPublicUrl(data?.path ?? path);
  const publicUrl = pub?.publicUrl;
  if (!publicUrl) throw new Error('Upload succeeded but no public URL was returned.');

  const { error: upsertError } = await supabase
    .from('valeter_profiles')
    .upsert(
      { user_id: userId, profile_photo_url: publicUrl, full_name: fullName.trim() || ' ' },
      { onConflict: 'user_id' }
    );
  if (upsertError) throw upsertError;

  await supabase.from('profiles').update({ profile_picture: publicUrl }).eq('id', userId);
  return publicUrl;
}
