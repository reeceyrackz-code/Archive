import type { ComponentProps } from 'react';
import type { Ionicons } from '@expo/vector-icons';
import {
  detailingServiceOptions,
  repairServiceOptions,
  serviceOptions,
  LEGACY_ECO_SERVICE_ID_MAP,
  findServiceOptionById,
} from '../constants/serviceOptions';
import { SERVICE_NAME_MAP, getServiceDisplayName, getServiceTrackingCategory } from './serviceNameMapper';

type IconName = ComponentProps<typeof Ionicons>['name'];

/** Animation played over the car while the Pro is at a station. */
export type StationFx =
  | 'water'
  | 'foam'
  | 'wheels'
  | 'mitt'
  | 'air'
  | 'sparkle'
  | 'vacuum'
  | 'scan'
  | 'polisher'
  | 'mist'
  | 'tools'
  | 'headlights'
  | 'dab';

export type WashStation = { label: string; icon: IconName; fx: StationFx };
export type JobKind = 'wash' | 'detail' | 'repair';

const st = (label: string, icon: IconName, fx: StationFx): WashStation => ({ label, icon, fx });
const FINISH = st('Complete', 'checkmark-circle-outline', 'sparkle');

const EXTERIOR_WASH: WashStation[] = [
  st('Pre-rinse', 'water', 'water'),
  st('Snow foam', 'snow', 'foam'),
  st('Wheels', 'disc', 'wheels'),
  st('Hand wash', 'hand-left', 'mitt'),
  st('Rinse', 'rainy', 'water'),
  st('Dry', 'sunny', 'air'),
  st('Glass', 'tablet-landscape-outline', 'scan'),
  FINISH,
];

const LIGHT_INTERIOR: WashStation[] = [
  st('Tidy up', 'file-tray-outline', 'sparkle'),
  st('Vacuum', 'aperture-outline', 'vacuum'),
  st('Wipe-down', 'hand-left', 'mitt'),
  st('Glass', 'tablet-landscape-outline', 'scan'),
  FINISH,
];

/** Stations per catalogue package, in the order each description lists the work. */
const PLANS: Record<string, WashStation[]> = {
  'bronze-wash': EXTERIOR_WASH,
  'silver-wash': [
    st('Pre-rinse', 'water', 'water'),
    st('Hand wash', 'hand-left', 'mitt'),
    st('Wheels', 'disc', 'wheels'),
    st('Dry', 'sunny', 'air'),
    st('Vacuum', 'aperture-outline', 'vacuum'),
    st('Dashboard', 'speedometer-outline', 'mitt'),
    st('Glass', 'tablet-landscape-outline', 'scan'),
    st('Tyre shine', 'ellipse-outline', 'wheels'),
    FINISH,
  ],
  'gold-wash': [
    st('Deep vacuum', 'aperture-outline', 'vacuum'),
    st('Stains', 'color-wand-outline', 'dab'),
    st('Shampoo', 'water-outline', 'foam'),
    st('Surfaces', 'hand-left', 'mitt'),
    st('Leather', 'shirt-outline', 'mitt'),
    st('Headliner', 'arrow-up-circle-outline', 'scan'),
    st('Glass', 'tablet-landscape-outline', 'scan'),
    st('Freshen', 'leaf-outline', 'mist'),
    FINISH,
  ],
  'platinum-wash': [
    st('Pre-rinse', 'water', 'water'),
    st('Snow foam', 'snow', 'foam'),
    st('Arches', 'disc', 'wheels'),
    st('Hand wash', 'hand-left', 'mitt'),
    st('Dry', 'sunny', 'air'),
    st('Deep vacuum', 'aperture-outline', 'vacuum'),
    st('Shampoo', 'water-outline', 'foam'),
    st('Trims & glass', 'tablet-landscape-outline', 'scan'),
    FINISH,
  ],
  'emerald-wash': [
    st('Snow foam', 'snow', 'foam'),
    st('Hand wash', 'hand-left', 'mitt'),
    st('Decon', 'flask-outline', 'mist'),
    st('Dry', 'sunny', 'air'),
    st('Polish', 'color-filter-outline', 'polisher'),
    st('Protect', 'shield-checkmark-outline', 'mist'),
    st('Deep interior', 'aperture-outline', 'vacuum'),
    st('Leather care', 'shirt-outline', 'mitt'),
    FINISH,
  ],
  'ceramic-coating': [
    st('Wash', 'water', 'foam'),
    st('Decon', 'flask-outline', 'mist'),
    st('Paint prep', 'search-outline', 'scan'),
    st('Correction', 'color-filter-outline', 'polisher'),
    st('Coating', 'shield-checkmark-outline', 'mist'),
    st('Curing', 'sunny-outline', 'scan'),
    FINISH,
  ],
  'machine-polishing': [
    st('Wash', 'water', 'foam'),
    st('Decon', 'flask-outline', 'mist'),
    st('Inspect', 'search-outline', 'scan'),
    st('Cut', 'color-filter-outline', 'polisher'),
    st('Refine', 'sparkles-outline', 'polisher'),
    st('Seal', 'shield-checkmark-outline', 'mist'),
    FINISH,
  ],
  'soft-top-restoration': [
    st('Gentle wash', 'water', 'water'),
    st('Mould treat', 'medkit-outline', 'mist'),
    st('Clean fabric', 'brush-outline', 'mitt'),
    st('Condition', 'color-palette-outline', 'mitt'),
    st('Waterproof', 'umbrella-outline', 'mist'),
    st('Seals check', 'search-outline', 'scan'),
    FINISH,
  ],
  'mould-removal': [
    st('Inspect', 'search-outline', 'scan'),
    st('Air-con', 'snow-outline', 'mist'),
    st('Treat mould', 'medkit-outline', 'mist'),
    st('Upholstery', 'shirt-outline', 'mitt'),
    st('De-odour', 'leaf-outline', 'mist'),
    FINISH,
  ],
  'maintenance-check': [
    st('Coolant', 'thermometer-outline', 'tools'),
    st('Oil level', 'speedometer-outline', 'tools'),
    st('Tyre tread', 'disc', 'wheels'),
    st('Lights', 'bulb', 'headlights'),
    st('Screen wash', 'rainy-outline', 'tools'),
    FINISH,
  ],
  'headlight-restoration': [
    st('Inspect', 'search-outline', 'scan'),
    st('Prep', 'hand-left', 'mitt'),
    st('Remove haze', 'bulb-outline', 'polisher'),
    st('Polish', 'sparkles-outline', 'polisher'),
    st('UV seal', 'shield-checkmark-outline', 'mist'),
    st('Lights on', 'bulb', 'headlights'),
    FINISH,
  ],
  'scratch-removal': [
    st('Inspect', 'search-outline', 'scan'),
    st('Clean area', 'water', 'mitt'),
    st('Correct', 'color-filter-outline', 'polisher'),
    st('Refine', 'sparkles-outline', 'polisher'),
    st('Protect', 'shield-checkmark-outline', 'mist'),
    FINISH,
  ],
  'paint-chip-repair': [
    st('Clean', 'water', 'mitt'),
    st('Rust treat', 'medkit-outline', 'dab'),
    st('Touch-in', 'color-palette-outline', 'dab'),
    st('Level & seal', 'shield-checkmark-outline', 'mist'),
    FINISH,
  ],
  'trim-restoration': [
    st('Clean trim', 'hand-left', 'mitt'),
    st('Treat fade', 'color-wand-outline', 'dab'),
    st('Restore', 'albums-outline', 'mitt'),
    st('UV protect', 'shield-checkmark-outline', 'mist'),
    FINISH,
  ],
  'leather-repair': [
    st('Assess', 'search-outline', 'scan'),
    st('Clean', 'hand-left', 'mitt'),
    st('Repair', 'build-outline', 'dab'),
    st('Colour blend', 'color-palette-outline', 'dab'),
    st('Condition', 'shirt-outline', 'mitt'),
    FINISH,
  ],
};

const DETAIL_IDS = new Set(detailingServiceOptions.map((o) => o.id));
const REPAIR_IDS = new Set([...repairServiceOptions.map((o) => o.id), 'maintenance-check']);

const GENERIC: Record<JobKind, WashStation[]> = {
  wash: EXTERIOR_WASH,
  detail: [
    st('Prep', 'water', 'water'),
    st('Decon', 'flask-outline', 'mist'),
    st('Interior', 'aperture-outline', 'vacuum'),
    st('Polish', 'color-filter-outline', 'polisher'),
    st('Protect', 'shield-checkmark-outline', 'mist'),
    FINISH,
  ],
  repair: [
    st('Inspect', 'search-outline', 'scan'),
    st('Prep', 'hand-left', 'mitt'),
    st('Repair', 'build-outline', 'tools'),
    st('Check', 'checkmark-done-outline', 'scan'),
    FINISH,
  ],
};

export function jobKindFor(serviceId: string | null | undefined, isDetailing: boolean): JobKind {
  const id = serviceId ? (LEGACY_ECO_SERVICE_ID_MAP[serviceId] ?? serviceId) : '';
  if (REPAIR_IDS.has(id)) return 'repair';
  if (DETAIL_IDS.has(id) || isDetailing) return 'detail';
  return 'wash';
}

/** Stations for a booking, following what its package says is included. */
export function stationsForService(
  serviceId: string | null | undefined,
  washType: string | null | undefined,
  kind: JobKind
): WashStation[] {
  const id = serviceId ? (LEGACY_ECO_SERVICE_ID_MAP[serviceId] ?? serviceId) : '';
  if (id === 'bronze-wash' && washType === 'interior') return LIGHT_INTERIOR;
  if (id === 'bronze-wash' && washType === 'both') return [...EXTERIOR_WASH.slice(0, -1), ...LIGHT_INTERIOR];
  return PLANS[id] ?? GENERIC[kind];
}

/** Extra stop for each add-on, slotted in before the finish line. */
const ADD_ON_STATIONS: Record<string, WashStation> = {
  'pet-hair': st('Pet hair', 'paw-outline', 'vacuum'),
  'stain-removal': st('Stains', 'color-wand-outline', 'dab'),
  'engine-bay': st('Engine bay', 'cog-outline', 'tools'),
  'headlight-restoration': st('Headlights', 'bulb', 'headlights'),
  'seat-shampoo': st('Seat shampoo', 'water-outline', 'foam'),
  'ceramic-spray': st('Ceramic spray', 'shield-checkmark-outline', 'mist'),
  'floor-mats-carpet-shampoo': st('Mats & carpets', 'grid-outline', 'foam'),
  'clay-bar-treatment': st('Clay bar', 'hand-left', 'mitt'),
  'iron-tar-decontamination': st('Iron & tar', 'flask-outline', 'mist'),
  'wiper-blade-install': st('Wipers', 'rainy-outline', 'tools'),
  'coolant-top-up': st('Coolant top-up', 'thermometer-outline', 'tools'),
  'oil-level-check': st('Oil level', 'speedometer-outline', 'tools'),
  'screen-wash-refill': st('Screen wash', 'cloud-outline', 'tools'),
};
const ADD_ON_MINUTES = 10;

const CATALOGUE = [...serviceOptions, ...detailingServiceOptions, ...repairServiceOptions];
const CATALOGUE_IDS = new Set(CATALOGUE.map((o) => o.id));
const ID_BY_NAME = new Map(CATALOGUE.map((o) => [o.name.toLowerCase(), o.id]));
const KEYWORD_IDS: ReadonlyArray<readonly [RegExp, string]> = [
  [/ceramic/, 'ceramic-coating'],
  [/polish|correction/, 'machine-polishing'],
  [/soft.?top|convertible/, 'soft-top-restoration'],
  [/mou?ld/, 'mould-removal'],
  [/headlight/, 'headlight-restoration'],
  [/scratch|swirl/, 'scratch-removal'],
  [/chip/, 'paint-chip-repair'],
  [/trim/, 'trim-restoration'],
  [/leather/, 'leather-repair'],
  [/maintenance|health.?check/, 'maintenance-check'],
  [/diamond|emerald/, 'emerald-wash'],
  [/platinum/, 'platinum-wash'],
  [/gold/, 'gold-wash'],
  [/silver/, 'silver-wash'],
  [/bronze/, 'bronze-wash'],
];

const slug = (v: string) => v.trim().toLowerCase().replace(/[_\s]+/g, '-');

/**
 * Catalogue package id for a booking, whatever shape it was saved in: package ids, legacy eco ids,
 * legacy types ("full_valet"), display names ("Gold Wash") or a free-text name.
 */
export function resolveServiceId(serviceType: string | null | undefined, serviceName: string | null | undefined): string | null {
  for (const raw of [serviceType, serviceName]) {
    if (!raw) continue;
    const id = LEGACY_ECO_SERVICE_ID_MAP[slug(raw)] ?? slug(raw);
    if (CATALOGUE_IDS.has(id)) return id;
  }
  const byName = serviceName ? ID_BY_NAME.get(serviceName.trim().toLowerCase()) : undefined;
  if (byName) return byName;
  const legacy = serviceType ? (SERVICE_NAME_MAP[serviceType] ?? SERVICE_NAME_MAP[slug(serviceType)]) : undefined;
  const byLegacy = legacy ? ID_BY_NAME.get(legacy.toLowerCase()) : undefined;
  if (byLegacy) return byLegacy;
  for (const raw of [serviceName, serviceType]) {
    if (!raw) continue;
    const lower = raw.toLowerCase();
    const hit = KEYWORD_IDS.find(([re]) => re.test(lower));
    if (hit) return hit[1];
  }
  return null;
}

export function parseAddOnIds(raw: unknown): string[] {
  let list: unknown[] = [];
  if (Array.isArray(raw)) list = raw;
  else if (typeof raw === 'string') list = raw.split(',');
  return [...new Set(list.map((v) => String(v).trim()).filter(Boolean))];
}

export type BookingJourneyInput = Readonly<{
  serviceType: string | null | undefined;
  serviceName: string | null | undefined;
  washType?: string | null;
  addOnIds?: unknown;
}>;

export type BookingJourney = Readonly<{
  serviceId: string | null;
  kind: JobKind;
  packageName: string;
  stations: WashStation[];
  addOnCount: number;
  estimateMs: number;
}>;

function kindForCategory(category: ReturnType<typeof getServiceTrackingCategory>): JobKind {
  if (category === 'repair') return 'repair';
  if (category === 'detailing') return 'detail';
  return 'wash';
}

/** Everything the work-stage journey needs, derived from what the customer actually booked. */
export function bookingJourney(b: BookingJourneyInput): BookingJourney {
  const serviceId = resolveServiceId(b.serviceType, b.serviceName);
  const category = getServiceTrackingCategory(b.serviceType, b.serviceName);
  const kind: JobKind = serviceId ? jobKindFor(serviceId, false) : kindForCategory(category);
  const washType = b.washType === 'interior' || b.washType === 'exterior' || b.washType === 'both' ? b.washType : null;
  const base = stationsForService(serviceId, washType, kind);
  const have = new Set(base.map((s) => s.label.toLowerCase()));
  const included = new Set(findServiceOptionById(serviceId ?? '')?.includedAddOnIds ?? []);
  const extras = parseAddOnIds(b.addOnIds)
    .filter((id) => !included.has(id) && id !== serviceId)
    .map((id) => ADD_ON_STATIONS[id])
    .filter((s): s is WashStation => !!s && !have.has(s.label.toLowerCase()));
  const stations = extras.length ? [...base.slice(0, -1), ...extras, base.at(-1)!] : base;
  const option = serviceId ? findServiceOptionById(serviceId) : undefined;
  const packageName = option?.name ?? getServiceDisplayName(b.serviceType, b.serviceName);
  const estimateMs = washEstimateMs(serviceId, kind) + extras.length * ADD_ON_MINUTES * 60000;
  return { serviceId, kind, packageName, stations, addOnCount: extras.length, estimateMs };
}

/* Whitespace is collapsed to single spaces first, so each optional space can only match one way. */
const NUM = String.raw`(\d+(?:\.\d+)?)`;
const DURATION_RE = new RegExp(String.raw`${NUM} ?(?:[–-] ?${NUM} ?)?(h(?:ours?|rs?)?|m(?:in(?:ute)?s?)?)\b`, 'i');

/**
 * Midpoint of a duration label like "20–35 min", "60–90 mins" or "2–3 hours".
 * Returns null when the label can't be read.
 */
export function minutesFromDurationLabel(label: string | null | undefined): number | null {
  if (!label) return null;
  const text = label.replaceAll(/\s+/g, ' ');
  const m = DURATION_RE.exec(text);
  if (!m) return null;
  const lo = Number(m[1]);
  const hi = m[2] ? Number(m[2]) : lo;
  const unitIsHours = (m[3] ?? '').toLowerCase().startsWith('h');
  const mid = (lo + hi) / 2;
  const minutes = unitIsHours ? mid * 60 : mid;
  return Number.isFinite(minutes) && minutes > 0 ? minutes : null;
}

const FALLBACK_MINUTES: Record<JobKind, number> = { wash: 45, repair: 90, detail: 150 };

/** Expected job length from the package's duration label, with a sensible fallback per job kind. */
export function washEstimateMs(serviceId: string | null | undefined, kind: JobKind): number {
  const opt = serviceId ? findServiceOptionById(serviceId) : undefined;
  const mins = minutesFromDurationLabel(opt?.dur) ?? FALLBACK_MINUTES[kind];
  return mins * 60000;
}

/** 0..1 progress through the job, held just short of the finish until the Pro marks it done. */
export function washJourneyProgress(startedAtMs: number, estimateMs: number, nowMs: number): number {
  if (!Number.isFinite(startedAtMs) || estimateMs <= 0) return 0;
  return Math.max(0, Math.min(0.999, (nowMs - startedAtMs) / estimateMs));
}
