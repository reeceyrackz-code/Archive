import { GOOGLE_MAPS_API_KEY } from '../config/google-maps';

const polyline = require('@mapbox/polyline');

export type LatLng = { latitude: number; longitude: number };

export type DrivingRoute = {
  coordinates: LatLng[];
  distanceMi: number;
  durationMinutes: number;
};

function metersToMiles(meters: number): number {
  return Math.round((meters / 1609.344) * 10) / 10;
}

function secondsToMinutes(seconds: number): number {
  return Math.max(1, Math.round(seconds / 60));
}

type DirectionsStep = { polyline?: { points?: string } };
type DirectionsLeg = { steps?: DirectionsStep[] };

/**
 * Full-resolution path from each step's polyline, so the line hugs every road at sat-nav zoom.
 * Falls back to the simplified overview path when steps are missing.
 */
function detailedPath(route: { legs?: DirectionsLeg[]; overview_polyline?: { points?: string } } | undefined): [number, number][] | null {
  const pts: [number, number][] = [];
  for (const leg of route?.legs ?? []) {
    for (const step of leg.steps ?? []) {
      const enc = step.polyline?.points;
      if (typeof enc !== 'string') continue;
      const seg: [number, number][] = polyline.decode(enc);
      pts.push(...(pts.length ? seg.slice(1) : seg));
    }
  }
  if (pts.length > 1) return pts;
  const overview = route?.overview_polyline?.points;
  return typeof overview === 'string' ? polyline.decode(overview) : null;
}

/** Fetch a driving route via Google Directions. Returns null if no route is available (no straight-line fallback). */
export async function fetchDrivingRoute(
  originLat: number,
  originLng: number,
  destLat: number,
  destLng: number
): Promise<DrivingRoute | null> {
  if (
    !Number.isFinite(originLat) ||
    !Number.isFinite(originLng) ||
    !Number.isFinite(destLat) ||
    !Number.isFinite(destLng)
  ) {
    return null;
  }

  const url =
    `https://maps.googleapis.com/maps/api/directions/json` +
    `?origin=${originLat},${originLng}` +
    `&destination=${destLat},${destLng}` +
    `&mode=driving` +
    `&key=${GOOGLE_MAPS_API_KEY}`;

  const res = await fetch(url);
  const json = await res.json();
  const route = json?.routes?.[0];
  const decoded = detailedPath(route);

  if (!Array.isArray(decoded) || decoded.length < 2) {
    return null;
  }

  const leg = route?.legs?.[0];
  const distanceMi =
    leg?.distance?.value != null
      ? metersToMiles(Number(leg.distance.value))
      : metersToMiles(Number(route?.legs?.reduce((sum: number, l: { distance?: { value?: number } }) => sum + (l.distance?.value ?? 0), 0) ?? 0));
  const durationMinutes =
    leg?.duration?.value != null
      ? secondsToMinutes(Number(leg.duration.value))
      : secondsToMinutes(Number(route?.legs?.reduce((sum: number, l: { duration?: { value?: number } }) => sum + (l.duration?.value ?? 0), 0) ?? 0));

  return {
    coordinates: decoded.map(([latitude, longitude]: [number, number]) => ({ latitude, longitude })),
    distanceMi,
    durationMinutes,
  };
}
