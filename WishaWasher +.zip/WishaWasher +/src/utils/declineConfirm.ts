import { Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const PREF_KEY = 'valeter_decline_confirm_v1';

/** 'skip' = decline on first tap; 'ask' = always confirm, and don't offer to stop asking. */
type DeclinePref = 'ask' | 'skip';

async function loadPref(): Promise<DeclinePref | null> {
  try {
    const raw = await AsyncStorage.getItem(PREF_KEY);
    return raw === 'ask' || raw === 'skip' ? raw : null;
  } catch {
    return null;
  }
}

function savePref(pref: DeclinePref | null) {
  const write = pref ? AsyncStorage.setItem(PREF_KEY, pref) : AsyncStorage.removeItem(PREF_KEY);
  write.catch(() => undefined);
}

/** Bring the "Are you sure?" check back after the Pro switched it off. */
export function resetDeclineConfirm() {
  savePref(null);
}

function offerToStopAsking() {
  Alert.alert(
    'Skip this check next time?',
    'Jobs will be declined as soon as you tap Decline. You can still undo for a few seconds.',
    [
      { text: 'Keep asking', style: 'cancel', onPress: () => savePref('ask') },
      { text: "Don't ask again", onPress: () => savePref('skip') },
    ]
  );
}

/**
 * Resolves true when the job should be declined. Asks "Are you sure?" unless the Pro opted out,
 * then (first time only) offers to skip the question in future.
 */
export async function confirmDecline(serviceName?: string | null): Promise<boolean> {
  const pref = await loadPref();
  if (pref === 'skip') return true;
  return new Promise((resolve) => {
    Alert.alert(
      'Decline this job?',
      `This ${serviceName || 'job'} will be offered to another Pro.`,
      [
        { text: 'Keep job', style: 'cancel', onPress: () => resolve(false) },
        {
          text: 'Decline',
          style: 'destructive',
          onPress: () => {
            resolve(true);
            if (pref == null) setTimeout(offerToStopAsking, 400);
          },
        },
      ],
      { cancelable: true, onDismiss: () => resolve(false) }
    );
  });
}
