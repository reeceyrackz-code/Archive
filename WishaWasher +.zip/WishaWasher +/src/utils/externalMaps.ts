import { Linking, Platform } from 'react-native';

function encodeDestination(address: string | null | undefined, latitude?: number | null, longitude?: number | null) {
  if (latitude != null && longitude != null && Number.isFinite(latitude) && Number.isFinite(longitude)) {
    return `${latitude},${longitude}`;
  }
  return String(address || '').trim();
}

export type NavApp = 'apple' | 'google' | 'waze';

export const NAV_APP_LABEL: Record<NavApp, string> = {
  apple: 'Apple Maps',
  google: 'Google Maps',
  waze: 'Waze',
};

/** Apps offered on this platform, most likely installed first. */
export function navAppsForPlatform(): NavApp[] {
  return Platform.OS === 'ios' ? ['apple', 'google', 'waze'] : ['google', 'waze'];
}

/**
 * Turn-by-turn in a specific app. Google and Waze use their universal links, which open the app when it's
 * installed and the browser otherwise (no URL-scheme allow-listing needed).
 */
export async function openNavApp(
  app: NavApp,
  params: { address?: string | null; latitude?: number | null; longitude?: number | null }
): Promise<void> {
  const destination = encodeDestination(params.address, params.latitude, params.longitude);
  if (!destination) throw new Error('No destination available for navigation.');
  const dest = encodeURIComponent(destination);
  const hasCoords = params.latitude != null && params.longitude != null;

  if (app === 'apple') {
    const native = `maps://?daddr=${dest}&dirflg=d`;
    await Linking.openURL((await Linking.canOpenURL(native)) ? native : `https://maps.apple.com/?daddr=${dest}&dirflg=d`);
    return;
  }
  if (app === 'waze') {
    const target = hasCoords ? `ll=${dest}` : `q=${dest}`;
    await Linking.openURL(`https://waze.com/ul?${target}&navigate=yes`);
    return;
  }
  if (Platform.OS === 'android') {
    const native = `google.navigation:q=${dest}&mode=d`;
    if (await Linking.canOpenURL(native)) {
      await Linking.openURL(native);
      return;
    }
  }
  await Linking.openURL(`https://www.google.com/maps/dir/?api=1&destination=${dest}&travelmode=driving&dir_action=navigate`);
}

export async function openExternalDirections(params: {
  address?: string | null;
  latitude?: number | null;
  longitude?: number | null;
  label?: string | null;
}): Promise<void> {
  const destination = encodeDestination(params.address, params.latitude, params.longitude);
  if (!destination) {
    throw new Error('No destination available for navigation.');
  }

  const label = encodeURIComponent(params.label || 'Destination');

  if (Platform.OS === 'ios') {
    const appleUrl = `maps://?daddr=${encodeURIComponent(destination)}&dirflg=d`;
    if (await Linking.canOpenURL(appleUrl)) {
      await Linking.openURL(appleUrl);
      return;
    }

    await Linking.openURL(`https://maps.apple.com/?daddr=${encodeURIComponent(destination)}&dirflg=d&q=${label}`);
    return;
  }

  if (Platform.OS === 'android') {
    const googleNavUrl = `google.navigation:q=${encodeURIComponent(destination)}&mode=d`;
    if (await Linking.canOpenURL(googleNavUrl)) {
      await Linking.openURL(googleNavUrl);
      return;
    }

    await Linking.openURL(`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(destination)}&travelmode=driving`);
    return;
  }

  await Linking.openURL(`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(destination)}&travelmode=driving`);
}
