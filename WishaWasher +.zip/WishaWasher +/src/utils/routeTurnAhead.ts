type LatLng = Readonly<{ latitude: number; longitude: number }>;

/** Next bend on the route: signed angle in degrees (positive = right) and how far ahead it is. */
export type RouteTurn = Readonly<{ angle: number; inMetres: number }>;

const EARTH_R = 6371000;
const MIN_SEGMENT_M = 8;
const TURN_MIN_DEG = 25;

function toLocal(origin: LatLng, p: LatLng) {
  const k = Math.cos((origin.latitude * Math.PI) / 180);
  return {
    x: ((p.longitude - origin.longitude) * Math.PI * EARTH_R * k) / 180,
    y: ((p.latitude - origin.latitude) * Math.PI * EARTH_R) / 180,
  };
}

/** Compass-style heading (0 = north, clockwise) between two local points, in degrees. */
function heading(a: { x: number; y: number }, b: { x: number; y: number }) {
  return (Math.atan2(b.x - a.x, b.y - a.y) * 180) / Math.PI;
}

/** Index of the route point closest to the origin, or null when the valeter is >250 m off the route. */
function nearestOnRoute(pts: readonly { x: number; y: number }[]) {
  let nearest = 0;
  let best = Infinity;
  pts.forEach((p, i) => {
    const d = p.x * p.x + p.y * p.y;
    if (d < best) {
      best = d;
      nearest = i;
    }
  });
  return best > 250 * 250 ? null : nearest;
}

/** Closest point on the route: the segment it falls on, how far along it (0–1), and the distance in metres. */
function closestOnRoute(pos: LatLng, route: readonly LatLng[]) {
  let best = Infinity;
  let index = 0;
  let at = 0;
  for (let i = 0; i < route.length - 1; i++) {
    const a = toLocal(pos, route[i]!);
    const b = toLocal(pos, route[i + 1]!);
    const dx = b.x - a.x;
    const dy = b.y - a.y;
    const len2 = dx * dx + dy * dy;
    const t = len2 > 0 ? Math.min(1, Math.max(0, -(a.x * dx + a.y * dy) / len2)) : 0;
    const px = a.x + t * dx;
    const py = a.y + t * dy;
    const d = px * px + py * py;
    if (d < best) {
      best = d;
      index = i;
      at = t;
    }
  }
  return { index, at, metres: Math.sqrt(best) };
}

/** How far the valeter is from the route line, in metres (null when there's no usable route). */
export function distanceToRoute(pos: LatLng | null | undefined, route: readonly LatLng[] | null | undefined): number | null {
  if (!pos || !route || route.length < 2) return null;
  return closestOnRoute(pos, route).metres;
}

/** The part of the route still to drive: from the valeter's snapped position onwards. */
export function remainingRoute(pos: LatLng | null | undefined, route: readonly LatLng[] | null | undefined): LatLng[] | null {
  if (!route || route.length < 2) return null;
  if (!pos) return [...route];
  const { index, metres } = closestOnRoute(pos, route);
  if (metres > 80) return [...route];
  return [pos, ...route.slice(index + 1)];
}

/** Straight-line distance in metres (equirectangular — fine at street scale). */
export function metresBetween(a: LatLng, b: LatLng) {
  const p = toLocal(a, b);
  return Math.hypot(p.x, p.y);
}

/** Plain-English manoeuvre for a bend, e.g. "Turn left", "Bear right", "Make a U-turn". */
export function turnPhrase(turn: RouteTurn): string {
  const a = Math.abs(turn.angle);
  const side = turn.angle > 0 ? 'right' : 'left';
  if (a >= 150) return 'Make a U-turn';
  if (a >= 60) return `Turn ${side}`;
  return `Bear ${side}`;
}

function wrap(deg: number) {
  return ((((deg + 180) % 360) + 360) % 360) - 180;
}

/**
 * Looks along the driving route from the valeter's position and returns the first change of direction
 * sharper than ~25° within `lookAheadM`, or null when the road runs straight (or the route is unusable).
 */
export function routeTurnAhead(pos: LatLng | null | undefined, route: readonly LatLng[] | null | undefined, lookAheadM = 450): RouteTurn | null {
  if (!pos || !route || route.length < 3) return null;
  const pts = route.map((p) => toLocal(pos, p));

  const nearest = nearestOnRoute(pts);
  if (nearest == null) return null;

  let from = nearest;
  let to = from + 1;
  while (to < pts.length - 1 && Math.hypot(pts[to]!.x - pts[from]!.x, pts[to]!.y - pts[from]!.y) < MIN_SEGMENT_M) to++;
  if (to >= pts.length) return null;
  const current = heading(pts[from]!, pts[to]!);

  let travelled = Math.hypot(pts[to]!.x, pts[to]!.y);
  from = to;
  while (from < pts.length - 1 && travelled <= lookAheadM) {
    to = from + 1;
    while (to < pts.length - 1 && Math.hypot(pts[to]!.x - pts[from]!.x, pts[to]!.y - pts[from]!.y) < MIN_SEGMENT_M) to++;
    const angle = wrap(heading(pts[from]!, pts[to]!) - current);
    if (Math.abs(angle) >= TURN_MIN_DEG) return { angle, inMetres: travelled };
    travelled += Math.hypot(pts[to]!.x - pts[from]!.x, pts[to]!.y - pts[from]!.y);
    from = to;
  }
  return null;
}

/** Straight-line compass bearing from `a` to `b`, or null when either is missing. */
export function bearingBetween(a: LatLng | null | undefined, b: LatLng | null | undefined): number | null {
  if (!a || !b) return null;
  return (heading({ x: 0, y: 0 }, toLocal(a, b)) + 360) % 360;
}

/** Compass heading (0 = north, clockwise) of the route where the valeter is now, or null off-route. */
export function routeHeading(pos: LatLng | null | undefined, route: readonly LatLng[] | null | undefined): number | null {
  if (!pos || !route || route.length < 2) return null;
  const pts = route.map((p) => toLocal(pos, p));
  const nearest = nearestOnRoute(pts);
  if (nearest == null) return null;
  const from = Math.min(nearest, pts.length - 2);
  let to = from + 1;
  while (to < pts.length - 1 && Math.hypot(pts[to]!.x - pts[from]!.x, pts[to]!.y - pts[from]!.y) < MIN_SEGMENT_M) to++;
  return (heading(pts[from]!, pts[to]!) + 360) % 360;
}

const STREET_SUFFIXES = new Set([
  'road', 'rd', 'street', 'st', 'lane', 'ln', 'avenue', 'ave', 'close', 'drive', 'dr', 'way',
  'crescent', 'court', 'place', 'gardens', 'grove', 'terrace', 'hill', 'square', 'mews', 'row',
  'walk', 'rise', 'view', 'parade', 'green', 'park',
]);

function endsWithStreetSuffix(part: string) {
  const last = part.split(/\s+/).pop()?.toLowerCase() ?? '';
  return STREET_SUFFIXES.has(last);
}

/** "12a Oak Lane, Leeds LS1" → "Oak Lane"; skips flat/unit prefixes, bare numbers and house names. */
export function streetFromAddress(address: string | null | undefined): string | null {
  const candidates = (address ?? '')
    .split(',')
    .map((s) => s.trim())
    .filter((part) => part && !/^(flat|apartment|apt|unit|suite)\b/i.test(part) && !/^\d+[a-z]?$/i.test(part))
    .map((part) => part.replace(/^\d+[a-z]?(-\d+[a-z]?)?\s+/i, '').trim())
    .filter(Boolean);
  return candidates.find(endsWithStreetSuffix) ?? candidates[0] ?? null;
}
