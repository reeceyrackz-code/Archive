import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';

export type JobPhotos = Readonly<{ before: string | null; after: string | null }>;

const EMPTY: JobPhotos = { before: null, after: null };
const cache = new Map<string, JobPhotos>();

/** The Pro's before / finished shots for a booking, read from its chat (read-only). */
export async function fetchJobPhotos(bookingId: string): Promise<JobPhotos> {
  const { data, error } = await supabase
    .from('booking_messages')
    .select('content, media_url, created_at')
    .eq('booking_id', bookingId)
    .eq('message_type', 'image')
    .order('created_at', { ascending: true });
  if (error || !data) return cache.get(bookingId) ?? EMPTY;
  let before: string | null = null;
  let after: string | null = null;
  for (const row of data as { content: string | null; media_url: string | null }[]) {
    const tag = (row.content ?? '').toLowerCase();
    if (!row.media_url) continue;
    if (!before && tag.includes('before')) before = row.media_url;
    if (tag.includes('finished') || tag.includes('after')) after = row.media_url;
  }
  const photos = { before, after };
  cache.set(bookingId, photos);
  return photos;
}

/** Job photos, refetched whenever `refreshKey` changes (e.g. the booking status). */
export function useJobPhotos(bookingId: string | null | undefined, refreshKey: unknown, enabled = true): JobPhotos {
  const [photos, setPhotos] = useState<JobPhotos>(() => (bookingId && cache.get(bookingId)) || EMPTY);
  useEffect(() => {
    if (!bookingId || !enabled) return;
    let cancelled = false;
    void fetchJobPhotos(bookingId)
      .then((p) => {
        if (!cancelled) setPhotos(p);
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, [bookingId, refreshKey, enabled]);
  return photos;
}
