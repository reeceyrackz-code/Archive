export default {
  name: "Wish a Washer",
  slug: "wish-a-washer",
  scheme: "waw",
  version: "1.0.0",
  orientation: "portrait",
  icon: "./app/assets/icon.png",
  userInterfaceStyle: "automatic",
  splash: {
    image: "./app/assets/icon.png",
    resizeMode: "contain",
    backgroundColor: "#0A1628" // Match LoadingScreen dark theme
  },
  assetBundlePatterns: [
    "**/*"
  ],
  experiments: { 
    typedRoutes: false,
    tsconfigPaths: true
  },
  ios: {
    supportsTablet: true,
    bundleIdentifier: "com.wishawasher.app",
    buildNumber: "6",
    infoPlist: {
      NSLocationWhenInUseUsageDescription: "We use your location to find nearby valeters and show your service location.",
      NSLocationAlwaysAndWhenInUseUsageDescription: "We use your location to provide real-time tracking and service updates.",
      NSCameraUsageDescription: "We use your camera to take photos of your vehicle for service documentation.",
      NSMicrophoneUsageDescription: "We use your microphone for voice booking and communication features.",
      NSPhotoLibraryUsageDescription: "We use your photo library to select vehicle photos for service documentation.",
      NSFaceIDUsageDescription: "We use Face ID to provide secure and quick login to your account.",
      NSCalendarsUsageDescription: "We use your calendar to add and keep your booked washes in order.",
      UIBackgroundModes: ["location", "fetch", "remote-notification"],
      CFBundleDisplayName: "Wish a Wash"
    }
  },
  android: {
    package: "com.wishawasher.app",
    versionCode: 1,
    permissions: [
      "ACCESS_FINE_LOCATION",
      "ACCESS_COARSE_LOCATION",
      "CAMERA",
      "RECORD_AUDIO",
      "READ_EXTERNAL_STORAGE",
      "WRITE_EXTERNAL_STORAGE",
      "READ_CALENDAR",
      "WRITE_CALENDAR",
      "INTERNET",
      "ACCESS_NETWORK_STATE",
      "VIBRATE",
      "WAKE_LOCK"
    ],
    adaptiveIcon: {
      foregroundImage: "./app/assets/adaptive-icon.png",
      backgroundColor: "#87CEEB" // Sky blue base (gradient: sky blue #87CEEB → navy #1E3A8A → green #10B981)
    }
  },
  web: {
    favicon: "./app/assets/icon.png",
    bundler: "metro"
  },
  plugins: [
    "expo-router",
    "expo-location",
    "expo-notifications",
    "expo-image-picker",
    "expo-calendar",
    "expo-camera",
    "expo-media-library",
    "expo-file-system",
    "expo-apple-authentication",
    "expo-local-authentication"
  ],
  extra: {
    eas: {
      projectId: "90a8096b-21f7-4c99-bd76-9442d933e4e3"
    },
    /** Inlined at build time; set `EXPO_PUBLIC_STRIPE_PUBLISHABLE_KEY` in EAS / `.env` */
    stripePublishableKey: process.env.EXPO_PUBLIC_STRIPE_PUBLISHABLE_KEY ?? ""
  }
};
