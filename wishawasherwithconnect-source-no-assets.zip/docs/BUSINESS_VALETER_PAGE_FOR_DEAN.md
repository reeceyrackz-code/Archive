# Valeter Business page — notes for Dean (backend / product wiring)

**Status:** The in-app screen (`business-affiliations`) has been **removed**. This document remains as a **product/backend reference** for the flows described below if you reintroduce them elsewhere.

**Former route:** `/valeter/profile/business-affiliations` (file deleted).

**Audience (original design):** Valeters managing how they show up (sole trader vs company) and browsing partner wash **sites** on a map, plus **inbox** (invites) and **sent** (outgoing requests).

---

## What the screen is supposed to do

1. **Map + search** — Load active rows from `car_wash_locations`, join org names from `organizations`, show pins in **Sites** mode. Search filters the list client-side.
2. **Business identity (sheet top)** — Show **trading as** name and whether the valeter is a **sole trader** or **limited company** valeter.
3. **Sole trader toggle** — Persists `users.is_individual_valeter` via Supabase `update`. If `users` read fails, UI shows a notice and updates are blocked with an alert.
4. **Inbox** — Intended to show pending `team_requests` where the query matches `valeter_email` or `valeter_id`. Accept/decline call `team_requests.update({ status })`. If the table or RLS blocks the client, a notice explains read-only mode.
5. **Sent / “Request to join”** — **Currently UI-only for outgoing joins:** tapping **Request to join** on a site card appends to **local React state** and shows an alert. It does **not** insert into Supabase or a join-requests table. **Dean:** wire this to a real API (e.g. insert into `team_requests` or a dedicated `location_join_requests` with `valeter_id`, `location_id`, `organization_id`, status).

---

## Sole trader vs limited company (intended behaviour)

| | Sole trader (`is_individual_valeter === true`) | Limited company (`false`) |
|---|--------------------------------|---------------------------|
| **Trading name** | Prefer profile / individual name; UI shows “Trading as” with the resolved display name. | Usually tied to `users.organization_id` → `organizations.name` when present. |
| **Registered company line** | Copy explains **not applicable** (individual). | Shows **Company on record** from loaded org name (or fallback). |
| **Map / joins / inbox** | Same UX: browse sites, inbox, sent. Business rules (e.g. who can approve a sole trader) are **backend**. | Same. |

**Open product questions for Dean**

- Should toggling sole trader **clear or keep** `organization_id`?
- Should sole traders be **blocked** from certain org-only invites?
- **Trading name** editing: is it only on main profile, or duplicated here?

---

## Data sources (current client)

- `users`: `organization_id`, `is_individual_valeter` (and profile read errors drive `usersTableAvailable` / notice).
- `organizations`: name + metadata when `organization_id` exists.
- `car_wash_locations`: public active locations for discovery.
- `team_requests`: inbox + accept/decline; optional/outgoing flow **not** implemented for cards.

---

## Navigation (current UI)

- **Menu (sidebar)** sets `sheetTab`: **`locations`** (map + site cards), **`requests`** (incoming `team_requests` invites as swipe cards), **`valeters`** (outgoing join requests as swipe cards). Search, sync, recenter, account (trading name, sole trader), and notices live in the sidebar. **Right rail removed** — everything is menu-driven.
- **Bottom sheet** shows a short mode label + dot indicator and **horizontal cards only** (minimal text).

---

## Files / components touched

- Screen: removed (was `app/valeter/profile/business-affiliations.tsx`)
- Sheet background: `src/components/shared/BusinessSheetBackground.tsx`

If you change schema or RLS, update the screen notices and error handling so valeters get a clear message instead of silent failure.
