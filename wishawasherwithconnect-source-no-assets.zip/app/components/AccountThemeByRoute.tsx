import React, { useMemo } from 'react';
import { usePathname } from 'expo-router';
import type { AccountType } from '../../src/constants/accountThemes';
import { AccountThemeProvider } from '../../src/components/shared/AccountThemeProvider';

export default function AccountThemeByRoute({ children }: Readonly<{ children: React.ReactNode }>) {
  const pathname = usePathname();
  const accountType: AccountType = useMemo(() => {
    if (pathname.includes('/valeter/')) return 'valeter';
    if (pathname.includes('/business/')) return 'business';
    return 'valeter';
  }, [pathname]);

  return <AccountThemeProvider accountType={accountType}>{children}</AccountThemeProvider>;
}
