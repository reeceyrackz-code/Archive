import React from 'react';
import { View, StyleSheet } from 'react-native';
import { usePathname } from 'expo-router';
import NavigationTab from './NavigationTab';
import { useAuth } from '../../src/providers/enhanced-auth-context';

// Routes where tab bar should be hidden
const HIDDEN_ROUTES = new Set([
  '/auth/login',
  '/auth/signup',
  '/auth/logout-test',
  '/onboarding',
  '/valeter/valeter-onboarding',
  '/organisation/organization-onboarding',
  '/business/onboarding',
]);

type NavTabWrapperProps = Readonly<{ children: React.ReactNode }>;

export default function NavTabWrapper({ children }: NavTabWrapperProps) {
  const pathname = usePathname();
  const { user, isLoading, authReady } = useAuth();

  const shouldHideTab = (): boolean => {
    const currentPath = pathname || '';
    if (currentPath === '/business/dashboard') return false;

    const isBusinessRoute =
      currentPath.includes('/business/') ||
      currentPath.includes('/organisation/') ||
      currentPath.includes('/organization/');

    // Keep tab hidden while auth/app bootstrap is still showing loading screens.
    if (isLoading || !authReady) return true;

    if (HIDDEN_ROUTES.has(currentPath)) return true;
    if (currentPath.includes('/auth/') || currentPath.includes('onboarding')) return true;

    if (
      currentPath.includes('/booking/location') ||
      currentPath.includes('/booking/tracking') ||
      currentPath.includes('/bookings/tracking') ||
      currentPath === '/valeter/jobs' ||
      currentPath.includes('/jobs/tracking') ||
      currentPath.includes('/jobs/accept') ||
      currentPath.includes('/chat')
    ) {
      return true;
    }

    if (!user) return !isBusinessRoute;
    return false;
  };

  const hideTab = shouldHideTab();

  return (
    <View style={styles.container} pointerEvents="box-none">
      <View style={styles.contentWrapper} pointerEvents="box-none">
        {children}
      </View>

      {!hideTab && <NavigationTab />}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // ✅ don’t paint a background here (let each screen own the background)
    backgroundColor: 'transparent',
  },
  contentWrapper: {
    flex: 1,
    backgroundColor: 'transparent',
    overflow: 'hidden',
  },
});
