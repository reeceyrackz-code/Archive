import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Linking,
  ActivityIndicator,
  Modal,
  Pressable,
  Animated,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useLocalSearchParams } from 'expo-router';
import { ChromeGlyph as Ionicons } from '../../src/components/shared/ChromeGlyph';

import { useAuth } from '../../src/providers/enhanced-auth-context';
import {
  businessOnboardingService,
  BusinessOnboardingStatus,
  type StripeConnectStatus,
} from '../../src/services/businessOnboardingService';
import { stripeConnectService } from '../../src/services/stripeConnectService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import GradientIconBox from '../../src/components/shared/GradientIconBox';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';
import LoadingScreen from '../../src/components/LoadingScreen';

const LIGHT_TEXT = '#F9FAFB';
const MUTED = 'rgba(249,250,251,0.72)';

function formatStripeStatus(status: StripeConnectStatus | undefined): string {
  switch (status) {
    case 'not_started':
      return 'Not started';
    case 'in_progress':
      return 'In progress';
    case 'completed':
      return 'Connected';
    case 'restricted':
      return 'Restricted';
    case 'rejected':
      return 'Rejected';
    default:
      return 'Unknown';
  }
}

function shortenAccountId(id: string | null | undefined): string {
  if (!id || id.length < 12) return id || 'Not linked yet';
  return `${id.slice(0, 10)}…${id.slice(-4)}`;
}

export default function BusinessStripeConnectScreen() {
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const insets = useSafeAreaInsets();
  const { theme: businessTheme } = useAccountTheme();
  const primary = businessTheme.primary;
  const scrollY = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [status, setStatus] = useState<BusinessOnboardingStatus | null>(null);
  const [dialogVisible, setDialogVisible] = useState(false);
  const [dialogTitle, setDialogTitle] = useState('');
  const [dialogMessage, setDialogMessage] = useState('');
  const [dialogType, setDialogType] = useState<'error' | 'warning' | 'info'>('info');
  const [dialogActions, setDialogActions] = useState<Array<{ label: string; kind?: 'primary' | 'secondary' | 'danger'; onPress?: () => void }>>([]);

  const openDialog = (
    title: string,
    message: string,
    type: 'error' | 'warning' | 'info' = 'info',
    actions: Array<{ label: string; kind?: 'primary' | 'secondary' | 'danger'; onPress?: () => void }> = [{ label: 'Close', kind: 'primary' }]
  ) => {
    setDialogTitle(title);
    setDialogMessage(message);
    setDialogType(type);
    setDialogActions(actions);
    setDialogVisible(true);
  };

  const load = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      const next = await businessOnboardingService.getStatus(user.id);
      setStatus(next);
    } catch (error: any) {
      openDialog('Unable to load Stripe setup', error?.message || 'Failed to load Stripe Connect status.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, [user?.id]);

  useEffect(() => {
    if (!params?.stripe_return && !params?.stripe_refresh) return;
    void handleCheckStatus(true);
  }, [params?.stripe_return, params?.stripe_refresh]);

  const startConnect = async () => {
    if (saving) return;
    try {
      await hapticFeedback('light');
      setSaving(true);
      if (user?.id) {
        await businessOnboardingService.setStripeSkipForNow(user.id, false);
      }
      const { url } = await stripeConnectService.createOnboardingLink();
      await Linking.openURL(url);
    } catch (error: any) {
      openDialog('Unable to start Stripe Connect', error?.message || 'Failed to start Stripe Connect.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleCheckStatus = async (silent = false) => {
    if (saving) return;
    try {
      await hapticFeedback('light');
      setSaving(true);
      const result = await stripeConnectService.syncStatusFromStripe();
      await load();
      if (result.stripeConnectStatus === 'completed') {
        router.replace('/business/dashboard' as any);
        return;
      }
      if (!silent) {
        openDialog(
          'Stripe setup still incomplete',
          'Finish all required steps in Stripe, then return here and tap “Refresh status”.',
          'warning'
        );
      }
    } catch (error: any) {
      openDialog('Unable to check Stripe status', error?.message || 'Failed to check Stripe status.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleSkipForNow = async () => {
    if (!user?.id || saving) return;

    openDialog(
      'Skip Stripe for now?',
      'Some business features may stay limited until Connect is complete. Payouts through the platform can be delayed.',
      'warning',
      [
        { label: 'Cancel', kind: 'secondary' },
        {
          label: 'Skip for now',
          kind: 'primary',
          onPress: async () => {
            try {
              setSaving(true);
              await businessOnboardingService.setStripeSkipForNow(user.id, true);
              router.replace('/business/dashboard' as any);
            } catch (error: any) {
              openDialog('Unable to skip right now', error?.message || 'Failed to update Stripe onboarding status.', 'error');
            } finally {
              setSaving(false);
            }
          },
        },
      ]
    );
  };

  if (loading) {
    return <LoadingScreen message="Loading payout setup…" />;
  }

  const stripeState = status?.stripeConnectStatus ?? 'not_started';
  const isComplete = stripeState === 'completed';

  return (
    <View style={styles.flex}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />

      <SafeAreaView style={styles.flex} edges={['top', 'left', 'right']}>
        <AppHeader
          title="Stripe Connect"
          accountType="business"
          scrollY={scrollY}
          enableScrollAnimation
          rightAction={
            <TouchableOpacity
              onPress={async () => {
                await hapticFeedback('light');
                router.push('/business/stripe-connect-test' as any);
              }}
              hitSlop={12}
              accessibilityLabel="Advanced Stripe tools"
            >
              <Ionicons name="build-outline" size={22} color={LIGHT_TEXT} />
            </TouchableOpacity>
          }
        />

        <Animated.ScrollView
          style={styles.scroll}
          showsVerticalScrollIndicator={false}
          onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
          scrollEventThrottle={16}
          contentContainerStyle={[
            styles.scrollInner,
            {
              paddingTop: HEADER_CONTENT_OFFSET,
              paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 200,
            },
          ]}
        >
          <GlassCard style={styles.heroCard} accountType="business">
            <View style={styles.heroTop}>
              <GradientIconBox icon="card-outline" preset="emerald" boxSize={44} size={22} />
              <View style={styles.heroBadge}>
                <Ionicons name="flash-outline" size={14} color={primary} />
                <Text style={[styles.heroBadgeText, { color: primary }]}>Payouts</Text>
              </View>
            </View>
            <Text style={styles.heroTitle}>Get paid on the platform</Text>
            <Text style={styles.heroSubtitle}>
              Connect Stripe so customer payments can reach your business bank account securely.
            </Text>
          </GlassCard>

          <GlassCard style={styles.sectionCard} accountType="business">
            <Text style={styles.sectionHeading}>Current status</Text>
            <View style={styles.statusRow}>
              <Text style={styles.metaLabel}>Connection</Text>
              <View style={[styles.statusPill, isComplete && { borderColor: `${primary}55`, backgroundColor: `${primary}18` }]}>
                <View style={[styles.statusDot, { backgroundColor: isComplete ? '#34D399' : '#FBBF24' }]} />
                <Text style={[styles.statusPillText, { color: LIGHT_TEXT }]}>{formatStripeStatus(stripeState)}</Text>
              </View>
            </View>
            <View style={styles.accountBlock}>
              <Text style={styles.metaLabel}>Stripe account</Text>
              <Text style={styles.accountValue} numberOfLines={1}>
                {shortenAccountId(status?.stripeAccountId)}
              </Text>
            </View>
          </GlassCard>

          <GlassCard style={styles.sectionCard} accountType="business">
            <Text style={styles.sectionHeading}>How it works</Text>
            {[
              'Open Stripe’s secure form and add business, identity, and bank details.',
              'When Stripe sends you back to the app, open this screen again.',
              'Tap “Refresh status” to confirm payouts are enabled.',
            ].map((line, i) => (
              <View key={i} style={styles.stepRow}>
                <View style={[styles.stepNum, { borderColor: `${primary}44`, backgroundColor: `${primary}14` }]}>
                  <Text style={[styles.stepNumText, { color: primary }]}>{i + 1}</Text>
                </View>
                <Text style={styles.stepBody}>{line}</Text>
              </View>
            ))}
          </GlassCard>

          <View style={styles.noticeRow}>
            <Ionicons name="information-circle-outline" size={22} color={primary} />
            <View style={{ flex: 1 }}>
              <Text style={styles.noticeTitle}>Before you start</Text>
              <Text style={styles.noticeBody}>
                Stripe decides what to verify based on your business. Have company and banking information ready.
              </Text>
            </View>
          </View>
        </Animated.ScrollView>

        <View style={[styles.footer, { paddingBottom: 12 + insets.bottom }]}>
          <TouchableOpacity
            style={[styles.primaryBtn, { backgroundColor: primary }]}
            onPress={startConnect}
            disabled={saving}
            activeOpacity={0.9}
          >
            {saving ? <ActivityIndicator color="#0A1929" /> : <Text style={styles.primaryBtnText}>Continue with Stripe</Text>}
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.secondaryBtn, { borderColor: `${primary}40` }]}
            onPress={() => handleCheckStatus(false)}
            disabled={saving}
            activeOpacity={0.9}
          >
            <Ionicons name="refresh-outline" size={18} color={LIGHT_TEXT} style={{ marginRight: 8 }} />
            <Text style={styles.secondaryBtnText}>Refresh status</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.tertiaryBtn} onPress={handleSkipForNow} disabled={saving} activeOpacity={0.85}>
            <Text style={styles.tertiaryBtnText}>Skip for now</Text>
          </TouchableOpacity>

          <Text style={styles.footerHint}>After onboarding in the browser, return here and refresh status.</Text>
        </View>

        <Modal visible={dialogVisible} transparent animationType="fade" onRequestClose={() => setDialogVisible(false)}>
          <Pressable style={styles.modalOverlay} onPress={() => setDialogVisible(false)}>
            <View style={styles.modalCard}>
              <View
                style={[
                  styles.modalIconWrap,
                  dialogType === 'error'
                    ? styles.modalIconError
                    : dialogType === 'warning'
                      ? styles.modalIconWarning
                      : styles.modalIconInfo,
                ]}
              >
                <Ionicons
                  name={dialogType === 'error' ? 'close-circle-outline' : dialogType === 'warning' ? 'alert-circle-outline' : 'information-circle-outline'}
                  size={24}
                  color="#FFFFFF"
                />
              </View>
              <Text style={styles.modalTitle}>{dialogTitle}</Text>
              <Text style={styles.modalMessage}>{dialogMessage}</Text>

              <View style={styles.modalActions}>
                {dialogActions.map((action, index) => (
                  <TouchableOpacity
                    key={`${action.label}-${index}`}
                    style={[
                      styles.modalButton,
                      action.kind === 'secondary' && styles.modalButtonSecondary,
                      action.kind === 'danger' && styles.modalButtonDanger,
                      (!action.kind || action.kind === 'primary') && [styles.modalButtonPrimary, { backgroundColor: primary }],
                    ]}
                    onPress={() => {
                      setDialogVisible(false);
                      action.onPress?.();
                    }}
                    activeOpacity={0.85}
                  >
                    <Text
                      style={[
                        styles.modalButtonText,
                        action.kind === 'secondary' && styles.modalButtonTextSecondary,
                        action.kind === 'danger' && styles.modalButtonTextDanger,
                        (!action.kind || action.kind === 'primary') && styles.modalButtonTextPrimary,
                      ]}
                    >
                      {action.label}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          </Pressable>
        </Modal>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  scroll: { flex: 1 },
  scrollInner: {
    paddingHorizontal: 20,
  },
  loadingWrap: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 14,
    paddingHorizontal: 32,
  },
  loadingText: {
    fontSize: 15,
    textAlign: 'center',
  },
  heroCard: {
    padding: 20,
    marginBottom: 14,
  },
  heroTop: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  heroBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  heroBadgeText: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.6,
    textTransform: 'uppercase',
  },
  heroTitle: {
    color: LIGHT_TEXT,
    fontSize: 22,
    fontWeight: '800',
    lineHeight: 28,
    marginBottom: 8,
  },
  heroSubtitle: {
    color: MUTED,
    fontSize: 15,
    lineHeight: 22,
  },
  sectionCard: {
    padding: 18,
    marginBottom: 14,
  },
  sectionHeading: {
    color: LIGHT_TEXT,
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 14,
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 14,
    gap: 12,
  },
  metaLabel: {
    color: 'rgba(249,250,251,0.55)',
    fontSize: 12,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.6,
  },
  statusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 999,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    maxWidth: '62%',
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  statusPillText: {
    fontSize: 13,
    fontWeight: '800',
    flex: 1,
  },
  accountBlock: {
    padding: 14,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  accountValue: {
    color: LIGHT_TEXT,
    fontSize: 14,
    fontWeight: '700',
    marginTop: 6,
  },
  stepRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 12,
  },
  stepNum: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    marginTop: 1,
  },
  stepNumText: {
    fontSize: 13,
    fontWeight: '800',
  },
  stepBody: {
    flex: 1,
    color: 'rgba(255,255,255,0.92)',
    fontSize: 14,
    lineHeight: 21,
  },
  noticeRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    padding: 16,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(255,255,255,0.1)',
    marginTop: 4,
  },
  noticeTitle: {
    color: LIGHT_TEXT,
    fontSize: 14,
    fontWeight: '800',
    marginBottom: 4,
  },
  noticeBody: {
    color: MUTED,
    fontSize: 13,
    lineHeight: 19,
  },
  footer: {
    paddingTop: 12,
    paddingHorizontal: 16,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(255,255,255,0.12)',
    backgroundColor: 'rgba(5,13,20,0.92)',
  },
  primaryBtn: {
    borderRadius: 14,
    minHeight: 52,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
  },
  primaryBtnText: {
    color: '#0A1929',
    fontSize: 15,
    fontWeight: '800',
  },
  secondaryBtn: {
    borderRadius: 14,
    minHeight: 50,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    borderWidth: 1,
    backgroundColor: 'rgba(255,255,255,0.06)',
    marginBottom: 8,
  },
  secondaryBtnText: {
    color: LIGHT_TEXT,
    fontWeight: '700',
    fontSize: 15,
  },
  tertiaryBtn: {
    borderRadius: 14,
    minHeight: 46,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 4,
  },
  tertiaryBtnText: {
    color: 'rgba(249,250,251,0.65)',
    fontWeight: '600',
    fontSize: 14,
  },
  footerHint: {
    color: 'rgba(249,250,251,0.45)',
    fontSize: 12,
    marginTop: 10,
    lineHeight: 17,
    textAlign: 'center',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(3,10,18,0.75)',
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  modalCard: {
    borderRadius: 22,
    padding: 22,
    backgroundColor: '#0D1D2E',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  modalIconWrap: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 14,
  },
  modalIconError: {
    backgroundColor: 'rgba(239,68,68,0.75)',
  },
  modalIconWarning: {
    backgroundColor: 'rgba(245,158,11,0.75)',
  },
  modalIconInfo: {
    backgroundColor: 'rgba(59,130,246,0.75)',
  },
  modalTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 8,
  },
  modalMessage: {
    color: '#C7DCEA',
    fontSize: 15,
    lineHeight: 22,
  },
  modalActions: {
    marginTop: 20,
    gap: 10,
  },
  modalButton: {
    minHeight: 50,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 16,
  },
  modalButtonPrimary: {},
  modalButtonSecondary: {
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  modalButtonDanger: {
    backgroundColor: 'rgba(239,68,68,0.16)',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.28)',
  },
  modalButtonText: {
    fontSize: 14,
    fontWeight: '800',
  },
  modalButtonTextPrimary: {
    color: '#0A1929',
  },
  modalButtonTextSecondary: {
    color: '#FFFFFF',
  },
  modalButtonTextDanger: {
    color: '#FFFFFF',
  },
});
