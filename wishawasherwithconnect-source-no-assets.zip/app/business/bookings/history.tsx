/**
 * Redirect: History was renamed to Activity. Kept for backwards compatibility.
 */
import { useEffect } from 'react';
import { router } from 'expo-router';

export default function HistoryRedirect() {
  useEffect(() => {
    router.replace('/business/bookings/activity');
  }, []);
  return null;
}
