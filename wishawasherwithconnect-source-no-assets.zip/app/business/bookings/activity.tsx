import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  Platform,
  Alert,
  Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import { router } from 'expo-router';
import MapView, { Marker, PROVIDER_DEFAULT } from 'react-native-maps';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_HEIGHT } from '../../../src/components/shared/AppHeader';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import StatusBadge from '../../../src/components/booking/StatusBadge';
import { colors } from '../../../src/constants/colors';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { loadHistoryBookingsForOrganization, type BusinessHistoryBooking } from '../../../src/services/BusinessBookingsService';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import { SCREEN_PADDING_H, SECTION_GAP, CARD_GAP } from '../../../src/constants/premiumTokens';
import DefaultLoadingSkeleton from '../../../src/components/shared/DefaultLoadingSkeleton';
import EmptyState from '../../../src/components/shared/EmptyState';

const SKY = colors.SKY;
const CARD_MAP_HEIGHT = 112;

type ActivityBooking = BusinessHistoryBooking;

export default function ActivityPage() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme: businessTheme } = useAccountTheme();
  const [bookings, setBookings] = useState<ActivityBooking[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [showAll, setShowAll] = useState(false);
  const [failedAvatarIds, setFailedAvatarIds] = useState<Record<string, boolean>>({});

  const organizationId = user?.organizationId ?? null;
  const isOrgUser = ['organization', 'business'].includes((user?.userType ?? '').toLowerCase());

  const completed = bookings.filter((b) => b.status === 'completed');
  const filtered = completed;

  const MAX_CARDS = 5;
  const displayed = showAll ? filtered : filtered.slice(0, MAX_CARDS);
  const hasMore = filtered.length > MAX_CARDS;

  const loadActivity = useCallback(async (isRefresh = false) => {
    if (!organizationId) {
      setLoading(false);
      setRefreshing(false);
      return;
    }
    try {
      if (!isRefresh) setLoading(true);
      else setRefreshing(true);
      const LOAD_TIMEOUT_MS = 15000;
      const list = await Promise.race([
        loadHistoryBookingsForOrganization(organizationId),
        new Promise<ActivityBooking[]>((_, reject) =>
          setTimeout(() => reject(new Error('Load timed out')), LOAD_TIMEOUT_MS)
        ),
      ]);
      setBookings(list);
    } catch (e: any) {
      console.error('[Activity] load error', e);
      setBookings([]);
      if (!isRefresh) {
        Alert.alert('Couldn’t load activity', e?.message === 'Load timed out' ? 'Request took too long. Pull down to try again.' : 'Pull down to try again.');
      }
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [organizationId]);

  useEffect(() => {
    if (isOrgUser && organizationId) {
      loadActivity(false);
    } else {
      setLoading(false);
    }
  }, [organizationId, isOrgUser, loadActivity]);

  const formatDate = (booking: ActivityBooking) => {
    const at = booking.scheduled_at;
    return at
      ? new Date(at).toLocaleString('en-GB', {
          weekday: 'short',
          day: 'numeric',
          month: 'short',
          hour: '2-digit',
          minute: '2-digit',
        })
      : new Date(booking.created_at).toLocaleDateString('en-GB', {
          weekday: 'short',
          day: 'numeric',
          month: 'short',
        });
  };

  const hasCoords = (b: ActivityBooking) =>
    b.location_lat != null &&
    b.location_lng != null &&
    Number.isFinite(b.location_lat) &&
    Number.isFinite(b.location_lng);

  const renderCard = (booking: ActivityBooking) => {
    const coords = hasCoords(booking);
    const region = coords
      ? {
          latitude: booking.location_lat!,
          longitude: booking.location_lng!,
          latitudeDelta: 0.003,
          longitudeDelta: 0.003,
        }
      : {
          latitude: 51.5074,
          longitude: -0.1278,
          latitudeDelta: 0.05,
          longitudeDelta: 0.05,
        };
    const isCompleted = booking.status === 'completed';
    const photoUri = booking.customer_profile_picture;
    const showAvatarImage = !!photoUri && !failedAvatarIds[booking.id];
    const initial = (booking.customer_name || '?').trim().charAt(0).toUpperCase() || '?';
    const valeterInitial = (booking.assigned_valeter_name || '?').trim().charAt(0).toUpperCase() || '?';

    return (
      <TouchableOpacity
        key={booking.id}
        activeOpacity={0.88}
        onPress={async () => {
          await hapticFeedback('light');
          router.push({
            pathname: '/business/bookings/[id]',
            params: { id: booking.id },
          } as any);
        }}
        style={styles.card}
      >
        <View style={styles.cardInner}>
          <View style={styles.cardHeader}>
            <View style={styles.avatarWrap}>
              {showAvatarImage && photoUri ? (
                <Image
                  source={{ uri: photoUri }}
                  style={styles.avatarImage}
                  resizeMode="cover"
                  onError={() =>
                    setFailedAvatarIds((prev) => (prev[booking.id] ? prev : { ...prev, [booking.id]: true }))
                  }
                />
              ) : (
                <LinearGradient
                  colors={
                    isCompleted ? [SKY + '40', SKY + '18'] : ['rgba(248,113,113,0.35)', 'rgba(248,113,113,0.12)']
                  }
                  style={styles.avatarGrad}
                >
                  <Text style={styles.avatarLetter}>{initial}</Text>
                </LinearGradient>
              )}
            </View>
            <View style={styles.cardHeaderText}>
              <Text style={styles.customerName} numberOfLines={1}>
                {booking.customer_name}
              </Text>
              <StatusBadge status={booking.status as any} size="small" />
            </View>
          </View>

          <View style={styles.infoBlock}>
            <View style={styles.infoRow}>
              <Ionicons name="briefcase-outline" size={16} color={SKY} />
              <Text style={styles.infoText} numberOfLines={1}>
                {getServiceDisplayName(booking.service_type, booking.service_name)}
              </Text>
            </View>
            <View style={styles.infoRow}>
              <Ionicons name="calendar-outline" size={16} color="rgba(249,250,251,0.7)" />
              <Text style={styles.infoText}>{formatDate(booking)}</Text>
            </View>
            {booking.location_address ? (
              <View style={styles.infoRow}>
                <Ionicons name="location-outline" size={16} color="rgba(249,250,251,0.7)" />
                <Text style={styles.infoText} numberOfLines={1}>
                  {booking.location_address.split(',')[0]}
                </Text>
              </View>
            ) : (
              <View style={styles.infoRow}>
                <Ionicons name="location-outline" size={16} color="rgba(148,163,184,0.5)" />
                <Text style={styles.infoTextMuted}>Location not recorded</Text>
              </View>
            )}
            {booking.assigned_valeter_name ? (
              <View style={styles.infoRow}>
                {booking.assigned_valeter_photo ? (
                  <Image source={{ uri: booking.assigned_valeter_photo }} style={styles.valeterAvatar} resizeMode="cover" />
                ) : (
                  <View style={styles.valeterAvatarFallback}>
                    <Text style={styles.valeterAvatarLetter}>{valeterInitial}</Text>
                  </View>
                )}
                <Text style={styles.infoText} numberOfLines={1}>
                  Car Care Pro: {booking.assigned_valeter_name}
                </Text>
              </View>
            ) : null}
          </View>

          <View style={styles.mapWrap}>
            {coords ? (
              <MapView
                style={styles.map}
                region={region}
                scrollEnabled={false}
                zoomEnabled={false}
                pitchEnabled={false}
                rotateEnabled={false}
                provider={Platform.OS === 'ios' ? PROVIDER_DEFAULT : undefined}
                mapType="standard"
              >
                <Marker
                  coordinate={{
                    latitude: booking.location_lat!,
                    longitude: booking.location_lng!,
                  }}
                  anchor={{ x: 0.5, y: 0.5 }}
                >
                  <View style={styles.mapPin}>
                    <Ionicons name="location" size={16} color={SKY} />
                  </View>
                </Marker>
              </MapView>
            ) : (
              <View style={styles.mapPlaceholder}>
                <Ionicons name="map-outline" size={32} color="rgba(148,163,184,0.4)" />
                <Text style={styles.mapPlaceholderText}>No map data</Text>
              </View>
            )}
          </View>

          <View style={styles.cardFooter}>
            <Text style={styles.viewDetails}>View details</Text>
            <Ionicons name="chevron-forward" size={18} color={SKY} />
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
      <LinearGradient
        colors={businessTheme.background}
        style={StyleSheet.absoluteFill}
      />
      <BubbleBackground accountType="business" />
      <AppHeader
        title="Activity"
        subtitle={
          !loading && completed.length > 0
            ? `${completed.length} completed`
            : undefined
        }
        accountType="business"
        leftAction={
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              router.back();
            }}
            style={styles.headerBtn}
          >
            <Ionicons name="arrow-back" size={24} color={SKY} />
          </TouchableOpacity>
        }
        rightAction={
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              loadActivity(true);
            }}
            style={styles.headerBtnCircle}
          >
            <Ionicons name="refresh-outline" size={20} color={SKY} />
          </TouchableOpacity>
        }
      />
      <View
        style={[
          styles.contentWrap,
          {
            paddingTop: insets.top + HEADER_HEIGHT + 0,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + SECTION_GAP,
          },
        ]}
      >
        {loading ? (
          <View style={styles.loadingArea}>
            <DefaultLoadingSkeleton message="Loading activity…" variant="rich" />
          </View>
        ) : bookings.length === 0 ? (
          <ScrollView
            contentContainerStyle={styles.centeredScroll}
            refreshControl={
              <RefreshControl
                refreshing={refreshing}
                onRefresh={() => loadActivity(true)}
                tintColor={SKY}
              />
            }
          >
            <EmptyState
              icon="time-outline"
              title="No completed jobs yet"
              subtitle="Completed jobs will appear here"
              iconColor={SKY}
            />
          </ScrollView>
        ) : (
          <>
            {filtered.length === 0 ? (
              <EmptyState
                icon="checkmark-circle-outline"
                title="No completed jobs"
                subtitle="Completed jobs will show here"
                iconColor={SKY}
              />
            ) : (
              <ScrollView
                contentContainerStyle={styles.listContent}
                showsVerticalScrollIndicator={false}
                refreshControl={
                  <RefreshControl
                    refreshing={refreshing}
                    onRefresh={() => loadActivity(true)}
                    tintColor={SKY}
                  />
                }
              >
                {displayed.map((b) => renderCard(b))}
                {hasMore && (
                  <TouchableOpacity
                    onPress={async () => {
                      await hapticFeedback('light');
                      setShowAll(true);
                    }}
                    style={styles.viewAllWrap}
                    activeOpacity={0.8}
                  >
                    <Text style={styles.viewAllText}>View all</Text>
                    <Ionicons name="list" size={20} color={SKY} />
                  </TouchableOpacity>
                )}
                {showAll && hasMore && (
                  <TouchableOpacity
                    onPress={async () => {
                      await hapticFeedback('light');
                      setShowAll(false);
                    }}
                    style={styles.viewAllWrap}
                    activeOpacity={0.8}
                  >
                    <Text style={styles.viewAllText}>Show less</Text>
                    <Ionicons name="chevron-up" size={20} color={SKY} />
                  </TouchableOpacity>
                )}
              </ScrollView>
            )}
          </>
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  contentWrap: { flex: 1 },
  loadingArea: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: SCREEN_PADDING_H,
  },
  headerBtn: { padding: 8, marginLeft: 4 },
  headerBtnCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.18)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.35)',
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 14,
    paddingHorizontal: SCREEN_PADDING_H * 1.5,
  },
  centeredScroll: {
    flexGrow: 1,
    justifyContent: 'center',
    paddingHorizontal: SCREEN_PADDING_H,
  },
  loadingText: { color: SKY, fontSize: 15, fontWeight: '600' },
  emptyIconWrap: {
    width: 96,
    height: 96,
    borderRadius: 48,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 6,
    textAlign: 'center',
  },
  emptySubtitle: {
    color: 'rgba(248,250,252,0.65)',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
  listContent: {
    paddingHorizontal: SCREEN_PADDING_H,
    paddingTop: SECTION_GAP,
    paddingBottom: SECTION_GAP,
    gap: CARD_GAP,
  },
  card: {
    borderRadius: 20,
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 16,
    elevation: 6,
  },
  cardInner: { padding: 18, paddingBottom: 14 },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 14,
  },
  avatarWrap: {
    width: 48,
    height: 48,
    borderRadius: 14,
    overflow: 'hidden',
    marginRight: 12,
  },
  avatarGrad: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarImage: {
    width: '100%',
    height: '100%',
  },
  avatarLetter: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
  },
  cardHeaderText: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    minWidth: 0,
    gap: 10,
  },
  customerName: {
    fontSize: 17,
    fontWeight: '800',
    color: '#F9FAFB',
    flex: 1,
  },
  infoBlock: { gap: 8, marginBottom: 14 },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  infoText: {
    fontSize: 14,
    color: 'rgba(249,250,251,0.9)',
    fontWeight: '500',
    flex: 1,
  },
  infoTextMuted: {
    fontSize: 14,
    color: 'rgba(148,163,184,0.7)',
    fontWeight: '500',
    fontStyle: 'italic',
  },
  valeterAvatar: {
    width: 18,
    height: 18,
    borderRadius: 9,
  },
  valeterAvatarFallback: {
    width: 18,
    height: 18,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(135,206,235,0.24)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.38)',
  },
  valeterAvatarLetter: {
    color: '#F9FAFB',
    fontSize: 9,
    fontWeight: '800',
  },
  mapWrap: {
    height: CARD_MAP_HEIGHT,
    width: '100%',
    borderRadius: 14,
    overflow: 'hidden',
    backgroundColor: 'rgba(15,23,42,0.6)',
    marginBottom: 14,
  },
  map: {
    width: '100%',
    height: '100%',
    borderRadius: 14,
  },
  mapPin: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(15,23,42,0.92)',
    borderWidth: 2,
    borderColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
  },
  mapPlaceholder: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
  },
  mapPlaceholderText: {
    fontSize: 12,
    color: 'rgba(148,163,184,0.6)',
    fontWeight: '500',
  },
  cardFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    gap: 6,
  },
  viewDetails: {
    fontSize: 14,
    fontWeight: '700',
    color: SKY,
  },
  viewAllWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    paddingHorizontal: 20,
    marginTop: 8,
    borderRadius: 16,
    backgroundColor: 'rgba(135,206,235,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  viewAllText: {
    fontSize: 16,
    fontWeight: '700',
    color: SKY,
  },
});
