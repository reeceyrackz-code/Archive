import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import GlassCard from '../../../src/components/booking/GlassCard';
import { colors } from '../../../src/constants/colors';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import LoadingScreen from '../../../src/components/LoadingScreen';
import EmptyState from '../../../src/components/shared/EmptyState';

const BG = colors.BG;
const SKY = colors.SKY;

interface ValeterRequest {
  id: string;
  valeter_id: string;
  valeter_name: string;
  valeter_email: string;
  requested_location: string | null;
  requested_role: string;
  status: string;
  created_at: string;
}

export default function ValeterRequests() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme: businessTheme } = useAccountTheme();
  const [requests, setRequests] = useState<ValeterRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [requestsAvailable, setRequestsAvailable] = useState(true);
  const [actionLoadingId, setActionLoadingId] = useState<string | null>(null);
  const [screenNotice, setScreenNotice] = useState<string | null>(null);

  const loadRequests = useCallback(async (isRefresh = false) => {
    if (!user?.id) return;
    try {
      if (isRefresh) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }
      const organizationId = user.organizationId;
      if (!organizationId) {
        setRequests([]);
        setScreenNotice('No organization is linked to this account yet.');
        return;
      }
      const { data, error } = await supabase
        .from('team_requests')
        .select('id, valeter_id, valeter_name, valeter_email, location_name, requested_role, status, created_at')
        .eq('organization_id', organizationId)
        .eq('status', 'pending')
        .order('created_at', { ascending: false });

      if (error) {
        setRequests([]);
        setRequestsAvailable(false);
        setScreenNotice('Team requests are not available right now. Ask your dev to enable table/RLS access.');
        return;
      }
      setRequestsAvailable(true);
      setScreenNotice(null);
      const mapped = (data || []).map((row: any) => ({
        id: String(row.id),
        valeter_id: String(row.valeter_id ?? ''),
        valeter_name: String(row.valeter_name ?? 'Car Care Pro'),
        valeter_email: String(row.valeter_email ?? 'No email'),
        requested_location: typeof row.location_name === 'string' ? row.location_name : null,
        requested_role: typeof row.requested_role === 'string' ? row.requested_role : 'valeter',
        status: String(row.status ?? 'pending'),
        created_at: String(row.created_at ?? new Date().toISOString()),
      })) as ValeterRequest[];
      setRequests(mapped);
    } catch (error) {
      console.error('Error loading requests:', error);
      Alert.alert('Couldn’t load requests', 'Pull down to try again.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [user?.id]);

  useEffect(() => {
    if (user?.id) {
      loadRequests(false);
    } else {
      setLoading(false);
    }
  }, [user?.id, loadRequests]);

  const handleApprove = async (requestId: string) => {
    try {
      await hapticFeedback('medium');
      if (!requestsAvailable) {
        Alert.alert('Unavailable', 'Request actions are currently disabled.');
        return;
      }
      setActionLoadingId(requestId);
      Alert.alert(
        'Approval pending backend',
        'UI is ready, but approving requests requires backend workflow wiring.'
      );
    } catch (error: any) {
      console.error('Error approving request:', error);
      Alert.alert('Error', error.message || 'Failed to approve request');
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleReject = async (requestId: string) => {
    Alert.alert(
      'Reject Request',
      'Are you sure you want to reject this request?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Reject',
          style: 'destructive',
          onPress: () => {
            void (async () => {
              try {
                await hapticFeedback('medium');
                if (!requestsAvailable) {
                  Alert.alert('Unavailable', 'Request actions are currently disabled.');
                  return;
                }
                setActionLoadingId(requestId);
                Alert.alert(
                  'Rejection pending backend',
                  'UI is ready, but rejecting requests requires backend workflow wiring.'
                );
              } catch (error: any) {
                console.error('Error rejecting request:', error);
                Alert.alert('Error', error.message || 'Failed to reject request');
              } finally {
                setActionLoadingId(null);
              }
            })();
          },
        },
      ]
    );
  };

  if (loading) {
    return <LoadingScreen message="Loading requests…" />;
  }

  return (
    <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader title="Car Care Pro Requests" />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent, 
          { 
            paddingTop: HEADER_CONTENT_OFFSET,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20,
          }
        ]}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={() => {
              void loadRequests(true);
            }}
            tintColor={SKY}
          />
        }
      >
        {screenNotice ? (
          <View style={styles.noticeWrap}>
            <Ionicons name="information-circle-outline" size={16} color={SKY} />
            <Text style={styles.noticeText}>{screenNotice}</Text>
          </View>
        ) : null}
        {requests.length === 0 ? (
          <View style={styles.emptyWrap}>
            <EmptyState
              icon="person-add-outline"
              title="No requests yet"
              subtitle="When car care pros ask to join your team, they’ll appear here"
              iconColor={SKY}
            />
          </View>
        ) : (
          <View style={styles.requestsList}>
            {requests.map((request) => (
              <GlassCard
                key={request.id}
                style={styles.requestCard}
                borderColor="rgba(135,206,235,0.3)"
              >
                <View style={styles.requestHeader}>
                  <View style={styles.valeterAvatar}>
                    <Ionicons name="person" size={24} color={SKY} />
                  </View>
                  <View style={styles.requestInfo}>
                    <Text style={styles.valeterName}>{request.valeter_name}</Text>
                    <Text style={styles.valeterEmail}>{request.valeter_email}</Text>
                    {request.requested_location && (
                      <View style={styles.locationRow}>
                        <Ionicons name="location" size={14} color={SKY} />
                        <Text style={styles.locationText}>{request.requested_location}</Text>
                      </View>
                    )}
                    {Boolean(request.requested_role) && (
                      <View style={styles.roleRow}>
                        <Ionicons name="person-circle" size={14} color={SKY} />
                        <Text style={styles.roleText}>{request.requested_role}</Text>
                      </View>
                    )}
                  </View>
                </View>

                <View style={styles.requestActions}>
                  <TouchableOpacity
                    onPress={() => handleApprove(request.id)}
                    style={styles.approveButton}
                    disabled={!requestsAvailable || actionLoadingId === request.id}
                  >
                    <LinearGradient
                      colors={['#10B981', '#059669']}
                      style={styles.actionButtonGradient}
                    >
                      {actionLoadingId === request.id ? (
                        <ActivityIndicator color="#FFFFFF" />
                      ) : (
                        <>
                          <Ionicons name="checkmark" size={18} color="#FFFFFF" />
                          <Text style={styles.actionButtonText}>Approve</Text>
                        </>
                      )}
                    </LinearGradient>
                  </TouchableOpacity>

                  <TouchableOpacity
                    onPress={() => handleReject(request.id)}
                    style={styles.rejectButton}
                    disabled={!requestsAvailable || actionLoadingId === request.id}
                  >
                    <GlassCard
                      style={styles.actionButtonCard}
                      borderColor="rgba(239,68,68,0.3)"
                    >
                      {actionLoadingId === request.id ? (
                        <ActivityIndicator color="#EF4444" />
                      ) : (
                        <>
                          <Ionicons name="close" size={18} color="#EF4444" />
                          <Text style={styles.rejectButtonText}>Reject</Text>
                        </>
                      )}
                    </GlassCard>
                  </TouchableOpacity>
                </View>
              </GlassCard>
            ))}
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
    flexGrow: 1,
  },
  emptyWrap: {
    flex: 1,
    justifyContent: 'center',
    paddingVertical: 40,
  },
  noticeWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
    backgroundColor: 'rgba(30,58,138,0.18)',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
    marginBottom: 12,
  },
  noticeText: { color: 'rgba(249,250,251,0.85)', fontSize: 12, flex: 1 },
  emptyCard: {
    padding: 40,
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '700',
    marginTop: 20,
    marginBottom: 12,
  },
  emptyText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
  requestsList: {
    gap: 16,
  },
  requestCard: {
    padding: 16,
  },
  requestHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 16,
  },
  valeterAvatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  requestInfo: {
    flex: 1,
  },
  valeterName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 4,
  },
  valeterEmail: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    marginBottom: 8,
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 4,
  },
  locationText: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 13,
  },
  roleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  roleText: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 13,
    textTransform: 'capitalize',
  },
  requestActions: {
    flexDirection: 'row',
    gap: 12,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.15)',
  },
  approveButton: {
    flex: 1,
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 6,
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  actionButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '700',
  },
  rejectButton: {
    flex: 1,
  },
  actionButtonCard: {
    paddingVertical: 14,
    paddingHorizontal: 16,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 8,
  },
  rejectButtonText: {
    color: '#EF4444',
    fontSize: 15,
    fontWeight: '700',
  },
});
