import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  TextInput,
  ActivityIndicator,
  Alert,
  Animated,
  RefreshControl,
  Platform,
  KeyboardAvoidingView,
  Image,
  Switch,
  Modal,
  Pressable,
  Linking,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../../src/components/shared/ChromeGlyph';
import { useFocusEffect } from '@react-navigation/native';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import { colors } from '../../src/constants/colors';
import { textStyles } from '../../src/constants/typography';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import BusinessSheetBackground from '../../src/components/shared/BusinessSheetBackground';
import { LocationStyleIconBox } from '../../src/components/shared/GradientIconBox';
import { accentToGradient } from '../../src/utils/accentGradient';
import LoadingScreen from '../../src/components/LoadingScreen';
import ContinueCTAButton from '../../src/components/ui/ContinueCTAButton';
import * as ImagePicker from 'expo-image-picker';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

const SKY = colors.SKY;
const IMAGE_MEDIA_TYPES: any =
  (ImagePicker as any)?.MediaType?.Images ? [(ImagePicker as any).MediaType.Images] : undefined;

type OrgRow = Record<string, any>;

function getMissingColumn(message?: string | null) {
  const m = /column\s+organizations\.(\w+)\s+does\s+not\s+exist/i.exec(message || '');
  return m?.[1] ?? null;
}

const LIGHT_TEXT = '#F9FAFB';
const MUTED_TEXT = 'rgba(249,250,251,0.7)';

// Literal business theme colors for StyleSheet (no getAccountTheme at load time to avoid load-order issues).
const THEME_PRIMARY = '#7DD3FC';
const THEME_PRIMARY_ALT = '#5BA3C7';

const DEFAULT_SERVICES_OFFERED = ['Bronze Wash', 'Silver Wash', 'Gold Wash', 'Platinum Wash', 'Diamond Wash'];

/** day_of_week from location_opening_hours: 0 = Mon, 1 = Tue, ... 6 = Sun */
const DAY_LABELS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

type LocationOpeningHourRow = {
  location_id: string;
  day_of_week: number;
  is_open: boolean;
  open_time: string | null;
  close_time: string | null;
};

type HeaderRightActionProps = Readonly<{
  isEditing: boolean;
  onCancelEditing: () => void;
  onOpenBusinessDetails: () => void;
  iconColor: string;
}>;

function HeaderRightAction({
  isEditing,
  onCancelEditing,
  onOpenBusinessDetails,
  iconColor,
}: HeaderRightActionProps) {
  if (isEditing) {
    return (
      <TouchableOpacity onPress={onCancelEditing} style={styles.headerAction} activeOpacity={0.85}>
        <Ionicons name="close" size={22} color={LIGHT_TEXT} />
      </TouchableOpacity>
    );
  }
  return (
    <View style={styles.headerRightActions}>
      <TouchableOpacity
        onPress={onOpenBusinessDetails}
        style={styles.headerIconBtn}
        hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
      >
        <Ionicons name="pencil" size={22} color={iconColor} />
      </TouchableOpacity>
    </View>
  );
}

function BusinessLogoCircle({ logoUrl, iconColor }: Readonly<{ logoUrl: string; iconColor: string }>) {
  if (logoUrl) return <Image source={{ uri: logoUrl }} style={styles.logoCircleImg} />;
  return (
    <View style={styles.logoCircleFallback}>
      <Ionicons name="business" size={34} color={iconColor} />
    </View>
  );
}

async function fetchOrgLocationData(organizationId: string): Promise<{
  openingHours: LocationOpeningHourRow[];
  serviceNames: string[];
}> {
  try {
    const { data: locationsData } = await supabase
      .from('car_wash_locations')
      .select('id')
      .eq('organization_id', organizationId)
      .order('created_at', { ascending: false });

    const locationIds = (locationsData || []).map((r: { id: string }) => r.id);
    const firstLocationId = locationIds[0];
    let openingHours: LocationOpeningHourRow[] = [];
    let serviceNames: string[] = [];

    if (firstLocationId) {
      const { data: hoursData } = await supabase
        .from('location_opening_hours')
        .select('location_id, day_of_week, is_open, open_time, close_time')
        .eq('location_id', firstLocationId)
        .order('day_of_week', { ascending: true });
      openingHours = (hoursData || []) as LocationOpeningHourRow[];
    }

    if (locationIds.length > 0) {
      try {
        const { data: svcData } = await supabase
          .from('location_services')
          .select('service_name')
          .in('location_id', locationIds)
          .eq('is_enabled', true);

        const names = (svcData || [])
          .map((r: { service_name: string }) => (r.service_name || '').trim())
          .filter(Boolean);
        serviceNames = Array.from(new Set(names));
      } catch (servicesError) {
        console.warn('[BusinessProfile] Failed to load location services:', servicesError);
      }
    }

    return { openingHours, serviceNames };
  } catch (locationsError) {
    console.warn('[BusinessProfile] Failed to load opening hours/service names:', locationsError);
    return { openingHours: [], serviceNames: [] };
  }
}

export default function BusinessProfile() { // NOSONAR
  const { user, logout } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme: businessTheme, mode, toggleMode } = useAccountTheme();
  const primaryColor = businessTheme.primary;

  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [loggingOutProfile, setLoggingOutProfile] = useState(false);

  // logo
  const [logoUrl, setLogoUrl] = useState<string>('');
  const [isUploadingLogo, setIsUploadingLogo] = useState(false);

  // form fields
  const [businessName, setBusinessName] = useState('');
  const [businessEmail, setBusinessEmail] = useState('');
  const [businessPhone, setBusinessPhone] = useState('');
  const [businessAddress, setBusinessAddress] = useState('');
  const [businessDescription, setBusinessDescription] = useState('');
  const [taxId, setTaxId] = useState('');

  // Public storefront (optional fields – may come from org later)
  const [openingHoursDisplay, setOpeningHoursDisplay] = useState<string>('');
  const [locationOpeningHours, setLocationOpeningHours] = useState<LocationOpeningHourRow[]>([]);
  const [openingHoursSheetVisible, setOpeningHoursSheetVisible] = useState(false);
  const [businessDetailsSheetVisible, setBusinessDetailsSheetVisible] = useState(false);
  const [website, setWebsite] = useState<string>('');
  const [instagram, setInstagram] = useState<string>('');
  const [servicesOffered, setServicesOffered] = useState<string[]>(DEFAULT_SERVICES_OFFERED);
  /** Services actually offered: from location_services (enabled) for this org's locations. No mock list. */
  const [locationServiceNames, setLocationServiceNames] = useState<string[]>([]);

  const originalRef = useRef({
    logoUrl: '',
    businessName: '',
    businessEmail: '',
    businessPhone: '',
    businessAddress: '',
    businessDescription: '',
    taxId: '',
    openingHoursDisplay: '',
    website: '',
    instagram: '',
    servicesOffered: [] as string[],
  });

  const organizationId = useMemo(() => user?.organizationId ?? null, [user?.organizationId]);
  const isOrgUser = (user?.userType ?? '').toLowerCase() === 'organization';

  const hasChanges = useMemo(() => {
    const o = originalRef.current;
    return (
      logoUrl !== o.logoUrl ||
      businessName !== o.businessName ||
      businessEmail !== o.businessEmail ||
      businessPhone !== o.businessPhone ||
      businessAddress !== o.businessAddress ||
      businessDescription !== o.businessDescription ||
      taxId !== o.taxId ||
      openingHoursDisplay !== o.openingHoursDisplay ||
      website !== o.website ||
      instagram !== o.instagram ||
      JSON.stringify(servicesOffered) !== JSON.stringify(o.servicesOffered)
    );
  }, [logoUrl, businessName, businessEmail, businessPhone, businessAddress, businessDescription, taxId, openingHoursDisplay, website, instagram, servicesOffered]);

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 450, useNativeDriver: true }).start();
  }, []);

  useEffect(() => {
    if (isOrgUser && organizationId) {
      loadBusinessProfile();
    } else {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [organizationId, isOrgUser]);

  useFocusEffect(
    React.useCallback(() => {
      if (isOrgUser && organizationId) loadBusinessProfile(false);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [organizationId, isOrgUser])
  );

  const applyOrgToForm = (org: OrgRow | null) => {
    const nextName = (org?.name ?? '') as string;
    const nextEmail = ((org?.email ?? user?.email ?? '') as string) || '';
    const nextPhone = (org?.phone ?? '') as string;
    const nextAddress = (org?.address ?? '') as string;
    const nextDesc = (org?.description ?? '') as string;

    const nextTax = (org?.tax_id ?? org?.vat_number ?? org?.vat ?? org?.taxid ?? '') as string;

    const nextLogo = (org?.logo ?? org?.logo_url ?? org?.avatar_url ?? org?.profile_picture ?? '') as string;
    const nextHours = (org?.opening_hours ?? org?.business_hours ?? '') as string;
    const nextWebsite = (org?.website ?? org?.website_url ?? '') as string;
    const nextInstagram = (org?.instagram ?? org?.instagram_url ?? '') as string;
    const nextServices = Array.isArray(org?.services_offered) ? (org.services_offered as string[]) : DEFAULT_SERVICES_OFFERED;

    setBusinessName(nextName);
    setBusinessEmail(nextEmail);
    setBusinessPhone(nextPhone);
    setBusinessAddress(nextAddress);
    setBusinessDescription(nextDesc);
    setTaxId(nextTax);
    setLogoUrl(nextLogo);
    setOpeningHoursDisplay(nextHours || '');
    setWebsite(nextWebsite || '');
    setInstagram(nextInstagram || '');
    setServicesOffered(nextServices.length ? nextServices : DEFAULT_SERVICES_OFFERED);

    originalRef.current = {
      logoUrl: nextLogo,
      businessName: nextName,
      businessEmail: nextEmail,
      businessPhone: nextPhone,
      businessAddress: nextAddress,
      businessDescription: nextDesc,
      taxId: nextTax,
      openingHoursDisplay: nextHours || '',
      website: nextWebsite || '',
      instagram: nextInstagram || '',
      servicesOffered: nextServices,
    };
  };

  const loadBusinessProfile = async (showSpinner = true) => {
    if (!isOrgUser || !organizationId) return;

    try {
      if (showSpinner) setLoading(true);

      const { data, error } = await supabase
        .from('organizations')
        .select('*')
        .eq('id', organizationId)
        .maybeSingle();

      if (error) throw error;

      applyOrgToForm(data || null);
      const locationData = await fetchOrgLocationData(organizationId);
      setLocationOpeningHours(locationData.openingHours);
      setLocationServiceNames(locationData.serviceNames);
    } catch (error: any) {
      console.error('Error loading business profile:', error);
      Alert.alert('Error', error?.message || 'Failed to load business information');
    } finally {
      if (showSpinner) setLoading(false);
    }
  };

  const onRefresh = async () => {
    if (!isOrgUser || !organizationId) return;
    try {
      setRefreshing(true);
      await loadBusinessProfile(false);
    } finally {
      setRefreshing(false);
    }
  };

  const cancelEditing = async () => {
    await hapticFeedback('light');
    const o = originalRef.current;
    setLogoUrl(o.logoUrl);
    setBusinessName(o.businessName);
    setBusinessEmail(o.businessEmail);
    setBusinessPhone(o.businessPhone);
    setBusinessAddress(o.businessAddress);
    setBusinessDescription(o.businessDescription);
    setTaxId(o.taxId);
    setOpeningHoursDisplay(o.openingHoursDisplay);
    setWebsite(o.website);
    setInstagram(o.instagram);
    setServicesOffered(o.servicesOffered);
    setIsEditing(false);
  };

  // storage
  const BUCKET = 'org-logos';

  const uploadLogoToStorage = async (localUri: string) => {
    if (!organizationId) return '';

    const ext = (localUri.split('.').pop() || 'jpg').toLowerCase();
    const path = `organizations/${organizationId}/logo_${Date.now()}.${ext}`;

    const res = await fetch(localUri);
    const blob = await res.blob();

    const { error: upErr } = await supabase.storage.from(BUCKET).upload(path, blob, {
      upsert: true,
      contentType: blob.type || (ext === 'png' ? 'image/png' : 'image/jpeg'),
    });

    if (upErr) throw upErr;

    const { data } = supabase.storage.from(BUCKET).getPublicUrl(path);
    return data?.publicUrl || '';
  };

  const handlePickLogo = async () => {
    try {
      await hapticFeedback('light');

      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted) {
        Alert.alert('Permission needed', 'Please allow photo library access to upload your logo.');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: IMAGE_MEDIA_TYPES,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.9,
      });

      if (result.canceled) return;

      const uri = result.assets?.[0]?.uri;
      if (!uri) return;

      setIsUploadingLogo(true);

      let finalUrl = uri;

      try {
        const uploaded = await uploadLogoToStorage(uri);
        if (uploaded) finalUrl = uploaded;
      } catch (e: any) {
        console.warn('[BusinessProfile] logo upload failed (using local preview):', e?.message || e);
        Alert.alert(
          'Logo upload not configured',
          'I picked the image but couldn’t upload it yet. If you want it to persist, create a Supabase Storage bucket named "org-logos" (or update BUCKET in this file).'
        );
      }

      setLogoUrl(finalUrl);
      setIsEditing(true);
    } finally {
      setIsUploadingLogo(false);
    }
  };

  const handleRemoveLogo = async () => {
    await hapticFeedback('light');
    setLogoUrl('');
    setIsEditing(true);
  };

  const handleProfileLogout = () => {
    if (loggingOutProfile) return;
    Alert.alert(
      'Log out?',
      'You’ll need to sign in again to access your business account.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Log out',
          style: 'destructive',
          onPress: async () => {
            try {
              setLoggingOutProfile(true);
              await hapticFeedback('medium');
              await logout();
              router.replace('/auth/login' as any);
            } catch (e: any) {
              Alert.alert('Error', e?.message || 'Failed to log out.');
            } finally {
              setLoggingOutProfile(false);
            }
          },
        },
      ]
    );
  };

  const handleProfileDeleteAccount = () => {
    Alert.alert(
      'Delete business account?',
      'We need to verify payouts, team access, and open bookings before removing a business account. Email support and we’ll guide you through it.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Email support',
          onPress: () =>
            void Linking.openURL('mailto:support@wishawash.com?subject=Business%20account%20deletion'),
        },
      ]
    );
  };

  const handleSave = async () => {
    if (!isOrgUser || !organizationId) {
      Alert.alert('Error', 'Business account not linked to an organization.');
      return;
    }

    if (!businessName.trim()) {
      Alert.alert('Missing info', 'Business name is required.');
      return;
    }

    try {
      setIsSaving(true);
      await hapticFeedback('medium');

      const payload: Record<string, any> = {
        id: organizationId,
        name: businessName.trim(),
        email: businessEmail.trim() || null,
        phone: businessPhone.trim() || null,
        address: businessAddress.trim() || null,
        description: businessDescription.trim() || null,
        updated_at: new Date().toISOString(),
      };
      // Optional org fields — add to organizations table when ready: opening_hours, website, instagram, cover_image_url, services_offered

      const logoValue = logoUrl.trim() || null;

      let { error } = await supabase
        .from('organizations')
        .upsert({ ...payload, tax_id: taxId.trim() || null, logo: logoValue });

      if (error) {
        const missing = getMissingColumn(error.message);

        if (missing === 'tax_id') {
          const retry = await supabase
            .from('organizations')
            .upsert({ ...payload, vat_number: taxId.trim() || null, logo: logoValue });
          error = retry.error;
        }

        if (missing === 'logo') {
          const retry2 = await supabase
            .from('organizations')
            .upsert({ ...payload, tax_id: taxId.trim() || null, logo_url: logoValue });
          error = retry2.error;
        }

        if (error) {
          const missing2 = getMissingColumn(error.message);
          if (missing2 === 'logo_url') {
            const retry3 = await supabase
              .from('organizations')
              .upsert({ ...payload, tax_id: taxId.trim() || null, avatar_url: logoValue });
            error = retry3.error;
          }
        }
      }

      if (error) throw error;

      await loadBusinessProfile(false);
      Alert.alert('Saved', 'Your business profile has been updated.');
      setIsEditing(false);
    } catch (error: any) {
      console.error('Error saving business profile:', error);
      Alert.alert('Error', error?.message || 'Failed to save business information');
    } finally {
      setIsSaving(false);
    }
  };

  if (loading) {
    return <LoadingScreen message="Loading profile…" />;
  }

  if (!isOrgUser || !organizationId) {
    return (
      <View style={styles.container}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="business" />
        <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
          <AppHeader title="Profile" accountType="business" />
          <View style={styles.loadingContainer}>
            <Ionicons name="alert-circle-outline" size={42} color={businessTheme.primary} style={{ opacity: 0.85 }} />
            <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320 }]}>
              This business account isn't linked to an organization yet.
              {'\n'}Log out and back in, or contact support.
            </Text>
          </View>
        </SafeAreaView>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />
      <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
        <AppHeader
          title="Profile"
          accountType="business"
          rightAction={
            <HeaderRightAction
              isEditing={isEditing}
              onCancelEditing={() => void cancelEditing()}
              onOpenBusinessDetails={() => {
                void hapticFeedback('light');
                setBusinessDetailsSheetVisible(true);
              }}
              iconColor={primaryColor || THEME_PRIMARY}
            />
          }
          scrollY={scrollY}
          enableScrollAnimation
        />

      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <Animated.ScrollView
          style={styles.scrollView}
          showsVerticalScrollIndicator={false}
          onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
          scrollEventThrottle={16}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
          contentContainerStyle={[
            styles.scrollContent,
            {
              paddingTop: HEADER_CONTENT_OFFSET,
              paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 24,
            },
          ]}
        >
          <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
            {/* ====== PROFILE HEADER (Google Business–style storefront) ====== */}
            <View style={styles.profileHeaderBlock}>
              <View style={styles.profileHeaderTopRow}>
                <TouchableOpacity
                  onPress={handlePickLogo}
                  activeOpacity={0.9}
                  disabled={isUploadingLogo}
                  style={styles.avatarContainer}
                >
                  <View style={styles.avatarOuter}>
                    <View style={styles.avatarInner}>
                      <BusinessLogoCircle logoUrl={logoUrl} iconColor={businessTheme.primary} />
                    </View>
                  </View>
                  <View style={styles.avatarEditBadge}>
                    {isUploadingLogo ? (
                      <ActivityIndicator size="small" color="#fff" />
                    ) : (
                      <Ionicons name="camera" size={14} color="#fff" />
                    )}
                  </View>
                </TouchableOpacity>
                <View style={styles.profileActionsRow}>
                  <TouchableOpacity style={styles.profileActionBtn} onPress={handlePickLogo} disabled={isUploadingLogo} activeOpacity={0.8}>
                    <Ionicons name={logoUrl ? 'image' : 'cloud-upload-outline'} size={16} color={businessTheme.primary} />
                    <Text style={styles.profileActionLabel}>{logoUrl ? 'Change logo' : 'Add logo'}</Text>
                  </TouchableOpacity>
                  {logoUrl ? (
                    <TouchableOpacity style={[styles.profileActionBtn, styles.profileActionBtnDanger]} onPress={handleRemoveLogo} activeOpacity={0.8}>
                      <Ionicons name="trash-outline" size={16} color="#FCA5A5" />
                    </TouchableOpacity>
                  ) : null}
                </View>
              </View>

              <Text style={styles.profileNameTitle} numberOfLines={1}>{businessName || 'Your business'}</Text>
              <Text style={styles.profileTrustSubtitle}>I trust this place with my car</Text>
              <Text style={styles.profileMetaSubtitle} numberOfLines={3}>
                {businessDescription || 'Add a description to tell customers about your business...'}
              </Text>

              <View style={styles.profileServiceTags}>
                {locationServiceNames.length > 0 ? (
                  locationServiceNames.slice(0, 5).map((s) => (
                    <View key={s} style={styles.profileServiceTag}><Text style={styles.profileServiceTagText}>{s}</Text></View>
                  ))
                ) : (
                  <TouchableOpacity style={styles.profileServiceTag} onPress={() => router.push('/business/locations' as any)} activeOpacity={0.85}>
                    <Text style={styles.profileServiceTagText}>Set in Locations → Services</Text>
                  </TouchableOpacity>
                )}
              </View>

              <TouchableOpacity
                style={styles.profileMetaRow}
                onPress={() => { hapticFeedback('light'); setOpeningHoursSheetVisible(true); }}
                activeOpacity={0.8}
              >
                <Ionicons name="time-outline" size={14} color={MUTED_TEXT} />
                <Text style={styles.profileMetaText}>
                  {locationOpeningHours.length > 0 ? 'View opening hours' : 'Opening hours (set in Locations)'}
                </Text>
                <Ionicons name="chevron-forward" size={14} color={MUTED_TEXT} />
              </TouchableOpacity>
              {businessAddress ? (
                <View style={styles.profileMetaRow}>
                  <Ionicons name="location-outline" size={14} color={MUTED_TEXT} />
                  <Text style={styles.profileMetaText} numberOfLines={1}>{businessAddress}</Text>
                </View>
              ) : null}
              <View style={styles.profileMetaRow}>
                <Ionicons name="mail-outline" size={14} color={MUTED_TEXT} />
                <Text style={styles.profileMetaText} numberOfLines={1}>{businessEmail || user?.email || 'Add email'}</Text>
              </View>
              {businessPhone ? (
                <View style={styles.profileMetaRow}>
                  <Ionicons name="call-outline" size={14} color={MUTED_TEXT} />
                  <Text style={styles.profileMetaText} numberOfLines={1}>{businessPhone}</Text>
                </View>
              ) : null}
              <View style={styles.pillsContainer}>
                {businessAddress ? (
                  <View style={styles.statusPill}>
                    <Ionicons name="location" size={12} color={THEME_PRIMARY} />
                    <Text style={styles.statusPillText}>Address set</Text>
                  </View>
                ) : null}
              </View>
            </View>

            {/* Opening hours bottom sheet — digital clock premium style */}
            <Modal
              visible={openingHoursSheetVisible}
              transparent
              animationType="slide"
              statusBarTranslucent
              onRequestClose={() => setOpeningHoursSheetVisible(false)}
            >
              <View style={styles.hoursSheetOverlay}>
                <Pressable style={StyleSheet.absoluteFill} onPress={() => setOpeningHoursSheetVisible(false)}>
                  <View style={[StyleSheet.absoluteFill, styles.hoursSheetBackdrop]} />
                </Pressable>
                <Pressable style={[styles.hoursSheetPanel, { paddingBottom: Math.max(24, insets.bottom + 12) }]} onPress={(e) => e.stopPropagation()}>
                  <BusinessSheetBackground />
                  <View style={[styles.hoursSheetHandle, { backgroundColor: (primaryColor || THEME_PRIMARY) + '80' }]} />
                  <View style={styles.hoursSheetHeader}>
                    <Text style={styles.hoursSheetTitle}>Opening hours</Text>
                    <TouchableOpacity onPress={() => setOpeningHoursSheetVisible(false)} hitSlop={12}>
                      <Ionicons name="close" size={24} color="rgba(255,255,255,0.9)" />
                    </TouchableOpacity>
                  </View>
                  <Text style={styles.hoursSheetSubtitle}>From your first location</Text>
                  {locationOpeningHours.length === 0 ? (
                    <View style={styles.hoursSheetEmpty}>
                      <Ionicons name="time-outline" size={32} color="rgba(255,255,255,0.4)" />
                      <Text style={styles.hoursSheetEmptyText}>Set hours in Locations → select location → Hours</Text>
                      <TouchableOpacity style={styles.hoursSheetCta} onPress={() => { setOpeningHoursSheetVisible(false); router.push('/business/locations' as any); }} activeOpacity={0.85}>
                        <Text style={styles.hoursSheetCtaText}>Go to Locations</Text>
                        <Ionicons name="chevron-forward" size={18} color="#0A1929" />
                      </TouchableOpacity>
                    </View>
                  ) : (
                    <View style={styles.hoursSheetGrid}>
                      {[0, 1, 2, 3, 4, 5, 6].map((dayOfWeek) => {
                        const row = locationOpeningHours.find((r) => r.day_of_week === dayOfWeek);
                        const isOpen = row?.is_open && row?.open_time && row?.close_time;
                        const openTime = (row?.open_time || '').slice(0, 5);
                        const closeTime = (row?.close_time || '').slice(0, 5);
                        return (
                          <View key={dayOfWeek} style={styles.hoursSheetRow}>
                            <Text style={styles.hoursSheetDay}>{DAY_LABELS[dayOfWeek]}</Text>
                            {isOpen ? (
                              <View style={styles.hoursSheetTimes}>
                                <View style={styles.hoursSheetTimeBlock}>
                                  <Text style={styles.hoursSheetTimeText}>{openTime}</Text>
                                </View>
                                <Text style={styles.hoursSheetTimeSep}>–</Text>
                                <View style={styles.hoursSheetTimeBlock}>
                                  <Text style={styles.hoursSheetTimeText}>{closeTime}</Text>
                                </View>
                              </View>
                            ) : (
                              <View style={styles.hoursSheetClosedWrap}>
                                <Text style={styles.hoursSheetClosed}>CLOSED</Text>
                              </View>
                            )}
                          </View>
                        );
                      })}
                    </View>
                  )}
                </Pressable>
              </View>
            </Modal>

            {/* Business details sheet (name, description, contact) */}
            <Modal visible={businessDetailsSheetVisible} transparent animationType="slide" statusBarTranslucent onRequestClose={() => setBusinessDetailsSheetVisible(false)}>
              <View style={styles.hoursSheetOverlay}>
                <Pressable style={StyleSheet.absoluteFill} onPress={() => setBusinessDetailsSheetVisible(false)}>
                  <View style={[StyleSheet.absoluteFill, styles.hoursSheetBackdrop]} />
                </Pressable>
                <Pressable style={[styles.hoursSheetPanel, { paddingBottom: Math.max(24, insets.bottom + 12) }]} onPress={(e) => e.stopPropagation()}>
                  <BusinessSheetBackground />
                  <View style={[styles.hoursSheetHandle, { backgroundColor: (primaryColor || THEME_PRIMARY) + '80' }]} />
                  <View style={styles.hoursSheetHeader}>
                    <Text style={styles.hoursSheetTitle}>Business details</Text>
                    <TouchableOpacity onPress={() => setBusinessDetailsSheetVisible(false)} hitSlop={12}>
                      <Ionicons name="close" size={24} color="rgba(255,255,255,0.9)" />
                    </TouchableOpacity>
                  </View>
                  <Text style={styles.hoursSheetSubtitle}>What customers see on your storefront</Text>
                  <Animated.ScrollView style={{ maxHeight: 360 }} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
                    <View style={styles.fieldRow}>
                      <Text style={styles.fieldLabel}>Business name</Text>
                      <TextInput style={styles.fieldInput} value={businessName} onChangeText={setBusinessName} placeholder="Business name" placeholderTextColor="rgba(249,250,251,0.45)" />
                    </View>
                    <View style={styles.fieldRow}>
                      <Text style={styles.fieldLabel}>Description</Text>
                      <TextInput style={[styles.fieldInput, styles.fieldInputMultiline]} value={businessDescription} onChangeText={setBusinessDescription} placeholder="What do you do?" placeholderTextColor="rgba(249,250,251,0.45)" multiline numberOfLines={3} />
                    </View>
                    <View style={styles.fieldRow}>
                      <Text style={styles.fieldLabel}>Address</Text>
                      <TextInput style={[styles.fieldInput, styles.fieldInputMultiline]} value={businessAddress} onChangeText={setBusinessAddress} placeholder="Business address" placeholderTextColor="rgba(249,250,251,0.45)" multiline />
                    </View>
                    <View style={styles.fieldRow}>
                      <Text style={styles.fieldLabel}>Email</Text>
                      <TextInput style={styles.fieldInput} value={businessEmail} onChangeText={setBusinessEmail} placeholder="Email" placeholderTextColor="rgba(249,250,251,0.45)" keyboardType="email-address" autoCapitalize="none" />
                    </View>
                    <View style={styles.fieldRow}>
                      <Text style={styles.fieldLabel}>Phone</Text>
                      <TextInput style={styles.fieldInput} value={businessPhone} onChangeText={setBusinessPhone} placeholder="Phone number" placeholderTextColor="rgba(249,250,251,0.45)" keyboardType="phone-pad" />
                    </View>
                  </Animated.ScrollView>
                  <ContinueCTAButton
                    title="Save"
                    accentColor={primaryColor || THEME_PRIMARY}
                    disabled={isSaving}
                    loading={isSaving}
                    style={styles.sheetSaveCta}
                    onPress={async () => {
                      await handleSave();
                      setBusinessDetailsSheetVisible(false);
                    }}
                  />
                </Pressable>
              </View>
            </Modal>

            <GlassCard style={[styles.notificationCard, styles.appearanceCardSpacing] as any} accountType="business">
              <View style={styles.notificationContent}>
                <View style={styles.notificationLeft}>
                  <View style={styles.quickActionIconBoxSmall}>
                    <LocationStyleIconBox
                      icon={mode === 'light' ? 'sunny' : 'moon'}
                      colors={[primaryColor, businessTheme.primaryAlt]}
                    />
                  </View>
                  <View style={styles.notificationInfo}>
                    <Text style={styles.notificationLabel}>Appearance</Text>
                    <Text style={styles.notificationDescription}>{mode === 'light' ? 'Light' : 'Dark'} mode</Text>
                  </View>
                </View>
                <Switch
                  value={mode === 'light'}
                  onValueChange={async () => { await hapticFeedback('light'); toggleMode(); }}
                  trackColor={{ false: 'rgba(255,255,255,0.2)', true: primaryColor }}
                  thumbColor="#FFFFFF"
                  ios_backgroundColor="rgba(255,255,255,0.2)"
                />
              </View>
            </GlassCard>

            {/* ====== SAVE / CANCEL ====== */}
            {isEditing ? (
              <View style={styles.saveSection}>
                <ContinueCTAButton
                  title="Save changes"
                  onPress={handleSave}
                  accentColor={primaryColor || THEME_PRIMARY}
                  disabled={!hasChanges || isSaving}
                  loading={isSaving}
                  leading={<Ionicons name="checkmark" size={20} color={colors.textOnDarkPrimary} />}
                />
                <ContinueCTAButton
                  title="Cancel"
                  onPress={cancelEditing}
                  accentColor={primaryColor || THEME_PRIMARY}
                  disabled={isSaving}
                  variant="secondary"
                  showTrailingChevron={false}
                  leading={<Ionicons name="close" size={20} color={colors.textOnDarkPrimary} />}
                />
                {!hasChanges && <Text style={styles.hintText}>No changes to save.</Text>}
              </View>
            ) : (
              <Text style={styles.hintText}>Tap the pencil above to edit your profile.</Text>
            )}

            <View style={styles.logoutButtonWrap}>
              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  router.push('/business/settings' as any);
                }}
                activeOpacity={0.9}
              >
                <GlassCard style={styles.settingsLinkCard as any} accountType="business" borderColor={`${primaryColor}35`}>
                  <View style={styles.logoutContent}>
                    <View style={[styles.logoutIconWrapper, { backgroundColor: 'transparent', borderWidth: 0 }]}>
                      <LocationStyleIconBox icon="settings-outline" colors={accentToGradient(primaryColor)} />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.settingsLinkTitle}>Settings</Text>
                      <Text style={styles.settingsLinkSubtitle}>Bookings, team, payouts, legal, and more</Text>
                    </View>
                    <Ionicons name="chevron-forward" size={20} color="rgba(148,163,184,0.9)" />
                  </View>
                </GlassCard>
              </TouchableOpacity>
            </View>

            <View style={styles.logoutButtonWrap}>
              <TouchableOpacity onPress={handleProfileLogout} disabled={loggingOutProfile} activeOpacity={0.9}>
                <GlassCard
                  style={[styles.logoutCard, loggingOutProfile && { opacity: 0.7 }] as any}
                  accountType="business"
                  borderColor="rgba(239,68,68,0.35)"
                >
                  <View style={styles.logoutContent}>
                    <View style={[styles.logoutIconWrapper, { backgroundColor: 'transparent', borderWidth: 0 }]}>
                      {loggingOutProfile ? (
                        <ActivityIndicator size="small" color="#EF4444" />
                      ) : (
                        <LocationStyleIconBox icon="log-out-outline" preset="red" />
                      )}
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.logoutTitle}>{loggingOutProfile ? 'Logging out…' : 'Log out'}</Text>
                      <Text style={styles.logoutSubtitle}>Sign out of this business account</Text>
                    </View>
                    <Ionicons name="chevron-forward" size={20} color="rgba(239,68,68,0.9)" />
                  </View>
                </GlassCard>
              </TouchableOpacity>
            </View>

            <View style={styles.deleteAccountButtonWrap}>
              <TouchableOpacity onPress={handleProfileDeleteAccount} activeOpacity={0.9}>
                <GlassCard style={styles.deleteAccountCardFilled as any} accountType="business" borderColor="rgba(239,68,68,0.45)">
                  <View style={styles.logoutContent}>
                    <View style={[styles.logoutIconWrapper, { backgroundColor: 'rgba(239,68,68,0.2)' }]}>
                      <Ionicons name="trash-outline" size={22} color="#EF4444" />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.logoutTitle}>Delete account</Text>
                      <Text style={styles.logoutSubtitle}>Request removal via support</Text>
                    </View>
                    <Ionicons name="chevron-forward" size={20} color="rgba(239,68,68,0.9)" />
                  </View>
                </GlassCard>
              </TouchableOpacity>
            </View>

            <View style={{ height: 16 }} />
          </Animated.View>
        </Animated.ScrollView>
      </KeyboardAvoidingView>
      </SafeAreaView>
    </View>
  );
}

const COVER_HEIGHT = 140;
const AVATAR_SIZE = 96;
const AVATAR_OVERLAP = 44;

const styles = StyleSheet.create({
  container: { flex: 1 },

  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 24,
  },
  loadingText: { color: LIGHT_TEXT, fontSize: 14, fontWeight: '700' },

  scrollView: { flex: 1 },
  scrollContent: { paddingHorizontal: 20 },

  content: { gap: 0 },


  // Profile header
  profileHeaderBlock: {
    paddingBottom: 24,
    marginBottom: 16,
    paddingHorizontal: 4,
  },
  profileHeaderTopRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    marginTop: 0,
    marginBottom: 16,
  },
  avatarContainer: {
    // left aligned overlapping cover
  },
  avatarOuter: {
    width: AVATAR_SIZE + 8,
    height: AVATAR_SIZE + 8,
    borderRadius: (AVATAR_SIZE + 8) / 2,
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarInner: {
    width: AVATAR_SIZE,
    height: AVATAR_SIZE,
    borderRadius: AVATAR_SIZE / 2,
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.06)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarEditBadge: {
    position: 'absolute',
    right: 0,
    bottom: 4,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: THEME_PRIMARY,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 3,
    borderColor: '#0F2847', // match BG
  },
  profileActionsRow: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 8,
  },
  profileActionBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  profileActionBtnDanger: { backgroundColor: 'rgba(239,68,68,0.2)', paddingHorizontal: 12 },
  profileActionLabel: { color: LIGHT_TEXT, fontSize: 13, fontWeight: '700' },
  profileNameTitle: {
    color: LIGHT_TEXT,
    fontSize: 24,
    fontWeight: '800',
    marginBottom: 4,
    letterSpacing: -0.3,
  },
  profileTrustSubtitle: {
    color: THEME_PRIMARY,
    fontSize: 13,
    fontWeight: '700',
    marginBottom: 8,
    fontStyle: 'italic',
  },
  profileMetaSubtitle: {
    color: 'rgba(249,250,251,0.85)',
    fontSize: 15,
    fontWeight: '400',
    marginBottom: 12,
    lineHeight: 20,
  },
  profileMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 6,
  },
  profileMetaText: { color: MUTED_TEXT, fontSize: 14, fontWeight: '500' },
  profileServiceTags: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 10, marginBottom: 10 },
  profileServiceTag: { paddingVertical: 4, paddingHorizontal: 10, borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.08)' },
  profileServiceTagText: { color: LIGHT_TEXT, fontSize: 12, fontWeight: '600' },
  pillsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 16,
  },
  statusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  statusPillText: {
    color: LIGHT_TEXT,
    fontSize: 13,
    fontWeight: '600',
  },

  // Quick Links
  quickLinksSection: {
    marginBottom: 20,
  },
  blockRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
    borderRadius: 20,
    padding: 16,
    marginBottom: 12,
  },
  blockRowIcon: {
    width: 44,
    height: 44,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  quickActionIconBox: {
    width: 44,
    height: 44,
    borderRadius: 14,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  quickActionIconBoxSmall: {
    width: 40,
    height: 40,
    borderRadius: 12,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
  },
  blockRowBody: {
    flex: 1,
  },
  blockRowTitle: {
    color: LIGHT_TEXT,
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 2,
  },
  blockRowSub: {
    color: MUTED_TEXT,
    fontSize: 13,
  },

  // Section dropdown (replaces tabs) — matches UI, more opaque
  tabDropdownWrap: { marginBottom: 16 },
  tabDropdownTrigger: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderRadius: 14,
    borderWidth: 1.5,
    minHeight: 50,
  },
  tabDropdownTriggerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    flex: 1,
    paddingVertical: 14,
    paddingHorizontal: 18,
  },
  tabDropdownLabel: { color: LIGHT_TEXT, fontSize: 16, fontWeight: '800' },
  tabSheetOverlay: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  tabSheetPanel: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingTop: 12,
    paddingHorizontal: 20,
    minHeight: 320,
    overflow: 'hidden',
  },
  tabSheetHandle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    alignSelf: 'center',
    marginBottom: 16,
  },
  tabSheetTitle: {
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 12,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  tabSheetOption: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderRadius: 14,
    marginBottom: 6,
    overflow: 'hidden',
  },
  tabSheetOptionActive: {},
  tabSheetOptionLabel: { fontSize: 17, fontWeight: '600' },
  tabSheetOptionLabelActive: { fontWeight: '700' },
  openingHoursRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    paddingHorizontal: 0,
  },
  openingHoursRowLabel: { fontSize: 16, color: 'rgba(249,250,251,0.9)', fontWeight: '500' },
  hoursSheetOverlay: { flex: 1, justifyContent: 'flex-end' },
  hoursSheetBackdrop: { backgroundColor: 'rgba(0,0,0,0.75)' },
  hoursSheetPanel: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingHorizontal: 24,
    paddingTop: 12,
    maxHeight: '85%',
    overflow: 'hidden',
  },
  hoursSheetHandle: {
    width: 36,
    height: 4,
    borderRadius: 2,
    alignSelf: 'center',
    marginBottom: 16,
  },
  hoursSheetHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  hoursSheetTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: '#F9FAFB',
    letterSpacing: -0.5,
  },
  hoursSheetSubtitle: {
    fontSize: 13,
    color: 'rgba(249,250,251,0.6)',
    marginBottom: 20,
    letterSpacing: 0.3,
  },
  hoursSheetEmpty: {
    alignItems: 'center',
    paddingVertical: 32,
    gap: 12,
  },
  hoursSheetEmptyText: {
    fontSize: 14,
    color: 'rgba(249,250,251,0.7)',
    textAlign: 'center',
    paddingHorizontal: 24,
  },
  hoursSheetCta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: THEME_PRIMARY,
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 12,
    marginTop: 8,
  },
  hoursSheetCtaText: { fontSize: 15, fontWeight: '700', color: '#0A1929' },
  hoursSheetGrid: { gap: 0 },
  hoursSheetRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.08)',
  },
  hoursSheetDay: {
    fontSize: 15,
    fontWeight: '600',
    color: 'rgba(249,250,251,0.9)',
    letterSpacing: 0.2,
  },
  hoursSheetTimes: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  hoursSheetTimeBlock: {
    backgroundColor: 'rgba(0,0,0,0.35)',
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.25)',
  },
  hoursSheetTimeText: {
    fontSize: 17,
    fontWeight: '700',
    color: '#7DD3FC',
    letterSpacing: 1.5,
    fontVariant: ['tabular-nums'],
  },
  hoursSheetTimeSep: {
    fontSize: 14,
    fontWeight: '600',
    color: 'rgba(249,250,251,0.5)',
  },
  hoursSheetClosedWrap: {
    backgroundColor: 'rgba(255,255,255,0.06)',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 8,
  },
  hoursSheetClosed: {
    fontSize: 12,
    fontWeight: '800',
    color: 'rgba(249,250,251,0.5)',
    letterSpacing: 1.2,
  },
  publicPreviewRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 14, marginBottom: 14 },
  publicPreviewLogo: { width: 56, height: 56, borderRadius: 28, overflow: 'hidden', backgroundColor: 'rgba(255,255,255,0.06)' },
  publicPreviewLogoImg: { width: '100%', height: '100%' },
  publicPreviewLogoPlaceholder: { width: '100%', height: '100%', alignItems: 'center', justifyContent: 'center', backgroundColor: `${THEME_PRIMARY}20` },
  publicPreviewText: { flex: 1, minWidth: 0 },
  publicPreviewName: { color: LIGHT_TEXT, fontSize: 16, fontWeight: '800', marginBottom: 4 },
  publicPreviewBio: { color: MUTED_TEXT, fontSize: 13, marginBottom: 4 },
  publicPreviewBioPlaceholder: { color: 'rgba(249,250,251,0.5)', fontSize: 13, fontStyle: 'italic', marginBottom: 4 },
  publicPreviewMeta: { color: MUTED_TEXT, fontSize: 12, marginBottom: 4 },
  publicPreviewMetaRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 4, marginBottom: 6 },
  publicPreviewMetaText: { color: MUTED_TEXT, fontSize: 12 },
  publicPreviewHoursRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 6 },
  publicPreviewHoursText: { color: MUTED_TEXT, fontSize: 13, flex: 1 },
  publicPreviewTags: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 8 },
  publicPreviewTag: { paddingVertical: 2, paddingHorizontal: 8, borderRadius: 8, backgroundColor: 'rgba(125,211,252,0.12)' },
  publicPreviewTagText: { color: LIGHT_TEXT, fontSize: 11, fontWeight: '600' },
  publicPreviewTagEmpty: { color: 'rgba(249,250,251,0.5)', fontSize: 12, fontStyle: 'italic' },
  editPublicButton: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 8, paddingVertical: 10 },
  editPublicButtonText: { color: THEME_PRIMARY, fontSize: 14, fontWeight: '700' },
  sheetDoneBtn: { marginTop: 8, marginHorizontal: 20, paddingVertical: 14, borderRadius: 16, backgroundColor: 'rgba(255,255,255,0.12)', alignItems: 'center' },
  sheetDoneBtnText: { color: LIGHT_TEXT, fontSize: 16, fontWeight: '700' },
  tabDropdownItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 14,
    paddingHorizontal: 18,
  },
  tabDropdownItemActive: { backgroundColor: 'rgba(125,211,252,0.18)' },
  tabDropdownItemText: { color: MUTED_TEXT, fontSize: 16, fontWeight: '700' },
  tabDropdownItemTextActive: { color: LIGHT_TEXT, fontWeight: '800' },
  sectionHeaderRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 4 },

  // Section cards (About / Contact / Settings)
  sectionCard: {
    padding: 20,
    marginBottom: 16,
    borderRadius: 20,
  },
  sectionCardTitle: {
    color: LIGHT_TEXT,
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 16,
  },
  sectionCardSubtitle: { color: LIGHT_TEXT, fontSize: 16, fontWeight: '800', marginBottom: 4 },
  sectionCardDescription: { color: MUTED_TEXT, fontSize: 13, marginBottom: 16 },
  reviewsRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 12 },
  reviewStat: { alignItems: 'center', flex: 1 },
  reviewStatValue: { color: LIGHT_TEXT, fontSize: 20, fontWeight: '800' },
  reviewStatLabel: { color: MUTED_TEXT, fontSize: 12, marginTop: 2 },
  verifiedBadgeRow: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 10, paddingHorizontal: 12, borderRadius: 12, backgroundColor: 'rgba(16,185,129,0.12)', marginBottom: 10 },
  verifiedBadgeText: { color: '#10B981', fontSize: 14, fontWeight: '700' },
  topRatedBadge: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 8 },
  topRatedText: { color: MUTED_TEXT, fontSize: 13, fontWeight: '600' },
  galleryGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 12 },
  gallerySlot: { flex: 1, minWidth: '30%', paddingVertical: 20, paddingHorizontal: 12, borderRadius: 14, backgroundColor: 'rgba(255,255,255,0.06)', alignItems: 'center', justifyContent: 'center' },
  gallerySlotLabel: { color: MUTED_TEXT, fontSize: 12, marginTop: 8, fontWeight: '600' },
  galleryComingSoon: { color: MUTED_TEXT, fontSize: 12, fontStyle: 'italic' },
  verificationRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 12, paddingHorizontal: 4, marginBottom: 8 },
  verificationText: { color: LIGHT_TEXT, fontSize: 14, fontWeight: '700' },
  fieldRow: { marginBottom: 16 },
  fieldLabel: {
    color: MUTED_TEXT,
    fontSize: 12,
    fontWeight: '700',
    marginBottom: 6,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  fieldInput: {
    color: LIGHT_TEXT,
    fontSize: 16,
    fontWeight: '600',
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  fieldInputMultiline: { minHeight: 80, textAlignVertical: 'top' },

  settingsTab: { gap: 0, marginBottom: 8 },
  settingsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 4,
  },
  settingsRowLeft: { flexDirection: 'row', alignItems: 'center', gap: 14, flex: 1 },
  settingsIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  settingsRowTitle: { color: LIGHT_TEXT, fontSize: 16, fontWeight: '700' },
  settingsRowSub: { color: MUTED_TEXT, fontSize: 13, marginTop: 2 },
  collapseHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 14,
    paddingHorizontal: 4,
    marginBottom: 8,
  },
  collapseTitle: { color: LIGHT_TEXT, fontSize: 16, fontWeight: '700', flex: 1 },
  collapseContent: { marginBottom: 16 },

  saveSection: { gap: 12, marginTop: 20 },
  input: { color: LIGHT_TEXT, fontSize: 16, padding: 0, fontWeight: '800' },
  textArea: { minHeight: 80, textAlignVertical: 'top' },

  logoCircleImg: { width: '100%', height: '100%' },
  logoCircleFallback: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: `${THEME_PRIMARY}20`,
  },

  headerRightActions: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  headerIconBtn: { padding: 8, justifyContent: 'center', alignItems: 'center' },
  headerAction: {
    width: 36,
    height: 36,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(132,204,22,0.15)',
  },

  hintText: {
    color: MUTED_TEXT,
    fontSize: 12,
    lineHeight: 18,
    marginTop: 8,
    textAlign: 'center',
    fontWeight: '700',
  },
  sectionHeaderButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flex: 1,
    marginBottom: 8,
  },
  sectionTitle: {
    ...textStyles.sectionTitle,
    color: LIGHT_TEXT,
  },
  sectionDescription: {
    color: MUTED_TEXT,
    fontSize: 13,
    marginBottom: 16,
    lineHeight: 18,
    fontWeight: '600',
  },
  settingsButton: {
    marginTop: 8,
  },
  settingsCard: {
    padding: 0,
    overflow: 'hidden',
  },
  settingsContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
  },
  settingsLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    flex: 1,
  },
  settingsIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 14,
    overflow: 'hidden',
  },
  settingsIconGradient: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  settingsText: {
    flex: 1,
    gap: 4,
  },
  settingsTitle: {
    color: LIGHT_TEXT,
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  settingsSubtitle: {
    color: MUTED_TEXT,
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '600',
  },

  accountRowWrapper: {
    marginBottom: 12,
  },
  // Notification Settings
  notificationList: {
    gap: 12,
    marginTop: 12,
  },
  notificationCard: {
    borderRadius: 20,
    padding: 0,
  },
  appearanceCardSpacing: {
    marginBottom: 12,
  },
  notificationContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
  },
  notificationLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    gap: 12,
  },
  notificationIconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.08)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  notificationInfo: {
    flex: 1,
    gap: 4,
  },
  notificationLabel: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
    letterSpacing: 0.1,
  },
  notificationDescription: {
    color: 'rgba(249,250,251,0.70)',
    fontSize: 12,
    lineHeight: 16,
    fontWeight: '500',
  },

  privacyCategoryBlock: {
    marginBottom: 8,
    gap: 10,
  },
  privacyCategoryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 4,
    marginTop: 4,
  },
  privacyCategoryTitle: {
    fontSize: 15,
    fontWeight: '800',
  },
  privacySettingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    gap: 12,
  },
  privacySettingText: {
    flex: 1,
    marginRight: 8,
    gap: 2,
  },
  privacySettingLabel: {
    color: LIGHT_TEXT,
    fontSize: 15,
    fontWeight: '700',
  },
  privacySettingDescription: {
    color: MUTED_TEXT,
    fontSize: 12,
    lineHeight: 16,
    fontWeight: '500',
  },
  privacyInfoCard: {
    marginTop: 8,
    padding: 16,
  },
  privacyInfoRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  privacyInfoText: {
    flex: 1,
    color: 'rgba(249,250,251,0.88)',
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '500',
  },

  // Availability Settings
  availabilityCard: {
    borderRadius: 20,
    padding: 0,
    marginBottom: 12,
  },
  availabilityContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
  },
  availabilityLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    gap: 12,
  },
  availabilityIconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.08)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  availabilityInfo: {
    flex: 1,
    gap: 4,
  },
  availabilityLabel: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
    letterSpacing: 0.1,
  },
  availabilityDescription: {
    color: 'rgba(249,250,251,0.70)',
    fontSize: 12,
    lineHeight: 16,
    fontWeight: '500',
  },

  // Log out / Delete account (Settings tab)
  logoutButtonWrap: { marginTop: 16, marginBottom: 8 },
  deleteAccountButtonWrap: { marginTop: 8, marginBottom: 24 },
  settingsLinkCard: {
    padding: 16,
    backgroundColor: 'rgba(255,255,255,0.04)',
  },
  settingsLinkTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 2,
  },
  settingsLinkSubtitle: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    fontWeight: '600',
  },
  deleteAccountCard: {},
  deleteAccountCardFilled: {
    padding: 16,
    backgroundColor: 'rgba(239,68,68,0.08)',
  },
  logoutCard: {
    padding: 16,
    backgroundColor: 'rgba(239,68,68,0.06)',
    borderWidth: 1.5,
    borderColor: 'rgba(239,68,68,0.25)',
  },
  logoutContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  logoutIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(239,68,68,0.14)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoutTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 2,
  },
  logoutSubtitle: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    fontWeight: '600',
  },
});
