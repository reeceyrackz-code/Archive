import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  Linking,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../../src/components/shared/ChromeGlyph';
import { router } from 'expo-router';

import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import { stripeConnectService } from '../../src/services/stripeConnectService';
import { businessOnboardingService } from '../../src/services/businessOnboardingService';

const SKY = colors.SKY;
const businessTheme = getAccountTheme('business');

type DebugStatus = {
  terms_status: string | null;
  terms_version: string | null;
  terms_accepted_at: string | null;
  terms_declined_at: string | null;
  stripe_connect_status: string | null;
  stripe_account_id: string | null;
  stripe_onboarding_started_at: string | null;
  stripe_onboarding_completed_at: string | null;
  stripe_details: Record<string, any> | null;
};

export default function BusinessStripeConnectTestScreen() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [busyAction, setBusyAction] = useState<string | null>(null);
  const [status, setStatus] = useState<DebugStatus | null>(null);

  const loadStatus = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('profiles')
        .select(
          'terms_status,terms_version,terms_accepted_at,terms_declined_at,stripe_connect_status,stripe_account_id,stripe_onboarding_started_at,stripe_onboarding_completed_at,stripe_details'
        )
        .eq('id', user.id)
        .maybeSingle();

      if (error) throw error;
      setStatus((data as DebugStatus) || null);
    } catch (error: any) {
      Alert.alert('Error', error?.message || 'Failed to load Stripe Connect debug status.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadStatus();
  }, [user?.id]);

  const runAction = async (key: string, fn: () => Promise<void>) => {
    try {
      setBusyAction(key);
      await fn();
      await loadStatus();
    } catch (error: any) {
      Alert.alert('Error', error?.message || 'Action failed.');
    } finally {
      setBusyAction(null);
    }
  };

  const resetTerms = async () => {
    if (!user?.id) return;
    await supabase
      .from('profiles')
      .update({
        terms_status: 'pending',
        terms_version: null,
        terms_accepted_at: null,
        terms_declined_at: null,
      } as any)
      .eq('id', user.id);
  };

  const resetStripe = async () => {
    if (!user?.id) return;
    await supabase
      .from('profiles')
      .update({
        stripe_connect_status: 'not_started',
        stripe_account_id: null,
        stripe_onboarding_started_at: null,
        stripe_onboarding_completed_at: null,
        stripe_details: {
          skipped_for_now: false,
          skipped_for_now_at: null,
        },
      } as any)
      .eq('id', user.id);
  };

  return (
    <View style={styles.container}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
      <SafeAreaView style={styles.container} edges={['top']}>
        <AppHeader title="Stripe Connect" accountType="business" />
        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
          showsVerticalScrollIndicator={false}
        >
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => router.back()}
            activeOpacity={0.85}
          >
            <Ionicons name="chevron-back" size={18} color={SKY} />
            <Text style={styles.backButtonText}>Back</Text>
          </TouchableOpacity>

          {loading ? (
            <View style={styles.loadingWrap}>
              <ActivityIndicator color={SKY} />
              <Text style={styles.loadingText}>Loading Stripe debug info...</Text>
            </View>
          ) : (
            <>
              <GlassCard style={styles.card} accountType="business">
                <Text style={styles.cardTitle}>Current status</Text>
                <Text style={styles.row}><Text style={styles.label}>Terms:</Text> {status?.terms_status || 'unknown'}</Text>
                <Text style={styles.row}><Text style={styles.label}>Terms version:</Text> {status?.terms_version || 'none'}</Text>
                <Text style={styles.row}><Text style={styles.label}>Stripe:</Text> {status?.stripe_connect_status || 'unknown'}</Text>
                <Text style={styles.row}><Text style={styles.label}>Stripe account:</Text> {status?.stripe_account_id || 'none'}</Text>
                <Text style={styles.row}><Text style={styles.label}>Accepted at:</Text> {status?.terms_accepted_at || 'none'}</Text>
                <Text style={styles.row}><Text style={styles.label}>Started at:</Text> {status?.stripe_onboarding_started_at || 'none'}</Text>
                <Text style={styles.row}><Text style={styles.label}>Completed at:</Text> {status?.stripe_onboarding_completed_at || 'none'}</Text>
              </GlassCard>

              <GlassCard style={styles.card} accountType="business">
                <Text style={styles.cardTitle}>Actions</Text>

                <TouchableOpacity
                  style={styles.primaryButton}
                  onPress={() => runAction('start', async () => {
                    const { url } = await stripeConnectService.createOnboardingLink();
                    await businessOnboardingService.startStripeConnect(user!.id, {
                      debug_started_at: new Date().toISOString(),
                      last_link_url: url,
                    });
                    await Linking.openURL(url);
                  })}
                  disabled={!!busyAction}
                >
                  {busyAction === 'start' ? <ActivityIndicator color="#0A1929" /> : <Text style={styles.primaryButtonText}>Start Stripe Connect</Text>}
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.secondaryButton}
                  onPress={() => runAction('sync', async () => {
                    await stripeConnectService.syncStatusFromStripe();
                  })}
                  disabled={!!busyAction}
                >
                  {busyAction === 'sync' ? <ActivityIndicator color="#fff" /> : <Text style={styles.secondaryButtonText}>Sync Stripe Status</Text>}
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.warnButton}
                  onPress={() => runAction('reset-terms', resetTerms)}
                  disabled={!!busyAction}
                >
                  {busyAction === 'reset-terms' ? <ActivityIndicator color="#fff" /> : <Text style={styles.warnButtonText}>Clear Terms Acceptance</Text>}
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.warnButton}
                  onPress={() => runAction('reset-stripe', resetStripe)}
                  disabled={!!busyAction}
                >
                  {busyAction === 'reset-stripe' ? <ActivityIndicator color="#fff" /> : <Text style={styles.warnButtonText}>Reset Stripe Connect Status</Text>}
                </TouchableOpacity>
              </GlassCard>

              <GlassCard style={styles.card} accountType="business">
                <Text style={styles.cardTitle}>Stripe details payload</Text>
                <Text style={styles.detailsText}>
                  {JSON.stringify(status?.stripe_details || {}, null, 2)}
                </Text>
              </GlassCard>
            </>
          )}
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollView: { flex: 1 },
  scrollContent: { paddingHorizontal: 20, paddingBottom: 28 },
  backButton: {
    alignSelf: 'flex-start',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 14,
    paddingHorizontal: 12,
    minHeight: 40,
    borderRadius: 999,
    backgroundColor: 'rgba(135,206,235,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.22)',
  },
  backButtonText: {
    color: SKY,
    fontSize: 13,
    fontWeight: '700',
  },
  loadingWrap: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 10, paddingTop: 80 },
  loadingText: { color: SKY, fontSize: 14 },
  card: { padding: 16, marginBottom: 16 },
  cardTitle: { color: '#F9FAFB', fontSize: 16, fontWeight: '800', marginBottom: 12 },
  row: { color: 'rgba(249,250,251,0.9)', fontSize: 13, marginBottom: 8, lineHeight: 18 },
  label: { color: SKY, fontWeight: '700' },
  primaryButton: {
    minHeight: 46,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: SKY,
    marginBottom: 10,
  },
  primaryButtonText: { color: '#0A1929', fontWeight: '800', fontSize: 14 },
  secondaryButton: {
    minHeight: 46,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(16,185,129,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.35)',
    marginBottom: 10,
  },
  secondaryButtonText: { color: '#F9FAFB', fontWeight: '800', fontSize: 14 },
  warnButton: {
    minHeight: 46,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(239,68,68,0.16)',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.32)',
    marginBottom: 10,
  },
  warnButtonText: { color: '#F9FAFB', fontWeight: '800', fontSize: 14 },
  detailsText: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 12,
    lineHeight: 18,
    fontFamily: 'Courier',
  },
});
