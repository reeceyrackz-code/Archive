/**
 * Business Earnings – Starling Bank–style layout. Stripe Connect for payouts.
 */
import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Animated,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../../src/components/shared/ChromeGlyph';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { supabase } from '../../src/lib/supabase';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GradientIconBox from '../../src/components/shared/GradientIconBox';
import { colors } from '../../src/constants/colors';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import LoadingScreen from '../../src/components/LoadingScreen';

const BG = colors.BG;
const SKY = colors.SKY;
const PAD = 20;

const formatCurrency = (amount: number): string =>
  new Intl.NumberFormat('en-GB', { style: 'currency', currency: 'GBP', minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(amount);

interface EarningsSummary {
  totalEarnings: number;
  thisMonth: number;
  lastMonth: number;
  pendingPayouts: number;
}

export default function BusinessEarnings() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme: businessTheme } = useAccountTheme();
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const [loading, setLoading] = useState(true);
  const [earnings, setEarnings] = useState<EarningsSummary>({
    totalEarnings: 0,
    thisMonth: 0,
    lastMonth: 0,
    pendingPayouts: 0,
  });

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 500, useNativeDriver: true }).start();
    if (user?.id) loadEarnings();
    else setLoading(false);
  }, [user?.id]);

  const loadEarnings = async () => {
    if (!user?.id) return;
    const organizationId = (user as any).organizationId ?? null;
    const isOrgUser = ['organization', 'business'].includes((user?.userType ?? '').toLowerCase());
    if (!isOrgUser || !organizationId) {
      setLoading(false);
      return;
    }
    try {
      setLoading(true);
      const { data: valeters, error: valErr } = await supabase
        .from('profiles')
        .select('id')
        .eq('organization_id', organizationId)
        .eq('user_type', 'valeter');
      if (valErr || !valeters?.length) {
        setEarnings({ totalEarnings: 0, thisMonth: 0, lastMonth: 0, pendingPayouts: 0 });
        setLoading(false);
        return;
      }
      const valeterIds = (valeters || []).map((v: any) => v.id) as string[];

      const { data: bookings, error } = await supabase
        .from('bookings')
        .select('id, price, status, completed_at, updated_at, created_at')
        .in('valeter_id', valeterIds);

      if (error) throw error;

      const paidStatuses = ['completed', 'closed', 'rated'];
      const rows = ((bookings || []) as { price: number; status?: string; completed_at: string | null; updated_at: string | null; created_at: string }[])
        .filter((b) => b.status && paidStatuses.includes(b.status));
      const totalEarnings = rows.reduce((sum, b) => sum + (Number(b.price) || 0), 0);

      const now = new Date();
      const firstDayThisMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const firstDayLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      const firstDayNextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1);

      const thisMonth = rows
        .filter((b) => {
          const date = b.completed_at || b.updated_at || b.created_at;
          return date && new Date(date) >= firstDayThisMonth && new Date(date) < firstDayNextMonth;
        })
        .reduce((sum, b) => sum + (Number(b.price) || 0), 0);

      const lastMonth = rows
        .filter((b) => {
          const date = b.completed_at || b.updated_at || b.created_at;
          return date && new Date(date) >= firstDayLastMonth && new Date(date) < firstDayThisMonth;
        })
        .reduce((sum, b) => sum + (Number(b.price) || 0), 0);

      setEarnings({
        totalEarnings: Math.round(totalEarnings * 100) / 100,
        thisMonth: Math.round(thisMonth * 100) / 100,
        lastMonth: Math.round(lastMonth * 100) / 100,
        pendingPayouts: 0,
      });
    } catch (e) {
      console.error('Error loading earnings:', e);
      setEarnings({ totalEarnings: 0, thisMonth: 0, lastMonth: 0, pendingPayouts: 0 });
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <LoadingScreen message="Loading earnings…" />;
  }

  return (
    <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
      <AppHeader title="Earnings" accountType="business" />
      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET, paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 24 }]}
      >
        <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
          {/* Starling-style main balance card */}
          <View style={styles.mainCard}>
            <Text style={styles.mainCardLabel}>Total balance</Text>
            <Text style={styles.mainCardValue}>{formatCurrency(earnings.totalEarnings)}</Text>
            <View style={styles.stripeBadge}>
              <Text style={styles.stripeBadgeText}>Earnings via Stripe Connect</Text>
            </View>
          </View>

          {/* Spaces / pots row */}
          <View style={styles.spacesRow}>
            <View style={styles.spaceCard}>
              <GradientIconBox icon="calendar" preset="green" boxSize={44} size={22} style={{ marginBottom: 14 }} />
              <Text style={styles.spaceValue}>{formatCurrency(earnings.thisMonth)}</Text>
              <Text style={styles.spaceLabel}>This month</Text>
            </View>
            <View style={styles.spaceCard}>
              <GradientIconBox icon="time" preset="amber" boxSize={44} size={22} style={{ marginBottom: 14 }} />
              <Text style={styles.spaceValue}>{formatCurrency(earnings.pendingPayouts)}</Text>
              <Text style={styles.spaceLabel}>Pending</Text>
            </View>
          </View>

          <TouchableOpacity
            style={styles.getPaidLink}
            onPress={async () => {
              await hapticFeedback('light');
              router.push('/business/stripe-connect' as any);
            }}
          >
            <GradientIconBox icon="wallet-outline" preset="green" boxSize={36} size={18} />
            <Text style={styles.getPaidLinkText}>Set up how you get paid</Text>
          </TouchableOpacity>

          {/* Recent activity */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Recent activity</Text>
            <View style={styles.activityCard}>
              <View style={styles.activityEmpty}>
                <GradientIconBox icon="wallet-outline" preset="sky" boxSize={56} size={28} />
                <Text style={styles.activityEmptyTitle}>No activity yet</Text>
                <Text style={styles.activityEmptySub}>Transactions will appear here</Text>
              </View>
            </View>
          </View>
        </Animated.View>
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12 },
  loadingText: { color: SKY, fontSize: 14 },
  scrollView: { flex: 1 },
  scrollContent: { paddingHorizontal: PAD },
  content: { paddingBottom: 24 },
  mainCard: {
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 24,
    paddingVertical: 28,
    paddingHorizontal: 24,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  mainCardLabel: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 15,
    fontWeight: '600',
    marginBottom: 6,
  },
  mainCardValue: {
    color: '#FFFFFF',
    fontSize: 36,
    fontWeight: '800',
    letterSpacing: -1,
  },
  stripeBadge: {
    alignSelf: 'flex-start',
    marginTop: 14,
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 10,
    backgroundColor: 'rgba(135,206,235,0.15)',
  },
  stripeBadgeText: {
    color: SKY,
    fontSize: 12,
    fontWeight: '600',
  },
  spacesRow: { flexDirection: 'row', gap: 14, marginBottom: 22 },
  spaceCard: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 20,
    padding: 20,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.06)',
  },
  spaceIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: 'rgba(16,185,129,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 14,
  },
  spaceValue: { color: '#FFFFFF', fontSize: 22, fontWeight: '800', letterSpacing: -0.3 },
  spaceLabel: { color: 'rgba(255,255,255,0.6)', fontSize: 13, fontWeight: '600', marginTop: 4 },
  getPaidLink: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginBottom: 28,
  },
  getPaidLinkText: { color: SKY, fontSize: 14, fontWeight: '600' },
  section: {},
  sectionTitle: {
    color: 'rgba(255,255,255,0.5)',
    fontSize: 13,
    fontWeight: '700',
    marginBottom: 12,
    letterSpacing: 0.3,
  },
  activityCard: {
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.06)',
    backgroundColor: 'rgba(255,255,255,0.03)',
    overflow: 'hidden',
  },
  activityEmpty: {
    alignItems: 'center',
    paddingVertical: 28,
    paddingHorizontal: 24,
  },
  activityEmptyTitle: { color: '#FFFFFF', fontSize: 16, fontWeight: '700', marginTop: 12 },
  activityEmptySub: { color: 'rgba(255,255,255,0.5)', fontSize: 13, marginTop: 4 },
});
