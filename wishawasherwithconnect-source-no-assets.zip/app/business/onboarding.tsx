import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  Image,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../../src/components/shared/ChromeGlyph';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import { colors } from '../../src/constants/colors';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';

const { width } = Dimensions.get('window');
const BG = colors.BG;
const SKY = colors.SKY;

const onboardingSlides = [
  {
    id: 1,
    title: 'Welcome to Wish a Wash for Businesses',
    description:
      'Manage your physical car wash locations, accept bookings, and grow your business with ease.',
    icon: 'business',
    color: '#3B82F6',
  },
  {
    id: 2,
    title: 'Add Your Locations',
    description:
      'Start by adding your physical car wash locations. Each location can accept bookings independently.',
    icon: 'location',
    color: '#10B981',
  },
  {
    id: 3,
    title: 'Invite Car Care Pros to Your Team',
    description:
      'Build your team by inviting car care pros to work at your locations. They can accept bookings and clock in/out.',
    icon: 'people',
    color: '#F59E0B',
  },
  {
    id: 4,
    title: 'Accept and Manage Bookings',
    description:
      'Receive booking requests, accept or reject them, and assign car care pros. Track everything in real-time.',
    icon: 'calendar',
    color: '#87CEEB',
  },
  {
    id: 5,
    title: 'Use AI Car Care Hub',
    description:
      'Access tips and guides on repair services, learn how to grow your business, and discover free marketing opportunities.',
    icon: 'bulb',
    color: '#EC4899',
  },
  {
    id: 6,
    title: 'Repair Services Benefits',
    description:
      'Offer repair services and benefit from free marketing. Attract environmentally conscious customers.',
    icon: 'leaf',
    color: '#10B981',
  },
  {
    id: 7,
    title: 'Terms & Policies',
    description:
      'Please review and agree to our Terms of Service and Privacy Policy to continue.',
    icon: 'document-text',
    color: '#87CEEB',
  },
];

export default function BusinessOnboarding() {
  const { updateUser } = useAuth();
  const scrollViewRef = useRef<ScrollView>(null);
  const insets = useSafeAreaInsets();
  const { theme: businessTheme } = useAccountTheme();
  const [currentSlide, setCurrentSlide] = useState(0);
  const fadeAnim = useRef(new Animated.Value(1)).current;

  const handleScroll = (event: any) => {
    const slideIndex = Math.round(event.nativeEvent.contentOffset.x / width);
    if (slideIndex !== currentSlide) {
      setCurrentSlide(slideIndex);
      hapticFeedback('light');
      Animated.sequence([
        Animated.timing(fadeAnim, { toValue: 0, duration: 200, useNativeDriver: true }),
        Animated.timing(fadeAnim, { toValue: 1, duration: 200, useNativeDriver: true }),
      ]).start();
    }
  };

  const goToSlide = (index: number) => {
    scrollViewRef.current?.scrollTo({ x: index * width, animated: true });
    setCurrentSlide(index);
    hapticFeedback('light');
  };

  const handleNext = () => {
    if (currentSlide < onboardingSlides.length - 1) {
      goToSlide(currentSlide + 1);
    } else {
      handleGetStarted();
    }
  };

  const markBusinessOnboardingComplete = async () => {
    try {
      await updateUser({ businessOnboarded: true });
      await AsyncStorage.setItem('onboarding_seen', 'business');
    } catch (e) {
      console.warn('[BusinessOnboarding] persist error:', e);
      await AsyncStorage.setItem('onboarding_seen', 'business');
    }
  };

  const handleGetStarted = async () => {
    await hapticFeedback('medium');
    await markBusinessOnboardingComplete();
    router.replace('/business/dashboard');
  };

  const handleSkip = handleGetStarted;

  return (
    <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      {/* Floating Header */}
      <AppHeader
        title="Welcome to Wish a Wash"
        showBack={false}
        rightAction={
          currentSlide < onboardingSlides.length - 1 ? (
            <TouchableOpacity
              onPress={handleSkip}
              style={styles.skipButton}
            >
              <Text style={styles.skipText}>Skip</Text>
            </TouchableOpacity>
          ) : null
        }
        accountType="business"
      />

      <View style={styles.contentWrapper}>
        <ScrollView
          ref={scrollViewRef}
          horizontal
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          onScroll={handleScroll}
          scrollEventThrottle={16}
          style={styles.slidesContainer}
        >
          {onboardingSlides.map((slide) => (
            <View key={slide.id} style={styles.slide}>
              <Animated.View style={[styles.slideContent, { opacity: fadeAnim }]}>
                <View style={styles.iconContainer}>
                  {slide.id === 1 ? (
                    <Image 
                      source={require('../assets/icon.png')} 
                      style={styles.logoImage} 
                      resizeMode="contain" 
                    />
                  ) : (
                    <View style={styles.iconWrapper}>
                      <Ionicons name={slide.icon as any} size={64} color={slide.color} />
                    </View>
                  )}
                </View>

                <Text style={styles.slideTitle}>{slide.title}</Text>
                <Text style={styles.slideDescription}>{slide.description}</Text>
              </Animated.View>
            </View>
          ))}
        </ScrollView>

        {/* Pagination Dots */}
        <View style={styles.pagination}>
          {onboardingSlides.map((slide, index) => (
            <TouchableOpacity
              key={`pagination-${slide.id}`}
              onPress={() => goToSlide(index)}
              style={[
                styles.dot,
                currentSlide === index && styles.dotActive,
                { backgroundColor: currentSlide === index ? SKY : 'rgba(135,206,235,0.3)' },
              ]}
            />
          ))}
        </View>

        {/* Navigation Buttons */}
        <View style={[styles.navigation, { paddingBottom: insets.bottom + 20 }]}>
          {currentSlide > 0 && (
            <TouchableOpacity
              onPress={() => goToSlide(currentSlide - 1)}
              style={styles.backButton}
            >
              <GlassCard style={styles.navButtonCard}>
                <Ionicons name="chevron-back" size={24} color={SKY} />
              </GlassCard>
            </TouchableOpacity>
          )}

          <TouchableOpacity
            onPress={handleNext}
            style={[styles.nextButton, currentSlide === 0 && styles.nextButtonFull]}
          >
            <LinearGradient
              colors={['#10B981', '#059669']}
              style={styles.nextButtonGradient}
            >
              <Text style={styles.nextButtonText}>
                {currentSlide === onboardingSlides.length - 1 ? 'Get Started' : 'Next'}
              </Text>
              <Ionicons
                name={currentSlide === onboardingSlides.length - 1 ? 'checkmark' : 'chevron-forward'}
                size={20}
                color="#FFFFFF"
              />
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  contentWrapper: {
    flex: 1,
    paddingTop: HEADER_CONTENT_OFFSET, // AppHeader is already floating
  },
  skipButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  skipText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  slidesContainer: {
    flex: 1,
  },
  slide: {
    width,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  slideContent: {
    alignItems: 'center',
    maxWidth: 400,
  },
  iconContainer: {
    marginBottom: 48,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoImage: {
    width: 100,
    height: 100,
  },
  iconWrapper: {
    width: 80,
    height: 80,
    justifyContent: 'center',
    alignItems: 'center',
  },
  slideTitle: {
    color: '#F9FAFB',
    fontSize: 26,
    fontWeight: '700',
    textAlign: 'center',
    marginBottom: 16,
    letterSpacing: -0.3,
    lineHeight: 34,
  },
  slideDescription: {
    color: 'rgba(249,250,251,0.75)',
    fontSize: 17,
    textAlign: 'center',
    lineHeight: 26,
    paddingHorizontal: 20,
  },
  pagination: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 20,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  dotActive: {
    width: 24,
    height: 8,
  },
  navigation: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingBottom: 20,
    gap: 12,
  },
  backButton: {
    width: 50,
  },
  navButtonCard: {
    width: 50,
    height: 50,
    borderRadius: 25,
    padding: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  nextButton: {
    flex: 1,
    borderRadius: 14,
    overflow: 'hidden',
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  nextButtonFull: {
    marginLeft: 0,
  },
  nextButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    paddingHorizontal: 32,
  },
  nextButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
});
