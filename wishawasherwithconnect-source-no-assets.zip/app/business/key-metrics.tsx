import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Platform } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { ChromeGlyph as Ionicons, type IconGlyphName } from '../../src/components/shared/ChromeGlyph';
import { router } from 'expo-router';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import { colors } from '../../src/constants/colors';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';
import AnimatedProgress, { type TierPalette } from '../../src/components/booking/AnimatedProgress';
import GlassCard from '../../src/components/booking/GlassCard';
import { DashboardGlassSection } from '../../src/components/shared/DashboardGlassSection';
import LoadingScreen from '../../src/components/LoadingScreen';
import { LocationStyleIconBox, GRADIENT_PRESETS } from '../../src/components/shared/GradientIconBox';

const SKY = colors.SKY ?? '#38BDF8';

const clamp = (v: number, min: number, max: number) => Math.max(min, Math.min(max, v));

/** Ring chrome matches account tier (profiles / users tier field). */
const ACCOUNT_TIER_PALETTE: Record<string, TierPalette> = {
  bronze: { fill: '#CD7F32', glow: '#E8A87C' },
  silver: { fill: '#94A3B8', glow: '#E2E8F0' },
  gold: { fill: '#D97706', glow: '#FDE68A' },
  platinum: { fill: '#CBD5E1', glow: '#F8FAFC' },
  emerald: { fill: '#22D3EE', glow: '#67E8F9' },
};

const WEEK_SPIN_DEAD: string[] = ['#EF4444', '#DC2626', '#991B1B', '#F87171'];
const WEEK_SPIN_ACTIVE: string[] = ['#10B981', '#34D399', '#059669', '#6EE7B7'];
const TEAM_SPIN: string[] = ['#14B8A6', '#5EEAD4', '#0D9488', '#2DD4BF'];

type BookingRow = { id: string; status: string; created_at: string };

export default function BusinessKeyMetricsScreen() {
  const { user } = useAuth();
  const accountTierKey = String(user?.tier ?? 'bronze').toLowerCase();
  const accountTierPalette =
    ACCOUNT_TIER_PALETTE[accountTierKey] ?? ACCOUNT_TIER_PALETTE.bronze;
  const accountTierSpin = [
    accountTierPalette.glow,
    accountTierPalette.fill,
    accountTierPalette.glow,
    accountTierPalette.fill,
  ];
  const insets = useSafeAreaInsets();
  const { theme: businessTheme } = useAccountTheme();
  const accent = businessTheme.primary;
  const organizationId = user?.organizationId ?? null;
  const isOrgUser = ['organization', 'business'].includes((user?.userType ?? '').toLowerCase());

  const [loading, setLoading] = useState(true);
  const [bookingsThisWeek, setBookingsThisWeek] = useState(0);
  const [lastWeekBookings, setLastWeekBookings] = useState(0);
  const [completionRate, setCompletionRate] = useState(0);
  const [valetersOnline, setValetersOnline] = useState(0);

  const getValeterIds = useCallback(async (): Promise<string[]> => {
    if (!organizationId) return [];
    try {
      const { data: valeters, error: valErr } = await supabase
        .from('profiles')
        .select('id')
        .eq('organization_id', organizationId)
        .eq('user_type', 'valeter');
      if (valErr) return [];
      return (valeters || []).map((v: { id: string }) => v.id);
    } catch {
      return [];
    }
  }, [organizationId]);

  const loadLastWeekBookings = useCallback(async (): Promise<number> => {
    if (!organizationId) return 0;
    try {
      const valeterIds = await getValeterIds();
      if (valeterIds.length === 0) return 0;
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      const twoWeeksAgo = new Date(weekAgo);
      twoWeeksAgo.setDate(twoWeeksAgo.getDate() - 7);
      const { count, error } = await supabase
        .from('bookings')
        .select('id', { count: 'exact', head: true })
        .in('valeter_id', valeterIds)
        .gte('created_at', twoWeeksAgo.toISOString())
        .lt('created_at', weekAgo.toISOString());
      if (error) throw error;
      return count || 0;
    } catch {
      return 0;
    }
  }, [organizationId, getValeterIds]);

  const loadBookingMetrics = useCallback(async () => {
    if (!organizationId) {
      return { bookingsThisWeek: 0, completionRate: 0 };
    }
    const valeterIds = await getValeterIds();
    if (valeterIds.length === 0) {
      return { bookingsThisWeek: 0, completionRate: 0 };
    }
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    const { data: bookings, error } = await supabase
      .from('bookings')
      .select('id, status, created_at')
      .in('valeter_id', valeterIds)
      .order('created_at', { ascending: false })
      .limit(200);
    if (error) throw error;
    const rows = (bookings || []) as BookingRow[];
    const bookingsThisWeek = rows.filter((b) => {
      const t = new Date(b.created_at).getTime();
      return Number.isFinite(t) && t >= weekAgo.getTime();
    }).length;
    const completed = rows.filter((b) => b.status === 'completed').length;
    const cancelled = rows.filter((b) => b.status === 'cancelled').length;
    const finished = completed + cancelled;
    const completionRate = finished > 0 ? Math.round((completed / finished) * 100) : 0;
    return { bookingsThisWeek, completionRate };
  }, [organizationId, getValeterIds]);

  const loadTeamCount = useCallback(async (): Promise<number> => {
    if (!organizationId) return 0;
    try {
      const { count, error } = await supabase
        .from('profiles')
        .select('id', { count: 'exact', head: true })
        .eq('organization_id', organizationId)
        .eq('user_type', 'valeter');
      if (error) throw error;
      return count || 0;
    } catch {
      return 0;
    }
  }, [organizationId]);

  useEffect(() => {
    if (!isOrgUser || !organizationId) {
      setLoading(false);
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        setLoading(true);
        const [metrics, team, lastWeek] = await Promise.all([
          loadBookingMetrics(),
          loadTeamCount(),
          loadLastWeekBookings(),
        ]);
        if (cancelled) return;
        setBookingsThisWeek(metrics.bookingsThisWeek);
        setCompletionRate(metrics.completionRate);
        setValetersOnline(team);
        setLastWeekBookings(lastWeek);
      } catch (e) {
        console.error('[BusinessKeyMetrics]', e);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [isOrgUser, organizationId, loadBookingMetrics, loadTeamCount, loadLastWeekBookings]);

  const weeklyStreakDiff = bookingsThisWeek - lastWeekBookings;
  const weekRingProgress =
    lastWeekBookings > 0
      ? clamp(Math.round((bookingsThisWeek / Math.max(lastWeekBookings, 1)) * 100), 0, 100)
      : clamp(bookingsThisWeek * 14, 0, 100);
  const teamRingProgress = clamp(valetersOnline * 28, 0, 100);

  if (!isOrgUser || !organizationId) {
    return (
      <View style={styles.container}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="business" />
        <SafeAreaView style={styles.container} edges={['top']}>
          <AppHeader title="Key metrics" accountType="business" showBack />
          <View style={styles.emptyWrap}>
            <Text style={styles.emptyText}>Sign in with a business account to see metrics.</Text>
            <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
              <Text style={styles.backBtnText}>Go back</Text>
            </TouchableOpacity>
          </View>
        </SafeAreaView>
      </View>
    );
  }

  if (loading) {
    return (
      <View style={styles.container}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="business" />
        <SafeAreaView style={styles.container} edges={['top']}>
          <LoadingScreen message="Loading metrics…" />
        </SafeAreaView>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />
      <SafeAreaView style={styles.container} edges={['top']}>
        <AppHeader title="Key metrics" accountType="business" showBack />
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[
            styles.scrollContent,
            {
              paddingTop: HEADER_CONTENT_OFFSET,
              paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 24,
            },
          ]}
        >
          <Text style={styles.intro}>
            Digital rings summarise each KPI. Open the dashboard quick action anytime — rings stay here when you have recent jobs on the home screen.
          </Text>

          <DashboardGlassSection palette="business" tone="frame" innerStyle={styles.sectionInner}>
            <MetricRingCard
              title="This week"
              subtitle="Bookings in the last 7 days — ring goes green after your first wash"
              accent={accent}
              ringProgress={weekRingProgress}
              centerMain={String(bookingsThisWeek)}
              centerSub="bookings"
              trendDiff={weeklyStreakDiff}
              ringColor={SKY}
              headerIcon="car-sport-outline"
              headerPreset="cyan"
              tierPalette={
                bookingsThisWeek < 1
                  ? { fill: '#EF4444', glow: '#FCA5A5' }
                  : { fill: '#10B981', glow: '#6EE7B7' }
              }
              spinPalette={bookingsThisWeek < 1 ? WEEK_SPIN_DEAD : WEEK_SPIN_ACTIVE}
              sequentialSpin
              glassCenter
            />
            <MetricRingCard
              title="Completion rate"
              subtitle={`Partner tier: ${accountTierKey} — ring colours match your level`}
              accent={accent}
              ringProgress={clamp(completionRate, 0, 100)}
              centerMain={String(Math.round(completionRate))}
              centerSub="%"
              trendDiff={null}
              ringColor="#10B981"
              showBuiltInPercent
              headerIcon="medal-outline"
              headerPreset="amber"
              tierPalette={accountTierPalette}
              spinPalette={accountTierSpin}
              sequentialSpin
              glassCenter
            />
            <MetricRingCard
              title="Team"
              subtitle="Car Care Pros on your organisation"
              accent={accent}
              ringProgress={teamRingProgress}
              centerMain={String(valetersOnline)}
              centerSub="pros"
              trendDiff={null}
              ringColor="#14B8A6"
              headerIcon="people-outline"
              headerPreset="teal"
              tierPalette={{ fill: '#14B8A6', glow: '#5EEAD4' }}
              spinPalette={TEAM_SPIN}
              sequentialSpin
              glassCenter
            />
          </DashboardGlassSection>
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

function MetricRingCard({
  title,
  subtitle,
  accent,
  ringProgress,
  centerMain,
  centerSub,
  trendDiff,
  ringColor,
  showBuiltInPercent,
  tierPalette,
  spinPalette,
  sequentialSpin,
  glassCenter,
  headerIcon,
  headerPreset = 'sky',
}: {
  title: string;
  subtitle: string;
  accent: string;
  ringProgress: number;
  centerMain: string;
  centerSub: string;
  trendDiff: number | null;
  ringColor: string;
  showBuiltInPercent?: boolean;
  tierPalette: TierPalette;
  spinPalette: string[];
  sequentialSpin?: boolean;
  glassCenter?: boolean;
  headerIcon?: IconGlyphName;
  headerPreset?: keyof typeof GRADIENT_PRESETS;
}) {
  return (
    <GlassCard style={styles.metricCard} accountType="business" borderColor={`${accent}35`}>
      <View style={styles.metricRow}>
        <View style={[styles.ringGlassPlate, { borderColor: `${accent}40`, shadowColor: accent }]}>
          <View style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(15,23,42,0.35)' }]} />
          <BlurView
            intensity={Platform.OS === 'ios' ? 36 : 56}
            tint="dark"
            style={StyleSheet.absoluteFill}
            {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
          />
          <LinearGradient
            colors={['rgba(255,255,255,0.12)', 'transparent']}
            start={{ x: 0, y: 0 }}
            end={{ x: 0, y: 0.55 }}
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
          />
          <View style={styles.ringWrap}>
            <AnimatedProgress
              progress={ringProgress}
              size={108}
              strokeWidth={9}
              showPercentage={!!showBuiltInPercent}
              color={ringColor}
              futuristic
              gamified
              tierPalette={tierPalette}
              spinPalette={spinPalette}
              sequentialSpin={sequentialSpin}
              glassCenter={glassCenter}
            />
            {!showBuiltInPercent ? (
              <View style={styles.ringCenterOverlay} pointerEvents="none">
                <Text style={styles.ringCenterMain} numberOfLines={1}>
                  {centerMain}
                </Text>
                <Text style={styles.ringCenterSub} numberOfLines={1}>
                  {centerSub}
                </Text>
              </View>
            ) : null}
          </View>
        </View>
        <View style={styles.metricCopy}>
          <View style={styles.metricTitleRow}>
            {headerIcon ? (
              <LocationStyleIconBox variant="inline" icon={headerIcon} preset={headerPreset} />
            ) : null}
            <Text style={[styles.metricTitle, headerIcon && { flex: 1 }]}>{title}</Text>
          </View>
          <Text style={styles.metricSubtitle}>{subtitle}</Text>
          {trendDiff != null && trendDiff !== 0 ? (
            <View style={styles.trendRow}>
              <Ionicons
                name={trendDiff > 0 ? 'trending-up' : 'trending-down'}
                size={16}
                color={trendDiff > 0 ? '#10B981' : 'rgba(239,68,68,0.9)'}
              />
              <Text style={[styles.trendText, trendDiff > 0 ? styles.trendUp : styles.trendDown]}>
                {Math.abs(trendDiff)} vs prior week
              </Text>
            </View>
          ) : null}
        </View>
      </View>
    </GlassCard>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollContent: { paddingHorizontal: 16 },
  intro: {
    color: 'rgba(249,250,251,0.65)',
    fontSize: 13,
    lineHeight: 18,
    marginBottom: 16,
    fontWeight: '500',
  },
  sectionInner: { paddingVertical: 12, paddingHorizontal: 12 },
  metricCard: { padding: 16, marginBottom: 14 },
  metricRow: { flexDirection: 'row', alignItems: 'center', gap: 18 },
  ringGlassPlate: {
    width: 120,
    height: 120,
    borderRadius: 60,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.22,
    shadowRadius: 12,
    elevation: 6,
  },
  ringWrap: {
    width: 108,
    height: 108,
    alignItems: 'center',
    justifyContent: 'center',
  },
  ringCenterOverlay: {
    position: 'absolute',
    width: 108,
    height: 108,
    alignItems: 'center',
    justifyContent: 'center',
  },
  ringCenterMain: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '800',
  },
  ringCenterSub: {
    color: 'rgba(249,250,251,0.55)',
    fontSize: 11,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.4,
    marginTop: 2,
  },
  metricCopy: { flex: 1, minWidth: 0 },
  metricTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 4,
  },
  metricTitle: { color: '#F9FAFB', fontSize: 17, fontWeight: '800' },
  metricSubtitle: { color: 'rgba(249,250,251,0.58)', fontSize: 12, lineHeight: 16, fontWeight: '600' },
  trendRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 10 },
  trendText: { fontSize: 13, fontWeight: '700' },
  trendUp: { color: '#10B981' },
  trendDown: { color: 'rgba(239,68,68,0.95)' },
  emptyWrap: { flex: 1, padding: 24, justifyContent: 'center' },
  emptyText: { color: 'rgba(249,250,251,0.7)', fontSize: 15, textAlign: 'center', marginBottom: 16 },
  backBtn: { alignSelf: 'center', paddingVertical: 12, paddingHorizontal: 20 },
  backBtnText: { color: SKY, fontSize: 16, fontWeight: '700' },
});
