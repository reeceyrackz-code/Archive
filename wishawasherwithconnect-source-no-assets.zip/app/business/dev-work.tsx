import React from 'react';
import DevWorkAuditScreen from '../../src/components/dev/DevWorkAuditScreen';
import {
  BUSINESS_DEV_WORK_INTRO,
  BUSINESS_DEV_WORK_SECTIONS,
} from '../../src/constants/devWorkChecklists';

export default function BusinessDevWorkScreen() {
  return (
    <DevWorkAuditScreen
      accountType="business"
      title="Dev work"
      intro={BUSINESS_DEV_WORK_INTRO}
      sections={BUSINESS_DEV_WORK_SECTIONS}
      footerNote="Stripe Connect, payout webhooks, and business account deletion must be implemented server-side. Cross-check app/business/stripe-connect.tsx for current UX flow."
    />
  );
}
