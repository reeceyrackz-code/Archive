import React, { useEffect, useRef, useState } from 'react';
import {
  Alert,
  Animated,
  KeyboardAvoidingView,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  TouchableOpacity,
  TouchableWithoutFeedback,
  View,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import type { IconGlyphName } from '../../src/components/shared/iconGlyphTypes';
import { ChromeGlyph as Ionicons } from '../../src/components/shared/ChromeGlyph';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import LoadingScreen from '../../src/components/LoadingScreen';
import { colors } from '../../src/constants/colors';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import BusinessSheetBackground from '../../src/components/shared/BusinessSheetBackground';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import { LocationStyleIconBox } from '../../src/components/shared/GradientIconBox';
import { accentToGradient } from '../../src/utils/accentGradient';
import { WASH_DEFINITIONS, getVehicleSizeAdjustmentGBP, type VehicleSize } from '../../src/pricing/pricingEngine';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';
import ContinueCTAButton from '../../src/components/ui/ContinueCTAButton';

const BG = colors.BG;
const SIZES: VehicleSize[] = ['SMALL', 'MEDIUM', 'LARGE', 'XL', 'XXL'];

const TIER_ICON: Record<string, IconGlyphName> = {
  BRONZE: 'water-outline',
  SILVER: 'sparkles-outline',
  GOLD: 'trophy-outline',
  PLATINUM: 'diamond-outline',
  DIAMOND: 'sparkles',
};

const TIER_HEX: Record<string, string> = {
  BRONZE: '#CD7F32',
  SILVER: '#C0C0C0',
  GOLD: '#FFD700',
  PLATINUM: '#E5E4E2',
  DIAMOND: '#22D3EE',
};

type ServiceConfig = {
  id: string;
  name: string;
  description: string;
  tier: string;
  enabled: boolean;
  prices: Record<VehicleSize, number>;
};

export default function BusinessServices() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme: businessTheme } = useAccountTheme();
  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const textMain = businessTheme.textPrimary ?? '#F9FAFB';
  const muted = businessTheme.textSecondary ?? 'rgba(249,250,251,0.72)';
  const glassBorder = businessTheme.glassBorder;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [services, setServices] = useState<ServiceConfig[]>([]);
  const [editingServiceId, setEditingServiceId] = useState<string | null>(null);
  const [priceDraft, setPriceDraft] = useState<Record<VehicleSize, string> | null>(null);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 450,
      useNativeDriver: true,
    }).start();
  }, [fadeAnim]);

  useEffect(() => {
    if (user?.id) {
      loadServices();
    } else {
      setLoading(false);
    }
  }, [user?.id]);

  const loadServices = async () => {
    try {
      setLoading(true);
      const mapped: ServiceConfig[] = WASH_DEFINITIONS.filter((wash) => wash.isMobile).map((wash) => {
        const prices = SIZES.reduce((acc, size) => {
          acc[size] = wash.basePriceSmallGBP + getVehicleSizeAdjustmentGBP(size);
          return acc;
        }, {} as Record<VehicleSize, number>);

        return {
          id: wash.id,
          name: wash.label,
          description: wash.description,
          tier: wash.tier,
          enabled: true,
          prices,
        };
      });
      setServices(mapped);
    } catch (error) {
      console.error('[BusinessServices] Failed to load services:', error);
      Alert.alert('Error', 'Failed to load services.');
    } finally {
      setLoading(false);
    }
  };

  const filteredServices = services;

  const toggleService = async (serviceId: string) => {
    await hapticFeedback('light');
    setServices((prev) => prev.map((service) => (service.id === serviceId ? { ...service, enabled: !service.enabled } : service)));
  };

  const getServicePriceRange = (service: ServiceConfig) => {
    const values = SIZES.map((size) => service.prices[size]);
    return { min: Math.min(...values), max: Math.max(...values) };
  };

  const getSelectedService = () => services.find((service) => service.id === editingServiceId) ?? null;

  const closePricingSheet = () => {
    setEditingServiceId(null);
    setPriceDraft(null);
  };

  const commitPricingDraft = () => {
    if (!editingServiceId || !priceDraft) {
      closePricingSheet();
      return;
    }
    const parseMoney = (raw: string) => {
      const cleaned = raw.replaceAll(',', '').trim();
      if (cleaned === '' || cleaned === '.') return 0;
      const n = Number.parseFloat(cleaned);
      return Number.isFinite(n) ? Math.max(0, n) : 0;
    };
    setServices((prev) =>
      prev.map((service) => {
        if (service.id !== editingServiceId) return service;
        const nextPrices = { ...service.prices };
        for (const size of SIZES) {
          nextPrices[size] = parseMoney(priceDraft[size] ?? '');
        }
        return { ...service, prices: nextPrices };
      })
    );
    closePricingSheet();
  };

  const handleSave = async () => {
    if (!user?.id) return;
    try {
      setSaving(true);
      Alert.alert('Saved', 'Services configuration updated.');
    } catch (error) {
      console.error('[BusinessServices] Failed to save services:', error);
      Alert.alert('Error', 'Could not save services configuration.');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
        <LoadingScreen message="Loading services..." />
      </SafeAreaView>
    );
  }

  const selectedService = getSelectedService();

  return (
    <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />
      <AppHeader title="Services & pricing" accountType="business" />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
        scrollEventThrottle={16}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingTop: HEADER_CONTENT_OFFSET, paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 24 },
        ]}
      >
        <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
          <Text style={[styles.heroKicker, { color: muted }]}>Configuration</Text>
          <Text style={[styles.heroTitle, { color: textMain }]}>Your wash tiers</Text>
          <Text style={[styles.heroSubtitle, { color: muted }]}>
            Enable tiers and set per–vehicle-size pricing. Matches how valeters see their services list.
          </Text>

          <View style={styles.listSection}>
            {filteredServices.map((service) => {
              const range = getServicePriceRange(service);
              const tierHex = TIER_HEX[service.tier] ?? businessTheme.primary;
              const tierIcon = TIER_ICON[service.tier] ?? 'water-outline';
              return (
                <View key={service.id} style={[styles.priceRow, { borderColor: glassBorder }]}>
                  <View style={styles.priceRowTop}>
                    <View style={styles.priceRowLead}>
                      <LocationStyleIconBox variant="inline" icon={tierIcon} colors={accentToGradient(tierHex)} />
                      <View style={styles.priceRowTitles}>
                        <View style={styles.priceRowTitleLine}>
                          <Text style={[styles.priceRowTitle, { color: textMain }]} numberOfLines={2}>
                            {service.name}
                          </Text>
                          <View style={[styles.tierBadge, { backgroundColor: `${tierHex}35`, borderColor: tierHex }]}>
                            <Text style={styles.tierBadgeText}>{service.tier}</Text>
                          </View>
                        </View>
                        <Text style={[styles.priceRowSub, { color: muted }]} numberOfLines={2}>
                          {service.description}
                        </Text>
                        <Text style={[styles.priceRowRange, { color: textMain }]}>
                          £{range.min.toFixed(2)} – £{range.max.toFixed(2)}
                        </Text>
                      </View>
                    </View>
                    <View style={styles.priceRowActions}>
                      <Switch
                        value={service.enabled}
                        onValueChange={() => toggleService(service.id)}
                        trackColor={{ false: 'rgba(255,255,255,0.15)', true: businessTheme.primary }}
                        thumbColor={service.enabled ? '#FFFFFF' : '#9CA3AF'}
                        ios_backgroundColor="rgba(255,255,255,0.15)"
                      />
                      <TouchableOpacity
                        onPress={async () => {
                          await hapticFeedback('light');
                          setPriceDraft(
                            SIZES.reduce((acc, size) => {
                              acc[size] = String(service.prices[size]);
                              return acc;
                            }, {} as Record<VehicleSize, string>)
                          );
                          setEditingServiceId(service.id);
                        }}
                        hitSlop={8}
                        accessibilityLabel="Edit pricing"
                      >
                        <LocationStyleIconBox variant="inline" icon="chevron-forward" colors={accentToGradient(businessTheme.primary)} />
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              );
            })}
          </View>

          <ContinueCTAButton
            title="Save services"
            onPress={handleSave}
            accentColor={businessTheme.primary}
            disabled={saving}
            loading={saving}
            style={styles.saveCta}
            leading={<Ionicons name="save-outline" size={20} color={colors.textOnDarkPrimary} />}
          />
        </Animated.View>
      </Animated.ScrollView>

      <Modal visible={!!editingServiceId} transparent animationType="slide" onRequestClose={closePricingSheet}>
        <View style={styles.modalRoot}>
          <TouchableWithoutFeedback onPress={closePricingSheet}>
            <View style={styles.modalBackdrop} />
          </TouchableWithoutFeedback>

          <KeyboardAvoidingView
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
            style={styles.modalSheetWrap}
            pointerEvents="box-none"
          >
            <View style={[styles.bottomSheet, { paddingBottom: Math.max(insets.bottom, 22), borderColor: glassBorder }]}>
              <BusinessSheetBackground />
              <View style={styles.sheetHandle} />
              <Text style={styles.sheetTitle}>{selectedService?.name ?? 'Service pricing'}</Text>
              <Text style={styles.sheetSubtitle}>Set prices by vehicle size</Text>

              <ScrollView
                style={styles.sheetBody}
                showsVerticalScrollIndicator={false}
                keyboardShouldPersistTaps="handled"
              >
                {priceDraft
                  ? SIZES.map((size) => (
                      <View key={size} style={styles.inputRow}>
                        <Text style={styles.inputLabel}>{size}</Text>
                        <View style={styles.inputWrap}>
                          <Text style={styles.currency}>£</Text>
                          <TextInput
                            style={styles.input}
                            value={priceDraft[size]}
                            onChangeText={(text) =>
                              setPriceDraft((prev) => (prev ? { ...prev, [size]: text } : prev))
                            }
                            keyboardType={Platform.OS === 'ios' ? 'decimal-pad' : 'numeric'}
                            placeholder="0.00"
                            placeholderTextColor="rgba(255,255,255,0.35)"
                            selectTextOnFocus
                          />
                        </View>
                      </View>
                    ))
                  : null}
              </ScrollView>

              <ContinueCTAButton title="Save" onPress={commitPricingDraft} accentColor={businessTheme.primary} style={styles.sheetCta} />
            </View>
          </KeyboardAvoidingView>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  scrollView: { flex: 1 },
  scrollContent: { paddingHorizontal: 20 },
  content: { gap: 0 },
  heroKicker: { marginBottom: 6, fontSize: 12, fontWeight: '800', letterSpacing: 1.2, textTransform: 'uppercase' },
  heroTitle: { fontSize: 26, fontWeight: '800', letterSpacing: -0.4, marginBottom: 8 },
  heroSubtitle: { fontSize: 14, lineHeight: 21, marginBottom: 22 },
  listSection: { gap: 12, paddingBottom: 8 },
  priceRow: {
    borderRadius: 18,
    borderWidth: 1,
    padding: 16,
    backgroundColor: 'rgba(255,255,255,0.03)',
  },
  priceRowTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  priceRowLead: { flexDirection: 'row', alignItems: 'center', flex: 1, gap: 12, minWidth: 0 },
  priceRowTitles: { flex: 1, minWidth: 0 },
  priceRowTitleLine: { flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' },
  priceRowTitle: { fontSize: 16, fontWeight: '800', flexShrink: 1 },
  priceRowSub: { fontSize: 13, fontWeight: '600', marginTop: 5, lineHeight: 18 },
  priceRowRange: { fontSize: 15, fontWeight: '800', marginTop: 8 },
  priceRowActions: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  tierBadge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
    borderWidth: 1,
  },
  tierBadgeText: {
    color: '#F9FAFB',
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  saveCta: { marginTop: 28, marginBottom: 8 },
  modalRoot: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  modalBackdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(5,13,20,0.72)',
  },
  modalSheetWrap: {
    width: '100%',
    zIndex: 2,
    elevation: 24,
  },
  bottomSheet: {
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    overflow: 'hidden',
    paddingHorizontal: 20,
    paddingTop: 12,
    borderWidth: 1,
    maxHeight: '80%',
    backgroundColor: 'transparent',
  },
  sheetHandle: {
    width: 40,
    height: 5,
    borderRadius: 5,
    backgroundColor: 'rgba(255,255,255,0.26)',
    alignSelf: 'center',
    marginBottom: 16,
  },
  sheetTitle: { color: '#F9FAFB', fontSize: 20, fontWeight: '700', textAlign: 'center' },
  sheetSubtitle: { color: 'rgba(249,250,251,0.72)', fontSize: 14, textAlign: 'center', marginTop: 4, marginBottom: 18 },
  sheetBody: { maxHeight: 360 },
  sheetCta: { marginTop: 12 },
  inputRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.08)',
  },
  inputLabel: { color: '#F9FAFB', fontSize: 15, fontWeight: '700' },
  inputWrap: {
    width: 118,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.16)',
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  currency: { color: 'rgba(249,250,251,0.65)', fontSize: 14, marginRight: 4 },
  input: { color: '#F9FAFB', fontSize: 15, fontWeight: '700', flex: 1, padding: 0 },
});
