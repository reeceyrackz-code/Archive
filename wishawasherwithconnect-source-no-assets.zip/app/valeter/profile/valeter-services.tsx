
/**
 * Valeter services & pricing — wash tiers, detailing, and repairs (Supabase valeter_service_settings).
 */
import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Alert,
  Animated,
  TextInput,
  Modal,
  KeyboardAvoidingView,
  Platform,
  Pressable,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import type { IconGlyphName } from '../../../src/components/shared/iconGlyphTypes';
import { useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import LoadingScreen from '../../../src/components/LoadingScreen';
import { colors } from '../../../src/constants/colors';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import { LocationStyleIconBox } from '../../../src/components/shared/GradientIconBox';
import InfoIconButton from '../../../src/components/shared/InfoIconButton';
import { accentToGradient } from '../../../src/utils/accentGradient';
import ContinueCTAButton from '../../../src/components/ui/ContinueCTAButton';

const BG = colors.BG ?? '#0F2847';
const SKY = colors.SKY ?? '#87CEEB';
const BUSINESS_PRIMARY = '#7DD3FC';

// -------- Tier & detailing defs (aligned with valeter_profile) --------
type TierKey = 'bronze' | 'silver' | 'gold' | 'platinum' | 'emerald';
type VehicleSizeKey = 'small' | 'medium' | 'large' | 'xl' | 'xxl';
const TIER_DEFS: Array<{
  key: TierKey;
  name: string;
  icon: IconGlyphName;
  color: string;
  tier: string;
}> = [
  { key: 'bronze', name: 'Bronze Wash', icon: 'water-outline', color: '#CD7F32', tier: 'BRONZE' },
  { key: 'silver', name: 'Silver Wash', icon: 'sparkles-outline', color: '#C0C0C0', tier: 'SILVER' },
  { key: 'gold', name: 'Gold Wash', icon: 'trophy-outline', color: '#FFD700', tier: 'GOLD' },
  { key: 'platinum', name: 'Platinum Wash', icon: 'diamond-outline', color: '#E5E4E2', tier: 'PLATINUM' },
  { key: 'emerald', name: 'Diamond Wash', icon: 'sparkles', color: '#22D3EE', tier: 'DIAMOND' },
];

const STANDARD_TIER_DESCRIPTIONS: Record<string, { description: string; includes: string[]; bestFor: string }> = {
  bronze: {
    description: 'A quick refresh for your vehicle. Choose either an exterior hand wash or a light interior clean including vacuuming and surface wipe-downs.',
    includes: ['Your choice: exterior hand wash OR light interior clean', 'Exterior option: safe wash, wheels, rinse, dry, exterior glass', 'Interior option: vacuum, surface wipe-downs, light cabin tidy', 'Fast and affordable'],
    bestFor: 'Maintenance between deeper valets.',
  },
  silver: {
    description: 'A balanced clean inside and out. Includes an exterior hand wash plus a light interior refresh with vacuuming, surface cleaning, and a tidy finish.',
    includes: ['Exterior hand wash, wheels and dry', 'Interior vacuum (seats, carpets, boot)', 'Dashboard, console and trims wiped', 'Interior and exterior glass cleaned', 'Tyre dressing and light spray wax where included'],
    bestFor: 'Regular maintenance and everyday cleanliness.',
  },
  gold: {
    description: 'A full interior deep clean designed to restore your vehicle from the inside out. Includes deep vacuuming, stain removal, upholstery and carpet treatment.',
    includes: ['Deep vacuum throughout cabin and boot', 'Stain treatment and upholstery / carpet care', 'Seats, carpets and mats shampooed or refreshed', 'All interior surfaces, trims and touchpoints detailed', 'Leather cleaned and dressed where applicable', 'Headliner and hard-to-reach areas addressed', 'Interior glass and finishes refreshed', 'Air freshener to finish'],
    bestFor: 'Vehicles needing a deep interior restoration.',
  },
  platinum: {
    description: 'A complete interior and exterior valet with enhanced attention to detail. Includes a thorough wash, detailed interior cleaning, and finishing touches.',
    includes: ['Thorough exterior wash, wheels and arches', 'Interior deep clean aligned with Gold cabin standard', 'Trims, glass and surfaces finished to a high standard', 'Enhanced attention to detail inside and out', 'Finishing touches for a clean, fresh presentation'],
    bestFor: 'Full vehicle refresh in one visit.',
  },
  emerald: {
    description: 'Our highest level service delivering a full vehicle transformation. Deep interior clean, detailed exterior wash, and premium finishing.',
    includes: ['Deep interior clean plus detailed exterior wash', 'Paint decontamination and enhancement where appropriate', 'Upholstery / leather care and interior sanitisation', 'Machine or hand finishing for gloss and clarity', 'Long-lasting protection or sealant where included', 'Fine detailing on edges, trims and glass', 'Premium finish aimed at near showroom presentation'],
    bestFor: 'Premium care and a near showroom finish.',
  },
};

type ServiceDescBlock = { description: string; includes: string[]; bestFor: string };
const ADDON_SERVICE_DESCRIPTIONS: Record<DetailingKey | RepairKey, ServiceDescBlock> = {
  'ceramic-coating': {
    description: 'A durable protective layer applied over clear coat to help repel water, dirt, and UV, and to keep gloss for longer between washes.',
    includes: ['Surface prep and decontamination where needed', 'Application of ceramic or SIO2-based coating per product instructions', 'Curing guidance for the customer', 'Typically quoted by vehicle size due to paint area'],
    bestFor: 'Owners who want easier washing and longer-lasting shine.',
  },
  'machine-polishing': {
    description: 'Machine correction to reduce swirl marks, light scratches, and oxidation, restoring clarity and gloss before protection or hand finishing.',
    includes: ['Paint assessment and safe wash', 'Single- or multi-stage machine work as agreed', 'Panel wipe and inspection', 'Optional sealant or wax if you include it in the package'],
    bestFor: 'Paint that looks dull or swirled but is otherwise sound.',
  },
  'soft-top-restoration': {
    description: 'Cleaning, conditioning, and protection for convertible fabric hoods to improve appearance and help resist water ingress and fading.',
    includes: ['Gentle clean of fabric and seams', 'Mould/mildew treatment if required (see also Mould Removal)', 'Waterproofer / UV protectant where appropriate', 'Trim and glass edges checked for drips'],
    bestFor: 'Convertibles with stained, faded, or poorly beading hoods.',
  },
  'mould-removal': {
    description: 'Targeted interior treatment to address mould and musty odours from moisture, spills, or poor ventilation—often combined with deep cleaning.',
    includes: ['Inspection of affected areas (seats, carpets, boot, HVAC paths)', 'HEPA vacuum and antimicrobial treatment as appropriate', 'Drying aids and odour neutraliser', 'Advice on preventing recurrence'],
    bestFor: 'Vehicles with visible mould, mildew smell, or water damage history.',
  },
  'headlight-restoration': {
    description: 'Restores clarity to yellowed or hazed polycarbonate lenses to improve night visibility and appearance, usually via wet sanding and UV seal.',
    includes: ['Masking adjacent paint and trim', 'Progressive refinement of lens surface', 'UV protective clear coat or seal', 'Final polish and beam check where possible'],
    bestFor: 'Cloudy headlights that fail MOT beam pattern or look aged.',
  },
  'scratch-removal': {
    description: 'Localised paint correction to reduce or remove clear-coat level marks; deeper scratches may need touch-up or bodyshop work.',
    includes: ['Depth check (clear coat vs base)', 'Compound and refine within safe limits', 'Panel wipe and gloss match', 'Honest call-out when touch-up or respray is safer'],
    bestFor: 'Parking scrapes, brush wash marks, and light clear-coat scratches.',
  },
  'paint-chip-repair': {
    description: 'Small touch-up of stone chips and chips to primer to limit rust and improve looks—colour matched where you stock or mix paint.',
    includes: ['Clean and feather edges', 'Primer / base / clear as needed per chip depth', 'Level and cure per product', 'Blend into surrounding panels where practical'],
    bestFor: 'Bonnet and front bumper stone chips and minor road rash.',
  },
  'trim-restoration': {
    description: 'Revives faded exterior plastic trim (bumpers, mirrors, cladding) with clean, dye, or dressings depending on condition.',
    includes: ['Deep clean of porous plastic', 'Grey/faded trim restored with dye or coating', 'Satin or gloss finish to customer preference', 'Avoid overspray on paint and glass'],
    bestFor: 'Sun-faded black plastic that looks grey or chalky.',
  },
  'leather-repair': {
    description: 'Repairs minor tears, scuffs, and wear on leather or leatherette—colour matching and flexible fillers for seats and bolsters.',
    includes: ['Clean and degrease the area', 'Sub-patch or filler for small holes', 'Grain texture and colour match', 'Conditioner to finish'],
    bestFor: 'Worn driver bolsters, scuffs, and small punctures not needing full retrim.',
  },
};

const VEHICLE_SIZE_DEFS: Array<{ key: VehicleSizeKey; label: string; icon: IconGlyphName }> = [
  { key: 'small', label: 'Small (Base)', icon: 'car-outline' },
  { key: 'medium', label: 'Medium', icon: 'car-sport-outline' },
  { key: 'large', label: 'Large', icon: 'bus-outline' },
  { key: 'xl', label: 'XL', icon: 'subway-outline' },
  { key: 'xxl', label: 'XXL', icon: 'train-outline' },
];

type DetailingKey = 'ceramic-coating' | 'machine-polishing' | 'soft-top-restoration' | 'mould-removal';
type RepairKey = 'headlight-restoration' | 'scratch-removal' | 'paint-chip-repair' | 'trim-restoration' | 'leather-repair';
type DetailingItem = {
  key: DetailingKey | RepairKey;
  name: string;
  enabled: boolean;
  price: number | null;
  prices?: Record<VehicleSizeKey, number | null>;
};

const DETAILING_DEFS: Array<{ key: DetailingKey; name: string; icon: IconGlyphName }> = [
  { key: 'ceramic-coating', name: 'Ceramic Coating', icon: 'shield-checkmark-outline' },
  { key: 'machine-polishing', name: 'Machine Polishing', icon: 'color-filter-outline' },
  { key: 'soft-top-restoration', name: 'Soft Top Restoration', icon: 'brush-outline' },
  { key: 'mould-removal', name: 'Mould Removal', icon: 'water-outline' },
];

const REPAIR_DEFS: Array<{ key: RepairKey; name: string; icon: IconGlyphName }> = [
  { key: 'headlight-restoration', name: 'Headlight Restoration', icon: 'bulb-outline' },
  { key: 'scratch-removal', name: 'Scratch Removal', icon: 'color-filter-outline' },
  { key: 'paint-chip-repair', name: 'Paint Chip Repair', icon: 'medkit-outline' },
  { key: 'trim-restoration', name: 'Trim Restoration', icon: 'albums-outline' },
  { key: 'leather-repair', name: 'Leather Repair', icon: 'shirt-outline' },
];

const money = (n: any) => (Number.isFinite(Number(n)) ? Number(n).toFixed(2) : '0.00');
const parseMaybeNumber = (raw: string, kind: 'price' | 'minutes'): number | null => {
  const t = (raw || '').trim();
  if (!t) return null;
  const v = Number(t);
  if (!Number.isFinite(v) || v < 0) return null;
  return kind === 'minutes' ? Math.round(v) : v;
};

const buildDefaultDetailingItems = (): DetailingItem[] =>
  DETAILING_DEFS.map((d) => ({ key: d.key, name: d.name, enabled: false, price: null, prices: defaultTierSizePricing() }));

const buildDefaultRepairItems = (): DetailingItem[] =>
  REPAIR_DEFS.map((d) => ({ key: d.key, name: d.name, enabled: false, price: null, prices: defaultTierSizePricing() }));

const getDetailingPrices = (item: DetailingItem): Record<VehicleSizeKey, number | null> => {
  if (item.prices && Object.keys(item.prices).length > 0) return item.prices;
  const p = item.price != null && Number.isFinite(item.price) ? item.price : null;
  return { small: p, medium: p, large: p, xl: p, xxl: p };
};

const coerceDetailingMenu = (raw: any): DetailingItem[] => {
  const defaults = buildDefaultDetailingItems();
  const map = new Map<string, DetailingItem>();
  defaults.forEach((d) => map.set(d.key, { ...d }));
  const items = raw?.items;
  if (Array.isArray(items)) {
    for (const it of items) {
      const keyRaw = String(it?.key || '');
      const key = (keyRaw === 'ceramic' ? 'ceramic-coating' : keyRaw);
      if (!map.has(key)) continue;
      const legacy = it?.price != null && Number.isFinite(Number(it?.price)) ? Number(it?.price) : null;
      const nextPrices = defaultTierSizePricing();
      VEHICLE_SIZE_DEFS.forEach(({ key: sizeKey }) => {
        const v = it?.prices?.[sizeKey];
        nextPrices[sizeKey] = v != null && Number.isFinite(Number(v)) ? Number(v) : legacy;
      });
      map.set(key, {
        key: key as DetailingKey,
        name: String(it?.name || map.get(key)!.name),
        enabled: !!it?.enabled,
        price: legacy,
        prices: nextPrices,
      });
    }
  }
  return Array.from(map.values());
};

const coerceRepairMenu = (raw: any): DetailingItem[] => {
  const defaults = buildDefaultRepairItems();
  const map = new Map<string, DetailingItem>();
  defaults.forEach((d) => map.set(d.key, { ...d }));
  const items = raw?.items;
  if (Array.isArray(items)) {
    for (const it of items) {
      const key = String(it?.key || '');
      if (!map.has(key)) continue;
      const legacy = it?.price != null && Number.isFinite(Number(it?.price)) ? Number(it?.price) : null;
      const nextPrices = defaultTierSizePricing();
      VEHICLE_SIZE_DEFS.forEach(({ key: sizeKey }) => {
        const v = it?.prices?.[sizeKey];
        nextPrices[sizeKey] = v != null && Number.isFinite(Number(v)) ? Number(v) : legacy;
      });
      map.set(key, {
        key: key as RepairKey,
        name: String(it?.name || map.get(key)!.name),
        enabled: !!it?.enabled,
        price: legacy,
        prices: nextPrices,
      });
    }
  }
  return Array.from(map.values());
};

type TierPricing = Record<TierKey, { prices: Record<VehicleSizeKey, number | null>; minutes: number | null; enabled?: boolean }>;
const defaultTierSizePricing = (): Record<VehicleSizeKey, number | null> =>
  ({ small: null, medium: null, large: null, xl: null, xxl: null });
const ALL_TIER_KEYS: TierKey[] = ['bronze', 'silver', 'gold', 'platinum', 'emerald'];
const defaultTierPricing = (): TierPricing =>
  ALL_TIER_KEYS.reduce(
    (acc, k) => ({ ...acc, [k]: { prices: defaultTierSizePricing(), minutes: null, enabled: true } }),
    {} as TierPricing
  );

const coerceTierPricing = (raw: any): TierPricing => {
  const base = defaultTierPricing();
  const obj = raw && typeof raw === 'object' ? raw : {};
  ALL_TIER_KEYS.forEach((k) => {
    const row = obj?.[k] || {};
    const legacy = row?.price != null && Number.isFinite(Number(row.price)) ? Number(row.price) : null;
    const nextPrices = defaultTierSizePricing();
    VEHICLE_SIZE_DEFS.forEach(({ key }) => {
      const v = row?.prices?.[key];
      nextPrices[key] = v != null && Number.isFinite(Number(v)) ? Number(v) : legacy;
    });
    base[k] = {
      prices: nextPrices,
      minutes: row?.minutes != null && Number.isFinite(Number(row.minutes)) ? Math.round(Number(row.minutes)) : null,
      enabled: row?.enabled !== false,
    };
  });
  return base;
};

const isMissingTableErr = (err: any) => {
  const msg = String(err?.message || '').toLowerCase();
  return msg.includes('does not exist') || msg.includes('relation') || msg.includes('schema cache');
};

type ServicePricingTab = 'standard' | 'detailing' | 'repairs';

function tabFromParam(raw: string | string[] | undefined): ServicePricingTab | null {
  const v = Array.isArray(raw) ? raw[0] : raw;
  if (v === 'standard' || v === 'detailing' || v === 'repairs') return v;
  return null;
}

const CATEGORY_TABS: Array<{ key: ServicePricingTab; label: string; icon: IconGlyphName }> = [
  { key: 'standard', label: 'Wash', icon: 'water-outline' },
  { key: 'detailing', label: 'Detail', icon: 'sparkles-outline' },
  { key: 'repairs', label: 'Repair', icon: 'construct-outline' },
];

function categoryTabPreset(key: ServicePricingTab, active: boolean): 'cyan' | 'amber' | 'sky' | 'gray' {
  if (!active) return 'gray';
  if (key === 'standard') return 'cyan';
  if (key === 'detailing') return 'amber';
  return 'sky';
}

type ServiceDescTarget =
  | { kind: 'tier'; key: TierKey }
  | { kind: 'addon'; key: DetailingKey | RepairKey };

function serviceDescTitle(target: ServiceDescTarget): string {
  if (target.kind === 'tier') {
    return TIER_DEFS.find((t) => t.key === target.key)?.name ?? 'Service';
  }
  return (
    DETAILING_DEFS.find((d) => d.key === target.key)?.name ??
    REPAIR_DEFS.find((r) => r.key === target.key)?.name ??
    'Service'
  );
}

function serviceDescBlock(target: ServiceDescTarget): ServiceDescBlock | null {
  if (target.kind === 'tier') {
    return STANDARD_TIER_DESCRIPTIONS[target.key] ?? null;
  }
  return ADDON_SERVICE_DESCRIPTIONS[target.key] ?? null;
}

const DETAILING_INFO_ACCENT = '#F59E0B';
const REPAIR_INFO_ACCENT = '#38BDF8';

export default function ValeterServices() {
  const { user } = useAuth();
  const { tab: tabParam } = useLocalSearchParams<{ tab?: string | string[] }>();
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const headerBg = theme.headerBackground ?? theme.background;
  const toOpaque = (s: string, alpha: number) => {
    if (s.includes('rgba')) return s.replace(/,\s*[\d.]+\)$/, `, ${alpha})`);
    const hexSuffix = alpha === 1 ? 'FF' : 'EE';
    return `${s}${hexSuffix}`;
  };
  const headerGradient: [string, string] = [
    toOpaque(headerBg[0], 1),
    toOpaque(headerBg[1] || headerBg[0], 0.93),
  ];
  const pageGradient: [string, string] = [theme.background[0], theme.background[1]];
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [detailingOffered, setDetailingOffered] = useState(false);
  const [repairsOffered, setRepairsOffered] = useState(false);
  const [detailingItems, setDetailingItems] = useState<DetailingItem[]>(buildDefaultDetailingItems());
  const [repairItems, setRepairItems] = useState<DetailingItem[]>(buildDefaultRepairItems());
  const [tierPricing, setTierPricing] = useState<TierPricing>(defaultTierPricing());
  const [activeServiceTab, setActiveServiceTab] = useState<ServicePricingTab>('standard');
  const [selectedTierForPricing, setSelectedTierForPricing] = useState<TierKey | null>(null);
  const [serviceDescTarget, setServiceDescTarget] = useState<ServiceDescTarget | null>(null);
  const [selectedDetailingForPricing, setSelectedDetailingForPricing] = useState<DetailingKey | RepairKey | null>(null);

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 400, useNativeDriver: true }).start();
  }, []);

  useEffect(() => {
    if (user?.id) loadSettings();
  }, [user?.id]);

  useEffect(() => {
    const next = tabFromParam(tabParam);
    if (next) setActiveServiceTab(next);
  }, [tabParam]);

  const loadSettings = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('valeter_service_settings')
        .select('*')
        .eq('valeter_id', user.id)
        .maybeSingle();
      if (error) {
        if (isMissingTableErr(error)) {
          Alert.alert('DB setup needed', "The table 'valeter_service_settings' doesn't exist yet.");
        }
        return;
      }
      if (data) {
        setDetailingOffered(data.detailing_offered === true);
        setRepairsOffered(data.repairs_offered === true);
        setDetailingItems(coerceDetailingMenu(data.detailing_menu));
        setRepairItems(coerceRepairMenu(data.repair_menu));
        setTierPricing(coerceTierPricing(data.tier_pricing));
      }
    } catch (e) {
      console.warn('[ValeterServices] load error', e);
    } finally {
      setLoading(false);
    }
  };

  const saveSettings = async () => {
    if (!user?.id) return;
    try {
      setSaving(true);
      const { error } = await supabase.from('valeter_service_settings').upsert(
        {
          valeter_id: user.id,
          detailing_offered: detailingOffered,
          repairs_offered: repairsOffered,
          detailing_menu: { items: detailingItems },
          repair_menu: { items: repairItems },
          tier_pricing: tierPricing,
        },
        { onConflict: 'valeter_id' }
      );
      if (error) {
        if (isMissingTableErr(error)) {
          Alert.alert('DB setup needed', "Create 'valeter_service_settings' first.");
          return;
        }
        throw error;
      }
      Alert.alert('Saved', 'Your services & pricing have been updated.');
    } catch (e: any) {
      Alert.alert('Error', e?.message || 'Failed to save');
    } finally {
      setSaving(false);
    }
  };

  const setTierPriceField = (key: TierKey, size: VehicleSizeKey, raw: string) => {
    const v = parseMaybeNumber(raw, 'price');
    setTierPricing((prev) => ({
      ...prev,
      [key]: { ...prev[key], prices: { ...prev[key].prices, [size]: v } },
    }));
  };
  const setTierMinutesField = (key: TierKey, raw: string) => {
    const v = parseMaybeNumber(raw, 'minutes');
    setTierPricing((prev) => ({ ...prev, [key]: { ...prev[key], minutes: v } }));
  };
  const setTierEnabled = (key: TierKey, enabled: boolean) => {
    setTierPricing((prev) => ({ ...prev, [key]: { ...prev[key], enabled } }));
  };
  const toggleDetailingItem = (key: DetailingKey, enabled: boolean) => {
    setDetailingItems((prev) => prev.map((it) => (it.key === key ? { ...it, enabled } : it)));
  };
  const toggleRepairItem = (key: RepairKey, enabled: boolean) => {
    setRepairItems((prev) => prev.map((it) => (it.key === key ? { ...it, enabled } : it)));
  };
  const setDetailingPriceField = (key: DetailingKey | RepairKey, size: VehicleSizeKey, raw: string) => {
    const v = parseMaybeNumber(raw, 'price');
    const isRepair = REPAIR_DEFS.some((d) => d.key === key);
    const setter = isRepair ? setRepairItems : setDetailingItems;
    setter((prev) =>
      prev.map((it) =>
        it.key === key ? { ...it, prices: { ...getDetailingPrices(it), [size]: v } } : it
      )
    );
  };
  const primary = theme.primary || BUSINESS_PRIMARY;
  const glassBorder = theme.glassBorder;
  const muted = theme.textSecondary ?? 'rgba(249,250,251,0.65)';
  const textMain = theme.textPrimary ?? '#F9FAFB';

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
        <LoadingScreen message="Loading…" />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
      <LinearGradient colors={pageGradient} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <AppHeader title="Services & pricing" accountType="valeter" showBack />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={[
          styles.scrollContent,
          { paddingTop: HEADER_CONTENT_OFFSET, paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 24 },
        ]}
      >
        <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
          <Text style={[styles.heroKicker, { color: muted }]}>Pricing</Text>
          <Text style={[styles.heroTitle, { color: textMain }]}>Your services</Text>
          <Text style={[styles.heroSubtitle, { color: muted }]}>
            Set wash tiers, add-ons, and repairs. Tap a row to edit prices by vehicle size.
          </Text>

          <View style={[styles.offeringsPanel, { borderColor: glassBorder }]}>
            <Text style={[styles.panelTitle, { color: textMain }]}>Offer to customers</Text>
            <View style={[styles.offeringsRow, { borderBottomColor: `${primary}22` }]}>
              <View style={styles.offeringsRowText}>
                <Text style={[styles.offeringsLabel, { color: textMain }]}>Detailing</Text>
                <Text style={[styles.offeringsHint, { color: muted }]}>Ceramic, polish, mould removal…</Text>
              </View>
              <Switch
                value={detailingOffered}
                onValueChange={() => {
                  hapticFeedback('light');
                  setDetailingOffered((v) => !v);
                }}
                trackColor={{ false: 'rgba(255,255,255,0.12)', true: `${primary}88` }}
                thumbColor={detailingOffered ? '#fff' : '#E5E7EB'}
              />
            </View>
            <View style={styles.offeringsRow}>
              <View style={styles.offeringsRowText}>
                <Text style={[styles.offeringsLabel, { color: textMain }]}>Repairs</Text>
                <Text style={[styles.offeringsHint, { color: muted }]}>Lights, paint chips, trim, leather…</Text>
              </View>
              <Switch
                value={repairsOffered}
                onValueChange={() => {
                  hapticFeedback('light');
                  setRepairsOffered((v) => !v);
                }}
                trackColor={{ false: 'rgba(255,255,255,0.12)', true: `${primary}88` }}
                thumbColor={repairsOffered ? '#fff' : '#E5E7EB'}
              />
            </View>
          </View>

          <View style={[styles.categoryRail, { borderColor: glassBorder, backgroundColor: 'rgba(255,255,255,0.04)' }]}>
            {CATEGORY_TABS.map(({ key, label, icon }) => {
              const active = activeServiceTab === key;
              return (
                <Pressable
                  key={key}
                  onPress={() => {
                    hapticFeedback('light');
                    setActiveServiceTab(key);
                  }}
                  style={[
                    styles.categorySegment,
                    active && { backgroundColor: `${primary}2E`, borderColor: primary },
                  ]}
                >
                  <LocationStyleIconBox variant="inline" icon={icon} preset={categoryTabPreset(key, active)} />
                  <Text style={[styles.categoryLabel, { color: muted }, active && { color: textMain, fontWeight: '800' }]}>
                    {label}
                  </Text>
                </Pressable>
              );
            })}
          </View>

          <View style={styles.listSection}>
            {activeServiceTab === 'standard' &&
              TIER_DEFS.map((t) => {
                const row = tierPricing[t.key];
                const enabled = row?.enabled !== false;
                const prices = Object.values(row?.prices || {}).filter((v): v is number => v != null && Number.isFinite(v));
                const fromPrice = prices.length > 0 ? Math.min(...prices) : null;
                return (
                  <View key={t.key} style={[styles.priceRow, { borderColor: glassBorder }]}>
                    <View style={styles.priceRowTop}>
                      <View style={styles.priceRowLead}>
                        <LocationStyleIconBox variant="inline" icon={t.icon} colors={accentToGradient(t.color)} />
                        <View style={styles.priceRowTitles}>
                          <View style={styles.priceRowTitleLine}>
                            <Text style={[styles.priceRowTitle, { color: textMain, flex: 1, minWidth: 0 }]} numberOfLines={1}>
                              {t.name}
                            </Text>
                            <InfoIconButton
                              accentColor={t.color}
                              onPress={() => {
                                hapticFeedback('light');
                                setServiceDescTarget({ kind: 'tier', key: t.key });
                              }}
                            />
                            {!!t.tier && (
                              <View style={[styles.tierBadge, { backgroundColor: `${t.color}35`, borderColor: t.color }]}>
                                <Text style={styles.tierBadgeText}>{t.tier}</Text>
                              </View>
                            )}
                          </View>
                          <Text style={[styles.priceRowSub, { color: muted }]}>
                            {fromPrice === null ? 'No prices set' : `From £${money(fromPrice)}`}
                          </Text>
                        </View>
                      </View>
                      <View style={styles.priceRowActions}>
                        <Switch
                          value={enabled}
                          onValueChange={() => {
                            hapticFeedback('light');
                            setTierEnabled(t.key, !enabled);
                          }}
                          trackColor={{ false: 'rgba(255,255,255,0.15)', true: primary }}
                          thumbColor={enabled ? '#fff' : '#9CA3AF'}
                        />
                        <TouchableOpacity
                          onPress={() => {
                            hapticFeedback('light');
                            setSelectedTierForPricing(t.key);
                          }}
                          hitSlop={8}
                          accessibilityLabel="Edit prices"
                        >
                          <LocationStyleIconBox variant="inline" icon="chevron-forward" colors={accentToGradient(primary)} />
                        </TouchableOpacity>
                      </View>
                    </View>
                  </View>
                );
              })}

            {activeServiceTab === 'detailing' &&
              DETAILING_DEFS.map((def) => {
                const item =
                  detailingItems.find((x) => x.key === def.key) ??
                  ({ key: def.key, name: def.name, enabled: false, price: null, prices: defaultTierSizePricing() } as DetailingItem);
                const enabled = item.enabled;
                const prices = getDetailingPrices(item);
                const priced = Object.values(prices).filter((p): p is number => p != null && Number.isFinite(p)) as number[];
                const fromPrice = priced.length > 0 ? Math.min(...priced) : null;
                const priceLabel = fromPrice === null ? 'No price set' : `From £${money(fromPrice)}`;
                return (
                  <View key={def.key} style={[styles.priceRow, { borderColor: glassBorder }]}>
                    <View style={styles.priceRowTop}>
                      <View style={styles.priceRowLead}>
                        <LocationStyleIconBox variant="inline" icon={def.icon} preset="amber" />
                        <View style={styles.priceRowTitles}>
                          <View style={styles.priceRowTitleLine}>
                            <Text style={[styles.priceRowTitle, { color: textMain, flex: 1, minWidth: 0 }]} numberOfLines={2}>
                              {def.name}
                            </Text>
                            <InfoIconButton
                              accentColor={DETAILING_INFO_ACCENT}
                              onPress={() => {
                                hapticFeedback('light');
                                setServiceDescTarget({ kind: 'addon', key: def.key });
                              }}
                            />
                          </View>
                          <Text style={[styles.priceRowSub, { color: muted }]}>{priceLabel}</Text>
                        </View>
                      </View>
                      <View style={styles.priceRowActions}>
                        <Switch
                          value={enabled}
                          onValueChange={() => {
                            hapticFeedback('light');
                            toggleDetailingItem(def.key, !enabled);
                          }}
                          trackColor={{ false: 'rgba(255,255,255,0.15)', true: primary }}
                          thumbColor={enabled ? '#fff' : '#9CA3AF'}
                        />
                        <TouchableOpacity
                          onPress={() => {
                            hapticFeedback('light');
                            setSelectedDetailingForPricing(def.key);
                          }}
                          hitSlop={8}
                          accessibilityLabel="Edit prices"
                        >
                          <LocationStyleIconBox variant="inline" icon="chevron-forward" colors={accentToGradient(primary)} />
                        </TouchableOpacity>
                      </View>
                    </View>
                  </View>
                );
              })}

            {activeServiceTab === 'repairs' &&
              REPAIR_DEFS.map((def) => {
                const item =
                  repairItems.find((x) => x.key === def.key) ??
                  ({ key: def.key, name: def.name, enabled: false, price: null, prices: defaultTierSizePricing() } as DetailingItem);
                const enabled = item.enabled;
                const prices = getDetailingPrices(item);
                const priced = Object.values(prices).filter((p): p is number => p != null && Number.isFinite(p)) as number[];
                const fromPrice = priced.length > 0 ? Math.min(...priced) : null;
                const priceLabel = fromPrice === null ? 'No price set' : `From £${money(fromPrice)}`;
                return (
                  <View key={def.key} style={[styles.priceRow, { borderColor: glassBorder }]}>
                    <View style={styles.priceRowTop}>
                      <View style={styles.priceRowLead}>
                        <LocationStyleIconBox variant="inline" icon={def.icon} preset="sky" />
                        <View style={styles.priceRowTitles}>
                          <View style={styles.priceRowTitleLine}>
                            <Text style={[styles.priceRowTitle, { color: textMain, flex: 1, minWidth: 0 }]} numberOfLines={2}>
                              {def.name}
                            </Text>
                            <InfoIconButton
                              accentColor={REPAIR_INFO_ACCENT}
                              onPress={() => {
                                hapticFeedback('light');
                                setServiceDescTarget({ kind: 'addon', key: def.key });
                              }}
                            />
                          </View>
                          <Text style={[styles.priceRowSub, { color: muted }]}>{priceLabel}</Text>
                        </View>
                      </View>
                      <View style={styles.priceRowActions}>
                        <Switch
                          value={enabled}
                          onValueChange={() => {
                            hapticFeedback('light');
                            toggleRepairItem(def.key, !enabled);
                          }}
                          trackColor={{ false: 'rgba(255,255,255,0.15)', true: primary }}
                          thumbColor={enabled ? '#fff' : '#9CA3AF'}
                        />
                        <TouchableOpacity
                          onPress={() => {
                            hapticFeedback('light');
                            setSelectedDetailingForPricing(def.key);
                          }}
                          hitSlop={8}
                          accessibilityLabel="Edit prices"
                        >
                          <LocationStyleIconBox variant="inline" icon="chevron-forward" colors={accentToGradient(primary)} />
                        </TouchableOpacity>
                      </View>
                    </View>
                  </View>
                );
              })}
          </View>

          <ContinueCTAButton
            title="Save Changes"
            onPress={saveSettings}
            accentColor={primary}
            disabled={saving}
            loading={saving}
            style={styles.continueCta}
            leading={<LocationStyleIconBox variant="inline" icon="checkmark-circle" preset="green" />}
          />
        </Animated.View>
      </Animated.ScrollView>

      {/* Tier pricing bottom sheet (header-matching) */}
      <Modal visible={!!selectedTierForPricing} transparent animationType="slide" statusBarTranslucent onRequestClose={() => setSelectedTierForPricing(null)}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.sheetContainer}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setSelectedTierForPricing(null)}>
            <View style={[StyleSheet.absoluteFill, styles.sheetBackdrop]} />
          </Pressable>
          <View style={[styles.bottomSheet, styles.bottomSheetHeaderStyle, { paddingBottom: Math.max(insets.bottom, 24), borderColor: theme.glassBorder }]} pointerEvents="box-none">
            <LinearGradient colors={headerGradient} style={StyleSheet.absoluteFill} pointerEvents="none" />
            <View style={styles.sheetHandle} />
            <View style={styles.sheetHeaderRow}>
              <Text style={styles.sheetTitleHeader} numberOfLines={1}>
                {selectedTierForPricing ? TIER_DEFS.find((t) => t.key === selectedTierForPricing)?.name : ''}
              </Text>
              <Pressable
                onPress={() => setSelectedTierForPricing(null)}
                style={({ pressed }) => [styles.sheetCloseBtnHeader, pressed && styles.sheetCloseBtnPressedHeader]}
                hitSlop={12}
              >
                <LocationStyleIconBox variant="card" icon="close" preset="gray" />
              </Pressable>
            </View>
            <ScrollView
              key={selectedTierForPricing ?? 'x'}
              style={styles.sheetScroll}
              contentContainerStyle={styles.sheetScrollContent}
              showsVerticalScrollIndicator={false}
              keyboardShouldPersistTaps="handled"
            >
              <View style={styles.sheetBlock}>
                <Text style={styles.sheetBlockTitle}>Vehicle size pricing</Text>
                <Text style={styles.sheetBlockSubtitle}>Set your price per wash for each vehicle size</Text>
                <View style={styles.sheetList}>
                  {VEHICLE_SIZE_DEFS.map((sizeDef, index) => {
                    const row = selectedTierForPricing ? tierPricing[selectedTierForPricing] : null;
                    const val = row?.prices?.[sizeDef.key];
                    const current = val != null && Number.isFinite(val) ? String(val) : '';
                    const isLast = index === VEHICLE_SIZE_DEFS.length - 1;
                    return (
                      <View key={sizeDef.key} style={[styles.sheetListItem, !isLast && styles.sheetListItemBorder]}>
                        <View style={styles.sheetListItemLeft}>
                          <LocationStyleIconBox
                            variant="inline"
                            icon={sizeDef.icon}
                            colors={accentToGradient(
                              selectedTierForPricing
                                ? TIER_DEFS.find((x) => x.key === selectedTierForPricing)?.color ?? primary
                                : primary
                            )}
                          />
                          <Text style={styles.sheetListItemLabel}>{sizeDef.label}</Text>
                        </View>
                        <View style={styles.sheetInputWrap}>
                          <Text style={styles.sheetInputPrefix}>£</Text>
                          <TextInput
                            key={`${selectedTierForPricing}-${sizeDef.key}`}
                            style={styles.sheetInput}
                            defaultValue={current}
                            onEndEditing={(e) => selectedTierForPricing && setTierPriceField(selectedTierForPricing, sizeDef.key, e.nativeEvent.text || '')}
                            keyboardType="decimal-pad"
                            placeholder="0.00"
                            placeholderTextColor="rgba(255,255,255,0.4)"
                          />
                        </View>
                      </View>
                    );
                  })}
                </View>
              </View>
              <View style={styles.sheetBlock}>
                <Text style={styles.sheetBlockTitle}>Duration</Text>
                <Text style={styles.sheetBlockSubtitle}>Estimated time per wash in minutes</Text>
                <View style={styles.sheetList}>
                  <View style={styles.sheetListItem}>
                    <View style={styles.sheetListItemLeft}>
                      <LocationStyleIconBox variant="inline" icon="time-outline" preset="cyan" />
                      <Text style={styles.sheetListItemLabel}>Minutes</Text>
                    </View>
                    <View style={styles.sheetInputWrap}>
                      <TextInput
                        key={`${selectedTierForPricing}-min`}
                        style={styles.sheetInput}
                        defaultValue={
                          selectedTierForPricing && tierPricing[selectedTierForPricing]?.minutes != null
                            ? String(tierPricing[selectedTierForPricing].minutes)
                            : ''
                        }
                        onEndEditing={(e) => selectedTierForPricing && setTierMinutesField(selectedTierForPricing, e.nativeEvent.text || '')}
                        keyboardType="number-pad"
                        placeholder="0"
                        placeholderTextColor="rgba(255,255,255,0.4)"
                      />
                      <Text style={styles.sheetInputSuffix}>min</Text>
                    </View>
                  </View>
                </View>
              </View>
            </ScrollView>
            <ContinueCTAButton
              title="Save"
              onPress={() => setSelectedTierForPricing(null)}
              accentColor={primary}
              style={styles.sheetContinueCta}
            />
          </View>
        </KeyboardAvoidingView>
      </Modal>

      {/* Detailing pricing bottom sheet (same design as tier sheet) */}
      <Modal visible={!!selectedDetailingForPricing} transparent animationType="slide" statusBarTranslucent onRequestClose={() => setSelectedDetailingForPricing(null)}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.sheetContainer}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setSelectedDetailingForPricing(null)}>
            <View style={[StyleSheet.absoluteFill, styles.sheetBackdrop]} />
          </Pressable>
          <View style={[styles.bottomSheet, styles.bottomSheetHeaderStyle, { paddingBottom: Math.max(insets.bottom, 24), borderColor: theme.glassBorder }]} pointerEvents="box-none">
            <LinearGradient colors={headerGradient} style={StyleSheet.absoluteFill} pointerEvents="none" />
            <View style={styles.sheetHandle} />
            <View style={styles.sheetHeaderRow}>
              <Text style={styles.sheetTitleHeader} numberOfLines={1}>
                {selectedDetailingForPricing ? (DETAILING_DEFS.find((d) => d.key === selectedDetailingForPricing)?.name ?? REPAIR_DEFS.find((d) => d.key === selectedDetailingForPricing)?.name ?? '') : ''}
              </Text>
              <Pressable
                onPress={() => setSelectedDetailingForPricing(null)}
                style={({ pressed }) => [styles.sheetCloseBtnHeader, pressed && styles.sheetCloseBtnPressedHeader]}
                hitSlop={12}
              >
                <LocationStyleIconBox variant="card" icon="close" preset="gray" />
              </Pressable>
            </View>
            <ScrollView
              key={selectedDetailingForPricing ?? 'x'}
              style={styles.sheetScroll}
              contentContainerStyle={styles.sheetScrollContent}
              showsVerticalScrollIndicator={false}
              keyboardShouldPersistTaps="handled"
            >
              <View style={styles.sheetBlock}>
                <Text style={styles.sheetBlockTitle}>Vehicle size pricing</Text>
                <Text style={styles.sheetBlockSubtitle}>Set your price per add-on for each vehicle size</Text>
                <View style={styles.sheetList}>
                  {VEHICLE_SIZE_DEFS.map((sizeDef, index) => {
                    const item = selectedDetailingForPricing ? (detailingItems.find((x) => x.key === selectedDetailingForPricing) ?? repairItems.find((x) => x.key === selectedDetailingForPricing)) : null;
                    const prices = item ? getDetailingPrices(item) : defaultTierSizePricing();
                    const val = prices[sizeDef.key];
                    const current = val != null && Number.isFinite(val) ? String(val) : '';
                    const isLast = index === VEHICLE_SIZE_DEFS.length - 1;
                    return (
                      <View key={sizeDef.key} style={[styles.sheetListItem, !isLast && styles.sheetListItemBorder]}>
                        <View style={styles.sheetListItemLeft}>
                          <LocationStyleIconBox
                            variant="inline"
                            icon={sizeDef.icon}
                            preset={
                              selectedDetailingForPricing &&
                              REPAIR_DEFS.some((d) => d.key === selectedDetailingForPricing)
                                ? 'sky'
                                : 'amber'
                            }
                          />
                          <Text style={styles.sheetListItemLabel}>{sizeDef.label}</Text>
                        </View>
                        <View style={styles.sheetInputWrap}>
                          <Text style={styles.sheetInputPrefix}>£</Text>
                          <TextInput
                            key={`detailing-${selectedDetailingForPricing}-${sizeDef.key}`}
                            style={styles.sheetInput}
                            defaultValue={current}
                            onEndEditing={(e) => selectedDetailingForPricing && setDetailingPriceField(selectedDetailingForPricing, sizeDef.key, e.nativeEvent.text || '')}
                            keyboardType="decimal-pad"
                            placeholder="0.00"
                            placeholderTextColor="rgba(255,255,255,0.4)"
                          />
                        </View>
                      </View>
                    );
                  })}
                </View>
              </View>
            </ScrollView>
            <ContinueCTAButton
              title="Save"
              onPress={() => setSelectedDetailingForPricing(null)}
              accentColor={primary}
              style={styles.sheetContinueCta}
            />
          </View>
        </KeyboardAvoidingView>
      </Modal>

      {/* Wash / detailing / repair info bottom sheet */}
      <Modal visible={!!serviceDescTarget} transparent animationType="slide" statusBarTranslucent onRequestClose={() => setServiceDescTarget(null)}>
        <View style={styles.sheetContainer}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setServiceDescTarget(null)}>
            <View style={[StyleSheet.absoluteFill, styles.sheetBackdrop]} />
          </Pressable>
          <View style={[styles.bottomSheet, styles.bottomSheetHeaderStyle, { paddingBottom: Math.max(insets.bottom, 24), borderColor: theme.glassBorder }]} pointerEvents="box-none">
            <LinearGradient colors={headerGradient} style={StyleSheet.absoluteFill} pointerEvents="none" />
            <View style={styles.sheetHandle} />
            <View style={styles.sheetHeaderRow}>
              <Text style={styles.sheetTitleHeader} numberOfLines={2}>
                {serviceDescTarget ? serviceDescTitle(serviceDescTarget) : ''}
              </Text>
              <Pressable
                onPress={() => setServiceDescTarget(null)}
                style={({ pressed }) => [styles.sheetCloseBtnHeader, pressed && styles.sheetCloseBtnPressedHeader]}
                hitSlop={12}
              >
                <LocationStyleIconBox variant="card" icon="close" preset="gray" />
              </Pressable>
            </View>
            <ScrollView
              key={serviceDescTarget ? `${serviceDescTarget.kind}-${serviceDescTarget.key}` : 'desc'}
              style={styles.sheetScroll}
              contentContainerStyle={styles.sheetScrollContent}
              showsVerticalScrollIndicator={false}
            >
              {serviceDescTarget &&
                (() => {
                  const desc = serviceDescBlock(serviceDescTarget);
                  if (!desc) return null;
                  return (
                    <>
                      <View style={styles.sheetBlock}>
                        <Text style={styles.sheetBlockTitle}>Description</Text>
                        <Text style={styles.sheetBlockSubtitle}>{desc.description}</Text>
                      </View>
                      <View style={styles.sheetBlock}>
                        <Text style={styles.sheetBlockTitle}>Includes</Text>
                        {desc.includes.map((item) => (
                          <Text key={item} style={styles.sheetDescBullet}>
                            • {item}
                          </Text>
                        ))}
                      </View>
                      <View style={styles.sheetBlock}>
                        <Text style={styles.sheetBlockTitle}>Best for</Text>
                        <Text style={styles.sheetBlockSubtitle}>{desc.bestFor}</Text>
                      </View>
                    </>
                  );
                })()}
            </ScrollView>
            <ContinueCTAButton
              title="Close"
              onPress={() => setServiceDescTarget(null)}
              accentColor={primary}
              style={styles.sheetContinueCta}
            />
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  scrollView: { flex: 1 },
  scrollContent: { paddingHorizontal: 20 },
  content: { gap: 0 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12 },
  loadingText: { color: SKY, fontSize: 14 },
  heroKicker: { marginBottom: 6 },
  heroTitle: { fontSize: 26, fontWeight: '800', letterSpacing: -0.4, marginBottom: 8 },
  heroSubtitle: { fontSize: 14, lineHeight: 21, marginBottom: 22 },
  offeringsPanel: {
    borderRadius: 18,
    borderWidth: 1,
    paddingHorizontal: 16,
    paddingVertical: 4,
    marginBottom: 18,
    backgroundColor: 'rgba(255,255,255,0.035)',
  },
  panelTitle: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1.1,
    textTransform: 'uppercase' as const,
    marginTop: 14,
    marginBottom: 4,
    opacity: 0.85,
  },
  offeringsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  offeringsRowText: { flex: 1, paddingRight: 12 },
  offeringsLabel: { fontSize: 16, fontWeight: '700' },
  offeringsHint: { fontSize: 12, marginTop: 4, lineHeight: 17 },
  categoryRail: {
    flexDirection: 'row',
    borderRadius: 16,
    padding: 5,
    gap: 6,
    marginBottom: 18,
    borderWidth: 1,
  },
  categorySegment: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 11,
    borderRadius: 12,
    gap: 4,
    borderWidth: 1,
    borderColor: 'transparent',
  },
  categoryLabel: { fontSize: 12, fontWeight: '700' },
  listSection: { gap: 12, paddingBottom: 8 },
  priceRow: {
    borderRadius: 18,
    borderWidth: 1,
    padding: 16,
    backgroundColor: 'rgba(255,255,255,0.03)',
  },
  priceRowTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  priceRowLead: { flexDirection: 'row', alignItems: 'center', flex: 1, gap: 12, minWidth: 0 },
  priceRowTitles: { flex: 1, minWidth: 0 },
  priceRowTitleLine: { flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' },
  priceRowTitle: { fontSize: 16, fontWeight: '800', flexShrink: 1 },
  priceRowSub: { fontSize: 13, fontWeight: '600', marginTop: 5 },
  priceRowActions: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  headerSection: { marginBottom: 8 },
  sectionTitle: { color: '#F9FAFB', fontSize: 24, fontWeight: '700', marginBottom: 6 },
  sectionSubtitle: { color: 'rgba(249,250,251,0.7)', fontSize: 15, lineHeight: 22 },
  sectionTitleSmall: { color: '#F9FAFB', fontSize: 18, fontWeight: '700', marginBottom: 4 },
  hint: { color: 'rgba(249,250,251,0.6)', fontSize: 13 },
  section: { marginTop: 8 },
  card: { borderRadius: 20, padding: 18, marginBottom: 12 },
  toggleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 12, paddingHorizontal: 4 },
  toggleLabel: { color: '#F9FAFB', fontSize: 15, fontWeight: '600' },
  tabsScroll: { marginTop: 12, marginBottom: 12 },
  tabsScrollContent: { flexDirection: 'row', paddingHorizontal: 4, gap: 8 },
  tab: { paddingVertical: 10, paddingHorizontal: 16, borderRadius: 10, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(255,255,255,0.04)' },
  tabActive: { backgroundColor: 'rgba(135,206,235,0.25)' },
  tabText: { color: 'rgba(249,250,251,0.7)', fontSize: 14, fontWeight: '600' },
  tabTextActive: { color: '#F9FAFB' },
  detailingTabContent: { marginTop: 4 },
  tierList: { gap: 12, marginTop: 8 },
  tierCard: { borderRadius: 20, padding: 0, overflow: 'hidden' },
  tierContent: { padding: 18 },
  tierInfo: { marginBottom: 12 },
  tierTitleRow: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 8 },
  tierName: { color: '#F9FAFB', fontSize: 18, fontWeight: '800', flex: 1 },
  badgeRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  tierBadge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8, borderWidth: 1 },
  tierBadgeText: { color: '#F9FAFB', fontSize: 9, fontWeight: '800', letterSpacing: 0.5 },
  priceSummary: { color: 'rgba(249,250,251,0.85)', fontSize: 16, fontWeight: '700', marginTop: 4 },
  tierCardInfoRow: { flexDirection: 'row', justifyContent: 'flex-end', paddingTop: 10, borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,0.08)', marginTop: 4 },
  tierCardInfoBtn: { padding: 4 },
  switchContainer: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingTop: 12, borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,0.1)' },
  switchLabel: { color: '#F9FAFB', fontSize: 14, fontWeight: '700' },
  switchLabelDisabled: { color: 'rgba(249,250,251,0.5)' },
  detailingList: { gap: 10 },
  detailingCard: { borderRadius: 16, padding: 14 },
  detailingRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  detailingLeft: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  detailingIcon: { width: 40, height: 40, borderRadius: 12, backgroundColor: 'rgba(135,206,235,0.15)', alignItems: 'center', justifyContent: 'center' },
  detailingIconOff: { backgroundColor: 'rgba(255,255,255,0.06)' },
  detailingName: { color: '#F9FAFB', fontSize: 16, fontWeight: '700' },
  detailingNameOff: { color: 'rgba(249,250,251,0.6)' },
  detailingPriceRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 12, paddingTop: 12, borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,0.08)' },
  detailingPriceLabel: { color: 'rgba(249,250,251,0.7)', fontSize: 14 },
  priceInputWrap: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(255,255,255,0.06)', borderRadius: 10, paddingHorizontal: 12, paddingVertical: 8, width: 100 },
  currency: { color: 'rgba(249,250,251,0.6)', fontSize: 14, marginRight: 4 },
  priceInput: { color: '#F9FAFB', fontSize: 14, fontWeight: '700', flex: 1, padding: 0 },
  continueCta: { marginTop: 28, marginBottom: 8 },
  sheetContinueCta: { marginTop: 8 },
  sheetContainer: { flex: 1, justifyContent: 'flex-end' },
  sheetBackdrop: { backgroundColor: 'rgba(0,0,0,0.82)' },
  sheetDescBullet: { color: 'rgba(249,250,251,0.9)', fontSize: 13, lineHeight: 20, marginBottom: 4 },
  bottomSheet: {
    overflow: 'hidden',
    maxHeight: '88%',
    width: '100%',
  },
  bottomSheetHeaderStyle: {
    borderTopLeftRadius: 22,
    borderTopRightRadius: 22,
    paddingHorizontal: 20,
    paddingTop: 8,
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderColor: 'rgba(135,206,235,0.35)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 16,
  },
  sheetOverlay: { backgroundColor: 'rgba(0,0,0,0.06)' },
  sheetHandle: {
    width: 36,
    height: 4,
    backgroundColor: 'rgba(255,255,255,0.35)',
    borderRadius: 2,
    alignSelf: 'center',
    marginBottom: 16,
  },
  sheetHeaderRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20, paddingBottom: 16, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.12)' },
  sheetTitleHeader: { color: '#F9FAFB', fontSize: 20, fontWeight: '600', flex: 1, marginRight: 12 },
  sheetCloseBtnHeader: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent',
  },
  sheetCloseBtnPressedHeader: { backgroundColor: 'rgba(255,255,255,0.15)' },
  sheetScroll: { maxHeight: 400, marginBottom: 16 },
  sheetScrollContent: { paddingBottom: 16 },
  sheetBlock: { marginBottom: 24 },
  sheetBlockTitle: { color: '#F9FAFB', fontSize: 16, fontWeight: '600', marginBottom: 4 },
  sheetBlockSubtitle: { color: 'rgba(249,250,251,0.7)', fontSize: 13, marginBottom: 12, lineHeight: 18 },
  sheetList: { backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: 8, borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)', overflow: 'hidden' },
  sheetListItem: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 14, paddingHorizontal: 16, backgroundColor: 'transparent' },
  sheetListItemBorder: { borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.08)' },
  sheetListItemLeft: { flexDirection: 'row', alignItems: 'center', gap: 12, flex: 1, minWidth: 0 },
  sheetListItemLabel: { color: '#F9FAFB', fontSize: 15, fontWeight: '500' },
  sheetInputWrap: { flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', backgroundColor: 'rgba(255,255,255,0.08)', borderRadius: 6, paddingHorizontal: 12, paddingVertical: 10, width: 120, minHeight: 44, borderWidth: 1, borderColor: 'rgba(255,255,255,0.15)' },
  sheetInputPrefix: { color: 'rgba(249,250,251,0.7)', fontSize: 14, fontWeight: '500', marginRight: 4 },
  sheetInput: { color: '#F9FAFB', fontSize: 15, fontWeight: '600', flex: 1, minWidth: 36, padding: 0 },
  sheetInputSuffix: { color: 'rgba(249,250,251,0.7)', fontSize: 13, fontWeight: '500', marginLeft: 4 },
});
