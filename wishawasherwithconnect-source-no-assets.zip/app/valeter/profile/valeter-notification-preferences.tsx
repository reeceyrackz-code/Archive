/**
 * Valeter Notification Preferences – Control how and when you receive alerts.
 * Matches business notification-settings page layout and styling.
 */
import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Switch,
  Animated,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import GlassCard from '../../../src/components/booking/GlassCard';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { colors } from '../../../src/constants/colors';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import { SCREEN_PADDING_H } from '../../../src/constants/screenLayout';
import LoadingScreen from '../../../src/components/LoadingScreen';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { router } from 'expo-router';

const SKY = colors.SKY;
const VALETER_BG_FALLBACK: [string, string] = ['#0A1929', '#2563EB'];

interface NotificationPreferences {
  jobAlerts: boolean;
  sound: boolean;
  vibration: boolean;
  email: boolean;
}

const DEFAULT_NOTIFICATION_PREFS: NotificationPreferences = {
  jobAlerts: true,
  sound: true,
  vibration: true,
  email: false,
};

const getNotifPrefsKey = (userId: string) => `valeter:notif_prefs:${userId}`;

const SETTINGS: { key: keyof NotificationPreferences; label: string; description: string; icon: string }[] = [
  { key: 'jobAlerts', label: 'Job request alerts', description: 'Get notified about new job opportunities', icon: 'briefcase' },
  { key: 'sound', label: 'Sound', description: 'Play sound for notifications', icon: 'volume-high' },
  { key: 'vibration', label: 'Vibration', description: 'Vibrate for alerts', icon: 'phone-portrait' },
  { key: 'email', label: 'Email', description: 'Receive email summaries', icon: 'mail' },
];

export default function ValeterNotificationPreferences() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const gradientBg = (theme?.background || VALETER_BG_FALLBACK) as [string, string];
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);
  const [notificationPrefs, setNotificationPrefs] = useState<NotificationPreferences>(DEFAULT_NOTIFICATION_PREFS);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (user?.id) {
      loadNotificationPreferencesLocal();
    } else {
      setLoading(false);
    }
  }, [user?.id]);

  const loadNotificationPreferencesLocal = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      const key = getNotifPrefsKey(user.id);
      const raw = await AsyncStorage.getItem(key);

      if (!raw) {
        setNotificationPrefs(DEFAULT_NOTIFICATION_PREFS);
        setLoading(false);
        return;
      }

      const parsed = JSON.parse(raw) as Partial<NotificationPreferences> | null;
      const merged: NotificationPreferences = {
        ...DEFAULT_NOTIFICATION_PREFS,
        ...(parsed || {}),
      };
      setNotificationPrefs(merged);
    } catch (error) {
      console.error('Error loading local notification preferences:', error);
      setNotificationPrefs(DEFAULT_NOTIFICATION_PREFS);
    } finally {
      setLoading(false);
    }
  };

  const saveNotificationPreferencesLocal = async (prefs: NotificationPreferences) => {
    if (!user?.id) return;
    try {
      const key = getNotifPrefsKey(user.id);
      await AsyncStorage.setItem(key, JSON.stringify(prefs));
    } catch (error) {
      console.error('Error saving local notification preferences:', error);
    }
  };

  const handleToggle = async (key: keyof NotificationPreferences) => {
    try {
      await hapticFeedback('light');
      const newPrefs: NotificationPreferences = { ...notificationPrefs, [key]: !notificationPrefs[key] };
      setNotificationPrefs(newPrefs);
      await saveNotificationPreferencesLocal(newPrefs);
    } catch (error) {
      console.error('Error updating local notification preferences:', error);
    }
  };

  if (loading) {
    return <LoadingScreen message="Loading…" />;
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <AppHeader
        title="Notifications"
        subtitle="Alerts and preferences"
        accountType="valeter"
        showBack
        onBack={() => { hapticFeedback('light'); router.back(); }}
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingTop: HEADER_CONTENT_OFFSET,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 24,
            paddingHorizontal: SCREEN_PADDING_H,
          },
        ]}
      >
        <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
          <View style={styles.headerSection}>
            <View style={styles.headerIconBox}>
              <Ionicons name="notifications-outline" size={28} color={SKY} />
            </View>
            <View>
              <Text style={styles.sectionTitle}>Notification preferences</Text>
              <Text style={styles.sectionSubtitle}>
                Control how and when you receive alerts
              </Text>
            </View>
          </View>

          <GlassCard style={styles.categoryCard} accountType="valeter">
            <View style={styles.settingsList}>
              {SETTINGS.map((item, index) => {
                const enabled = notificationPrefs[item.key];
                return (
                  <View key={item.key}>
                    <TouchableOpacity
                      style={styles.settingRow}
                      onPress={() => handleToggle(item.key)}
                      activeOpacity={0.8}
                    >
                      <View style={styles.settingLeft}>
                        <View style={[styles.settingIconBox, enabled && styles.settingIconBoxActive]}>
                          <Ionicons
                            name={enabled ? 'notifications' : 'notifications-off'}
                            size={18}
                            color={enabled ? SKY : 'rgba(255,255,255,0.5)'}
                          />
                        </View>
                        <View style={styles.settingInfo}>
                          <Text style={[styles.settingLabel, !enabled && styles.settingLabelDisabled]}>
                            {item.label}
                          </Text>
                          <Text style={styles.settingDescription}>{item.description}</Text>
                        </View>
                      </View>
                      <Switch
                        value={enabled}
                        onValueChange={() => handleToggle(item.key)}
                        trackColor={{ false: 'rgba(255,255,255,0.15)', true: SKY }}
                        thumbColor={enabled ? '#FFFFFF' : '#9CA3AF'}
                        ios_backgroundColor="rgba(255,255,255,0.15)"
                      />
                    </TouchableOpacity>
                    {index < SETTINGS.length - 1 && <View style={styles.settingDivider} />}
                  </View>
                );
              })}
            </View>
          </GlassCard>
        </Animated.View>
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollView: { flex: 1 },
  scrollContent: {},
  content: { gap: 20 },
  headerSection: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 14,
    marginBottom: 20,
  },
  headerIconBox: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '600',
    marginBottom: 4,
    letterSpacing: -0.3,
  },
  sectionSubtitle: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
    fontWeight: '500',
    lineHeight: 18,
  },
  categoryCard: {
    borderRadius: 16,
    padding: 0,
    overflow: 'hidden',
  },
  settingsList: { padding: 12 },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    paddingHorizontal: 4,
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    gap: 12,
  },
  settingIconBox: {
    width: 36,
    height: 36,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.08)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.15)',
  },
  settingIconBoxActive: {
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderColor: 'rgba(135,206,235,0.3)',
  },
  settingInfo: { flex: 1, gap: 3 },
  settingLabel: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: -0.1,
  },
  settingLabelDisabled: {
    color: 'rgba(249,250,251,0.6)',
  },
  settingDescription: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 12,
    lineHeight: 16,
    fontWeight: '500',
  },
  settingDivider: {
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.08)',
    marginLeft: 48,
    marginVertical: 4,
  },
});
