import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Dimensions,
  ActivityIndicator,
  Alert,
  Platform,
  Image,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system/legacy';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import { DVLA_CONFIG } from '../../../src/config/dvla';
import { colors } from '../../../src/constants/colors';
import DefaultLoadingSkeleton from '../../../src/components/shared/DefaultLoadingSkeleton';

const BUCKET = 'valeter_documents';
const IMAGE_MEDIA_TYPES: any = (ImagePicker as any)?.MediaType?.Images ? [(ImagePicker as any).MediaType.Images] : undefined;

const getExtAndMimeFromUri = (uri: string) => {
  const clean = (uri || '').split('?')[0];
  const extRaw = (clean.split('.').pop() || 'jpg').toLowerCase();
  const ext = extRaw === 'jpg' ? 'jpeg' : extRaw;
  let mime = 'image/jpeg';
  if (ext === 'png') mime = 'image/png';
  else if (ext === 'webp') mime = 'image/webp';
  return { extRaw, ext, mime };
};

const base64ToUint8Array = (base64: string) => {
  const binary = globalThis.atob ? globalThis.atob(base64) : Buffer.from(base64, 'base64').toString('binary');
  const len = binary.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
};

const { width } = Dimensions.get('window');
const SKY = colors.SKY ?? '#38BDF8';
const VALETER_BG_FALLBACK: [string, string] = ['#0F172A', '#1E293B'];

// Premium LinkedIn/Uber: flat, elevated cards, strong hierarchy, minimal decoration
const CARD_BG = 'rgba(255,255,255,0.06)';
const CARD_BORDER = 'rgba(255,255,255,0.08)';
const LABEL_MUTED = 'rgba(255,255,255,0.5)';
const VALUE_WHITE = '#F8FAFC';

interface ValeterProfileData {
  user_id: string;
  vehicle_make?: string;
  vehicle_model?: string;
  vehicle_registration?: string;
  vehicle_photo_url?: string | null;
  tax_status?: string;
  tax_due_date?: string;
  mot_status?: string;
  mot_expiry_date?: string;
}

export default function ValeterVehicleInfo() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme: valeterTheme } = useAccountTheme();
  const gradientBg = (valeterTheme?.background || VALETER_BG_FALLBACK) as [string, string];
  const primary = valeterTheme?.primary ?? SKY;

  const [profile, setProfile] = useState<ValeterProfileData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isLookingUpDVLA, setIsLookingUpDVLA] = useState(false);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);

  useEffect(() => {
    if (user?.id) loadProfile();
  }, [user?.id]);

  const loadProfile = async () => {
    try {
      setIsLoading(true);
      const { data } = await supabase
        .from('valeter_profiles')
        .select('*')
        .eq('user_id', user!.id)
        .maybeSingle();
      if (data) setProfile(data);
      else {
        const { data: created } = await supabase
          .from('valeter_profiles')
          .insert({ user_id: user!.id, full_name: ' ' })
          .select()
          .single();
        setProfile(created);
      }
    } catch {
      Alert.alert('Error', 'Failed to load vehicle information');
    } finally {
      setIsLoading(false);
    }
  };

  const lookupDVLA = async (registration: string) => {
    if (!registration?.trim()) {
      Alert.alert('Enter registration', 'Add your registration to look up details.');
      return;
    }
    if (!DVLA_CONFIG.apiKey) {
      Alert.alert('DVLA not configured', 'Missing DVLA API key');
      return;
    }
    try {
      setIsLookingUpDVLA(true);
      const res = await fetch(DVLA_CONFIG.baseUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': DVLA_CONFIG.apiKey },
        body: JSON.stringify({ registrationNumber: registration.trim() }),
      });
      if (!res.ok) throw new Error('DVLA lookup failed');
      const data = await res.json();
      setProfile(prev =>
        prev
          ? {
              ...prev,
              vehicle_make: data.make ?? prev.vehicle_make,
              tax_status: data.taxStatus ?? null,
              tax_due_date: data.taxDueDate ?? null,
              mot_status: data.motStatus ?? null,
              mot_expiry_date: data.motExpiryDate ?? null,
            }
          : prev
      );
      await hapticFeedback('success');
      Alert.alert('Updated', 'Tax and MOT details have been updated from DVLA.');
    } catch (e: any) {
      Alert.alert('DVLA lookup failed', e.message || 'Unable to fetch vehicle details');
    } finally {
      setIsLookingUpDVLA(false);
    }
  };

  const uploadVehiclePhotoToStorage = async (uri: string): Promise<string> => {
    if (!user?.id) throw new Error('No user');
    const { extRaw, mime } = getExtAndMimeFromUri(uri);
    const fileName = `vehicle_${user.id}_${Date.now()}.${extRaw || 'jpg'}`;
    const storagePath = `vehicles/${user.id}/${fileName}`;
    const base64 = await FileSystem.readAsStringAsync(uri.startsWith('file://') ? uri : uri, { encoding: 'base64' as any });
    const bytes = base64ToUint8Array(base64);
    const { data, error } = await supabase.storage.from(BUCKET).upload(storagePath, bytes, { contentType: mime, upsert: true });
    if (error) {
      const msg = String(error?.message || '').toLowerCase();
      if (msg.includes('bucket') || msg.includes('not found')) throw new Error("Storage bucket 'valeter_documents' not found.");
      if (msg.includes('policy') || msg.includes('permission')) throw new Error('Upload blocked by storage policy.');
      throw error;
    }
    const { data: pub } = supabase.storage.from(BUCKET).getPublicUrl(data?.path ?? storagePath);
    return pub?.publicUrl ?? storagePath;
  };

  const persistVehiclePhotoUrl = async (publicUrl: string) => {
    if (!user?.id) return;
    const { error } = await supabase
      .from('valeter_profiles')
      .update({ vehicle_photo_url: publicUrl })
      .eq('user_id', user.id);
    if (error) {
      const msg = String(error?.message || '').toLowerCase();
      if (msg.includes('column') && msg.includes('vehicle_photo')) return;
      throw error;
    }
    setProfile(prev => (prev ? { ...prev, vehicle_photo_url: publicUrl } : null));
  };

  const onVehiclePhotoPicked = async (uri: string) => {
    try {
      setUploadingPhoto(true);
      const publicUrl = await uploadVehiclePhotoToStorage(uri);
      await persistVehiclePhotoUrl(publicUrl);
      hapticFeedback('medium');
      Alert.alert('Done', 'Vehicle photo updated.');
    } catch (e: any) {
      Alert.alert('Upload failed', e?.message ?? 'Please try again.');
    } finally {
      setUploadingPhoto(false);
    }
  };

  const showVehiclePhotoOptions = () => {
    hapticFeedback('light');
    Alert.alert(
      'Vehicle photo',
      'Choose a photo of your vehicle',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Take photo',
          onPress: async () => {
            const perm = await ImagePicker.requestCameraPermissionsAsync();
            if (perm.status !== 'granted') {
              Alert.alert('Permission needed', 'Camera access is required to take a photo.');
              return;
            }
            const result = await ImagePicker.launchCameraAsync({
              mediaTypes: IMAGE_MEDIA_TYPES,
              allowsEditing: true,
              aspect: [16, 10],
              quality: 0.85,
            });
            if (!result.canceled && result.assets?.[0]?.uri) await onVehiclePhotoPicked(result.assets[0].uri);
          },
        },
        {
          text: 'Choose from library',
          onPress: async () => {
            const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
            if (perm.status !== 'granted') {
              Alert.alert('Permission needed', 'Photo library access is required.');
              return;
            }
            const result = await ImagePicker.launchImageLibraryAsync({
              mediaTypes: IMAGE_MEDIA_TYPES,
              allowsEditing: true,
              aspect: [16, 10],
              quality: 0.85,
            });
            if (!result.canceled && result.assets?.[0]?.uri) await onVehiclePhotoPicked(result.assets[0].uri);
          },
        },
      ]
    );
  };

  const handleSaveProfile = async () => {
    if (!profile || !user?.id) return;
    try {
      setIsSaving(true);
      const payload: Record<string, unknown> = {
        vehicle_make: profile.vehicle_make,
        vehicle_model: profile.vehicle_model,
        vehicle_registration: profile.vehicle_registration,
        tax_status: profile.tax_status,
        tax_due_date: profile.tax_due_date,
        mot_status: profile.mot_status,
        mot_expiry_date: profile.mot_expiry_date,
      };
      if (profile.vehicle_photo_url !== undefined) payload.vehicle_photo_url = profile.vehicle_photo_url;
      const { error } = await supabase.from('valeter_profiles').update(payload).eq('user_id', user.id);
      if (error) throw error;
      Alert.alert('Saved', 'Vehicle details updated');
      setIsEditing(false);
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to save vehicle details');
    } finally {
      setIsSaving(false);
    }
  };

  const formatDate = (d: string | null | undefined) =>
    d ? new Date(d).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' }) : null;

  if (isLoading || !profile) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
        <AppHeader title="Vehicle" accountType="valeter" />
        <View style={styles.loadingWrap}>
          <DefaultLoadingSkeleton message="Loading…" />
        </View>
      </SafeAreaView>
    );
  }

  const hasRegistration = !!(profile.vehicle_registration || '').trim();
  const taxValid = profile.tax_status === 'Taxed';
  const motValid = profile.mot_status === 'Valid';

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Vehicle"
        accountType="valeter"
        rightAction={
          <TouchableOpacity
            onPress={() => { hapticFeedback('light'); setIsEditing(!isEditing); }}
            style={styles.headerEditBtn}
            activeOpacity={0.8}
          >
            <Text style={[styles.headerEditText, { color: primary }]}>
              {isEditing ? 'Cancel' : 'Edit'}
            </Text>
          </TouchableOpacity>
        }
      />

      <ScrollView
        contentContainerStyle={[
          styles.scrollContent,
          { paddingTop: HEADER_CONTENT_OFFSET, paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 32 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {/* Profile-style cover block with vehicle photo */}
        <View style={styles.cover}>
          <TouchableOpacity
            style={styles.coverPhotoWrap}
            onPress={showVehiclePhotoOptions}
            disabled={uploadingPhoto}
            activeOpacity={0.9}
          >
            {profile.vehicle_photo_url ? (
              <Image source={{ uri: profile.vehicle_photo_url }} style={styles.coverPhoto} resizeMode="cover" />
            ) : (
              <View style={[styles.coverPhotoPlaceholder, { backgroundColor: primary + '18' }]}>
                <Ionicons name="car-sport" size={48} color={primary} />
                <Text style={styles.coverPhotoPlaceholderText}>Add vehicle photo</Text>
              </View>
            )}
            <View style={styles.coverPhotoOverlay}>
              {uploadingPhoto ? (
                <ActivityIndicator size="small" color="#fff" />
              ) : (
                <>
                  <Ionicons name="camera" size={22} color="#fff" />
                  <Text style={styles.coverPhotoOverlayText}>{profile.vehicle_photo_url ? 'Change photo' : 'Add photo'}</Text>
                </>
              )}
            </View>
          </TouchableOpacity>
          <View style={styles.coverInner}>
            <Text style={styles.coverReg}>{profile.vehicle_registration || '—'}</Text>
            <Text style={styles.coverSub} numberOfLines={1}>
              {[profile.vehicle_make, profile.vehicle_model].filter(Boolean).join(' · ') || 'Add vehicle details'}
            </Text>
          </View>
        </View>

        {/* Details card - row-based (LinkedIn style) */}
        <View style={styles.section}>
          <View style={styles.card}>
            <View style={styles.cardRow}>
              <Text style={styles.rowLabel}>Registration</Text>
              {isEditing ? (
                <TextInput
                  style={styles.rowInput}
                  value={profile.vehicle_registration || ''}
                  autoCapitalize="characters"
                  onChangeText={t =>
                    setProfile({
                      ...profile,
                      vehicle_registration: t.replace(/\s/g, '').toUpperCase().slice(0, 8),
                    })
                  }
                  placeholder="AB12 CDE"
                  placeholderTextColor={LABEL_MUTED}
                />
              ) : (
                <Text style={styles.rowValue}>{profile.vehicle_registration || '—'}</Text>
              )}
            </View>
            <View style={styles.divider} />
            <View style={styles.cardRow}>
              <Text style={styles.rowLabel}>Make</Text>
              <Text style={styles.rowValue}>{profile.vehicle_make || '—'}</Text>
            </View>
            <View style={styles.divider} />
            <View style={styles.cardRow}>
              <Text style={styles.rowLabel}>Model</Text>
              {isEditing ? (
                <TextInput
                  style={styles.rowInput}
                  value={profile.vehicle_model || ''}
                  onChangeText={t => setProfile({ ...profile, vehicle_model: t })}
                  placeholder="e.g. Transit Custom"
                  placeholderTextColor={LABEL_MUTED}
                />
              ) : (
                <Text style={styles.rowValue}>{profile.vehicle_model || '—'}</Text>
              )}
            </View>
            {isEditing && hasRegistration && DVLA_CONFIG.apiKey && (
              <>
                <View style={styles.divider} />
                <TouchableOpacity
                  style={styles.dvlaRow}
                  onPress={() => lookupDVLA(profile.vehicle_registration || '')}
                  disabled={isLookingUpDVLA}
                  activeOpacity={0.7}
                >
                  {isLookingUpDVLA ? (
                    <ActivityIndicator size="small" color={primary} />
                  ) : (
                    <>
                      <Ionicons name="search-outline" size={20} color={primary} />
                      <Text style={[styles.dvlaLabel, { color: primary }]}>Look up Tax & MOT from DVLA</Text>
                      <Ionicons name="chevron-forward" size={18} color={LABEL_MUTED} />
                    </>
                  )}
                </TouchableOpacity>
              </>
            )}
          </View>
        </View>

        {/* Compliance: Tax & MOT (Uber-style status row) */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Compliance</Text>
          <View style={styles.statusCard}>
            <View style={[styles.statusItem, !taxValid && styles.statusItemMuted]}>
              <View style={[styles.statusDot, taxValid ? styles.statusDotOk : styles.statusDotNone]} />
              <View style={styles.statusBody}>
                <Text style={styles.statusName}>Vehicle tax</Text>
                <Text style={[styles.statusVal, taxValid && styles.statusValOk]}>
                  {profile.tax_status || '—'}
                </Text>
                {profile.tax_due_date && (
                  <Text style={styles.statusDate}>{formatDate(profile.tax_due_date)}</Text>
                )}
              </View>
            </View>
            <View style={styles.statusDivider} />
            <View style={[styles.statusItem, !motValid && styles.statusItemMuted]}>
              <View style={[styles.statusDot, motValid ? styles.statusDotOk : styles.statusDotNone]} />
              <View style={styles.statusBody}>
                <Text style={styles.statusName}>MOT</Text>
                <Text style={[styles.statusVal, motValid && styles.statusValOk]}>
                  {profile.mot_status || '—'}
                </Text>
                {profile.mot_expiry_date && (
                  <Text style={styles.statusDate}>{formatDate(profile.mot_expiry_date)}</Text>
                )}
              </View>
            </View>
          </View>
        </View>

        {isEditing && (
          <TouchableOpacity
            style={[styles.primaryBtn, { backgroundColor: primary }]}
            onPress={handleSaveProfile}
            disabled={isSaving}
            activeOpacity={0.88}
          >
            {isSaving ? (
              <ActivityIndicator color="#fff" size="small" />
            ) : (
              <Text style={styles.primaryBtnText}>Save changes</Text>
            )}
          </TouchableOpacity>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  loadingWrap: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingLabel: {
    color: LABEL_MUTED,
    fontSize: 15,
    marginTop: 12,
  },
  scrollContent: {
    paddingHorizontal: 24,
  },
  headerEditBtn: {
    paddingVertical: 8,
    paddingHorizontal: 4,
  },
  headerEditText: {
    fontSize: 16,
    fontWeight: '600',
  },

  // Cover (LinkedIn profile header style) with vehicle photo
  cover: {
    marginBottom: 24,
    borderRadius: 16,
    overflow: 'hidden',
    backgroundColor: CARD_BG,
    borderWidth: 1,
    borderColor: CARD_BORDER,
    ...Platform.select({
      ios: { shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.12, shadowRadius: 8 },
      android: { elevation: 4 },
    }),
  },
  coverPhotoWrap: {
    width: '100%',
    height: 160,
    position: 'relative',
  },
  coverPhoto: {
    width: '100%',
    height: '100%',
  },
  coverPhotoPlaceholder: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  coverPhotoPlaceholderText: {
    color: LABEL_MUTED,
    fontSize: 14,
    fontWeight: '600',
    marginTop: 8,
  },
  coverPhotoOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.35)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  coverPhotoOverlayText: {
    color: '#fff',
    fontSize: 13,
    fontWeight: '700',
    marginTop: 6,
  },
  coverInner: {
    paddingVertical: 24,
    paddingHorizontal: 24,
    alignItems: 'center',
  },
  coverReg: {
    color: VALUE_WHITE,
    fontSize: 32,
    fontWeight: '800',
    letterSpacing: 4,
    marginBottom: 6,
  },
  coverSub: {
    color: LABEL_MUTED,
    fontSize: 15,
    fontWeight: '500',
  },

  // Section
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    color: LABEL_MUTED,
    fontSize: 11,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 1.2,
    marginBottom: 10,
    paddingHorizontal: 2,
  },

  // Card (flat, elevated)
  card: {
    backgroundColor: CARD_BG,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: CARD_BORDER,
    overflow: 'hidden',
    ...Platform.select({
      ios: { shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 8 },
      android: { elevation: 3 },
    }),
  },
  cardRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 16,
    paddingHorizontal: 20,
    minHeight: 52,
  },
  divider: {
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.06)',
    marginLeft: 20,
  },
  rowLabel: {
    color: LABEL_MUTED,
    fontSize: 15,
    fontWeight: '500',
    flex: 0,
    marginRight: 16,
  },
  rowValue: {
    color: VALUE_WHITE,
    fontSize: 16,
    fontWeight: '600',
    flex: 1,
    textAlign: 'right',
  },
  rowInput: {
    color: VALUE_WHITE,
    fontSize: 16,
    fontWeight: '600',
    flex: 1,
    textAlign: 'right',
    paddingVertical: 4,
    paddingHorizontal: 8,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 8,
  },
  dvlaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    gap: 10,
  },
  dvlaLabel: {
    fontSize: 15,
    fontWeight: '600',
    flex: 1,
  },

  // Compliance (Tax & MOT) - Uber-style list
  statusCard: {
    backgroundColor: CARD_BG,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: CARD_BORDER,
    overflow: 'hidden',
    ...Platform.select({
      ios: { shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 8 },
      android: { elevation: 3 },
    }),
  },
  statusItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 18,
    paddingHorizontal: 20,
  },
  statusItemMuted: {},
  statusDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginRight: 14,
  },
  statusDotOk: { backgroundColor: '#22C55E' },
  statusDotNone: { backgroundColor: 'rgba(255,255,255,0.25)' },
  statusBody: { flex: 1 },
  statusName: {
    color: LABEL_MUTED,
    fontSize: 13,
    fontWeight: '500',
    marginBottom: 2,
  },
  statusVal: {
    color: VALUE_WHITE,
    fontSize: 16,
    fontWeight: '700',
  },
  statusValOk: { color: '#22C55E' },
  statusDate: {
    color: LABEL_MUTED,
    fontSize: 12,
    marginTop: 2,
  },
  statusDivider: {
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.06)',
    marginLeft: 44,
  },

  // Primary CTA
  primaryBtn: {
    paddingVertical: 18,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    ...Platform.select({
      ios: { shadowColor: SKY, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8 },
      android: { elevation: 4 },
    }),
  },
  primaryBtnText: {
    color: '#fff',
    fontSize: 17,
    fontWeight: '700',
  },
});
