import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  Switch,
  ScrollView,
  Pressable,
  Modal,
  Platform,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import DateTimePicker from '@react-native-community/datetimepicker';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import GlassCard from '../../../src/components/booking/GlassCard';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { colors } from '../../../src/constants/colors';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import LoadingScreen from '../../../src/components/LoadingScreen';
import { loadCalendarSyncSettings, saveCalendarSyncSettings } from '../../../src/services/calendarSyncSettings';

const SKY = colors.SKY;
const VALETER_BG_FALLBACK: [string, string] = ['#0A1929', '#2563EB'];

const DAYS_ORDER = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'] as const;
const DAY_LABELS: Record<typeof DAYS_ORDER[number], string> = {
  monday: 'Monday',
  tuesday: 'Tuesday',
  wednesday: 'Wednesday',
  thursday: 'Thursday',
  friday: 'Friday',
  saturday: 'Saturday',
  sunday: 'Sunday',
};

interface DaySchedule {
  enabled: boolean;
  startTime: string;
  endTime: string;
}

interface AvailabilitySchedule {
  monday: DaySchedule;
  tuesday: DaySchedule;
  wednesday: DaySchedule;
  thursday: DaySchedule;
  friday: DaySchedule;
  saturday: DaySchedule;
  sunday: DaySchedule;
}

type TimePickerTarget = {
  day: keyof AvailabilitySchedule;
  field: 'startTime' | 'endTime';
} | null;

const DEFAULT_AVAILABILITY: AvailabilitySchedule = {
  monday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  tuesday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  wednesday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  thursday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  friday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  saturday: { enabled: true, startTime: '09:00', endTime: '17:00' },
  sunday: { enabled: false, startTime: '09:00', endTime: '17:00' },
};
const REMINDER_OPTIONS = [5, 10, 15, 30, 60];

function twoStopGradient(bg: readonly string[] | undefined, fallback: [string, string]): [string, string] {
  if (Array.isArray(bg) && bg.length >= 2) {
    return [String(bg[0]), String(bg[1])];
  }
  return fallback;
}

export default function WorkingHours() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const gradientBg = twoStopGradient(theme?.background, VALETER_BG_FALLBACK);

  const accent = theme?.accent ?? SKY;
  const textPrimary = theme?.textPrimary ?? '#F9FAFB';
  const textSecondary = theme?.textSecondary ?? 'rgba(249,250,251,0.85)';
  const textMuted = theme?.textSecondary ?? 'rgba(249,250,251,0.55)';
  const cardBg = theme?.cardBackground ?? 'rgba(255,255,255,0.06)';

  const [loading, setLoading] = useState(true);
  const [availabilitySchedule, setAvailabilitySchedule] = useState<AvailabilitySchedule>(DEFAULT_AVAILABILITY);
  const [saving, setSaving] = useState(false);
  const [timePickerTarget, setTimePickerTarget] = useState<TimePickerTarget>(null);
  const [calendarSyncEnabled, setCalendarSyncEnabled] = useState(true);
  const [calendarReminderMinutes, setCalendarReminderMinutes] = useState<number[]>([30, 10]);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const persistTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start();

    if (user?.id) {
      loadAvailabilitySchedule();
      void (async () => {
        const settings = await loadCalendarSyncSettings(user.id);
        setCalendarSyncEnabled(settings.enabled);
        setCalendarReminderMinutes(settings.reminderMinutes);
      })();
    } else {
      setLoading(false);
    }
  }, [user?.id]);

  const loadAvailabilitySchedule = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      const { data: profile, error } = await supabase
        .from('valeter_profiles')
        .select('availability_schedule')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error) throw error;

      if (profile?.availability_schedule) {
        setAvailabilitySchedule(profile.availability_schedule as AvailabilitySchedule);
      }
    } catch (error) {
      console.error('Error loading availability schedule:', error);
    } finally {
      setLoading(false);
    }
  };

  const persistSchedule = useCallback(async (newSchedule: AvailabilitySchedule) => {
    if (!user?.id) return;
    setSaving(true);
    try {
      const { error } = await supabase
        .from('valeter_profiles')
        .update({ availability_schedule: newSchedule })
        .eq('user_id', user.id);
      if (error) throw error;
    } catch (e) {
      console.error('Error saving schedule:', e);
    } finally {
      setSaving(false);
    }
  }, [user?.id]);

  useEffect(() => {
    return () => {
      if (persistTimeoutRef.current != null) {
        clearTimeout(persistTimeoutRef.current);
      }
    };
  }, []);

  const handleDayToggle = async (day: keyof AvailabilitySchedule) => {
    await hapticFeedback('light');
    const newSchedule = {
      ...availabilitySchedule,
      [day]: { ...availabilitySchedule[day], enabled: !availabilitySchedule[day].enabled },
    };
    setAvailabilitySchedule(newSchedule);
    persistSchedule(newSchedule);
  };

  const parseTimeToDate = (value: string) => {
    const [h, m] = value.split(':').map(Number);
    const date = new Date();
    date.setHours(Number.isFinite(h) ? h : 0, Number.isFinite(m) ? m : 0, 0, 0);
    return date;
  };

  const formatTime = (date: Date) => {
    const hh = String(date.getHours()).padStart(2, '0');
    const mm = String(date.getMinutes()).padStart(2, '0');
    return `${hh}:${mm}`;
  };

  const openTimePicker = (day: keyof AvailabilitySchedule, field: 'startTime' | 'endTime') => {
    void hapticFeedback('light');
    setTimePickerTarget({ day, field });
  };

  const closeTimePicker = () => {
    setTimePickerTarget(null);
  };

  const handleTimeSelected = (date: Date) => {
    if (!timePickerTarget) return;
    const { day, field } = timePickerTarget;
    const nextValue = formatTime(date);
    const newSchedule = {
      ...availabilitySchedule,
      [day]: { ...availabilitySchedule[day], [field]: nextValue },
    };
    setAvailabilitySchedule(newSchedule);
    void persistSchedule(newSchedule);
  };
  const pickerCardBg = theme?.cardBackground ?? '#0F172A';
  const saveCalendarSettings = useCallback(
    async (enabled: boolean, reminderMinutes: number[]) => {
      if (!user?.id) return;
      await saveCalendarSyncSettings(user.id, { enabled, reminderMinutes });
    },
    [user?.id]
  );

  const toggleCalendarSync = async (next: boolean) => {
    await hapticFeedback('light');
    setCalendarSyncEnabled(next);
    await saveCalendarSettings(next, calendarReminderMinutes);
  };

  const toggleReminderOption = async (minutes: number) => {
    await hapticFeedback('light');
    const has = calendarReminderMinutes.includes(minutes);
    const next = has
      ? calendarReminderMinutes.filter((m) => m !== minutes)
      : [...calendarReminderMinutes, minutes].sort((a, b) => b - a);
    if (next.length === 0) return;
    setCalendarReminderMinutes(next);
    await saveCalendarSettings(calendarSyncEnabled, next);
  };

  const applyWeekdays = useCallback(async () => {
    await hapticFeedback('light');
    const newSchedule = { ...availabilitySchedule };
    (['monday', 'tuesday', 'wednesday', 'thursday', 'friday'] as const).forEach((d) => {
      newSchedule[d] = { enabled: true, startTime: '08:00', endTime: '18:00' };
    });
    setAvailabilitySchedule(newSchedule);
    persistSchedule(newSchedule);
  }, [availabilitySchedule, persistSchedule]);

  const applyWeekends = useCallback(async () => {
    await hapticFeedback('light');
    const newSchedule = { ...availabilitySchedule };
    (['saturday', 'sunday'] as const).forEach((d) => {
      newSchedule[d] = { ...newSchedule[d], enabled: true, startTime: '09:00', endTime: '17:00' };
    });
    setAvailabilitySchedule(newSchedule);
    persistSchedule(newSchedule);
  }, [availabilitySchedule, persistSchedule]);

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="valeter" />
        <AppHeader title="Working Hours" accountType="valeter" />
        <LoadingScreen message="Loading schedule…" />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <AppHeader title="Working Hours" accountType="valeter" />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingTop: HEADER_CONTENT_OFFSET, paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 24 },
        ]}
      >
        <Animated.View style={[styles.wrap, { opacity: fadeAnim }]}>
          {/* Hero block */}
          <View style={styles.hero}>
            <View style={[styles.heroIconWrap, { backgroundColor: `${accent}20` }]}>
              <Ionicons name="time" size={28} color={accent} />
            </View>
            <Text style={[styles.heroTitle, { color: textPrimary }]}>Set your availability</Text>
            <Text style={[styles.heroSubtitle, { color: textSecondary }]}>
              Choose when you're available for jobs. Times are in 24-hour format.
            </Text>
          </View>

          {/* Quick actions */}
          <View style={styles.quickRow}>
            <Pressable
              onPress={applyWeekdays}
              style={({ pressed }) => [styles.quickBtn, { backgroundColor: cardBg, opacity: pressed ? 0.8 : 1 }]}
            >
              <Ionicons name="briefcase-outline" size={16} color={accent} />
              <Text style={[styles.quickBtnText, { color: textPrimary }]}>Weekdays 8–6</Text>
            </Pressable>
            <Pressable
              onPress={applyWeekends}
              style={({ pressed }) => [styles.quickBtn, { backgroundColor: cardBg, opacity: pressed ? 0.8 : 1 }]}
            >
              <Ionicons name="calendar-outline" size={16} color={accent} />
              <Text style={[styles.quickBtnText, { color: textPrimary }]}>Weekends 9–5</Text>
            </Pressable>
          </View>

          {/* Calendar sync settings */}
          <GlassCard style={styles.syncCard} accountType="valeter">
            <View style={styles.syncHeaderRow}>
              <View style={styles.syncTitleWrap}>
                <Text style={[styles.syncTitle, { color: textPrimary }]}>Phone calendar sync</Text>
                <Text style={[styles.syncSub, { color: textSecondary }]}>
                  Keep booked jobs in your iPhone/Android calendar automatically.
                </Text>
              </View>
              <Switch
                value={calendarSyncEnabled}
                onValueChange={toggleCalendarSync}
                trackColor={{ false: 'rgba(255,255,255,0.2)', true: accent }}
                thumbColor="#FFFFFF"
                ios_backgroundColor="rgba(255,255,255,0.2)"
              />
            </View>
            <Text style={[styles.reminderLabel, { color: textSecondary }]}>Reminders before booking</Text>
            <View style={styles.reminderChips}>
              {REMINDER_OPTIONS.map((minutes) => {
                const selected = calendarReminderMinutes.includes(minutes);
                return (
                  <Pressable
                    key={minutes}
                    onPress={() => toggleReminderOption(minutes)}
                    style={[
                      styles.reminderChip,
                      {
                        borderColor: selected ? `${accent}95` : 'rgba(255,255,255,0.2)',
                        backgroundColor: selected ? `${accent}26` : 'rgba(255,255,255,0.05)',
                        opacity: calendarSyncEnabled ? 1 : 0.45,
                      },
                    ]}
                    disabled={!calendarSyncEnabled}
                  >
                    <Text style={[styles.reminderChipText, { color: selected ? '#FFFFFF' : textSecondary }]}>{minutes}m</Text>
                  </Pressable>
                );
              })}
            </View>
          </GlassCard>

          {/* Schedule card */}
          <GlassCard style={styles.card} accountType="valeter">
            {DAYS_ORDER.map((day, index) => {
              const schedule = availabilitySchedule[day];
              const label = DAY_LABELS[day];
              const isWeekend = day === 'saturday' || day === 'sunday';
              let rowAccentColor = textMuted;
              if (schedule.enabled) {
                rowAccentColor = isWeekend ? '#F59E0B' : accent;
              }

              return (
                <View key={day}>
                  <View style={[styles.row, index === DAYS_ORDER.length - 1 && styles.rowLast]}>
                    <View style={[styles.rowAccent, { backgroundColor: rowAccentColor }]} />
                    <View style={styles.rowBody}>
                      <Text style={[styles.dayLabel, { color: schedule.enabled ? textPrimary : textMuted }]} numberOfLines={1}>
                        {label}
                      </Text>
                      {schedule.enabled ? (
                        <View style={styles.timeRow}>
                          <Pressable
                            onPress={() => openTimePicker(day, 'startTime')}
                            style={({ pressed }) => [
                              styles.timeInput,
                              styles.timePickerBtn,
                              { borderColor: `${accent}40`, opacity: pressed ? 0.85 : 1 },
                            ]}
                          >
                            <Text style={[styles.timeText, { color: textPrimary }]}>{schedule.startTime}</Text>
                            <Ionicons name="time-outline" size={15} color={textMuted} />
                          </Pressable>
                          <Text style={[styles.timeDash, { color: textMuted }]}>–</Text>
                          <Pressable
                            onPress={() => openTimePicker(day, 'endTime')}
                            style={({ pressed }) => [
                              styles.timeInput,
                              styles.timePickerBtn,
                              { borderColor: `${accent}40`, opacity: pressed ? 0.85 : 1 },
                            ]}
                          >
                            <Text style={[styles.timeText, { color: textPrimary }]}>{schedule.endTime}</Text>
                            <Ionicons name="time-outline" size={15} color={textMuted} />
                          </Pressable>
                        </View>
                      ) : (
                        <Text style={[styles.offLabel, { color: textMuted }]}>Off</Text>
                      )}
                    </View>
                    <View style={styles.switchWrap}>
                      <Switch
                        value={schedule.enabled}
                        onValueChange={() => handleDayToggle(day)}
                        trackColor={{ false: 'rgba(255,255,255,0.2)', true: accent }}
                        thumbColor="#FFFFFF"
                        ios_backgroundColor="rgba(255,255,255,0.2)"
                      />
                    </View>
                  </View>
                  {index < DAYS_ORDER.length - 1 && <View style={[styles.divider, { backgroundColor: `${accent}18` }]} />}
                </View>
              );
            })}
          </GlassCard>

          {saving && (
            <View style={styles.savingWrap}>
              <View style={[styles.savingDot, { backgroundColor: accent }]} />
              <Text style={[styles.savingText, { color: textSecondary }]}>Saving…</Text>
            </View>
          )}
        </Animated.View>
      </ScrollView>

      {timePickerTarget && (
        <>
          {Platform.OS === 'ios' ? (
            <Modal transparent animationType="fade" visible onRequestClose={closeTimePicker}>
              <View style={styles.pickerOverlay}>
                <View style={[styles.pickerCard, { backgroundColor: pickerCardBg }]}>
                  <View style={styles.pickerHeader}>
                    <Pressable onPress={closeTimePicker} style={styles.pickerHeaderBtn}>
                      <Text style={[styles.pickerHeaderBtnText, { color: textSecondary }]}>Cancel</Text>
                    </Pressable>
                    <Text style={[styles.pickerTitle, { color: textPrimary }]}>Select time</Text>
                    <Pressable onPress={closeTimePicker} style={styles.pickerHeaderBtn}>
                      <Text style={[styles.pickerHeaderBtnText, { color: accent }]}>Done</Text>
                    </Pressable>
                  </View>
                  <DateTimePicker
                    value={parseTimeToDate(availabilitySchedule[timePickerTarget.day][timePickerTarget.field])}
                    mode="time"
                    display="spinner"
                    is24Hour
                    onChange={(_, selectedDate) => {
                      if (selectedDate) handleTimeSelected(selectedDate);
                    }}
                  />
                </View>
              </View>
            </Modal>
          ) : (
            <DateTimePicker
              value={parseTimeToDate(availabilitySchedule[timePickerTarget.day][timePickerTarget.field])}
              mode="time"
              display="default"
              is24Hour
              onChange={(event, selectedDate) => {
                if (event.type === 'dismissed') {
                  closeTimePicker();
                  return;
                }
                if (selectedDate) {
                  handleTimeSelected(selectedDate);
                }
                closeTimePicker();
              }}
            />
          )}
        </>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollContent: { paddingHorizontal: 20 },
  wrap: { paddingTop: 8 },

  hero: {
    alignItems: 'center',
    marginBottom: 20,
  },
  heroIconWrap: {
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  heroTitle: {
    fontSize: 22,
    fontWeight: '800',
    marginBottom: 6,
    textAlign: 'center',
  },
  heroSubtitle: {
    fontSize: 14,
    fontWeight: '500',
    textAlign: 'center',
    paddingHorizontal: 16,
    lineHeight: 20,
  },

  quickRow: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 20,
  },
  quickBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  quickBtnText: {
    fontSize: 13,
    fontWeight: '700',
  },
  syncCard: {
    borderRadius: 16,
    marginBottom: 18,
    padding: 14,
  },
  syncHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10,
  },
  syncTitleWrap: { flex: 1 },
  syncTitle: {
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 3,
  },
  syncSub: {
    fontSize: 12,
    lineHeight: 18,
  },
  reminderLabel: {
    marginTop: 10,
    marginBottom: 8,
    fontSize: 12,
    fontWeight: '600',
  },
  reminderChips: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  reminderChip: {
    borderWidth: 1,
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
  reminderChipText: {
    fontSize: 12,
    fontWeight: '700',
  },

  card: {
    padding: 0,
    overflow: 'hidden',
    borderRadius: 20,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 16,
    minHeight: 56,
  },
  rowLast: {
    paddingBottom: 16,
  },
  rowAccent: {
    width: 4,
    height: 36,
    borderRadius: 2,
    marginRight: 14,
  },
  rowBody: {
    flex: 1,
    justifyContent: 'center',
    minHeight: 40,
  },
  dayLabel: {
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 4,
  },
  timeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  timeInput: {
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 10,
    borderWidth: 1,
  },
  timePickerBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 6,
  },
  timeText: {
    fontSize: 15,
    fontWeight: '600',
  },
  timeDash: {
    fontSize: 16,
    fontWeight: '700',
  },
  offLabel: {
    fontSize: 14,
    fontWeight: '600',
  },
  switchWrap: {
    marginLeft: 8,
  },
  divider: {
    height: 1,
    marginLeft: 16 + 4 + 14,
  },
  savingWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 16,
  },
  savingDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  savingText: {
    fontSize: 13,
    fontWeight: '600',
  },
  pickerOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.45)',
    justifyContent: 'flex-end',
  },
  pickerCard: {
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    paddingBottom: 20,
  },
  pickerHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 14,
    paddingTop: 12,
  },
  pickerHeaderBtn: {
    paddingVertical: 8,
    minWidth: 54,
  },
  pickerHeaderBtnText: {
    fontSize: 14,
    fontWeight: '700',
  },
  pickerTitle: {
    fontSize: 15,
    fontWeight: '800',
  },
});
