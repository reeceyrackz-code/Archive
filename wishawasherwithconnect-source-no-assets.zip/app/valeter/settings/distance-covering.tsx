import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Alert,
  Animated,
  Platform,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import Slider from '@react-native-community/slider';
import { router } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { supabase } from '../../../src/lib/supabase';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import { fetchRadiusPreference, RadiusColumn } from '../../../src/utils/radiusPreference';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { colors } from '../../../src/constants/colors';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import LoadingScreen from '../../../src/components/LoadingScreen';
import ContinueCTAButton from '../../../src/components/ui/ContinueCTAButton';

const SKY = colors.SKY ?? '#87CEEB';
const VALETER_BG_FALLBACK: [string, string] = ['#0A1929', '#1E3A8A'];

const RADIUS_STEPS = [5, 10, 15, 20, 25, 30] as const;


export default function DistanceCovering() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const gradientBg = (theme?.background || VALETER_BG_FALLBACK) as [string, string];
  const primaryAccent = theme.primary || SKY;

  const [selectedRadius, setSelectedRadius] = useState(10);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingRadius, setIsLoadingRadius] = useState(true);

  const [radiusColumn, setRadiusColumn] = useState<RadiusColumn>('working_radius');
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    loadCurrentRadius();
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);


  const loadCurrentRadius = async () => {
    if (!user?.id) return;

    try {
      setIsLoadingRadius(true);
      const { value, column } = await fetchRadiusPreference(user.id);
      setRadiusColumn(column);

      if (typeof value === 'number') setSelectedRadius(value);
      else setSelectedRadius(10);
    } catch (error) {
      console.error('Error loading radius:', error);
    } finally {
      setIsLoadingRadius(false);
    }
  };


  const handleRadiusChange = (value: number) => {
    hapticFeedback('light');
    const step = 5;
    const rounded = Math.round(value / step) * step;
    setSelectedRadius(Math.min(30, Math.max(5, rounded)));
  };

  const handleSaveRadius = async () => {
    if (!user?.id) {
      Alert.alert('Error', 'Please sign in to update your settings.');
      return;
    }

    try {
      setIsLoading(true);
      await hapticFeedback('medium');

      const { data: existingProfile } = await supabase
        .from('valeter_profiles')
        .select('id')
        .eq('user_id', user.id)
        .maybeSingle();

      const buildPayload = (column: RadiusColumn) => ({
        [column]: selectedRadius,
      });

      let error: any;

      if (existingProfile) {
        const { error: updateError } = await supabase
          .from('valeter_profiles')
          .update(buildPayload(radiusColumn))
          .eq('user_id', user.id);
        error = updateError;
      } else {
        const { error: insertError } = await supabase
          .from('valeter_profiles')
          .insert({ user_id: user.id, ...buildPayload(radiusColumn), is_online: false });
        error = insertError;
      }

      if (error && error.code === '42703' && radiusColumn === 'working_radius') {
        setRadiusColumn('radius_coverage');
        const fallbackPayload = buildPayload('radius_coverage');

        if (existingProfile) {
          const { error: legacyUpdateError } = await supabase
            .from('valeter_profiles')
            .update(fallbackPayload)
            .eq('user_id', user.id);
          error = legacyUpdateError;
        } else {
          const { error: legacyInsertError } = await supabase
            .from('valeter_profiles')
            .insert({ user_id: user.id, ...fallbackPayload, is_online: false });
          error = legacyInsertError;
        }
      }

      if (error && (error.code === '42703' || error.code === 'PGRST204')) {
        Alert.alert(
          'Database Migration Required',
          `Some columns need to be added. Please run this SQL in Supabase:

ALTER TABLE valeter_profiles ADD COLUMN IF NOT EXISTS working_radius INTEGER DEFAULT 10;
ALTER TABLE valeter_profiles ADD COLUMN IF NOT EXISTS availability_schedule JSONB;

Your notification preferences are saved locally on this device.`,
          [{ text: 'OK', onPress: () => router.back() }]
        );
        return;
      }

      if (error) throw error;

      Alert.alert('Settings Updated', `Your settings have been saved successfully.`, [
        { text: 'OK', onPress: () => router.back() },
      ]);
    } catch (error: any) {
      console.error('Error saving settings:', error);
      Alert.alert('Error', error.message || 'Failed to save settings. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const getRadiusDescription = (radius: number) => {
    switch (radius) {
      case 5:
        return 'Perfect for local neighbourhood work';
      case 10:
        return 'Ideal for city district coverage';
      case 15:
        return 'Great for extended city areas';
      case 20:
        return 'Covers metropolitan areas';
      case 25:
        return 'Wide coverage for busy areas';
      case 30:
        return 'Maximum coverage for high-demand areas';
      default:
        return 'Select your preferred coverage area';
    }
  };

  if (isLoadingRadius) {
    return <LoadingScreen message="Loading…" />;
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />
      <AppHeader title="Working radius" accountType="valeter" />

      <ScrollView
        style={styles.content}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          paddingTop: HEADER_CONTENT_OFFSET,
          paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 100,
          paddingHorizontal: 20,
        }}
      >
        <Animated.View style={{ opacity: fadeAnim }}>
          <Text style={styles.sectionTitle}>How far you'll travel for jobs</Text>

          <View style={styles.barCard}>
            <View style={styles.barValueRow}>
              <Text style={styles.barValueLabel}>{selectedRadius} miles</Text>
              <Ionicons name="navigate" size={20} color={SKY} />
            </View>
            <Text style={styles.barDescription}>{getRadiusDescription(selectedRadius)}</Text>

            <View style={styles.sliderWrap}>
              <View style={styles.trackBg} />
              <View style={[styles.trackFill, { width: `${((selectedRadius - 5) / 25) * 100}%` }]} />
              <Slider
                style={styles.slider}
                minimumValue={5}
                maximumValue={30}
                step={5}
                value={selectedRadius}
                onValueChange={handleRadiusChange}
                minimumTrackTintColor="transparent"
                maximumTrackTintColor="transparent"
                thumbTintColor={SKY}
                tapToSeek
              />
            </View>

            <View style={styles.tickRow}>
              {RADIUS_STEPS.map((m) => (
                <TouchableOpacity
                  key={m}
                  onPress={() => handleRadiusChange(m)}
                  style={styles.tick}
                  activeOpacity={0.7}
                >
                  <Text style={[styles.tickText, selectedRadius === m && styles.tickTextActive]}>{m}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </Animated.View>
      </ScrollView>

      <View style={[styles.uberSaveWrap, { bottom: TAB_BAR_TOTAL_HEIGHT + (insets.bottom || 0) + 28 }]}>
        <ContinueCTAButton
          title="Save"
          onPress={handleSaveRadius}
          accentColor={primaryAccent}
          disabled={isLoading}
          loading={isLoading}
          leading={<Ionicons name="checkmark" size={20} color={colors.textOnDarkPrimary} />}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { flex: 1 },

  sectionTitle: {
    color: 'rgba(249,250,251,0.9)',
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 16,
  },
  barCard: {
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 20,
    paddingVertical: 24,
    paddingHorizontal: 20,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  barValueRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 6,
  },
  barValueLabel: {
    color: '#F9FAFB',
    fontSize: 28,
    fontWeight: '800',
    letterSpacing: -0.5,
  },
  barDescription: {
    color: 'rgba(249,250,251,0.65)',
    fontSize: 14,
    marginBottom: 24,
  },
  sliderWrap: {
    height: 28,
    justifyContent: 'center',
    marginHorizontal: 4,
  },
  trackBg: {
    position: 'absolute',
    left: 0,
    right: 0,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255,255,255,0.12)',
  },
  trackFill: {
    position: 'absolute',
    left: 0,
    height: 8,
    borderRadius: 4,
    backgroundColor: SKY,
    opacity: 0.9,
  },
  slider: {
    width: '100%',
    height: 28,
    ...(Platform.OS === 'ios' ? { marginVertical: -10 } : {}),
  },
  tickRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 12,
    paddingHorizontal: 2,
  },
  tick: {
    paddingVertical: 6,
    paddingHorizontal: 4,
    minWidth: 32,
    alignItems: 'center',
  },
  tickText: {
    color: 'rgba(249,250,251,0.5)',
    fontSize: 12,
    fontWeight: '600',
  },
  tickTextActive: {
    color: SKY,
    fontWeight: '700',
  },
  uberSaveWrap: {
    position: 'absolute',
    left: 16,
    right: 16,
    paddingBottom: 0,
  },
});
