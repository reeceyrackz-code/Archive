/**
 * Valeter Inbox – Support messages with customers during jobs. Premium redesign.
 */
import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  RefreshControl,
  ScrollView,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { router } from 'expo-router';
import { ChromeGlyph as Ionicons } from '../../src/components/shared/ChromeGlyph';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import EmptyState from '../../src/components/shared/EmptyState';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { colors } from '../../src/constants/colors';
import { getServiceDisplayName } from '../../src/utils/serviceNameMapper';
import { formatDisplayName } from '../../src/utils/formatDisplayName';
import { getDeletedChatBookingIds, addMultipleDeletedChatBookingIds } from '../../src/services/DeletedChatsService';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import { HEADER_STYLE_CARD_GRADIENT } from '../../src/constants/bookingCardTheme';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';
import DefaultLoadingSkeleton from '../../src/components/shared/DefaultLoadingSkeleton';

const SKY = colors.SKY ?? '#38BDF8';

const INBOX_BOOKING_STATUSES: string[] = [
  'confirmed',
  'en_route',
  'arrived',
  'in_progress',
];

type InboxThread = {
  id: string;
  bookingId: string;
  customerName: string;
  serviceDisplayName: string;
  status: string;
  address?: string | null;
  updatedAt: string;
};

function formatRelativeDate(iso: string): string {
  const d = new Date(iso);
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / (24 * 60 * 60 * 1000));
  if (diffMins < 1) return 'Just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays === 0) return d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
  if (diffDays === 1) return 'Yesterday';
  if (diffDays < 7) return `${diffDays}d ago`;
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
}

async function getCustomerName(userId: string): Promise<string> {
  try {
    const { data } = await supabase
      .from('profiles')
      .select('full_name')
      .eq('id', userId)
      .maybeSingle();
    return (data as any)?.full_name || 'Customer';
  } catch {
    return 'Customer';
  }
}

export default function ValeterInboxScreen() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const accent = theme?.primary ?? SKY;
  const gradientBg = (theme?.background ?? ['#0A1929', '#1e3a5f']) as [string, string];
  const cardGradient = (theme?.headerBackground ?? HEADER_STYLE_CARD_GRADIENT) as [string, string];

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [threads, setThreads] = useState<InboxThread[]>([]);

  const loadThreads = useCallback(async () => {
    if (!user?.id) {
      setThreads([]);
      setLoading(false);
      return;
    }
    try {
      const [{ data: rows, error }, deletedIds] = await Promise.all([
        supabase
          .from('bookings')
          .select('id, user_id, service_type, service_name, status, location_address, updated_at, created_at')
          .eq('valeter_id', user.id)
          .in('status', INBOX_BOOKING_STATUSES)
          .order('updated_at', { ascending: false })
          .limit(50),
        getDeletedChatBookingIds(),
      ]);

      if (error) throw error;

      const list: InboxThread[] = [];
      for (const row of rows || []) {
        const r = row as any;
        if (deletedIds.has(r.id)) continue;
        const customerName = await getCustomerName(r.user_id);
        list.push({
          id: r.id,
          bookingId: r.id,
          customerName,
          serviceDisplayName: getServiceDisplayName(r.service_type, r.service_name),
          status: r.status || 'scheduled',
          address: r.location_address,
          updatedAt: r.updated_at || r.created_at || new Date().toISOString(),
        });
      }
      setThreads(list);
    } catch (e) {
      console.error('[ValeterInbox] load error', e);
      setThreads([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [user?.id]);

  useEffect(() => {
    loadThreads();
  }, [loadThreads]);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    loadThreads();
  }, [loadThreads]);

  const openChat = useCallback((bookingId: string) => {
    hapticFeedback('light');
    router.push({ pathname: '/valeter/jobs/chat', params: { bookingId } } as any);
  }, []);

  const handleClearAll = useCallback(() => {
    if (threads.length === 0) return;
    hapticFeedback('medium');
    Alert.alert(
      'Hide all chats',
      'Hide all conversations from your inbox? They will be removed from this list only (not deleted). You can still access chats from the job.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Hide all',
          style: 'destructive',
          onPress: async () => {
            const ids = threads.map((t) => t.id);
            await addMultipleDeletedChatBookingIds(ids);
            setThreads([]);
          },
        },
      ]
    );
  }, [threads]);

  return (
    <View style={styles.container}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <AppHeader
        title="Inbox"
        subtitle="Messages with customers during jobs"
        showBack
        onBack={() => {
          hapticFeedback('light');
          router.back();
        }}
        accountType="valeter"
        rightAction={
          threads.length > 0 ? (
            <TouchableOpacity onPress={handleClearAll} style={styles.headerClearBtn} hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}>
              <Ionicons name="trash-outline" size={22} color={accent} />
            </TouchableOpacity>
          ) : undefined
        }
      />
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingTop: HEADER_CONTENT_OFFSET,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 24,
          },
        ]}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={accent} />}
      >
        {loading ? (
          <View style={styles.centered}>
            <DefaultLoadingSkeleton message="Loading inbox…" variant="rich" />
          </View>
        ) : threads.length === 0 ? (
          <Animated.View entering={FadeInDown.delay(100)} style={styles.emptyContainer}>
            <EmptyState
              icon="chatbubbles-outline"
              title="No messages yet"
              subtitle="When you have active or recent jobs, you can message customers here. Tap a thread to open the chat."
              actionLabel="View jobs"
              onAction={() => router.push('/valeter/jobs')}
              iconColor={accent}
            />
          </Animated.View>
        ) : (
          <>
            {/* Summary strip */}
            <View style={[styles.summaryStrip, { borderColor: `${accent}40`, shadowColor: accent }]}>
              <BlurView intensity={20} tint="dark" style={StyleSheet.absoluteFill} />
              <LinearGradient colors={cardGradient} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1 }} style={StyleSheet.absoluteFill} />
              <View style={styles.summaryOverlay} />
              <View style={styles.summaryRow}>
                <Ionicons name="mail-open" size={20} color={accent} />
                <Text style={[styles.summaryTitle, { color: '#F9FAFB' }]}>Support messages</Text>
                <View style={[styles.summaryPill, { backgroundColor: `${accent}30` }]}>
                  <Text style={[styles.summaryCount, { color: accent }]}>{threads.length}</Text>
                  <Text style={[styles.summaryLabel, { color: accent }]}>
                    {threads.length === 1 ? 'conversation' : 'conversations'}
                  </Text>
                </View>
              </View>
            </View>

            {threads.map((thread, index) => (
              <Animated.View
                key={thread.bookingId}
                entering={FadeInDown.delay(80 + index * 50)}
                style={styles.threadWrap}
              >
                <TouchableOpacity
                  activeOpacity={0.85}
                  onPress={() => openChat(thread.bookingId)}
                  style={[styles.threadCard, { borderColor: `${accent}35`, shadowColor: accent }]}
                >
                  <BlurView intensity={16} tint="dark" style={StyleSheet.absoluteFill} />
                  <LinearGradient colors={cardGradient} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1 }} style={StyleSheet.absoluteFill} />
                  <View style={styles.cardOverlay} />
                  <View style={styles.threadInner}>
                    <View style={[styles.avatarWrap, { backgroundColor: `${accent}20`, borderColor: `${accent}40` }]}>
                      <Ionicons name="person-circle-outline" size={44} color={accent} />
                    </View>
                    <View style={styles.threadBody}>
                      <View style={styles.threadTopRow}>
                        <Text style={styles.threadName} numberOfLines={1}>
                          {formatDisplayName(thread.customerName)}
                        </Text>
                        <Text style={[styles.threadDate, { color: accent }]}>Updated {formatRelativeDate(thread.updatedAt)}</Text>
                      </View>
                      <Text style={[styles.threadService, { color: accent }]} numberOfLines={1}>
                        {thread.serviceDisplayName}
                      </Text>
                      {thread.address ? (
                        <View style={styles.addressRow}>
                          <Ionicons name="location-outline" size={12} color="#94A3B8" />
                          <Text style={styles.addressText} numberOfLines={1}>{thread.address}</Text>
                        </View>
                      ) : null}
                      <View style={styles.openChatRow}>
                        <View style={[styles.openChatBtn, { backgroundColor: `${accent}30` }]}>
                          <Ionicons name="chatbubble-outline" size={16} color={accent} />
                          <Text style={[styles.openChatBtnText, { color: accent }]}>Open chat</Text>
                        </View>
                      </View>
                    </View>
                  </View>
                </TouchableOpacity>
              </Animated.View>
            ))}
          </>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollView: { flex: 1 },
  scrollContent: { paddingHorizontal: 20 },
  centered: {
    paddingVertical: 48,
    alignItems: 'center',
    gap: 12,
  },
  loadingText: { fontSize: 14, fontWeight: '600' },
  emptyContainer: { flex: 1, minHeight: 280, justifyContent: 'center' },
  headerClearBtn: {
    width: 44,
    height: 44,
    justifyContent: 'center',
    alignItems: 'center',
  },
  summaryStrip: {
    borderRadius: 18,
    overflow: 'hidden',
    marginBottom: 20,
    borderWidth: 1.5,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 10,
    elevation: 3,
  },
  summaryOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.2)',
  },
  summaryRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 18,
    gap: 12,
  },
  summaryTitle: {
    flex: 1,
    fontSize: 16,
    fontWeight: '800',
  },
  summaryPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  summaryCount: { fontSize: 15, fontWeight: '800' },
  summaryLabel: { fontSize: 12, fontWeight: '600' },
  threadWrap: { marginBottom: 12 },
  threadCard: {
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1.5,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.12,
    shadowRadius: 8,
    elevation: 2,
  },
  cardOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.15)',
  },
  threadInner: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    padding: 16,
  },
  avatarWrap: {
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 14,
    borderWidth: 1,
  },
  threadBody: { flex: 1, minWidth: 0 },
  threadTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 8,
    marginBottom: 4,
  },
  threadName: {
    fontSize: 17,
    fontWeight: '800',
    color: '#F9FAFB',
    flex: 1,
  },
  threadDate: { fontSize: 12, fontWeight: '600' },
  threadService: { fontSize: 13, fontWeight: '700', marginBottom: 4 },
  addressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 10,
  },
  addressText: { fontSize: 12, color: '#94A3B8', flex: 1 },
  openChatRow: { flexDirection: 'row', justifyContent: 'flex-end' },
  openChatBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 12,
  },
  openChatBtnText: { fontSize: 13, fontWeight: '800' },
});
