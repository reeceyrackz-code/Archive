import React, { useState, useEffect, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { ChromeGlyph as Ionicons } from '../../src/components/shared/ChromeGlyph';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import LoadingScreen from '../../src/components/LoadingScreen';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import { colors } from '../../src/constants/colors';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const VALETER_BG_FALLBACK: [string, string] = ['#0A1929', '#2563EB'];

const CHART_HEIGHT = 200;
const BAR_GAP = 6;
const NUM_WEEKS = 6;
const NUM_MONTHS = 6;

type PeriodMode = 'weeks' | 'months';

interface ChartBar {
  label: string;
  value: number;
  jobs: number;
}

export default function ValeterWashHistory() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const gradientBg = (theme?.background || VALETER_BG_FALLBACK) as [string, string];
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [bookings, setBookings] = useState<any[]>([]);
  const [totalEarnings, setTotalEarnings] = useState(0);
  const [periodMode, setPeriodMode] = useState<PeriodMode>('weeks');
  const [stats, setStats] = useState({
    totalJobs: 0,
    thisMonth: 0,
    thisWeek: 0,
    averageRating: 0,
  });

  const loadBookings = async () => {
    if (!user?.id) return;
    try {
      const { data: allBookings, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('valeter_id', user.id);

      if (error) throw error;

      const bookingsList = allBookings || [];
      const completed = bookingsList.filter((b: any) =>
        ['completed', 'rated', 'closed'].includes(b.status)
      );

      const sorted = completed.sort((a: any, b: any) => {
        const dateA = a.updated_at || a.created_at || a.completed_at;
        const dateB = b.updated_at || b.created_at || b.completed_at;
        const timeA = dateA ? new Date(dateA).getTime() : 0;
        const timeB = dateB ? new Date(dateB).getTime() : 0;
        return timeB - timeA;
      });

      setBookings(sorted);

      const earnings = completed.reduce((sum: number, b: any) => sum + (b.price || 0), 0);
      setTotalEarnings(earnings);

      const now = new Date();
      const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const firstDayOfWeek = new Date(now);
      firstDayOfWeek.setDate(now.getDate() - now.getDay());

      const thisMonth = completed.filter((b: any) => {
        const date = b.updated_at || b.created_at || b.completed_at;
        return date && new Date(date) >= firstDayOfMonth;
      }).length;

      const thisWeek = completed.filter((b: any) => {
        const date = b.updated_at || b.created_at || b.completed_at;
        return date && new Date(date) >= firstDayOfWeek;
      }).length;

      setStats({
        totalJobs: completed.length,
        thisMonth,
        thisWeek,
        averageRating: 0,
      });
    } catch (error: any) {
      console.error('[ValeterWashHistory] Error loading bookings:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const chartData = useMemo((): ChartBar[] => {
    const completed = bookings.filter((b: any) =>
      ['completed', 'rated', 'closed'].includes(b.status)
    );
    const now = new Date();

    if (periodMode === 'weeks') {
      const bars: ChartBar[] = [];
      for (let i = NUM_WEEKS - 1; i >= 0; i--) {
        const weekEnd = new Date(now);
        weekEnd.setDate(now.getDate() - now.getDay() - i * 7);
        const weekStart = new Date(weekEnd);
        weekStart.setDate(weekEnd.getDate() - 6);
        const periodEarnings = completed
          .filter((b: any) => {
            const date = b.completed_at || b.updated_at || b.created_at;
            if (!date) return false;
            const d = new Date(date);
            return d >= weekStart && d <= new Date(weekEnd.getTime() + 86400000);
          })
          .reduce((sum: number, b: any) => sum + (b.price || 0), 0);
        const periodJobs = completed.filter((b: any) => {
          const date = b.completed_at || b.updated_at || b.created_at;
          if (!date) return false;
          const d = new Date(date);
          return d >= weekStart && d <= new Date(weekEnd.getTime() + 86400000);
        }).length;
        const label = weekEnd.getDate().toString();
        const shortMonth = weekEnd.toLocaleDateString('en-GB', { month: 'short' });
        bars.push({ label: `${shortMonth} ${label}`, value: periodEarnings, jobs: periodJobs });
      }
      return bars;
    }

    const bars: ChartBar[] = [];
    for (let i = NUM_MONTHS - 1; i >= 0; i--) {
      const monthDate = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const nextMonth = new Date(monthDate.getFullYear(), monthDate.getMonth() + 1, 1);
      const periodEarnings = completed
        .filter((b: any) => {
          const date = b.completed_at || b.updated_at || b.created_at;
          if (!date) return false;
          const d = new Date(date);
          return d >= monthDate && d < nextMonth;
        })
        .reduce((sum: number, b: any) => sum + (b.price || 0), 0);
      const periodJobs = completed.filter((b: any) => {
        const date = b.completed_at || b.updated_at || b.created_at;
        if (!date) return false;
        const d = new Date(date);
        return d >= monthDate && d < nextMonth;
      }).length;
      const label = monthDate.toLocaleDateString('en-GB', { month: 'short', year: '2-digit' });
      bars.push({ label, value: periodEarnings, jobs: periodJobs });
    }
    return bars;
  }, [bookings, periodMode]);

  const maxChartValue = useMemo(() => {
    if (chartData.length === 0) return 1;
    const max = Math.max(...chartData.map((b) => b.value));
    return max > 0 ? max : 1;
  }, [chartData]);

  useEffect(() => {
    loadBookings();
  }, [user?.id]);

  const onRefresh = () => {
    setRefreshing(true);
    loadBookings();
  };


  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LoadingScreen message="Loading earnings history…" />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <AppHeader
        title="Earnings"
        subtitle={`£${totalEarnings.toFixed(2)} total`}
        rightAction={
          <TouchableOpacity onPress={loadBookings} style={styles.refreshButton}>
            <Ionicons name="refresh" size={20} color={SKY} />
          </TouchableOpacity>
        }
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingTop: HEADER_CONTENT_OFFSET,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20,
          },
        ]}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />}
      >
        {/* Total Earnings hero */}
        <View style={styles.earningsCard}>
          <LinearGradient
            colors={['rgba(135,206,235,0.28)', 'rgba(37,99,235,0.22)', 'rgba(135,206,235,0.18)']}
            style={styles.earningsGradient}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
          >
            <View style={styles.earningsIconWrapper}>
              <LinearGradient
                colors={['rgba(135,206,235,0.4)', 'rgba(37,99,235,0.3)']}
                style={StyleSheet.absoluteFill}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
              />
              <Ionicons name="wallet" size={36} color={SKY} />
            </View>
            <Text style={styles.earningsLabel}>Total Earnings</Text>
            <Text style={styles.earningsValue}>£{totalEarnings.toFixed(2)}</Text>
            <Text style={styles.earningsSubtext}>{bookings.length} completed jobs</Text>
          </LinearGradient>
        </View>

        {/* Bar chart */}
        <View style={styles.chartSection}>
          <View style={styles.chartSectionHeader}>
            <Text style={styles.chartSectionTitle}>Earnings over time</Text>
            <View style={styles.periodToggle}>
              <TouchableOpacity
                style={[styles.periodBtn, periodMode === 'weeks' && styles.periodBtnActive]}
                onPress={() => setPeriodMode('weeks')}
                activeOpacity={0.8}
              >
                <Text style={[styles.periodBtnText, periodMode === 'weeks' && styles.periodBtnTextActive]}>
                  6 weeks
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.periodBtn, periodMode === 'months' && styles.periodBtnActive]}
                onPress={() => setPeriodMode('months')}
                activeOpacity={0.8}
              >
                <Text style={[styles.periodBtnText, periodMode === 'months' && styles.periodBtnTextActive]}>
                  6 months
                </Text>
              </TouchableOpacity>
            </View>
          </View>
          <View style={styles.chartCard}>
            <View style={styles.chartYAxis}>
              <Text style={styles.chartYLabel}>
                £{maxChartValue >= 1000 ? (maxChartValue / 1000).toFixed(1) + 'k' : Math.ceil(maxChartValue).toString()}
              </Text>
              <Text style={styles.chartYLabel}>£0</Text>
            </View>
            <View style={styles.chartBarsWrap}>
              {chartData.map((bar, index) => {
                const heightPct = maxChartValue > 0 ? bar.value / maxChartValue : 0;
                const barHeight = Math.max(heightPct * CHART_HEIGHT, bar.value > 0 ? 8 : 0);
                return (
                  <View key={`${periodMode}-${index}-${bar.label}`} style={styles.barColumn}>
                    <View style={styles.barContainer}>
                      <View style={[styles.barPlaceholder, { height: CHART_HEIGHT }]}>
                        <LinearGradient
                          colors={bar.value > 0 ? [SKY, '#0EA5E9'] : ['rgba(135,206,235,0.12)', 'rgba(135,206,235,0.08)']}
                          style={[styles.barFill, { height: barHeight }]}
                          start={{ x: 0.5, y: 1 }}
                          end={{ x: 0.5, y: 0 }}
                        />
                      </View>
                    </View>
                    <Text style={styles.barLabel} numberOfLines={1}>{bar.label}</Text>
                    {bar.value > 0 && (
                      <Text style={styles.barValue}>£{bar.value.toFixed(0)}</Text>
                    )}
                  </View>
                );
              })}
            </View>
          </View>
        </View>

        {/* Stats Grid */}
        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{stats.totalJobs}</Text>
            <Text style={styles.statLabel}>Total Jobs</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{stats.thisMonth}</Text>
            <Text style={styles.statLabel}>This Month</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{stats.thisWeek}</Text>
            <Text style={styles.statLabel}>This Week</Text>
          </View>
          {stats.averageRating > 0 && (
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{stats.averageRating.toFixed(1)}</Text>
              <Text style={styles.statLabel}>Avg Rating</Text>
            </View>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  scrollView: { flex: 1 },
  scrollContent: { padding: 20 },
  refreshButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  earningsCard: {
    borderRadius: 24,
    overflow: 'hidden',
    marginBottom: 24,
    elevation: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.35,
    shadowRadius: 12,
    borderWidth: 2,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  earningsGradient: {
    padding: 32,
    alignItems: 'center',
  },
  earningsIconWrapper: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(135,206,235,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 18,
    borderWidth: 2.5,
    borderColor: 'rgba(135,206,235,0.5)',
    overflow: 'hidden',
  },
  earningsLabel: {
    color: '#87CEEB',
    fontSize: 15,
    fontWeight: '600',
    marginBottom: 8,
    letterSpacing: 0.5,
  },
  earningsValue: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 40 : 48,
    fontWeight: '800',
    marginBottom: 6,
  },
  earningsSubtext: {
    color: '#87CEEB',
    fontSize: 14,
    opacity: 0.9,
    fontWeight: '500',
  },
  chartSection: {
    marginBottom: 24,
  },
  chartSectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 14,
    paddingHorizontal: 4,
  },
  chartSectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
  },
  periodToggle: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 12,
    padding: 4,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  periodBtn: {
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 10,
  },
  periodBtnActive: {
    backgroundColor: 'rgba(135,206,235,0.35)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.5)',
  },
  periodBtnText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 13,
    fontWeight: '600',
  },
  periodBtnTextActive: {
    color: '#F9FAFB',
  },
  chartCard: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 20,
    paddingVertical: 20,
    paddingHorizontal: 16,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.25)',
    alignItems: 'flex-end',
  },
  chartYAxis: {
    width: 36,
    justifyContent: 'space-between',
    height: CHART_HEIGHT + 4,
    marginRight: 8,
  },
  chartYLabel: {
    color: 'rgba(255,255,255,0.5)',
    fontSize: 10,
    fontWeight: '600',
  },
  chartBarsWrap: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    gap: BAR_GAP,
  },
  barColumn: {
    flex: 1,
    alignItems: 'center',
    minWidth: 0,
  },
  barContainer: {
    width: '100%',
    alignItems: 'center',
  },
  barPlaceholder: {
    width: '80%',
    maxWidth: 32,
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  barFill: {
    width: '100%',
    minHeight: 4,
    borderTopLeftRadius: 6,
    borderTopRightRadius: 6,
  },
  barLabel: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 10,
    fontWeight: '600',
    marginTop: 8,
    textAlign: 'center',
  },
  barValue: {
    color: SKY,
    fontSize: 10,
    fontWeight: '700',
    marginTop: 2,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 24,
  },
  statCard: {
    flex: 1,
    minWidth: (width - (isSmallScreen ? 36 : 40) - 12) / 2,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 20,
    padding: 18,
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.25,
    shadowRadius: 6,
  },
  statNumber: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 24 : 28,
    fontWeight: '800',
    marginBottom: 4,
  },
  statLabel: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '600',
  },
});
