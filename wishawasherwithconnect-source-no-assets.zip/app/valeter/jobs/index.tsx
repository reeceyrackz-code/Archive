import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  RefreshControl,
  Image,
  Modal,
  Alert,
  Platform,
} from 'react-native';
import MapView, { Marker, Region } from 'react-native-maps';
import { BlurView } from 'expo-blur';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons, type IconGlyphName } from '../../../src/components/shared/ChromeGlyph';
import { router } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import {
  fetchProfilesByIds,
  resolveCustomerAvatarFromProfileRow,
  type CustomerProfileRow,
} from '../../../src/utils/customerProfiles';
import { fetchRadiusPreference } from '../../../src/utils/radiusPreference';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import GradientIconBox, { LocationStyleIconBox } from '../../../src/components/shared/GradientIconBox';
import { accentToGradient } from '../../../src/utils/accentGradient';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { colors } from '../../../src/constants/colors';
import { SCREEN_PADDING_H, CARD_GAP } from '../../../src/constants/premiumTokens';
import { DARK_MAP_STYLE } from '../../../src/constants/mapStyles';
import { CAR_IMAGE } from '../../../src/constants/washerAssets';
import DefaultLoadingSkeleton from '../../../src/components/shared/DefaultLoadingSkeleton';
import { notifyValeterJobRequest, preparePhoneNotifications } from '../../../src/services/valeterJobPhoneNotifications';
import { syncValeterBookingsToDeviceCalendar } from '../../../src/services/bookingCalendarSync';
import {
  assertNoScheduleConflictForOffer,
  loadValeterScheduleBlocks,
  offerOverlapsSchedule,
  valeterScheduleAllowsJobOffer,
} from '../../../src/services/valeterScheduleConflict';

const SKY = colors.SKY ?? '#38BDF8';

interface JobRequest {
  id: string;
  service_type: string;
  service_name?: string;
  price: number;
  location_address: string;
  location_lat?: number | null;
  location_lng?: number | null;
  scheduled_at?: string;
  request_sent_at: string;
  customer_name?: string;
  customer_photo?: string | null;
  customer_rating?: number;
  customer_review_count?: number;
  distance?: number;
  drive_time_minutes?: number;
  formatted_location?: string;
  assignedToValeter?: boolean;
  status?: string;
  vehicle_type?: string | null;
  vehicle_info?: string | null;
  vehicle_registration?: string | null;
  vehicle_make?: string | null;
  vehicle_model?: string | null;
  vehicle_photo?: string | null;
}

function haversineMi(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 3959;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function formatRelativeTime(dateString: string): string {
  const diffMs = Date.now() - new Date(dateString).getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);
  if (diffMins < 1) return 'Just now';
  if (diffMins < 60) return `${diffMins} min ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays < 7) return `${diffDays}d ago`;
  return new Date(dateString).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
}

function bookingFieldString(value: unknown, fallback = ''): string {
  if (value === null || value === undefined) {
    return fallback;
  }
  if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
    return String(value);
  }
  return fallback;
}

type VehicleExtras = {
  registration?: string;
  make?: string;
  model?: string;
  type?: string;
  photo?: string;
};

type MapRawBookingContext = Readonly<{
  valeterUserId: string;
  vehicleMap: Map<string, VehicleExtras>;
  profiles: Map<string, CustomerProfileRow>;
  vLat: number | null | undefined;
  vLng: number | null | undefined;
}>;

function jobVehicleInfoFromRaw(raw: unknown): string | null {
  if (raw === null || raw === undefined) {
    return null;
  }
  const s = bookingFieldString(raw, '—');
  return s === '' ? null : s;
}

function attachOptionalJobRowFields(row: JobRequest, j: Record<string, unknown>): void {
  if (j.service_name !== null && j.service_name !== undefined) {
    row.service_name = bookingFieldString(j.service_name);
  }
  if (j.scheduled_at !== null && j.scheduled_at !== undefined) {
    row.scheduled_at = bookingFieldString(j.scheduled_at);
  }
  if (j.status !== null && j.status !== undefined) {
    row.status = bookingFieldString(j.status);
  }
}

function mapRawBookingToJobRequest(j: Record<string, unknown>, ctx: MapRawBookingContext): JobRequest {
  const { valeterUserId, vehicleMap, profiles, vLat, vLng } = ctx;
  const jid = j.id;
  const uid = j.user_id;
  const valeterOnJob = j.valeter_id;
  const assigned =
    typeof valeterOnJob === 'string'
      ? valeterOnJob === valeterUserId
      : (typeof valeterOnJob === 'number' || typeof valeterOnJob === 'bigint') &&
        String(valeterOnJob) === valeterUserId;
  let distance: number | undefined;
  let driveTime: number | undefined;
  const locLat = j.location_lat as number | null | undefined;
  const locLng = j.location_lng as number | null | undefined;
  if (vLat != null && vLng != null && locLat != null && locLng != null) {
    distance = Math.round(haversineMi(vLat, vLng, locLat, locLng) * 10) / 10;
    driveTime = Math.round((distance ?? 0) * 2);
  }
  const userIdStr = typeof uid === 'string' ? uid : null;
  const vehicle = userIdStr ? vehicleMap.get(userIdStr) : null;
  const prof = userIdStr ? profiles.get(userIdStr) : null;
  const addr = bookingFieldString(j.location_address);
  const vehicleInfo = jobVehicleInfoFromRaw(j.vehicle_info);
  const row: JobRequest = {
    id: bookingFieldString(jid, ''),
    service_type: bookingFieldString(j.service_type),
    price: Number(j.price ?? 0),
    location_address: addr,
    location_lat: locLat ?? null,
    location_lng: locLng ?? null,
    request_sent_at: bookingFieldString(j.request_sent_at),
    customer_name: prof?.full_name || prof?.name || 'Customer',
    customer_photo: resolveCustomerAvatarFromProfileRow(prof ?? null),
    formatted_location: formatLocation(addr || '—'),
    assignedToValeter: assigned,
    vehicle_type: (typeof j.vehicle_type === 'string' && j.vehicle_type) || vehicle?.type || null,
    vehicle_info: vehicleInfo,
    vehicle_registration: vehicle?.registration ?? null,
    vehicle_make: vehicle?.make ?? null,
    vehicle_model: vehicle?.model ?? null,
    vehicle_photo: vehicle?.photo ?? null,
  };
  if (distance !== undefined) {
    row.distance = distance;
  }
  if (driveTime !== undefined) {
    row.drive_time_minutes = driveTime;
  }
  attachOptionalJobRowFields(row, j);
  return row;
}

function formatLocation(address: string): string {
  const postcodeRegex = /\b([A-Z]{1,2}\d{1,2}[A-Z]?\s?\d[A-Z]{2})\b/i;
  const match = postcodeRegex.exec(address);
  const postcode = match ? match[1].toUpperCase() : null;
  const parts = address.split(',').map((p) => p.trim());
  const area = parts.at(-3) || parts.at(-2) || parts[0] || address;
  if (postcode && area) return `${area.replace(postcode, '').trim()} (${postcode})`;
  if (postcode) return `(${postcode})`;
  return area;
}

function getTierColor(serviceType?: string, serviceName?: string): string {
  const s = getServiceDisplayName(serviceType, serviceName);
  if (s.includes('Bronze')) return '#CD7F32';
  if (s.includes('Silver')) return '#C0C0C0';
  if (s.includes('Diamond') || s.includes('Gold')) return '#10B981';
  if (s.includes('Platinum')) return '#E5E4E2';
  return SKY;
}

function getTierIcon(serviceType?: string, serviceName?: string): IconGlyphName {
  const s = getServiceDisplayName(serviceType, serviceName);
  if (s.includes('Ceramic')) return 'shield-checkmark-outline';
  if (s.includes('Polishing')) return 'color-filter-outline';
  return 'car-outline';
}

const DEFAULT_VALETER_PAGE_BG: [string, string] = ['#0A1929', '#1E3A8A'];

function valeterPageBackground(theme: { background?: readonly string[] } | undefined): [string, string] {
  const bg = theme?.background;
  if (Array.isArray(bg) && bg.length >= 2) {
    return [String(bg[0]), String(bg[1])];
  }
  return DEFAULT_VALETER_PAGE_BG;
}

function valeterModalHeaderGradient(theme: { headerBackground?: readonly string[] } | undefined): [string, string] {
  const hb = theme?.headerBackground;
  if (Array.isArray(hb) && hb.length >= 2) {
    return [String(hb[0]), String(hb[1])];
  }
  return ['rgba(10,25,41,0.98)', 'rgba(5,13,20,0.98)'];
}

function jobDetailDriveTimeSuffix(minutes: number | null | undefined): string {
  if (minutes == null) return '';
  return ` · ~${minutes} min`;
}

function ValeterJobDetailCustomerAvatar({ job, sky }: Readonly<{ job: JobRequest; sky: string }>) {
  if (job.customer_photo) {
    return <Image source={{ uri: job.customer_photo }} style={styles.jobDetailCustomerAvatar} resizeMode="cover" />;
  }
  if (job.vehicle_photo) {
    return <Image source={{ uri: job.vehicle_photo }} style={styles.jobDetailCustomerAvatar} resizeMode="cover" />;
  }
  return (
    <View style={[styles.jobDetailCustomerAvatarPlaceholder, { backgroundColor: `${sky}22` }]}>
      <LocationStyleIconBox variant="inline" icon="person" colors={accentToGradient(sky)} />
    </View>
  );
}

function ValeterJobDetailActions({
  job,
  accent,
  onPrimary,
  onAccept,
  onDecline,
}: Readonly<{
  job: JobRequest;
  accent: string;
  onPrimary: (j: JobRequest) => void;
  onAccept: (j: JobRequest) => void;
  onDecline: (j: JobRequest) => void;
}>) {
  if (job.status === 'pending_payment') {
    return (
      <View style={styles.awaitingPaymentBlock}>
        <View style={[styles.jobDetailBtn, styles.jobDetailBtnDisabled]}>
          <Ionicons name="wallet-outline" size={18} color="#F59E0B" />
          <Text style={styles.jobDetailBtnTextLocked}>Locked until customer pays</Text>
        </View>
        <Text style={styles.awaitingPaymentSub}>Unlocks when customer completes payment – then you can start the trip.</Text>
      </View>
    );
  }
  const assignedOrAccepted = job.assignedToValeter || (job.status != null && job.status !== 'pending_valeter_acceptance');
  if (assignedOrAccepted) {
    return (
      <TouchableOpacity onPress={() => onPrimary(job)} style={[styles.jobDetailBtn, { backgroundColor: accent }]} activeOpacity={0.9}>
        <Ionicons name="navigate" size={18} color="#fff" />
        <Text style={styles.jobDetailBtnText}>View trip</Text>
      </TouchableOpacity>
    );
  }
  return (
    <>
      <TouchableOpacity onPress={() => onDecline(job)} style={styles.jobDetailDeclineBtn} activeOpacity={0.9}>
        <Ionicons name="close-circle-outline" size={18} color="#EF4444" />
        <Text style={styles.jobDetailDeclineBtnText}>Decline</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => onAccept(job)} style={[styles.jobDetailBtn, styles.jobDetailAcceptBtn, { backgroundColor: accent }]} activeOpacity={0.9}>
        <Ionicons name="checkmark-circle" size={18} color="#fff" />
        <Text style={styles.jobDetailBtnText}>Accept</Text>
      </TouchableOpacity>
    </>
  );
}

type ValeterJobDetailSheetProps = {
  job: JobRequest;
  accent: string;
  sky: string;
  insetsBottom: number;
  mapRegion: Region | null;
  valeterCoords: { lat: number; lng: number } | null;
  onClose: () => void;
  onPrimary: (j: JobRequest) => void;
  onAccept: (j: JobRequest) => void;
  onDecline: (j: JobRequest) => void;
};

function ValeterJobDetailSheet({
  job,
  accent,
  sky,
  insetsBottom,
  mapRegion,
  valeterCoords,
  onClose,
  onPrimary,
  onAccept,
  onDecline,
}: Readonly<ValeterJobDetailSheetProps>) {
  return (
    <>
      <View style={styles.modalHeader}>
        <View style={[styles.jobsSheetPill, { backgroundColor: `${accent}20`, borderColor: `${accent}50` }]}>
          <LocationStyleIconBox variant="micro" icon="briefcase-outline" colors={accentToGradient(accent)} />
          <Text style={[styles.jobsSheetPillText, { color: accent }]}>Job</Text>
        </View>
        <TouchableOpacity onPress={onClose} style={styles.jobDetailCloseBtn} hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}>
          <LocationStyleIconBox variant="card" icon="close" preset="gray" />
        </TouchableOpacity>
      </View>
      <View style={[styles.jobDetailCard, { marginHorizontal: SCREEN_PADDING_H, marginBottom: insetsBottom + 16 }]}>
        {mapRegion ? (
          <>
            <MapView
              style={styles.jobDetailCardMap}
              region={mapRegion}
              scrollEnabled={false}
              zoomEnabled={false}
              pitchEnabled={false}
              rotateEnabled={false}
              customMapStyle={DARK_MAP_STYLE}
            >
              {valeterCoords && (
                <Marker coordinate={{ latitude: valeterCoords.lat, longitude: valeterCoords.lng }} title="You" anchor={{ x: 0.5, y: 1 }}>
                  <View style={[styles.jobDetailMapMarkerYou, { backgroundColor: accent }]}>
                    <Ionicons name="location" size={14} color="#fff" />
                  </View>
                </Marker>
              )}
              <Marker
                coordinate={{ latitude: job.location_lat!, longitude: job.location_lng! }}
                title={job.customer_name || 'Customer'}
                description={getServiceDisplayName(job.service_type, job.service_name)}
                anchor={{ x: 0.5, y: 1 }}
              >
                <View style={styles.jobDetailMapMarkerJob}>
                  <Image source={CAR_IMAGE} style={styles.jobDetailMapMarkerJobImage} resizeMode="contain" />
                </View>
              </Marker>
            </MapView>
            <LinearGradient
              colors={['rgba(0,0,0,0.35)', 'rgba(0,0,0,0.7)', 'rgba(0,0,0,0.85)']}
              style={StyleSheet.absoluteFill}
              start={{ x: 0.5, y: 0 }}
              end={{ x: 0.5, y: 1 }}
            />
            <BlurView
              intensity={Platform.OS === 'ios' ? 28 : 48}
              tint="dark"
              style={[StyleSheet.absoluteFill, { opacity: 0.85 }]}
              {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
            />
          </>
        ) : null}
        <View style={styles.jobDetailCardContent}>
          <View style={styles.jobDetailRequestBadge}>
            <View style={styles.jobDetailRequestBadgeDot} />
            <Text style={styles.jobDetailRequestBadgeText}>
              {job.status === 'pending_valeter_acceptance' || !job.assignedToValeter ? 'New request' : 'Job'}
            </Text>
          </View>
          <View style={styles.jobDetailRequestHeaderRow}>
            <View style={styles.jobDetailTitleRow}>
              <Text style={styles.jobDetailTitle}>{getServiceDisplayName(job.service_type, job.service_name)}</Text>
              {job.price >= 40 && (
                <View style={styles.jobDetailHighValue}>
                  <LocationStyleIconBox variant="micro" icon="star" preset="amber" />
                  <Text style={styles.jobDetailHighValueText}>High value</Text>
                </View>
              )}
            </View>
            {job.request_sent_at ? (
              <View style={styles.jobDetailTimerPill}>
                <Ionicons name="time" size={12} color="#fff" />
                <Text style={styles.jobDetailTimerPillText}>{formatRelativeTime(job.request_sent_at)}</Text>
              </View>
            ) : null}
          </View>
          <View style={styles.jobDetailCustomerRow}>
            <ValeterJobDetailCustomerAvatar job={job} sky={sky} />
            <Text style={styles.jobDetailCustomer} numberOfLines={1}>
              {job.customer_name || 'Customer'}
            </Text>
          </View>
          <Text style={styles.jobDetailAddress} numberOfLines={2}>
            {job.formatted_location || job.location_address || '—'}
          </Text>
          <View style={styles.jobDetailMeta}>
            <Text style={styles.jobDetailPrice}>£{job.price.toFixed(2)}</Text>
            {job.distance != null && (
              <Text style={styles.jobDetailDistance}>
                {job.distance} mi{jobDetailDriveTimeSuffix(job.drive_time_minutes)}
              </Text>
            )}
          </View>
          <View style={styles.jobDetailActions}>
            <ValeterJobDetailActions job={job} accent={accent} onPrimary={onPrimary} onAccept={onAccept} onDecline={onDecline} />
          </View>
        </View>
      </View>
    </>
  );
}

export default function JobsPage() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();

  const [jobs, setJobs] = useState<JobRequest[]>([]);
  const [jobsLoading, setJobsLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [nearbyCount, setNearbyCount] = useState(0);
  const [selectedJob, setSelectedJob] = useState<JobRequest | null>(null);
  const [valeterCoords, setValeterCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [todayEarnings, setTodayEarnings] = useState<number>(0);
  const [latestIncomingJobId, setLatestIncomingJobId] = useState<string | null>(null);

  const loadNearbyCount = useCallback(async () => {
    if (!user?.id) return;
    try {
      const { data: presence } = await supabase
        .from('valeter_presence')
        .select('last_lat, last_lng')
        .eq('user_id', user.id)
        .maybeSingle();
      if (!presence?.last_lat || !presence?.last_lng) {
        setNearbyCount(0);
        return;
      }
      const { value: radiusMi } = await fetchRadiusPreference(user.id);
      const r = radiusMi ?? 10;
      const { data: bookings } = await supabase
        .from('bookings')
        .select('user_id, location_lat, location_lng')
        .in('status', ['pending_valeter_acceptance', 'pending_payment', 'confirmed', 'scheduled'])
        .not('location_lat', 'is', null)
        .not('location_lng', 'is', null);
      const valeterLat = presence.last_lat;
      const valeterLng = presence.last_lng;
      const inRadius = (bookings || []).filter(
        (b: any) =>
          b.location_lat &&
          b.location_lng &&
          haversineMi(valeterLat, valeterLng, b.location_lat, b.location_lng) <= r
      );
      setNearbyCount(new Set(inRadius.map((b: any) => b.user_id)).size);
    } catch {
      setNearbyCount(0);
    }
  }, [user?.id]);

  const loadTodayEarnings = useCallback(async () => {
    if (!user?.id) return;
    try {
      const todayStart = new Date();
      todayStart.setHours(0, 0, 0, 0);
      const todayEnd = new Date(todayStart);
      todayEnd.setDate(todayEnd.getDate() + 1);
      const { data } = await supabase
        .from('bookings')
        .select('id, status, price, completed_at')
        .eq('valeter_id', user.id)
        .eq('status', 'completed')
        .not('completed_at', 'is', null)
        .gte('completed_at', todayStart.toISOString())
        .lt('completed_at', todayEnd.toISOString());
      const total = (data || []).reduce((sum: number, b: any) => sum + (Number(b.price) || 0), 0);
      setTodayEarnings(Math.round(total * 100) / 100);
    } catch (e) {
      console.warn('[Jobs] today earnings load error', e);
    }
  }, [user?.id]);

  const loadJobs = useCallback(async () => {
    if (!user?.id) return;
    try {
      const query = supabase
        .from('bookings')
        .select(
          'id, service_type, service_name, price, location_address, location_lat, location_lng, scheduled_at, request_sent_at, status, user_id, valeter_id, vehicle_type, vehicle_info'
        )
        .order('request_sent_at', { ascending: false })
        .limit(50)
        .or(
          `and(status.eq.pending_valeter_acceptance,valeter_id.is.null),` +
            `and(status.eq.pending_valeter_acceptance,valeter_id.eq.${user.id}),` +
            `and(status.in.(pending_payment,confirmed,en_route,arrived,in_progress,scheduled),valeter_id.eq.${user.id})`
        );
      const { data, error } = await query;
      if (error) throw error;

      const { commitmentWindows, externalBusy } = await loadValeterScheduleBlocks(user.id);

      const customerIds = [...new Set((data || []).map((j: any) => j.user_id).filter(Boolean))] as string[];
      const profiles = await fetchProfilesByIds(customerIds);
      const vehicleMap = new Map<string, VehicleExtras>();
      if (customerIds.length > 0) {
        const { data: vehicles } = await supabase
          .from('customer_vehicles')
          .select('user_id, registration, make, model, type, photo')
          .in('user_id', customerIds)
          .eq('is_default', true);
        (vehicles || []).forEach((v: any) =>
          vehicleMap.set(v.user_id, {
            registration: v.registration,
            make: v.make,
            model: v.model,
            type: v.type,
            photo: v.photo ?? undefined,
          })
        );
      }

      const { data: presence } = await supabase
        .from('valeter_presence')
        .select('last_lat, last_lng')
        .eq('user_id', user.id)
        .maybeSingle();
      if (presence?.last_lat != null && presence?.last_lng != null) {
        setValeterCoords({ lat: presence.last_lat, lng: presence.last_lng });
      } else {
        setValeterCoords(null);
      }
      const { value: radiusMi } = await fetchRadiusPreference(user.id);
      const r = radiusMi ?? 10;
      const vLat = presence?.last_lat;
      const vLng = presence?.last_lng;

      const mapCtx: MapRawBookingContext = {
        valeterUserId: user.id,
        vehicleMap,
        profiles,
        vLat,
        vLng,
      };
      const mapped: JobRequest[] = (data || [])
        .map((raw) => mapRawBookingToJobRequest(raw as Record<string, unknown>, mapCtx))
        .filter((job) => {
          if (job.assignedToValeter) return true;
          return job.distance == null || job.distance <= r;
        });

      const out = mapped.filter((job) => {
        const isOpenPool =
          job.status === 'pending_valeter_acceptance' && !job.assignedToValeter;
        if (!isOpenPool) return true;
        return !offerOverlapsSchedule(
          job.scheduled_at,
          job.request_sent_at,
          job.service_type,
          job.service_name ?? undefined,
          commitmentWindows,
          externalBusy
        );
      });
      setJobs(out);
    } catch (e) {
      console.error('[Jobs] load error:', e);
      setJobs([]);
    } finally {
      setJobsLoading(false);
    }
  }, [user?.id]);

  useEffect(() => {
    void preparePhoneNotifications();
  }, []);

  useEffect(() => {
    if (!latestIncomingJobId) return;
    const incoming = jobs.find((job) => job.id === latestIncomingJobId);
    if (!incoming) return;
    const serviceName = getServiceDisplayName(incoming.service_type, incoming.service_name);
    Alert.alert('New job request', `${serviceName} • £${Number(incoming.price || 0).toFixed(2)}`);
    void hapticFeedback('medium');
    setLatestIncomingJobId(null);
  }, [latestIncomingJobId, jobs]);

  useEffect(() => {
    if (!user?.id) return;
    void syncValeterBookingsToDeviceCalendar(user.id, jobs);
  }, [jobs, user?.id]);

  useEffect(() => {
    loadJobs();
    loadNearbyCount();
    loadTodayEarnings();
    const ch = supabase
      .channel('jobs-updates')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'bookings' }, (payload) => {
        const booking = (payload.new ?? payload.old) as Record<string, unknown> | null;
        const bookingStatus = typeof booking?.status === 'string' ? booking.status : null;
        const bookingValeterId = typeof booking?.valeter_id === 'string' ? booking.valeter_id : null;
        const bookingId = typeof booking?.id === 'string' ? booking.id : null;

        if (
          bookingStatus === 'pending_valeter_acceptance' &&
          bookingValeterId != null &&
          bookingValeterId === user?.id &&
          bookingId != null &&
          user?.id
        ) {
          void (async () => {
            const ok = await valeterScheduleAllowsJobOffer(user.id, booking as {
              scheduled_at?: string | null;
              request_sent_at?: string | null;
              created_at?: string | null;
              service_type?: string | null;
              service_name?: string | null;
            });
            if (!ok) return;
            void notifyValeterJobRequest({
              bookingId,
              serviceName: typeof booking?.service_name === 'string' ? booking.service_name : null,
              price: typeof booking?.price === 'number' ? booking.price : Number(booking?.price ?? Number.NaN),
              locationAddress: typeof booking?.location_address === 'string' ? booking.location_address : null,
            });
            setLatestIncomingJobId(bookingId);
          })();
        }

        loadJobs();
        loadNearbyCount();
      })
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [loadJobs, loadNearbyCount, loadTodayEarnings, user?.id]);

  const onRefresh = async () => {
    setRefreshing(true);
    await Promise.all([loadJobs(), loadNearbyCount(), loadTodayEarnings()]);
    setRefreshing(false);
  };

  const openDetail = (job: JobRequest) => {
    hapticFeedback('light');
    if (job.assignedToValeter || (job.status && job.status !== 'pending_valeter_acceptance')) {
      router.push({ pathname: '/valeter/jobs/tracking', params: { jobId: job.id } } as any);
    } else {
      router.push({ pathname: '/valeter/jobs/accept', params: { jobId: job.id } });
    }
  };

  const closeDetail = () => setSelectedJob(null);

  const handlePrimaryAction = (job: JobRequest) => {
    closeDetail();
    if (job.assignedToValeter || (job.status && job.status !== 'pending_valeter_acceptance')) {
      router.push({ pathname: '/valeter/jobs/tracking', params: { jobId: job.id } } as any);
    } else {
      router.push({ pathname: '/valeter/jobs/accept', params: { jobId: job.id } });
    }
  };

  const handleAccept = async (job: JobRequest) => {
    if (!user?.id) return;
    hapticFeedback('medium');
    try {
      const gate = await assertNoScheduleConflictForOffer(user.id, {
        scheduled_at: job.scheduled_at,
        request_sent_at: job.request_sent_at,
        service_type: job.service_type,
        service_name: job.service_name,
      });
      if (!gate.ok) {
        Alert.alert('Schedule clash', gate.message);
        return;
      }
      // Only columns guaranteed on `bookings` in PostgREST — omit organization_id / valeter_accepted_at
      // unless those columns exist in your DB + API schema (otherwise PGRST204).
      const payload = {
        valeter_id: user.id,
        status: 'pending_payment' as const,
      };
      const { error } = await supabase.from('bookings').update(payload).eq('id', job.id);
      if (error) throw error;
      closeDetail();
      router.push({ pathname: '/valeter/jobs/tracking', params: { jobId: job.id } } as any);
    } catch (e: any) {
      console.error('[Jobs] accept error:', e);
      let msg = 'Could not accept this job. Check your connection or try again.';
      if (typeof e?.message === 'string') msg = e.message;
      else if (typeof e?.details === 'string') msg = e.details;
      Alert.alert('Could not accept job', msg);
    }
  };

  const handleDecline = (_job: JobRequest) => {
    hapticFeedback('light');
    closeDetail();
    loadJobs();
  };

  const accent = theme.primary ?? SKY;

  const selectedJobMapRegion = useMemo((): Region | null => {
    if (!selectedJob?.location_lat || !selectedJob?.location_lng) return null;
    const jLat = selectedJob.location_lat;
    const jLng = selectedJob.location_lng;
    if (valeterCoords) {
      const minLat = Math.min(jLat, valeterCoords.lat);
      const maxLat = Math.max(jLat, valeterCoords.lat);
      const minLng = Math.min(jLng, valeterCoords.lng);
      const maxLng = Math.max(jLng, valeterCoords.lng);
      const latDelta = Math.max((maxLat - minLat) * 2, 0.012);
      const lngDelta = Math.max((maxLng - minLng) * 2, 0.012);
      return {
        latitude: (minLat + maxLat) / 2,
        longitude: (minLng + maxLng) / 2,
        latitudeDelta: latDelta,
        longitudeDelta: lngDelta,
      };
    }
    return { latitude: jLat, longitude: jLng, latitudeDelta: 0.02, longitudeDelta: 0.02 };
  }, [selectedJob?.location_lat, selectedJob?.location_lng, valeterCoords]);

  const renderRow = ({ item: job }: { item: JobRequest }) => {
    const isAssigned = job.assignedToValeter;
    const isPending = job.status === 'pending_valeter_acceptance';
    const isLocked = job.status === 'pending_payment';
    const color = getTierColor(job.service_type, job.service_name);
    const icon = getTierIcon(job.service_type, job.service_name);

    return (
      <View style={styles.card}>
        <TouchableOpacity
          activeOpacity={0.88}
          onPress={() => openDetail(job)}
          style={styles.cardTouch}
        >
          {/* Top: vehicle photo or service hero */}
          <View style={styles.cardTop}>
            {job.vehicle_photo ? (
              <Image source={{ uri: job.vehicle_photo }} style={styles.cardHeroImage} resizeMode="cover" />
            ) : (
              <View style={[styles.cardHeroPlaceholder, { backgroundColor: `${color}18` }]}>
                <LocationStyleIconBox variant="hero" icon={icon} colors={accentToGradient(color)} />
              </View>
            )}
            <View style={[styles.cardTierBadge, { backgroundColor: color }]}>
              <Text style={styles.cardTierBadgeText} numberOfLines={1}>{getServiceDisplayName(job.service_type, job.service_name)}</Text>
            </View>
            {job.price >= 40 && (
              <View style={styles.highValueBadge}>
                <Ionicons name="star" size={12} color="#FBBF24" />
                <Text style={styles.highValueBadgeText}>High value</Text>
              </View>
            )}
          </View>
          {/* Body: customer + location + meta */}
          <View style={styles.cardBody}>
            <View style={styles.cardCustomerRow}>
              {job.customer_photo ? (
                <Image source={{ uri: job.customer_photo }} style={styles.cardAvatar} />
              ) : (
                <View style={styles.cardAvatarPlaceholder}>
                  <LocationStyleIconBox variant="inline" icon="person" preset="sky" />
                </View>
              )}
              <Text style={styles.cardCustomerName} numberOfLines={1}>{job.customer_name || 'Customer'}</Text>
            </View>
            <Text style={styles.cardAddress} numberOfLines={2}>
              {job.formatted_location || job.location_address || '—'}
            </Text>
            <View style={styles.cardMetaRow}>
              <Text style={styles.cardMetaText}>{formatRelativeTime(job.request_sent_at)}</Text>
              {job.distance != null && <Text style={styles.cardMetaText}> · {job.distance} mi</Text>}
              {job.drive_time_minutes != null && <Text style={styles.cardMetaText}> · {job.drive_time_minutes} min</Text>}
            </View>
            {(job.vehicle_registration || job.vehicle_make) && (
              <Text style={styles.cardVehicle} numberOfLines={1}>
                {[job.vehicle_registration, job.vehicle_make, job.vehicle_model].filter(Boolean).join(' ')}
              </Text>
            )}
          </View>
          {/* Footer: price + action */}
          <View style={styles.cardFooter}>
            <View style={styles.cardPriceRow}>
              <Text style={styles.cardPrice}>£{job.price.toFixed(2)}</Text>
              {job.price >= 40 && (
                <View style={styles.highValueChip}>
                  <Text style={styles.highValueChipText}>High value</Text>
                </View>
              )}
            </View>
            <View style={styles.cardFooterRight}>
              {isPending && !isAssigned && (
                <View style={styles.acceptDeclineRow}>
                  <TouchableOpacity onPress={(e) => { e.stopPropagation(); handleDecline(job); }} style={styles.declineChip} activeOpacity={0.9}>
                    <LocationStyleIconBox variant="micro" icon="close-circle-outline" preset="red" />
                    <Text style={styles.declineChipText}>Decline</Text>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={(e) => { e.stopPropagation(); handleAccept(job); }} style={styles.acceptChip} activeOpacity={0.9}>
                    <Ionicons name="checkmark-circle" size={14} color="#fff" />
                    <Text style={styles.acceptChipText}>Accept</Text>
                  </TouchableOpacity>
                </View>
              )}
              {isLocked && (
                <View style={styles.lockedChip}>
                  <Ionicons name="wallet-outline" size={12} color="#F59E0B" />
                  <Text style={styles.lockedChipText}>Awaiting payment</Text>
                </View>
              )}
              {isAssigned && !isLocked && (
                <View style={styles.trackChip}>
                  <Text style={styles.trackChipText}>Track</Text>
                </View>
              )}
              {(!isPending || isAssigned) && (
                <Ionicons name="chevron-forward" size={18} color="rgba(255,255,255,0.5)" />
              )}
            </View>
          </View>
        </TouchableOpacity>
      </View>
    );
  };

  const listHeader = (
    <View style={styles.headerRow}>
      {jobs.length > 0 && (
        <View style={styles.pill}>
          <View style={styles.pillDot} />
          <Text style={styles.pillText}>{nearbyCount} nearby</Text>
        </View>
      )}
    </View>
  );

  const empty = (
    <View style={styles.empty}>
      <GradientIconBox icon="map-outline" preset="sky" boxSize={80} size={44} />
      <Text style={styles.emptyTitle}>No jobs nearby right now</Text>
      <Text style={styles.emptySub}>
        Stay online and you'll receive wash requests from customers in your area.
      </Text>
      <View style={[styles.emptyTip, { borderColor: `${accent}40`, backgroundColor: `${accent}12` }]}>
        <LocationStyleIconBox variant="inline" icon="bulb-outline" colors={accentToGradient(accent)} />
        <Text style={[styles.emptyTipText, { color: accent }]}>
          Tip: Most bookings happen between 5pm–8pm and on weekends.
        </Text>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={valeterPageBackground(theme)} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />
      <AppHeader
        title="Jobs"
        accountType="valeter"
        rightAction={
          <TouchableOpacity onPress={onRefresh} style={styles.refreshBtn}>
            <Ionicons name="refresh" size={20} color={accent} />
          </TouchableOpacity>
        }
      />
      {/* Jobs page: list with map icon (like business locations) */}
      <View style={[styles.pageContent, { paddingTop: HEADER_CONTENT_OFFSET }]}>
        <View style={[styles.jobsPageHeader, { borderColor: `${accent}25` }]}>
          <View style={styles.jobsPageTitleRow}>
            <LocationStyleIconBox variant="card" icon="navigate" colors={accentToGradient(accent)} />
            <Text style={styles.jobsPageTitle}>Jobs</Text>
          </View>
          <View style={[styles.todayPill, { backgroundColor: `${accent}18`, borderColor: `${accent}40` }]}>
            <Text style={styles.todayLabel}>Today</Text>
            <Text style={[styles.todayValue, { color: accent }]}>£{todayEarnings.toFixed(2)}</Text>
          </View>
        </View>
        {jobsLoading && jobs.length === 0 ? (
          <View style={styles.loadingWrap}>
            <DefaultLoadingSkeleton message="Loading jobs…" variant="rich" />
          </View>
        ) : (
          <FlatList
            data={jobs}
            keyExtractor={(item) => item.id}
            renderItem={renderRow}
            ListHeaderComponent={jobs.length > 0 ? listHeader : null}
            ListEmptyComponent={empty}
            contentContainerStyle={[
              styles.listContent,
              {
                paddingBottom: (insets?.bottom ?? 0) + 24,
                flexGrow: jobs.length === 0 ? 1 : undefined,
              },
            ]}
            refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />}
            showsVerticalScrollIndicator={false}
            style={styles.listContainer}
          />
        )}
      </View>

      {/* Job detail modal (with small map using location icon for valeter) */}
      <Modal visible={!!selectedJob} animationType="slide" presentationStyle="pageSheet" onRequestClose={closeDetail}>
        <SafeAreaView style={styles.modalContainer} edges={['top']}>
          <LinearGradient colors={valeterModalHeaderGradient(theme)} style={StyleSheet.absoluteFill} />
          {selectedJob ? (
            <ValeterJobDetailSheet
              job={selectedJob}
              accent={accent}
              sky={SKY}
              insetsBottom={insets?.bottom ?? 0}
              mapRegion={selectedJobMapRegion}
              valeterCoords={valeterCoords}
              onClose={closeDetail}
              onPrimary={handlePrimaryAction}
              onAccept={handleAccept}
              onDecline={handleDecline}
            />
          ) : null}
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  pageContent: { flex: 1, paddingHorizontal: SCREEN_PADDING_H },
  jobsPageHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    paddingHorizontal: 4,
    borderBottomWidth: 1,
    marginBottom: 4,
  },
  jobsPageTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  jobsPageTitle: { color: '#F9FAFB', fontSize: 20, fontWeight: '800' },
  modalContainer: { flex: 1 },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: SCREEN_PADDING_H,
    paddingTop: 8,
    paddingBottom: 12,
  },
  jobsSheetPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    borderWidth: 1,
  },
  jobsSheetPillText: {
    fontSize: 12,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 0.8,
  },
  jobDetailHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
    paddingHorizontal: 4,
  },
  jobDetailCloseBtn: { padding: 4 },
  jobDetailCard: {
    flex: 1,
    marginHorizontal: SCREEN_PADDING_H,
    marginBottom: 16,
    borderRadius: 22,
    overflow: 'hidden',
    position: 'relative',
  },
  jobDetailCardMap: {
    ...StyleSheet.absoluteFillObject,
  },
  jobDetailMapMarkerYou: {
    width: 26,
    height: 26,
    borderRadius: 13,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2.5,
    borderColor: '#fff',
  },
  jobDetailMapMarkerJob: {
    width: 24,
    height: 24,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  jobDetailMapMarkerJobImage: { width: 20, height: 20 },
  jobDetailCardContent: {
    padding: 18,
    zIndex: 2,
  },
  jobDetailRequestBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    gap: 6,
    marginBottom: 10,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 10,
    backgroundColor: 'rgba(239,68,68,0.2)',
  },
  jobDetailRequestBadgeDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#EF4444' },
  jobDetailRequestBadgeText: { color: '#FCA5A5', fontSize: 12, fontWeight: '700' },
  jobDetailRequestHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    gap: 10,
    marginBottom: 8,
  },
  jobDetailTimerPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    backgroundColor: 'rgba(239,68,68,0.8)',
  },
  jobDetailTimerPillText: { color: '#fff', fontSize: 12, fontWeight: '700' },
  jobDetailTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap', flex: 1, minWidth: 0 },
  jobDetailTitle: { color: '#F9FAFB', fontSize: 17, fontWeight: '700', flex: 1 },
  jobDetailHighValue: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 6, paddingVertical: 3, borderRadius: 8, backgroundColor: 'rgba(251,191,36,0.25)', borderWidth: 1, borderColor: 'rgba(251,191,36,0.5)' },
  jobDetailHighValueText: { color: '#FBBF24', fontSize: 11, fontWeight: '700' },
  jobDetailCustomerRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 8 },
  jobDetailCustomerAvatar: { width: 40, height: 40, borderRadius: 20 },
  jobDetailCustomerAvatarPlaceholder: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  jobDetailCustomer: { color: 'rgba(249,250,251,0.9)', fontSize: 15, fontWeight: '700', flex: 1 },
  jobDetailAddress: { color: 'rgba(249,250,251,0.75)', fontSize: 13, marginBottom: 10, lineHeight: 18 },
  jobDetailMeta: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 14 },
  jobDetailPrice: { color: '#FCD34D', fontSize: 18, fontWeight: '800' },
  jobDetailDistance: { color: 'rgba(249,250,251,0.7)', fontSize: 13, fontWeight: '600' },
  jobDetailActions: { flexDirection: 'row', gap: 10 },
  jobDetailBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 14, borderRadius: 12 },
  jobDetailBtnText: { color: '#fff', fontSize: 15, fontWeight: '700' },
  jobDetailBtnDisabled: { backgroundColor: 'rgba(245,158,11,0.3)' },
  jobDetailBtnTextLocked: { color: '#F59E0B', fontSize: 14, fontWeight: '700' },
  awaitingPaymentBlock: { gap: 8 },
  awaitingPaymentSub: { color: 'rgba(249,250,251,0.65)', fontSize: 13, textAlign: 'center', marginTop: 4 },
  jobDetailDeclineBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 14, borderRadius: 12, backgroundColor: 'rgba(239,68,68,0.25)', borderWidth: 1, borderColor: 'rgba(239,68,68,0.5)' },
  jobDetailDeclineBtnText: { color: '#EF4444', fontSize: 14, fontWeight: '700' },
  jobDetailAcceptBtn: {},
  listContainer: { flex: 1 },
  refreshBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingWrap: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12 },
  loadingText: { color: SKY, fontSize: 15 },
  listContent: { paddingHorizontal: SCREEN_PADDING_H, gap: CARD_GAP },
  headerRow: { marginBottom: 16 },
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(255,255,255,0.08)',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
  },
  pillDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#10B981' },
  pillText: { color: '#F9FAFB', fontSize: 13, fontWeight: '600' },
  card: {
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
    overflow: 'hidden',
  },
  cardTouch: {},
  cardTop: {
    height: 100,
    position: 'relative',
    backgroundColor: 'rgba(0,0,0,0.2)',
  },
  cardHeroImage: {
    width: '100%',
    height: '100%',
  },
  cardHeroPlaceholder: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  cardTierBadge: {
    position: 'absolute',
    bottom: 8,
    left: 12,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 10,
    maxWidth: '80%',
  },
  cardTierBadgeText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '700',
  },
  cardBody: {
    paddingHorizontal: 14,
    paddingTop: 12,
    paddingBottom: 10,
  },
  cardCustomerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 8,
  },
  cardAvatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
  },
  cardAvatarPlaceholder: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(135,206,235,0.25)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  cardCustomerName: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
    flex: 1,
  },
  cardAddress: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
    marginBottom: 4,
  },
  cardMetaRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 2,
  },
  cardMetaText: {
    color: 'rgba(249,250,251,0.55)',
    fontSize: 12,
  },
  cardVehicle: {
    color: 'rgba(249,250,251,0.5)',
    fontSize: 11,
    marginTop: 2,
  },
  cardFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.06)',
  },
  cardPriceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  cardFooterRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  cardPrice: { color: SKY, fontSize: 18, fontWeight: '800' },
  highValueBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
    backgroundColor: 'rgba(251,191,36,0.9)',
  },
  highValueBadgeText: { color: '#0A1929', fontSize: 11, fontWeight: '700' },
  highValueChip: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    backgroundColor: 'rgba(251,191,36,0.25)',
    borderWidth: 1,
    borderColor: 'rgba(251,191,36,0.5)',
  },
  highValueChipText: { color: '#FBBF24', fontSize: 11, fontWeight: '700' },
  lockedChip: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8, backgroundColor: 'rgba(245,158,11,0.15)', borderWidth: 1, borderColor: 'rgba(245,158,11,0.4)' },
  lockedChipText: { color: '#F59E0B', fontSize: 11, fontWeight: '700' },
  acceptDeclineRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  declineChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
    backgroundColor: 'rgba(239,68,68,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.4)',
  },
  declineChipText: { color: '#EF4444', fontSize: 13, fontWeight: '700' },
  acceptChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
    backgroundColor: '#10B981',
  },
  acceptChipText: { color: '#fff', fontSize: 13, fontWeight: '700' },
  trackChip: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    backgroundColor: 'rgba(135,206,235,0.2)',
  },
  trackChipText: { color: SKY, fontSize: 11, fontWeight: '600' },
  empty: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',
    paddingTop: 24,
    paddingBottom: 48,
    paddingHorizontal: 32,
    minHeight: 320,
  },
  emptyTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '700', marginTop: 16, marginBottom: 8 },
  emptySub: { color: 'rgba(249,250,251,0.65)', fontSize: 14, textAlign: 'center', lineHeight: 20 },
  emptyTip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 20,
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 12,
    borderWidth: 1,
  },
  emptyTipText: { fontSize: 13, fontWeight: '600', flex: 1 },
  todayPill: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 12,
    borderWidth: 1,
  },
  todayLabel: { fontSize: 10, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.5, color: 'rgba(249,250,251,0.7)', marginBottom: 2 },
  todayValue: { fontSize: 16, fontWeight: '800' },
  sheetFooter: { gap: 10 },
  sheetAcceptDeclineRow: {
    flexDirection: 'row',
    gap: 12,
  },
  sheetDeclineBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    borderRadius: 14,
    backgroundColor: 'rgba(239,68,68,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.4)',
  },
  sheetDeclineBtnText: { color: '#EF4444', fontSize: 16, fontWeight: '700' },
  sheetBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingVertical: 14,
    borderRadius: 14,
    backgroundColor: SKY,
  },
  sheetBtnAccept: { backgroundColor: '#10B981' },
  sheetBtnDisabled: {
    backgroundColor: 'rgba(245,158,11,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(245,158,11,0.4)',
  },
  sheetBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  sheetBtnTextLocked: { color: '#F59E0B', fontSize: 16, fontWeight: '700' },
  carImageWrap: {
    width: '100%',
    aspectRatio: 16 / 9,
    borderRadius: 14,
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.06)',
    marginBottom: 16,
  },
  carImage: {
    width: '100%',
    height: '100%',
  },
  sheetCustomerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    marginBottom: 20,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.08)',
  },
  sheetAvatar: {
    width: 56,
    height: 56,
    borderRadius: 28,
  },
  sheetAvatarPlaceholder: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: 'rgba(135,206,235,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  sheetCustomerInfo: { flex: 1 },
  sheetCustomerName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 4,
  },
  sheetCustomerMeta: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
  },
});
