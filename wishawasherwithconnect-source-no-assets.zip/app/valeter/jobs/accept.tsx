import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  StatusBar,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import MapView, { Marker, Region } from 'react-native-maps';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import GlassCard from '../../../src/components/booking/GlassCard';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { assertNoScheduleConflictForOffer } from '../../../src/services/valeterScheduleConflict';
import { CustomerProfileRow, fetchProfileById } from '../../../src/utils/customerProfiles';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { colors } from '../../../src/constants/colors';

const SKY = colors.SKY;
const BG = colors.BG;
const VALETER_BG_FALLBACK: [string, string] = ['#0A1929', '#2563EB'];

type AcceptBookingRow = Record<string, unknown> & {
  id?: string;
  user_id?: string | null;
  service_type?: string;
  service_name?: string;
  price?: number;
  location_address?: string;
  location_lat?: number | null;
  location_lng?: number | null;
  scheduled_at?: string;
  request_sent_at?: string;
};

function twoStopGradient(bg: readonly string[] | undefined, fallback: [string, string]): [string, string] {
  if (Array.isArray(bg) && bg.length >= 2) {
    return [String(bg[0]), String(bg[1])];
  }
  return fallback;
}

function routeParamString(value: string | string[] | undefined): string {
  if (typeof value === 'string') {
    return value;
  }
  if (Array.isArray(value) && value.length > 0 && typeof value[0] === 'string') {
    return value[0];
  }
  return '';
}

export default function JobAccept() {
  const { user } = useAuth();
  const { theme } = useAccountTheme();
  const gradientBg = twoStopGradient(theme?.background, VALETER_BG_FALLBACK);
  const params = useLocalSearchParams();
  const jobId = routeParamString(params.jobId);

  const [job, setJob] = useState<AcceptBookingRow | null>(null);
  const [customerProfile, setCustomerProfile] = useState<CustomerProfileRow | null>(null);
  const [loading, setLoading] = useState(true);
  const [accepting, setAccepting] = useState(false);
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const cardAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(cardAnim, {
        toValue: 1,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();

    loadJob();
  }, [jobId]);

  const loadJob = async () => {
    if (!jobId) {
      setLoading(false);
      return;
    }
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('id', jobId)
        .single();

      if (error) throw error;
      setJob(data as AcceptBookingRow);
      if (data?.user_id) {
        const profile = await fetchProfileById(data.user_id);
        setCustomerProfile(profile);
      } else {
        setCustomerProfile(null);
      }

      if (data.location_lat && data.location_lng) {
        setRegion({
          latitude: data.location_lat,
          longitude: data.location_lng,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        });
      }
    } catch (error) {
      console.error('Error loading job:', error);
      Alert.alert('Error', 'Failed to load job details');
    } finally {
      setLoading(false);
    }
  };

  const handleAccept = async () => {
    if (!user?.id || !job) return;
    if (accepting) return;

    setAccepting(true);
    await hapticFeedback('medium');

    try {
      const gate = await assertNoScheduleConflictForOffer(user.id, {
        scheduled_at: typeof job.scheduled_at === 'string' ? job.scheduled_at : null,
        request_sent_at: typeof job.request_sent_at === 'string' ? job.request_sent_at : null,
        service_type: typeof job.service_type === 'string' ? job.service_type : null,
        service_name: typeof job.service_name === 'string' ? job.service_name : null,
      });
      if (!gate.ok) {
        Alert.alert('Schedule clash', gate.message);
        setAccepting(false);
        return;
      }

      const updatePayload = {
        valeter_id: user.id,
        status: 'pending_payment' as const,
      };

      const { error: updateError } = await supabase
        .from('bookings')
        .update(updatePayload)
        .eq('id', jobId);

      if (updateError) throw updateError;

      router.replace({ pathname: '/valeter/jobs/tracking', params: { jobId } });
    } catch (error: any) {
      Alert.alert('Error', error?.message || 'Failed to accept job');
      setAccepting(false);
    }
  };

  const handleDecline = async () => {
    await hapticFeedback('light');
    router.back();
  };

  if (loading || !job) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="valeter" />
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Loading job details...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <StatusBar barStyle="light-content" backgroundColor={BG} />
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <AppHeader title="Job Details" />

      <Animated.View
        style={[
          styles.content,
          {
            paddingTop: HEADER_CONTENT_OFFSET,
            opacity: fadeAnim,
          },
        ]}
      >
        {/* Map */}
        <View style={styles.mapContainer}>
          <MapView style={styles.map} region={region}>
            {job.location_lat && job.location_lng && (
              <Marker
                coordinate={{
                  latitude: job.location_lat,
                  longitude: job.location_lng,
                }}
              >
                <View style={styles.marker}>
                  <Ionicons name="flag" size={24} color="#EF4444" />
                </View>
              </Marker>
            )}
          </MapView>
        </View>

        {/* Job Details Card */}
        <Animated.View
          style={[
            styles.cardContainer,
            {
              transform: [{ scale: cardAnim }],
            },
          ]}
        >
          <GlassCard style={styles.detailsCard}>
            <View style={styles.detailsHeader}>
              <Ionicons name="water" size={32} color={SKY} />
              <View style={styles.detailsTitleContainer}>
                <Text style={styles.detailsTitle}>
                  {getServiceDisplayName(job.service_type, job.service_name)}
                </Text>
                <Text style={styles.detailsPrice}>£{job.price?.toFixed(2) || '0.00'}</Text>
              </View>
            </View>

            <View style={styles.detailsContent}>
              <View style={styles.detailRow}>
                <Ionicons name="location" size={20} color={SKY} />
                <Text style={styles.detailText}>{job.location_address}</Text>
              </View>
              {job.user_id && (
                <View style={styles.detailRow}>
                  <Ionicons name="person" size={20} color={SKY} />
                  <Text style={styles.detailText}>
                    {customerProfile?.full_name || 'Customer'}
                  </Text>
                </View>
              )}
              {job.scheduled_at && (
                <View style={styles.detailRow}>
                  <Ionicons name="time" size={20} color={SKY} />
                  <Text style={styles.detailText}>
                    {new Date(job.scheduled_at).toLocaleString()}
                  </Text>
                </View>
              )}
            </View>
          </GlassCard>

          {/* Action Buttons */}
          <View style={styles.actionsContainer}>
            <TouchableOpacity
              onPress={handleAccept}
              style={styles.acceptButton}
              activeOpacity={0.8}
              disabled={accepting}
            >
              <LinearGradient
                colors={['#10B981', '#059669']}
                style={styles.acceptGradient}
              >
                {accepting ? (
                  <Text style={styles.buttonText}>Accepting...</Text>
                ) : (
                  <>
                    <Ionicons name="checkmark-circle" size={20} color="#FFFFFF" />
                    <Text style={styles.buttonText}>Accept Job</Text>
                  </>
                )}
              </LinearGradient>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={handleDecline}
              style={styles.declineButton}
              activeOpacity={0.8}
            >
              <Text style={styles.declineText}>Decline</Text>
            </TouchableOpacity>
          </View>
        </Animated.View>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#0A1929',
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(135,206,235,0.15)',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    flex: 1,
    textAlign: 'center',
  },
  headerSpacer: {
    width: 40,
  },
  content: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: SKY,
    fontSize: 16,
  },
  mapContainer: {
    flex: 1,
  },
  map: {
    flex: 1,
  },
  marker: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  cardContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: 20,
    paddingBottom: 40,
  },
  detailsCard: {
    padding: 20,
    marginBottom: 20,
  },
  detailsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 20,
  },
  detailsTitleContainer: {
    flex: 1,
  },
  detailsTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  detailsPrice: {
    color: SKY,
    fontSize: 24,
    fontWeight: 'bold',
  },
  detailsContent: {
    gap: 12,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  detailText: {
    color: '#E5E7EB',
    fontSize: 14,
    flex: 1,
  },
  actionsContainer: {
    gap: 12,
  },
  acceptButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  acceptGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    paddingHorizontal: 32,
    gap: 8,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  declineButton: {
    paddingVertical: 18,
    alignItems: 'center',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.5)',
  },
  declineText: {
    color: '#EF4444',
    fontSize: 16,
    fontWeight: '600',
  },
});

