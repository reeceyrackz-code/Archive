/**
 * Valeter chat with customer – WhatsApp-like UI (shared ChatThreadView).
 */
import React, { useState, useEffect } from 'react';
import { View, ActivityIndicator, Alert } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { colors } from '../../../src/constants/colors';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import ChatThreadView from '../../../src/components/chat/ChatThreadView';
import LoadingScreen from '../../../src/components/LoadingScreen';

const SKY = colors.SKY;

async function getCustomerName(userId: string): Promise<string> {
  try {
    const { data } = await supabase.from('profiles').select('full_name, name').eq('id', userId).maybeSingle();
    const p = data as any;
    return (p?.full_name || p?.name || 'Customer') as string;
  } catch {
    return 'Customer';
  }
}

export default function ValeterJobChatScreen() {
  const params = useLocalSearchParams<{ bookingId: string }>();
  const bookingId = params.bookingId;
  const { user } = useAuth();
  const [customerName, setCustomerName] = useState<string>('Customer');
  const [serviceName, setServiceName] = useState<string>('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!bookingId) {
      setLoading(false);
      return;
    }
    (async () => {
      try {
        const { data, error } = await supabase
          .from('bookings')
          .select('user_id, service_type, service_name, location_address')
          .eq('id', bookingId)
          .eq('valeter_id', user?.id)
          .maybeSingle();
        if (error || !data) {
          setLoading(false);
          return;
        }
        const r = data as any;
        setServiceName(getServiceDisplayName(r.service_type, r.service_name));
        setCustomerName(await getCustomerName(r.user_id));
      } catch {
        setCustomerName('Customer');
      } finally {
        setLoading(false);
      }
    })();
  }, [bookingId, user?.id]);

  const handleBack = () => {
    hapticFeedback('light');
    router.back();
  };

  const handleCall = () => {
    hapticFeedback('light');
    Alert.alert('Call', 'Call customer – will open phone dialler when connected.');
  };

  const handleAttachImage = () => {
    hapticFeedback('light');
    Alert.alert('Photo', 'Send picture – photo picker will be connected when backend is ready.');
  };

  const handleVoiceNote = () => {
    hapticFeedback('light');
    Alert.alert('Voice note', 'Hold to record – voice messages will be sent when backend is ready.');
  };

  const handleDeleteChat = () => {
    hapticFeedback('light');
    Alert.alert(
      'Delete chat',
      'Remove this conversation from your list?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            if (bookingId) {
              const { addDeletedChatBookingId } = await import('../../../src/services/DeletedChatsService');
              await addDeletedChatBookingId(bookingId);
            }
            router.back();
          },
        },
      ]
    );
  };

  if (loading) {
    return <LoadingScreen message="Loading…" />;
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#0F172A' }} edges={[]}>
      <ChatThreadView
        title={customerName}
        subtitle={serviceName}
        onBack={handleBack}
        onCall={handleCall}
        onAttachImage={handleAttachImage}
        onVoiceNote={handleVoiceNote}
        onDelete={handleDeleteChat}
        accentColor={SKY}
      />
    </SafeAreaView>
  );
}
