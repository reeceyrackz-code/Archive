import React from 'react';
import DevWorkAuditScreen from '../../src/components/dev/DevWorkAuditScreen';
import {
  VALETER_DEV_WORK_INTRO,
  VALETER_DEV_WORK_SECTIONS,
} from '../../src/constants/devWorkChecklists';

export default function ValeterDevWorkScreen() {
  return (
    <DevWorkAuditScreen
      accountType="valeter"
      title="Dev work"
      intro={VALETER_DEV_WORK_INTRO}
      sections={VALETER_DEV_WORK_SECTIONS}
      footerNote="Organisation join flows (backend/product): see docs/BUSINESS_VALETER_PAGE_FOR_DEAN.md. The valeter Business affiliations screen was removed from the app."
    />
  );
}
