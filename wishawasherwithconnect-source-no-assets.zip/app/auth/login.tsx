import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert,
  Animated,
  Platform,
  ScrollView,
  StatusBar,
  KeyboardAvoidingView,
  Modal,
  Pressable,
  Linking,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Video, ResizeMode, AVPlaybackStatus } from 'expo-av';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { router } from 'expo-router';
import { ChromeGlyph as Ionicons } from '../../src/components/shared/ChromeGlyph';
import * as AppleAuthentication from 'expo-apple-authentication';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { supabase } from '../../src/lib/supabase';
import {
  isBiometricAvailable,
  getBiometricType,
  authenticateWithBiometrics,
  saveBiometricCredentials,
  getBiometricCredentials,
  clearBiometricCredentials,
  isBiometricEnabled,
} from '../../src/services/BiometricService';
import { colors } from '../../src/constants/colors';
import WWPrimaryButton from '../../src/components/ui/WWPrimaryButton';
import ContinueCTAButton from '../../src/components/ui/ContinueCTAButton';
import AuthBrandMark from '../../src/components/auth/AuthBrandMark';
import { AUTH_PAGES_VIDEO } from '../assets/authExports';
import {
  sharedAuthStyleDefs,
  AUTH_GRADIENT_COLORS,
  AUTH_CONTENT_OVERLAY_COLORS,
} from '../../src/constants/authStyles';

const TERMS_URL = 'https://wishawash.com/terms';
const PRIVACY_URL = 'https://wishawash.com/privacy';

export default function LoginScreen() {
  const { login, logout, loginWithApple } = useAuth();

  const [userType, setUserType] = useState<'valeter' | 'business'>('valeter');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isAppleAvailable, setIsAppleAvailable] = useState(false);
  const [emailModalVisible, setEmailModalVisible] = useState(false);
  const [isBiometricAvailableState, setIsBiometricAvailableState] = useState(false);
  const [biometricType, setBiometricType] = useState<string>('Biometric');
  const [hasBiometricCredentials, setHasBiometricCredentials] = useState(false);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const videoOpacity = useRef(new Animated.Value(0)).current;
  const buttonScale = useRef(new Animated.Value(1)).current;
  const videoRef = useRef<Video>(null);

  useEffect(() => {
    if (userType === 'valeter') {
      setEmail('lingardodeano@gmail.com');
      setPassword('@@@Urztfc58812');
    } else {
      setEmail('deanlingard@decanusltd.com');
      setPassword('password');
    }
  }, [userType]);

  useEffect(() => {
    (async () => {
      try {
        const available =
          Platform.OS === 'ios' && (await AppleAuthentication.isAvailableAsync());
        setIsAppleAvailable(Boolean(available));
      } catch {
        setIsAppleAvailable(false);
      }
    })();
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const available = await isBiometricAvailable();
        setIsBiometricAvailableState(available);
        if (available) {
          const type = await getBiometricType();
          setBiometricType(type);
          const enabled = await isBiometricEnabled();
          const credentials = await getBiometricCredentials();
          setHasBiometricCredentials(enabled && credentials !== null);
        }
      } catch {
        setIsBiometricAvailableState(false);
      }
    })();
  }, []);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 800, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0, duration: 800, useNativeDriver: true }),
    ]).start();
  }, []);

  const handlePlaybackStatusUpdate = (status: AVPlaybackStatus) => {
    if (!status.isLoaded || !videoRef.current) return;
    if (status.didJustFinish) {
      videoRef.current.setPositionAsync(0).then(() => videoRef.current?.playAsync()).catch(() => {});
      return;
    }
    if (status.durationMillis != null && status.positionMillis != null) {
      const remaining = status.durationMillis - status.positionMillis;
      if (remaining < 500 && remaining > 0) {
        videoRef.current.setPositionAsync(0).then(() => videoRef.current?.playAsync()).catch(() => {});
      }
    }
  };

  const handleVideoLoad = () => {
    Animated.timing(videoOpacity, {
      toValue: 1,
      duration: 700,
      useNativeDriver: true,
    }).start();
  };

  const finishRouting = () => {
    if (userType === 'valeter') {
      router.replace('/valeter/valeter-dashboard');
    } else {
      router.replace('/business/dashboard' as any);
    }
  };

  const getEffectiveRole = async (): Promise<string> => {
    const { data: authData, error: authErr } = await supabase.auth.getUser();
    if (authErr) throw authErr;
    const sbUser = authData?.user;
    if (!sbUser?.id) return '';
    const { data: profile, error: profErr } = await supabase
      .from('profiles')
      .select('user_type')
      .eq('id', sbUser.id)
      .maybeSingle();
    if (profErr) throw profErr;
    const role = (profile?.user_type ?? (sbUser.user_metadata as any)?.userType ?? '') as string;
    return role.toLowerCase();
  };

  const isOrgRole = (role: string) =>
    role === 'organization' || role === 'organisation' || role === 'organistion';
  const isValeterRole = (role: string) =>
    role === 'valeter' || role === 'valeter_account' || role === 'valetor';

  const safeLogout = async () => {
    try {
      if (typeof logout === 'function') await logout();
      else await supabase.auth.signOut();
    } catch {}
  };

  const handlePressIn = () => {
    Animated.spring(buttonScale, { toValue: 0.98, useNativeDriver: true, speed: 50 }).start();
  };
  const handlePressOut = () => {
    Animated.spring(buttonScale, { toValue: 1, useNativeDriver: true, speed: 50 }).start();
  };

  const handleLogin = async (saveForBiometric: boolean = false) => {
    if (!email.trim() || !password.trim()) {
      Alert.alert('Error', 'Please enter both email and password');
      return;
    }
    await hapticFeedback('medium');
    setIsLoading(true);
    try {
      const adminTriggerEmails = [
        'Reeceyrackz@gmail.com',
        'founder@wishawash.com',
        'admin@wishawash.com',
        'ceo@wishawash.com',
        'director@wishawash.com',
      ];
      const adminTriggerPasswords = ['WishWash2026!', 'Admin2026!', 'Founder2026!', 'CEO2026!'];
      if (
        adminTriggerEmails.includes(email.toLowerCase()) &&
        adminTriggerPasswords.includes(password)
      ) {
        router.push('/super-admin-auth' as any);
        setIsLoading(false);
        return;
      }

      const ok = await login(email.trim(), password);
      if (!ok) {
        Alert.alert('Login Failed', 'Invalid email or password.');
        return;
      }

      const role = await getEffectiveRole();
      if (userType === 'business' && !isOrgRole(role)) {
        await safeLogout();
        Alert.alert(
          'Not a business account',
          "That login isn't registered as a business account. Switch to Car Care Pro."
        );
        return;
      }
      if (userType !== 'business' && !isValeterRole(role)) {
        await safeLogout();
        Alert.alert(
          'Not a Car Care Pro account',
          "That login isn't registered as a Car Care Pro account. Switch to Business."
        );
        return;
      }

      if (saveForBiometric && isBiometricAvailableState) {
        try {
          await saveBiometricCredentials({ email: email.trim(), password, userType });
          setHasBiometricCredentials(true);
        } catch {}
      }
      setEmailModalVisible(false);
      finishRouting();
    } catch (e: any) {
      Alert.alert('Login Failed', e?.message || 'Something went wrong. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAppleLogin = async () => {
    try {
      await hapticFeedback('light');
      const credential = await AppleAuthentication.signInAsync({
        requestedScopes: [
          AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
          AppleAuthentication.AppleAuthenticationScope.EMAIL,
        ],
      });
      if (typeof loginWithApple === 'function') {
        const ok = await loginWithApple(credential);
        if (!ok) {
          Alert.alert('Apple Sign In Failed', 'Could not authenticate with Apple.');
          return;
        }
      } else if (credential?.identityToken) {
        await AsyncStorage.setItem('appleIdentityToken', credential.identityToken);
      }

      const role = await getEffectiveRole();
      if (userType === 'business' && !isOrgRole(role)) {
        await safeLogout();
        Alert.alert(
          'Not a business account',
          "That Apple login isn't registered as a business account. Switch to Car Care Pro."
        );
        return;
      }
      if (userType !== 'business' && !isValeterRole(role)) {
        await safeLogout();
        Alert.alert(
          'Not a Car Care Pro account',
          "That Apple login isn't registered as a Car Care Pro account. Switch to Business."
        );
        return;
      }
      finishRouting();
    } catch (error: any) {
      if (error?.code === 'ERR_CANCELED') return;
      Alert.alert('Apple Sign In Failed', error?.message || 'Please try again.');
    }
  };

  const handleGoogleLogin = () => {
    hapticFeedback('light');
    Alert.alert('Coming soon', 'Google sign-in will be available soon. Use email or Apple for now.');
  };

  const openEmailModal = () => {
    hapticFeedback('light');
    setEmailModalVisible(true);
  };

  const handleBiometricLogin = async () => {
    try {
      await hapticFeedback('light');
      const available = await isBiometricAvailable();
      if (!available) {
        Alert.alert('Biometric Unavailable', 'Biometric authentication is not available.');
        return;
      }
      const credentials = await getBiometricCredentials();
      if (!credentials) {
        Alert.alert('No Saved Credentials', 'Sign in with email first to enable biometric login.');
        return;
      }
      const authenticated = await authenticateWithBiometrics();
      if (!authenticated) return;

      setEmail(credentials.email);
      setPassword(credentials.password);
      setUserType(credentials.userType);
      setIsLoading(true);
      const ok = await login(credentials.email, credentials.password);
      if (!ok) {
        Alert.alert('Login Failed', 'Invalid credentials.');
        await clearBiometricCredentials();
        setHasBiometricCredentials(false);
        return;
      }
      const role = await getEffectiveRole();
      if (credentials.userType === 'business' && !isOrgRole(role)) {
        await safeLogout();
        Alert.alert('Not a business account', "That login isn't registered as a business account.");
        return;
      }
      if (credentials.userType !== 'business' && !isValeterRole(role)) {
        await safeLogout();
        Alert.alert('Not a Car Care Pro account', "That login isn't registered as a Car Care Pro account.");
        return;
      }
      finishRouting();
    } catch (e: any) {
      Alert.alert('Biometric Login Failed', e?.message || 'Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const openLink = (url: string) => Linking.openURL(url).catch(() => {});

  return (
    <View style={styles.root}>
      <StatusBar translucent backgroundColor="transparent" barStyle="light-content" />

      <TouchableOpacity
        style={styles.topRightLink}
        onPress={() => router.push('/auth/signup' as any)}
        disabled={isLoading}
        activeOpacity={0.8}
      >
        <Text style={styles.topRightLinkText}>Sign up</Text>
      </TouchableOpacity>

      <Animated.View style={[StyleSheet.absoluteFill, { opacity: videoOpacity }]}>
        <Video
          ref={videoRef}
          source={AUTH_PAGES_VIDEO}
          style={styles.videoBackground}
          resizeMode={ResizeMode.COVER}
          shouldPlay
          isLooping
          isMuted
          progressUpdateIntervalMillis={30}
          onPlaybackStatusUpdate={handlePlaybackStatusUpdate}
          onLoad={handleVideoLoad}
        />
      </Animated.View>
      <View style={StyleSheet.absoluteFill} pointerEvents="none">
        <LinearGradient colors={[...AUTH_GRADIENT_COLORS]} style={StyleSheet.absoluteFill} />
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <Animated.View
            style={[styles.contentContainer, { opacity: fadeAnim, transform: [{ translateY: slideAnim }] }]}
          >
            <View style={styles.logoContainer}>
              <View style={styles.logoImageWrapper}>
                <AuthBrandMark />
              </View>
              <Text style={styles.headline}>Welcome to Wish-a-Wash</Text>
              <Text style={styles.subtext}>Sign in to provide washes.</Text>
            </View>

            <View style={styles.contentOverlayWrapper}>
              <View style={StyleSheet.absoluteFill} pointerEvents="none">
                <LinearGradient
                  colors={[...AUTH_CONTENT_OVERLAY_COLORS]}
                  style={StyleSheet.absoluteFill}
                />
              </View>
              <BlurView intensity={Platform.OS === 'ios' ? 40 : 24} tint="dark" style={styles.glassCard}>
                <View style={styles.faceAndEmailRow}>
                  {isBiometricAvailableState && hasBiometricCredentials && (
                    <ContinueCTAButton
                      variant="secondary"
                      title={`Sign in with ${biometricType}`}
                      onPress={handleBiometricLogin}
                      accentColor={colors.SKY}
                      disabled={isLoading}
                      showTrailingChevron={false}
                      leading={
                        <Ionicons name="finger-print" size={22} color={colors.textOnDarkPrimary} />
                      }
                      style={styles.authGlassCta}
                    />
                  )}
                  <ContinueCTAButton
                    variant="secondary"
                    title="Continue with Email"
                    onPress={openEmailModal}
                    accentColor={colors.SKY}
                    disabled={isLoading}
                    showTrailingChevron={false}
                    leading={<Ionicons name="mail-outline" size={22} color={colors.textOnDarkPrimary} />}
                    style={styles.authGlassCta}
                  />
                </View>

                <View style={styles.dividerContainer}>
                  <View style={styles.dividerLine} />
                  <Text style={styles.dividerText}>or</Text>
                  <View style={styles.dividerLine} />
                </View>

                <Text style={styles.oauthLabel}>Continue with</Text>

                {isAppleAvailable && (
                  <TouchableOpacity
                    style={[styles.ssoButton, styles.ssoButtonApple]}
                    onPress={handleAppleLogin}
                    onPressIn={handlePressIn}
                    onPressOut={handlePressOut}
                    activeOpacity={0.9}
                  >
                    <Ionicons name="logo-apple" size={24} color="#000000" />
                    <Text style={[styles.ssoButtonText, styles.ssoButtonTextLight]}>
                      Continue with Apple
                    </Text>
                  </TouchableOpacity>
                )}
                <TouchableOpacity
                  style={[styles.ssoButton, styles.ssoButtonGoogle]}
                  onPress={handleGoogleLogin}
                  onPressIn={handlePressIn}
                  onPressOut={handlePressOut}
                  activeOpacity={0.9}
                >
                  <Ionicons name="logo-google" size={22} color="#4285F4" />
                  <Text style={[styles.ssoButtonText, styles.ssoButtonTextLight]}>
                    Continue with Google
                  </Text>
                </TouchableOpacity>
              </BlurView>
            </View>

            <View style={styles.trustCopy}>
              <Text style={styles.trustCopyText}>
                By continuing, you agree to{' '}
                <Text style={styles.trustCopyLink} onPress={() => openLink(TERMS_URL)}>
                  Terms
                </Text>
                {' & '}
                <Text style={styles.trustCopyLink} onPress={() => openLink(PRIVACY_URL)}>
                  Privacy Policy
                </Text>
              </Text>
            </View>

            <View style={styles.footer}>
              <Text style={styles.footerText}>Wish a Wash v1.0.0 • © 2025</Text>
            </View>
          </Animated.View>
        </ScrollView>
      </KeyboardAvoidingView>

      <Modal
        visible={emailModalVisible}
        animationType="slide"
        transparent
        onRequestClose={() => setEmailModalVisible(false)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setEmailModalVisible(false)}>
          <KeyboardAvoidingView
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
            style={styles.modalKeyboardAvoid}
          >
            <Pressable style={styles.modalContent} onPress={(e) => e.stopPropagation()}>
              <BlurView intensity={60} tint="dark" style={styles.modalBlur}>
                <ScrollView
                  style={styles.modalScroll}
                  contentContainerStyle={styles.modalScrollContent}
                  keyboardShouldPersistTaps="handled"
                  showsVerticalScrollIndicator={false}
                >
                  <View style={styles.modalInner}>
                    <View style={styles.modalHeader}>
                      <Text style={styles.modalTitle}>Sign in with Email</Text>
                      <TouchableOpacity
                        onPress={() => setEmailModalVisible(false)}
                        hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
                      >
                        <Ionicons name="close" size={28} color="rgba(255,255,255,0.9)" />
                      </TouchableOpacity>
                    </View>

                    <View style={styles.userTypeSwitcher}>
                      <TouchableOpacity
                        style={[styles.userTypeButton, userType === 'valeter' && styles.userTypeButtonActive]}
                        onPress={() => { setUserType('valeter'); hapticFeedback('light'); }}
                        activeOpacity={0.7}
                      >
                        <Text style={[styles.userTypeButtonText, userType === 'valeter' && styles.userTypeButtonTextActive]}>
                          Car Care Pro
                        </Text>
                      </TouchableOpacity>
                      <TouchableOpacity
                        style={[styles.userTypeButton, userType === 'business' && styles.userTypeButtonActive]}
                        onPress={() => { setUserType('business'); hapticFeedback('light'); }}
                        activeOpacity={0.7}
                      >
                        <Text style={[styles.userTypeButtonText, userType === 'business' && styles.userTypeButtonTextActive]}>
                          Business
                        </Text>
                      </TouchableOpacity>
                    </View>

                    <View style={styles.inputWrapper}>
                      <View style={styles.inputIconContainer}>
                        <Ionicons name="mail-outline" size={20} color="rgba(255,255,255,0.7)" />
                      </View>
                      <TextInput
                        style={styles.input}
                        placeholder="Email address"
                        placeholderTextColor={colors.inputPlaceholder}
                        value={email}
                        onChangeText={setEmail}
                        autoCapitalize="none"
                        keyboardType="email-address"
                        autoComplete="email"
                      />
                    </View>

                    <View style={styles.inputWrapper}>
                      <View style={styles.inputIconContainer}>
                        <Ionicons name="lock-closed-outline" size={20} color="rgba(255,255,255,0.7)" />
                      </View>
                      <TextInput
                        style={styles.input}
                        placeholder="Password"
                        placeholderTextColor={colors.inputPlaceholder}
                        value={password}
                        onChangeText={setPassword}
                        secureTextEntry
                        autoComplete="password"
                      />
                    </View>

                    <TouchableOpacity
                      style={styles.forgotPasswordLink}
                      onPress={() => Alert.alert('Reset Password', 'Password reset will be available soon.')}
                    >
                      <Text style={styles.forgotPasswordText}>Forgot password?</Text>
                    </TouchableOpacity>

                    <WWPrimaryButton
                      title={isLoading ? 'Signing in…' : 'Continue'}
                      onPress={() => handleLogin(false)}
                      disabled={isLoading}
                      loading={isLoading}
                      style={styles.loginButton}
                    />

                    {isBiometricAvailableState && !hasBiometricCredentials && (
                      <TouchableOpacity
                        style={styles.saveBiometricLink}
                        onPress={() => handleLogin(true)}
                        disabled={isLoading}
                      >
                        <Ionicons name="finger-print-outline" size={18} color="#87CEEB" />
                        <Text style={styles.saveBiometricText}>Enable {biometricType} for faster login</Text>
                      </TouchableOpacity>
                    )}

                    <TouchableOpacity style={styles.phoneInsteadLink}>
                      <Text style={styles.phoneInsteadText}>Use phone instead</Text>
                    </TouchableOpacity>
                  </View>
                </ScrollView>
              </BlurView>
            </Pressable>
          </KeyboardAvoidingView>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  ...sharedAuthStyleDefs,
  faceAndEmailRow: {
    gap: 12,
    marginBottom: 0,
  },
  authGlassCta: { marginBottom: 0 },
  oauthLabel: {
    marginTop: 4,
    marginBottom: 12,
    fontSize: 12,
    fontWeight: '600',
    color: 'rgba(255,255,255,0.6)',
    textAlign: 'center',
  },
  contentOverlayWrapper: {
    position: 'relative',
    width: '100%',
    borderRadius: 20,
    overflow: 'hidden',
    marginBottom: 4,
  },
  glassCard: {
    borderRadius: 20,
    overflow: 'hidden',
    paddingHorizontal: 20,
    paddingTop: 24,
    paddingBottom: 24,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  forgotPasswordLink: { alignSelf: 'flex-end', marginBottom: 14 },
  forgotPasswordText: { color: '#87CEEB', fontWeight: '600' },
  loginButton: { marginTop: 4 },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  modalKeyboardAvoid: { width: '100%', maxHeight: '92%' },
  modalContent: { maxHeight: '92%', borderTopLeftRadius: 24, borderTopRightRadius: 24, overflow: 'hidden' },
  modalBlur: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    overflow: 'hidden',
    maxHeight: '100%',
  },
  modalScroll: { maxHeight: '100%' },
  modalScrollContent: { padding: 24, paddingBottom: 40 },
  modalInner: { padding: 0 },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: { fontSize: 20, fontWeight: '700', color: 'rgba(255,255,255,0.95)' },
  userTypeSwitcher: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 999,
    padding: 3,
    marginBottom: 16,
    gap: 4,
  },
  userTypeButton: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 999,
    alignItems: 'center',
    justifyContent: 'center',
  },
  userTypeButtonActive: { backgroundColor: '#237AE6' },
  userTypeButtonText: { fontSize: 14, fontWeight: '600', color: 'rgba(255,255,255,0.7)' },
  userTypeButtonTextActive: { color: '#FFFFFF', fontWeight: '700' },
  phoneInsteadLink: { alignSelf: 'center', marginTop: 16, paddingVertical: 8 },
  phoneInsteadText: { fontSize: 14, color: 'rgba(255,255,255,0.65)', fontWeight: '500' },
  saveBiometricLink: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 12,
    paddingVertical: 8,
  },
  saveBiometricText: { fontSize: 13, color: '#87CEEB', fontWeight: '600' },
});
