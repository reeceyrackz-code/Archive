/**
 * Bottom sheet that shows the list of active bookings for the business.
 * Use on dashboard or anywhere you want to show active bookings in a sheet.
 */
import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  Pressable,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Alert,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import BusinessSheetBackground from '../shared/BusinessSheetBackground';
import { colors } from '../../constants/colors';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { supabase } from '../../lib/supabase';
import DefaultLoadingSkeleton from '../shared/DefaultLoadingSkeleton';
import GradientIconBox from '../shared/GradientIconBox';
import { canOpenLiveTracking } from '../../utils/businessBookingAccess';
import { canBusinessUseBookingChat } from '../../services/bookingCustomerChatAccess';

const SKY = colors.SKY;

export interface ActiveBookingItem {
  id: string;
  time: string;
  service: string;
  price: number;
  status: string;
  customerName?: string;
  /** Resolved customer avatar URL (profiles picture / avatar_url / logo). */
  customer_profile_picture?: string | null;
  customer_email?: string | null;
  customer_phone?: string | null;
  location_address?: string | null;
  assigned_valeter_name?: string | null;
  assigned_valeter_photo?: string | null;
  vehicle_registration?: string | null;
  vehicle_make?: string | null;
  vehicle_model?: string | null;
  scheduled_at?: string | null;
  /** Same as `bookings.user_id` — used for post-completion chat rules */
  customer_id?: string | null;
}

export interface ActiveBookingsSheetProps {
  visible: boolean;
  onClose: () => void;
  bookings: ActiveBookingItem[];
  loading?: boolean;
  onRefresh?: () => void;
  /** Optional: navigate to full bookings page on "View all" */
  onViewAll?: () => void;
}

const LIVE_STATUSES = ['in_progress', 'en_route', 'arrived'];

function statusLabel(s: string): string {
  const map: Record<string, string> = {
    in_progress: 'In progress',
    en_route: 'En route',
    arrived: 'Arrived',
    confirmed: 'Confirmed',
    pending_valeter_acceptance: 'Finding Car Care Pro',
    pending_payment: 'Pending payment',
    pending_business_acceptance: 'Pending',
    scheduled: 'Scheduled',
    pending: 'Pending',
  };
  return map[s] ?? s.replace(/_/g, ' ');
}

function BookingCard({
  booking,
  onTrack,
  onAmend,
  onChat,
  onCancel,
  onPress,
  cancellingId,
  canCancel,
  statusLabel: statusLabelFn,
}: {
  booking: ActiveBookingItem;
  onTrack: (b: ActiveBookingItem) => void;
  onAmend: (id: string) => void;
  onChat: (b: ActiveBookingItem) => void;
  onCancel: (b: ActiveBookingItem) => void;
  onPress: (id: string) => void;
  cancellingId: string | null;
  canCancel: boolean;
  statusLabel: (s: string) => string;
}) {
  const isActive = LIVE_STATUSES.includes(booking.status);
  const cancelling = cancellingId === booking.id;
  const vehicleLine = [booking.vehicle_registration, booking.vehicle_make, booking.vehicle_model].filter(Boolean).join(' ') || null;
  const hasContact = booking.customer_phone || booking.customer_email;
  const hasVehicle = !!vehicleLine;
  const trackLocked = !canOpenLiveTracking(booking.scheduled_at, booking.status);

  return (
    <TouchableOpacity
      activeOpacity={0.85}
      onPress={() => onPress(booking.id)}
      style={styles.card}
    >
      <View style={styles.cardRow}>
        {booking.customer_profile_picture ? (
          <Image source={{ uri: booking.customer_profile_picture }} style={styles.cardAvatar} resizeMode="cover" />
        ) : (
          <View style={styles.cardAvatarPlaceholder}>
            <Ionicons name="person" size={20} color="rgba(249,250,251,0.65)" />
          </View>
        )}
        <View style={styles.cardLeft}>
          <Text style={styles.cardCustomer} numberOfLines={1}>
            {booking.customerName || 'Customer'}
          </Text>
          <Text style={styles.cardService} numberOfLines={1}>{booking.service}</Text>
          <View style={styles.cardMeta}>
            <Ionicons name="time-outline" size={12} color="rgba(249,250,251,0.6)" />
            <Text style={styles.cardMetaText}>{booking.time}</Text>
            {booking.location_address ? (
              <>
                <Text style={styles.cardMetaDot}>·</Text>
                <Text style={styles.cardMetaText} numberOfLines={1}>
                  {booking.location_address.split(',')[0]}
                </Text>
              </>
            ) : null}
          </View>
        </View>
        <View style={[styles.badge, isActive && styles.badgeActive]}>
          {isActive && <View style={styles.badgeDot} />}
          <Text style={styles.badgeText}>{statusLabelFn(booking.status)}</Text>
        </View>
      </View>
      {(hasContact || hasVehicle) && (
        <View style={styles.detailsBlock}>
          {booking.customer_phone ? (
            <View style={styles.detailRow}>
              <Ionicons name="call-outline" size={14} color="rgba(249,250,251,0.65)" />
              <Text style={styles.detailText} numberOfLines={1}>{booking.customer_phone}</Text>
            </View>
          ) : null}
          {booking.customer_email ? (
            <View style={styles.detailRow}>
              <Ionicons name="mail-outline" size={14} color="rgba(249,250,251,0.65)" />
              <Text style={styles.detailText} numberOfLines={1}>{booking.customer_email}</Text>
            </View>
          ) : null}
          {vehicleLine ? (
            <View style={styles.detailRow}>
              <Ionicons name="car-outline" size={14} color="rgba(249,250,251,0.65)" />
              <Text style={styles.detailText} numberOfLines={1}>{vehicleLine}</Text>
            </View>
          ) : null}
        </View>
      )}
      {booking.assigned_valeter_name ? (
        <View style={styles.valeterRow}>
          {booking.assigned_valeter_photo ? (
            <Image source={{ uri: booking.assigned_valeter_photo }} style={styles.valeterAvatar} resizeMode="cover" />
          ) : (
            <View style={styles.valeterAvatarFallback}>
              <Ionicons name="person-outline" size={11} color="rgba(249,250,251,0.65)" />
            </View>
          )}
          <Text style={styles.valeterText}>Car Care Pro: {booking.assigned_valeter_name}</Text>
        </View>
      ) : null}
      <View style={styles.cardFooter}>
        <Text style={styles.priceText}>£{booking.price.toFixed(2)}</Text>
        <Text style={styles.viewDetails}>View details</Text>
        <Ionicons name="chevron-forward" size={18} color={SKY} />
      </View>
      <View style={styles.actionRow}>
        <TouchableOpacity
          style={[styles.actionBtn, trackLocked && styles.actionBtnDisabled]}
          onPress={() => onTrack(booking)}
          hitSlop={8}
          disabled={trackLocked}
        >
          <Ionicons name={trackLocked ? 'lock-closed-outline' : 'navigate-outline'} size={18} color={SKY} />
          <Text style={[styles.actionLabel, trackLocked && styles.actionLabelDisabled]}>Track</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionBtn} onPress={() => onAmend(booking.id)} hitSlop={8}>
          <Ionicons name="time-outline" size={18} color={SKY} />
          <Text style={styles.actionLabel}>Amend</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionBtn} onPress={() => onChat(booking)} hitSlop={8}>
          <Ionicons name="chatbubble-outline" size={18} color={SKY} />
          <Text style={styles.actionLabel}>Chat</Text>
        </TouchableOpacity>
        {canCancel && (
          <TouchableOpacity
            style={styles.actionBtn}
            onPress={() => onCancel(booking)}
            disabled={cancelling}
            hitSlop={8}
          >
            {cancelling ? (
              <ActivityIndicator size="small" color="#FCA5A5" />
            ) : (
              <Ionicons name="close-circle-outline" size={18} color="#FCA5A5" />
            )}
            <Text style={[styles.actionLabel, styles.actionLabelDanger]}>Cancel</Text>
          </TouchableOpacity>
        )}
      </View>
    </TouchableOpacity>
  );
}

export default function ActiveBookingsSheet({
  visible,
  onClose,
  bookings,
  loading = false,
  onRefresh,
  onViewAll,
}: ActiveBookingsSheetProps) {
  const insets = useSafeAreaInsets();
  const [cancellingId, setCancellingId] = useState<string | null>(null);

  // Completed/cancelled only belong on history page
  const nonFinished = bookings.filter((b) => b.status !== 'completed' && b.status !== 'cancelled');
  const activeBookings = nonFinished.filter((b) => LIVE_STATUSES.includes(b.status));
  const upcomingBookings = nonFinished.filter((b) => !LIVE_STATUSES.includes(b.status));

  const handleBookingPress = (id: string) => {
    hapticFeedback('light');
    onClose();
    router.push({ pathname: '/business/bookings/[id]', params: { id } } as any);
  };

  const handleTrack = (b: ActiveBookingItem) => {
    hapticFeedback('light');
    if (!canOpenLiveTracking(b.scheduled_at, b.status)) {
      Alert.alert(
        'Tracking unavailable',
        ['completed', 'cancelled'].includes(String(b.status).toLowerCase())
          ? 'This booking has ended.'
          : 'Live tracking unlocks 30 minutes before the scheduled start.'
      );
      return;
    }
    onClose();
    router.push({ pathname: '/business/bookings/tracking', params: { bookingId: b.id } } as any);
  };

  const handleAmend = (id: string) => {
    hapticFeedback('light');
    onClose();
    router.push({ pathname: '/business/bookings/[id]', params: { id } } as any);
  };

  const handleChat = async (b: ActiveBookingItem) => {
    hapticFeedback('light');
    const allowed = await canBusinessUseBookingChat(b.status, b.id, b.customer_id);
    if (!allowed) {
      Alert.alert(
        'Messaging locked',
        'For completed jobs, messaging unlocks when the customer sends a message.'
      );
      return;
    }
    onClose();
    router.push({ pathname: '/business/bookings/chat', params: { id: b.id } } as any);
  };

  const handleCancel = (booking: ActiveBookingItem) => {
    hapticFeedback('light');
    Alert.alert(
      'Cancel booking',
      `Cancel this booking for ${booking.customerName || 'Customer'}?`,
      [
        { text: 'No', style: 'cancel' },
        {
          text: 'Yes, cancel',
          style: 'destructive',
          onPress: async () => {
            setCancellingId(booking.id);
            try {
              const { error } = await supabase
                .from('bookings')
                .update({ status: 'cancelled' })
                .eq('id', booking.id);
              if (error) throw error;
              onRefresh?.();
            } catch (err: any) {
              Alert.alert('Error', err?.message || 'Failed to cancel booking');
            } finally {
              setCancellingId(null);
            }
          },
        },
      ]
    );
  };

  const handleViewAll = () => {
    hapticFeedback('light');
    onClose();
    if (onViewAll) onViewAll();
    else router.push('/business/bookings/activity');
  };

  const handleViewActivity = () => {
    hapticFeedback('light');
    onClose();
    router.push('/business/bookings/activity');
  };

  const canCancel = (status: string) => {
    const s = status.toLowerCase();
    return s !== 'cancelled' && s !== 'completed';
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      statusBarTranslucent
      onRequestClose={onClose}
    >
      <View style={styles.overlay}>
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose}>
          <View style={[StyleSheet.absoluteFill, styles.backdrop]} />
        </Pressable>
        <Pressable style={[styles.sheet, { paddingBottom: Math.max(24, insets.bottom + 12) }]} onPress={(e) => e.stopPropagation()}>
          <BusinessSheetBackground />
          <View style={styles.handle} />
          <View style={styles.headerRow}>
            <Text style={styles.title}>Active bookings</Text>
            <View style={styles.headerActions}>
              {onRefresh && (
                <TouchableOpacity onPress={onRefresh} style={styles.iconBtn} hitSlop={12}>
                  <Ionicons name="refresh-outline" size={22} color={SKY} />
                </TouchableOpacity>
              )}
              <TouchableOpacity onPress={onClose} style={styles.iconBtn} hitSlop={12}>
                <Ionicons name="close" size={24} color="rgba(249,250,251,0.9)" />
              </TouchableOpacity>
            </View>
          </View>
          <Text style={styles.subtitle}>Live and upcoming</Text>

          <View style={[styles.body, { paddingBottom: 24 }]}>
            {loading ? (
              <View style={styles.loadingWrap}>
                <DefaultLoadingSkeleton message="Loading…" />
              </View>
            ) : bookings.length === 0 ? (
              <View style={styles.emptyWrap}>
                <View style={styles.emptyCard}>
                  <GradientIconBox icon="calendar-outline" preset="sky" boxSize={56} size={28} />
                  <Text style={styles.emptyTitle}>No active bookings</Text>
                  <Text style={styles.emptySub}>New requests will appear here. Check activity for completed jobs.</Text>
                  <TouchableOpacity onPress={handleViewActivity} style={styles.ctaBtn} activeOpacity={0.85}>
                    <LinearGradient colors={[SKY, '#0ea5e9']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.ctaGrad}>
                      <Text style={styles.ctaText}>View activity</Text>
                      <Ionicons name="chevron-forward" size={18} color="#0f172a" />
                    </LinearGradient>
                  </TouchableOpacity>
                </View>
              </View>
            ) : (
              <ScrollView
                showsVerticalScrollIndicator={true}
                contentContainerStyle={styles.scrollContent}
                bounces={true}
              >
                {activeBookings.length > 0 && (
                  <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Active</Text>
                    {activeBookings.map((booking) => (
                      <BookingCard
                        key={booking.id}
                        booking={booking}
                        onTrack={handleTrack}
                        onAmend={handleAmend}
                        onChat={handleChat}
                        onCancel={handleCancel}
                        onPress={handleBookingPress}
                        cancellingId={cancellingId}
                        canCancel={canCancel(booking.status)}
                        statusLabel={statusLabel}
                      />
                    ))}
                  </View>
                )}
                {upcomingBookings.length > 0 && (
                  <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Upcoming</Text>
                    {upcomingBookings.map((booking) => (
                      <BookingCard
                        key={booking.id}
                        booking={booking}
                        onTrack={handleTrack}
                        onAmend={handleAmend}
                        onChat={handleChat}
                        onCancel={handleCancel}
                        onPress={handleBookingPress}
                        cancellingId={cancellingId}
                        canCancel={canCancel(booking.status)}
                        statusLabel={statusLabel}
                      />
                    ))}
                  </View>
                )}
                {activeBookings.length === 0 && upcomingBookings.length === 0 && (
                  <View style={styles.emptySection}>
                    <Text style={styles.emptySectionText}>No active or upcoming bookings</Text>
                  </View>
                )}
                <TouchableOpacity onPress={handleViewAll} style={styles.viewAllBtn} activeOpacity={0.8}>
                  <Text style={styles.viewAllText}>View all bookings</Text>
                  <Ionicons name="list-outline" size={20} color={SKY} />
                </TouchableOpacity>
              </ScrollView>
            )}
          </View>
        </Pressable>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  backdrop: {
    backgroundColor: 'rgba(0,0,0,0.75)',
  },
  sheet: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    maxHeight: '88%',
    minHeight: 380,
    borderWidth: 1,
    borderBottomWidth: 0,
    borderColor: 'rgba(125,211,252,0.28)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.28,
    shadowRadius: 20,
    elevation: 16,
    overflow: 'hidden',
    paddingTop: 12,
    paddingHorizontal: 20,
  },
  darkOverlay: { ...StyleSheet.absoluteFillObject },
  handle: {
    alignSelf: 'center',
    width: 36,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(125,211,252,0.6)',
    marginBottom: 12,
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 2,
  },
  title: { fontSize: 22, fontWeight: '800', color: '#F9FAFB', letterSpacing: -0.5 },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  iconBtn: { padding: 6 },
  subtitle: {
    fontSize: 13,
    color: 'rgba(249,250,251,0.6)',
    marginBottom: 16,
    letterSpacing: 0.3,
  },
  body: { flex: 1, paddingHorizontal: 0 },
  loadingWrap: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12, paddingVertical: 48 },
  loadingText: { fontSize: 15, color: SKY, fontWeight: '600' },
  emptyWrap: { paddingVertical: 24, paddingHorizontal: 0 },
  emptyCard: {
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.2)',
  },
  emptyTitle: { fontSize: 18, fontWeight: '800', color: '#F9FAFB', marginTop: 16, marginBottom: 6 },
  emptySub: { fontSize: 14, color: 'rgba(248,250,252,0.7)', marginBottom: 20, textAlign: 'center', paddingHorizontal: 8, lineHeight: 20 },
  ctaBtn: { borderRadius: 14, overflow: 'hidden', alignSelf: 'stretch' },
  ctaGrad: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, paddingVertical: 14, paddingHorizontal: 24 },
  ctaText: { fontSize: 16, fontWeight: '800', color: '#0f172a' },
  scrollContent: { paddingBottom: 24, gap: 14, paddingHorizontal: 0 },
  section: { marginBottom: 16 },
  sectionTitle: {
    fontSize: 13,
    fontWeight: '800',
    color: 'rgba(249,250,251,0.7)',
    marginBottom: 10,
    textTransform: 'uppercase',
    letterSpacing: 0.8,
  },
  emptySection: { paddingVertical: 16, alignItems: 'center' },
  emptySectionText: { fontSize: 14, color: 'rgba(248,250,252,0.6)', fontWeight: '500' },
  actionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    gap: 16,
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.08)',
  },
  actionBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  actionLabel: { fontSize: 12, fontWeight: '600', color: SKY },
  actionLabelDanger: { color: '#FCA5A5' },
  actionBtnDisabled: { opacity: 0.38 },
  actionLabelDisabled: { color: 'rgba(125,211,252,0.55)' },
  card: {
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 18,
    padding: 18,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.22)',
  },
  cardRow: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12 },
  cardAvatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  cardAvatarPlaceholder: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  cardLeft: { flex: 1, minWidth: 0 },
  cardCustomer: { fontSize: 16, fontWeight: '800', color: '#F9FAFB', marginBottom: 2 },
  cardService: { fontSize: 14, color: 'rgba(248,250,252,0.8)', marginBottom: 6, fontWeight: '600' },
  cardMeta: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 4 },
  cardMetaText: { fontSize: 12, color: 'rgba(249,250,251,0.6)', fontWeight: '500' },
  cardMetaDot: { fontSize: 12, color: 'rgba(249,250,251,0.5)' },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  badgeActive: { backgroundColor: 'rgba(125,211,252,0.25)', borderColor: 'rgba(125,211,252,0.4)' },
  badgeDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: SKY },
  badgeText: { fontSize: 11, fontWeight: '700', color: 'rgba(248,250,252,0.9)' },
  detailsBlock: { marginTop: 10, gap: 6 },
  detailRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  detailText: { fontSize: 13, color: 'rgba(249,250,251,0.85)', fontWeight: '500', flex: 1 },
  valeterRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 6 },
  valeterAvatar: {
    width: 18,
    height: 18,
    borderRadius: 9,
  },
  valeterAvatarFallback: {
    width: 18,
    height: 18,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
  },
  valeterText: { fontSize: 12, color: 'rgba(249,250,251,0.6)', fontWeight: '500' },
  cardFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.08)',
  },
  priceText: { fontSize: 15, fontWeight: '800', color: '#F9FAFB' },
  viewDetails: { fontSize: 14, fontWeight: '700', color: SKY, marginRight: 4 },
  viewAllBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    marginTop: 8,
    borderRadius: 14,
    backgroundColor: 'rgba(125,211,252,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.3)',
  },
  viewAllText: { fontSize: 15, fontWeight: '700', color: SKY },
});
