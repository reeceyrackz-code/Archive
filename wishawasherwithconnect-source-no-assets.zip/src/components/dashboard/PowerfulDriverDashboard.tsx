// app/valeter/PowerfulDriverDashboard.tsx
import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Dimensions,
  ScrollView,
  Modal,
  Alert,
  ActivityIndicator,
  RefreshControl,
  Platform,
  Image,
  Pressable,
  TextInput,
  Linking,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import MapView, { Marker, Region } from 'react-native-maps';
import { useAuth } from '../../providers/enhanced-auth-context';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import AppHeader, { HEADER_HEIGHT } from '../shared/AppHeader';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { PremiumCard } from '../premium';
import { SCREEN_PADDING_H, SECTION_GAP, CARD_GAP, SECTION_GAP_LG, MOTION } from '../../constants/premiumTokens';
import * as Location from 'expo-location';
import { supabase } from '../../lib/supabase';
import GradientNotificationBell from '../shared/GradientNotificationBell';
import GradientIconBox, { LocationStyleIconBox } from '../shared/GradientIconBox';
import { accentToGradient } from '../../utils/accentGradient';
import { CONTINUE_CTA_ICON_NAME } from '../../utils/bookingContinueStyle';
import BubbleBackground from '../shared/BubbleBackground';
import DefaultLoadingSkeleton from '../shared/DefaultLoadingSkeleton';
import { DashboardGlassSection } from '../shared/DashboardGlassSection';
import useLiveLocation from '../../hooks/useLiveLocation';
import { ValeterStatsService, ValeterPerformanceStats } from '../../services/Valeterstatsservice';
import { TAB_BAR_TOTAL_HEIGHT } from '../../../app/components/NavigationTab';
import { registerPushToken } from '../../services/registerPushToken';
import {
  notifyValeterJobRequest,
  preparePhoneNotifications,
} from '../../services/valeterJobPhoneNotifications';
import { getServiceDisplayName } from '../../utils/serviceNameMapper';
import {
  fetchProfileById,
  fetchProfilesByIds,
  resolveCustomerAvatarsForUserIds,
} from '../../utils/customerProfiles';
import {
  loadDismissedRecentJobIds,
  dismissRecentJobFromDashboard,
} from '../../services/dashboardRecentJobsDismissals';
import AnimatedProgress from '../booking/AnimatedProgress';
import { getStatusProgress } from '../../utils/trackingStatusHelpers';
import {
  assertNoScheduleConflictForOffer,
  loadValeterScheduleBlocks,
  offerOverlapsSchedule,
  valeterScheduleAllowsJobOffer,
} from '../../services/valeterScheduleConflict';
import { colors } from '../../constants/colors';
import { DARK_MAP_STYLE } from '../../constants/mapStyles';
import { HEADER_STYLE_CARD_GRADIENT } from '../../constants/bookingCardTheme';
import { syncValeterExternalCalendarBusyToSupabase } from '../../services/valeterExternalCalendarBusy';

const { width } = Dimensions.get('window');
const SKY = colors.SKY ?? '#38BDF8';
const isSmallScreen = width < 375;

const VALETER_HERO_SUBTEXTS = [
  'Available jobs in your area',
  'Go online to receive requests',
  'Update status as you go',
];

function getStatusRingColor(status: string): string {
  switch (status) {
    case 'pending_payment':
      return '#F59E0B';
    case 'confirmed':
      return '#8B5CF6';
    case 'en_route':
    case 'arrived':
      return '#10B981';
    case 'in_progress':
      return SKY;
    default:
      return SKY;
  }
}

// All statuses that count as "active" — card disappears only when completed or cancelled
const ACTIVE_JOB_STATUSES = ['pending_payment', 'scheduled', 'confirmed', 'en_route', 'arrived', 'in_progress'] as const;
type ActiveJob = {
  id: string;
  status: string;
  service_type: string;
  service_name: string | null;
  location_address: string | null;
  location_lat: number | null;
  location_lng: number | null;
  price: number;
  user_id: string | null;
};

function haversineMi(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 3959;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

interface JobRequest {
  id: string;
  serviceName: string;
  distance: number;
  driveTimeMinutes?: number;
  price: number;
  customerName: string;
  address: string;
  timeRemaining: number;
  location_lat: number | null;
  location_lng: number | null;
  scheduledAt?: string | null;
  requestSentAt?: string | null;
  serviceType?: string;
  serviceNameRaw?: string | null;
}

interface TodayStats {
  hoursOnline: string;
  jobsCompleted: number;
  earnings: number;
}

export default function PowerfulDriverDashboard() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme, mode } = useAccountTheme();

  const [profilePicture, setProfilePicture] = useState<string | null>(null);
  const [recentBookings, setRecentBookings] = useState<any[]>([]);
  const [isOnline, setIsOnline] = useState(false);
  const [loadingPresence, setLoadingPresence] = useState(true);
  const [toggling, setToggling] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const [jobRequests, setJobRequests] = useState<JobRequest[]>([]);
  const [todayStats, setTodayStats] = useState<TodayStats>({
    hoursOnline: '0h 0m',
    jobsCompleted: 0,
    earnings: 0,
  });

  const [valeterStats, setValeterStats] = useState<ValeterPerformanceStats | null>(null);
  const [loadingStats, setLoadingStats] = useState(true);

  const [profileName, setProfileName] = useState<string>('Car Care Pro');
  const [workingRadius, setWorkingRadius] = useState<number>(10);

  const [activeJob, setActiveJob] = useState<ActiveJob | null>(null);
  const [activeJobLoading, setActiveJobLoading] = useState(false);
  const [selectedYourJob, setSelectedYourJob] = useState<any | null>(null);
  const [dismissedValeterRecentIds, setDismissedValeterRecentIds] = useState<Set<string>>(() => new Set());
  const [activeJobMapRegion, setActiveJobMapRegion] = useState<Region | null>(null);
  const [customerNameActive, setCustomerNameActive] = useState<string>('Customer');
  const [heroSubtextIndex, setHeroSubtextIndex] = useState(0);
  const heroSubtextOpacity = useRef(new Animated.Value(1)).current;

  const [showLocationPicker, setShowLocationPicker] = useState(false);
  const [pickedLocationLabel, setPickedLocationLabel] = useState<string | null>(null);
  const [pickedCoords, setPickedCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [locationSearchQuery, setLocationSearchQuery] = useState('');
  const [locationSearching, setLocationSearching] = useState(false);

  const { coords, cityLabel, addressLine, loading: locationLoading, refresh } = useLiveLocation();

  const scrollY = useRef(new Animated.Value(0)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const locationChannelsRef = useRef<ReturnType<typeof supabase.channel>[]>([]);

  // Fade in animation on mount
  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 800,
      useNativeDriver: true,
    }).start();
  }, []);

  // Pulsing animation for online indicator
  useEffect(() => {
    if (isOnline) {
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, { toValue: 1.2, duration: 1000, useNativeDriver: true }),
          Animated.timing(pulseAnim, { toValue: 1, duration: 1000, useNativeDriver: true }),
        ])
      ).start();
    } else {
      pulseAnim.setValue(1);
    }
  }, [isOnline, pulseAnim]);

  const loadValeterName = async (userId: string) => {
    // 1) valeter_profiles.full_name (primary - saved from profile page)
    try {
      const { data: vp } = await supabase
        .from('valeter_profiles')
        .select('full_name')
        .eq('user_id', userId)
        .maybeSingle();

      const name = (vp?.full_name || '').trim();
      if (name) return name;
    } catch {}

    // 2) profiles.full_name (fallback)
    try {
      const { data: p } = await supabase
        .from('profiles')
        .select('full_name')
        .eq('id', userId)
        .maybeSingle();

      const name = (p?.full_name || '').trim();
      if (name) return name;
    } catch {}

    // 3) auth context / fallback
    const maybe = (user?.name || '').trim();
    if (maybe) return maybe;

    return 'Car Care Pro';
  };

  const loadWorkingRadius = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('valeter_profiles')
        .select('working_radius')
        .eq('user_id', userId)
        .maybeSingle();

      if (error) {
        console.warn('[valeter_profiles] working_radius read error', error);
        return;
      }

      const r = Number(data?.working_radius);
      if (Number.isFinite(r) && r > 0) setWorkingRadius(r);
      else setWorkingRadius(10);
    } catch (e) {
      console.warn('[valeter_profiles] working_radius read crash', e);
      setWorkingRadius(10);
    }
  };

  useEffect(() => {
    if (!user?.id) {
      setDismissedValeterRecentIds(new Set());
      return;
    }
    let cancelled = false;
    void loadDismissedRecentJobIds('valeter', user.id).then((s) => {
      if (!cancelled) setDismissedValeterRecentIds(s);
    });
    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  const handleDismissValeterRecentJob = useCallback(
    async (jobId: string) => {
      if (!user?.id) return;
      await hapticFeedback('light');
      await dismissRecentJobFromDashboard('valeter', user.id, jobId);
      setDismissedValeterRecentIds((prev) => new Set(prev).add(jobId));
    },
    [user?.id]
  );

  const loadRecentBookings = useCallback(async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select(
          'id, service_type, service_name, status, price, scheduled_at, location_address, user_id, created_at, completed_at, updated_at'
        )
        .eq('valeter_id', user.id)
        .in('status', [
          'completed',
          'confirmed',
          'in_progress',
          'scheduled',
          'pending_payment',
          'en_route',
          'arrived',
          'pending_valeter_acceptance',
          'valeter_assigned',
        ])
        .limit(40);

      if (error) {
        console.warn('[Dashboard] loadRecentBookings error:', error);
        setRecentBookings([]);
        return;
      }
      if (!data?.length) {
        setRecentBookings([]);
        return;
      }

      const ids = [
        ...new Set(
          data
            .map((b: { user_id?: string | null }) => b.user_id)
            .filter((id): id is string => typeof id === 'string' && id.length > 0)
        ),
      ];
      const profiles = await fetchProfilesByIds(ids);
      const photos = ids.length > 0 ? resolveCustomerAvatarsForUserIds(ids, profiles) : new Map();
      const now = Date.now();
      const thirtyMs = 30 * 24 * 60 * 60 * 1000;
      const isUpcomingRow = (b: { scheduled_at?: string | null; status?: string }) => {
        if (!b.scheduled_at) return false;
        if (new Date(b.scheduled_at).getTime() <= now) return false;
        const s = String(b.status);
        return !['completed', 'cancelled', 'valeter_timeout'].includes(s);
      };

      const enriched = data
        .map((b: Record<string, unknown>) => {
          const uid = typeof b.user_id === 'string' ? b.user_id : null;
          const p = uid ? profiles.get(uid) : undefined;
          return {
            ...b,
            customer_name: p?.full_name || p?.name || 'Customer',
            customer_photo: uid ? photos.get(uid) ?? null : null,
          };
        })
        .filter((b: Record<string, unknown>) => {
          const st = String(b.status ?? '').toLowerCase();
          if (st !== 'completed' && st !== 'valeter_timeout') return true;
          const ref = (b.completed_at as string | null | undefined) || (b.updated_at as string | null | undefined) || (b.created_at as string | undefined);
          if (!ref) return true;
          const t = new Date(ref).getTime();
          if (!Number.isFinite(t)) return true;
          return Date.now() - t <= thirtyMs;
        });

      enriched.sort((a: Record<string, unknown>, b: Record<string, unknown>) => {
        const aUp = isUpcomingRow(a as { scheduled_at?: string | null; status?: string });
        const bUp = isUpcomingRow(b as { scheduled_at?: string | null; status?: string });
        if (aUp && !bUp) return -1;
        if (!aUp && bUp) return 1;
        if (aUp && bUp) {
          return (
            new Date(String(a.scheduled_at)).getTime() - new Date(String(b.scheduled_at)).getTime()
          );
        }
        const ad = new Date(
          typeof a.scheduled_at === 'string'
            ? a.scheduled_at
            : typeof a.created_at === 'string'
              ? a.created_at
              : 0
        ).getTime();
        const bd = new Date(
          typeof b.scheduled_at === 'string'
            ? b.scheduled_at
            : typeof b.created_at === 'string'
              ? b.created_at
              : 0
        ).getTime();
        return bd - ad;
      });

      setRecentBookings(enriched);
    } catch (e) {
      console.warn('[Dashboard] loadRecentBookings error:', e);
      setRecentBookings([]);
    }
  }, [user?.id]);

  // Load initial online status + subscribe to realtime
  useEffect(() => {
    if (!user?.id) return;
    let mounted = true;

    (async () => {
      setLoadingPresence(true);

      // ✅ Name at top should be the valeter's name
      const name = await loadValeterName(user.id);
      if (mounted) setProfileName(name);

      // ✅ Working radius from DB
      await loadWorkingRadius(user.id);

      // Load profile picture - check both valeter_profiles and documents table
      const [profileRes, docRes] = await Promise.all([
        supabase
          .from('valeter_profiles')
          .select('profile_photo_url')
          .eq('user_id', user.id)
          .maybeSingle(),
        supabase
          .from('valeter_documents')
          .select('file_url, status')
          .eq('user_id', user.id)
          .eq('type', 'profile_photo')
          .maybeSingle(),
      ]);
      
      if (mounted) {
        const profilePhotoUrl = profileRes.data?.profile_photo_url || 
          (docRes.data?.status === 'approved' ? docRes.data.file_url : null);
        
        if (profilePhotoUrl) {
          setProfilePicture(profilePhotoUrl);
        }
      }

      // Load recent bookings and today's earnings (real data from jobs)
      const todayStart = new Date();
      todayStart.setHours(0, 0, 0, 0);
      const todayEnd = new Date(todayStart);
      todayEnd.setDate(todayEnd.getDate() + 1);

      const [todayRes] = await Promise.all([
        supabase
          .from('bookings')
          .select('id, status, price, scheduled_at')
          .eq('valeter_id', user.id)
          .gte('scheduled_at', todayStart.toISOString())
          .lt('scheduled_at', todayEnd.toISOString()),
        loadRecentBookings(),
      ]);

      if (mounted && todayRes.data) {
        const completedToday = (todayRes.data as any[]).filter((b) => b.status === 'completed');
        const earningsToday = completedToday.reduce((sum: number, b: any) => sum + (Number(b.price) || 0), 0);
        setTodayStats({
          hoursOnline: '0h 0m',
          jobsCompleted: completedToday.length,
          earnings: Math.round(earningsToday * 100) / 100,
        });
      }

      // presence
      const { data, error } = await supabase
        .from('valeter_presence')
        .select('is_online')
        .eq('user_id', user.id)
        .maybeSingle();

      if (!mounted) return;
      if (error) console.warn('[presence] read error', error);

      setIsOnline(!!data?.is_online);
      setLoadingPresence(false);
    })();

    const channel = supabase
      .channel('presence-self')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'valeter_presence',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          const row: any = payload.new ?? payload.old;
          if (row && typeof row.is_online === 'boolean') setIsOnline(row.is_online);
        }
      )
      .subscribe();

    return () => {
      mounted = false;
      supabase.removeChannel(channel);
    };
  }, [user?.id, loadRecentBookings]);

  useEffect(() => {
    if (!user?.id) return;
    void preparePhoneNotifications();
    void registerPushToken();
  }, [user?.id]);

  // When valeter is already online (e.g. after login), refresh their location once so map/jobs show current position
  const locationRefreshedOnMount = useRef(false);
  useEffect(() => {
    if (!user?.id || !isOnline || loadingPresence || locationRefreshedOnMount.current) return;
    locationRefreshedOnMount.current = true;
    (async () => {
      try {
        const { status } = await Location.getForegroundPermissionsAsync();
        if (status !== 'granted') return;
        const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
        const lat = Number(loc.coords.latitude.toFixed(6));
        const lng = Number(loc.coords.longitude.toFixed(6));
        await supabase.rpc('update_my_presence', {
          p_is_online: true,
          p_last_lat: lat,
          p_last_lng: lng,
        });
      } catch (e) {
        console.warn('[ValeterDashboard] Refresh location on load failed:', e);
      }
    })();
  }, [user?.id, isOnline, loadingPresence]);

  const REQUEST_TIMEOUT_SECONDS = 300; // 5 min to accept

  const loadJobRequests = useCallback(async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select(
          'id, service_name, service_type, location_address, location_lat, location_lng, price, scheduled_at, request_sent_at, created_at, user_id'
        )
        .eq('valeter_id', user.id)
        .eq('status', 'pending_valeter_acceptance')
        .order('request_sent_at', { ascending: false })
        .limit(20);

      if (error) throw error;

      const rows = data || [];
      const userIds = [...new Set(rows.map((r: any) => r.user_id).filter(Boolean))] as string[];
      const { commitmentWindows, externalBusy } = await loadValeterScheduleBlocks(user.id);
      const [presenceRes, profilesMap] = await Promise.all([
        supabase.from('valeter_presence').select('last_lat, last_lng').eq('user_id', user.id).maybeSingle(),
        fetchProfilesByIds(userIds),
      ]);
      const vLat = presenceRes.data?.last_lat;
      const vLng = presenceRes.data?.last_lng;

      const nowSec = Math.floor(Date.now() / 1000);
      const list: JobRequest[] = rows.map((r: any) => {
        const sentAt = r.request_sent_at || r.created_at;
        const endSec = sentAt ? Math.floor(new Date(sentAt).getTime() / 1000) + REQUEST_TIMEOUT_SECONDS : nowSec + REQUEST_TIMEOUT_SECONDS;
        const timeRemaining = Math.max(0, endSec - nowSec);
        let distance = 0;
        let driveTimeMinutes: number | undefined;
        if (vLat != null && vLng != null && r.location_lat != null && r.location_lng != null) {
          distance = Math.round(haversineMi(vLat, vLng, r.location_lat, r.location_lng) * 10) / 10;
          driveTimeMinutes = Math.round(distance * 2);
        }
        const profile = r.user_id ? profilesMap.get(r.user_id) : null;
        const customerName = profile?.full_name?.trim() || 'Customer';
        return {
          id: r.id,
          serviceName: getServiceDisplayName(r.service_type, r.service_name),
          distance,
          driveTimeMinutes,
          price: Number(r.price) || 0,
          customerName,
          address: r.location_address || '',
          timeRemaining,
          location_lat: r.location_lat != null ? Number(r.location_lat) : null,
          location_lng: r.location_lng != null ? Number(r.location_lng) : null,
          scheduledAt: r.scheduled_at ?? null,
          requestSentAt: r.request_sent_at || r.created_at || null,
          serviceType: typeof r.service_type === 'string' ? r.service_type : undefined,
          serviceNameRaw: r.service_name ?? null,
        };
      });
      const listFiltered = list.filter(
        (req) =>
          !offerOverlapsSchedule(
            req.scheduledAt,
            req.requestSentAt,
            req.serviceType,
            req.serviceNameRaw ?? undefined,
            commitmentWindows,
            externalBusy
          )
      );
      setJobRequests(listFiltered);
    } catch (e) {
      console.warn('[Dashboard] loadJobRequests error', e);
      setJobRequests([]);
    }
  }, [user?.id]);

  // Load job requests when online (initial + when going online)
  useEffect(() => {
    if (!user?.id || !isOnline) return;
    loadJobRequests();
  }, [user?.id, isOnline, loadJobRequests]);

  // Subscribe to job requests for this valeter (realtime when new requests come in)
  useEffect(() => {
    if (!user?.id || !isOnline) return;

    const channel = supabase
      .channel('job-requests')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'bookings',
          filter: `valeter_id=eq.${user.id}`,
        },
        (payload) => {
          const booking: any = payload.new;
          if (booking.status === 'pending_valeter_acceptance') {
            void loadJobRequests();
            void (async () => {
              if (!user?.id) return;
              const ok = await valeterScheduleAllowsJobOffer(user.id, booking);
              if (!ok) return;
              void notifyValeterJobRequest({
                bookingId: booking.id,
                serviceName: booking.service_name,
                price: booking.price,
                locationAddress: booking.location_address,
              });
            })();
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'bookings',
          filter: `valeter_id=eq.${user.id}`,
        },
        (payload) => {
          const booking: any = payload.new;
          if (booking.status === 'pending_valeter_acceptance') {
            void loadJobRequests();
            void (async () => {
              if (!user?.id) return;
              const ok = await valeterScheduleAllowsJobOffer(user.id, booking);
              if (!ok) return;
              void notifyValeterJobRequest({
                bookingId: booking.id,
                serviceName: booking.service_name,
                price: booking.price,
                locationAddress: booking.location_address,
              });
            })();
            return;
          }

          setJobRequests((prev) => prev.filter((r) => r.id !== booking.id));
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id, isOnline, loadJobRequests]);

  // Countdown timer for job requests
  useEffect(() => {
    if (jobRequests.length === 0) return;

    const interval = setInterval(() => {
      setJobRequests((prev) =>
        prev
          .map((req) => {
            if (req.timeRemaining <= 1) {
              handleJobTimeout(req.id);
              return { ...req, timeRemaining: 0 };
            }
            return { ...req, timeRemaining: req.timeRemaining - 1 };
          })
          .filter((req) => req.timeRemaining > 0)
      );
    }, 1000);

    return () => clearInterval(interval);
  }, [jobRequests]);

  const goOnlineWithLocation = async () => {
    const uid = user?.id;
    if (!uid) throw new Error('not-signed-in');
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission needed', 'Location permission is required to go online so customers can find you.');
      throw new Error('location-permission-denied');
    }
    const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
    const lat = Number(loc.coords.latitude.toFixed(6));
    const lng = Number(loc.coords.longitude.toFixed(6));

    const { error } = await supabase.rpc('update_my_presence', {
      p_is_online: true,
      p_last_lat: lat,
      p_last_lng: lng,
    });
    if (error) throw error;
    void syncValeterExternalCalendarBusyToSupabase(uid, true);
  };

  const goOffline = async () => {
    const { error } = await supabase.rpc('set_online', { p_is_online: false });
    if (error) throw error;
  };

  const toggleOnline = async () => {
    try {
      if (!user?.id) return;
      setToggling(true);
      await hapticFeedback('medium');

      if (!isOnline) await goOnlineWithLocation();
      else await goOffline();

      setIsOnline(!isOnline);
    } catch (e) {
      console.error('[presence] toggle error', e);
      Alert.alert('Error', 'Could not update your online status. Try again.');
    } finally {
      setToggling(false);
    }
  };

  const handleAcceptJob = async (jobId: string) => {
    if (!user?.id) return;
    try {
      await hapticFeedback('medium');
      const req = jobRequests.find((r) => r.id === jobId);
      const gate = await assertNoScheduleConflictForOffer(user.id, {
        scheduled_at: req?.scheduledAt,
        request_sent_at: req?.requestSentAt,
        service_type: req?.serviceType,
        service_name: req?.serviceNameRaw,
      });
      if (!gate.ok) {
        Alert.alert('Schedule clash', gate.message);
        return;
      }
      const { error } = await supabase
        .from('bookings')
        .update({
          valeter_id: user.id,
          status: 'pending_payment',
        })
        .eq('id', jobId);

      if (error) throw error;

      setJobRequests((prev) => prev.filter((r) => r.id !== jobId));
      router.push({ pathname: '/valeter/jobs/tracking', params: { jobId } } as any);
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to accept job');
    }
  };

  const handleDeclineJob = async (jobId: string) => {
    try {
      await hapticFeedback('light');
      const { error } = await supabase
        .from('bookings')
        .update({
          status: 'valeter_declined',
          valeter_response_at: new Date().toISOString(),
        })
        .eq('id', jobId);

      if (error) throw error;
      setJobRequests((prev) => prev.filter((r) => r.id !== jobId));
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to decline job');
    }
  };

  const handleJobTimeout = async (jobId: string) => {
    try {
      await supabase.from('bookings').update({ status: 'valeter_timeout' }).eq('id', jobId);
    } catch (e) {
      console.error('Timeout update failed:', e);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const displayLocationLabel = pickedLocationLabel ?? cityLabel ?? 'Set location';

  const handleUseCurrentLocation = async () => {
    try {
      await hapticFeedback('light');
      setPickedLocationLabel(null);
      setPickedCoords(null);
      const { status } = await Location.getForegroundPermissionsAsync();
      if (status !== 'granted') {
        const req = await Location.requestForegroundPermissionsAsync();
        if (req.status !== 'granted') {
          Alert.alert('Permission needed', 'Location permission is required to use current location.');
          return;
        }
      }
      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const lat = Number(loc.coords.latitude.toFixed(6));
      const lng = Number(loc.coords.longitude.toFixed(6));
      if (user?.id && isOnline) {
        await supabase.rpc('update_my_presence', { p_is_online: true, p_last_lat: lat, p_last_lng: lng });
      }
      await refresh();
      setShowLocationPicker(false);
    } catch (e) {
      console.warn('[Dashboard] use current location error', e);
      Alert.alert('Error', 'Could not get current location. Try again.');
    }
  };

  const handleSearchLocation = async () => {
    const query = locationSearchQuery.trim();
    if (!query) return;
    try {
      setLocationSearching(true);
      await hapticFeedback('light');
      const results = await Location.geocodeAsync(query);
      if (results && results.length > 0) {
        const first = results[0];
        const lat = first.latitude;
        const lng = first.longitude;
        setPickedCoords({ lat, lng });
        setPickedLocationLabel(query);
        if (user?.id && isOnline) {
          await supabase.rpc('update_my_presence', {
            p_is_online: true,
            p_last_lat: Number(lat.toFixed(6)),
            p_last_lng: Number(lng.toFixed(6)),
          });
        }
        setShowLocationPicker(false);
        setLocationSearchQuery('');
      } else {
        Alert.alert('No results', 'No location found for that address. Try a different search.');
      }
    } catch (e) {
      console.warn('[Dashboard] geocode error', e);
      Alert.alert('Error', 'Could not find that location. Try again.');
    } finally {
      setLocationSearching(false);
    }
  };

  const loadActiveJob = useCallback(async () => {
    if (!user?.id) return;
    try {
      setActiveJobLoading(true);
      const { data, error } = await supabase
        .from('bookings')
        .select('id,status,service_type,service_name,location_address,location_lat,location_lng,price,user_id')
        .eq('valeter_id', user.id)
        .in('status', ACTIVE_JOB_STATUSES as any)
        .order('request_sent_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error || !data) {
        setActiveJob(null);
        setActiveJobMapRegion(null);
        return;
      }

      const lat = data.location_lat != null ? Number(data.location_lat) : null;
      const lng = data.location_lng != null ? Number(data.location_lng) : null;

      setActiveJob({
        id: data.id,
        status: data.status,
        service_type: data.service_type,
        service_name: data.service_name ?? null,
        location_address: data.location_address ?? null,
        location_lat: lat,
        location_lng: lng,
        price: Number(data.price ?? 0),
        user_id: data.user_id ?? null,
      });

      if (lat != null && lng != null) {
        setActiveJobMapRegion({
          latitude: lat,
          longitude: lng,
          latitudeDelta: 0.02,
          longitudeDelta: 0.02,
        });
      } else {
        setActiveJobMapRegion(null);
      }

      if (data.user_id) {
        const profile = await fetchProfileById(data.user_id);
        setCustomerNameActive(profile?.full_name || 'Customer');
      } else {
        setCustomerNameActive('Customer');
      }
    } catch (e) {
      console.warn('[Dashboard] loadActiveJob error:', e);
      setActiveJob(null);
      setActiveJobMapRegion(null);
    } finally {
      setActiveJobLoading(false);
    }
  }, [user?.id]);

  useEffect(() => {
    if (!user?.id) return;
    loadActiveJob();
    const channel = supabase
      .channel(`valeter-active-job-${user.id}`)
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'bookings', filter: `valeter_id=eq.${user.id}` },
        () => { loadActiveJob(); }
      )
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user?.id, loadActiveJob]);

  useEffect(() => {
    const t = setInterval(() => setHeroSubtextIndex((i) => (i + 1) % VALETER_HERO_SUBTEXTS.length), 4000);
    return () => clearInterval(t);
  }, []);

  // Load valeter stats
  useEffect(() => {
    if (!user?.id) return;

    const loadStats = async () => {
      try {
        setLoadingStats(true);
        const stats = await ValeterStatsService.getValeterStats(user.id);
        setValeterStats(stats);
      } catch (error) {
        console.error('Error loading valeter stats:', error);
      } finally {
        setLoadingStats(false);
      }
    };

    loadStats();
  }, [user?.id]);

  const loadTodayStats = useCallback(async () => {
    if (!user?.id) return;
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    const todayEnd = new Date(todayStart);
    todayEnd.setDate(todayEnd.getDate() + 1);
    const { data } = await supabase
      .from('bookings')
      .select('id, status, price, completed_at')
      .eq('valeter_id', user.id)
      .eq('status', 'completed')
      .gte('completed_at', todayStart.toISOString())
      .lt('completed_at', todayEnd.toISOString());
    const completedToday = data || [];
    const earningsToday = completedToday.reduce((sum: number, b: any) => sum + (Number(b.price) || 0), 0);
    setTodayStats({
      hoursOnline: '0h 0m',
      jobsCompleted: completedToday.length,
      earnings: Math.round(earningsToday * 100) / 100,
    });
  }, [user?.id]);

  const onRefresh = async () => {
    setRefreshing(true);
    try {
      if (user?.id) {
        const stats = await ValeterStatsService.getValeterStats(user.id);
        setValeterStats(stats);
        await loadWorkingRadius(user.id);
        const name = await loadValeterName(user.id);
        setProfileName(name);
        await loadActiveJob();
        await loadJobRequests();
        await loadTodayStats();
        await loadRecentBookings();
      }
      await new Promise((resolve) => setTimeout(resolve, 700));
    } finally {
      setRefreshing(false);
    }
  };

  const handleResumeTracking = () => {
    if (activeJob?.id) {
      hapticFeedback('light');
      router.push({ pathname: '/valeter/jobs/tracking', params: { jobId: activeJob.id } } as any);
    }
  };

  const quickScale0 = useRef(new Animated.Value(1)).current;
  const quickScale1 = useRef(new Animated.Value(1)).current;
  const quickScale2 = useRef(new Animated.Value(1)).current;
  const quickScale3 = useRef(new Animated.Value(1)).current;
  const quickScale4 = useRef(new Animated.Value(1)).current;
  const quickScale5 = useRef(new Animated.Value(1)).current;
  const headerBg = theme.headerBackground || theme.background || ['#0A1929', '#2563EB'];
  const accent = theme.primary || '#3B82F6';
  const upcomingJobs = useMemo(() => {
    const now = Date.now();
    return recentBookings
      .filter((b: any) => {
        if (!b.scheduled_at || new Date(b.scheduled_at).getTime() <= now) return false;
        const s = String(b.status);
        return !['completed', 'cancelled', 'valeter_timeout'].includes(s);
      })
      .slice(0, 8);
  }, [recentBookings]);
  const firstJobRequest = jobRequests[0] ?? null;
  const highValueCount = useMemo(() => jobRequests.filter((r) => r.price >= 40).length, [jobRequests]);

  const firstJobRequestMapRegion = useMemo((): Region | null => {
    if (!firstJobRequest?.location_lat || !firstJobRequest?.location_lng) return null;
    const jLat = firstJobRequest.location_lat;
    const jLng = firstJobRequest.location_lng;
    const vLat = coords?.latitude;
    const vLng = coords?.longitude;
    if (vLat != null && vLng != null) {
      const minLat = Math.min(jLat, vLat);
      const maxLat = Math.max(jLat, vLat);
      const minLng = Math.min(jLng, vLng);
      const maxLng = Math.max(jLng, vLng);
      const latDelta = Math.max((maxLat - minLat) * 2, 0.012);
      const lngDelta = Math.max((maxLng - minLng) * 2, 0.012);
      return {
        latitude: (minLat + maxLat) / 2,
        longitude: (minLng + maxLng) / 2,
        latitudeDelta: latDelta,
        longitudeDelta: lngDelta,
      };
    }
    return { latitude: jLat, longitude: jLng, latitudeDelta: 0.02, longitudeDelta: 0.02 };
  }, [firstJobRequest?.location_lat, firstJobRequest?.location_lng, coords?.latitude, coords?.longitude]);

  return (
    <View style={styles.container}>
      <LinearGradient colors={theme.background as [string, string]} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />
      <SafeAreaView style={StyleSheet.absoluteFill} edges={['top']}>
        <AppHeader
          title={profileName || 'Car Care Pro'}
          subtitle={displayLocationLabel}
          onSubtitlePress={() => { hapticFeedback('light'); setShowLocationPicker(true); }}
          accountType="valeter"
          showBack={false}
          profilePicture={profilePicture || undefined}
          rightAction={
            <TouchableOpacity onPress={() => router.push('/valeter/notifications')} style={{ padding: 4 }}>
              <GradientNotificationBell count={jobRequests.length} onPress={() => router.push('/valeter/notifications')} />
            </TouchableOpacity>
          }
        />

        <Animated.ScrollView
          style={[styles.scrollView, { marginTop: HEADER_HEIGHT }]}
          onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
          scrollEventThrottle={16}
          contentContainerStyle={[styles.scrollContent, { paddingTop: SECTION_GAP, paddingBottom: TAB_BAR_TOTAL_HEIGHT + (insets?.bottom ?? 0) + SECTION_GAP_LG }]}
          showsVerticalScrollIndicator={false}
          refreshControl={<RefreshControl tintColor={accent} refreshing={refreshing} onRefresh={onRefresh} />}
        >
          <Animated.View style={{ opacity: fadeAnim }}>
            {/* Hero: View Jobs — same style as customer "Book a Wash" */}
            <View style={[styles.bookingButtonsSection, { marginHorizontal: isSmallScreen ? 12 : SCREEN_PADDING_H }]}>
              <TouchableOpacity
                style={styles.bookWashCard}
                onPress={() => { hapticFeedback('light'); router.push('/valeter/jobs'); }}
                activeOpacity={0.88}
              >
                <View style={styles.bookWashGlassFallback} />
                <BlurView
                  intensity={Platform.OS === 'ios' ? 48 : 72}
                  tint="dark"
                  style={StyleSheet.absoluteFill}
                  {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
                />
                <LinearGradient
                  colors={['rgba(14,165,233,0.75)', 'rgba(56,189,248,0.5)', 'rgba(202,224,80,0.75)']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={StyleSheet.absoluteFill}
                />
                <LinearGradient
                  colors={['rgba(255,255,255,0.14)', 'rgba(255,255,255,0.02)', 'transparent']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 0, y: 1 }}
                  style={StyleSheet.absoluteFill}
                  pointerEvents="none"
                />
                <View style={styles.bookWashCardContent}>
                  <GradientIconBox icon="car-sport" preset="sky" boxSize={38} size={20} style={styles.bookWashCardIconWrap} />
                  <View style={styles.bookWashCardTextWrap}>
                    <Text style={styles.bookWashCardTitle}>View Jobs</Text>
                    <Animated.Text style={[styles.bookWashCardSubtitle, { opacity: heroSubtextOpacity }]} numberOfLines={1}>
                      {activeJob ? 'Track your active job' : VALETER_HERO_SUBTEXTS[heroSubtextIndex]}
                    </Animated.Text>
                  </View>
                  <View style={styles.bookWashCardChevron}>
                    <Ionicons name={CONTINUE_CTA_ICON_NAME} size={16} color="rgba(255,255,255,0.6)" />
                  </View>
                </View>
              </TouchableOpacity>

              {/* Status + Today earnings — above quick actions */}
              <View style={[styles.belowQuickWrap, { marginTop: 12 }]}>
                <Pressable
                  onPress={loadingPresence || toggling ? undefined : toggleOnline}
                  style={[styles.statusEarningsCard, isOnline && styles.statusEarningsCardOnline]}
                  disabled={loadingPresence || toggling}
                >
                  <View
                    pointerEvents="none"
                    style={[
                      StyleSheet.absoluteFill,
                      { backgroundColor: isOnline ? 'rgba(16,185,129,0.12)' : 'rgba(15,23,42,0.52)' },
                    ]}
                  />
                  <BlurView
                    intensity={Platform.OS === 'ios' ? 40 : 64}
                    tint="dark"
                    style={StyleSheet.absoluteFill}
                    {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
                  />
                  <LinearGradient
                    colors={['rgba(255,255,255,0.1)', 'rgba(255,255,255,0.02)', 'transparent'] as [string, string, string]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 0, y: 1 }}
                    style={StyleSheet.absoluteFill}
                    pointerEvents="none"
                  />
                  <View style={styles.statusEarningsRow}>
                    <View style={styles.statusBlock}>
                      <Animated.View style={[styles.statusDot, { backgroundColor: isOnline ? '#10B981' : '#6B7280', transform: [{ scale: pulseAnim }] }]} />
                      <View style={styles.statusTextBlock}>
                        <Text style={styles.statusLabel}>
                          {loadingPresence || toggling ? 'Updating…' : isOnline ? "You're online" : "You're offline"}
                        </Text>
                        <Text style={styles.statusHint}>{isOnline ? 'Receiving jobs' : 'Tap to go online'}</Text>
                      </View>
                      {toggling ? (
                        <ActivityIndicator size="small" color="#94A3B8" />
                      ) : isOnline ? (
                        <LocationStyleIconBox variant="inline" icon="checkmark-circle" preset="green" />
                      ) : (
                        <LocationStyleIconBox variant="inline" icon="play-circle-outline" preset="gray" />
                      )}
                    </View>
                    <View style={styles.earningsBlock}>
                      <Text style={styles.earningsLabel}>Today's Earnings</Text>
                      <View style={styles.earningsValueRow}>
                        <Text style={[styles.earningsValue, { color: accent }]}>£{Number(todayStats.earnings || 0).toFixed(2)}</Text>
                        <Text style={styles.earningsSub}> • {todayStats.jobsCompleted} job{todayStats.jobsCompleted !== 1 ? 's' : ''}</Text>
                      </View>
                    </View>
                  </View>
                </Pressable>
              </View>

              {/* Daily stats — above quick actions */}
              <View style={[styles.belowQuickWrap, styles.dailyStatsWrap, { marginTop: 12 }]}>
                <View style={[styles.dailyStatsCard, { borderColor: `${accent}40`, shadowColor: accent }]}>
                  <View
                    pointerEvents="none"
                    style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(15,23,42,0.45)' }]}
                  />
                  <BlurView
                    intensity={Platform.OS === 'ios' ? 44 : 70}
                    tint={mode === 'light' ? 'light' : 'dark'}
                    style={StyleSheet.absoluteFill}
                    {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
                  />
                  <LinearGradient
                    colors={(theme?.headerBackground ?? HEADER_STYLE_CARD_GRADIENT) as [string, string]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 0, y: 1 }}
                    style={StyleSheet.absoluteFill}
                  />
                  <View style={[styles.dailyStatsGlow, { backgroundColor: accent }]} />
                  <LinearGradient
                    colors={['rgba(255,255,255,0.08)', 'transparent']}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 0, y: 0.45 }}
                    style={StyleSheet.absoluteFill}
                    pointerEvents="none"
                  />
                  <View style={styles.dailyStatsRow}>
                    <View style={styles.dailyStatItem}>
                      <View style={styles.dailyStatIconWrap}>
                        <LocationStyleIconBox icon="briefcase-outline" preset="sky" />
                      </View>
                      <Text style={[styles.dailyStatValue, { color: '#F9FAFB' }]}>{todayStats.jobsCompleted}</Text>
                      <Text style={[styles.dailyStatLabel, { color: accent }]}>Jobs today</Text>
                    </View>
                    <View style={[styles.dailyStatDivider, { backgroundColor: `${accent}30` }]} />
                    <View style={styles.dailyStatItem}>
                      <View style={styles.dailyStatIconWrap}>
                        <LocationStyleIconBox icon="wallet-outline" preset="green" />
                      </View>
                      <Text style={[styles.dailyStatValue, { color: accent }]}>£{Number(todayStats.earnings || 0).toFixed(2)}</Text>
                      <Text style={[styles.dailyStatLabel, { color: '#94A3B8' }]}>Earned today</Text>
                    </View>
                    <View style={[styles.dailyStatDivider, { backgroundColor: `${accent}30` }]} />
                    <View style={styles.dailyStatItem}>
                      <View style={styles.dailyStatIconWrap}>
                        <LocationStyleIconBox icon="calendar-outline" preset="cyan" />
                      </View>
                      <Text style={[styles.dailyStatValue, { color: '#F9FAFB' }]}>{upcomingJobs.length}</Text>
                      <Text style={[styles.dailyStatLabel, { color: '#94A3B8' }]}>Upcoming</Text>
                    </View>
                  </View>
                </View>
              </View>

              {/* Quick Actions — horizontal scroll */}
              <DashboardGlassSection palette="valeter" tone="frame" innerStyle={styles.valeterQuickActionsGlassInner}>
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.quickActionsScrollContent}
                style={styles.quickActionsScroll}
              >
                <Pressable onPress={() => { hapticFeedback('light'); router.push('/valeter/settings/working-hours'); }} style={styles.quickActionCardWrap}>
                  <Animated.View style={[styles.quickActionCard, { transform: [{ scale: quickScale0 }], borderColor: `${accent}50`, shadowColor: accent }]}>
                    <View style={[StyleSheet.absoluteFill, styles.quickActionGlassFallback]} />
                    <BlurView
                      intensity={Platform.OS === 'ios' ? 32 : 52}
                      tint="dark"
                      style={StyleSheet.absoluteFill}
                      {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
                    />
                    <LinearGradient
                      colors={['rgba(255,255,255,0.1)', 'transparent']}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 0, y: 1 }}
                      style={StyleSheet.absoluteFill}
                      pointerEvents="none"
                    />
                    <View style={styles.quickActionIconBox}>
                      <LocationStyleIconBox icon="calendar" preset="sky" />
                    </View>
                    <Text style={styles.quickActionItemLabel} numberOfLines={2}>Availability</Text>
                  </Animated.View>
                </Pressable>
                <Pressable onPress={() => { hapticFeedback('light'); router.push('/valeter/settings/distance-covering'); }} style={styles.quickActionCardWrap}>
                  <Animated.View style={[styles.quickActionCard, { transform: [{ scale: quickScale1 }], borderColor: `${accent}50`, shadowColor: accent }]}>
                    <View style={[StyleSheet.absoluteFill, styles.quickActionGlassFallback]} />
                    <BlurView
                      intensity={Platform.OS === 'ios' ? 32 : 52}
                      tint="dark"
                      style={StyleSheet.absoluteFill}
                      {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
                    />
                    <LinearGradient
                      colors={['rgba(255,255,255,0.1)', 'transparent']}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 0, y: 1 }}
                      style={StyleSheet.absoluteFill}
                      pointerEvents="none"
                    />
                    <View style={styles.quickActionIconBox}>
                      <LocationStyleIconBox icon="navigate" preset="green" />
                    </View>
                    <Text style={styles.quickActionItemLabel} numberOfLines={2}>Radius</Text>
                  </Animated.View>
                </Pressable>
                <Pressable onPress={() => { hapticFeedback('light'); router.push('/valeter/profile/valeter-vehicle-info'); }} style={styles.quickActionCardWrap}>
                  <Animated.View style={[styles.quickActionCard, { transform: [{ scale: quickScale2 }], borderColor: `${accent}50`, shadowColor: accent }]}>
                    <View style={[StyleSheet.absoluteFill, styles.quickActionGlassFallback]} />
                    <BlurView
                      intensity={Platform.OS === 'ios' ? 32 : 52}
                      tint="dark"
                      style={StyleSheet.absoluteFill}
                      {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
                    />
                    <LinearGradient
                      colors={['rgba(255,255,255,0.1)', 'transparent']}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 0, y: 1 }}
                      style={StyleSheet.absoluteFill}
                      pointerEvents="none"
                    />
                    <View style={styles.quickActionIconBox}>
                      <LocationStyleIconBox icon="car-sport" preset="amber" />
                    </View>
                    <Text style={styles.quickActionItemLabel} numberOfLines={2}>Vehicle</Text>
                  </Animated.View>
                </Pressable>
                <Pressable onPress={() => { hapticFeedback('light'); router.push('/valeter/profile/valeter-services'); }} style={styles.quickActionCardWrap}>
                  <Animated.View style={[styles.quickActionCard, { transform: [{ scale: quickScale3 }], borderColor: `${accent}50`, shadowColor: accent }]}>
                    <View style={[StyleSheet.absoluteFill, styles.quickActionGlassFallback]} />
                    <BlurView
                      intensity={Platform.OS === 'ios' ? 32 : 52}
                      tint="dark"
                      style={StyleSheet.absoluteFill}
                      {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
                    />
                    <LinearGradient
                      colors={['rgba(255,255,255,0.1)', 'transparent']}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 0, y: 1 }}
                      style={StyleSheet.absoluteFill}
                      pointerEvents="none"
                    />
                    <View style={styles.quickActionIconBox}>
                      <LocationStyleIconBox icon="pricetags-outline" preset="sky" />
                    </View>
                    <Text style={styles.quickActionItemLabel} numberOfLines={2}>Services</Text>
                  </Animated.View>
                </Pressable>
                <Pressable onPress={() => { hapticFeedback('light'); router.push('/valeter/valeter-wash-history'); }} style={styles.quickActionCardWrap}>
                  <Animated.View style={[styles.quickActionCard, { transform: [{ scale: quickScale4 }], borderColor: `${accent}50`, shadowColor: accent }]}>
                    <View style={[StyleSheet.absoluteFill, styles.quickActionGlassFallback]} />
                    <BlurView
                      intensity={Platform.OS === 'ios' ? 32 : 52}
                      tint="dark"
                      style={StyleSheet.absoluteFill}
                      {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
                    />
                    <LinearGradient
                      colors={['rgba(255,255,255,0.1)', 'transparent']}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 0, y: 1 }}
                      style={StyleSheet.absoluteFill}
                      pointerEvents="none"
                    />
                    <View style={styles.quickActionIconBox}>
                      <LocationStyleIconBox icon="time" preset="cyan" />
                    </View>
                    <Text style={styles.quickActionItemLabel} numberOfLines={2}>History</Text>
                  </Animated.View>
                </Pressable>
                <Pressable onPress={() => { hapticFeedback('light'); router.push('/valeter/dev-work'); }} style={styles.quickActionCardWrap}>
                  <Animated.View style={[styles.quickActionCard, { transform: [{ scale: quickScale5 }], borderColor: `${accent}50`, shadowColor: accent }]}>
                    <View style={[StyleSheet.absoluteFill, styles.quickActionGlassFallback]} />
                    <BlurView
                      intensity={Platform.OS === 'ios' ? 32 : 52}
                      tint="dark"
                      style={StyleSheet.absoluteFill}
                      {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
                    />
                    <LinearGradient
                      colors={['rgba(255,255,255,0.1)', 'transparent']}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 0, y: 1 }}
                      style={StyleSheet.absoluteFill}
                      pointerEvents="none"
                    />
                    <View style={styles.quickActionIconBox}>
                      <LocationStyleIconBox icon="clipboard-outline" preset="gray" />
                    </View>
                    <Text style={styles.quickActionItemLabel} numberOfLines={2}>Dev work</Text>
                  </Animated.View>
                </Pressable>
              </ScrollView>
              </DashboardGlassSection>
            </View>

            {/* Active Job — single hero card when present */}
            {activeJobLoading ? (
              <View style={styles.activeBookingSection}>
                <View style={styles.activeBookingLoadingWrap}>
                  <DefaultLoadingSkeleton message="Checking active job…" />
                </View>
              </View>
            ) : activeJob ? (
              <View style={styles.activeBookingSection}>
                <TouchableOpacity activeOpacity={0.92} onPress={handleResumeTracking} style={[styles.activeBookingCard, styles.activeBookingCardGlow]}>
                  <View style={styles.activeBookingMapContainer}>
                    {activeJobMapRegion ? (
                      <>
                        <MapView
                          style={StyleSheet.absoluteFill}
                          region={activeJobMapRegion}
                          scrollEnabled={false}
                          zoomEnabled={false}
                          pitchEnabled={false}
                          rotateEnabled={false}
                          showsUserLocation
                        >
                          {activeJob.location_lat != null && activeJob.location_lng != null && (
                            <Marker coordinate={{ latitude: activeJob.location_lat, longitude: activeJob.location_lng }}>
                              <View style={[styles.mapMarkerContainer, { backgroundColor: 'rgba(135,206,235,0.9)' }]}>
                                <Ionicons name="location" size={20} color="#0A1929" />
                              </View>
                            </Marker>
                          )}
                        </MapView>
                        <LinearGradient colors={['transparent', 'rgba(0,0,0,0.75)']} style={StyleSheet.absoluteFill} />
                      </>
                    ) : (
                      <LinearGradient colors={['rgba(135,206,235,0.24)', 'rgba(30,58,138,0.3)']} style={StyleSheet.absoluteFill} />
                    )}
                    <View style={styles.activeBookingCardOverlayWrap}>
                      <BlurView intensity={Platform.OS === 'ios' ? 48 : 72} tint="dark" style={StyleSheet.absoluteFill} />
                      <View style={styles.activeBookingCardOverlay}>
                        <View style={styles.activeBookingRingWrap}>
                          <AnimatedProgress progress={getStatusProgress(activeJob.status as any)} size={72} strokeWidth={8} showPercentage={true} color={getStatusRingColor(activeJob.status)} />
                        </View>
                        <View style={styles.activeBookingCardContent}>
                          <View style={styles.activeBookingLiveChip}>
                            <View style={styles.activeBookingLiveDot} />
                            <Text style={styles.activeBookingLiveText}>LIVE</Text>
                          </View>
                          <Text style={styles.activeBookingTitle}>Active job</Text>
                          <Text style={styles.activeBookingSubtitle} numberOfLines={1}>
                            {getServiceDisplayName(activeJob.service_type, activeJob.service_name)}
                          </Text>
                          <Text style={styles.activeBookingValeter} numberOfLines={1}>Customer: {customerNameActive}</Text>
                          <View style={styles.activeBookingStatusPill}>
                            <Text style={styles.activeBookingStatusText}>Track job</Text>
                            <Ionicons name={CONTINUE_CTA_ICON_NAME} size={14} color="#0A1929" />
                          </View>
                        </View>
                      </View>
                    </View>
                  </View>
                  <View style={styles.activeBookingBottomRow}>
                    <BlurView intensity={Platform.OS === 'ios' ? 64 : 88} tint="dark" style={StyleSheet.absoluteFill} />
                    <View style={styles.activeBookingBottomRowInner}>
                      <View style={styles.activeBookingPriceWrap}>
                        <LocationStyleIconBox variant="micro" icon="wallet-outline" preset="green" />
                        <Text style={styles.activeBookingPrice}>£{Number(activeJob.price || 0).toFixed(2)}</Text>
                      </View>
                      <View style={styles.activeBookingCta}>
                        <Text style={styles.activeBookingMetaCta}>Track job</Text>
                        <Ionicons name="chevron-forward" size={18} color={SKY} />
                      </View>
                    </View>
                  </View>
                </TouchableOpacity>
              </View>
            ) : null}

            {/* New job request — single premium card with live map background */}
            {firstJobRequest && (
              <View style={[styles.belowQuickWrap, { marginHorizontal: isSmallScreen ? 12 : SCREEN_PADDING_H }]}>
                <View style={[styles.requestCard, styles.requestCardWithMap]}>
                  {firstJobRequestMapRegion ? (
                    <>
                      <MapView
                        style={styles.requestCardMap}
                        region={firstJobRequestMapRegion}
                        scrollEnabled={false}
                        zoomEnabled={false}
                        pitchEnabled={false}
                        rotateEnabled={false}
                        customMapStyle={DARK_MAP_STYLE}
                      >
                        {coords?.latitude != null && coords?.longitude != null && (
                          <Marker coordinate={{ latitude: coords.latitude, longitude: coords.longitude }} title="You">
                            <View style={[styles.requestCardMapMarkerYou, { backgroundColor: accent }]}>
                              <Ionicons name="location" size={12} color="#fff" />
                            </View>
                          </Marker>
                        )}
                        <Marker coordinate={{ latitude: firstJobRequest.location_lat!, longitude: firstJobRequest.location_lng! }} title={firstJobRequest.serviceName}>
                          <View style={styles.requestCardMapMarkerJob}>
                            <Ionicons name="car" size={12} color="#fff" />
                          </View>
                        </Marker>
                      </MapView>
                      <LinearGradient
                        colors={['rgba(0,0,0,0.35)', 'rgba(0,0,0,0.7)', 'rgba(0,0,0,0.85)']}
                        style={StyleSheet.absoluteFill}
                        start={{ x: 0.5, y: 0 }}
                        end={{ x: 0.5, y: 1 }}
                      />
                      <BlurView
                        intensity={Platform.OS === 'ios' ? 28 : 48}
                        tint="dark"
                        style={[StyleSheet.absoluteFill, { opacity: 0.85 }]}
                        {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
                      />
                    </>
                  ) : null}
                  <View style={styles.requestCardContent}>
                    <View style={styles.requestCardBadge}>
                      <View style={styles.requestCardBadgeDot} />
                      <Text style={styles.requestCardBadgeText}>New request</Text>
                    </View>
                    <View style={styles.requestHeader}>
                      <View style={styles.requestTitleRow}>
                        <Text style={styles.requestTitle}>{firstJobRequest.serviceName}</Text>
                        {firstJobRequest.price >= 40 && (
                          <View style={styles.requestHighValueBadge}>
                            <Ionicons name="star" size={12} color="#FBBF24" />
                            <Text style={styles.requestHighValueText}>High value</Text>
                          </View>
                        )}
                      </View>
                      <View style={styles.requestTimer}>
                        <Ionicons name="time" size={12} color="#fff" />
                        <Text style={styles.requestTimerText}>{formatTime(firstJobRequest.timeRemaining)}</Text>
                      </View>
                    </View>
                    <Text style={styles.requestCustomer}>{firstJobRequest.customerName}</Text>
                    <Text style={styles.requestAddress} numberOfLines={2}>{firstJobRequest.address}</Text>
                    <View style={styles.requestMeta}>
                      <Text style={styles.requestPrice}>£{firstJobRequest.price}</Text>
                      {firstJobRequest.distance > 0 && (
                        <Text style={styles.requestDistance}>
                          {firstJobRequest.distance} mi{firstJobRequest.driveTimeMinutes != null ? ` · ~${firstJobRequest.driveTimeMinutes} min` : ''}
                        </Text>
                      )}
                      {jobRequests.length > 1 && <Text style={styles.requestMore}>+{jobRequests.length - 1} more</Text>}
                    </View>
                    <View style={styles.requestActions}>
                      <TouchableOpacity style={styles.acceptBtn} onPress={() => handleAcceptJob(firstJobRequest.id)} activeOpacity={0.8}>
                        <GradientIconBox
                          icon="checkmark"
                          borderless
                          boxSize={28}
                          size={16}
                          colors={['rgba(255,255,255,0.38)', 'rgba(255,255,255,0.14)']}
                        />
                        <Text style={styles.acceptBtnText}>Accept</Text>
                      </TouchableOpacity>
                      <TouchableOpacity style={styles.declineBtn} onPress={() => handleDeclineJob(firstJobRequest.id)} activeOpacity={0.8}>
                        <Text style={styles.declineBtnText}>Decline</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              </View>
            )}

            {/* Recent jobs — only when there is at least one upcoming or recent booking */}
            {(() => {
              const combined = [
                ...upcomingJobs.map((item: any) => ({ ...item, _type: 'upcoming' as const })),
                ...recentBookings
                  .filter((b: any) => !upcomingJobs.some((u: any) => u.id === b.id))
                  .filter((b: any) => !dismissedValeterRecentIds.has(b.id))
                  .slice(0, 3)
                  .map((item: any) => ({ ...item, _type: 'recent' as const })),
              ].slice(0, 8);
              if (combined.length === 0) return null;
              return (
            <View style={[styles.yourJobsSection, { marginHorizontal: isSmallScreen ? 12 : SCREEN_PADDING_H }]}>
              <DashboardGlassSection palette="valeter" tone="panel" innerStyle={styles.valeterJobsGlassInner}>
              <View style={styles.sectionRow}>
                <Text style={styles.sectionTitle}>Recent jobs</Text>
                <TouchableOpacity onPress={() => router.push('/valeter/jobs')}>
                  <Text style={[styles.seeAll, { color: accent }]}>See all</Text>
                </TouchableOpacity>
              </View>
                  <ScrollView
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    contentContainerStyle={styles.yourJobsScrollContent}
                  >
                    {combined.map((item: any) => (
                      <View
                        key={item.id}
                        style={[styles.jobCardHoriz, { borderColor: `${accent}50`, shadowColor: accent }]}
                      >
                        <Pressable
                          style={styles.jobCardHorizDismiss}
                          onPress={() => void handleDismissValeterRecentJob(item.id)}
                          hitSlop={10}
                          accessibilityLabel="Remove from recent jobs"
                        >
                          <Ionicons name="close-circle" size={22} color="rgba(248,113,113,0.92)" />
                        </Pressable>
                        <TouchableOpacity
                          onPress={() => {
                            hapticFeedback('light');
                            setSelectedYourJob(item);
                          }}
                          style={styles.jobCardHorizTouch}
                          activeOpacity={0.85}
                        >
                        <View style={styles.jobCardHorizIcon}>
                          {item.status === 'completed' ? (
                            <LocationStyleIconBox icon="checkmark-circle" preset="green" />
                          ) : (
                            <LocationStyleIconBox
                              icon={item._type === 'upcoming' ? 'car-sport-outline' : 'time-outline'}
                              preset="sky"
                            />
                          )}
                        </View>
                        <View style={styles.jobCardHorizCustomerRow}>
                          {item.customer_photo ? (
                            <Image source={{ uri: item.customer_photo }} style={styles.jobCardHorizAvatar} resizeMode="cover" />
                          ) : (
                            <View style={[styles.jobCardHorizAvatar, styles.jobCardHorizAvatarPlaceholder]}>
                              <Ionicons name="person" size={14} color="rgba(249,250,251,0.7)" />
                            </View>
                          )}
                          <Text style={styles.jobCardHorizCustomerName} numberOfLines={1}>
                            {item.customer_name || 'Customer'}
                          </Text>
                        </View>
                        <Text style={styles.jobCardHorizTitle} numberOfLines={1}>
                          {getServiceDisplayName(item.service_type, item.service_name) || item.service_name || 'Car Wash'}
                        </Text>
                        <Text style={styles.jobCardHorizSub} numberOfLines={1}>
                          {item._type === 'upcoming' && item.scheduled_at
                            ? new Date(item.scheduled_at).toLocaleString('en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })
                            : item.status === 'completed'
                            ? 'Completed'
                            : item.status === 'in_progress'
                            ? 'Active'
                            : 'Confirmed'}
                        </Text>
                        <Text style={styles.jobCardHorizPrice}>£{Number(item.price || 0).toFixed(2)}</Text>
                        </TouchableOpacity>
                      </View>
                    ))}
                  </ScrollView>
              </DashboardGlassSection>
            </View>
              );
            })()}
          </Animated.View>
        </Animated.ScrollView>
      </SafeAreaView>
      <Modal visible={showLocationPicker} transparent animationType="slide">
        <Pressable style={styles.locationPickerOverlay} onPress={() => setShowLocationPicker(false)}>
          <Pressable style={styles.locationPickerSheet} onPress={(e) => e.stopPropagation()}>
            <View style={styles.locationPickerHandle} />
            <Text style={styles.locationPickerTitle}>Location</Text>
            <Text style={styles.locationPickerSubtitle}>Choose how to set your location</Text>
            <TouchableOpacity
              style={styles.locationPickerOption}
              onPress={handleUseCurrentLocation}
              disabled={locationLoading}
              activeOpacity={0.8}
            >
              <View style={styles.locationPickerOptionIcon}>
                <Ionicons name="navigate" size={22} color={SKY} />
              </View>
              <View style={styles.locationPickerOptionText}>
                <Text style={styles.locationPickerOptionTitle}>Use current location</Text>
                <Text style={styles.locationPickerOptionSub}>GPS will update your position</Text>
              </View>
              {locationLoading ? <ActivityIndicator size="small" color={SKY} /> : <Ionicons name="chevron-forward" size={18} color="rgba(249,250,251,0.5)" />}
            </TouchableOpacity>
            <View style={styles.locationPickerDivider} />
            <Text style={styles.locationPickerSearchLabel}>Search for a place</Text>
            <View style={styles.locationPickerSearchRow}>
              <TextInput
                style={styles.locationPickerSearchInput}
                placeholder="Address or place name"
                placeholderTextColor="rgba(249,250,251,0.4)"
                value={locationSearchQuery}
                onChangeText={setLocationSearchQuery}
                onSubmitEditing={handleSearchLocation}
                returnKeyType="search"
              />
              <TouchableOpacity
                style={[styles.locationPickerSearchBtn, locationSearching && styles.locationPickerSearchBtnDisabled]}
                onPress={handleSearchLocation}
                disabled={locationSearching || !locationSearchQuery.trim()}
                activeOpacity={0.8}
              >
                {locationSearching ? <ActivityIndicator size="small" color="#0A1929" /> : <Ionicons name="search" size={20} color="#0A1929" />}
              </TouchableOpacity>
            </View>
            <TouchableOpacity style={styles.locationPickerCancel} onPress={() => setShowLocationPicker(false)} activeOpacity={0.8}>
              <Text style={styles.locationPickerCancelText}>Cancel</Text>
            </TouchableOpacity>
          </Pressable>
        </Pressable>
      </Modal>

      {/* Your job detail bottom sheet */}
      <Modal
        visible={!!selectedYourJob}
        transparent
        animationType="slide"
        onRequestClose={() => setSelectedYourJob(null)}
      >
        <View style={styles.yourJobSheetContainer}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setSelectedYourJob(null)}>
            <BlurView intensity={40} tint="dark" style={StyleSheet.absoluteFill} />
          </Pressable>
          <View style={[styles.yourJobSheet, { paddingBottom: Math.max(insets?.bottom ?? 0, 24) }]} pointerEvents="box-none">
            {selectedYourJob ? (
              <>
                <View style={styles.yourJobSheetHandle} />
                <View style={styles.yourJobSheetHeader}>
                  <Text style={styles.yourJobSheetTitle}>{getServiceDisplayName(selectedYourJob.service_type, selectedYourJob.service_name) || selectedYourJob.service_name || 'Job'}</Text>
                  <Text style={[styles.yourJobSheetSubtitle, { color: accent }]}>
                    {selectedYourJob._type === 'upcoming' ? 'Upcoming' : selectedYourJob.status === 'completed' ? 'Completed' : selectedYourJob.status === 'in_progress' ? 'Active' : 'Confirmed'}
                  </Text>
                </View>
                <View style={styles.yourJobSheetPhotoHero}>
                  {selectedYourJob.customer_photo ? (
                    <Image
                      source={{ uri: selectedYourJob.customer_photo }}
                      style={[styles.yourJobSheetPhotoHeroImg, { borderColor: `${accent}55` }]}
                      resizeMode="cover"
                    />
                  ) : (
                    <View
                      style={[
                        styles.yourJobSheetPhotoHeroImg,
                        styles.yourJobSheetPhotoHeroPlaceholder,
                        { borderColor: `${accent}40` },
                      ]}
                    >
                      <Ionicons name="person" size={40} color={accent} />
                    </View>
                  )}
                </View>
                <View style={styles.yourJobSheetCustomer}>
                  <View style={styles.yourJobSheetCustomerText}>
                    <Text style={styles.yourJobSheetCustomerLabel}>Customer</Text>
                    <Text style={styles.yourJobSheetCustomerName} numberOfLines={2}>
                      {selectedYourJob.customer_name || 'Customer'}
                    </Text>
                  </View>
                </View>
                <ScrollView style={styles.yourJobSheetScroll} showsVerticalScrollIndicator={false}>
                  {selectedYourJob.scheduled_at ? (
                    <View style={styles.yourJobSheetRow}>
                      <Ionicons name="calendar-outline" size={20} color={accent} />
                      <Text style={styles.yourJobSheetLabel}>Scheduled</Text>
                      <Text style={styles.yourJobSheetValue}>
                        {new Date(selectedYourJob.scheduled_at).toLocaleString('en-GB', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </Text>
                    </View>
                  ) : null}
                  {selectedYourJob.location_address ? (
                    <View style={styles.yourJobSheetRow}>
                      <Ionicons name="location-outline" size={20} color={accent} />
                      <Text style={styles.yourJobSheetLabel}>Address</Text>
                      <Text style={styles.yourJobSheetValue}>{selectedYourJob.location_address}</Text>
                    </View>
                  ) : null}
                  <View style={styles.yourJobSheetRow}>
                    <LocationStyleIconBox variant="inline" icon="wallet-outline" colors={accentToGradient(accent)} />
                    <Text style={styles.yourJobSheetLabel}>Price</Text>
                    <Text style={[styles.yourJobSheetValue, styles.yourJobSheetPrice, { color: accent }]}>
                      £{Number(selectedYourJob.price || 0).toFixed(2)}
                    </Text>
                  </View>
                </ScrollView>
                <View style={styles.yourJobSheetActions}>
                  <TouchableOpacity
                    style={[styles.yourJobSheetCloseBtn, { borderColor: `${accent}50` }]}
                    onPress={() => {
                      hapticFeedback('light');
                      setSelectedYourJob(null);
                    }}
                    activeOpacity={0.85}
                  >
                    <Text style={[styles.yourJobSheetCloseBtnText, { color: accent }]}>Close</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[styles.yourJobSheetViewBtn, { backgroundColor: accent }]}
                    onPress={() => {
                      hapticFeedback('light');
                      setSelectedYourJob(null);
                      router.push({ pathname: '/valeter/jobs/tracking', params: { jobId: selectedYourJob.id } } as any);
                    }}
                    activeOpacity={0.85}
                  >
                    <Ionicons name="navigate" size={18} color="#fff" />
                    <Text style={styles.yourJobSheetViewBtnText}>View trip</Text>
                  </TouchableOpacity>
                </View>
              </>
            ) : null}
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },

  /* Uber-style: minimal top bar */
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SCREEN_PADDING_H,
    paddingBottom: 12,
  },
  avatarWrap: { marginRight: 12 },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.1)',
  },
  topBarCenter: { flex: 1, minWidth: 0 },
  topBarTitle: {
    fontSize: 18,
    fontWeight: '700',
    letterSpacing: -0.3,
  },
  topBarLocationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 4,
    gap: 8,
    minHeight: 22,
  },
  locationPickerTouchable: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    minWidth: 0,
  },
  topBarSub: {
    fontSize: 13,
    marginTop: 2,
  },
  onlinePill: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    backgroundColor: 'rgba(107,114,128,0.35)',
    gap: 5,
  },
  onlinePillOn: {
    backgroundColor: 'rgba(16,185,129,0.35)',
  },
  onlinePillDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#9CA3AF',
  },
  onlinePillDotOn: {
    backgroundColor: '#10B981',
  },
  onlinePillText: {
    fontSize: 11,
    fontWeight: '700',
    color: 'rgba(249,250,251,0.7)',
  },
  onlinePillTextOn: {
    color: '#6EE7B7',
  },
  bellWrap: { padding: 4 },

  scrollView: { flex: 1 },
  scrollContent: {},

  heroCardWrap: { marginBottom: CARD_GAP },
  /* Below quick actions — new unified UI */
  belowQuickWrap: { marginBottom: 16 },
  dailyStatsWrap: { marginBottom: 14 },
  dailyStatsCard: {
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.12,
    shadowRadius: 8,
    elevation: 3,
  },
  dailyStatsGlow: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 1.5,
    zIndex: 2,
    opacity: 0.6,
  },
  dailyStatsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    paddingVertical: 14,
    paddingHorizontal: 12,
    zIndex: 2,
  },
  dailyStatItem: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  dailyStatIconWrap: {
    width: 42,
    height: 42,
    borderRadius: 14,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 6,
  },
  dailyStatValue: {
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 2,
  },
  dailyStatLabel: {
    fontSize: 11,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 0.3,
  },
  dailyStatDivider: {
    width: 1,
    height: 32,
    borderRadius: 1,
  },
  statusEarningsCard: {
    borderRadius: 14,
    overflow: 'hidden',
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.2)',
    position: 'relative',
  },
  statusEarningsCardOnline: {
    borderColor: 'rgba(16,185,129,0.4)',
  },
  statusEarningsRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  statusBlock: { flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1, minWidth: 0 },
  statusDot: { width: 8, height: 8, borderRadius: 4 },
  statusTextBlock: { flex: 1, minWidth: 0 },
  statusLabel: { color: '#F9FAFB', fontSize: 14, fontWeight: '700', marginBottom: 0 },
  statusHint: { color: 'rgba(249,250,251,0.6)', fontSize: 11, fontWeight: '500' },
  earningsBlock: { alignItems: 'flex-end' },
  earningsLabel: { color: 'rgba(249,250,251,0.6)', fontSize: 10, fontWeight: '600', marginBottom: 1, textTransform: 'uppercase', letterSpacing: 0.5 },
  earningsValueRow: { flexDirection: 'row', alignItems: 'baseline', gap: 2 },
  earningsValue: { fontSize: 15, fontWeight: '800' },
  earningsSub: { color: 'rgba(249,250,251,0.7)', fontSize: 11, fontWeight: '600' },
  requestCardBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    gap: 6,
    marginBottom: 10,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 10,
    backgroundColor: 'rgba(239,68,68,0.2)',
  },
  requestCardBadgeDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#EF4444' },
  requestCardBadgeText: { color: '#FCA5A5', fontSize: 12, fontWeight: '700' },
  mapPreviewCard: {
    borderRadius: 22,
    overflow: 'hidden',
    borderWidth: 1.5,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.22,
    shadowRadius: 14,
    elevation: 5,
  },
  mapPreviewGlowLine: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 2,
    zIndex: 2,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 8,
    elevation: 2,
  },
  mapPreviewInner: { zIndex: 2 },
  mapPreviewHeader: {
    paddingHorizontal: 18,
    paddingTop: 16,
    paddingBottom: 12,
  },
  mapPreviewHeaderBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 12,
    borderWidth: 1,
  },
  mapPreviewTitle: { fontSize: 15, fontWeight: '800', letterSpacing: 0.3 },
  mapPreviewMapWrap: {
    height: 200,
    marginHorizontal: 14,
    marginBottom: 14,
    borderRadius: 14,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  mapPreviewMap: { width: '100%', height: '100%' },
  mapPreviewMapVignette: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    pointerEvents: 'none',
  },
  mapPreviewMarkerYou: {
    width: 34,
    height: 34,
    borderRadius: 17,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.35,
    shadowRadius: 4,
    elevation: 4,
  },
  mapPreviewMarkerJob: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: 'rgba(245,158,11,0.95)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2.5,
    borderColor: 'rgba(255,255,255,0.9)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 3,
    elevation: 3,
  },
  mapPreviewSummary: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 14,
    paddingHorizontal: 18,
    paddingTop: 14,
    paddingBottom: 16,
    borderTopWidth: 1,
  },
  mapPreviewSummaryText: {
    color: 'rgba(249,250,251,0.9)',
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  mapPreviewSummaryAccent: {
    fontWeight: '800',
  },
  yourJobsSection: { marginTop: SECTION_GAP - 8, marginBottom: 28 },
  yourJobsScrollContent: {
    paddingRight: SCREEN_PADDING_H,
    gap: 8,
    paddingVertical: 4,
    lineHeight: 14,
  },
  jobCardHoriz: {
    width: 136,
    paddingVertical: 10,
    paddingHorizontal: 10,
    borderTopLeftRadius: 18,
    borderTopRightRadius: 8,
    borderBottomRightRadius: 18,
    borderBottomLeftRadius: 8,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1.5,
    overflow: 'visible',
    position: 'relative',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 3,
  },
  jobCardHorizTouch: {
    width: '100%',
  },
  jobCardHorizDismiss: {
    position: 'absolute',
    top: 0,
    right: 0,
    zIndex: 6,
    padding: 2,
  },
  jobCardHorizIcon: {
    width: 36,
    height: 36,
    borderRadius: 12,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 6,
  },
  jobCardHorizCustomerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 6,
    minWidth: 0,
  },
  jobCardHorizAvatar: {
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  jobCardHorizAvatarPlaceholder: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  jobCardHorizCustomerName: {
    flex: 1,
    color: 'rgba(249,250,251,0.92)',
    fontSize: 11,
    fontWeight: '700',
    minWidth: 0,
  },
  jobCardHorizTitle: { color: '#F9FAFB', fontSize: 13, fontWeight: '700', marginBottom: 2 },
  jobCardHorizSub: { color: 'rgba(249,250,251,0.65)', fontSize: 11, marginBottom: 4 },
  jobCardHorizPrice: { color: SKY, fontSize: 14, fontWeight: '800' },
  jobRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 14,
    marginBottom: 8,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 14,
    gap: 12,
  },
  jobRowIcon: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  jobRowIconDone: { backgroundColor: 'rgba(16,185,129,0.2)' },
  jobRowBody: { flex: 1, minWidth: 0 },
  jobRowTitle: { color: '#F9FAFB', fontSize: 15, fontWeight: '600', marginBottom: 2 },
  jobRowSub: { color: 'rgba(249,250,251,0.6)', fontSize: 13 },
  jobRowPrice: { color: '#F9FAFB', fontSize: 15, fontWeight: '700' },
  /* Hero: one primary CTA */
  heroCard: {},
  heroInner: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 0,
    gap: 14,
  },
  heroInnerOnline: {
    backgroundColor: '#059669',
  },
  heroInnerOffline: {
    backgroundColor: '#374151',
  },
  heroDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  heroTextBlock: { flex: 1, minWidth: 0 },
  heroTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 2,
  },
  heroSub: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 14,
    fontWeight: '500',
  },

  /* Single job request card — premium floating style */
  requestCard: {
    marginBottom: CARD_GAP,
    padding: 18,
    borderRadius: 22,
    backgroundColor: 'rgba(59,130,246,0.18)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 20,
    elevation: 6,
  },
  requestCardWithMap: {
    overflow: 'hidden',
    position: 'relative',
    padding: 0,
  },
  requestCardMap: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
  },
  requestCardMapMarkerYou: {
    width: 24,
    height: 24,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#fff',
  },
  requestCardMapMarkerJob: {
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: 'rgba(245,158,11,0.95)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.9)',
  },
  requestCardContent: {
    padding: 18,
    zIndex: 2,
  },
  requestHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  requestTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flex: 1,
    minWidth: 0,
  },
  requestTitle: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '700',
  },
  requestTimer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    backgroundColor: 'rgba(239,68,68,0.8)',
  },
  requestTimerText: { color: '#fff', fontSize: 12, fontWeight: '700' },
  requestHighValueBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 8,
    backgroundColor: 'rgba(251,191,36,0.25)',
    borderWidth: 1,
    borderColor: 'rgba(251,191,36,0.5)',
  },
  requestHighValueText: { color: '#FBBF24', fontSize: 11, fontWeight: '700' },
  requestCustomer: {
    color: 'rgba(249,250,251,0.9)',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
  },
  requestAddress: {
    color: 'rgba(249,250,251,0.75)',
    fontSize: 13,
    marginBottom: 12,
    lineHeight: 18,
  },
  requestMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 14,
  },
  requestPrice: {
    color: '#FCD34D',
    fontSize: 18,
    fontWeight: '800',
  },
  requestDistance: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
    fontWeight: '600',
  },
  requestMore: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 13,
    fontWeight: '600',
  },
  requestActions: {
    flexDirection: 'row',
    gap: 10,
  },
  acceptBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    borderRadius: 12,
    backgroundColor: '#10B981',
  },
  acceptBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  declineBtn: {
    paddingVertical: 14,
    paddingHorizontal: 20,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.5)',
    justifyContent: 'center',
  },
  declineBtnText: { color: '#EF4444', fontSize: 15, fontWeight: '700' },

  /* Section + list */
  section: { marginBottom: 28 },
  sectionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '700',
  },
  seeAll: { fontSize: 14, fontWeight: '600' },
  listRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 14,
    marginBottom: 6,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 12,
    gap: 12,
  },
  listRowIcon: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  listRowIconDone: { backgroundColor: 'rgba(16,185,129,0.2)' },
  listRowBody: { flex: 1, minWidth: 0 },
  listRowTitle: { color: '#F9FAFB', fontSize: 15, fontWeight: '600', marginBottom: 2 },
  listRowSub: { color: 'rgba(249,250,251,0.6)', fontSize: 13 },
  listRowPrice: { color: '#F9FAFB', fontSize: 15, fontWeight: '700' },
  emptyBlock: {
    alignItems: 'center',
    paddingVertical: 24,
    paddingHorizontal: 20,
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderRadius: 12,
    gap: 8,
  },
  emptyText: { color: 'rgba(249,250,251,0.6)', fontSize: 14 },
  emptyLink: { fontSize: 14, fontWeight: '700' },

  /* Quick links row */
  quickRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8,
    marginBottom: 16,
  },
  quickItem: {
    alignItems: 'center',
    minWidth: 72,
  },
  quickIconWrap: {
    width: 48,
    height: 48,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  quickLabel: {
    color: 'rgba(249,250,251,0.85)',
    fontSize: 12,
    fontWeight: '600',
  },

  /* Customer-style hero + quick actions */
  bookingButtonsSection: {
    marginBottom: 22,
  },
  bookWashGlassFallback: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(14,165,233,0.35)',
  },
  bookWashCard: {
    borderRadius: 22,
    overflow: 'hidden',
    marginBottom: 14,
    position: 'relative',
    borderWidth: StyleSheet.hairlineWidth * 2,
    borderColor: 'rgba(255,255,255,0.16)',
  },
  bookWashCardContent: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 18,
    gap: 14,
  },
  bookWashCardIconWrap: {},
  bookWashCardTextWrap: { flex: 1, minWidth: 0 },
  bookWashCardTitle: {
    color: '#F8FAFC',
    fontSize: 17,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  bookWashCardSubtitle: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 12,
    fontWeight: '500',
    marginTop: 2,
  },
  bookWashCardChevron: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.04)',
  },
  valeterJobsGlassInner: {
    paddingTop: 12,
    paddingBottom: 14,
    paddingHorizontal: 12,
  },
  valeterQuickActionsGlassInner: {
    paddingVertical: 10,
    paddingHorizontal: 8,
  },
  quickActionGlassFallback: {
    backgroundColor: 'rgba(15,23,42,0.4)',
  },
  quickActionsScroll: { marginBottom: 4 },
  quickActionsScrollContent: {
    flexDirection: 'row',
    gap: 12,
    paddingHorizontal: 0,
    paddingRight: SCREEN_PADDING_H,
    alignItems: 'center',
  },
  quickActionCardWrap: { alignSelf: 'stretch' },
  quickActionCard: {
    alignItems: 'center',
    justifyContent: 'flex-start',
    gap: 6,
    width: 92,
    minWidth: 92,
    paddingVertical: 12,
    paddingHorizontal: 8,
    borderRadius: 18,
    backgroundColor: 'transparent',
    borderWidth: 1.5,
    overflow: 'hidden',
    position: 'relative',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 3,
  },
  quickActionIconBox: {
    width: 42,
    height: 42,
    borderRadius: 14,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
  },
  quickActionItemLabel: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 0.2,
    textAlign: 'center',
    paddingHorizontal: 2,
    minWidth: 76,
  },

  /* Active Job — same as customer ActiveBookingSection */
  activeBookingSection: {
    marginHorizontal: 20,
    marginBottom: 22,
  },
  activeBookingLoadingWrap: {
    borderRadius: 22,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    backgroundColor: 'rgba(255,255,255,0.03)',
    padding: 0,
    minHeight: 220,
    alignItems: 'stretch',
  },
  activeBookingCard: {
    borderRadius: 22,
    overflow: 'hidden',
    backgroundColor: 'rgba(10,25,41,0.65)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.22)',
    shadowColor: '#0A1929',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 16,
    elevation: 8,
  },
  activeBookingCardGlow: {
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.12,
    shadowRadius: 14,
  },
  activeBookingMapContainer: {
    height: 208,
    borderRadius: 0,
    overflow: 'hidden',
    position: 'relative',
  },
  activeBookingCardOverlayWrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    overflow: 'hidden',
  },
  activeBookingCardOverlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingBottom: 58,
    gap: 16,
  },
  activeBookingRingWrap: {
    width: 80,
    height: 80,
    alignItems: 'center',
    justifyContent: 'center',
  },
  activeBookingCardContent: { flex: 1, minWidth: 0 },
  activeBookingLiveChip: {
    alignSelf: 'flex-start',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 9,
    paddingVertical: 4,
    borderRadius: 8,
    marginBottom: 6,
    backgroundColor: 'rgba(16,185,129,0.28)',
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.45)',
  },
  activeBookingLiveDot: {
    width: 5,
    height: 5,
    borderRadius: 3,
    backgroundColor: '#10B981',
  },
  activeBookingLiveText: {
    color: 'rgba(255,255,255,0.98)',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 0.8,
  },
  activeBookingTitle: {
    color: 'rgba(255,255,255,0.98)',
    fontSize: 17,
    fontWeight: '800',
    letterSpacing: 0.35,
    marginBottom: 2,
  },
  activeBookingSubtitle: {
    color: 'rgba(255,255,255,0.88)',
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 0.1,
  },
  activeBookingValeter: {
    color: 'rgba(255,255,255,0.72)',
    fontSize: 12,
    fontWeight: '600',
    marginTop: 5,
    letterSpacing: 0.05,
  },
  activeBookingStatusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 13,
    paddingVertical: 8,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.98)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.4)',
    marginTop: 8,
  },
  activeBookingStatusText: {
    color: '#0A1929',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  activeBookingBottomRow: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 18,
    paddingVertical: 14,
    paddingBottom: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.06)',
    overflow: 'hidden',
  },
  activeBookingBottomRowInner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
  },
  activeBookingPriceWrap: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  activeBookingPrice: {
    color: 'rgba(255,255,255,0.95)',
    fontSize: 15,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  activeBookingCta: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  activeBookingMetaCta: {
    color: SKY,
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.15,
  },
  mapMarkerContainer: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  locationPickerOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  locationPickerSheet: {
    backgroundColor: '#0A1929',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingHorizontal: 20,
    paddingTop: 12,
    paddingBottom: 34,
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  locationPickerHandle: {
    width: 36,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(249,250,251,0.3)',
    alignSelf: 'center',
    marginBottom: 20,
  },
  locationPickerTitle: { fontSize: 20, fontWeight: '800', color: '#F9FAFB', marginBottom: 4 },
  locationPickerSubtitle: { fontSize: 13, color: 'rgba(249,250,251,0.6)', marginBottom: 20 },
  locationPickerOption: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    marginBottom: 16,
  },
  locationPickerOptionIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 14,
  },
  locationPickerOptionText: { flex: 1, minWidth: 0 },
  locationPickerOptionTitle: { fontSize: 16, fontWeight: '700', color: '#F9FAFB', marginBottom: 2 },
  locationPickerOptionSub: { fontSize: 12, color: 'rgba(249,250,251,0.6)' },
  locationPickerDivider: { height: 1, backgroundColor: 'rgba(255,255,255,0.08)', marginVertical: 16 },
  locationPickerSearchLabel: { fontSize: 14, fontWeight: '600', color: 'rgba(249,250,251,0.8)', marginBottom: 10 },
  locationPickerSearchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 20,
  },
  locationPickerSearchInput: {
    flex: 1,
    height: 48,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    paddingHorizontal: 16,
    fontSize: 16,
    color: '#F9FAFB',
  },
  locationPickerSearchBtn: {
    width: 48,
    height: 48,
    borderRadius: 14,
    backgroundColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
  },
  locationPickerSearchBtnDisabled: { opacity: 0.6 },
  locationPickerCancel: {
    paddingVertical: 14,
    alignItems: 'center',
  },
  locationPickerCancelText: { fontSize: 16, fontWeight: '600', color: SKY },

  yourJobSheetContainer: { flex: 1, justifyContent: 'flex-end' },
  yourJobSheet: {
    backgroundColor: '#0F2847',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingHorizontal: 24,
    paddingTop: 12,
    maxHeight: '85%',
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  yourJobSheetHandle: {
    width: 40,
    height: 5,
    backgroundColor: 'rgba(255,255,255,0.25)',
    borderRadius: 3,
    alignSelf: 'center',
    marginBottom: 20,
  },
  yourJobSheetHeader: { marginBottom: 12 },
  yourJobSheetPhotoHero: { alignItems: 'center', marginBottom: 14 },
  yourJobSheetPhotoHeroImg: {
    width: 96,
    height: 96,
    borderRadius: 48,
    borderWidth: 2,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  yourJobSheetPhotoHeroPlaceholder: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  yourJobSheetTitle: { color: '#F9FAFB', fontSize: 20, fontWeight: '800', marginBottom: 4 },
  yourJobSheetSubtitle: { fontSize: 14, fontWeight: '600' },
  yourJobSheetCustomer: {
    marginBottom: 18,
    paddingVertical: 12,
    paddingHorizontal: 14,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 16,
  },
  yourJobSheetCustomerText: { flex: 1, minWidth: 0 },
  yourJobSheetCustomerLabel: { color: '#94A3B8', fontSize: 12, fontWeight: '600', marginBottom: 4 },
  yourJobSheetCustomerName: { color: '#F9FAFB', fontSize: 17, fontWeight: '700' },
  yourJobSheetScroll: { maxHeight: 280, marginBottom: 16 },
  yourJobSheetRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 14,
  },
  yourJobSheetLabel: { color: '#94A3B8', fontSize: 14, fontWeight: '600', minWidth: 90 },
  yourJobSheetValue: { flex: 1, color: '#F9FAFB', fontSize: 15, fontWeight: '600' },
  yourJobSheetPrice: { fontSize: 18, fontWeight: '800' },
  yourJobSheetActions: { flexDirection: 'row', gap: 12 },
  yourJobSheetCloseBtn: {
    flex: 1,
    paddingVertical: 16,
    borderRadius: 14,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  yourJobSheetCloseBtnText: { fontSize: 16, fontWeight: '700' },
  yourJobSheetViewBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    borderRadius: 14,
  },
  yourJobSheetViewBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});
