import React, { useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet, Animated, Easing, Platform } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { colors } from '../../constants/colors';

const SKY = colors.SKY ?? '#38BDF8';

/** Progress-band tiers when no explicit `tierPalette` is provided (legacy gamified look). */
const TIERS = [
  { max: 25, fill: '#F59E0B', glow: '#FCD34D' },
  { max: 50, fill: '#8B5CF6', glow: '#A78BFA' },
  { max: 75, fill: '#0EA5E9', glow: '#38BDF8' },
  { max: 100, fill: '#10B981', glow: '#34D399' },
];

function getTier(p: number) {
  for (const t of TIERS) if (p <= t.max) return t;
  return TIERS[TIERS.length - 1];
}

const RAINBOW_SPIN: [string, string, string, string] = ['#22D3EE', '#A78BFA', '#34D399', '#22D3EE'];

function hexWithAlpha(hex: string, alphaHex: string): string {
  const t = hex.trim();
  if (/^#[0-9A-F]{6}$/i.test(t)) return `${t}${alphaHex}`;
  if (/^#[0-9A-F]{8}$/i.test(t)) return t;
  return t;
}

export type TierPalette = { fill: string; glow: string };

export interface AnimatedProgressProps {
  progress: number;
  size?: number;
  strokeWidth?: number;
  showPercentage?: boolean;
  color?: string;
  gamified?: boolean;
  futuristic?: boolean;
  /** Subtle scale pulse on the ring (dashboard job cards). */
  ringPulse?: boolean;
  /**
   * When `gamified`, use these colors for the arc and glow instead of inferring from `progress`.
   * Use for account tier / weekly vehicle rings so the ring matches the user’s level, not a random band.
   */
  tierPalette?: TierPalette;
  /**
   * Colours for the spinning chrome. With `sequentialSpin`, only one hue leads at a time (less busy).
   * Without `sequentialSpin`, used as a rotating multi-stop gradient (or falls back to rainbow if unset).
   */
  spinPalette?: string[];
  /** Advance `spinPalette` one colour every ~4s instead of showing all hues at once. */
  sequentialSpin?: boolean;
  /** Frosted glass centre (metrics rings). */
  glassCenter?: boolean;
}

export default function AnimatedProgress({
  progress,
  size = 120,
  strokeWidth = 8,
  showPercentage = true,
  color = SKY,
  gamified = false,
  futuristic = false,
  ringPulse = false,
  tierPalette,
  spinPalette,
  sequentialSpin = false,
  glassCenter = false,
}: AnimatedProgressProps) {
  const value = useRef(new Animated.Value(0)).current;
  const [display, setDisplay] = useState(0);
  const rotation = useRef(new Animated.Value(0)).current;
  const ringScale = useRef(new Animated.Value(1)).current;
  const [spinIdx, setSpinIdx] = useState(0);
  const stroke = Math.max(strokeWidth, 4);
  const inner = size - stroke * 2;
  const center = size - stroke * 4;
  const isFuturistic = futuristic && gamified;
  const tier = getTier(progress);
  const fillColor = gamified ? (tierPalette?.fill ?? tier.fill) : color;
  const glowColor = gamified ? (tierPalette?.glow ?? tier.glow) : color;

  useEffect(() => {
    Animated.spring(value, {
      toValue: progress,
      useNativeDriver: false,
      tension: 60,
      friction: 8,
    }).start();
    const sub = value.addListener(({ value: v }) => setDisplay(Math.round(v)));
    return () => {
      value.removeListener(sub);
    };
  }, [progress, value]);

  useEffect(() => {
    if (!gamified && !futuristic) return;
    const loop = Animated.loop(
      Animated.timing(rotation, {
        toValue: 1,
        duration: isFuturistic ? 7200 : 5200,
        easing: Easing.linear,
        useNativeDriver: true,
      })
    );
    loop.start();
    return () => loop.stop();
  }, [gamified, futuristic, isFuturistic, rotation]);

  useEffect(() => {
    if (!sequentialSpin || !spinPalette?.length) return;
    const id = setInterval(() => {
      setSpinIdx((i) => (i + 1) % spinPalette.length);
    }, 4200);
    return () => clearInterval(id);
  }, [sequentialSpin, spinPalette]);

  useEffect(() => {
    if (!ringPulse) return;
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(ringScale, {
          toValue: 1.045,
          duration: 1400,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
        Animated.timing(ringScale, {
          toValue: 1,
          duration: 1400,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [ringPulse, ringScale]);

  const rotate = rotation.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '360deg'],
  });

  const fillWidth = value.interpolate({
    inputRange: [0, 100],
    outputRange: ['0%', '100%'],
  });

  const compact = size <= 72;

  const activeSpin =
    spinPalette && spinPalette.length > 0
      ? spinPalette[spinIdx % spinPalette.length]
      : fillColor;

  const futuristicGradientColors: [string, string, string, string] = (() => {
    if (!spinPalette?.length) {
      return RAINBOW_SPIN;
    }
    if (sequentialSpin) {
      const c = activeSpin;
      return [
        hexWithAlpha(c, 'FF'),
        hexWithAlpha(c, 'CC'),
        hexWithAlpha(c, '55'),
        hexWithAlpha(c, 'EE'),
      ];
    }
    const n = spinPalette.length;
    if (n >= 4) {
      return [spinPalette[0], spinPalette[1], spinPalette[2], spinPalette[3 % n]];
    }
    if (n === 3) {
      return [spinPalette[0], spinPalette[1], spinPalette[2], spinPalette[0]];
    }
    if (n === 2) {
      return [spinPalette[0], spinPalette[1], spinPalette[0], spinPalette[1]];
    }
    return [spinPalette[0], spinPalette[0], hexWithAlpha(spinPalette[0], '88'), spinPalette[0]];
  })();

  const gamifiedSweepColors: [string, string, string, string] = (() => {
    if (sequentialSpin && spinPalette?.length) {
      const c = activeSpin;
      return [hexWithAlpha(c, 'E6'), hexWithAlpha(c, '99'), 'transparent', 'transparent'];
    }
    return [`${glowColor}E6`, `${fillColor}99`, 'transparent', 'transparent'];
  })();

  const centerBg = glassCenter ? 'rgba(15,23,42,0.35)' : 'rgba(10,18,32,0.8)';
  const trackBorderColor = isFuturistic
    ? 'rgba(189,200,216,0.34)'
    : gamified
      ? 'rgba(201,214,232,0.3)'
      : 'rgba(173,191,214,0.26)';
  const trackFillColor = glassCenter ? 'rgba(13,22,39,0.22)' : 'rgba(13,22,39,0.3)';

  return (
    <Animated.View style={[s.root, { width: size, height: size, transform: ringPulse ? [{ scale: ringScale }] : [] }]}>
      <View
        style={[
          s.track,
          {
            width: size,
            height: size,
            borderRadius: size / 2,
            borderWidth: stroke,
            borderColor: trackBorderColor,
            backgroundColor: trackFillColor,
          },
        ]}
      />
      <LinearGradient
        colors={['rgba(248,250,252,0.34)', 'rgba(148,163,184,0.08)', 'rgba(2,6,23,0.06)']}
        start={{ x: 0.15, y: 0 }}
        end={{ x: 0.85, y: 1 }}
        style={[
          s.trackChromeOverlay,
          {
            width: size,
            height: size,
            borderRadius: size / 2,
          },
        ]}
        pointerEvents="none"
      />
      <View
        style={[
          s.trackSpecular,
          {
            width: size * 0.52,
            height: Math.max(10, stroke + 6),
            borderRadius: 999,
            top: stroke * 0.55,
          },
        ]}
        pointerEvents="none"
      />

      {isFuturistic && (
        <Animated.View
          style={[s.shimmerWrap, { width: size, height: size, transform: [{ rotate }] }]}
          pointerEvents="none"
        >
          <LinearGradient
            colors={futuristicGradientColors}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={[s.shimmer, { width: size, height: size, borderRadius: size / 2 }]}
          />
          <View
            style={[
              s.shimmerHole,
              {
                width: inner,
                height: inner,
                borderRadius: inner / 2,
                left: stroke,
                top: stroke,
                backgroundColor: glassCenter ? 'rgba(15,23,42,0.72)' : 'rgba(0,0,0,0.85)',
              },
            ]}
          />
        </Animated.View>
      )}

      {gamified && !isFuturistic && (
        <Animated.View
          style={[s.shimmerWrap, { width: size, height: size, transform: [{ rotate }] }]}
          pointerEvents="none"
        >
          <LinearGradient
            colors={gamifiedSweepColors}
            start={{ x: 0.5, y: 0 }}
            end={{ x: 0.5, y: 1 }}
            style={[s.shimmer, { width: size, height: size, borderRadius: size / 2 }]}
          />
          <View
            style={[
              s.shimmerHole,
              {
                width: inner,
                height: inner,
                borderRadius: inner / 2,
                left: stroke,
                top: stroke,
                backgroundColor: glassCenter ? 'rgba(15,23,42,0.78)' : 'rgba(15,23,42,0.95)',
              },
            ]}
          />
        </Animated.View>
      )}

      <View
        style={[
          s.fillClip,
          {
            width: size,
            height: size,
            borderRadius: size / 2,
            borderWidth: stroke,
            borderColor: 'transparent',
          },
        ]}
      >
        <Animated.View style={[s.fill, { width: fillWidth, height: '100%', borderRadius: size / 2 }]}>
          {gamified ? (
            <LinearGradient
              colors={[`${glowColor}DD`, `${fillColor}CC`, `${glowColor}99`]}
              start={{ x: 0, y: 0.5 }}
              end={{ x: 1, y: 0.5 }}
              style={StyleSheet.absoluteFill}
            />
          ) : (
            <View style={[StyleSheet.absoluteFill, { backgroundColor: color, opacity: 0.85 }]} />
          )}
        </Animated.View>
      </View>

      <View
        style={[
          s.center,
          {
            width: center,
            height: center,
            borderRadius: center / 2,
            backgroundColor: centerBg,
            borderWidth: glassCenter ? 1 : 0,
            borderColor: glassCenter ? 'rgba(125,211,252,0.22)' : 'transparent',
            overflow: 'hidden',
          },
        ]}
      >
        <View style={s.centerChromeShadow} pointerEvents="none" />
        {glassCenter ? (
          <BlurView
            intensity={Platform.OS === 'ios' ? 28 : 42}
            tint="dark"
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
            {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
          />
        ) : null}
        {glassCenter ? (
          <LinearGradient
            colors={['rgba(255,255,255,0.12)', 'transparent']}
            start={{ x: 0, y: 0 }}
            end={{ x: 0, y: 1 }}
            style={[StyleSheet.absoluteFill, { opacity: 0.9 }]}
            pointerEvents="none"
          />
        ) : null}
        {showPercentage && (
          <>
            <Text
              allowFontScaling={false}
              {...(Platform.OS === 'android' && { includeFontPadding: false })}
              style={[s.num, size <= 64 && s.numSmall, compact && s.numCompact]}
            >
              {display}
            </Text>
            <Text
              allowFontScaling={false}
              {...(Platform.OS === 'android' && { includeFontPadding: false })}
              style={[
                s.sym,
                size <= 64 && s.symSmall,
                compact && s.symCompact,
                gamified && { color: glowColor },
              ]}
            >
              %
            </Text>
          </>
        )}
      </View>
    </Animated.View>
  );
}

const s = StyleSheet.create({
  root: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  track: {
    position: 'absolute',
    backgroundColor: 'transparent',
  },
  trackChromeOverlay: {
    position: 'absolute',
    opacity: 0.9,
  },
  trackSpecular: {
    position: 'absolute',
    alignSelf: 'center',
    backgroundColor: 'rgba(241,245,249,0.23)',
    opacity: 0.95,
  },
  shimmerWrap: {
    position: 'absolute',
  },
  shimmer: {
    position: 'absolute',
  },
  shimmerHole: {
    position: 'absolute',
  },
  fillClip: {
    position: 'absolute',
    overflow: 'hidden',
  },
  fill: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    overflow: 'hidden',
  },
  center: {
    position: 'absolute',
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
  },
  centerChromeShadow: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(241,245,249,0.16)',
    backgroundColor: 'rgba(15,23,42,0.18)',
  },
  num: {
    color: '#FFF',
    fontSize: 22,
    fontWeight: '800',
    letterSpacing: -0.5,
    zIndex: 1,
  },
  numSmall: {
    fontSize: 16,
  },
  numCompact: {
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: -0.3,
  },
  sym: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 14,
    fontWeight: '700',
    marginLeft: 1,
    zIndex: 1,
  },
  symSmall: {
    fontSize: 11,
  },
  symCompact: {
    fontSize: 9,
    fontWeight: '700',
    marginLeft: 0,
  },
});
