import React from 'react';
import { View, StyleSheet, Platform, ViewStyle, StyleProp } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';

export type DashboardGlassTone = 'panel' | 'frame';

type Props = {
  children: React.ReactNode;
  style?: StyleProp<ViewStyle>;
  innerStyle?: StyleProp<ViewStyle>;
  /** panel = blur + gradients (section shells); frame = frosted border without extra blur (use around GlassCard rows) */
  tone?: DashboardGlassTone;
  palette?: 'business' | 'valeter';
};

const BUSINESS_GRADIENT = ['rgba(125,211,252,0.1)', 'rgba(10,25,41,0.38)', 'rgba(15,40,71,0.32)'] as const;
const VALETER_GRADIENT = ['rgba(14,165,233,0.12)', 'rgba(15,23,42,0.4)', 'rgba(30,58,95,0.34)'] as const;

export function DashboardGlassSection({
  children,
  style,
  innerStyle,
  tone = 'panel',
  palette = 'business',
}: Props) {
  const isValeter = palette === 'valeter';
  const mainGradient = (isValeter ? VALETER_GRADIENT : BUSINESS_GRADIENT) as unknown as [string, string, string];
  const fallback = isValeter ? 'rgba(15,23,42,0.62)' : 'rgba(10,25,41,0.58)';

  if (tone === 'frame') {
    return (
      <View style={[styles.outerFrame, style]}>
        <LinearGradient
          colors={['rgba(255,255,255,0.07)', 'rgba(255,255,255,0.02)']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={StyleSheet.absoluteFill}
        />
        <View style={[styles.inner, innerStyle]}>{children}</View>
      </View>
    );
  }

  return (
    <View style={[styles.outerPanel, style]}>
      <View style={[styles.fallback, { backgroundColor: fallback }]} />
      <BlurView
        intensity={Platform.OS === 'ios' ? 42 : 68}
        tint="dark"
        style={StyleSheet.absoluteFill}
        {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
      />
      <LinearGradient
        colors={[mainGradient[0], mainGradient[1], mainGradient[2]]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={StyleSheet.absoluteFill}
      />
      <LinearGradient
        colors={['rgba(255,255,255,0.11)', 'rgba(255,255,255,0.02)', 'transparent'] as [string, string, string]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <View style={[styles.inner, innerStyle]}>{children}</View>
    </View>
  );
}

const styles = StyleSheet.create({
  outerPanel: {
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: StyleSheet.hairlineWidth * 2,
    borderColor: 'rgba(255,255,255,0.14)',
  },
  outerFrame: {
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: StyleSheet.hairlineWidth * 2,
    borderColor: 'rgba(255,255,255,0.12)',
    backgroundColor: 'rgba(15,23,42,0.35)',
  },
  fallback: {
    ...StyleSheet.absoluteFillObject,
  },
  inner: {
    padding: 14,
  },
});
