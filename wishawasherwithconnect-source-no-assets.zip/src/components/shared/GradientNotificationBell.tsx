import React, { useRef } from 'react';
import {
  TouchableOpacity,
  View,
  Text,
  StyleSheet,
  Animated,
  ViewStyle,
} from 'react-native';
import { useAccountTheme } from './AccountThemeProvider';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { BUTTON_PRESS_SCALE, BUTTON_ANIM_DURATION } from '../../constants/premiumTokens';
import GradientIconBox from './GradientIconBox';
import { accentToGradient } from '../../utils/accentGradient';

export interface GradientNotificationBellProps {
  count?: number;
  onPress?: () => void;
  loading?: boolean;
  accentColor?: string;
  disabled?: boolean;
  /** Optional style for the wrapper (e.g. margin). */
  style?: ViewStyle;
}

export default function GradientNotificationBell({
  count = 0,
  onPress,
  loading = false,
  accentColor,
  disabled = false,
  style,
}: GradientNotificationBellProps) {
  const { theme } = useAccountTheme();
  const accent = accentColor ?? theme.primary ?? '#87CEEB';
  const scaleAnim = useRef(new Animated.Value(1)).current;

  const handlePressIn = () => {
    if (disabled || loading) return;
    Animated.timing(scaleAnim, {
      toValue: BUTTON_PRESS_SCALE,
      duration: BUTTON_ANIM_DURATION,
      useNativeDriver: true,
    }).start();
  };

  const handlePressOut = () => {
    Animated.timing(scaleAnim, {
      toValue: 1,
      duration: BUTTON_ANIM_DURATION,
      useNativeDriver: true,
    }).start();
  };

  const handlePress = async () => {
    if (disabled || loading) return;
    await hapticFeedback('light');
    onPress?.();
  };

  return (
    <TouchableOpacity
      activeOpacity={1}
      onPress={handlePress}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      disabled={disabled || loading}
      style={[styles.wrapper, style]}
      accessibilityRole="button"
      accessibilityLabel={count > 0 ? `${count} notifications` : 'Notifications'}
    >
      <Animated.View style={[styles.bellOuter, { transform: [{ scale: scaleAnim }] }]}>
        <View style={styles.bellInner}>
          <GradientIconBox
            icon={loading ? 'notifications-off-outline' : 'notifications-outline'}
            colors={accentToGradient(accent)}
            boxSize={36}
            size={19}
          />
          {count > 0 && (
            <Animated.View style={[styles.badge, { backgroundColor: accent }]}>
              <Text style={styles.badgeText} numberOfLines={1}>
                {count > 99 ? '99+' : count}
              </Text>
            </Animated.View>
          )}
        </View>
      </Animated.View>
    </TouchableOpacity>
  );
}

const BELL_SIZE = 40;
const BADGE_SIZE = 18;
const BADGE_FONT = 10;

const styles = StyleSheet.create({
  wrapper: {
    marginLeft: 8,
  },
  bellOuter: {
    width: BELL_SIZE,
    height: BELL_SIZE,
    borderRadius: BELL_SIZE / 2,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 4,
  },
  bellInner: {
    width: BELL_SIZE,
    height: BELL_SIZE,
    borderRadius: BELL_SIZE / 2,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'visible',
  },
  badge: {
    position: 'absolute',
    top: -2,
    right: -2,
    minWidth: BADGE_SIZE,
    height: BADGE_SIZE,
    borderRadius: BADGE_SIZE / 2,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 4,
  },
  badgeText: {
    color: '#FFFFFF',
    fontSize: BADGE_FONT,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
});
