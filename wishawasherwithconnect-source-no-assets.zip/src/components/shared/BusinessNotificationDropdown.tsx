import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Modal,
  FlatList,
  ActivityIndicator,
  Animated,
  Pressable,
  Alert,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import {
  fetchBusinessNotificationFeed,
  DROPDOWN_FEED_DEFAULTS,
  type BusinessNotificationItem,
  type NotificationPriority,
} from '../../services/businessNotificationsFeed';
import {
  loadDismissedBusinessNotificationIds,
  dismissBusinessNotificationIds,
} from '../../services/businessNotificationDismissals';
import GradientIconBox, { LocationStyleIconBox } from './GradientIconBox';
import {
  NotificationInboxRow,
  businessNotificationIconAccent,
} from './NotificationInboxRow';
import BusinessSheetBackground from './BusinessSheetBackground';
import { useAccountTheme } from './AccountThemeProvider';
import { colors } from '../../constants/colors';
import { accentToGradient } from '../../utils/accentGradient';

const { height: SCREEN_H } = Dimensions.get('window');
const SHEET_MAX_H = Math.min(SCREEN_H * 0.82, 640);

type NotificationItem = BusinessNotificationItem;

interface BusinessNotificationDropdownProps {
  visible: boolean;
  onClose: () => void;
  organizationId: string | null;
}

export default function BusinessNotificationDropdown({
  visible,
  onClose,
  organizationId,
}: BusinessNotificationDropdownProps) {
  const { theme: businessTheme } = useAccountTheme();
  const insets = useSafeAreaInsets();
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [dismissedIds, setDismissedIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const slideAnim = useRef(new Animated.Value(0)).current;
  const backdropAnim = useRef(new Animated.Value(0)).current;

  const headerAccent = businessTheme.primary || colors.navActive;
  const glassBorder = businessTheme.glassBorder ?? 'rgba(125,211,252,0.28)';

  const visibleNotifications = useMemo(
    () => notifications.filter((n) => !dismissedIds.has(n.id)).slice(0, 20),
    [notifications, dismissedIds]
  );

  useEffect(() => {
    if (visible && organizationId) {
      void (async () => {
        const dismissed = await loadDismissedBusinessNotificationIds(organizationId);
        setDismissedIds(dismissed);
        await fetchNotifications();
      })();
      Animated.parallel([
        Animated.spring(slideAnim, {
          toValue: 1,
          useNativeDriver: true,
          tension: 52,
          friction: 9,
        }),
        Animated.timing(backdropAnim, {
          toValue: 1,
          duration: 280,
          useNativeDriver: true,
        }),
      ]).start();
    } else {
      slideAnim.setValue(0);
      backdropAnim.setValue(0);
    }
  }, [visible, organizationId]);

  const fetchNotifications = async () => {
    if (!organizationId) return;

    try {
      setLoading(true);

      const notificationItems = await fetchBusinessNotificationFeed(organizationId, {
        bookingLimit: DROPDOWN_FEED_DEFAULTS.bookingLimit,
        teamRequestLimit: DROPDOWN_FEED_DEFAULTS.teamRequestLimit,
        teamUpdateMaxAgeMs: DROPDOWN_FEED_DEFAULTS.teamUpdateMaxAgeMs,
      });

      setNotifications(notificationItems);
    } catch (error) {
      console.error('Error fetching notifications:', error);
      setNotifications([]);
    } finally {
      setLoading(false);
    }
  };

  const handleDismissOne = useCallback(
    async (id: string) => {
      if (!organizationId) return;
      await hapticFeedback('light');
      const next = await dismissBusinessNotificationIds(organizationId, [id]);
      setDismissedIds(next);
    },
    [organizationId]
  );

  const handleClearAllVisible = useCallback(() => {
    if (!organizationId) return;
    const visible = notifications.filter((n) => !dismissedIds.has(n.id));
    if (visible.length === 0) return;
    Alert.alert(
      'Clear all notifications?',
      'This hides every item from your inbox. Bookings and team data are not deleted.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Clear all',
          style: 'destructive',
          onPress: async () => {
            await hapticFeedback('medium');
            const ids = visible.map((n) => n.id);
            const next = await dismissBusinessNotificationIds(organizationId, ids);
            setDismissedIds(next);
          },
        },
      ]
    );
  }, [organizationId, notifications, dismissedIds]);

  const handleNotificationPress = async (item: NotificationItem) => {
    await hapticFeedback('light');
    onClose();

    if (item.type === 'booking_update' && item.bookingId) {
      const isActive =
        item.title === 'Booking In Progress' || item.message.toLowerCase().includes('in progress');
      if (isActive) {
        router.push('/business/dashboard');
        return;
      }
    }

    if (item.route) {
      router.push(item.route as any);
    }
  };

  const getPriorityColor = (priority: NotificationPriority) => {
    switch (priority) {
      case 'high':
        return '#EF4444';
      case 'medium':
        return '#FBBF24';
      case 'low':
        return '#10B981';
      default:
        return businessTheme.primary;
    }
  };

  const hasUndismissed = notifications.some((n) => !dismissedIds.has(n.id));

  const renderNotification = ({ item }: { item: NotificationItem }) => {
    const meta = businessNotificationIconAccent(item.type, headerAccent);
    const priorityColor = getPriorityColor(item.priority);

    return (
      <NotificationInboxRow
        title={item.title}
        message={item.message}
        timeLine={item.time}
        icon={meta.icon}
        accentColor={meta.accent}
        onPress={() => void handleNotificationPress(item)}
        onDismiss={() => void handleDismissOne(item.id)}
        showChevron
        chevronAccentColor={headerAccent}
        priorityUrgent={item.priority === 'high'}
        priorityColor={priorityColor}
      />
    );
  };

  const sheetTranslate = slideAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [SHEET_MAX_H + 48, 0],
  });

  const backdropOpacity = backdropAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 1],
  });

  return (
    <Modal visible={visible} transparent animationType="none" statusBarTranslucent onRequestClose={onClose}>
      <View style={styles.root} pointerEvents="box-none">
        <Animated.View style={[styles.backdropFill, { opacity: backdropOpacity }]}>
          <Pressable style={StyleSheet.absoluteFill} onPress={onClose} accessibilityRole="button" accessibilityLabel="Close notifications" />
        </Animated.View>

        <Animated.View
          style={[
            styles.sheetOuter,
            {
              maxHeight: SHEET_MAX_H,
              paddingBottom: Math.max(insets.bottom, 12),
              transform: [{ translateY: sheetTranslate }],
            },
          ]}
        >
          <View style={[styles.sheetCard, { borderColor: glassBorder }]}>
            <BusinessSheetBackground />
            <View style={[styles.sheetGlassStroke, { borderColor: glassBorder }]} pointerEvents="none" />
            <View style={[styles.sheetGlowLine, { backgroundColor: `${headerAccent}75`, shadowColor: headerAccent }]} />

            <View style={styles.grabberWrap}>
              <View style={[styles.grabber, { backgroundColor: `${headerAccent}88` }]} />
            </View>

            <View style={styles.sheetHeader}>
              <View style={styles.sheetHeaderLeft}>
                <GradientIconBox
                  icon="notifications-outline"
                  colors={accentToGradient(headerAccent)}
                  boxSize={48}
                  size={24}
                />
                <View>
                  <Text style={styles.sheetTitle}>Notifications</Text>
                  <Text style={styles.sheetSubtitle}>Bookings, team & alerts</Text>
                </View>
              </View>
              <View style={styles.sheetHeaderRight}>
                {hasUndismissed && (
                  <TouchableOpacity onPress={handleClearAllVisible} style={styles.textBtn} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
                    <Text style={[styles.clearAllText, { color: headerAccent }]}>Clear all</Text>
                  </TouchableOpacity>
                )}
                <TouchableOpacity onPress={onClose} style={styles.closeRound} accessibilityLabel="Close">
                  <LocationStyleIconBox variant="card" icon="close" preset="gray" />
                </TouchableOpacity>
              </View>
            </View>

            {loading ? (
              <View style={styles.loadingContainer}>
                <ActivityIndicator size="small" color={headerAccent} />
                <Text style={styles.loadingText}>Loading updates…</Text>
              </View>
            ) : notifications.length === 0 ? (
              <View style={styles.emptyContainer}>
                <GradientIconBox icon="notifications-off-outline" preset="sky" boxSize={72} size={36} />
                <Text style={styles.emptyText}>You&apos;re all caught up</Text>
                <Text style={styles.emptySubtext}>New activity will show up here.</Text>
              </View>
            ) : visibleNotifications.length === 0 ? (
              <View style={styles.emptyContainer}>
                <GradientIconBox icon="checkmark-done-outline" preset="sky" boxSize={72} size={36} />
                <Text style={styles.emptyText}>Inbox cleared</Text>
                <Text style={styles.emptySubtext}>Open the full list for history.</Text>
              </View>
            ) : (
              <FlatList
                data={visibleNotifications}
                renderItem={renderNotification}
                keyExtractor={(item) => item.id}
                style={styles.list}
                contentContainerStyle={styles.listContent}
                showsVerticalScrollIndicator={false}
              />
            )}

            {!loading && (
              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  onClose();
                  router.push('/business/notifications' as any);
                }}
                style={styles.viewAllFooter}
                activeOpacity={0.88}
              >
                <LinearGradient
                  colors={[`${headerAccent}22`, 'rgba(15,23,42,0.35)']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={StyleSheet.absoluteFill}
                />
                <Text style={[styles.viewAllText, { color: headerAccent }]}>Open full inbox</Text>
                <LocationStyleIconBox
                  variant="inline"
                  icon="arrow-forward-outline"
                  colors={accentToGradient(headerAccent)}
                />
              </TouchableOpacity>
            )}
          </View>
        </Animated.View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  backdropFill: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(5,12,24,0.72)',
  },
  sheetOuter: {
    width: '100%',
  },
  sheetCard: {
    borderTopLeftRadius: 26,
    borderTopRightRadius: 26,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderBottomWidth: 0,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -8 },
    shadowOpacity: 0.45,
    shadowRadius: 24,
    elevation: 28,
  },
  sheetGlassStroke: {
    ...StyleSheet.absoluteFillObject,
    borderTopLeftRadius: 26,
    borderTopRightRadius: 26,
    borderWidth: 1.5,
    zIndex: 2,
  },
  sheetGlowLine: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 2,
    zIndex: 3,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.85,
    shadowRadius: 10,
  },
  grabberWrap: {
    alignItems: 'center',
    paddingTop: 10,
    paddingBottom: 4,
    zIndex: 4,
  },
  grabber: {
    width: 44,
    height: 5,
    borderRadius: 3,
    opacity: 0.9,
  },
  sheetHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 14,
    zIndex: 4,
  },
  sheetHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    flex: 1,
    minWidth: 0,
  },
  sheetTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  sheetSubtitle: {
    color: 'rgba(249,250,251,0.58)',
    fontSize: 13,
    fontWeight: '600',
    marginTop: 2,
  },
  sheetHeaderRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  textBtn: {
    paddingVertical: 6,
    paddingHorizontal: 4,
  },
  clearAllText: {
    fontSize: 14,
    fontWeight: '800',
  },
  closeRound: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  loadingContainer: {
    paddingVertical: 36,
    alignItems: 'center',
    gap: 12,
    zIndex: 4,
  },
  loadingText: {
    color: 'rgba(249,250,251,0.65)',
    fontSize: 14,
    fontWeight: '600',
  },
  emptyContainer: {
    paddingVertical: 28,
    paddingHorizontal: 24,
    alignItems: 'center',
    gap: 10,
    zIndex: 4,
  },
  emptyText: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
  },
  emptySubtext: {
    color: 'rgba(249,250,251,0.58)',
    fontSize: 13,
    textAlign: 'center',
    lineHeight: 18,
  },
  list: {
    maxHeight: SCREEN_H * 0.46,
    zIndex: 4,
  },
  listContent: {
    paddingHorizontal: 16,
    paddingBottom: 8,
    gap: 10,
  },
  viewAllFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    marginHorizontal: 16,
    marginTop: 4,
    marginBottom: 6,
    paddingVertical: 16,
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    zIndex: 4,
  },
  viewAllText: {
    fontSize: 15,
    fontWeight: '900',
  },
});
