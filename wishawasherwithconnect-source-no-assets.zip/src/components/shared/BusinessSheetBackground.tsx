/**
 * Shared fill for business bottom sheets — matches Team page roster sheet:
 * BlurView + header gradient + primary accent wash.
 */
import React from 'react';
import { StyleSheet, Platform, View } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useAccountTheme } from './AccountThemeProvider';
import { colors } from '../../constants/colors';

const FALLBACK_HEADER: [string, string] = ['#0f172a', '#0f172a'];

export default function BusinessSheetBackground() {
  const { theme, mode } = useAccountTheme();
  const headerBg = (theme.headerBackground ?? theme.background ?? FALLBACK_HEADER) as [string, string];
  const headerAccent = theme.primary || colors.navActive;

  return (
    <BlurView
      intensity={Platform.OS === 'ios' ? 30 : 22}
      tint={mode === 'light' ? 'light' : 'dark'}
      style={StyleSheet.absoluteFill}
    >
      <LinearGradient
        colors={[`${headerBg[0]}FF`, `${headerBg[1] || headerBg[0]}EE`]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={StyleSheet.absoluteFill}
      />
      <View style={StyleSheet.absoluteFill} pointerEvents="none">
        <LinearGradient
          colors={[`${headerAccent}30`, 'transparent']}
          start={{ x: 0, y: 0 }}
          end={{ x: 0, y: 1 }}
          style={StyleSheet.absoluteFill}
        />
      </View>
    </BlurView>
  );
}
