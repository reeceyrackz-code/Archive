import React, { createContext, useContext, useState, useEffect, ReactNode, useMemo } from 'react';
import { Appearance } from 'react-native';
import type { ThemeMode } from '../../constants/accountThemes';

interface GlobalThemeContextValue {
  mode: ThemeMode;
  setMode: (mode: ThemeMode) => void;
  toggleMode: () => void;
}

const GlobalThemeContext = createContext<GlobalThemeContextValue | undefined>(undefined);

/** Supports light/dark and follows device appearance changes. */
export function GlobalThemeProvider({ children, initialMode = 'dark' }: Readonly<{ children: ReactNode; initialMode?: ThemeMode }>) {
  const [mode, setModeState] = useState<ThemeMode>(initialMode);

  useEffect(() => {
    const initialSystem = Appearance.getColorScheme();
    if (initialSystem === 'light' || initialSystem === 'dark') {
      setModeState(initialSystem);
    }
    const sub = Appearance.addChangeListener(({ colorScheme }) => {
      if (colorScheme === 'light' || colorScheme === 'dark') {
        setModeState(colorScheme);
      }
    });
    return () => sub.remove();
  }, [initialMode]);

  const setMode = (newMode: ThemeMode) => {
    setModeState(newMode);
  };

  const toggleMode = () => {
    const next: ThemeMode = mode === 'light' ? 'dark' : 'light';
    setModeState(next);
  };

  const value = useMemo(() => ({ mode, setMode, toggleMode }), [mode]);

  return (
    <GlobalThemeContext.Provider value={value}>
      {children}
    </GlobalThemeContext.Provider>
  );
}

export function useGlobalTheme(): GlobalThemeContextValue {
  const context = useContext(GlobalThemeContext);
  if (!context) {
    return {
      mode: 'dark',
      setMode: () => {},
      toggleMode: () => {},
    };
  }
  return context;
}
