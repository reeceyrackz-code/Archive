import React, { createContext, useContext, ReactNode, useMemo } from 'react';
import { AccountType, getAccountTheme, AccountTheme, ThemeMode } from '../../constants/accountThemes';
import { useGlobalTheme } from './GlobalThemeContext';

interface AccountThemeContextValue {
  accountType: AccountType;
  theme: AccountTheme;
  mode: ThemeMode;
  setMode: (mode: ThemeMode) => void;
  toggleMode: () => void;
}

const AccountThemeContext = createContext<AccountThemeContextValue | undefined>(undefined);

interface AccountThemeProviderProps {
  accountType: AccountType;
  children: ReactNode;
}

export function AccountThemeProvider({ accountType, children }: Readonly<AccountThemeProviderProps>) {
  const { mode, setMode, toggleMode } = useGlobalTheme();
  const theme = getAccountTheme(accountType, mode);
  const value = useMemo(
    () => ({ accountType, theme, mode, setMode, toggleMode }),
    [accountType, theme, mode, setMode, toggleMode]
  );

  return (
    <AccountThemeContext.Provider value={value}>
      {children}
    </AccountThemeContext.Provider>
  );
}

export function useAccountTheme(): AccountThemeContextValue {
  const context = useContext(AccountThemeContext);
  const globalTheme = useGlobalTheme();
  if (!context) {
    return {
      accountType: 'valeter',
      theme: getAccountTheme('valeter', globalTheme.mode),
      mode: globalTheme.mode,
      setMode: globalTheme.setMode,
      toggleMode: globalTheme.toggleMode,
    };
  }
  return context;
}

