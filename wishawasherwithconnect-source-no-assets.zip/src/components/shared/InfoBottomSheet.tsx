/**
 * Shared info bottom sheet – supports light/dark theme.
 */
import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  Pressable,
  TouchableOpacity,
  ScrollView,
  type ViewStyle,
} from 'react-native';
import { ChromeGlyph as Ionicons } from './ChromeGlyph';
import { HEADER_STYLE_CARD_BORDER } from '../../constants/bookingCardTheme';
import { colors } from '../../constants/colors';
import { useAccountTheme } from './AccountThemeProvider';
import BusinessSheetBackground from './BusinessSheetBackground';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const SKY = colors.SKY;

export interface InfoBottomSheetProps {
  visible: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  accentColor?: string;
  footer?: React.ReactNode;
  contentMaxHeight?: string;
  /** When 'linkedin', uses light background, dark text. When 'header', uses header-matching gradient with more opacity, light text. */
  variant?: 'default' | 'linkedin' | 'header';
}

/** Light mode = reference style (muted blue–navy) → same glass sheet + light text. */
export default function InfoBottomSheet({
  visible,
  onClose,
  title,
  children,
  accentColor = SKY,
  footer,
  contentMaxHeight = '85%',
  variant = 'default',
}: Readonly<InfoBottomSheetProps>) {
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const isLight = theme.mode === 'light';
  const linkedIn = variant === 'linkedin';
  const headerStyle = variant === 'header';
  const sheetBorder = theme.glassBorder ?? HEADER_STYLE_CARD_BORDER;
  const titleColor = linkedIn ? '#000000' : (theme.textPrimary ?? '#F9FAFB');
  const closeColor = linkedIn ? '#666666' : (theme.textSecondary ?? 'rgba(249,250,251,0.9)');
  const contentBorderColor = !headerStyle && accentColor !== SKY ? `${accentColor}40` : sheetBorder;

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      statusBarTranslucent
      onRequestClose={onClose}
    >
      <Pressable style={styles.overlay} onPress={onClose}>
        <Pressable
          style={[
            styles.content,
            linkedIn && styles.contentLinkedIn,
            headerStyle && styles.contentHeader,
            {
              maxHeight: contentMaxHeight as ViewStyle['maxHeight'],
              height: contentMaxHeight as ViewStyle['height'],
              borderColor: linkedIn ? '#EBEBEB' : (contentBorderColor ?? sheetBorder),
            },
          ]}
          onPress={(e) => e.stopPropagation()}
        >
          {!linkedIn ? <BusinessSheetBackground /> : null}
          <View style={[
            styles.handle,
            linkedIn && styles.handleLinkedIn,
            headerStyle && { backgroundColor: (accentColor || theme.primary || SKY) + '50' },
            !linkedIn && !headerStyle && (isLight ? { backgroundColor: 'rgba(100,116,139,0.35)' } : { backgroundColor: accentColor + '50' }),
          ]} />
          <View style={[styles.header, linkedIn && styles.headerLinkedIn, headerStyle && styles.headerHeader]}>
            <Text style={[styles.title, { color: titleColor }, linkedIn && styles.titleLinkedIn]}>{title}</Text>
            <TouchableOpacity onPress={onClose} hitSlop={12} accessibilityLabel="Close" accessibilityRole="button" style={linkedIn ? styles.closeBtnLinkedIn : (headerStyle ? styles.closeBtnHeader : undefined)}>
              <Ionicons name="close" size={linkedIn || headerStyle ? 22 : 24} color={closeColor} />
            </TouchableOpacity>
          </View>
          <View style={styles.scrollWrap}>
            <ScrollView
              showsVerticalScrollIndicator={!linkedIn}
              bounces={true}
              style={styles.scroll}
              contentContainerStyle={[styles.scrollContent, linkedIn && styles.scrollContentLinkedIn, headerStyle && styles.scrollContentHeader]}
            >
              {children}
            </ScrollView>
          </View>
          {footer ? <View style={[styles.footer, linkedIn && styles.footerLinkedIn, headerStyle && styles.footerHeader, { paddingBottom: Math.max(24, insets.bottom + 12) }]}>{footer}</View> : null}
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.72)',
    justifyContent: 'flex-end',
  },
  content: {
    width: '100%',
    backgroundColor: 'transparent',
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderWidth: 1,
    overflow: 'hidden',
  },
  contentLinkedIn: {
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 16,
  },
  contentHeader: {
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 16,
  },
  sheetOverlay: {
    backgroundColor: 'rgba(0,0,0,0.45)',
  },
  headerHeader: {
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.12)',
    paddingBottom: 14,
    marginBottom: 0,
  },
  closeBtnHeader: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  scrollContentHeader: {
    paddingHorizontal: 20,
  },
  footerHeader: {
    borderTopColor: 'rgba(255,255,255,0.12)',
  },
  handleLinkedIn: {
    width: 36,
    height: 4,
    backgroundColor: '#DADADA',
    borderRadius: 2,
  },
  headerLinkedIn: {
    borderBottomWidth: 1,
    borderBottomColor: '#EBEBEB',
    paddingBottom: 14,
    marginBottom: 0,
  },
  titleLinkedIn: {
    fontSize: 20,
    fontWeight: '600',
  },
  closeBtnLinkedIn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  scrollContentLinkedIn: {
    paddingHorizontal: 20,
  },
  footerLinkedIn: {
    borderTopColor: '#EBEBEB',
  },
  handle: {
    width: 36,
    height: 3,
    borderRadius: 2,
    alignSelf: 'center',
    marginTop: 10,
    marginBottom: 14,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 22,
    paddingTop: 8,
    paddingBottom: 14,
  },
  title: {
    color: '#F9FAFB',
    fontSize: 19,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  scrollWrap: {
    flex: 1,
    minHeight: 0,
  },
  scroll: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 22,
    paddingBottom: 36,
    flexGrow: 1,
  },
  footer: {
    paddingHorizontal: 22,
    paddingTop: 14,
    borderTopWidth: 1,
    borderTopColor: 'rgba(148,163,184,0.18)',
  },
});

/** LinkedIn variant: light background, dark text – use for content when variant="linkedin". */
export const infoBottomSheetLinkedInStyles = StyleSheet.create({
  block: { marginBottom: 20 },
  blockTitle: { color: '#000000', fontSize: 16, fontWeight: '600', marginBottom: 4 },
  blockSubtitle: { color: '#666666', fontSize: 13, marginBottom: 12, lineHeight: 18 },
  list: { backgroundColor: '#FFFFFF', borderRadius: 8, borderWidth: 1, borderColor: '#EBEBEB', overflow: 'hidden' },
  listItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: 14, paddingHorizontal: 16, borderBottomWidth: 1, borderBottomColor: '#EBEBEB' },
  listItemLast: { borderBottomWidth: 0 },
  listItemIcon: { width: 36, height: 36, borderRadius: 18, backgroundColor: '#E7F3FF', alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  listItemLabel: { color: '#666666', fontSize: 14, fontWeight: '500', minWidth: 100 },
  listItemValue: { flex: 1, color: '#000000', fontSize: 15, fontWeight: '600' },
  listItemValueAccent: { fontSize: 17, fontWeight: '700', color: '#0A66C2' },
  reviewBlock: { marginTop: 12, padding: 16, borderRadius: 8, backgroundColor: '#F3F2EF', borderWidth: 1, borderColor: '#EBEBEB' },
  reviewLabel: { color: '#666666', fontSize: 12, fontWeight: '600', marginBottom: 6 },
  reviewText: { color: '#000000', fontSize: 14, fontStyle: 'italic', lineHeight: 20 },
  saveBtn: { backgroundColor: '#0A66C2', borderRadius: 24, paddingVertical: 14, alignItems: 'center', justifyContent: 'center' },
  saveBtnText: { color: '#FFFFFF', fontSize: 16, fontWeight: '600' },
});

/** Header variant: header-matching gradient, light text – use for content when variant="header". */
export const infoBottomSheetHeaderStyles = StyleSheet.create({
  list: { backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: 8, borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)', overflow: 'hidden' },
  listItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: 14, paddingHorizontal: 16, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.08)', backgroundColor: 'transparent' },
  listItemLast: { borderBottomWidth: 0 },
  listItemIcon: { width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(135,206,235,0.2)', alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  listItemLabel: { color: 'rgba(249,250,251,0.85)', fontSize: 14, fontWeight: '500', minWidth: 100 },
  listItemValue: { flex: 1, color: '#F9FAFB', fontSize: 15, fontWeight: '600' },
  listItemValueAccent: { fontSize: 17, fontWeight: '700', color: SKY },
  reviewBlock: { marginTop: 12, padding: 16, borderRadius: 8, backgroundColor: 'rgba(255,255,255,0.06)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)' },
  reviewLabel: { color: 'rgba(249,250,251,0.7)', fontSize: 12, fontWeight: '600', marginBottom: 6 },
  reviewText: { color: '#F9FAFB', fontSize: 14, fontStyle: 'italic', lineHeight: 20 },
  saveBtn: { borderRadius: 24, paddingVertical: 14, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  saveBtnText: { color: '#FFFFFF', fontSize: 16, fontWeight: '600' },
});

/** Shared content styles – match customer app (avatar, name, stats, sections, info rows). */
export const infoBottomSheetContentStyles = StyleSheet.create({
  avatar: { alignItems: 'center', marginBottom: 12 },
  avatarImg: { width: 88, height: 88, borderRadius: 44, borderWidth: 2, borderColor: SKY },
  avatarInner: { width: 88, height: 88, borderRadius: 44, backgroundColor: 'rgba(135,206,235,0.15)', borderWidth: 2, borderColor: SKY, alignItems: 'center', justifyContent: 'center' },
  hubIcon: { width: 76, height: 76 },
  name: { color: '#F9FAFB', fontSize: 20, fontWeight: '800', textAlign: 'center', marginBottom: 4 },
  org: { color: 'rgba(255,255,255,0.7)', fontSize: 14, textAlign: 'center', marginBottom: 8 },
  joinedRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, marginBottom: 16 },
  joinedText: { color: SKY, fontSize: 13, fontWeight: '600' },
  stats: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, justifyContent: 'center', marginBottom: 24 },
  stat: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  statText: { color: '#E5E7EB', fontSize: 14, fontWeight: '600' },
  section: { marginTop: 8 },
  sectionTitle: { color: '#F9FAFB', fontSize: 16, fontWeight: '700', marginBottom: 12 },
  addressRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, marginBottom: 16 },
  address: { color: 'rgba(255,255,255,0.8)', fontSize: 14, flex: 1 },
  reviewItem: { padding: 12, marginBottom: 8, borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.06)', borderWidth: 1, borderColor: 'rgba(148,163,184,0.15)' },
  reviewHeader: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 6 },
  reviewRating: { color: '#FBBF24', fontSize: 14, fontWeight: '700' },
  reviewText: { color: '#E5E7EB', fontSize: 14, lineHeight: 20 },
  reviewsPlaceholder: { padding: 24, borderRadius: 14, backgroundColor: 'rgba(255,255,255,0.05)', borderWidth: 1, borderColor: 'rgba(148,163,184,0.15)', alignItems: 'center', gap: 8 },
  placeholderText: { color: 'rgba(148,163,184,0.7)', fontSize: 13, fontWeight: '500' },
  infoRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  infoText: { color: 'rgba(241,245,249,0.9)', fontSize: 13, flex: 1 },
  infoModalSection: { marginTop: 4 },
  infoModalSectionTitle: { fontSize: 14, fontWeight: '700', marginBottom: 8, color: '#F9FAFB' },
});
