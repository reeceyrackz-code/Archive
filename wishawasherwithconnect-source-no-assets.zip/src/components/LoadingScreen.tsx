import React, { useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  Image,
  Dimensions,
  Platform,
  Modal,
  Easing,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { usePathname } from 'expo-router';
import { useGlobalTheme } from './shared/GlobalThemeContext';
import { getAccountTheme } from '../constants/accountThemes';

const { width: SCREEN_W, height: SCREEN_H } = Dimensions.get('window');

const BG_TOP_DARK = '#1e3d5c';
const BG_BOTTOM_DARK = '#0a1628';
const TAGLINE = '#7dd3fc';
const BAR_TRACK = 'rgba(55, 65, 81, 0.85)';
const BAR_FILL = '#7dd3fc';

const LOGO = require('../../app/assets/icon.png');

const SPLASH_LOGO_SIZE = Math.min(220, Math.round(SCREEN_W * 0.48));
const SPLASH_LOGO_RADIUS = Math.round((28 * SPLASH_LOGO_SIZE) / 132);

interface LoadingScreenProps {
  message?: string;
  /**
   * When false, fills the parent only (no overlay). Use at app root (`/`, `loading`) so the next
   * route can fade in over the same visual.
   */
  overlay?: boolean;
  /** Big splash: large logo, glow orbs, entrance fade/scale. Default true. */
  splash?: boolean;
}

type ReadonlyLoadingScreenProps = Readonly<LoadingScreenProps>;

/** Full-screen Wish a Wash splash: gradient, pulsing logo, optional glow, animated bar. */
export default function LoadingScreen({
  message,
  overlay = true,
  splash: splashProp = true,
}: ReadonlyLoadingScreenProps) {
  const pathname = usePathname();
  const { mode } = useGlobalTheme();
  const pulse = useRef(new Animated.Value(1)).current;
  const barProgress = useRef(new Animated.Value(0)).current;
  const entrance = useRef(new Animated.Value(0)).current;
  const glowA = useRef(new Animated.Value(0.25)).current;
  const glowB = useRef(new Animated.Value(0.15)).current;

  const accountType: 'valeter' | 'business' = pathname?.includes('/business/') ? 'business' : 'valeter';
  const themedBackground = getAccountTheme(accountType, mode).background;
  const gradientColors: [string, string] = mode === 'dark' ? [BG_TOP_DARK, BG_BOTTOM_DARK] : themedBackground;

  useEffect(() => {
    const pulseLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, {
          toValue: 1.06,
          duration: 750,
          useNativeDriver: true,
        }),
        Animated.timing(pulse, {
          toValue: 1,
          duration: 750,
          useNativeDriver: true,
        }),
      ])
    );
    pulseLoop.start();

    const barLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(barProgress, {
          toValue: 1,
          duration: 2200,
          useNativeDriver: false,
        }),
        Animated.timing(barProgress, {
          toValue: 0,
          duration: 350,
          useNativeDriver: false,
        }),
      ])
    );
    barLoop.start();

    let glowLoop: Animated.CompositeAnimation | null = null;
    if (splashProp) {
      glowLoop = Animated.loop(
        Animated.sequence([
          Animated.parallel([
            Animated.timing(glowA, { toValue: 0.5, duration: 1800, useNativeDriver: true }),
            Animated.timing(glowB, { toValue: 0.35, duration: 2200, useNativeDriver: true }),
          ]),
          Animated.parallel([
            Animated.timing(glowA, { toValue: 0.2, duration: 1800, useNativeDriver: true }),
            Animated.timing(glowB, { toValue: 0.12, duration: 2200, useNativeDriver: true }),
          ]),
        ])
      );
      glowLoop.start();
    }

    entrance.setValue(0);
    Animated.timing(entrance, {
      toValue: 1,
      duration: 520,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start();

    return () => {
      pulseLoop.stop();
      barLoop.stop();
      glowLoop?.stop();
    };
  }, [pulse, barProgress, entrance, glowA, glowB, splashProp]);

  const logoSize = splashProp ? SPLASH_LOGO_SIZE : Math.min(160, Math.round(SCREEN_W * 0.38));
  const logoRadius = splashProp ? SPLASH_LOGO_RADIUS : Math.round((28 * logoSize) / 132);
  const horizontalPad = splashProp ? 24 : 28;
  const maxBarW = SCREEN_W - horizontalPad * 2;
  const barFillWidth = barProgress.interpolate({
    inputRange: [0, 1],
    outputRange: [6, Math.max(24, maxBarW - 8)],
  });

  const entranceOpacity = entrance;
  const entranceScale = entrance.interpolate({
    inputRange: [0, 1],
    outputRange: [0.94, 1],
  });

  const content = (
    <>
      {splashProp ? (
        <View style={styles.glowLayer} pointerEvents="none">
          <Animated.View style={[styles.glowOrb, styles.glowOrbL, { opacity: glowA }]} />
          <Animated.View style={[styles.glowOrb, styles.glowOrbR, { opacity: glowB }]} />
        </View>
      ) : null}

      <Animated.View
        style={[
          styles.centerBlock,
          { opacity: entranceOpacity, transform: [{ scale: entranceScale }] },
        ]}
      >
        <Animated.View style={{ transform: [{ scale: pulse }] }}>
          <View
            style={[
              styles.logoOuter,
              {
                width: logoSize,
                height: logoSize,
                borderRadius: logoRadius,
                borderWidth: splashProp ? 4 : 3,
              },
            ]}
          >
            <Image
              source={LOGO}
              style={[
                styles.logoImage,
                {
                  width: logoSize,
                  height: logoSize,
                  borderRadius: logoRadius,
                },
              ]}
              resizeMode="cover"
              accessibilityLabel="Wish a Wash"
            />
          </View>
        </Animated.View>

        <Text style={[styles.title, splashProp && styles.titleSplash]}>Wish a Wash</Text>
        <Text style={[styles.tagline, splashProp && styles.taglineSplash]}>Your Wish Our Wash</Text>
        {message ? (
          <Text style={styles.message} numberOfLines={2}>
            {message}
          </Text>
        ) : null}
      </Animated.View>

      <View style={[styles.barArea, { paddingHorizontal: horizontalPad }]}>
        <View style={styles.barTrack}>
          <Animated.View style={[styles.barFill, { width: barFillWidth }]} />
        </View>
      </View>
    </>
  );

  const fullScreenBody = (
    <SafeAreaView style={styles.flex} edges={['top', 'bottom']}>
      <LinearGradient
        colors={gradientColors}
        start={{ x: 0.5, y: 0 }}
        end={{ x: 0.5, y: 1 }}
        style={StyleSheet.absoluteFill}
      />
      <View style={[styles.fullInner, splashProp && styles.fullInnerSplash]}>{content}</View>
    </SafeAreaView>
  );

  if (!overlay) {
    return fullScreenBody;
  }

  return (
    <Modal
      visible
      animationType="fade"
      transparent
      statusBarTranslucent={Platform.OS === 'android'}
      presentationStyle={Platform.OS === 'ios' ? 'overFullScreen' : undefined}
      onRequestClose={() => {
        /* Loading is controlled by parent; do not dismiss from hardware back. */
      }}
    >
      <View style={styles.modalRoot}>{fullScreenBody}</View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  modalRoot: {
    flex: 1,
    backgroundColor: BG_BOTTOM_DARK,
  },
  flex: {
    flex: 1,
    backgroundColor: BG_BOTTOM_DARK,
  },
  fullInner: {
    flex: 1,
    justifyContent: 'space-between',
    paddingBottom: Platform.OS === 'ios' ? 8 : 16,
  },
  fullInnerSplash: {
    paddingTop: SCREEN_H * 0.06,
  },
  glowLayer: {
    ...StyleSheet.absoluteFillObject,
    alignItems: 'center',
    justifyContent: 'center',
  },
  glowOrb: {
    position: 'absolute',
    width: SCREEN_W * 0.95,
    height: SCREEN_W * 0.95,
    borderRadius: SCREEN_W * 0.5,
    backgroundColor: 'rgba(125,211,252,0.22)',
  },
  glowOrbL: {
    top: SCREEN_H * 0.08,
    alignSelf: 'center',
    marginLeft: -SCREEN_W * 0.2,
  },
  glowOrbR: {
    top: SCREEN_H * 0.22,
    alignSelf: 'center',
    marginLeft: SCREEN_W * 0.18,
    backgroundColor: 'rgba(56,189,248,0.18)',
  },
  centerBlock: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: 8,
  },
  logoOuter: {
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderTopColor: 'rgba(255,255,255,0.45)',
    borderLeftColor: 'rgba(255,255,255,0.35)',
    borderRightColor: 'rgba(0,0,0,0.35)',
    borderBottomColor: 'rgba(0,0,0,0.45)',
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 8 },
        shadowOpacity: 0.45,
        shadowRadius: 16,
      },
      android: { elevation: 16 },
    }),
  },
  logoImage: {
    overflow: 'hidden',
  },
  title: {
    marginTop: 28,
    fontSize: 28,
    fontWeight: '800',
    color: '#FFFFFF',
    letterSpacing: -0.5,
  },
  titleSplash: {
    marginTop: 32,
    fontSize: 34,
    letterSpacing: -0.8,
  },
  tagline: {
    marginTop: 8,
    fontSize: 15,
    fontWeight: '600',
    color: TAGLINE,
    letterSpacing: 0.2,
  },
  taglineSplash: {
    marginTop: 10,
    fontSize: 17,
  },
  message: {
    marginTop: 18,
    fontSize: 14,
    fontWeight: '600',
    color: 'rgba(255,255,255,0.72)',
    textAlign: 'center',
    paddingHorizontal: 24,
  },
  barArea: {
    width: '100%',
    alignItems: 'center',
    paddingBottom: 4,
  },
  barTrack: {
    width: '100%',
    maxWidth: 400,
    height: 5,
    borderRadius: 3,
    backgroundColor: BAR_TRACK,
    overflow: 'hidden',
  },
  barFill: {
    height: '100%',
    borderRadius: 3,
    backgroundColor: BAR_FILL,
  },
});
