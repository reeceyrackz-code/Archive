import React, { type ReactNode } from 'react';
import { Text, StyleSheet, ViewStyle, TextStyle } from 'react-native';
import { ChromeGlyph as Ionicons, type IconGlyphName } from '../shared/ChromeGlyph';
import { colors } from '../../constants/colors';
import ContinueCTAButton from './ContinueCTAButton';

interface WWPrimaryButtonProps {
  title: string;
  onPress: () => void;
  disabled?: boolean;
  loading?: boolean;
  style?: ViewStyle;
  textStyle?: TextStyle;
  /** Legacy emoji / text glyph before the label */
  icon?: string;
  /** Optional Ionicons before title; Continue chevron still trails by default */
  leftIconName?: IconGlyphName;
  leftIconSize?: number;
  showTrailingChevron?: boolean;
}

/** Auth & global primary CTA — Archive 4 Continue glass + `chevron-forward`. */
export default function WWPrimaryButton({
  title,
  onPress,
  disabled = false,
  loading = false,
  style,
  textStyle,
  icon,
  leftIconName,
  leftIconSize = 20,
  showTrailingChevron = true,
}: WWPrimaryButtonProps) {
  let leading: ReactNode = null;
  if (leftIconName) {
    leading = <Ionicons name={leftIconName} size={leftIconSize} color={colors.textOnDarkPrimary} />;
  } else if (icon) {
    leading = <Text style={styles.iconEmoji}>{icon}</Text>;
  }

  return (
    <ContinueCTAButton
      accentColor={colors.SKY}
      title={title}
      onPress={onPress}
      disabled={disabled}
      loading={loading}
      style={style}
      textStyle={textStyle}
      variant="primary"
      leading={leading}
      showTrailingChevron={showTrailingChevron}
    />
  );
}

const styles = StyleSheet.create({
  iconEmoji: {
    fontSize: 18,
    marginRight: 0,
  },
});
