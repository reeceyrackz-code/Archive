import React from 'react';
import { ViewStyle, StyleSheet, View } from 'react-native';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import {
  ICON_SIZE,
} from '../../constants/premiumTokens';
import ContinueCTAButton from '../ui/ContinueCTAButton';

interface ActionButtonProps {
  title: string;
  onPress: () => void;
  icon?: React.ReactNode;
  style?: ViewStyle;
  variant?: 'primary' | 'secondary';
}

export default function ActionButton({
  title,
  onPress,
  icon,
  style,
  variant = 'primary',
}: Readonly<ActionButtonProps>) {
  const { theme } = useAccountTheme();
  const accentColor = theme.primary ?? theme.primaryAlt ?? '#237AE6';
  const leading = icon ? <View style={styles.iconWrap}>{icon}</View> : undefined;

  return (
    <ContinueCTAButton
      title={title}
      onPress={onPress}
      accentColor={accentColor}
      variant={variant}
      leading={leading}
      style={style}
    />
  );
}

const styles = StyleSheet.create({
  iconWrap: {
    width: ICON_SIZE,
    height: ICON_SIZE,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
