import React from 'react';
import { View, Text, StyleSheet, ViewStyle } from 'react-native';
import PremiumCard from './PremiumCard';
import {
  HERO_TITLE_SIZE,
  HERO_NUMBER_SIZE,
  HERO_SUBTITLE_SIZE,
  ICON_GAP,
  ICON_SIZE,
} from '../../constants/premiumTokens';
import { useAccountTheme } from '../shared/AccountThemeProvider';

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  /** Optional trend label (e.g. "+18%", "+£42 vs yesterday") */
  trend?: string;
  trendPositive?: boolean;
  icon?: React.ReactNode;
  style?: ViewStyle;
  onPress?: () => void;
  entranceDelay?: number;
}

export default function StatCard({
  title,
  value,
  subtitle,
  trend,
  trendPositive = true,
  icon,
  style,
  onPress,
  entranceDelay,
}: StatCardProps) {
  const { theme } = useAccountTheme();
  const textColor = theme.textPrimary ?? '#F1F5F9';
  const secondaryColor = theme.textSecondary ?? 'rgba(241,245,249,0.88)';
  const tertiaryColor = theme.textOnBackground ?? 'rgba(241,245,249,0.7)';
  const accent = theme.primary ?? '#87CEEB';
  const trendColor = trendPositive ? '#34D399' : 'rgba(248,113,113,0.95)';

  return (
    <PremiumCard onPress={onPress} style={style} entranceDelay={entranceDelay}>
      <View style={styles.row}>
        {icon ? (
          <View style={[styles.iconWrap, { backgroundColor: `${accent}20` }]}>
            {icon}
          </View>
        ) : null}
        <View style={styles.content}>
          <Text style={[styles.title, { color: tertiaryColor }]} numberOfLines={1}>
            {title}
          </Text>
          <View style={styles.valueRow}>
            <Text style={[styles.value, { color: textColor }]} numberOfLines={1}>
              {value}
            </Text>
            {trend != null && trend !== '' ? (
              <Text style={[styles.trend, { color: trendColor }]} numberOfLines={1}>
                {trend}
              </Text>
            ) : null}
          </View>
          {subtitle != null && subtitle !== '' ? (
            <Text style={[styles.subtitle, { color: secondaryColor }]} numberOfLines={1}>
              {subtitle}
            </Text>
          ) : null}
        </View>
      </View>
    </PremiumCard>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconWrap: {
    width: 44,
    height: 44,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: ICON_GAP,
  },
  content: {
    flex: 1,
  },
  title: {
    fontSize: HERO_TITLE_SIZE,
    fontWeight: '600',
    letterSpacing: 0.2,
    marginBottom: 4,
  },
  valueRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: 8,
    flexWrap: 'wrap',
  },
  value: {
    fontSize: HERO_NUMBER_SIZE,
    fontWeight: '800',
    letterSpacing: -0.5,
    marginBottom: 2,
  },
  trend: {
    fontSize: HERO_SUBTITLE_SIZE,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  subtitle: {
    fontSize: HERO_SUBTITLE_SIZE,
    fontWeight: '500',
  },
});
