import React from 'react';
import { View, Text, StyleSheet, ViewStyle, TouchableOpacity } from 'react-native';
import type { IconGlyphName } from '../shared/iconGlyphTypes';
import GradientIconBox from '../shared/GradientIconBox';
import { accentToGradient } from '../../utils/accentGradient';
import { SCREEN_PADDING_H, SECTION_GAP, CARD_GAP } from '../../constants/premiumTokens';
import { useAccountTheme } from '../shared/AccountThemeProvider';

interface PremiumEmptyStateProps {
  icon?: IconGlyphName;
  title: string;
  message: string;
  actionLabel?: string;
  onAction?: () => void;
  style?: ViewStyle;
}

export default function PremiumEmptyState({
  icon = 'document-text-outline',
  title,
  message,
  actionLabel,
  onAction,
  style,
}: PremiumEmptyStateProps) {
  const { theme } = useAccountTheme();
  const textColor = theme.textPrimary ?? '#F1F5F9';
  const secondaryColor = theme.textSecondary ?? 'rgba(241,245,249,0.88)';
  const accent = theme.primary ?? '#87CEEB';

  return (
    <View style={[styles.wrap, style]}>
      <View style={styles.iconWrap}>
        <GradientIconBox icon={icon} colors={accentToGradient(accent)} boxSize={72} size={36} />
      </View>
      <Text style={[styles.title, { color: textColor }]}>{title}</Text>
      <Text style={[styles.message, { color: secondaryColor }]}>{message}</Text>
      {actionLabel != null && onAction != null && (
        <TouchableOpacity onPress={onAction} activeOpacity={0.8}>
          <Text style={[styles.action, { color: accent }]}>{actionLabel}</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    alignItems: 'center',
    paddingVertical: SECTION_GAP,
    paddingHorizontal: SCREEN_PADDING_H,
  },
  iconWrap: {
    width: 80,
    height: 80,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: CARD_GAP,
  },
  title: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 8,
    textAlign: 'center',
  },
  message: {
    fontSize: 14,
    fontWeight: '500',
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 16,
  },
  action: {
    fontSize: 16,
    fontWeight: '700',
  },
});
