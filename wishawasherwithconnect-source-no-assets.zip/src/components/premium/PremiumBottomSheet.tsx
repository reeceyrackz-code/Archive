import React, { useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  Pressable,
  Dimensions,
  Animated,
  PanResponder,
  ViewStyle,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { BOTTOM_SHEET } from '../../constants/premiumTokens';
import { HEADER_STYLE_CARD_GRADIENT, HEADER_STYLE_CARD_BORDER, BOOKING_SHEET_DARK_OVERLAY, BOOKING_SHEET_BLUR_INTENSITY } from '../../constants/bookingCardTheme';

const { height: SCREEN_HEIGHT } = Dimensions.get('window');

/** Height of the app tab bar so the sheet can extend over it when needed. */
const TAB_BAR_HEIGHT = 72;

const DRAG_CLOSE_THRESHOLD = 80;
const DRAG_VELOCITY_THRESHOLD = 0.3;

interface PremiumBottomSheetProps {
  visible: boolean;
  onClose: () => void;
  children: React.ReactNode;
  title?: string;
  style?: ViewStyle;
  heightRatio?: number;
  /** When false, no dimmed backdrop (e.g. map stays visible). Default true. */
  showBackdrop?: boolean;
  /** When true, sheet extends to the very bottom of the screen, sitting on top of the tab bar. */
  extendOverTabBar?: boolean;
}

export default function PremiumBottomSheet({
  visible,
  onClose,
  children,
  title,
  style,
  heightRatio = 0.5,
  showBackdrop = true,
  extendOverTabBar = false,
}: PremiumBottomSheetProps) {
  const insets = useSafeAreaInsets();
  const slideAnim = useRef(new Animated.Value(SCREEN_HEIGHT)).current;
  const dragOffset = useRef(new Animated.Value(0)).current;
  const backdropOpacity = useRef(new Animated.Value(0)).current;

  const baseHeight = Math.min(SCREEN_HEIGHT * heightRatio, SCREEN_HEIGHT - insets.top - 80);
  const sheetHeight = extendOverTabBar ? baseHeight + TAB_BAR_HEIGHT : baseHeight;
  const paddingBottom = extendOverTabBar ? insets.bottom + 20 + TAB_BAR_HEIGHT : insets.bottom + 20;

  const translateY = useMemo(
    () => Animated.add(slideAnim, dragOffset),
    [slideAnim, dragOffset],
  );

  const panResponder = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => true,
        onMoveShouldSetPanResponder: (_, gestureState) => Math.abs(gestureState.dy) > 5,
        onPanResponderGrant: () => {},
        onPanResponderMove: (_, gestureState) => {
          const { dy } = gestureState;
          const clamped = Math.max(-120, Math.min(sheetHeight, dy));
          dragOffset.setValue(clamped);
        },
        onPanResponderRelease: (_, gestureState) => {
          const { dy, vy } = gestureState;
          const shouldClose =
            dy > DRAG_CLOSE_THRESHOLD || (dy > 30 && vy > DRAG_VELOCITY_THRESHOLD);
          if (shouldClose) {
            Animated.parallel([
              Animated.timing(dragOffset, {
                toValue: 0,
                duration: 150,
                useNativeDriver: true,
              }),
              Animated.timing(slideAnim, {
                toValue: SCREEN_HEIGHT,
                duration: 220,
                useNativeDriver: true,
              }),
              Animated.timing(backdropOpacity, {
                toValue: 0,
                duration: 200,
                useNativeDriver: true,
              }),
            ]).start(() => onClose());
          } else {
            Animated.spring(dragOffset, {
              toValue: 0,
              useNativeDriver: true,
              damping: 25,
              stiffness: 300,
            }).start();
          }
        },
      }),
    [sheetHeight, slideAnim, dragOffset, backdropOpacity, onClose],
  );

  useEffect(() => {
    if (visible) {
      dragOffset.setValue(0);
      Animated.parallel([
        Animated.spring(slideAnim, {
          toValue: 0,
          useNativeDriver: true,
          damping: 20,
          stiffness: 200,
        }),
        Animated.timing(backdropOpacity, {
          toValue: 1,
          duration: 200,
          useNativeDriver: true,
        }),
      ]).start();
    } else {
      Animated.parallel([
        Animated.timing(slideAnim, {
          toValue: SCREEN_HEIGHT,
          duration: 250,
          useNativeDriver: true,
        }),
        Animated.timing(backdropOpacity, {
          toValue: 0,
          duration: 200,
          useNativeDriver: true,
        }),
      ]).start();
    }
  }, [visible, slideAnim, dragOffset, backdropOpacity]);

  return (
    <Modal
      visible={visible}
      transparent
      animationType="none"
      onRequestClose={onClose}
    >
      {showBackdrop ? (
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose}>
          <Animated.View
            style={[
              StyleSheet.absoluteFill,
              styles.backdrop,
              { opacity: backdropOpacity },
            ]}
          />
        </Pressable>
      ) : (
        <Animated.View
          pointerEvents="none"
          style={[StyleSheet.absoluteFill, { opacity: backdropOpacity }]}
        />
      )}
      <Animated.View
        style={[
          styles.sheet,
          {
            height: sheetHeight,
            paddingBottom,
            borderTopLeftRadius: BOTTOM_SHEET.borderTopLeftRadius,
            borderTopRightRadius: BOTTOM_SHEET.borderTopRightRadius,
            borderTopWidth: 1,
            borderLeftWidth: 1,
            borderRightWidth: 1,
            borderColor: HEADER_STYLE_CARD_BORDER,
            transform: [{ translateY }],
          },
          style,
        ]}
      >
        <Pressable onPress={(e) => e.stopPropagation()} style={styles.sheetInner}>
          <BlurView intensity={BOOKING_SHEET_BLUR_INTENSITY} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
          <LinearGradient
            colors={HEADER_STYLE_CARD_GRADIENT as [string, string]}
            start={{ x: 0, y: 0 }}
            end={{ x: 0, y: 1 }}
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
          />
          <View style={[StyleSheet.absoluteFill, styles.sheetDarkOverlay]} pointerEvents="none" />
          <View style={styles.handleWrap} {...panResponder.panHandlers}>
            <View style={styles.handleBar} />
          </View>
          {title != null ? (
            <Text style={styles.title}>{title}</Text>
          ) : null}
          <View style={styles.content}>{children}</View>
        </Pressable>
      </Animated.View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: {
    backgroundColor: 'rgba(0,0,0,0.75)',
  },
  sheet: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.2,
    shadowRadius: 16,
    elevation: 24,
  },
  sheetInner: {
    flex: 1,
    overflow: 'hidden',
    paddingTop: 4,
    paddingHorizontal: 20,
    paddingBottom: 8,
  },
  sheetDarkOverlay: {
    backgroundColor: BOOKING_SHEET_DARK_OVERLAY,
  },
  handleWrap: {
    alignSelf: 'stretch',
    paddingVertical: 8,
    paddingHorizontal: 20,
    marginHorizontal: -20,
    marginBottom: 2,
    alignItems: 'center',
  },
  handleBar: {
    width: BOTTOM_SHEET.handleBarWidth,
    height: BOTTOM_SHEET.handleBarHeight,
    borderRadius: 2,
    backgroundColor: 'rgba(255,255,255,0.25)',
  },
  title: {
    fontSize: 18,
    fontWeight: '700',
    color: 'rgba(255,255,255,0.95)',
    marginBottom: 10,
  },
  content: {
    flex: 1,
  },
});
