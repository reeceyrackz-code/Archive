import React, { useCallback, useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  Pressable,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Alert,
} from 'react-native';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { washCompletionService, WashCompletion } from '../../services/WashCompletionService';
import { colors } from '../../constants/colors';
import { hapticFeedback } from '../../services/HapticFeedbackService';

export interface WashRatingAndTipProps {
  washCompletionId: string;
  visible: boolean;
  onClose: () => void;
  /** Called after rating + tip are saved locally */
  onSubmitted?: () => void;
}

const TIP_OPTIONS_GBP = [0, 2, 5, 10, 20];

export default function WashRatingAndTip({
  washCompletionId,
  visible,
  onClose,
  onSubmitted,
}: Readonly<WashRatingAndTipProps>) {
  const insets = useSafeAreaInsets();
  const [washCompletion, setWashCompletion] = useState<WashCompletion | null>(null);
  const [loading, setLoading] = useState(true);
  const [rating, setRating] = useState(0);
  const [review, setReview] = useState('');
  const [tipAmount, setTipAmount] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const loadWashCompletion = useCallback(async () => {
    if (!washCompletionId) return;
    setLoading(true);
    setLoadError(null);
    try {
      const completion = await washCompletionService.getWashCompletion(washCompletionId);
      setWashCompletion(completion);
      if (!completion) {
        setLoadError('Could not load this wash completion. It may not be available on this build yet.');
      }
    } catch (error) {
      console.error('Error loading wash completion:', error);
      setWashCompletion(null);
      setLoadError('Could not load this wash completion right now. Please try again.');
    } finally {
      setLoading(false);
    }
  }, [washCompletionId]);

  useEffect(() => {
    if (visible && washCompletionId) {
      setSubmitError(null);
      setRating(0);
      setReview('');
      setTipAmount(0);
      loadWashCompletion();
    }
  }, [visible, washCompletionId, loadWashCompletion]);

  const handleSubmit = async () => {
    if (rating < 1) {
      return;
    }
    if (!review.trim()) {
      return;
    }
    setSubmitting(true);
    setSubmitError(null);
    try {
      await hapticFeedback('medium');
      await washCompletionService.submitRating(washCompletionId, rating, review.trim(), tipAmount);
      await hapticFeedback('light');
      onSubmitted?.();
      onClose();
    } catch (error) {
      console.error('Error submitting wash rating:', error);
      setSubmitError('Could not submit rating right now. Please try again.');
      Alert.alert('Submission failed', 'Could not submit rating right now. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <KeyboardAvoidingView
        style={styles.overlay}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <Pressable style={styles.backdrop} onPress={onClose} />
        <View style={[styles.sheet, { paddingBottom: 16 + insets.bottom }]}>
          <View style={styles.handle} />
          <Text style={styles.title}>Rate your wash</Text>
          <Text style={styles.subtitle}>Share feedback and optionally add a tip for your Car Care Pro.</Text>

          {loading && (
            <View style={styles.centered}>
              <ActivityIndicator color={colors.SKY} />
            </View>
          )}
          {!loading && washCompletion === null && (
            <>
              <Text style={styles.errorText}>{loadError ?? 'Could not load this wash completion.'}</Text>
              <TouchableOpacity style={styles.retryBtn} onPress={loadWashCompletion}>
                <Ionicons name="refresh" size={16} color={colors.SKY} />
                <Text style={styles.retryText}>Retry</Text>
              </TouchableOpacity>
            </>
          )}
          {!loading && washCompletion !== null && (
            <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
              <View style={styles.starsRow}>
                {[1, 2, 3, 4, 5].map((star) => (
                  <TouchableOpacity
                    key={star}
                    onPress={async () => {
                      await hapticFeedback('light');
                      setRating(star);
                    }}
                    hitSlop={8}
                  >
                    <Ionicons
                      name={star <= rating ? 'star' : 'star-outline'}
                      size={36}
                      color={star <= rating ? '#FBBF24' : 'rgba(148,163,184,0.6)'}
                    />
                  </TouchableOpacity>
                ))}
              </View>

              <TextInput
                style={styles.reviewInput}
                placeholder="Tell us about your experience... (e.g., Great service, car looks amazing, very professional)"
                placeholderTextColor="#87CEEB"
                multiline
                value={review}
                onChangeText={setReview}
                textAlignVertical="top"
              />

              <Text style={styles.tipLabel}>Tip (optional)</Text>
              <View style={styles.tipRow}>
                {TIP_OPTIONS_GBP.map((amt) => (
                  <TouchableOpacity
                    key={amt}
                    style={[styles.tipChip, tipAmount === amt && styles.tipChipActive]}
                    onPress={async () => {
                      await hapticFeedback('light');
                      setTipAmount(amt);
                    }}
                  >
                    <Text style={[styles.tipChipText, tipAmount === amt && styles.tipChipTextActive]}>
                      {amt === 0 ? 'None' : `£${amt}`}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              <TouchableOpacity
                style={[styles.submitBtn, (rating < 1 || !review.trim() || submitting) && styles.submitBtnDisabled]}
                disabled={rating < 1 || !review.trim() || submitting}
                onPress={handleSubmit}
              >
                {submitting ? (
                  <ActivityIndicator color="#0f172a" />
                ) : (
                  <Text style={styles.submitText}>Submit</Text>
                )}
              </TouchableOpacity>
              {submitError ? <Text style={styles.errorText}>{submitError}</Text> : null}
            </ScrollView>
          )}
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  backdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  sheet: {
    backgroundColor: colors.BG,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingHorizontal: 20,
    paddingTop: 12,
    maxHeight: '88%',
  },
  handle: {
    alignSelf: 'center',
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(148,163,184,0.4)',
    marginBottom: 12,
  },
  title: {
    fontSize: 22,
    fontWeight: '700',
    color: colors.textOnDarkPrimary,
    marginBottom: 6,
  },
  subtitle: {
    fontSize: 14,
    color: colors.textOnDarkSecondary,
    marginBottom: 16,
  },
  centered: {
    paddingVertical: 24,
    alignItems: 'center',
  },
  errorText: {
    color: '#fca5a5',
    marginBottom: 16,
  },
  retryBtn: {
    alignSelf: 'flex-start',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.35)',
    borderRadius: 10,
    paddingHorizontal: 10,
    paddingVertical: 8,
    marginBottom: 16,
  },
  retryText: { color: colors.SKY, fontWeight: '700' },
  starsRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 8,
    marginBottom: 16,
  },
  reviewInput: {
    minHeight: 100,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.35)',
    borderRadius: 12,
    padding: 12,
    color: colors.textOnDarkPrimary,
    fontSize: 15,
    marginBottom: 16,
  },
  tipLabel: {
    fontSize: 15,
    fontWeight: '600',
    color: colors.textOnDarkPrimary,
    marginBottom: 8,
  },
  tipRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 20,
  },
  tipChip: {
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.4)',
    backgroundColor: 'rgba(255,255,255,0.04)',
  },
  tipChipActive: {
    borderColor: colors.SKY,
    backgroundColor: 'rgba(135,206,235,0.15)',
  },
  tipChipText: {
    color: colors.textOnDarkSecondary,
    fontWeight: '600',
  },
  tipChipTextActive: {
    color: colors.textOnDarkPrimary,
  },
  submitBtn: {
    backgroundColor: colors.SKY,
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 8,
  },
  submitBtnDisabled: {
    opacity: 0.45,
  },
  submitText: {
    color: '#0f172a',
    fontSize: 16,
    fontWeight: '700',
  },
});
