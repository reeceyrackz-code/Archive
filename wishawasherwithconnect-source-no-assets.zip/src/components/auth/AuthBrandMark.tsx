import React from 'react';
import { View, Text, StyleSheet, Platform } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import { colors } from '../../constants/colors';
import { BOOKING_CONTINUE_RADIUS, bookingContinueChromeBorder } from '../../utils/bookingContinueStyle';

/**
 * Auth hero mark: Continue-style glass frame + car icon (replaces static PNG).
 */
export default function AuthBrandMark() {
  const rim = bookingContinueChromeBorder(colors.SKY);
  return (
    <View style={styles.wrap} accessibilityRole="image" accessibilityLabel="Provider Car Care">
      <View style={[styles.frame, { borderColor: rim }]}>
        <BlurView
          intensity={Platform.OS === 'ios' ? 26 : 20}
          tint="dark"
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
          {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
        />
        <LinearGradient
          colors={['rgba(135,206,235,0.42)', 'rgba(15,40,71,0.72)']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
        />
        <LinearGradient
          colors={['rgba(255,255,255,0.2)', 'transparent']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.sheen}
          pointerEvents="none"
        />
        <View style={styles.inner}>
          <Ionicons name="car-sport" size={40} color={colors.textOnDarkPrimary} />
          <Text style={styles.wordmark}>Car Care</Text>
          <Text style={styles.tag}>Provider</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { alignItems: 'center', marginBottom: 4 },
  sheen: { ...StyleSheet.absoluteFillObject },
  frame: {
    width: 112,
    height: 112,
    borderRadius: BOOKING_CONTINUE_RADIUS,
    overflow: 'hidden',
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sheen: { ...StyleSheet.absoluteFillObject },
  inner: { alignItems: 'center', justifyContent: 'center', gap: 2, paddingVertical: 8 },
  wordmark: {
    color: colors.textOnDarkPrimary,
    fontSize: 15,
    fontWeight: '900',
    letterSpacing: 0.8,
    marginTop: 4,
  },
  tag: {
    color: 'rgba(255,255,255,0.72)',
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1.4,
    textTransform: 'uppercase',
  },
});
