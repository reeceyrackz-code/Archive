/**
 * Persists booking IDs for chats the user has deleted, so they don't show in the inbox.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';

const KEY = 'deleted_chat_booking_ids';

export async function addDeletedChatBookingId(bookingId: string): Promise<void> {
  const ids = await getDeletedChatBookingIds();
  if (ids.has(bookingId)) return;
  ids.add(bookingId);
  await AsyncStorage.setItem(KEY, JSON.stringify([...ids]));
}

export async function getDeletedChatBookingIds(): Promise<Set<string>> {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    if (!raw) return new Set();
    const arr = JSON.parse(raw) as string[];
    return new Set(Array.isArray(arr) ? arr : []);
  } catch {
    return new Set();
  }
}

export async function addMultipleDeletedChatBookingIds(bookingIds: string[]): Promise<void> {
  const ids = await getDeletedChatBookingIds();
  let changed = false;
  for (const id of bookingIds) {
    if (!ids.has(id)) {
      ids.add(id);
      changed = true;
    }
  }
  if (changed) {
    await AsyncStorage.setItem(KEY, JSON.stringify([...ids]));
  }
}
