import { supabase } from '../lib/supabase';

export type TermsStatus = 'pending' | 'accepted' | 'declined';
export type StripeConnectStatus =
  | 'not_started'
  | 'in_progress'
  | 'completed'
  | 'restricted'
  | 'rejected';

export type BusinessOnboardingStatus = {
  termsStatus: TermsStatus;
  termsVersion: string | null;
  termsAcceptedAt: string | null;
  termsDeclinedAt: string | null;
  stripeConnectStatus: StripeConnectStatus;
  stripeAccountId: string | null;
  stripeOnboardingStartedAt: string | null;
  stripeOnboardingCompletedAt: string | null;
  stripeDetails: Record<string, any>;
};

const DEFAULT_STATUS: BusinessOnboardingStatus = {
  termsStatus: 'pending',
  termsVersion: null,
  termsAcceptedAt: null,
  termsDeclinedAt: null,
  stripeConnectStatus: 'not_started',
  stripeAccountId: null,
  stripeOnboardingStartedAt: null,
  stripeOnboardingCompletedAt: null,
  stripeDetails: {},
};

const nowIso = () => new Date().toISOString();

const normalize = (row: any): BusinessOnboardingStatus => ({
  termsStatus: (row?.terms_status || 'pending') as TermsStatus,
  termsVersion: row?.terms_version ?? null,
  termsAcceptedAt: row?.terms_accepted_at ?? null,
  termsDeclinedAt: row?.terms_declined_at ?? null,
  stripeConnectStatus: (row?.stripe_connect_status || 'not_started') as StripeConnectStatus,
  stripeAccountId: row?.stripe_account_id ?? null,
  stripeOnboardingStartedAt: row?.stripe_onboarding_started_at ?? null,
  stripeOnboardingCompletedAt: row?.stripe_onboarding_completed_at ?? null,
  stripeDetails: row?.stripe_details && typeof row.stripe_details === 'object' ? row.stripe_details : {},
});

export const businessOnboardingService = {
  async getStatus(userId: string): Promise<BusinessOnboardingStatus> {
    const { data, error } = await supabase
      .from('profiles')
      .select(
        'terms_status,terms_version,terms_accepted_at,terms_declined_at,stripe_connect_status,stripe_account_id,stripe_onboarding_started_at,stripe_onboarding_completed_at,stripe_details'
      )
      .eq('id', userId)
      .maybeSingle();

    if (error) throw error;
    if (!data) return DEFAULT_STATUS;
    return normalize(data);
  },

  async acceptTerms(userId: string, termsVersion = 'v1.0'): Promise<void> {
    const { error } = await supabase
      .from('profiles')
      .update({
        terms_status: 'accepted',
        terms_version: termsVersion,
        terms_accepted_at: nowIso(),
        terms_declined_at: null,
      } as any)
      .eq('id', userId);

    if (error) throw error;
  },

  async declineTerms(userId: string, termsVersion = 'v1.0'): Promise<void> {
    const { error } = await supabase
      .from('profiles')
      .update({
        terms_status: 'declined',
        terms_version: termsVersion,
        terms_declined_at: nowIso(),
      } as any)
      .eq('id', userId);

    if (error) throw error;
  },

  async startStripeConnect(userId: string, details?: Record<string, any>): Promise<void> {
    const status = await this.getStatus(userId);
    const nextDetails = { ...(status.stripeDetails || {}), ...(details || {}) };
    const { error } = await supabase
      .from('profiles')
      .update({
        stripe_connect_status: 'in_progress',
        stripe_onboarding_started_at: status.stripeOnboardingStartedAt || nowIso(),
        stripe_details: nextDetails,
      } as any)
      .eq('id', userId);

    if (error) throw error;
  },

  async completeStripeConnect(
    userId: string,
    params: { stripeAccountId: string; details?: Record<string, any> }
  ): Promise<void> {
    const status = await this.getStatus(userId);
    const nextDetails = { ...(status.stripeDetails || {}), ...(params.details || {}) };

    const { error } = await supabase
      .from('profiles')
      .update({
        stripe_connect_status: 'completed',
        stripe_account_id: params.stripeAccountId,
        stripe_onboarding_started_at: status.stripeOnboardingStartedAt || nowIso(),
        stripe_onboarding_completed_at: nowIso(),
        stripe_details: nextDetails,
      } as any)
      .eq('id', userId);

    if (error) throw error;
  },

  async setStripeSkipForNow(userId: string, skipped: boolean): Promise<void> {
    const status = await this.getStatus(userId);
    const nextDetails = {
      ...(status.stripeDetails || {}),
      skipped_for_now: skipped,
      skipped_for_now_at: skipped ? nowIso() : null,
    };

    const { error } = await supabase
      .from('profiles')
      .update({
        stripe_details: nextDetails,
      } as any)
      .eq('id', userId);

    if (error) throw error;
  },
};
