import AsyncStorage from '@react-native-async-storage/async-storage';
import { Platform } from 'react-native';
import * as Calendar from 'expo-calendar';
import { getServiceDisplayName } from '../utils/serviceNameMapper';
import { loadCalendarSyncSettings } from './calendarSyncSettings';
import { syncValeterExternalCalendarBusyToSupabase } from './valeterExternalCalendarBusy';

type BookingCalendarItem = {
  id: string;
  status?: string;
  service_type?: string;
  service_name?: string;
  location_address?: string;
  /** Short location label from app (e.g. area + postcode) */
  formatted_location?: string;
  customer_name?: string;
  price?: number;
  scheduled_at?: string;
  request_sent_at?: string;
  vehicle_registration?: string | null;
  vehicle_make?: string | null;
  vehicle_model?: string | null;
  vehicle_info?: string | null;
  vehicle_type?: string | null;
  location_lat?: number | null;
  location_lng?: number | null;
};

const CALENDAR_NAME = 'Wish a Wash Bookings';
const CALENDAR_COLOR = '#38BDF8';
const CALENDAR_ID_KEY = '@waw_calendar_id';

function eventMapKey(userId: string): string {
  return `@waw_calendar_event_map_${userId}`;
}

function parseBookingStartIso(booking: BookingCalendarItem): string {
  const candidates = [booking.scheduled_at, booking.request_sent_at].filter(Boolean) as string[];
  for (const src of candidates) {
    const d = new Date(src);
    if (!Number.isNaN(d.getTime())) {
      return d.toISOString();
    }
  }
  // Accepted/scheduled job with no parseable time — anchor to next half-hour so it still appears on calendar
  const now = new Date();
  now.setMinutes(Math.ceil(now.getMinutes() / 30) * 30, 0, 0);
  if (now.getTime() <= Date.now()) {
    now.setMinutes(now.getMinutes() + 30);
  }
  return now.toISOString();
}

function humanStatus(status: string | undefined): string {
  if (!status) return 'Unknown';
  const map: Record<string, string> = {
    pending_payment: 'Accepted — awaiting customer payment',
    confirmed: 'Confirmed',
    scheduled: 'Scheduled',
    en_route: 'En route',
    arrived: 'Arrived',
    in_progress: 'In progress',
  };
  return map[status] ?? status.replaceAll('_', ' ');
}

function eventDurationHours(booking: BookingCalendarItem): number {
  const name = getServiceDisplayName(booking.service_type, booking.service_name).toLowerCase();
  if (name.includes('detail') || name.includes('ceramic') || name.includes('full')) return 2;
  return 1;
}

function endIsoFromStart(startIso: string, booking: BookingCalendarItem): string {
  const d = new Date(startIso);
  d.setHours(d.getHours() + eventDurationHours(booking));
  return d.toISOString();
}

function eventTitle(booking: BookingCalendarItem): string {
  const service = getServiceDisplayName(booking.service_type, booking.service_name);
  const who = booking.customer_name?.trim();
  if (who) {
    return `Wish a Wash: ${service} — ${who}`;
  }
  return `Wish a Wash: ${service}`;
}

function mapsUrl(booking: BookingCalendarItem): string | null {
  const lat = booking.location_lat;
  const lng = booking.location_lng;
  if (lat == null || lng == null || Number.isNaN(Number(lat)) || Number.isNaN(Number(lng))) {
    return null;
  }
  const q = `${lat},${lng}`;
  return `https://maps.google.com/?q=${encodeURIComponent(q)}`;
}

function eventNotes(booking: BookingCalendarItem): string {
  const service = getServiceDisplayName(booking.service_type, booking.service_name);
  const address =
    [booking.location_address, booking.formatted_location].find((s) => s && String(s).trim()) ?? '';
  const vehicleParts = [
    booking.vehicle_registration,
    booking.vehicle_make,
    booking.vehicle_model,
    booking.vehicle_type,
    booking.vehicle_info,
  ].filter((s) => s && String(s).trim());
  const vehicleLine = vehicleParts.length > 0 ? vehicleParts.join(' · ') : null;
  const mapLink = mapsUrl(booking);

  const bits = [
    `Service: ${service}`,
    address ? `Location:\n${address}` : null,
    booking.customer_name ? `Customer: ${booking.customer_name}` : null,
    vehicleLine ? `Vehicle: ${vehicleLine}` : null,
    booking.price == null ? null : `Price: £${Number(booking.price).toFixed(2)}`,
    `Status: ${humanStatus(booking.status)}`,
    booking.scheduled_at ? `Scheduled for: ${new Date(booking.scheduled_at).toLocaleString('en-GB')}` : null,
    mapLink ? `Maps: ${mapLink}` : null,
    booking.id ? `Booking ID: ${booking.id}` : null,
  ].filter(Boolean);
  return bits.join('\n\n');
}

function eventLocationField(booking: BookingCalendarItem): string {
  const full = booking.location_address?.trim();
  if (full) return full;
  const short = booking.formatted_location?.trim();
  if (short) return short;
  return 'Wish a Wash job — open app for address';
}

/** Valeter has accepted or job is scheduled onward (not open marketplace requests). */
function shouldBeInCalendar(status: string | undefined): boolean {
  if (!status) return false;
  return [
    'pending_payment',
    'confirmed',
    'scheduled',
    'en_route',
    'arrived',
    'in_progress',
  ].includes(status);
}

async function getDefaultSourceId(): Promise<string | null> {
  const defaultCalendar = await Calendar.getDefaultCalendarAsync();
  if (defaultCalendar?.source?.id) return defaultCalendar.source.id;
  const sources = await Calendar.getSourcesAsync();
  const local = sources.find((s) => s.type === Calendar.SourceType.LOCAL);
  return local?.id ?? null;
}

async function ensureCalendarId(): Promise<string | null> {
  const cached = await AsyncStorage.getItem(CALENDAR_ID_KEY);
  if (cached) {
    try {
      const calendars = await Calendar.getCalendarsAsync(Calendar.EntityTypes.EVENT);
      const existing = calendars.find((c) => c.id === cached);
      if (existing?.id) return existing.id;
    } catch {
      // ignore and recreate
    }
  }

  const calendars = await Calendar.getCalendarsAsync(Calendar.EntityTypes.EVENT);
  const existingByName = calendars.find((c) => c.name === CALENDAR_NAME);
  if (existingByName?.id) {
    await AsyncStorage.setItem(CALENDAR_ID_KEY, existingByName.id);
    return existingByName.id;
  }

  if (Platform.OS === 'ios') {
    const sourceId = await getDefaultSourceId();
    if (!sourceId) return null;
    const newId = await Calendar.createCalendarAsync({
      title: CALENDAR_NAME,
      name: CALENDAR_NAME,
      color: CALENDAR_COLOR,
      entityType: Calendar.EntityTypes.EVENT,
      sourceId,
      source: { id: sourceId, type: Calendar.SourceType.LOCAL, name: CALENDAR_NAME },
      ownerAccount: 'personal',
      accessLevel: Calendar.CalendarAccessLevel.OWNER,
    });
    await AsyncStorage.setItem(CALENDAR_ID_KEY, newId);
    return newId;
  }

  const newId = await Calendar.createCalendarAsync({
    title: CALENDAR_NAME,
    name: CALENDAR_NAME,
    color: CALENDAR_COLOR,
    entityType: Calendar.EntityTypes.EVENT,
    ownerAccount: 'personal',
    accessLevel: Calendar.CalendarAccessLevel.OWNER,
    sourceId: undefined,
  });
  await AsyncStorage.setItem(CALENDAR_ID_KEY, newId);
  return newId;
}

async function loadEventMap(userId: string): Promise<Record<string, string>> {
  try {
    const raw = await AsyncStorage.getItem(eventMapKey(userId));
    if (!raw) return {};
    const parsed = JSON.parse(raw) as Record<string, string>;
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

async function saveEventMap(userId: string, map: Record<string, string>): Promise<void> {
  await AsyncStorage.setItem(eventMapKey(userId), JSON.stringify(map));
}

function buildAlarms(reminderMinutes: number[]): Array<{ relativeOffset: number }> {
  const unique = [...new Set(reminderMinutes)].filter((v) => v > 0);
  if (unique.length > 0) {
    return unique.map((minutes) => ({ relativeOffset: -minutes }));
  }
  return [{ relativeOffset: -30 }, { relativeOffset: -10 }];
}

async function removeMappedEvents(eventMap: Record<string, string>): Promise<void> {
  for (const eventId of Object.values(eventMap)) {
    try {
      await Calendar.deleteEventAsync(eventId);
    } catch {
      // ignore stale ids
    }
  }
}

async function upsertBookingEvent(
  calendarId: string,
  booking: BookingCalendarItem,
  eventMap: Record<string, string>,
  activeIds: Set<string>,
  alarms: Array<{ relativeOffset: number }>
): Promise<void> {
  if (!booking.id) return;

  const startIso = parseBookingStartIso(booking);
  const shouldKeep = shouldBeInCalendar(booking.status);
  const existingEventId = eventMap[booking.id];

  if (!shouldKeep) {
    if (existingEventId) {
      try {
        await Calendar.deleteEventAsync(existingEventId);
      } catch {
        // event may already be deleted
      }
      delete eventMap[booking.id];
    }
    return;
  }

  activeIds.add(booking.id);
  const details = {
    title: eventTitle(booking),
    location: eventLocationField(booking),
    notes: eventNotes(booking),
    startDate: new Date(startIso),
    endDate: new Date(endIsoFromStart(startIso, booking)),
    alarms,
  };

  if (existingEventId) {
    try {
      await Calendar.updateEventAsync(existingEventId, details);
    } catch {
      const created = await Calendar.createEventAsync(calendarId, details);
      eventMap[booking.id] = created;
    }
    return;
  }

  const created = await Calendar.createEventAsync(calendarId, details);
  eventMap[booking.id] = created;
}

async function pruneOrphanedEvents(eventMap: Record<string, string>, activeIds: Set<string>): Promise<void> {
  for (const [bookingId, eventId] of Object.entries(eventMap)) {
    if (activeIds.has(bookingId)) continue;
    try {
      await Calendar.deleteEventAsync(eventId);
    } catch {
      // ignore stale event ids
    }
    delete eventMap[bookingId];
  }
}

export async function syncValeterBookingsToDeviceCalendar(
  userId: string,
  bookings: BookingCalendarItem[]
): Promise<void> {
  if (!userId || (Platform.OS !== 'ios' && Platform.OS !== 'android')) return;

  try {
    const permission = await Calendar.requestCalendarPermissionsAsync();
    if (permission.status !== 'granted') return;

    const settings = await loadCalendarSyncSettings(userId);
    const calendarId = await ensureCalendarId();
    if (!calendarId) return;

    const eventMap = await loadEventMap(userId);
    if (!settings.enabled) {
      await removeMappedEvents(eventMap);
      await saveEventMap(userId, {});
      await syncValeterExternalCalendarBusyToSupabase(userId, true);
      return;
    }

    const alarms = buildAlarms(settings.reminderMinutes);
    const activeIds = new Set<string>();

    for (const booking of bookings) {
      await upsertBookingEvent(calendarId, booking, eventMap, activeIds, alarms);
    }



    await pruneOrphanedEvents(eventMap, activeIds);
    await saveEventMap(userId, eventMap);
    await syncValeterExternalCalendarBusyToSupabase(userId, true);
  } catch (error) {
    console.warn('[CalendarSync] failed to sync bookings:', error);
  }
}