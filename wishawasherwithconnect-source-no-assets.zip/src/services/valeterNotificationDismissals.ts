import AsyncStorage from '@react-native-async-storage/async-storage';

const STORAGE_PREFIX = 'valeter_notifications_dismissed_v1';

function keyForUser(userId: string) {
  return `${STORAGE_PREFIX}:${userId}`;
}

export async function loadDismissedValeterNotificationIds(userId: string): Promise<Set<string>> {
  try {
    const raw = await AsyncStorage.getItem(keyForUser(userId));
    if (!raw) return new Set();
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return new Set();
    return new Set(parsed.filter((id): id is string => typeof id === 'string'));
  } catch {
    return new Set();
  }
}

export async function saveDismissedValeterNotificationIds(userId: string, ids: Set<string>): Promise<void> {
  await AsyncStorage.setItem(keyForUser(userId), JSON.stringify([...ids]));
}

export async function dismissValeterNotificationIds(userId: string, idsToDismiss: string[]): Promise<Set<string>> {
  const next = await loadDismissedValeterNotificationIds(userId);
  idsToDismiss.forEach((id) => next.add(id));
  await saveDismissedValeterNotificationIds(userId, next);
  return next;
}
