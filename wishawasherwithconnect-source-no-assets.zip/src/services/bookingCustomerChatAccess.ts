import { supabase } from '../lib/supabase';

/**
 * Whether the customer has sent at least one in-app message for this booking.
 * Expects a `booking_messages` table with `booking_id` and `sender_id` (customer user id).
 * If the table is missing, returns false so the composer stays locked for completed jobs.
 */
export async function hasCustomerInboundChatMessage(
  bookingId: string,
  customerUserId: string | null | undefined
): Promise<boolean> {
  if (!bookingId || !customerUserId) return false;
  try {
    const { data, error } = await supabase
      .from('booking_messages')
      .select('id')
      .eq('booking_id', bookingId)
      .eq('sender_id', customerUserId)
      .limit(1);
    if (error) {
      if (typeof __DEV__ !== 'undefined' && __DEV__) {
        console.warn('[bookingCustomerChatAccess] booking_messages:', error.message);
      }
      return false;
    }
    return Array.isArray(data) && data.length > 0;
  } catch {
    return false;
  }
}

/** Business can open/send chat before completion; after completion only if the customer messaged first. */
export async function canBusinessUseBookingChat(
  bookingStatus: string,
  bookingId: string,
  customerUserId: string | null | undefined
): Promise<boolean> {
  const s = String(bookingStatus || '').toLowerCase();
  if (s !== 'completed') return true;
  return hasCustomerInboundChatMessage(bookingId, customerUserId);
}
