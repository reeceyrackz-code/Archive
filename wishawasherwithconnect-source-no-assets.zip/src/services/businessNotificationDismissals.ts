import AsyncStorage from '@react-native-async-storage/async-storage';

const STORAGE_PREFIX = 'business_notifications_dismissed_v1';

function keyForOrg(organizationId: string) {
  return `${STORAGE_PREFIX}:${organizationId}`;
}

export async function loadDismissedBusinessNotificationIds(organizationId: string): Promise<Set<string>> {
  try {
    const raw = await AsyncStorage.getItem(keyForOrg(organizationId));
    if (!raw) return new Set();
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return new Set();
    return new Set(parsed.filter((id): id is string => typeof id === 'string'));
  } catch {
    return new Set();
  }
}

export async function saveDismissedBusinessNotificationIds(
  organizationId: string,
  ids: Set<string>
): Promise<void> {
  await AsyncStorage.setItem(keyForOrg(organizationId), JSON.stringify([...ids]));
}

/** Add one or more notification ids to the dismissed set for this org. */
export async function dismissBusinessNotificationIds(
  organizationId: string,
  idsToDismiss: string[]
): Promise<Set<string>> {
  const next = await loadDismissedBusinessNotificationIds(organizationId);
  idsToDismiss.forEach((id) => next.add(id));
  await saveDismissedBusinessNotificationIds(organizationId, next);
  return next;
}

/** Remove every stored dismissal for this org (e.g. support / reset). */
export async function clearAllDismissedBusinessNotifications(organizationId: string): Promise<void> {
  await AsyncStorage.removeItem(keyForOrg(organizationId));
}
