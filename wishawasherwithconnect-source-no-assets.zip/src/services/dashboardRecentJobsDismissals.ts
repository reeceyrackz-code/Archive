import AsyncStorage from '@react-native-async-storage/async-storage';

const TTL_MS = 30 * 24 * 60 * 60 * 1000;

function storageKey(scope: 'business' | 'valeter', accountId: string) {
  return `dash_recent_jobs_dismiss_v1_${scope}_${accountId}`;
}

type DismissMap = Record<string, number>;

function parseAndPrune(raw: string | null, now: number): DismissMap {
  if (!raw) return {};
  try {
    const o = JSON.parse(raw) as DismissMap;
    const next: DismissMap = {};
    for (const [id, t] of Object.entries(o)) {
      if (typeof t === 'number' && now - t < TTL_MS) {
        next[id] = t;
      }
    }
    return next;
  } catch {
    return {};
  }
}

export async function loadDismissedRecentJobIds(
  scope: 'business' | 'valeter',
  accountId: string
): Promise<Set<string>> {
  if (!accountId) return new Set();
  const now = Date.now();
  const raw = await AsyncStorage.getItem(storageKey(scope, accountId));
  const pruned = parseAndPrune(raw, now);
  const serialized = JSON.stringify(pruned);
  if (serialized !== raw) {
    await AsyncStorage.setItem(storageKey(scope, accountId), serialized);
  }
  return new Set(Object.keys(pruned));
}

export async function dismissRecentJobFromDashboard(
  scope: 'business' | 'valeter',
  accountId: string,
  jobId: string
): Promise<void> {
  if (!accountId || !jobId) return;
  const now = Date.now();
  const raw = await AsyncStorage.getItem(storageKey(scope, accountId));
  const pruned = parseAndPrune(raw, now);
  pruned[jobId] = now;
  await AsyncStorage.setItem(storageKey(scope, accountId), JSON.stringify(pruned));
}
