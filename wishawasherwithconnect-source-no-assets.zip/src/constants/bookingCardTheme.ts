import { colors } from './colors';

/** Single curved radius for all booking cards */
const CARD_BORDER_RADIUS = 18;

/** Vertical position for card strip on map views */
export const CARD_STRIP_TOP = 156;

/** Bottom offset from tab bar for booking index cards */
export const BOOKING_INDEX_CARDS_BOTTOM_PADDING = 24;

/** Gradient matching AppHeader (premium navy glass) – use theme.headerBackground in tracking for exact match */
export const HEADER_STYLE_CARD_GRADIENT = [
  'rgba(10,25,41,0.72)',
  'rgba(5,13,20,0.82)',
] as [string, string];

/** Border color – matches AppHeader glass stroke; use theme.glassBorder in tracking */
export const HEADER_STYLE_CARD_BORDER = 'rgba(135,206,235,0.38)';

/** Header glass – gradient + border for bottom sheets to match AppHeader */
export const APP_HEADER_GLASS_GRADIENT = [
  'rgba(10,25,41,0.7)',
  'rgba(5,13,20,0.8)',
] as [string, string];
export const APP_HEADER_GLASS_BORDER = 'rgba(135,206,235,0.4)';

/** Sheet gradient matching header with more opacity (for pricing/settings sheets) */
export const SHEET_HEADER_GRADIENT = [
  'rgba(10,25,41,0.96)',
  'rgba(5,13,20,0.98)',
] as [string, string];
export const SHEET_HEADER_BORDER = 'rgba(135,206,235,0.35)';

/** @deprecated use SHEET_HEADER_GRADIENT */
export const BUSINESS_SHEET_GRADIENT = SHEET_HEADER_GRADIENT;

/** Dark overlay for tracking bottom sheets – premium glass, matches header depth */
export const BOOKING_SHEET_DARK_OVERLAY = 'rgba(0,0,0,0.36)';

/** Blur intensity for tracking sheets – sleek glass match to header */
export const BOOKING_SHEET_BLUR_INTENSITY = 32;

/** Sheet card look – border radius, padding */
export const BOOKING_SHEET_CARD_RADIUS = 16;
export const BOOKING_SHEET_CARD_PADDING = 14;
export const BOOKING_SHEET_CARD_GAP = 14;
export const BOOKING_SHEET_CARD_ICON_SIZE = 56;
export const BOOKING_SHEET_CARD_ICON_RADIUS = 14;

/** Shared sheet card typography/layout */
export const BOOKING_SHEET_CARD = {
  padding: 14,
  borderRadius: 16,
  borderWidth: 1,
  gap: 14,
  iconWrapSize: 56,
  iconWrapRadius: 14,
  titleFontSize: 17,
  titleFontWeight: '600' as const,
  titleColor: '#F1F5F9',
  subtitleFontSize: 14,
  subtitleColor: '#94A3B8',
  subtitleMarginTop: 2,
  topRowMarginBottom: 2,
  badgePaddingVertical: 4,
  badgePaddingHorizontal: 8,
  badgeBorderRadius: 6,
  badgeMarginTop: 4,
  badgeTextFontSize: 13,
  badgeTextFontWeight: '600' as const,
  selectedBorderWidth: 2,
};

/** Confirm CTA on all booking sheets */
export const BOOKING_SHEET_CONFIRM_BTN = {
  paddingVertical: 14,
  paddingHorizontal: 18,
  borderRadius: 14,
  borderWidth: 1,
  fontSize: 16,
  fontWeight: '700' as const,
};

/** Curved border style for cards */
export const CURVED_BOOKING_CARD = {
  borderRadius: CARD_BORDER_RADIUS,
  overflow: 'hidden' as const,
  backgroundColor: 'transparent',
  borderWidth: 1,
  borderColor: HEADER_STYLE_CARD_BORDER,
  shadowColor: '#000',
  shadowOffset: { width: 0, height: 1 },
  shadowOpacity: 0.08,
  shadowRadius: 6,
  elevation: 3,
};

/** Business sheet-style card (same as tracking bottom sheet): wrapper with gradient + dark overlay */
export const BUSINESS_SHEET_CARD = {
  borderRadius: 16,
  overflow: 'hidden' as const,
  padding: 16,
  borderWidth: 1,
  borderColor: 'rgba(135,206,235,0.22)',
  minHeight: 0,
};

/** Inner content card style for business sheet cards (matches tracking smallTrackingCard / bookingInfoCard) */
export const BUSINESS_SHEET_INNER_CARD = {
  borderRadius: 14,
  borderWidth: 1,
  borderColor: 'rgba(135,206,235,0.25)',
  padding: 12,
  backgroundColor: 'rgba(10,25,41,0.4)',
};
