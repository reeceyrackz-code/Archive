/**
 * Asset requires rooted from app/assets so Metro resolves consistently.
 */
export const CAR_IMAGE = require('../../app/assets/car.png');
export const VALETER_IMAGE = require('../../app/assets/valeter.png');
export const VALETER_MAP_IMAGE = require('../../app/assets/valeter-map.png');
export const CARWASH_IMAGE = require('../../app/assets/carwash.png');
export const ICON = require('../../app/assets/icon.png');
export const ICON_AUTH = require('../../app/assets/icon-auth.png');
export const WASHER_IMAGE = require('../../app/assets/valeter.png');

export const BRONZE_IMAGE = require('../../app/assets/bronze.png');
export const SILVER_IMAGE = require('../../app/assets/silver.png');
export const GOLD_IMAGE = require('../../app/assets/Gold.png');
export const PLATINUM_IMAGE = require('../../app/assets/platinum.png');
export const EMERALD_IMAGE = require('../../app/assets/emerald.png');
export const DETAILING_HUB_IMAGE = require('../../app/assets/Detailing1.png');
export const CERAMIC_DETAIL_IMAGE = require('../../app/assets/Ceramic.png');
export const SOFTOP_DETAIL_IMAGE = require('../../app/assets/Softop.png');
export const MOULD_DETAIL_IMAGE = require('../../app/assets/mould.png');
export const HEADLIGHT_DETAIL_IMAGE = require('../../app/assets/headlight.png');
export const ONBOARDING_VIDEO = require('../../app/assets/onboarding.mp4');
