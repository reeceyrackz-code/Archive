// Typography constants - Uber-style clean semi-bold text using Rubik font
// Similar to Uber's typography system with clean, modern sans-serif

export const typography = {
  // Font family
  fontFamily: {
    regular: 'Rubik_400Regular',
    medium: 'Rubik_500Medium',
    semiBold: 'Rubik_600SemiBold',
    bold: 'Rubik_700Bold',
  },

  // Font sizes (Uber-style scale)
  fontSize: {
    xs: 12,
    sm: 14,
    base: 16,
    lg: 18,
    xl: 20,
    '2xl': 24,
    '3xl': 28,
    '4xl': 32,
    '5xl': 36,
    '6xl': 40,
  },

  // Line heights
  lineHeight: {
    tight: 1.2,
    normal: 1.5,
    relaxed: 1.75,
  },

  // Letter spacing
  letterSpacing: {
    tighter: -0.5,
    tight: -0.3,
    normal: 0,
    wide: 0.3,
    wider: 0.5,
  },

  // Predefined text styles (Uber-style)
  styles: {
    // Headings
    h1: {
      fontFamily: 'Rubik_600SemiBold',
      fontSize: 32,
      lineHeight: 38,
      letterSpacing: -0.3,
    },
    h2: {
      fontFamily: 'Rubik_600SemiBold',
      fontSize: 28,
      lineHeight: 34,
      letterSpacing: -0.3,
    },
    h3: {
      fontFamily: 'Rubik_600SemiBold',
      fontSize: 24,
      lineHeight: 30,
      letterSpacing: -0.3,
    },
    h4: {
      fontFamily: 'Rubik_600SemiBold',
      fontSize: 20,
      lineHeight: 26,
      letterSpacing: -0.2,
    },
    h5: {
      fontFamily: 'Rubik_600SemiBold',
      fontSize: 18,
      lineHeight: 24,
      letterSpacing: -0.2,
    },
    h6: {
      fontFamily: 'Rubik_600SemiBold',
      fontSize: 16,
      lineHeight: 22,
      letterSpacing: -0.1,
    },

    // Body text
    body: {
      fontFamily: 'Rubik_400Regular',
      fontSize: 16,
      lineHeight: 24,
      letterSpacing: 0,
    },
    bodyMedium: {
      fontFamily: 'Rubik_500Medium',
      fontSize: 16,
      lineHeight: 24,
      letterSpacing: 0,
    },
    bodySemiBold: {
      fontFamily: 'Rubik_600SemiBold',
      fontSize: 16,
      lineHeight: 24,
      letterSpacing: 0,
    },

    // Small text
    small: {
      fontFamily: 'Rubik_400Regular',
      fontSize: 14,
      lineHeight: 20,
      letterSpacing: 0,
    },
    smallMedium: {
      fontFamily: 'Rubik_500Medium',
      fontSize: 14,
      lineHeight: 20,
      letterSpacing: 0,
    },
    smallSemiBold: {
      fontFamily: 'Rubik_600SemiBold',
      fontSize: 14,
      lineHeight: 20,
      letterSpacing: 0,
    },

    // Caption
    caption: {
      fontFamily: 'Rubik_400Regular',
      fontSize: 12,
      lineHeight: 18,
      letterSpacing: 0,
    },
    captionMedium: {
      fontFamily: 'Rubik_500Medium',
      fontSize: 12,
      lineHeight: 18,
      letterSpacing: 0,
    },
    captionSemiBold: {
      fontFamily: 'Rubik_600SemiBold',
      fontSize: 12,
      lineHeight: 18,
      letterSpacing: 0,
    },

    // Button text
    button: {
      fontFamily: 'Rubik_600SemiBold',
      fontSize: 16,
      lineHeight: 24,
      letterSpacing: 0.2,
    },
    buttonLarge: {
      fontFamily: 'Rubik_600SemiBold',
      fontSize: 18,
      lineHeight: 26,
      letterSpacing: 0.2,
    },
  },
};

// Helper function to get font style
export const getFontStyle = (variant: keyof typeof typography.styles) => {
  return typography.styles[variant];
};

/** Canonical text styles for themeColors.getTextStylesWithColors – do not define ad-hoc fontSize/fontWeight. */
export const textStyles = {
  pageTitle: { fontFamily: 'Rubik_600SemiBold' as const, fontSize: 24, lineHeight: 30, letterSpacing: -0.3 },
  pageSubtitle: { fontFamily: 'Rubik_500Medium' as const, fontSize: 15, lineHeight: 22, letterSpacing: 0 },
  sectionTitle: { fontFamily: 'Rubik_600SemiBold' as const, fontSize: 18, lineHeight: 24, letterSpacing: -0.2 },
  sectionSubtitle: { fontFamily: 'Rubik_500Medium' as const, fontSize: 14, lineHeight: 20, letterSpacing: 0 },
  body: { fontFamily: 'Rubik_400Regular' as const, fontSize: 16, lineHeight: 24, letterSpacing: 0 },
  bodyMedium: { fontFamily: 'Rubik_500Medium' as const, fontSize: 16, lineHeight: 24, letterSpacing: 0 },
  bodySemiBold: { fontFamily: 'Rubik_600SemiBold' as const, fontSize: 16, lineHeight: 24, letterSpacing: 0 },
  bodySmall: { fontFamily: 'Rubik_400Regular' as const, fontSize: 14, lineHeight: 20, letterSpacing: 0 },
  bodySmallMedium: { fontFamily: 'Rubik_500Medium' as const, fontSize: 14, lineHeight: 20, letterSpacing: 0 },
  caption: { fontFamily: 'Rubik_400Regular' as const, fontSize: 12, lineHeight: 18, letterSpacing: 0 },
  captionMedium: { fontFamily: 'Rubik_500Medium' as const, fontSize: 12, lineHeight: 18, letterSpacing: 0 },
  captionSemiBold: { fontFamily: 'Rubik_600SemiBold' as const, fontSize: 12, lineHeight: 18, letterSpacing: 0 },
  cardTitle: { fontFamily: 'Rubik_600SemiBold' as const, fontSize: 18, lineHeight: 24, letterSpacing: -0.2 },
  button: { fontFamily: 'Rubik_600SemiBold' as const, fontSize: 16, lineHeight: 24, letterSpacing: 0.2 },
  buttonLarge: { fontFamily: 'Rubik_600SemiBold' as const, fontSize: 17, lineHeight: 24, letterSpacing: 0.2 },
  statValue: { fontFamily: 'Rubik_700Bold' as const, fontSize: 20, lineHeight: 26, letterSpacing: -0.2 },
  statLabel: { fontFamily: 'Rubik_500Medium' as const, fontSize: 12, lineHeight: 16, letterSpacing: 0 },
  tabLabel: { fontFamily: 'Rubik_600SemiBold' as const, fontSize: 11, lineHeight: 14, letterSpacing: 0 },
  modalTitle: { fontFamily: 'Rubik_600SemiBold' as const, fontSize: 18, lineHeight: 24, letterSpacing: -0.2 },
  modalSubtitle: { fontFamily: 'Rubik_400Regular' as const, fontSize: 14, lineHeight: 20, letterSpacing: 0 },
  emptyTitle: { fontFamily: 'Rubik_600SemiBold' as const, fontSize: 18, lineHeight: 24, letterSpacing: -0.2 },
};
