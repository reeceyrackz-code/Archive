import { Dimensions, Platform, StyleSheet } from 'react-native';
import { colors } from './colors';
import { BOOKING_CONTINUE_RADIUS } from '../utils/bookingContinueStyle';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

/** Gradient overlay colors for auth video background (shared by login/signup). Lighter = less tint, more video visible. */
export const AUTH_GRADIENT_COLORS = [
  'rgba(15,40,71,0.18)',
  'rgba(15,40,71,0.35)',
  'rgba(15,40,71,0.58)',
] as const;

/** Content overlay: subtle transparent gradient behind glass card */
export const AUTH_CONTENT_OVERLAY_COLORS = [
  'rgba(15,40,71,0.22)',
  'rgba(15,40,71,0.38)',
  'rgba(15,40,71,0.58)',
] as const;

const sharedAuthStyleDefs = {
  root: { flex: 1, backgroundColor: '#0A1929' as const },
  keyboardView: { flex: 1 },
  scrollContent: {
    flexGrow: 1,
    paddingTop: Platform.OS === 'ios' ? 100 : 24,
    paddingBottom: 28,
    paddingHorizontal: isSmallScreen ? 20 : 24,
  },
  contentContainer: { flex: 1 },

  topRightLink: {
    position: 'absolute' as const,
    top: Platform.OS === 'ios' ? 50 : 24,
    right: 24,
    zIndex: 20,
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  topRightLinkText: {
    color: '#B8E0F0',
    fontWeight: '700' as const,
    fontSize: 16,
  },

  videoBackground: StyleSheet.absoluteFillObject,

  logoContainer: {
    alignItems: 'center' as const,
    marginBottom: 12,
  },
  logoImageWrapper: {
    width: 132,
    height: 132,
    borderRadius: 28,
    backgroundColor: 'rgba(255,255,255,0.06)',
    overflow: 'hidden' as const,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.45,
    shadowRadius: 16,
    elevation: 16,
    borderWidth: 3,
    borderTopColor: 'rgba(255,255,255,0.45)',
    borderLeftColor: 'rgba(255,255,255,0.35)',
    borderRightColor: 'rgba(0,0,0,0.35)',
    borderBottomColor: 'rgba(0,0,0,0.45)',
  },
  logoImage: {
    width: 132,
    height: 132,
    borderRadius: 28,
    overflow: 'hidden' as const,
  },

  headline: {
    fontSize: 22,
    fontWeight: '700' as const,
    color: 'rgba(255,255,255,0.98)',
    textAlign: 'center' as const,
    marginBottom: 4,
  },
  subtext: {
    fontSize: 15,
    fontWeight: '500' as const,
    color: 'rgba(255,255,255,0.72)',
    textAlign: 'center' as const,
    marginBottom: 28,
  },

  glassCard: {
    borderRadius: 22,
    overflow: 'hidden' as const,
    paddingHorizontal: 22,
    paddingTop: 26,
    paddingBottom: 26,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.25,
    shadowRadius: 20,
    elevation: 12,
  },

  emailCtaButton: {
    backgroundColor: 'rgba(255,255,255,0.14)',
    borderRadius: BOOKING_CONTINUE_RADIUS,
    paddingVertical: 16,
    paddingHorizontal: 20,
    marginBottom: 16,
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
    gap: 10,
  },
  emailCtaButtonText: {
    fontSize: 16,
    fontWeight: '600' as const,
    color: 'rgba(255,255,255,0.95)',
  },

  dividerContainer: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    marginTop: 20,
    marginBottom: 18,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
  dividerText: {
    marginHorizontal: 12,
    color: 'rgba(255,255,255,0.6)',
    fontSize: 12,
    fontWeight: '600' as const,
  },

  ssoButton: {
    width: '100%' as const,
    height: 52,
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
    borderRadius: BOOKING_CONTINUE_RADIUS,
    paddingHorizontal: 20,
    marginBottom: 12,
    gap: 12,
  },
  ssoButtonApple: {
    backgroundColor: '#FFFFFF',
  },
  ssoButtonGoogle: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.35)',
  },
  ssoButtonText: {
    fontSize: 16,
    fontWeight: '600' as const,
  },
  ssoButtonTextLight: {
    color: '#1a1a1a',
  },
  ssoButtonTextWhite: {
    color: '#FFFFFF',
  },

  trustCopy: {
    marginTop: 20,
    paddingHorizontal: 8,
  },
  trustCopyText: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.55)',
    textAlign: 'center' as const,
    lineHeight: 18,
  },
  trustCopyLink: {
    color: '#87CEEB',
    fontWeight: '600' as const,
    textDecorationLine: 'underline' as const,
  },
  secureNote: {
    fontSize: 11,
    color: 'rgba(255,255,255,0.45)',
    textAlign: 'center' as const,
    marginTop: 6,
  },

  helpLink: {
    marginTop: 16,
    alignSelf: 'center' as const,
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    paddingVertical: 6,
    paddingHorizontal: 12,
  },
  helpLinkText: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.7)',
    fontWeight: '500' as const,
  },

  signupCtaRow: {
    marginTop: 24,
    flexDirection: 'row' as const,
    flexWrap: 'wrap' as const,
    justifyContent: 'center' as const,
    alignItems: 'center' as const,
  },
  signupCtaText: {
    fontSize: 15,
    color: 'rgba(255,255,255,0.75)',
  },
  signupCtaLink: {
    color: '#B8E0F0',
    fontWeight: '700' as const,
  },

  footer: {
    marginTop: 24,
    alignItems: 'center' as const,
  },
  footerText: {
    fontSize: 11,
    color: 'rgba(255,255,255,0.4)',
  },

  inputWrapper: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    backgroundColor: 'rgba(135,206,235,0.25)',
    borderRadius: 12,
    marginBottom: 12,
  },
  inputIconContainer: {
    width: 44,
    height: 48,
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
  },
  input: {
    flex: 1,
    color: colors.inputText,
    fontSize: 15,
    paddingRight: 12,
  },
};

export { sharedAuthStyleDefs };
