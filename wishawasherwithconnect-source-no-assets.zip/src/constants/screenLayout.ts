/**
 * Screen layout constants – single source of truth for positioning.
 * Use with ScreenLayout and for manual padding so every page aligns.
 */

import { HEADER_HEIGHT } from '../components/shared/AppHeader';

/** Tab bar visible height (match NavigationTab). */
const TAB_BAR_HEIGHT = 54;

/** Gap between bottom of header and start of content (px) */
export const CONTENT_GAP_BELOW_HEADER = 20;

/** Content top = header margin (8) + header height + gap. Add insets.top in component. */
export const CONTENT_TOP_WITHOUT_SAFE = 8 + HEADER_HEIGHT + CONTENT_GAP_BELOW_HEADER;

/** Horizontal padding for screen content (8pt grid). */
export const SCREEN_PADDING_H = 20;

/** Vertical gap between major sections. */
export const SECTION_GAP = 24;

/** Gap between cards. */
export const CARD_GAP = 16;

/** Bottom padding for scroll content (above tab bar). Add insets.bottom in component. */
export const SCREEN_BOTTOM_WITHOUT_SAFE = TAB_BAR_HEIGHT + 24;
