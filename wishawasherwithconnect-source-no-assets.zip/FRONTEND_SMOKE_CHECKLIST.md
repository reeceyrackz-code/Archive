# Frontend Smoke Checklist

Use this checklist after each major UI/state change and before TestFlight submission.

## 1) App Start + Auth
- App launches without red screen or stuck splash.
- Login works for `customer`, `valeter`, and `organization`.
- Logout returns to auth flow cleanly.
- Wrong credentials show a clear error message.

## 2) Customer Core Flow
- Customer dashboard loads without blank sections.
- Booking creation path opens and saves required fields.
- Booking status updates render without crashes.
- Chat/inbox screen opens and sends at least one message.

## 3) Valeter Core Flow
- Valeter dashboard loads and quick actions open expected routes.
- Job list loads and accepts a job without UI dead-end.
- Tracking screen opens from active job path.
- Valeter profile opens, edits save, and returns to profile.

## 4) Business Core Flow
- Business dashboard opens with no missing critical cards.
- Locations list opens and location detail page loads.
- Team page opens and member list/search is usable.
- Business profile screen opens and saves editable fields.

## 5) Valeter Business affiliations (removed)
- Screen deleted; no smoke steps here.

## 6) Resilience + UX Quality
- Every network failure path shows user-friendly feedback.
- Empty states render correctly (no undefined labels).
- Buttons disable during in-flight submit actions.
- No visible placeholder/debug strings in production paths.

## 7) Release Readiness
- `npm run type-check` passes.
- App starts with `npm start` and role routes still work.
- iOS production build command runs from current branch.
- TestFlight upload metadata matches intended build/version.

