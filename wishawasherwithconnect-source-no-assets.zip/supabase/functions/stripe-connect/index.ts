// supabase/functions/stripe-connect/index.ts
import { createClient } from 'npm:@supabase/supabase-js@2';
import Stripe from 'npm:stripe@14.25.0';

const SUPABASE_URL = Deno.env.get('SUPABASE_URL') ?? '';
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';
const STRIPE_SECRET_KEY = Deno.env.get('STRIPE_SECRET_KEY') ?? '';

const stripe = new Stripe(STRIPE_SECRET_KEY, {
  apiVersion: '2024-06-20',
});

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

function json(status: number, body: Record<string, unknown>) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

async function getAuthedUserId(req: Request): Promise<string | null> {
  const authHeader = req.headers.get('Authorization') ?? '';
  const token = authHeader.replace('Bearer ', '').trim();
  if (!token) return null;

  const admin = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
  const { data, error } = await admin.auth.getUser(token);
  if (error || !data?.user?.id) return null;
  return data.user.id;
}

function toStripeConnectStatus(account: Stripe.Account): 'in_progress' | 'completed' | 'restricted' {
  if (account.details_submitted && account.charges_enabled && account.payouts_enabled) {
    return 'completed';
  }
  if ((account.requirements?.disabled_reason || '').length > 0) {
    return 'restricted';
  }
  return 'in_progress';
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY || !STRIPE_SECRET_KEY) {
    return json(500, { error: 'Missing function environment variables.' });
  }

  try {
    const userId = await getAuthedUserId(req);
    if (!userId) return json(401, { error: 'Unauthorized' });

    const body = await req.json().catch(() => ({}));
    const action = String(body?.action || '');

    const admin = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
    const { data: profile, error: profileErr } = await admin
      .from('profiles')
      .select('id,email,user_type,role,terms_status,stripe_account_id,stripe_connect_status,stripe_details')
      .eq('id', userId)
      .maybeSingle();

    if (profileErr || !profile) {
      return json(404, { error: 'Profile not found.' });
    }

    const userType = String(profile.user_type || '').toLowerCase();
    const role = String(profile.role || '').toLowerCase();
    const isBusiness = userType === 'organization' || role === 'organization' || userType === 'business';
    if (!isBusiness) {
      return json(403, { error: 'Only business users can access Stripe Connect.' });
    }

    if (String(profile.terms_status || 'pending') !== 'accepted') {
      return json(409, { error: 'Terms must be accepted before Stripe Connect.' });
    }

    if (action === 'create_onboarding_link') {
      const returnUrl = String(body?.returnUrl || '');
      const refreshUrl = String(body?.refreshUrl || '');
      if (!returnUrl || !refreshUrl) {
        return json(400, { error: 'returnUrl and refreshUrl are required.' });
      }

      let stripeAccountId = profile.stripe_account_id as string | null;

      if (!stripeAccountId) {
        const account = await stripe.accounts.create({
          type: 'express',
          email: profile.email || undefined,
          metadata: {
            user_id: userId,
          },
        });
        stripeAccountId = account.id;
      }

      const link = await stripe.accountLinks.create({
        account: stripeAccountId,
        type: 'account_onboarding',
        return_url: returnUrl,
        refresh_url: refreshUrl,
      });

      const nextDetails = {
        ...(profile.stripe_details || {}),
        last_onboarding_link_created_at: new Date().toISOString(),
      };

      const { error: updateErr } = await admin
        .from('profiles')
        .update({
          stripe_account_id: stripeAccountId,
          stripe_connect_status: 'in_progress',
          stripe_onboarding_started_at: new Date().toISOString(),
          stripe_details: nextDetails,
        } as any)
        .eq('id', userId);

      if (updateErr) return json(500, { error: updateErr.message });

      return json(200, {
        url: link.url,
        stripeAccountId,
        stripeConnectStatus: 'in_progress',
      });
    }

    if (action === 'get_status') {
      const stripeAccountId = (profile.stripe_account_id as string | null) ?? null;
      if (!stripeAccountId) {
        return json(200, {
          stripeConnectStatus: 'not_started',
          stripeAccountId: null,
          detailsSubmitted: false,
          chargesEnabled: false,
          payoutsEnabled: false,
        });
      }

      const account = await stripe.accounts.retrieve(stripeAccountId);
      const nextStatus = toStripeConnectStatus(account);

      const nextDetails = {
        ...(profile.stripe_details || {}),
        account_country: account.country,
        account_email: account.email,
        business_type: account.business_type,
        requirements: account.requirements,
        updated_from_stripe_at: new Date().toISOString(),
      };

      const updatePayload: Record<string, unknown> = {
        stripe_connect_status: nextStatus,
        stripe_details: nextDetails,
      };
      if (nextStatus === 'completed') {
        updatePayload.stripe_onboarding_completed_at = new Date().toISOString();
      }

      const { error: updateErr } = await admin
        .from('profiles')
        .update(updatePayload as any)
        .eq('id', userId);

      if (updateErr) return json(500, { error: updateErr.message });

      return json(200, {
        stripeConnectStatus: nextStatus,
        stripeAccountId,
        detailsSubmitted: account.details_submitted,
        chargesEnabled: account.charges_enabled,
        payoutsEnabled: account.payouts_enabled,
      });
    }

    return json(400, { error: 'Unsupported action.' });
  } catch (e: any) {
    return json(500, { error: e?.message || 'Unexpected server error.' });
  }
});

