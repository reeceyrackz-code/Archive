# Asset Usage Guide

This document describes how each asset in this folder should be used throughout the application.

## Video Assets

### `car-cleaning.mp4`
- **Usage**: Login page background video
- **Location**: `app/auth/login.tsx`
- **Purpose**: Provides dynamic background for user authentication

### `car-cleaning2.mp4`
- **Usage**: Sign-up page background video
- **Location**: `app/auth/signup.tsx`
- **Purpose**: Provides dynamic background for new user registration

### `water-rain.mp4`
- **Usage**: Valeter onboarding background video
- **Locations**: 
  - `app/onboarding.tsx` (general valeter onboarding)
  - `app/valeter/valeter-onboarding.tsx` (valeter-specific onboarding)
- **Purpose**: Creates immersive water/rain theme for valeter onboarding experience

### `business.mp4`
- **Usage**: Business onboarding background video
- **Location**: `app/business/onboarding.tsx`
- **Purpose**: Professional background for business account onboarding

## Image Assets

### `car.png`
- **Usage**: Customer location markers on maps
- **Locations**:
  - `app/business/bookings.tsx` (business viewing customer locations)
  - `app/valeter/jobs/index.tsx` (valeter viewing customer locations)
  - `app/valeter/trips/index.tsx` (valeter trip/customer map markers)
- **Purpose**: Represents customer vehicles on map views for tracking and bookings

### `car-wash-2.png`
- **Usage**: Wash hub location markers
- **Locations**:
  - `app/business/locations.tsx` (default hub icon)
  - Any map view showing wash hub locations
- **Purpose**: Default icon for physical car wash hub locations on maps

### `detailing.png`
- **Usage**: Detailing hub location markers
- **Locations**:
  - Future: `app/business/locations.tsx` (when location types are implemented)
  - Any map view showing detailing hub locations
- **Purpose**: Icon for detailing hubs (both physical and mobile) on maps
- **Note**: Currently not implemented - will be used when location type field is added

### `cleaning.png`
- **Usage**: App logo/branding
- **Locations**:
  - `app/auth/login.tsx` (logo on login screen)
  - `app/auth/signup.tsx` (logo on sign-up screen)
  - `app/onboarding.tsx` (logo on valeter onboarding slide 1)
  - `app/valeter/valeter-onboarding.tsx` (logo display)
  - `app/business/onboarding.tsx` (logo display)
  - `app/_layout.tsx` (preloaded for fast logo display)
  - `/assets/icon.png` (app icon - copied from this file)
  - `/assets/splash.png` (splash screen - copied from this file)
- **Purpose**: Primary branding/logo image used throughout the app

## File Structure

```
app/assets/
├── car-cleaning.mp4      → Login background
├── car-cleaning2.mp4     → Sign-up background
├── water-rain.mp4        → Valeter onboarding background
├── business.mp4          → Business onboarding background
├── car.png               → Customer map markers
├── car-wash-2.png        → Wash hub map markers
├── detailing.png         → Detailing hub map markers
└── cleaning.png          → App logo/branding

/assets/ (root level - required by Expo)
├── icon.png              → App icon (copied from cleaning.png)
├── splash.png            → Splash screen (copied from cleaning.png)
└── adaptive-icon.png     → Android adaptive icon (copied from cleaning.png)
```

## Path Convention

All assets in `app/assets/` should be referenced using relative paths from the importing file:
- From `app/` (e.g. `_layout.tsx`, `onboarding.tsx`): `require('./assets/filename')`
- From `app/auth/`: `require('../assets/filename')`
- From `app/business/`: `require('../assets/filename')`
- From `app/valeter/`: `require('../assets/filename')`
- From `app/valeter/jobs/` or `app/valeter/trips/`: `require('../../assets/filename')`

## Future Enhancements

### Location Type Icons
When the `Location` interface is extended to include a `type` field, the map markers should dynamically select icons:

```typescript
interface Location {
  // ... existing fields
  type: 'wash_hub' | 'detailing_hub' | 'mobile_detailing';
}

// In map rendering:
const getLocationIcon = (type: string) => {
  switch(type) {
    case 'wash_hub':
      return require('../assets/car-wash-2.png');
    case 'detailing_hub':
    case 'mobile_detailing':
      return require('../assets/detailing.png');
    default:
      return require('../assets/car-wash-2.png');
  }
};
```

## Notes

- All video assets use `expo-av` Video component with looping and muted playback
- Map marker images should use `resizeMode="contain"` for proper scaling
- Background videos should use `ResizeMode.COVER` for full-screen coverage
- Always include a dark gradient overlay on background videos for text readability
