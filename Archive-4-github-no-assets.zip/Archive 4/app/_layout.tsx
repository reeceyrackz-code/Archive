// app/_layout.tsx (RootLayout)
// Single isBooting at root; Wish-a-Wash splash only during app boot and auth restoration.

import React, { Component, useEffect, useState } from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { AuthProvider } from '../src/providers/enhanced-auth-context';
import { BootProvider } from '../src/contexts/BootContext';
import { ToastProvider } from '../src/contexts/ToastContext';
import { ThemeProvider, useTheme } from '../src/contexts/ThemeContext';
import { AccountThemeProvider } from '../src/components/shared/AccountThemeProvider';
import type { AccountType } from '../src/constants/accountThemes';
import { useAuth } from '../src/providers/enhanced-auth-context';
import { BookingFlowThemeProvider } from '../src/contexts/BookingFlowThemeContext';
import { LogBox, Platform, View, StyleSheet, Text, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { colors } from '../src/constants/colors';
import { BORDER_RADIUS, SPACING } from '../src/constants/designTokens';
import * as SplashScreen from 'expo-splash-screen';
import NavigationTab from './components/NavigationTab';
import { TabBarInsetProvider, useTabBarBottomReserve } from '../src/contexts/TabBarInsetContext';

let StripeProvider: any = ({ children }: { children: React.ReactNode }) => <>{children}</>;
if (Platform.OS !== 'web') {
  try {
    const stripe = require('@stripe/stripe-react-native');
    StripeProvider = stripe.StripeProvider;
  } catch (e) {
    if (__DEV__) console.warn('Stripe not available:', e);
  }
}

LogBox.ignoreLogs([
  'Non-serializable values were found in the navigation state',
  'AsyncStorage has been extracted from react-native',
]);

/** Catches React tree errors so the app shows a fallback instead of a blank crash. */
class RootErrorBoundary extends Component<
  { children: React.ReactNode },
  { hasError: boolean; error: Error | null }
> {
  state = { hasError: false, error: null as Error | null };

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    if (__DEV__) {
      console.error('RootErrorBoundary:', error, errorInfo?.componentStack);
    }
  }

  render() {
    if (this.state.hasError && this.state.error) {
      return (
        <View style={styles.errorRoot}>
          <View style={styles.errorIconCircle}>
            <Text style={styles.errorIconText}>!</Text>
          </View>
          <Text style={styles.errorTitle}>Something went wrong</Text>
          <Text style={styles.errorText} numberOfLines={5}>
            {this.state.error?.message}
          </Text>
          <Text style={styles.errorHint}>You can try again or restart the app.</Text>
          <TouchableOpacity
            style={styles.errorButton}
            onPress={() => this.setState({ hasError: false, error: null })}
            activeOpacity={0.8}
            accessibilityLabel="Try again"
            accessibilityRole="button"
          >
            <Text style={styles.errorButtonText}>Try again</Text>
          </TouchableOpacity>
        </View>
      );
    }
    return this.props.children;
  }
}

/** Defers mounting Stripe so the app shell renders first; avoids native init crash taking down the whole app. */
function DeferredStripeProvider({ children }: Readonly<{ children: React.ReactNode }>) {
  const [mountStripe, setMountStripe] = useState(Platform.OS === 'web');
  useEffect(() => {
    if (Platform.OS === 'web') return;
    const t = setTimeout(() => setMountStripe(true), 100);
    return () => clearTimeout(t);
  }, []);

  if (!mountStripe) {
    return <>{children}</>;
  }
  return (
    <StripeProvider
      publishableKey="pk_test_51S3OQLGYkpu3JDyWrHRRw6kvG9t4BNGpCiFVDAUeQCptnXAFJYnNEyWyv1HJG7XYsOd7Io4qYAn9T4deCcYUu2zC00O9yRUMdU"
      merchantIdentifier="merchant.com.wishawashapp"
      urlScheme="waw"
    >
      {children}
    </StripeProvider>
  );
}

function AccountThemeRoot({ children }: Readonly<{ children: React.ReactNode }>) {
  const { user } = useAuth();
  const accountType: AccountType =
    user?.userType === 'valeter'
      ? 'valeter'
      : user?.userType === 'organization'
        ? 'business'
        : 'customer';
  return <AccountThemeProvider accountType={accountType}>{children}</AccountThemeProvider>;
}

function RootContent() {
  const { theme } = useTheme();
  const tabBarBottomReserve = useTabBarBottomReserve();
  return (
    <>
      <StatusBar style="light" backgroundColor="transparent" />
      <View style={styles.contentWrapper}>
        <LinearGradient
          colors={theme.backgroundGradient}
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
        />
        <View style={[styles.stackClip, { marginBottom: tabBarBottomReserve }]}>
          <Stack
            screenOptions={{
              headerShown: false,
              contentStyle: { backgroundColor: 'transparent' },
              animation: 'default',
              gestureEnabled: false,
            }}
          />
        </View>
        <NavigationTab />
      </View>
    </>
  );
}

export default function RootLayout() {
  useEffect(() => {
    SplashScreen.preventAutoHideAsync().catch((e: unknown) => {
      if (__DEV__) console.warn('SplashScreen.preventAutoHideAsync failed:', e);
    });
  }, []);

  return (
    <RootErrorBoundary>
      <DeferredStripeProvider>
        <AuthProvider>
          <ThemeProvider>
            <AccountThemeRoot>
              <BootProvider>
                <ToastProvider>
                  <BookingFlowThemeProvider>
                    <TabBarInsetProvider>
                      <View style={styles.root}>
                        <RootContent />
                      </View>
                    </TabBarInsetProvider>
                  </BookingFlowThemeProvider>
                </ToastProvider>
              </BootProvider>
            </AccountThemeRoot>
          </ThemeProvider>
        </AuthProvider>
      </DeferredStripeProvider>
    </RootErrorBoundary>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: 'transparent' },
  contentWrapper: { flex: 1 },
  /** Clip scroll content so it does not draw under the floating nav tab. */
  stackClip: { flex: 1, overflow: 'hidden' },
  errorRoot: {
    flex: 1,
    backgroundColor: colors.bgPrimary,
    justifyContent: 'center',
    alignItems: 'center',
    padding: SPACING.xxl,
  },
  errorIconCircle: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: colors.surfaceOverlayStrong,
    borderWidth: 2,
    borderColor: colors.inputErrorBorder,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: SPACING.lg,
  },
  errorIconText: {
    color: colors.inputError,
    fontSize: 24,
    fontWeight: '700',
  },
  errorTitle: {
    color: colors.textOnDarkPrimary,
    fontSize: 18,
    fontWeight: '700',
    marginBottom: SPACING.md,
  },
  errorText: {
    color: colors.textOnDarkTertiary,
    fontSize: 14,
    textAlign: 'center',
    marginBottom: SPACING.sm,
  },
  errorHint: {
    color: colors.greyMedium,
    fontSize: 13,
    textAlign: 'center',
    marginBottom: SPACING.xxl,
  },
  errorButton: {
    backgroundColor: colors.SKY,
    paddingHorizontal: SPACING.xxl,
    paddingVertical: SPACING.md,
    borderRadius: BORDER_RADIUS.sm,
    minWidth: 160,
    alignItems: 'center',
  },
  errorButtonText: { color: colors.textOnDarkPrimary, fontWeight: '700', fontSize: 16 },
});
