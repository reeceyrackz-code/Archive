import React from 'react';
import { View, Text } from 'react-native';
import { useAuth } from '../src/providers/enhanced-auth-context';
import PolicyScreen, { policyScreenStyles } from '../src/components/shared/PolicyScreen';
import type { PolicySection } from '../src/components/shared/PolicyScreen';

export default function PrivacyPolicy() {
  const { user } = useAuth();
  const accountType = (user?.userType === 'valeter' ? 'valeter' : user?.userType === 'organization' ? 'business' : 'customer') as 'customer' | 'valeter' | 'business';

  const sections: PolicySection[] = [
    {
      title: '1. Introduction',
      icon: 'information-circle',
      content: (
        <Text style={policyScreenStyles.sectionText}>
          Welcome to Wish a Wash. We respect your privacy and are committed to protecting your personal data. This policy explains how we collect, use, and safeguard your information.
        </Text>
      ),
    },
    {
      title: '2. Data We Collect',
      icon: 'document-text',
      content: (
        <>
          <Text style={policyScreenStyles.sectionText}>We collect information you provide directly to us, including:</Text>
          <View style={policyScreenStyles.bulletList}>
            <Text style={policyScreenStyles.bulletPoint}>• Name, email, and phone number</Text>
            <Text style={policyScreenStyles.bulletPoint}>• Payment information (processed securely)</Text>
            <Text style={policyScreenStyles.bulletPoint}>• Vehicle details (via DVLA integration)</Text>
            <Text style={policyScreenStyles.bulletPoint}>• Location data (for service delivery)</Text>
            <Text style={policyScreenStyles.bulletPoint}>• Usage data and preferences</Text>
          </View>
        </>
      ),
    },
    {
      title: '3. How We Use Your Data',
      icon: 'settings',
      content: (
        <>
          <Text style={policyScreenStyles.sectionText}>We use your data to:</Text>
          <View style={policyScreenStyles.bulletList}>
            <Text style={policyScreenStyles.bulletPoint}>• Provide and improve our services</Text>
            <Text style={policyScreenStyles.bulletPoint}>• Process payments and bookings</Text>
            <Text style={policyScreenStyles.bulletPoint}>• Communicate with you about services</Text>
            <Text style={policyScreenStyles.bulletPoint}>• Send important updates and reminders</Text>
            <Text style={policyScreenStyles.bulletPoint}>• Ensure platform security and prevent fraud</Text>
          </View>
        </>
      ),
    },
    {
      title: '4. Data Security',
      icon: 'lock-closed',
      content: (
        <Text style={policyScreenStyles.sectionText}>
          We implement appropriate technical and organisational measures to protect your personal data against unauthorised access, alteration, disclosure, or destruction. All data is encrypted in transit and at rest.
        </Text>
      ),
    },
    {
      title: '5. Your Rights',
      icon: 'person',
      content: (
        <>
          <Text style={policyScreenStyles.sectionText}>Under UK GDPR, you have the right to:</Text>
          <View style={policyScreenStyles.bulletList}>
            <Text style={policyScreenStyles.bulletPoint}>• Access your personal data</Text>
            <Text style={policyScreenStyles.bulletPoint}>• Rectify inaccurate information</Text>
            <Text style={policyScreenStyles.bulletPoint}>• Request erasure of your data</Text>
            <Text style={policyScreenStyles.bulletPoint}>• Restrict processing of your data</Text>
            <Text style={policyScreenStyles.bulletPoint}>• Data portability</Text>
            <Text style={policyScreenStyles.bulletPoint}>• Object to processing</Text>
          </View>
          <Text style={[policyScreenStyles.sectionText, { marginTop: 12 }]}>
            To exercise these rights, contact us through the app or email support.
          </Text>
        </>
      ),
    },
  ];

  return (
    <PolicyScreen
      title="Privacy Policy"
      headerIcon="shield-checkmark"
      accountType={accountType}
      sections={sections}
    />
  );
}
