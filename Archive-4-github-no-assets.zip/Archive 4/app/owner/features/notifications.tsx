import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  FlatList,
  RefreshControl,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';

import GlassCard from '@/components/booking/GlassCard';
import StatusBadge from '../../../src/components/booking/StatusBadge';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import AppHeader from '../../../src/components/shared/AppHeader';
import { useOwnerScrollContentPadding } from '../../../src/hooks/useOwnerScrollContentPadding';
import { SkeletonList } from '../../../src/components/shared/SkeletonLoader';
import GradientNotificationBell from '../../../src/components/shared/GradientNotificationBell';
import GradientIconBox from '../../../src/components/shared/GradientIconBox';
import { colors } from '../../../src/constants/colors';
import { BORDER_RADIUS, FONT_SIZES, SPACING } from '../../../src/constants/designTokens';

const BG = colors.BG;
const SKY = colors.SKY;
const DISMISSED_STORAGE_KEY = 'wishawash:dismissed-notifications-v1';

// Include all booking statuses that should show notifications
const NOTIFICATION_STATUSES = [
  'pending',
  'pending_valeter_acceptance',
  'pending_payment',
  'confirmed',
  'valeter_assigned',
  'en_route',
  'arrived',
  'in_progress',
  'scheduled',
  'completed',
  'cancelled',
] as const;

const TRACKABLE_STATUSES = new Set(['confirmed', 'valeter_assigned', 'en_route', 'arrived', 'in_progress']);
const WAITING_STATUSES = new Set([
  'pending',
  'pending_business_acceptance',
  'pending_valeter_acceptance',
  'scheduled',
]);

type NotificationType = 
  | 'booking'
  | 'vehicle_reminder'
  | 'reward'
  | 'payment'
  | 'document'
  | 'system'
  | 'referral';

function notificationIconSolid(type: NotificationType): keyof typeof Ionicons.glyphMap {
  switch (type) {
    case 'booking':
      return 'car';
    case 'vehicle_reminder':
      return 'warning';
    case 'reward':
      return 'gift';
    case 'payment':
      return 'card';
    case 'document':
      return 'document-text';
    case 'referral':
      return 'people';
    case 'system':
    default:
      return 'notifications';
  }
}

type UnifiedNotification = {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  createdAt: string;
  priority: 'low' | 'medium' | 'high';
  // Booking-specific
  bookingId?: string;
  status?: string;
  serviceName?: string;
  scheduledAt?: string | null;
  timeSlot?: string | null;
  price?: number | null;
  address?: string | null;
  valeterName?: string | null;
  // Vehicle reminder-specific
  vehicleId?: string;
  vehicleMake?: string;
  vehicleModel?: string;
  reminderType?: 'tax' | 'mot';
  expiryDate?: string;
  daysRemaining?: number;
  // Reward-specific
  rewardTitle?: string;
  points?: number;
  // Payment-specific
  paymentAmount?: number;
  paymentStatus?: string;
  // Document-specific
  documentType?: string;
  documentStatus?: string;
  // Action route
  actionRoute?: string;
  actionParams?: Record<string, string>;
};

type DismissedStore = Record<string, string[]>;

export default function NotificationsCentre() {
  const scrollPad = useOwnerScrollContentPadding(true);
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [allNotifications, setAllNotifications] = useState<UnifiedNotification[]>([]);
  const [visibleNotifications, setVisibleNotifications] = useState<UnifiedNotification[]>([]);
  const [dismissedIds, setDismissedIds] = useState<Set<string>>(new Set());
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);

  const loadDismissed = useCallback(async () => {
    if (!user?.id) return;
    try {
      const raw = await AsyncStorage.getItem(DISMISSED_STORAGE_KEY);
      if (!raw) {
        setDismissedIds(new Set());
        return;
      }
      const parsed = JSON.parse(raw) as DismissedStore;
      const ids = parsed?.[user.id] ?? [];
      setDismissedIds(new Set(ids));
    } catch (error) {
      console.warn('[Notifications] failed to read dismissed list', error);
      setDismissedIds(new Set());
    }
  }, [user?.id]);

  const persistDismissed = useCallback(
    async (next: Set<string>) => {
      if (!user?.id) return;
      try {
        const raw = await AsyncStorage.getItem(DISMISSED_STORAGE_KEY);
        const parsed = raw ? (JSON.parse(raw) as DismissedStore) : {};
        parsed[user.id] = Array.from(next);
        await AsyncStorage.setItem(DISMISSED_STORAGE_KEY, JSON.stringify(parsed));
      } catch (error) {
        console.warn('[Notifications] failed to persist dismissed list', error);
      }
    },
    [user?.id]
  );

  const mapBookingToNotification = (row: any): UnifiedNotification => {
    const status = row.status ?? 'pending';
    const serviceName = row.service_name ?? row.service_type ?? 'Car wash';

    let title: string;
    let message: string;
    let priority: 'low' | 'medium' | 'high' = 'medium';

    switch (status) {
      case 'pending':
      case 'pending_valeter_acceptance':
        title = 'Connecting to your pro';
        message = `We're connecting you with a pro for your ${serviceName} booking`;
        priority = 'high';
        break;
      case 'pending_payment':
        title = 'Payment Required';
        message = `Complete payment for your ${serviceName} booking`;
        priority = 'high';
        break;
      case 'confirmed':
      case 'valeter_assigned':
        title = 'Valeter Assigned';
        message = `A valeter has been assigned to your ${serviceName} booking`;
        priority = 'high';
        break;
      case 'en_route':
        title = 'Valeter On The Way';
        message = `Your valeter is en route to your location`;
        priority = 'high';
        break;
      case 'arrived':
        title = 'Valeter Arrived';
        message = `Your valeter has arrived at your location`;
        priority = 'high';
        break;
      case 'in_progress':
        title = 'Service In Progress';
        message = `Your ${serviceName} is currently being performed`;
        break;
      case 'completed':
        title = 'Service Completed';
        message = `Your ${serviceName} has been completed. Please rate your experience`;
        break;
      case 'cancelled':
        title = 'Booking Cancelled';
        message = `Your ${serviceName} booking has been cancelled`;
        priority = 'low';
        break;
      case 'scheduled':
        title = 'Booking Scheduled';
        message = `Your ${serviceName} is scheduled for ${row.scheduled_at ? new Date(row.scheduled_at).toLocaleDateString('en-GB') : 'later'}`;
        break;
      default:
        title = serviceName;
        message = `Update on your ${serviceName} booking`;
    }

    return {
      id: `booking-${row.id}`,
      type: 'booking',
      title,
      message,
      createdAt: row.created_at || row.updated_at || new Date().toISOString(),
      priority,
      bookingId: String(row.id),
      status,
      serviceName,
      scheduledAt: row.scheduled_at,
      timeSlot: row.time_slot,
      price: row.price,
      address: row.location_address ?? row.address ?? null,
      valeterName: row.valeter_name ?? null,
      actionRoute: (() => {
        if (WAITING_STATUSES.has(status)) return '/owner/track';
        if (status === 'pending_payment') return '/owner/track';
        if (TRACKABLE_STATUSES.has(status)) return '/owner/track';
        return '/owner/wash-history';
      })(),
      actionParams: status === 'completed' 
        ? { highlightId: String(row.id) }
        : { bookingId: String(row.id) },
    };
  };

  const fetchVehicleReminders = useCallback(async (userId: string): Promise<UnifiedNotification[]> => {
    try {
      const { data: vehicles, error } = await supabase
        .from('customer_vehicles')
        .select('id,make,model,registration,tax_expiry,mot_expiry')
        .eq('user_id', userId);

      if (error || !vehicles) return [];

      const reminders: UnifiedNotification[] = [];
      const now = new Date();
      const thirtyDaysFromNow = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

      vehicles.forEach((vehicle) => {
        // Tax reminder
        if (vehicle.tax_expiry) {
          const taxExpiry = new Date(vehicle.tax_expiry);
          const daysRemaining = Math.ceil((taxExpiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
          
          if (taxExpiry <= thirtyDaysFromNow && taxExpiry >= now) {
            const dayLabel = daysRemaining === 1 ? '' : 's';
            reminders.push({
              id: `tax-reminder-${vehicle.id}`,
              type: 'vehicle_reminder',
              title: 'Vehicle Tax Expiring Soon',
              message: `${vehicle.make} ${vehicle.model} (${vehicle.registration}) tax expires in ${daysRemaining} day${dayLabel}`,
              createdAt: now.toISOString(),
              priority: (() => {
                if (daysRemaining <= 7) return 'high';
                if (daysRemaining <= 14) return 'medium';
                return 'low';
              })(),
              vehicleId: vehicle.id,
              vehicleMake: vehicle.make,
              vehicleModel: vehicle.model,
              reminderType: 'tax',
              expiryDate: vehicle.tax_expiry,
              daysRemaining,
              actionRoute: '/owner/settings/vehicle-management',
            });
          }
        }

        // MOT reminder
        if (vehicle.mot_expiry) {
          const motExpiry = new Date(vehicle.mot_expiry);
          const daysRemaining = Math.ceil((motExpiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
          
          if (motExpiry <= thirtyDaysFromNow && motExpiry >= now) {
            const dayLabel = daysRemaining === 1 ? '' : 's';
            reminders.push({
              id: `mot-reminder-${vehicle.id}`,
              type: 'vehicle_reminder',
              title: 'MOT Expiring Soon',
              message: `${vehicle.make} ${vehicle.model} (${vehicle.registration}) MOT expires in ${daysRemaining} day${dayLabel}`,
              createdAt: now.toISOString(),
              priority: (() => {
                if (daysRemaining <= 7) return 'high';
                if (daysRemaining <= 14) return 'medium';
                return 'low';
              })(),
              vehicleId: vehicle.id,
              vehicleMake: vehicle.make,
              vehicleModel: vehicle.model,
              reminderType: 'mot',
              expiryDate: vehicle.mot_expiry,
              daysRemaining,
              actionRoute: '/owner/settings/vehicle-management',
            });
          }
        }
      });

      return reminders;
    } catch (error) {
      console.warn('[Notifications] vehicle reminders error', error);
      return [];
    }
  }, []);

  const fetchRewardNotifications = useCallback(async (userId: string): Promise<UnifiedNotification[]> => {
    try {
      // Check user's reward points and tier
      const { data: userData, error } = await supabase
        .from('users')
        .select('tier_points,tier')
        .eq('id', userId)
        .single();

      if (error || !userData) return [];

      const notifications: UnifiedNotification[] = [];
      const points = userData.tier_points || 0;

      // Check for milestone rewards
      const milestones = [500, 1000, 2000, 3000, 5000];
      const nextMilestone = milestones.find(m => m > points);
      
      if (nextMilestone && points > 0) {
        const pointsNeeded = nextMilestone - points;
        if (pointsNeeded <= 100) {
          notifications.push({
            id: `reward-milestone-${nextMilestone}`,
            type: 'reward',
            title: 'Reward Milestone Approaching',
            message: `You're ${pointsNeeded} points away from unlocking a new reward!`,
            createdAt: new Date().toISOString(),
            priority: 'medium',
            points: nextMilestone,
            actionRoute: '/owner/features/rewards',
          });
        }
      }

      return notifications;
    } catch (error) {
      console.warn('[Notifications] reward notifications error', error);
      return [];
    }
  }, []);

  const fetchNotifications = useCallback(async () => {
    if (!user?.id) {
      setAllNotifications([]);
      setVisibleNotifications([]);
      setLoading(false);
      setRefreshing(false);
      return;
    }

    try {
      if (!refreshing) {
        setLoading(true);
      }

      // Fetch from all sources in parallel
      const [bookingsResult, vehicleReminders, rewardNotifications] = await Promise.all([
        supabase
          .from('bookings')
          .select(
            'id,status,service_name,service_type,price,created_at,updated_at,scheduled_at,time_slot,location_address,address,valeter_name'
          )
          .eq('user_id', user.id)
          .in('status', NOTIFICATION_STATUSES as any)
          .order('created_at', { ascending: false })
          .limit(100),
        fetchVehicleReminders(user.id),
        fetchRewardNotifications(user.id),
      ]);

      const bookingNotifications = (bookingsResult.data && !bookingsResult.error)
        ? bookingsResult.data.map(mapBookingToNotification)
        : [];
      const notifications: UnifiedNotification[] = [
        ...bookingNotifications,
        ...vehicleReminders,
        ...rewardNotifications,
      ];

      // Sort by priority and date (high priority first, then by date)
      notifications.sort((a, b) => {
        const priorityOrder = { high: 3, medium: 2, low: 1 };
        const priorityDiff = priorityOrder[b.priority] - priorityOrder[a.priority];
        if (priorityDiff !== 0) return priorityDiff;
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      });

      setAllNotifications(notifications);
      
      // Debug logging
      if (notifications.length > 0) {
        console.log('[Notifications] Fetched notifications:', {
          total: notifications.length,
          bookingCount: bookingsResult.data?.length || 0,
          vehicleCount: vehicleReminders.length,
          rewardCount: rewardNotifications.length,
        });
      }
    } catch (error) {
      console.warn('[Notifications] unexpected load error', error);
      setAllNotifications([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [refreshing, user?.id, fetchVehicleReminders, fetchRewardNotifications]);

  const attachRealtime = useCallback(() => {
    if (!user?.id) return;
    if (channelRef.current) {
      supabase.removeChannel(channelRef.current);
      channelRef.current = null;
    }
    const channel = supabase
      .channel(`notifications-centre-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'bookings',
          filter: `user_id=eq.${user.id}`,
        },
        () => {
          fetchNotifications();
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'customer_vehicles',
          filter: `user_id=eq.${user.id}`,
        },
        () => {
          fetchNotifications();
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'users',
          filter: `id=eq.${user.id}`,
        },
        () => {
          fetchNotifications();
        }
      )
      .subscribe();
    channelRef.current = channel;
  }, [fetchNotifications, user?.id]);

  useEffect(() => {
    loadDismissed();
  }, [loadDismissed]);

  useEffect(() => {
    fetchNotifications();
  }, [fetchNotifications]);

  useEffect(() => {
    attachRealtime();
    return () => {
      if (channelRef.current) {
        supabase.removeChannel(channelRef.current);
        channelRef.current = null;
      }
    };
  }, [attachRealtime]);

  useEffect(() => {
    const visible = allNotifications.filter((notification) => !dismissedIds.has(notification.id));
    setVisibleNotifications(visible);
    
    // Debug logging
    if (allNotifications.length > 0 || visible.length !== allNotifications.length) {
      console.log('[Notifications] Visible notifications:', {
        total: allNotifications.length,
        dismissed: dismissedIds.size,
        visible: visible.length,
      });
    }
  }, [allNotifications, dismissedIds]);

  const handleDismiss = useCallback(
    async (notificationId: string) => {
      await hapticFeedback('light');
      setVisibleNotifications((prev) => prev.filter((notification) => notification.id !== notificationId));
      setAllNotifications((prev) => prev.filter((notification) => notification.id !== notificationId));
      const next = new Set(dismissedIds);
      next.add(notificationId);
      setDismissedIds(next);
      await persistDismissed(next);
    },
    [dismissedIds, persistDismissed]
  );

  const handleResetDismissed = useCallback(async () => {
    if (!user?.id) return;
    const next = new Set<string>();
    setDismissedIds(next);
    await persistDismissed(next);
    fetchNotifications();
  }, [fetchNotifications, persistDismissed, user?.id]);

  const handleRefresh = useCallback(async () => {
    setRefreshing(true);
    await fetchNotifications();
  }, [fetchNotifications]);

  const primaryRouteForStatus = useCallback((status: string) => {
    if (WAITING_STATUSES.has(status)) return '/owner/track';
    if (status === 'pending_payment') return '/owner/track';
    if (TRACKABLE_STATUSES.has(status)) return '/owner/track';
    return '/owner/wash-history';
  }, []);

  const handleGoToNotification = useCallback(
    (notification: UnifiedNotification) => {
      if (notification.actionRoute) {
        router.push({
          pathname: notification.actionRoute as any,
          params: notification.actionParams || {},
        });
      } else if (notification.type === 'booking' && notification.bookingId) {
        const route = notification.actionRoute || primaryRouteForStatus(notification.status || '');
        router.push({
          pathname: route as any,
          params: notification.actionParams || { bookingId: notification.bookingId },
        });
      } else if (notification.type === 'vehicle_reminder') {
        router.push({
          pathname: '/owner/settings/vehicle-management',
        });
      } else if (notification.type === 'reward') {
        router.push({
          pathname: '/owner/features/rewards',
        });
      }
    },
    []
  );

  const handleGoToHistory = useCallback((notification: UnifiedNotification) => {
    if (notification.bookingId) {
      router.push({
        pathname: '/owner/wash-history',
        params: { highlightId: notification.bookingId },
      });
    } else {
      router.push({
        pathname: '/owner/wash-history',
      });
    }
  }, []);

  const formattedCount = useMemo(
    () => `${visibleNotifications.length} notification${visibleNotifications.length === 1 ? '' : 's'}`,
    [visibleNotifications.length]
  );

  const renderNotification = ({ item }: { item: UnifiedNotification }) => {
    const isBooking = item.type === 'booking';

    return (
      <GlassCard style={styles.notificationCard}>
        <View style={styles.cardHeader}>
          <View style={styles.headerTexts}>
            <View style={styles.titleRow}>
              <GradientIconBox
                icon={notificationIconSolid(item.type)}
                preset="sky"
                boxSize={36}
                size={18}
                elevated
              />
              <Text style={styles.cardTitle}>{item.title}</Text>
            </View>
            <Text style={styles.cardSubtitle}>{formatDate(item.createdAt)}</Text>
          </View>
          {isBooking && item.status && (
            <StatusBadge status={item.status as any} size="small" />
          )}
          {!isBooking && (() => {
            const priorityColor = item.priority === 'high' ? '#EF4444' : item.priority === 'medium' ? '#F59E0B' : '#6B7280';
            return (
              <View style={[styles.priorityBadge, { backgroundColor: priorityColor }]}>
                <Text style={styles.priorityText}>{item.priority}</Text>
              </View>
            );
          })()}
        </View>

        <Text style={styles.messageText}>{item.message}</Text>

        {isBooking && (
          <>
            {item.address && (
              <View style={styles.metaRow}>
                <Ionicons name="location-outline" size={16} color={SKY} />
                <Text style={styles.metaText} numberOfLines={1}>
                  {item.address}
                </Text>
              </View>
            )}

            {item.valeterName && (
              <View style={styles.metaRow}>
                <Ionicons name="person-outline" size={16} color={SKY} />
                <Text style={styles.metaText}>{item.valeterName}</Text>
              </View>
            )}

            {item.price && (
              <View style={styles.priceRow}>
                <Text style={styles.priceLabel}>Total</Text>
                <Text style={styles.priceValue}>{formatCurrency(item.price)}</Text>
              </View>
            )}
          </>
        )}

        {item.type === 'vehicle_reminder' && (
          <View style={styles.metaRow}>
            <Ionicons name="car-outline" size={16} color={SKY} />
            <Text style={styles.metaText}>
              {item.vehicleMake} {item.vehicleModel}
            </Text>
            {item.daysRemaining !== undefined && (
              <Text style={[styles.metaText, { marginLeft: 'auto', fontWeight: '600' }]}>
                {item.daysRemaining} day{item.daysRemaining === 1 ? '' : 's'} left
              </Text>
            )}
          </View>
        )}

        {item.type === 'reward' && item.points && (
          <View style={styles.priceRow}>
            <Text style={styles.priceLabel}>Points needed</Text>
            <Text style={styles.priceValue}>{item.points}</Text>
          </View>
        )}

        <View style={styles.actionsRow}>
          <TouchableOpacity style={styles.primaryButton} onPress={() => handleGoToNotification(item)}>
            {(() => {
              const iconName = isBooking ? 'compass-outline' : (item.type === 'vehicle_reminder' ? 'car-outline' : 'arrow-forward-outline');
              const buttonLabel = isBooking ? 'Go to booking' : (item.type === 'vehicle_reminder' ? 'Manage vehicles' : 'View details');
              return (
                <>
                  <Ionicons name={iconName as any} size={16} color="#0A1929" />
                  <Text style={styles.primaryButtonText}>{buttonLabel}</Text>
                </>
              );
            })()}
          </TouchableOpacity>
          {isBooking && (
            <TouchableOpacity style={styles.secondaryButton} onPress={() => handleGoToHistory(item)}>
              <Text style={styles.secondaryButtonText}>History</Text>
            </TouchableOpacity>
          )}
          <TouchableOpacity style={styles.deleteButton} onPress={() => handleDismiss(item.id)}>
            <Ionicons name="trash-outline" size={20} color="#EF4444" />
          </TouchableOpacity>
        </View>
      </GlassCard>
    );
  };

  const listEmptyComponent = () => (
    <View style={styles.emptyState}>
      <View style={{ opacity: 0.85, marginBottom: 8 }}>
        <GradientIconBox
          icon="notifications-off-outline"
          preset="sky"
          boxSize={72}
          size={32}
          borderRadius={24}
          elevated
        />
      </View>
      <Text style={styles.emptyTitle}>You are fully up to date</Text>
      <Text style={styles.emptySubtitle}>We will surface new updates from bookings, vehicles, rewards, and more the moment they arrive.</Text>
      {dismissedIds.size > 0 && (
        <TouchableOpacity style={styles.restoreButton} onPress={handleResetDismissed}>
          <Ionicons name="refresh-outline" size={16} color={BG} />
          <Text style={styles.restoreButtonText}>Restore dismissed</Text>
        </TouchableOpacity>
      )}
    </View>
  );

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      <AppHeader
        title="Notifications"
        {...(!loading ? { subtitle: `Priority updates · ${formattedCount}` } : {})}
        variant="dashboard"
        showBack
        onBack={() => { hapticFeedback('light'); router.back(); }}
        accountType="customer"
        rightAction={
          <GradientNotificationBell
            count={visibleNotifications.length}
            accentColor={colors.SKY}
            disabled
          />
        }
      />

      {loading ? (
        <View style={[styles.listContent, scrollPad]}>
          <SkeletonList count={6} />
        </View>
      ) : (
        <FlatList
          data={visibleNotifications}
          keyExtractor={(item) => item.id}
          contentContainerStyle={[
              styles.listContent,
              scrollPad,
            ]}
          renderItem={renderNotification}
          ListEmptyComponent={listEmptyComponent}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={SKY} />}
        />
      )}
    </SafeAreaView>
  );
}

const formatCurrency = (value?: number | null) => {
  if (typeof value !== 'number') return '£—';
  return `£${value.toFixed(2).replace(/\.00$/, '')}`;
};

const formatDate = (iso?: string | null) => {
  if (!iso) return 'Just now';
  return new Date(iso).toLocaleString('en-GB', {
    day: 'numeric',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  });
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  listContent: {
    paddingHorizontal: SPACING.xl,
    paddingTop: SPACING.lg,
    paddingBottom: 40,
    gap: SPACING.lg,
  },
  notificationCard: {
    padding: SPACING.lg,
    borderRadius: BORDER_RADIUS.lg,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.18,
    shadowRadius: 10,
    elevation: 4,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
    gap: 12,
  },
  headerTexts: {
    flex: 1,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  cardTitle: {
    color: '#F9FAFB',
    fontSize: FONT_SIZES.base,
    fontWeight: '700',
    flex: 1,
  },
  messageText: {
    color: '#E5E7EB',
    fontSize: FONT_SIZES.md,
    marginTop: SPACING.sm,
    marginBottom: SPACING.md,
    lineHeight: 20,
  },
  priorityBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  priorityText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: '600',
    textTransform: 'uppercase',
  },
  cardSubtitle: {
    color: '#B3C0D5',
    fontSize: 12,
    marginTop: 2,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 4,
  },
  metaText: {
    color: '#E5E7EB',
    flex: 1,
    fontSize: 13,
  },
  priceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'baseline',
    marginTop: 12,
  },
  priceLabel: {
    color: '#94A3B8',
    fontSize: 12,
  },
  priceValue: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
  },
  actionsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginTop: 16,
  },
  primaryButton: {
    flex: 1,
    backgroundColor: SKY,
    paddingVertical: SPACING.sm + 2,
    borderRadius: BORDER_RADIUS.sm + 2,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
  },
  primaryButtonText: {
    color: '#0A1929',
    fontWeight: '600',
  },
  secondaryButton: {
    paddingVertical: SPACING.sm + 2,
    paddingHorizontal: SPACING.lg,
    borderRadius: BORDER_RADIUS.sm + 2,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  secondaryButtonText: {
    color: SKY,
    fontWeight: '600',
  },
  deleteButton: {
    padding: 8,
    borderRadius: 10,
    backgroundColor: 'rgba(239,68,68,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 80,
    gap: 12,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '600',
  },
  emptySubtitle: {
    color: '#94A3B8',
    fontSize: 14,
    textAlign: 'center',
    paddingHorizontal: 20,
  },
  restoreButton: {
    marginTop: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: SKY,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 12,
  },
  restoreButtonText: {
    color: BG,
    fontWeight: '600',
  },
  loadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  loadingText: {
    color: '#E5E7EB',
    fontSize: 14,
  },
});

