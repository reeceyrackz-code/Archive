import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Alert,
  ScrollView,
  Modal,
  Pressable,
  ActivityIndicator,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  Dimensions,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Video, ResizeMode } from 'expo-av';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import MapView, { Marker, Region } from 'react-native-maps';
import * as Location from 'expo-location';
import AppHeader from '../../../src/components/shared/AppHeader';
import { BookingHeaderMapControlButton } from '../../../src/components/shared/BookingHeaderMapControlButton';
import useLiveLocation from '../../../src/hooks/useLiveLocation';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { loadPersistedCustomerDashboardMapLocation } from '../../../src/services/customerDashboardMapLocationStorage';
import { colors } from '../../../src/constants/colors';
import {
  getBookingIndexOptionCardWidth,
  getBookingIndexOptionSnapInterval,
  HEADER_STYLE_CARD_GRADIENT,
  PREMIUM_BOOKING_MAP_SHEET_GLASS,
} from '../../../src/constants/bookingCardTheme';
import IndexTrackingCardShell, { indexTrackingCardStyles as ix } from '../../../src/components/booking/IndexTrackingCardShell';
import BookingSheetPremiumLayers from '../../../src/components/booking/BookingSheetPremiumLayers';
import BookingBottomSheetOverlay from '../../../src/components/booking/BookingBottomSheetOverlay';
import { customerMapTrackingSheetActionStyles } from '../../../src/components/booking/CustomerMapTrackingSheetShell';
import { ACTIVE_CUSTOMER_BOOKING_STATUSES } from '../../../src/utils/activeBookingGuard';
import {
  BOOKING_MAP_STYLE,
  DEFAULT_MAP_REGION,
  LOCATION_PICKER_MAP_STYLE,
  MAP_LOCKED_DARK,
  MAP_CAMERA_ANIMATION_DURATION,
} from '../../../src/constants/mapConstants';
import {
  MapMarkerWashHub,
  MapMarkerDetailingHub,
  MapMarkerCustomerVehicle,
} from '../../../src/components/maps/MapMarkerViews';
import { useBookingFlowTheme } from '../../../src/contexts/BookingFlowThemeContext';
import { BOOKING_FLOW_VIDEO } from '../../assets/assetExports';
import { WWPrimaryButton, WWSheetCloseButton } from '../../../src/components/ui';
import GradientIconBox from '../../../src/components/shared/GradientIconBox';
import { accentToGradient } from '../../../src/utils/accentGradient';

const SKY = colors.SKY;
const DETAILING_YELLOW = colors.DETAILING_YELLOW;
const { width: SCREEN_W, height: SCREEN_H } = Dimensions.get('window');

const NEARBY_MAP_FIT_PADDING = { top: 72, right: 24, bottom: 100, left: 24 } as const;
/** Option tiles sized to the glass sheet inner width + horizontal peek. */
const INDEX_OPTION_CARD_WIDTH = getBookingIndexOptionCardWidth(SCREEN_W);
const INDEX_OPTION_SNAP_INTERVAL = getBookingIndexOptionSnapInterval(SCREEN_W);

/** Index only chooses delivery mode; wash vs detailing is chosen on the service sheets. */
const bookingIndexOptions = [
  {
    id: 'come-to-you',
    title: 'Come To You',
    subtitle: 'We come to your location',
    description:
      'A vetted professional brings the service to you with live tracking and updates. Choose wash or detailing when you pick your package.',
    trustLine: 'Vetted professionals',
    eta: '10–30 mins',
    icon: 'car-sport',
    route: '/owner/booking/create',
    params: {} as Record<string, string>,
  },
  {
    id: 'come-to-us',
    title: 'Come To Us',
    subtitle: 'Book at a verified wash or studio nearby',
    description:
      'Book a slot at a verified location nearby. Choose car wash or detail studio when you browse hubs.',
    trustLine: 'Verified locations',
    eta: "Today's slots",
    icon: 'business',
    route: '/owner/booking/physical/location',
    params: {} as Record<string, string>,
  },
] as const;

type LocationSearchResultItem = {
  id: string;
  description: string;
  latitude: number;
  longitude: number;
};

type ActiveBooking = { id: string; status: string };
type ProviderLocation = {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
  detailing_offered?: boolean | null;
};
type PickerLocation = { latitude: number; longitude: number; address: string };

export default function WashTypeSelection() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { setTheme } = useBookingFlowTheme();

  const [indexFocusedOptionId, setIndexFocusedOptionId] = useState<(typeof bookingIndexOptions)[number]['id']>(
    bookingIndexOptions[0].id,
  );

  const [activeBooking, setActiveBooking] = useState<ActiveBooking | null>(null);
  const [checkingActive, setCheckingActive] = useState(false);
  const [infoModalOption, setInfoModalOption] = useState<(typeof bookingIndexOptions)[number] | null>(null);
  const [locationPickerVisible, setLocationPickerVisible] = useState(false);
  const [changeLocationVisible, setChangeLocationVisible] = useState(false);
  const [pendingOption, setPendingOption] = useState<(typeof bookingIndexOptions)[number] | null>(null);
  const [pickerLocation, setPickerLocation] = useState<PickerLocation | null>(null);
  const [pickerLoading, setPickerLoading] = useState(false);
  const [locationSearch, setLocationSearch] = useState('');
  /** Device geocoder (arrow / search) — uses expo-location, not Google Places API */
  const [searchGeocodeLoading, setSearchGeocodeLoading] = useState(false);
  const [searchResults, setSearchResults] = useState<LocationSearchResultItem[]>([]);
  const [pickerMapRegion, setPickerMapRegion] = useState<Region | null>(null);
  const [providerLocations, setProviderLocations] = useState<ProviderLocation[]>([]);
  /** Nearby hubs / studios on a map — opened from header tracking icon (video stays full-screen). */
  const [showNearbyMapSheet, setShowNearbyMapSheet] = useState(false);
  const [nearbyMapFocusId, setNearbyMapFocusId] = useState<string | null>(null);
  const pickerMapGeocodeDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const { coords: liveCoords } = useLiveLocation();
  const [region, setRegion] = useState<Region | null>(null);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);

  const mapRef = useRef<MapView>(null);
  const indexOptionsScrollRef = useRef<ScrollView>(null);
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(40)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    setTheme('wash');
  }, [setTheme]);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 450, useNativeDriver: true }),
      Animated.spring(slideAnim, { toValue: 0, tension: 60, friction: 8, useNativeDriver: true }),
    ]).start();
  }, [fadeAnim, slideAnim]);

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, { toValue: 1.2, duration: 1000, useNativeDriver: true }),
        Animated.timing(markerPulse, { toValue: 1, duration: 1000, useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [markerPulse]);

  useEffect(() => {
    if (liveCoords) {
      const c = { latitude: liveCoords.latitude, longitude: liveCoords.longitude };
      setUserLocation(c);
      setRegion({ ...c, latitudeDelta: 0.001, longitudeDelta: 0.001 });
      return;
    }
    (async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status !== 'granted') return;
        const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
        const c = { latitude: loc.coords.latitude, longitude: loc.coords.longitude };
        setUserLocation(c);
        setRegion({ ...c, latitudeDelta: 0.001, longitudeDelta: 0.001 });
      } catch {}
    })();
  }, [liveCoords]);

  useEffect(() => {
    const loadProviders = async () => {
      try {
        const { data, error } = await supabase
          .from('car_wash_locations')
          .select('id,name,latitude,longitude,detailing_offered');
        if (error) return;
        const normalized = (data || [])
          .map((row: any) => ({
            id: String(row.id),
            name: row.name || 'Service Provider',
            latitude: Number(row.latitude),
            longitude: Number(row.longitude),
            detailing_offered: row.detailing_offered ?? null,
          }))
          .filter((p: ProviderLocation) => Number.isFinite(p.latitude) && Number.isFinite(p.longitude));
        setProviderLocations(normalized);
      } catch {}
    };
    loadProviders();
  }, []);

  useEffect(() => {
    if (!user?.id) return;
    const loadActiveBooking = async () => {
      try {
        setCheckingActive(true);
        const { data, error } = await supabase
          .from('bookings')
          .select('id,status')
          .eq('user_id', user.id)
          .in('status', [...ACTIVE_CUSTOMER_BOOKING_STATUSES])
          .order('created_at', { ascending: false })
          .limit(1)
          .maybeSingle();
        if (error || !data) {
          setActiveBooking(null);
          return;
        }
        setActiveBooking({ id: data.id, status: data.status });
      } finally {
        setCheckingActive(false);
      }
    };
    loadActiveBooking();
    const channel = supabase
      .channel(`wash-type-active-booking-${user.id}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'bookings', filter: `user_id=eq.${user.id}` },
        () => loadActiveBooking()
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id]);

  const goToActiveBooking = () => {
    if (!activeBooking?.id) return;
    router.push({ pathname: '/owner/booking/tracking', params: { bookingId: activeBooking.id } } as any);
  };

  const handleSelect = async (option: (typeof bookingIndexOptions)[number]) => {
    if (checkingActive) return;
    if (activeBooking?.id) {
      Alert.alert(
        'One booking at a time',
        'You already have an active booking. Please complete or cancel it before starting a new one.',
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'View my booking', onPress: goToActiveBooking },
        ]
      );
      return;
    }
    await hapticFeedback('medium');
    if (option.route === '/owner/booking/create') {
      setPendingOption(option);
      setLocationPickerVisible(true);
      setPickerLoading(true);
      try {
        const persisted = await loadPersistedCustomerDashboardMapLocation();
        if (persisted) {
          const coords = { latitude: persisted.latitude, longitude: persisted.longitude };
          setPickerLocation({ ...coords, address: persisted.address });
          setRegion({ ...coords, latitudeDelta: 0.001, longitudeDelta: 0.001 });
          return;
        }
        let coords = userLocation;
        if (!coords) {
          const { status } = await Location.requestForegroundPermissionsAsync();
          if (status === 'granted') {
            const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
            coords = { latitude: loc.coords.latitude, longitude: loc.coords.longitude };
            setUserLocation(coords);
            setRegion({ ...coords, latitudeDelta: 0.001, longitudeDelta: 0.001 });
          }
        }
        if (coords) {
          try {
            const [result] = await Location.reverseGeocodeAsync(coords);
            const addr = result
              ? `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim() || 'Current location'
              : 'Current location';
            setPickerLocation({ ...coords, address: addr });
          } catch {
            setPickerLocation({ ...coords, address: 'Current location' });
          }
        }
      } finally {
        setPickerLoading(false);
      }
      return;
    }
    if (Object.keys(option.params).length > 0) {
      router.push({ pathname: option.route as any, params: option.params });
    } else {
      router.push(option.route as any);
    }
  };

  const handleConfirmPickerLocation = async () => {
    if (!pendingOption || !pickerLocation) return;
    await hapticFeedback('medium');
    setLocationPickerVisible(false);
    router.push({
      pathname: pendingOption.route as any,
      params: {
        ...pendingOption.params,
        latitude: String(pickerLocation.latitude),
        longitude: String(pickerLocation.longitude),
        address: pickerLocation.address,
        startAtVehicle: 'true',
      },
    });
  };

  const handleManualLocationSearch = async () => {
    const q = locationSearch.trim();
    if (!q) return;
    setSearchGeocodeLoading(true);
    try {
      const results = await Location.geocodeAsync(q);
      if (!results?.length) {
        Alert.alert('Not found', 'No matching location found. Try a fuller address or postcode.');
        setSearchResults([]);
        return;
      }
      const max = Math.min(results.length, 8);
      const items: LocationSearchResultItem[] = [];
      for (let i = 0; i < max; i++) {
        const r = results[i];
        let description = q;
        try {
          const [rev] = await Location.reverseGeocodeAsync({ latitude: r.latitude, longitude: r.longitude });
          if (rev) {
            const line = `${rev.street || ''} ${rev.city || ''} ${rev.postalCode || ''}`.trim();
            if (line) description = line;
          }
        } catch {
          /* keep typed query as fallback label */
        }
        items.push({
          id: `${r.latitude.toFixed(5)}-${r.longitude.toFixed(5)}-${i}`,
          description,
          latitude: r.latitude,
          longitude: r.longitude,
        });
      }
      if (items.length === 1) {
        const only = items[0];
        setPickerLocation({
          latitude: only.latitude,
          longitude: only.longitude,
          address: only.description,
        });
        setPickerMapRegion({
          latitude: only.latitude,
          longitude: only.longitude,
          latitudeDelta: 0.0012,
          longitudeDelta: 0.0012,
        });
        setLocationSearch(only.description);
        setSearchResults([]);
      } else {
        setSearchResults(items);
      }
    } catch (e) {
      Alert.alert('Search failed', (e as Error)?.message ?? 'Could not look up that address. Try again.');
      setSearchResults([]);
    } finally {
      setSearchGeocodeLoading(false);
    }
  };

  const resolvePickerMapAddress = async (coords: { latitude: number; longitude: number }) => {
    try {
      const [result] = await Location.reverseGeocodeAsync(coords);
      const addr = result
        ? `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim() || 'Selected location'
        : 'Selected location';
      setPickerLocation({ ...coords, address: addr });
    } catch {
      setPickerLocation({ ...coords, address: 'Selected location' });
    }
  };

  useEffect(() => {
    if (!changeLocationVisible) {
      setSearchResults([]);
      setSearchGeocodeLoading(false);
    }
  }, [changeLocationVisible]);

  useEffect(() => {
    if (!changeLocationVisible) return;
    setSearchResults([]);
  }, [locationSearch, changeLocationVisible]);

  useEffect(() => {
    if (!locationPickerVisible && !changeLocationVisible) return;
    if (!pickerLocation) return;
    setPickerMapRegion({
      latitude: pickerLocation.latitude,
      longitude: pickerLocation.longitude,
      latitudeDelta: 0.0012,
      longitudeDelta: 0.0012,
    });
  }, [locationPickerVisible, changeLocationVisible, pickerLocation]);

  const visibleProviders = useMemo(() => providerLocations, [providerLocations]);
  const sheetProviders = visibleProviders;
  const primaryColor = SKY;

  useEffect(() => {
    if (!showNearbyMapSheet) {
      setNearbyMapFocusId(null);
      return;
    }
    const coords: { latitude: number; longitude: number }[] = [];
    if (userLocation) coords.push(userLocation);
    sheetProviders.forEach((p) => coords.push({ latitude: p.latitude, longitude: p.longitude }));
    const id = requestAnimationFrame(() => {
      if (!mapRef.current) return;
      if (coords.length >= 2) {
        mapRef.current.fitToCoordinates(coords, {
          edgePadding: { ...NEARBY_MAP_FIT_PADDING },
          animated: true,
        });
      } else if (coords.length === 1) {
        mapRef.current.animateToRegion(
          { ...coords[0], latitudeDelta: 0.06, longitudeDelta: 0.06 },
          MAP_CAMERA_ANIMATION_DURATION,
        );
      } else {
        mapRef.current.animateToRegion(
          {
            latitude: DEFAULT_MAP_REGION.latitude,
            longitude: DEFAULT_MAP_REGION.longitude,
            latitudeDelta: 0.12,
            longitudeDelta: 0.12,
          },
          MAP_CAMERA_ANIMATION_DURATION,
        );
      }
    });
    return () => cancelAnimationFrame(id);
  }, [showNearbyMapSheet, sheetProviders, userLocation]);

  const handleNearbyMapRecenter = useCallback(async () => {
    await hapticFeedback('light');
    const coords: { latitude: number; longitude: number }[] = [];
    if (userLocation) coords.push(userLocation);
    sheetProviders.forEach((p) => coords.push({ latitude: p.latitude, longitude: p.longitude }));
    if (!mapRef.current) return;
    if (userLocation) {
      mapRef.current.animateToRegion(
        { ...userLocation, latitudeDelta: 0.04, longitudeDelta: 0.04 },
        MAP_CAMERA_ANIMATION_DURATION,
      );
      return;
    }
    if (coords.length >= 2) {
      mapRef.current.fitToCoordinates(coords, {
        edgePadding: { ...NEARBY_MAP_FIT_PADDING },
        animated: true,
      });
    } else if (coords.length === 1) {
      mapRef.current.animateToRegion(
        { ...coords[0], latitudeDelta: 0.06, longitudeDelta: 0.06 },
        MAP_CAMERA_ANIMATION_DURATION,
      );
    }
  }, [userLocation, sheetProviders]);

  const handleNearbyProviderChip = useCallback(
    (p: ProviderLocation) => {
      void hapticFeedback('light');
      setNearbyMapFocusId(p.id);
      mapRef.current?.animateToRegion(
        {
          latitude: p.latitude,
          longitude: p.longitude,
          latitudeDelta: 0.035,
          longitudeDelta: 0.035,
        },
        MAP_CAMERA_ANIMATION_DURATION,
      );
    },
    [],
  );

  const indexSelectedOption = useMemo(
    () => bookingIndexOptions.find((o) => o.id === indexFocusedOptionId) ?? bookingIndexOptions[0],
    [indexFocusedOptionId],
  );

  const syncIndexSelectionFromScroll = useCallback((offsetX: number) => {
    const idx = Math.round(offsetX / INDEX_OPTION_SNAP_INTERVAL);
    const clamped = Math.max(0, Math.min(idx, bookingIndexOptions.length - 1));
    setIndexFocusedOptionId(bookingIndexOptions[clamped].id);
  }, []);

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <Video
        source={BOOKING_FLOW_VIDEO}
        style={StyleSheet.absoluteFill}
        shouldPlay
        isLooping
        isMuted
        resizeMode={ResizeMode.COVER}
      />

      <AppHeader
        title="Book a Service"
        subtitle="Choose how you want to book"
        showBack
        onBack={() => router.back()}
        primaryColor={primaryColor}
        rightAction={(
          <BookingHeaderMapControlButton
            onPress={() => {
              void hapticFeedback('light');
              setShowNearbyMapSheet(true);
            }}
            accentColor={primaryColor}
            accessibilityLabel="Open nearby map"
          />
        )}
      />

      <Animated.View
        style={[
          styles.sheetContainer,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
            bottom: 0,
          },
        ]}
      >
        <View
          style={[
            styles.sheetPanel,
            {
              maxHeight: Math.min(SCREEN_H * 0.44, 428),
              paddingBottom: Math.max(insets.bottom, 16),
            },
          ]}
        >
          <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} />
          <LinearGradient
            colors={HEADER_STYLE_CARD_GRADIENT}
            style={StyleSheet.absoluteFill}
          />
          <LinearGradient
            colors={['rgba(255,255,255,0.16)', 'rgba(255,255,255,0.02)', 'transparent']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.sheetSheen}
            pointerEvents="none"
          />
          <BookingSheetPremiumLayers />

          <View style={styles.handle} />

          <ScrollView
            ref={indexOptionsScrollRef}
            horizontal
            showsHorizontalScrollIndicator={false}
            style={styles.optionsScroll}
            contentContainerStyle={styles.optionsScrollContent}
            snapToInterval={INDEX_OPTION_SNAP_INTERVAL}
            snapToAlignment="start"
            decelerationRate="fast"
            disableIntervalMomentum
            onMomentumScrollEnd={(e) => syncIndexSelectionFromScroll(e.nativeEvent.contentOffset.x)}
            onScrollEndDrag={(e) => syncIndexSelectionFromScroll(e.nativeEvent.contentOffset.x)}
          >
            {bookingIndexOptions.map((option, optionIndex) => {
              const isMobile = option.id === 'come-to-you';
              const hubIcon = 'business';
              const isFocused = indexFocusedOptionId === option.id;
              return (
                <TouchableOpacity
                  key={option.id}
                  activeOpacity={0.92}
                  onPress={() => {
                    void hapticFeedback('light');
                    setIndexFocusedOptionId(option.id);
                    indexOptionsScrollRef.current?.scrollTo({
                      x: optionIndex * INDEX_OPTION_SNAP_INTERVAL,
                      animated: true,
                    });
                  }}
                  style={[ix.cardWrap, styles.indexOptionCardOuter, { width: INDEX_OPTION_CARD_WIDTH }]}
                  accessibilityRole="button"
                  accessibilityLabel={`${option.title}. ${isFocused ? 'Selected.' : ''} Use Continue to proceed.`}
                >
                  <IndexTrackingCardShell
                    accentColor={primaryColor}
                    style={{
                      borderWidth: 2,
                      borderColor: isFocused ? primaryColor + 'AA' : 'rgba(148,163,184,0.35)',
                    }}
                  >
                    <View style={ix.optionCardTopRow}>
                      <GradientIconBox
                        icon={isMobile ? 'car-sport' : hubIcon}
                        colors={accentToGradient(primaryColor)}
                        boxSize={44}
                        borderRadius={16}
                        elevated
                        size={22}
                      />
                      <View style={ix.optionTitleMain}>
                        <Text style={ix.optionKicker}>{isMobile ? 'MOBILE' : 'VISIT US'}</Text>
                        <Text style={ix.optionTitle} numberOfLines={2} ellipsizeMode="tail">
                          {option.title}
                        </Text>
                        <Text style={ix.optionSubtitle} numberOfLines={2} ellipsizeMode="tail">
                          {option.subtitle}
                        </Text>
                      </View>
                      <TouchableOpacity
                        style={[ix.optionInfoBtn, { borderColor: 'transparent', backgroundColor: 'transparent' }]}
                        onPress={() => {
                          hapticFeedback('light');
                          setInfoModalOption(option);
                        }}
                        activeOpacity={0.85}
                        accessibilityLabel="More information"
                        accessibilityRole="button"
                      >
                        <GradientIconBox
                          icon="information-circle-outline"
                          colors={accentToGradient(primaryColor)}
                          boxSize={40}
                          borderRadius={14}
                          elevated
                          size={22}
                        />
                      </TouchableOpacity>
                    </View>
                    <View style={ix.optionFooterRow}>
                      <View style={ix.optionFooterLeft}>
                        <View style={[ix.optionStatusPill, { backgroundColor: 'rgba(16,185,129,0.18)', borderColor: 'rgba(52,211,153,0.25)' }]}>
                          <View style={ix.optionStatusDot} />
                          <Text style={ix.optionStatusText} numberOfLines={1}>
                          Live
                        </Text>
                        </View>
                      </View>
                    </View>
                  </IndexTrackingCardShell>
                </TouchableOpacity>
              );
            })}
          </ScrollView>

          <View style={styles.indexSheetCtaRow}>
            <View style={{ width: INDEX_OPTION_CARD_WIDTH, alignSelf: 'flex-start' }}>
              <TouchableOpacity
                style={[
                  customerMapTrackingSheetActionStyles.bookingInfoActionCard,
                  customerMapTrackingSheetActionStyles.bookingInfoCard,
                  styles.indexBookingSheetTrackingCta,
                  {
                    borderColor: primaryColor + '8A',
                    opacity: checkingActive ? 0.45 : 1,
                  },
                ]}
                onPress={() => void handleSelect(indexSelectedOption)}
                disabled={checkingActive}
                activeOpacity={0.85}
                accessibilityRole="button"
                accessibilityLabel="Continue with selected booking type"
              >
                <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
                <LinearGradient
                  colors={[primaryColor + '59', 'rgba(15,23,42,0.65)']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 0, y: 1 }}
                  style={StyleSheet.absoluteFill}
                  pointerEvents="none"
                />
                <View style={{ zIndex: 1 }}>
                  <GradientIconBox
                    icon="arrow-forward-circle"
                    colors={accentToGradient(primaryColor)}
                    boxSize={36}
                    borderRadius={12}
                    elevated
                    size={18}
                  />
                </View>
                <View style={customerMapTrackingSheetActionStyles.bookingInfoCardTextWrap}>
                  <Text style={[styles.indexBookingSheetCtaLabel, { color: primaryColor }]}>Continue</Text>
                </View>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Animated.View>

      <BookingBottomSheetOverlay
        visible={!!infoModalOption}
        onClose={() => setInfoModalOption(null)}
        maxHeightRatio={0.88}
      >
        {infoModalOption ? (
          <ScrollView
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
            contentContainerStyle={styles.infoSheetScrollContent}
          >
            <Text style={[styles.modalTitle, { color: primaryColor }]} numberOfLines={3}>
              {infoModalOption.title}
            </Text>
            <Text style={styles.modalSub}>{infoModalOption.subtitle}</Text>
            <Text style={styles.modalSectionLabel}>About this option</Text>
            <Text style={styles.modalDesc}>{infoModalOption.description}</Text>
            <View style={[styles.modalDetailCard, { borderColor: primaryColor + '35' }]}>
              <View style={styles.modalDetailRow}>
                <Ionicons name="time-outline" size={18} color={primaryColor} />
                <View style={styles.modalDetailTextCol}>
                  <Text style={styles.modalDetailLabel}>Typical timing</Text>
                  <Text style={styles.modalDetailValue}>{infoModalOption.eta}</Text>
                </View>
              </View>
              <View style={styles.modalDetailDivider} />
              <View style={styles.modalDetailRow}>
                <Ionicons name="shield-checkmark-outline" size={18} color="#94A3B8" />
                <View style={styles.modalDetailTextCol}>
                  <Text style={styles.modalDetailLabel}>Trust & quality</Text>
                  <Text style={styles.modalDetailValue}>{infoModalOption.trustLine}</Text>
                </View>
              </View>
            </View>
            <TouchableOpacity
              style={[
                customerMapTrackingSheetActionStyles.bookingInfoActionCard,
                customerMapTrackingSheetActionStyles.bookingInfoCard,
                styles.indexBookingSheetTrackingCta,
                styles.infoSheetContinueCta,
                {
                  borderColor: primaryColor + '8A',
                  opacity: checkingActive ? 0.45 : 1,
                },
              ]}
              onPress={() => {
                const o = infoModalOption;
                if (!o) return;
                setInfoModalOption(null);
                void handleSelect(o);
              }}
              disabled={checkingActive}
              activeOpacity={0.85}
              accessibilityRole="button"
              accessibilityLabel="Continue with this option"
            >
              <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
              <LinearGradient
                colors={[primaryColor + '59', 'rgba(15,23,42,0.65)']}
                start={{ x: 0, y: 0 }}
                end={{ x: 0, y: 1 }}
                style={StyleSheet.absoluteFill}
                pointerEvents="none"
              />
              <Ionicons name="arrow-forward-circle" size={18} color={primaryColor} style={{ zIndex: 1 }} />
              <View style={customerMapTrackingSheetActionStyles.bookingInfoCardTextWrap}>
                <Text style={[styles.indexBookingSheetCtaLabel, { color: primaryColor }]}>Continue</Text>
              </View>
            </TouchableOpacity>
          </ScrollView>
        ) : null}
      </BookingBottomSheetOverlay>

      <Modal
        visible={locationPickerVisible}
        transparent
        animationType="slide"
        onRequestClose={() => setLocationPickerVisible(false)}
      >
        <KeyboardAvoidingView
          style={styles.locationPickerKeyboardWrap}
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          keyboardVerticalOffset={12}
        >
          <Pressable style={styles.locationPickerOverlay} onPress={() => setLocationPickerVisible(false)}>
            <Pressable style={styles.locationPickerSheet} onPress={(e) => e.stopPropagation()}>
            <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} />
            <LinearGradient colors={HEADER_STYLE_CARD_GRADIENT} style={StyleSheet.absoluteFill} />
            <LinearGradient
              colors={['rgba(255,255,255,0.16)', 'rgba(255,255,255,0.02)', 'transparent']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.sheetSheen}
            />
            <View style={styles.handle} />
            {pickerLoading ? (
              <View style={styles.locationPickerLoading}>
                <ActivityIndicator size="small" color={primaryColor} />
                <Text style={styles.locationPickerLoadingText}>Finding your location...</Text>
              </View>
            ) : (
              <>
                <View style={styles.pickerMiniMapWrap}>
                  <MapView
                    style={styles.pickerMiniMap}
                    region={pickerMapRegion ?? {
                      latitude: pickerLocation?.latitude ?? userLocation?.latitude ?? DEFAULT_MAP_REGION.latitude,
                      longitude: pickerLocation?.longitude ?? userLocation?.longitude ?? DEFAULT_MAP_REGION.longitude,
                      latitudeDelta: 0.0012,
                      longitudeDelta: 0.0012,
                    }}
                    onRegionChangeComplete={(r) => setPickerMapRegion(r)}
                    onPress={(e) => {
                      const c = e.nativeEvent.coordinate;
                      setPickerMapRegion({
                        latitude: c.latitude,
                        longitude: c.longitude,
                        latitudeDelta: pickerMapRegion?.latitudeDelta ?? 0.0012,
                        longitudeDelta: pickerMapRegion?.longitudeDelta ?? 0.0012,
                      });
                      if (pickerMapGeocodeDebounceRef.current) clearTimeout(pickerMapGeocodeDebounceRef.current);
                      pickerMapGeocodeDebounceRef.current = setTimeout(() => {
                        void resolvePickerMapAddress(c);
                      }, 220);
                    }}
                    scrollEnabled
                    zoomEnabled
                    rotateEnabled={false}
                    pitchEnabled={false}
                    toolbarEnabled={false}
                    customMapStyle={LOCATION_PICKER_MAP_STYLE}
                    userInterfaceStyle={MAP_LOCKED_DARK}
                  >
                    {pickerLocation && (
                      <Marker coordinate={{ latitude: pickerLocation.latitude, longitude: pickerLocation.longitude }}>
                        <Animated.View style={{ transform: [{ scale: markerPulse }] }}>
                          <MapMarkerCustomerVehicle size={40} variant="car" />
                        </Animated.View>
                      </Marker>
                    )}
                  </MapView>
                </View>
                <View style={styles.locationPreviewCard}>
                  <View style={styles.locationPreviewCardRow}>
                    <Ionicons name="location-outline" size={18} color={primaryColor} />
                    <Text style={styles.locationPreviewText} numberOfLines={2}>
                      {pickerLocation?.address || 'Location unavailable'}
                    </Text>
                  </View>
                  <Text style={styles.pickupLocationMicrocopy}>This is where your car will be cleaned</Text>
                </View>
                <Text style={styles.pickerMiniMapHint}>Pinch to zoom and tap map for exact pickup point</Text>
                <TouchableOpacity
                  style={styles.locationPickerSecondaryBtn}
                  onPress={() => {
                setLocationPickerVisible(false);
                setChangeLocationVisible(true);
                  }}
                  activeOpacity={0.85}
                >
                  <View style={[ix.optionChevronWrap, { borderColor: 'rgba(255,255,255,0.28)', backgroundColor: 'rgba(255,255,255,0.1)' }]}>
                    <Ionicons name="create-outline" size={13} color="#E2E8F0" />
                  </View>
                  <Text style={styles.locationPickerSecondaryText}>Change location</Text>
                </TouchableOpacity>
                <WWPrimaryButton
                  title="Confirm pickup location"
                  onPress={handleConfirmPickerLocation}
                  disabled={!pickerLocation}
                  leftIconName="checkmark"
                  leftIconSize={18}
                  style={{ marginTop: 6, marginBottom: 10 }}
                />
              </>
            )}
            </Pressable>
          </Pressable>
        </KeyboardAvoidingView>
      </Modal>

      <Modal
        visible={changeLocationVisible}
        transparent
        animationType="slide"
        onRequestClose={() => setChangeLocationVisible(false)}
      >
        <KeyboardAvoidingView
          style={styles.locationPickerKeyboardWrap}
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          keyboardVerticalOffset={12}
        >
          <Pressable style={styles.locationPickerOverlay} onPress={() => setChangeLocationVisible(false)}>
            <Pressable style={styles.locationPickerSheet} onPress={(e) => e.stopPropagation()}>
            <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} />
            <LinearGradient colors={HEADER_STYLE_CARD_GRADIENT} style={StyleSheet.absoluteFill} />
            <LinearGradient
              colors={['rgba(255,255,255,0.16)', 'rgba(255,255,255,0.02)', 'transparent']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.sheetSheen}
            />
            <View style={styles.handle} />
            <Text style={styles.locationPickerTitle}>Change location</Text>
            <Text style={styles.locationPickerSearchMicrocopy}>
              Enter an address or postcode and tap → to search (device geocoding). Tap a result or the map to fine-tune.
            </Text>
            <View
              style={[
                styles.searchInputWrap,
                { borderColor: `${primaryColor}55` },
              ]}
            >
              <Ionicons name="search" size={20} color={primaryColor} />
              <TextInput
                style={styles.searchInput}
                placeholder="Postcode, street, or place"
                placeholderTextColor="#94A3B8"
                value={locationSearch}
                onChangeText={setLocationSearch}
                onFocus={() => {
                  setLocationSearch('');
                  setSearchResults([]);
                  setSearchGeocodeLoading(false);
                }}
                onSubmitEditing={() => { void handleManualLocationSearch(); }}
                returnKeyType="search"
                autoCorrect={false}
                autoCapitalize="none"
                editable={!searchGeocodeLoading}
                blurOnSubmit={false}
              />
              <TouchableOpacity
                style={[
                  styles.searchActionBtn,
                  {
                    backgroundColor: `${primaryColor}34`,
                    borderColor: `${primaryColor}CC`,
                  },
                  (!locationSearch.trim() || searchGeocodeLoading) && { opacity: 0.45 },
                ]}
                onPress={() => { void handleManualLocationSearch(); }}
                activeOpacity={0.85}
                disabled={!locationSearch.trim() || searchGeocodeLoading}
                accessibilityLabel="Search address"
              >
                {searchGeocodeLoading ? (
                  <ActivityIndicator size="small" color="#FFFFFF" />
                ) : (
                  <Ionicons name="arrow-forward" size={18} color="#FFFFFF" />
                )}
              </TouchableOpacity>
            </View>
            <TouchableOpacity
              style={[styles.useCurrentBtn, { borderColor: `${primaryColor}38` }]}
              onPress={async () => {
                setPickerLoading(true);
                try {
                  const { status } = await Location.requestForegroundPermissionsAsync();
                  if (status !== 'granted') return;
                  const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
                  const coords = { latitude: loc.coords.latitude, longitude: loc.coords.longitude };
                  const [result] = await Location.reverseGeocodeAsync(coords);
                  const addr = result
                    ? `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim() || 'Current location'
                    : 'Current location';
                  setPickerLocation({ ...coords, address: addr });
                  setPickerMapRegion({
                    latitude: coords.latitude,
                    longitude: coords.longitude,
                    latitudeDelta: 0.0012,
                    longitudeDelta: 0.0012,
                  });
                } finally {
                  setPickerLoading(false);
                }
              }}
              activeOpacity={0.85}
            >
              <Ionicons name="locate" size={16} color={primaryColor} />
              <Text style={styles.useCurrentText}>Use current location</Text>
            </TouchableOpacity>
            <ScrollView
              style={styles.searchResultsList}
              contentContainerStyle={styles.searchResultsListContent}
              keyboardShouldPersistTaps="handled"
              nestedScrollEnabled
            >
              {searchResults.map((s) => (
                <TouchableOpacity
                  key={s.id}
                  style={[styles.searchResultItem, { borderColor: `${primaryColor}22` }]}
                  onPress={async () => {
                    await hapticFeedback('light');
                    const nextLocation = {
                      latitude: s.latitude,
                      longitude: s.longitude,
                      address: s.description,
                    };
                    setPickerLocation(nextLocation);
                    setPickerMapRegion({
                      latitude: nextLocation.latitude,
                      longitude: nextLocation.longitude,
                      latitudeDelta: 0.0012,
                      longitudeDelta: 0.0012,
                    });
                    setLocationSearch(s.description);
                    setSearchResults([]);
                  }}
                  activeOpacity={0.8}
                  disabled={searchGeocodeLoading}
                >
                  <Ionicons name="location-outline" size={16} color={primaryColor} />
                  <Text style={styles.searchResultText} numberOfLines={2}>
                    {s.description}
                  </Text>
                  <Ionicons name="chevron-forward" size={14} color="rgba(148,163,184,0.65)" />
                </TouchableOpacity>
              ))}
            </ScrollView>
            {!searchGeocodeLoading &&
              locationSearch.trim().length >= 2 &&
              searchResults.length === 0 && (
                <Text style={styles.searchEmptyText}>
                  Tap → to search. Multiple matches appear here so you can pick the right one.
                </Text>
              )}
            <View style={styles.pickerMiniMapWrap}>
              <MapView
                style={styles.pickerMiniMap}
                region={pickerMapRegion ?? {
                  latitude: pickerLocation?.latitude ?? userLocation?.latitude ?? DEFAULT_MAP_REGION.latitude,
                  longitude: pickerLocation?.longitude ?? userLocation?.longitude ?? DEFAULT_MAP_REGION.longitude,
                  latitudeDelta: 0.0012,
                  longitudeDelta: 0.0012,
                }}
                onRegionChangeComplete={(r) => setPickerMapRegion(r)}
                onPress={(e) => {
                  const c = e.nativeEvent.coordinate;
                  setPickerMapRegion({
                    latitude: c.latitude,
                    longitude: c.longitude,
                    latitudeDelta: pickerMapRegion?.latitudeDelta ?? 0.0012,
                    longitudeDelta: pickerMapRegion?.longitudeDelta ?? 0.0012,
                  });
                  if (pickerMapGeocodeDebounceRef.current) clearTimeout(pickerMapGeocodeDebounceRef.current);
                  pickerMapGeocodeDebounceRef.current = setTimeout(() => {
                    void resolvePickerMapAddress(c);
                  }, 220);
                }}
                scrollEnabled
                zoomEnabled
                rotateEnabled={false}
                pitchEnabled={false}
                toolbarEnabled={false}
                customMapStyle={LOCATION_PICKER_MAP_STYLE}
                userInterfaceStyle={MAP_LOCKED_DARK}
              >
                {pickerLocation && (
                  <Marker coordinate={{ latitude: pickerLocation.latitude, longitude: pickerLocation.longitude }}>
                    <Animated.View style={{ transform: [{ scale: markerPulse }] }}>
                      <MapMarkerCustomerVehicle size={40} variant="car" />
                    </Animated.View>
                  </Marker>
                )}
              </MapView>
            </View>
            <Text style={styles.pickerMiniMapHint}>Pinch to zoom and tap map for exact pickup point</Text>
            <Text style={styles.pickupLocationMicrocopyStandalone}>This is where your car will be cleaned</Text>
            <WWPrimaryButton
              title="Confirm pickup location"
              onPress={() => {
                if (!pickerLocation) return;
                setChangeLocationVisible(false);
                setLocationPickerVisible(true);
              }}
              disabled={!pickerLocation}
              leftIconName="checkmark"
              leftIconSize={18}
              style={{ marginTop: 6, marginBottom: 10 }}
            />
            </Pressable>
          </Pressable>
        </KeyboardAvoidingView>
      </Modal>

      <Modal
        visible={showNearbyMapSheet}
        transparent
        animationType="slide"
        onRequestClose={() => setShowNearbyMapSheet(false)}
        statusBarTranslucent
      >
        <View style={styles.nearbyMapBackdrop}>
          <Pressable
            style={StyleSheet.absoluteFill}
            onPress={() => setShowNearbyMapSheet(false)}
            accessibilityRole="button"
            accessibilityLabel="Dismiss nearby map"
          />
          <View
            style={[
              styles.nearbyMapSheet,
              {
                height: Math.min(SCREEN_H * 0.72, SCREEN_H - insets.top - 12),
                paddingBottom: Math.max(insets.bottom, 10),
              },
            ]}
          >
            <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} />
            <LinearGradient colors={HEADER_STYLE_CARD_GRADIENT} style={StyleSheet.absoluteFill} />
            <LinearGradient
              colors={['rgba(255,255,255,0.14)', 'rgba(255,255,255,0.03)', 'transparent']}
              locations={[0, 0.28, 0.58]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0.42 }}
              style={StyleSheet.absoluteFill}
              pointerEvents="none"
            />
            <BookingSheetPremiumLayers />
            <View style={styles.nearbyMapSheetBody}>
              <View style={styles.nearbyMapHandle} />
              <View style={styles.nearbyMapHeader}>
                <View style={styles.nearbyMapTitleBlock}>
                  <Text style={styles.nearbyMapTitle}>Locations nearby</Text>
                  <Text style={styles.nearbyMapSubtitle}>
                    {sheetProviders.length
                      ? 'Tap a pin or chip to focus the map'
                      : 'No locations to show yet'}
                  </Text>
                </View>
                <View style={styles.nearbyMapHeaderActions}>
                  <View style={styles.nearbyMapIconBtn}>
                    <BookingHeaderMapControlButton
                      onPress={() => void handleNearbyMapRecenter()}
                      accentColor={primaryColor}
                      accessibilityLabel="Recenter map"
                      size={42}
                      iconSize={22}
                    />
                  </View>
                  <View style={styles.nearbyMapIconBtn}>
                    <WWSheetCloseButton
                      size={40}
                      iconSize={20}
                      onPress={() => setShowNearbyMapSheet(false)}
                      accessibilityLabel="Close map"
                    />
                  </View>
                </View>
              </View>
              <View style={styles.nearbyMapMapFrame}>
                <MapView
                  ref={mapRef}
                  style={StyleSheet.absoluteFill}
                  initialRegion={
                    region ?? {
                      latitude: DEFAULT_MAP_REGION.latitude,
                      longitude: DEFAULT_MAP_REGION.longitude,
                      latitudeDelta: 0.08,
                      longitudeDelta: 0.08,
                    }
                  }
                  customMapStyle={BOOKING_MAP_STYLE}
                  userInterfaceStyle={MAP_LOCKED_DARK}
                  showsUserLocation={!!userLocation}
                  showsMyLocationButton={false}
                  showsCompass={false}
                  mapType="standard"
                  scrollEnabled
                  zoomEnabled
                  rotateEnabled
                  pitchEnabled
                  mapPadding={{ top: 10, right: 10, bottom: 12, left: 10 }}
                  legalLabelInsets={{ top: 0, right: 8, bottom: 8, left: 8 }}
                >
                  {sheetProviders.map((p) => {
                    const isDetailHub = p.detailing_offered === true;
                    return (
                      <Marker
                        key={p.id}
                        coordinate={{ latitude: p.latitude, longitude: p.longitude }}
                        title={p.name}
                        onPress={() => handleNearbyProviderChip(p)}
                      >
                        {isDetailHub ? (
                          <MapMarkerDetailingHub size={44} isSelected={nearbyMapFocusId === p.id} />
                        ) : (
                          <MapMarkerWashHub size={44} isSelected={nearbyMapFocusId === p.id} />
                        )}
                      </Marker>
                    );
                  })}
                </MapView>
              </View>
              {sheetProviders.length > 0 ? (
                <ScrollView
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  style={styles.nearbyMapChipsScroll}
                  contentContainerStyle={styles.nearbyMapChipsContent}
                >
                  {sheetProviders.map((p) => {
                    const active = nearbyMapFocusId === p.id;
                    const isDetailHub = p.detailing_offered === true;
                    const hubAccent = isDetailHub ? DETAILING_YELLOW : SKY;
                    return (
                      <TouchableOpacity
                        key={`chip-${p.id}`}
                        style={[
                          styles.nearbyMapChip,
                          active &&
                            (isDetailHub ? styles.nearbyMapChipActiveDetail : styles.nearbyMapChipActive),
                        ]}
                        onPress={() => handleNearbyProviderChip(p)}
                        activeOpacity={0.88}
                        accessibilityRole="button"
                        accessibilityLabel={p.name}
                      >
                        <Ionicons
                          name={isDetailHub ? 'sparkles' : 'location'}
                          size={14}
                          color={active ? '#0f172a' : hubAccent}
                        />
                        <Text style={[styles.nearbyMapChipLabel, active && styles.nearbyMapChipLabelActive]} numberOfLines={1}>
                          {p.name}
                        </Text>
                      </TouchableOpacity>
                    );
                  })}
                </ScrollView>
              ) : null}
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  nearbyMapBackdrop: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(2,6,23,0.58)',
  },
  nearbyMapSheet: {
    width: '100%',
    position: 'relative',
    ...PREMIUM_BOOKING_MAP_SHEET_GLASS,
  },
  nearbyMapSheetBody: {
    flex: 1,
    zIndex: 2,
    paddingHorizontal: 4,
  },
  nearbyMapHandle: {
    alignSelf: 'center',
    width: 38,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(135,206,235,0.65)',
    marginTop: 10,
    marginBottom: 8,
  },
  nearbyMapHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    paddingHorizontal: 14,
    paddingBottom: 6,
  },
  nearbyMapTitleBlock: {
    flex: 1,
    marginRight: 8,
    gap: 4,
  },
  nearbyMapTitle: {
    color: '#F8FAFC',
    fontSize: 18,
    fontWeight: '900',
    letterSpacing: 0.2,
  },
  nearbyMapSubtitle: {
    color: 'rgba(248,250,252,0.62)',
    fontSize: 12,
    fontWeight: '600',
    letterSpacing: 0.15,
  },
  nearbyMapHeaderActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  nearbyMapIconBtn: {
    width: 42,
    height: 42,
    alignItems: 'center',
    justifyContent: 'center',
  },
  nearbyMapCloseCircle: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  nearbyMapMapFrame: {
    flex: 1,
    minHeight: 220,
    marginHorizontal: 10,
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  nearbyMapChipActiveDetail: {
    backgroundColor: 'rgba(234,179,8,0.32)',
    borderColor: 'rgba(234,179,8,0.88)',
  },
  nearbyMapChipsScroll: {
    flexGrow: 0,
    maxHeight: 56,
    marginTop: 4,
  },
  nearbyMapChipsContent: {
    paddingHorizontal: 12,
    paddingVertical: 10,
    gap: 8,
    alignItems: 'center',
  },
  nearbyMapChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    maxWidth: 200,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 999,
    backgroundColor: 'rgba(2,6,23,0.45)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.35)',
  },
  nearbyMapChipActive: {
    backgroundColor: 'rgba(135,206,235,0.35)',
    borderColor: 'rgba(135,206,235,0.85)',
  },
  nearbyMapChipLabel: {
    flexShrink: 1,
    color: 'rgba(248,250,252,0.92)',
    fontSize: 13,
    fontWeight: '700',
  },
  nearbyMapChipLabelActive: {
    color: '#0f172a',
  },
  providerMarkerWrap: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.12)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  providerMarker: { width: 34, height: 34 },
  sheetContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    zIndex: 40,
  },
  sheetPanel: {
    minHeight: 332,
    padding: 14,
    paddingBottom: 14,
    ...PREMIUM_BOOKING_MAP_SHEET_GLASS,
  },
  sheetSheen: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.9,
  },
  handle: {
    alignSelf: 'center',
    width: 38,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(135,206,235,0.65)',
    marginBottom: 20,
  },
  optionsScroll: {
    flexGrow: 0,
    width: '100%',
  },
  optionsScrollContent: {
    marginTop: 28,
    paddingLeft: 0,
    paddingRight: 18,
    gap: 12,
    alignItems: 'stretch',
  },
  indexOptionCardOuter: {
    alignSelf: 'stretch',
  },
  indexSheetCtaRow: {
    marginTop: 18,
    paddingTop: 4,
    paddingBottom: 2,
    alignItems: 'flex-start',
  },
  indexBookingSheetTrackingCta: {
    flex: 0,
    alignSelf: 'stretch',
    width: '100%',
    minHeight: 50,
    paddingVertical: 11,
    paddingHorizontal: 14,
    borderRadius: 24,
    gap: 8,
  },
  indexBookingSheetCtaLabel: {
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 0.15,
    includeFontPadding: false,
  },
  infoSheetContinueCta: {
    marginTop: 10,
  },
  compactToggleWrap: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 2,
    marginBottom: 6,
    borderRadius: 24,
    padding: 6,
    backgroundColor: 'rgba(2,6,23,0.35)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
  },
  compactModePill: {
    flex: 1,
    height: 40,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
    backgroundColor: 'rgba(255,255,255,0.04)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 7,
  },
  compactModePillActive: {
    backgroundColor: 'rgba(56,189,248,0.26)',
    borderColor: 'rgba(56,189,248,0.82)',
  },
  compactModePillActiveDetail: {
    backgroundColor: 'rgba(234,179,8,0.26)',
    borderColor: 'rgba(234,179,8,0.84)',
  },
  compactModeIconWrap: {
    width: 22,
    height: 22,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    backgroundColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  compactModeIconWrapActive: {
    borderColor: 'rgba(56,189,248,0.95)',
    backgroundColor: 'rgba(56,189,248,0.45)',
  },
  compactModeIconWrapActiveDetail: {
    borderColor: 'rgba(234,179,8,0.95)',
    backgroundColor: 'rgba(234,179,8,0.45)',
  },
  compactModeText: {
    color: 'rgba(255,255,255,0.82)',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.3,
    textTransform: 'uppercase',
  },
  compactModeTextActive: {
    color: '#FFFFFF',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(2,6,23,0.45)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  modalCard: {
    width: '100%',
    maxWidth: 360,
    maxHeight: '78%',
    borderRadius: 24,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.25)',
  },
  modalInner: { padding: 18, paddingBottom: 14, maxHeight: 520 },
  modalScroll: { maxHeight: 400 },
  modalScrollContent: { paddingBottom: 20 },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 6,
  },
  modalTitle: { fontSize: 20, fontWeight: '800', marginBottom: 6 },
  infoSheetScrollContent: { paddingBottom: 28 },
  modalSub: { color: '#94A3B8', fontSize: 13, marginBottom: 12, fontWeight: '600' },
  modalSectionLabel: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  modalDesc: { color: '#E2E8F0', fontSize: 14, lineHeight: 21, marginBottom: 16 },
  modalDetailCard: {
    borderRadius: 16,
    borderWidth: 1,
    backgroundColor: 'rgba(255,255,255,0.04)',
    padding: 14,
    marginBottom: 14,
  },
  modalDetailRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 12 },
  modalDetailTextCol: { flex: 1, minWidth: 0 },
  modalDetailLabel: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 11,
    fontWeight: '700',
    marginBottom: 4,
    textTransform: 'uppercase',
    letterSpacing: 0.4,
  },
  modalDetailValue: { color: '#F1F5F9', fontSize: 14, fontWeight: '700', lineHeight: 20 },
  modalDetailDivider: {
    height: StyleSheet.hairlineWidth,
    backgroundColor: 'rgba(148,163,184,0.25)',
    marginVertical: 12,
  },
  locationPickerSheet: {
    width: '100%',
    maxWidth: undefined,
    maxHeight: '82%',
    minHeight: 430,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.3)',
    overflow: 'hidden',
    padding: 14,
    paddingBottom: 20,
    alignSelf: 'stretch',
    marginTop: 0,
  },
  locationPickerOverlay: {
    flex: 1,
    backgroundColor: 'rgba(2,6,23,0.45)',
    justifyContent: 'flex-end',
    alignItems: 'stretch',
  },
  locationPickerKeyboardWrap: {
    flex: 1,
  },
  locationPickerTitle: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 6,
  },
  locationPickerSearchMicrocopy: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 12,
    fontWeight: '600',
    lineHeight: 16,
    marginBottom: 10,
  },
  pickerMiniMapWrap: {
    borderRadius: 14,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.16)',
    marginBottom: 10,
  },
  pickerMiniMap: {
    width: '100%',
    height: 150,
  },
  pickerMiniMapMarker: {
    width: 26,
    height: 26,
  },
  pickerMiniMapHint: {
    marginTop: -2,
    marginBottom: 10,
    color: 'rgba(226,232,240,0.86)',
    fontSize: 12,
    fontWeight: '600',
  },
  locationPickerLoading: {
    paddingVertical: 16,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  locationPickerLoadingText: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 13,
    fontWeight: '600',
  },
  locationPreviewCard: {
    flexDirection: 'column',
    gap: 8,
    alignItems: 'stretch',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.25)',
    backgroundColor: 'rgba(15,23,42,0.5)',
    padding: 12,
    marginBottom: 10,
  },
  locationPreviewCardRow: {
    flexDirection: 'row',
    gap: 8,
    alignItems: 'center',
  },
  pickupLocationMicrocopy: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 12,
    fontWeight: '600',
    lineHeight: 16,
    paddingLeft: 26,
  },
  pickupLocationMicrocopyStandalone: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 12,
    fontWeight: '600',
    lineHeight: 16,
    marginBottom: 8,
    textAlign: 'center',
  },
  locationPreviewText: {
    color: '#E2E8F0',
    fontSize: 13,
    fontWeight: '600',
    flex: 1,
  },
  locationPickerSecondaryBtn: {
    borderRadius: 18,
    minHeight: 46,
    paddingVertical: 12,
    paddingHorizontal: 18,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 10,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.35)',
    backgroundColor: 'rgba(255,255,255,0.04)',
  },
  locationPickerSecondaryText: {
    color: '#E2E8F0',
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  searchInputWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    minHeight: 56,
    borderWidth: 1.5,
    backgroundColor: 'rgba(15,23,42,0.72)',
    borderRadius: 16,
    paddingHorizontal: 14,
    paddingVertical: 8,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.12,
    shadowRadius: 6,
    elevation: 3,
  },
  searchInlineSpinner: {
    marginRight: 4,
  },
  searchInput: {
    flex: 1,
    color: '#F1F5F9',
    fontSize: 16,
    fontWeight: '600',
    paddingVertical: 4,
    minHeight: 40,
  },
  searchActionBtn: {
    width: 44,
    height: 44,
    borderRadius: 14,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  useCurrentBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 4,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.22)',
    backgroundColor: 'rgba(255,255,255,0.05)',
    minHeight: 40,
    paddingVertical: 8,
    paddingHorizontal: 10,
    marginBottom: 10,
    alignSelf: 'flex-start',
  },
  useCurrentText: {
    color: '#E2E8F0',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  searchResultsList: {
    maxHeight: 176,
    marginBottom: 6,
  },
  searchResultsListContent: {
    paddingBottom: 4,
    flexGrow: 0,
  },
  searchResultItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 12,
    paddingHorizontal: 12,
    borderRadius: 12,
    borderWidth: 1,
    backgroundColor: 'rgba(255,255,255,0.05)',
    marginBottom: 8,
  },
  searchResultText: {
    color: '#E2E8F0',
    fontSize: 13,
    flex: 1,
  },
  searchEmptyText: {
    color: 'rgba(148,163,184,0.9)',
    fontSize: 12,
    fontWeight: '600',
    lineHeight: 16,
    marginBottom: 8,
  },
});
