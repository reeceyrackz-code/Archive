import React, { useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, Alert, StatusBar } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { Video, ResizeMode } from 'expo-av';
import { useAuth } from '../../../../src/providers/enhanced-auth-context';
import { serviceOptions } from '../../../../src/constants/serviceOptions';
import { colors } from '../../../../src/constants/colors';
import {
  ActiveBookingBlockedError,
  createHubPendingPaymentBooking,
  fetchCarWashHub,
  resolveHubServiceForBookingInsert,
} from '../../../../src/utils/hubPendingPaymentBooking';
import { BOOKING_FLOW_VIDEO } from '../../../assets/assetExports';

const SKY = colors.SKY;

/**
 * Legacy route: immediately creates a pending-payment booking and sends the user to payment.
 * (Interactive confirm UI was removed from the hub wash flow.)
 */
export default function PhysicalConfirm() {
  const { user } = useAuth();
  const params = useLocalSearchParams<{
    locationId?: string;
    serviceId?: string;
    vehicleId?: string;
    washType?: string;
    scheduledAt?: string;
    price?: string;
  }>();

  const didSubmitRef = useRef(false);
  const [hint, setHint] = useState('Preparing payment…');

  useEffect(() => {
    if (didSubmitRef.current) return;
    const { locationId, serviceId, vehicleId, washType, scheduledAt, price: priceParam } = params;

    if (!user?.id) {
      setHint('Sign in required');
      Alert.alert('Sign in required', 'Please sign in to complete your booking.', [
        { text: 'OK', onPress: () => router.back() },
      ]);
      return;
    }
    if (!locationId || !serviceId || !vehicleId || !scheduledAt) {
      setHint('Invalid link');
      Alert.alert('Missing information', 'This booking link is incomplete.', [
        { text: 'OK', onPress: () => router.back() },
      ]);
      return;
    }

    didSubmitRef.current = true;

    void (async () => {
      try {
        const hub = await fetchCarWashHub(locationId);
        const service = await resolveHubServiceForBookingInsert(serviceId, serviceOptions);
        if (!hub || !service) {
          didSubmitRef.current = false;
          Alert.alert('Error', 'Could not load booking details.', [{ text: 'OK', onPress: () => router.back() }]);
          return;
        }
        const displayPrice =
          priceParam != null && !Number.isNaN(Number(priceParam))
            ? Number(priceParam)
            : Number(serviceOptions.find((o) => o.id === service.id)?.price ?? 0);

        const bookingId = await createHubPendingPaymentBooking({
          userId: user.id,
          vehicleId,
          hub,
          service,
          price: displayPrice,
          washType: washType || null,
          scheduledAt,
        });

        router.replace({
          pathname: '/owner/booking/payment',
          params: { bookingId },
        });
      } catch (err: unknown) {
        didSubmitRef.current = false;
        if (err instanceof ActiveBookingBlockedError) {
          Alert.alert(
            'One booking at a time',
            'You already have an active booking. Please complete or cancel it before starting a new one.',
            [
              { text: 'OK', style: 'cancel' },
              {
                text: 'View my booking',
                onPress: () =>
                  router.push({ pathname: '/owner/booking/tracking', params: { bookingId: err.activeBookingId } } as any),
              },
            ]
          );
        } else {
          console.error('[physical-confirm-auto] error', err);
          const message =
            err && typeof err === 'object' && 'message' in err ? String((err as { message: string }).message) : 'Unable to create booking';
          Alert.alert('Error', message, [{ text: 'OK', onPress: () => router.back() }]);
        }
      }
    })();
  }, [user?.id, params.locationId, params.serviceId, params.vehicleId, params.scheduledAt, params.price, params.washType]);

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <StatusBar hidden />
      <Video
        source={BOOKING_FLOW_VIDEO}
        style={StyleSheet.absoluteFill}
        shouldPlay
        isLooping
        isMuted
        resizeMode={ResizeMode.COVER}
      />
      <View style={styles.center}>
        <ActivityIndicator size="large" color={SKY} />
        <Text style={styles.hint}>{hint}</Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#020617' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 14 },
  hint: { color: SKY, fontSize: 15, fontWeight: '600' },
});
