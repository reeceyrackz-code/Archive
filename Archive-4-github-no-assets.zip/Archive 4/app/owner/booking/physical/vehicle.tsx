import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Video, ResizeMode } from 'expo-av';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../../src/lib/supabase';
import useLiveLocation from '../../../../src/hooks/useLiveLocation';
import PhysicalBookingHubMapLayer from '../../../../src/components/booking/PhysicalBookingHubMapLayer';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import AppHeader from '../../../../src/components/shared/AppHeader';
import { colors } from '../../../../src/constants/colors';
import {
  HEADER_STYLE_CARD_GRADIENT,
  PREMIUM_BOOKING_MAP_SHEET_GLASS,
  getCustomerBookingSheetScreenBottom,
  getIndexTrackingCardSnapInterval,
  getIndexTrackingCardWidth,
} from '../../../../src/constants/bookingCardTheme';
import IndexTrackingCardShell, { indexTrackingCardStyles as ix } from '../../../../src/components/booking/IndexTrackingCardShell';
import { customerMapTrackingSheetActionStyles } from '../../../../src/components/booking/CustomerMapTrackingSheetShell';
import { VehicleInfoOverlay } from '../../../../src/components/booking/VehicleInfoOverlay';
import { fetchVehicleStats } from '../../../../src/utils/vehicleStats';
import { HEADER_BORDER_RADIUS } from '../../../../src/constants/layoutConstants';
import { BOOKING_VEHICLE_BACKGROUND_VIDEO } from '../../../assets/assetExports';
import BookingSheetPremiumLayers from '../../../../src/components/booking/BookingSheetPremiumLayers';

const { width } = Dimensions.get('window');
const SKY = colors.SKY;

type VehicleSize = 'small' | 'medium' | 'large' | 'xl' | 'xxl';

type Vehicle = {
  id: string;
  type?: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  is_default: boolean;
  image_url?: string | null;
  created_at?: string | null;
  photo?: string | null;
  size?: VehicleSize | string | null;
};

function formatVehicleSize(size: VehicleSize | string | null | undefined): string {
  if (!size) return '';
  const s = String(size).toLowerCase();
  if (s === 'small') return 'S';
  if (s === 'medium') return 'M';
  if (s === 'large') return 'L';
  if (s === 'xl') return 'XL';
  if (s === 'xxl') return 'XXL';
  return s.charAt(0).toUpperCase() + s.slice(1);
}

export default function PhysicalVehicleSelection() {
  const insets = useSafeAreaInsets();
  const sheetBottom = getCustomerBookingSheetScreenBottom();
  const cardWidth = getIndexTrackingCardWidth(width);
  const snapInterval = getIndexTrackingCardSnapInterval(width);
  const { user } = useAuth();
  const { coords } = useLiveLocation();
  const params = useLocalSearchParams<{ locationId?: string; scheduledAt?: string; serviceId?: string }>();
  const locationId = params.locationId;
  const scheduledAt = params.scheduledAt;
  const serviceId = params.serviceId;

  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedVehicle, setSelectedVehicle] = useState<string | null>(null);
  const [infoModalVehicle, setInfoModalVehicle] = useState<Vehicle | null>(null);
  const [vehicleStats, setVehicleStats] = useState<{ washCount: number; lastCleanedAt: string | null; cleanRating: number | null }>({ washCount: 0, lastCleanedAt: null, cleanRating: null });
  const [hubGeo, setHubGeo] = useState<{ lat: number; lng: number } | null>(null);

  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 500, useNativeDriver: true }).start();
    loadVehicles();
  }, [user?.id]);

  useEffect(() => {
    if (!locationId) {
      setHubGeo(null);
      return;
    }
    let alive = true;
    (async () => {
      const { data } = await supabase.from('car_wash_locations').select('latitude,longitude').eq('id', locationId).maybeSingle();
      if (!alive || !data) return;
      const lat = Number((data as { latitude?: unknown }).latitude);
      const lng = Number((data as { longitude?: unknown }).longitude);
      if (Number.isFinite(lat) && Number.isFinite(lng)) setHubGeo({ lat, lng });
      else setHubGeo(null);
    })();
    return () => {
      alive = false;
    };
  }, [locationId]);

  const loadVehicles = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('*')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false });

      if (error) throw error;

      const rows = (data || []).map((r: any) => ({
        ...r,
        image_url: r.image_url ?? r.photo ?? null,
        created_at: r.created_at ?? null,
      }));
      setVehicles(rows);
      setSelectedVehicle((prev) => {
        if (rows.length === 0) return null;
        if (prev && rows.some((v) => v.id === prev)) return prev;
        const def = rows.find((v: Vehicle) => v.is_default) || rows[0];
        return def.id;
      });
    } catch (e) {
      console.error('Failed to load vehicles', e);
    } finally {
      setLoading(false);
    }
  };

  const openVehicleInfo = async (vehicle: Vehicle) => {
    hapticFeedback('light');
    setInfoModalVehicle(vehicle);
    setVehicleStats({ washCount: 0, lastCleanedAt: null, cleanRating: null });
    try {
      const stats = await fetchVehicleStats(vehicle.id);
      setVehicleStats({ washCount: stats.washCount, lastCleanedAt: stats.lastCleanedAt, cleanRating: stats.cleanRating });
    } catch {
      setVehicleStats({ washCount: 0, lastCleanedAt: null, cleanRating: null });
    }
  };

  const handleSelectAndContinue = async (vehicleId: string) => {
    await hapticFeedback('light');
    await hapticFeedback('medium');
    if (locationId) {
      router.push({
        pathname: '/owner/booking/physical/service',
        params: {
          locationId,
          vehicleId,
          ...(serviceId ? { serviceId } : {}),
          ...(scheduledAt && { scheduledAt }),
        },
      });
    } else {
      router.push({
        pathname: '/owner/booking/physical/location',
        params: { vehicleId },
      });
    }
  };

  const handleVehicleSelect = async (vehicleId: string) => {
    await hapticFeedback('light');
    setSelectedVehicle(vehicleId);
  };

  const selectedVehicleData = vehicles.find((v) => v.id === selectedVehicle) ?? null;

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      {hubGeo ? (
        <PhysicalBookingHubMapLayer
          hubLatitude={hubGeo.lat}
          hubLongitude={hubGeo.lng}
          userLatitude={coords?.latitude}
          userLongitude={coords?.longitude}
          mapPaddingBottom={sheetBottom + 52}
        />
      ) : (
        <Video
          source={BOOKING_VEHICLE_BACKGROUND_VIDEO}
          style={StyleSheet.absoluteFill}
          shouldPlay
          isLooping
          isMuted
          resizeMode={ResizeMode.COVER}
        />
      )}

      <AppHeader
        title="Choose your vehicle"
        subtitle="Swipe to compare your vehicles"
        showBack
        onBack={() => router.back()}
        rightAction={
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              router.replace('/owner/owner-dashboard' as any);
            }}
            style={styles.exitButton}
            activeOpacity={0.7}
          >
            <Ionicons name="close" size={22} color="#FFFFFF" />
          </TouchableOpacity>
        }
      />

      <Animated.View
        style={[
          styles.cardsContainer,
          {
            opacity: fadeAnim,
            bottom: sheetBottom,
          },
        ]}
      >
        <View style={[styles.vehicleBottomSheet, { paddingBottom: Math.max(insets.bottom, 8) }]}>
          <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} />
          <LinearGradient colors={HEADER_STYLE_CARD_GRADIENT} style={StyleSheet.absoluteFill} />
          <LinearGradient
            colors={['rgba(255,255,255,0.16)', 'rgba(255,255,255,0.02)', 'transparent']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.locationSheetSheen}
          />
          <BookingSheetPremiumLayers />
          <View style={styles.locationSheetHandle} />
          {selectedVehicleData ? (
            <View style={styles.vehicleSelectedBannerWrap}>
              <View style={styles.vehicleSelectedBanner}>
                <Ionicons name="checkmark-circle" size={14} color={SKY} />
                <Text style={styles.vehicleSelectedBannerText} numberOfLines={1}>
                  Selected: {selectedVehicleData.make} {selectedVehicleData.model}
                </Text>
              </View>
            </View>
          ) : null}
          {loading ? (
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              style={styles.bookingStepHorizontalScroll}
              contentContainerStyle={styles.bookingIndexOptionsScrollVehicle}
              scrollEnabled={false}
            >
              <View style={[ix.cardWrap, { width: cardWidth }]}>
                <IndexTrackingCardShell accentColor={SKY}>
                  <View style={styles.loadingContainer}>
                    <ActivityIndicator size="large" color={SKY} />
                    <Text style={styles.loadingText}>Loading vehicles…</Text>
                  </View>
                </IndexTrackingCardShell>
              </View>
            </ScrollView>
          ) : vehicles.length === 0 ? (
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              style={styles.bookingStepHorizontalScroll}
              contentContainerStyle={styles.bookingIndexOptionsScrollVehicle}
              scrollEnabled={false}
            >
              <View style={[ix.cardWrap, { width: cardWidth }]}>
                <IndexTrackingCardShell accentColor={SKY}>
                  <View style={styles.emptyContent}>
                    <View style={[styles.iconWrap, { backgroundColor: SKY + '20', borderColor: SKY + '40' }]}>
                      <Ionicons name="car-outline" size={28} color={SKY} />
                    </View>
                    <Text style={styles.emptyText}>No vehicles found</Text>
                    <Text style={styles.emptySubtext}>Add a vehicle to continue</Text>
                    <TouchableOpacity onPress={() => router.push('/owner/settings/vehicle-management')} style={styles.addButton} activeOpacity={0.85}>
                      <LinearGradient colors={[SKY, '#60A5FA']} style={styles.addButtonGradient}>
                        <Ionicons name="add-circle" size={20} color="#FFFFFF" />
                        <Text style={styles.addButtonText}>Add Vehicle</Text>
                      </LinearGradient>
                    </TouchableOpacity>
                  </View>
                </IndexTrackingCardShell>
              </View>
            </ScrollView>
          ) : (
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              style={styles.bookingStepHorizontalScroll}
              contentContainerStyle={styles.bookingIndexOptionsScrollVehicle}
              snapToInterval={snapInterval}
              decelerationRate="fast"
              snapToAlignment="start"
            >
              {vehicles.map((vehicle) => {
                const isVehicleSelected = selectedVehicle === vehicle.id;
                return (
                  <TouchableOpacity
                    key={vehicle.id}
                    activeOpacity={0.92}
                    onPress={() => void handleVehicleSelect(vehicle.id)}
                    style={[ix.cardWrap, { width: cardWidth }]}
                  >
                    <IndexTrackingCardShell
                      accentColor={SKY}
                      style={isVehicleSelected ? { borderColor: SKY + '90', borderWidth: 2 } : undefined}
                    >
                      <View style={ix.optionCardTopRow}>
                        <View style={[ix.optionIconBadge, { borderColor: SKY + '55', backgroundColor: SKY + '35' }]}>
                          <Ionicons name="car-sport" size={22} color={SKY} />
                        </View>
                        <View style={ix.optionTitleMain}>
                          <Text style={ix.optionKicker}>YOUR VEHICLE</Text>
                          <Text style={ix.optionTitle} numberOfLines={1}>
                            {vehicle.make} {vehicle.model}
                          </Text>
                          <Text style={ix.optionSubtitle} numberOfLines={2}>
                            {vehicle.color}
                            {vehicle.registration ? ` · ${vehicle.registration}` : ''}
                            {vehicle.is_default ? ' · Default' : ''}
                            {vehicle.size ? ` · ${formatVehicleSize(vehicle.size)}` : ''}
                          </Text>
                          <Text style={styles.vehiclePricingHint} numberOfLines={2}>
                            Used to calculate pricing & time
                          </Text>
                        </View>
                        <TouchableOpacity
                          style={[ix.optionInfoBtn, { borderColor: SKY + '40', backgroundColor: SKY + '15' }]}
                          onPress={() => { hapticFeedback('light'); void openVehicleInfo(vehicle); }}
                          activeOpacity={0.85}
                          accessibilityLabel="Vehicle information"
                          accessibilityRole="button"
                        >
                          <Ionicons name="information-circle-outline" size={22} color={SKY} />
                        </TouchableOpacity>
                      </View>
                      {vehicles.length > 1 ? (
                        <View style={ix.optionFooterRow}>
                          <View style={ix.optionFooterLeft}>
                            <View style={[ix.optionStatusPill, { backgroundColor: 'rgba(148,163,184,0.12)' }]}>
                              <View style={[ix.optionStatusDot, { backgroundColor: '#94A3B8' }]} />
                              <Text style={[ix.optionStatusText, { color: '#94A3B8' }]}>Swipe to compare</Text>
                            </View>
                          </View>
                        </View>
                      ) : null}
                    </IndexTrackingCardShell>
                  </TouchableOpacity>
                );
              })}
            </ScrollView>
          )}
          {!loading && vehicles.length > 0 ? (
            <View style={[styles.sheetPrimaryCtaRow, styles.sheetPrimaryCtaRowVehicleStep]}>
              <View style={{ width: cardWidth }}>
                <TouchableOpacity
                  style={[
                    customerMapTrackingSheetActionStyles.bookingInfoActionCard,
                    customerMapTrackingSheetActionStyles.bookingInfoCard,
                    styles.bookingSheetTrackingCta,
                    { borderColor: SKY + '8A', opacity: selectedVehicle ? 1 : 0.45 },
                  ]}
                  onPress={() => {
                    if (!selectedVehicle) return;
                    void handleSelectAndContinue(selectedVehicle);
                  }}
                  disabled={!selectedVehicle}
                  activeOpacity={0.85}
                >
                  <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
                  <LinearGradient
                    colors={[SKY + '59', 'rgba(15,23,42,0.65)']}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 0, y: 1 }}
                    style={StyleSheet.absoluteFill}
                    pointerEvents="none"
                  />
                  <Ionicons name="arrow-forward-circle" size={18} color={SKY} style={{ zIndex: 1 }} />
                  <View style={customerMapTrackingSheetActionStyles.bookingInfoCardTextWrap}>
                    <Text style={[styles.bookingSheetCtaLabel, { color: SKY }]}>Continue</Text>
                  </View>
                </TouchableOpacity>
              </View>
            </View>
          ) : null}
        </View>
      </Animated.View>

      <VehicleInfoOverlay
        visible={!!infoModalVehicle}
        vehicle={infoModalVehicle ? { ...infoModalVehicle, mot_expiry: (infoModalVehicle as any).mot_expiry ?? null, mot_expiry_date: (infoModalVehicle as any).mot_expiry_date ?? null, mileage: (infoModalVehicle as any).mileage ?? null, tax_status: (infoModalVehicle as any).tax_status ?? null, tax_due_date: (infoModalVehicle as any).tax_due_date ?? null, tax_expiry: (infoModalVehicle as any).tax_expiry ?? null } : null}
        stats={vehicleStats}
        accentColor={SKY}
        onClose={() => setInfoModalVehicle(null)}
      />

    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  vehicleBottomSheet: {
    width: '100%',
    paddingTop: 2,
    ...PREMIUM_BOOKING_MAP_SHEET_GLASS,
  },
  locationSheetSheen: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.9,
  },
  locationSheetHandle: {
    width: 42,
    height: 4,
    borderRadius: 2,
    alignSelf: 'center',
    marginTop: 10,
    marginBottom: 4,
    backgroundColor: 'rgba(255,255,255,0.55)',
  },
  bookingStepHorizontalScroll: {
    flexGrow: 0,
    flexShrink: 0,
  },
  bookingIndexOptionsScrollVehicle: {
    marginTop: 18,
    paddingLeft: 14,
    paddingRight: 12,
    gap: 10,
  },
  sheetPrimaryCtaRow: {
    paddingLeft: 14,
    paddingRight: 14,
    paddingTop: 0,
    marginTop: -10,
    paddingBottom: 2,
  },
  sheetPrimaryCtaRowVehicleStep: {
    marginTop: 10,
  },
  bookingSheetTrackingCta: {
    flex: 0,
    alignSelf: 'stretch',
    width: '100%',
    minHeight: 50,
    paddingVertical: 11,
    paddingHorizontal: 14,
    borderRadius: 24,
    gap: 8,
  },
  bookingSheetCtaLabel: {
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 0.15,
    includeFontPadding: false,
  },
  vehicleSelectedBannerWrap: {
    paddingHorizontal: 14,
    paddingTop: 2,
    paddingBottom: 10,
  },
  vehicleSelectedBanner: {
    marginTop: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(56,189,248,0.45)',
    backgroundColor: 'rgba(56,189,248,0.12)',
    alignSelf: 'flex-start',
  },
  vehicleSelectedBannerText: {
    color: SKY,
    fontSize: 11,
    fontWeight: '700',
  },
  exitButton: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
    elevation: 8,
  },
  cardsContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    width: '100%',
  },
  vehicleCardInner: {
    position: 'relative',
    padding: 20,
  },
  vehicleCardInfoIcon: {
    position: 'absolute',
    top: 14,
    right: 14,
    zIndex: 1,
  },
  vehicleCardCarIcon: {
    width: 52,
    height: 52,
    borderRadius: 18,
    marginRight: 14,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  iconWrap: {
    width: 52,
    height: 52,
    borderRadius: 18,
    marginRight: 14,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardContent: {
    flex: 1,
    minWidth: 0,
    paddingRight: 44,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  cardTitle: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
    flex: 1,
    marginBottom: 4,
  },
  cardColourRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 6,
    marginBottom: 6,
  },
  cardSubtitle: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '600',
  },
  vehiclePricingHint: {
    marginTop: 6,
    fontSize: 11,
    color: 'rgba(148,163,184,0.95)',
    fontWeight: '600',
    lineHeight: 15,
  },
  badgeSmall: {
    paddingHorizontal: 6,
    paddingVertical: 4,
    borderRadius: 10,
    borderWidth: 1,
  },
  cardMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 6,
  },
  quickHint: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 9,
    paddingVertical: 4,
    borderRadius: 10,
    borderWidth: 1,
  },
  quickHintText: {
    fontSize: 12,
    fontWeight: '600',
  },
  infoIconBtn: {
    padding: 6,
    borderRadius: 10,
  },
  ctaDivider: {
    height: 1,
    marginTop: 14,
    marginBottom: 12,
    borderRadius: 1,
  },
  ctaWrapper: {
    marginTop: 10,
    paddingHorizontal: 16,
    alignItems: 'center',
  },
  ctaButton: {
    borderRadius: HEADER_BORDER_RADIUS,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
  },
  ctaGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    paddingHorizontal: 20,
    gap: 10,
  },
  ctaText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '900',
  },
  emptyContent: {
    alignItems: 'center',
    paddingVertical: 24,
  },
  emptyText: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
    marginTop: 14,
    marginBottom: 4,
  },
  emptySubtext: {
    color: '#94A3B8',
    fontSize: 13,
    textAlign: 'center',
    marginBottom: 16,
  },
  loadingContainer: {
    paddingVertical: 40,
    paddingHorizontal: 20,
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: SKY,
    fontSize: 15,
    fontWeight: '700',
  },
  addButton: {
    borderRadius: 12,
    overflow: 'hidden',
    marginTop: 16,
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  addButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
    paddingVertical: 14,
    gap: 8,
  },
  addButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  // Vehicle info modal – same card opacity as other info popups
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  infoModalContentWrap: {
    width: '100%',
    maxWidth: 360,
    maxHeight: '88%',
    borderRadius: 24,
    overflow: 'hidden',
    borderWidth: 1.5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.35,
    shadowRadius: 24,
    elevation: 12,
  },
  infoModalCard: {
    flex: 1,
    overflow: 'hidden',
    backgroundColor: 'transparent',
  },
  infoModalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 18,
    paddingHorizontal: 20,
    paddingLeft: 24,
    borderBottomWidth: 1,
    position: 'relative',
  },
  infoModalAccent: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 4,
    borderTopLeftRadius: 2,
    borderBottomLeftRadius: 2,
  },
  infoModalTitle: {
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
    flex: 1,
  },
  infoModalCloseBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(148,163,184,0.18)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoModalScroll: {
    maxHeight: 400,
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 12,
  },
  infoModalCover: {
    height: 120,
    borderRadius: 14,
    overflow: 'hidden',
    marginBottom: 16,
    borderWidth: 1,
    borderColor: SKY + '30',
  },
  infoModalPhoto: {
    width: '100%',
    height: '100%',
  },
  infoModalPhotoPlaceholder: {
    flex: 1,
    width: '100%',
    height: '100%',
    backgroundColor: SKY + '18',
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoModalVehicleTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    textAlign: 'center',
    marginBottom: 16,
    letterSpacing: 0.2,
  },
  infoModalBody: {
    gap: 12,
    marginBottom: 18,
  },
  infoModalRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  infoModalText: {
    color: '#94A3B8',
    fontSize: 14,
    lineHeight: 20,
  },
  infoModalBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 10,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 12,
    backgroundColor: '#10B98122',
    borderWidth: 1,
    borderColor: '#10B98140',
    alignSelf: 'flex-start',
  },
  infoModalBadgeText: {
    color: '#10B981',
    fontSize: 13,
    fontWeight: '700',
  },
  infoModalDone: {
    marginHorizontal: 20,
    marginTop: 8,
    marginBottom: 20,
    paddingVertical: 16,
    borderRadius: 14,
    alignItems: 'center',
  },
  infoModalDoneText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '800',
  },
});
