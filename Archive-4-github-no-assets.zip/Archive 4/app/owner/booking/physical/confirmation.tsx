import React, { useEffect } from 'react';
import { ActivityIndicator, StyleSheet, View } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';

export default function PhysicalConfirmation() {
  const params = useLocalSearchParams<{ bookingId?: string }>();

  useEffect(() => {
    if (params.bookingId) {
      router.replace({ pathname: '/owner/booking/tracking', params: { bookingId: params.bookingId } } as any);
      return;
    }
    router.replace('/owner/owner-dashboard' as any);
  }, [params.bookingId]);

  return (
    <View style={styles.container}>
      <ActivityIndicator size="large" color="#87CEEB" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent',
  },
});
