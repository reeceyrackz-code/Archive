import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Video, ResizeMode } from 'expo-av';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import AppHeader from '../../../../src/components/shared/AppHeader';
import { colors } from '../../../../src/constants/colors';
import IndexTrackingCardShell, { indexTrackingCardStyles as ix } from '../../../../src/components/booking/IndexTrackingCardShell';
import { supabase } from '../../../../src/lib/supabase';
import { serviceOptions } from '../../../../src/constants/serviceOptions';
import { HUB_WASH_DISPLAY_NAME } from '../../../../src/constants/washTierPlatformCopy';
import {
  BOOKING_CARD,
  HEADER_STYLE_CARD_GRADIENT,
  PREMIUM_BOOKING_MAP_SHEET_GLASS,
  getCustomerBookingSheetScreenBottom,
  getIndexTrackingCardSnapInterval,
  getIndexTrackingCardWidth,
} from '../../../../src/constants/bookingCardTheme';
import ServiceTierSpongeIcon, { getServiceTierLeadIconName } from '../../../../src/components/booking/ServiceTierSpongeIcon';
import { customerMapTrackingSheetActionStyles } from '../../../../src/components/booking/CustomerMapTrackingSheetShell';
import { HEADER_BORDER_RADIUS } from '../../../../src/constants/layoutConstants';
import { getVehicleSize } from '../../../../src/pricing/pricingEngine';
import { BOOKING_FLOW_VIDEO } from '../../../assets/assetExports';
import BookingSheetPremiumLayers from '../../../../src/components/booking/BookingSheetPremiumLayers';
import BookingBottomSheetOverlay from '../../../../src/components/booking/BookingBottomSheetOverlay';
import useLiveLocation from '../../../../src/hooks/useLiveLocation';
import PhysicalBookingHubMapLayer from '../../../../src/components/booking/PhysicalBookingHubMapLayer';
import { useAuth } from '../../../../src/providers/enhanced-auth-context';
import {
  ActiveBookingBlockedError,
  createHubPendingPaymentBooking,
  fetchCarWashHub,
} from '../../../../src/utils/hubPendingPaymentBooking';

const { width } = Dimensions.get('window');
const SKY = colors.SKY;

type TierId = 'bronze-wash' | 'silver-wash' | 'gold-wash' | 'platinum-wash' | 'emerald-wash';

const WASH_TIER_TAGLINES: Partial<Record<TierId, string>> = {
  'bronze-wash': 'Quick exterior wash',
  'silver-wash': 'Exterior + light interior',
  'gold-wash': 'Interior focused',
  'platinum-wash': 'Full valet',
  'emerald-wash': 'Premium full detail',
};

const TIER_COLORS = {
  'bronze-wash': { main: '#CD7F32', light: 'rgba(205,127,50,0.25)', border: 'rgba(205,127,50,0.5)' },
  'silver-wash': { main: '#A8A8A8', light: 'rgba(168,168,168,0.2)', border: 'rgba(168,168,168,0.5)' },
  'gold-wash': { main: '#FFD700', light: 'rgba(255,215,0,0.2)', border: 'rgba(255,215,0,0.5)' },
  'platinum-wash': { main: '#E5E4E2', light: 'rgba(229,228,226,0.2)', border: 'rgba(229,228,226,0.5)' },
  'emerald-wash': { main: '#22D3EE', light: 'rgba(34,211,238,0.25)', border: 'rgba(34,211,238,0.48)' },
} as const;

type ServiceUI = {
  id: TierId;
  name: string;
  desc: string;
  dur: string;
  minutes: number;
  price: number;
  is_enabled: boolean;
  badge?: 'Best Value' | 'Most Popular' | 'Premium Detail';
  bulletPoints?: string[];
  descriptionTitle?: string;
};

const TIERS: Array<{
  id: TierId;
  service_name: 'Bronze Wash' | 'Silver Wash' | 'Gold Wash' | 'Platinum Wash' | 'Diamond Wash';
  defaultDesc: string;
  defaultMinutes: number;
  badge?: 'Best Value' | 'Most Popular' | 'Premium Detail';
  hubDescriptionTitle: string;
  hubBullets: string[];
}> = [
  {
    id: 'bronze-wash',
    service_name: 'Bronze Wash',
    defaultDesc:
      'A quick exterior wash to remove dirt and grime. Includes foam wash, rinse, and dry for a clean and refreshed finish.',
    defaultMinutes: 30,
    hubDescriptionTitle: 'Exterior wash',
    hubBullets: [
      'Quick exterior wash to remove dirt and grime',
      'Foam wash, rinse, and dry',
      'Clean and refreshed finish',
    ],
  },
  {
    id: 'silver-wash',
    service_name: 'Silver Wash',
    defaultDesc:
      'An exterior wash combined with a light interior clean. Includes vacuuming and a quick wipe-down of key surfaces for a tidy finish.',
    defaultMinutes: 60,
    hubDescriptionTitle: 'Exterior + light interior',
    hubBullets: [
      'Exterior wash combined with a light interior clean',
      'Vacuuming and quick wipe-down of key surfaces',
      'Tidy finish inside and out',
    ],
  },
  {
    id: 'gold-wash',
    service_name: 'Gold Wash',
    defaultDesc:
      'A deeper interior clean for vehicles needing extra attention. Includes thorough vacuuming, surface cleaning, and targeted stain treatment.',
    defaultMinutes: 90,
    badge: 'Most Popular',
    hubDescriptionTitle: 'Interior focused',
    hubBullets: [
      'Deeper interior clean for vehicles needing extra attention',
      'Thorough vacuuming and surface cleaning',
      'Targeted stain treatment',
    ],
  },
  {
    id: 'platinum-wash',
    service_name: 'Platinum Wash',
    defaultDesc:
      'A full interior and exterior clean with added attention to detail. Includes a thorough wash, interior cleaning, and finishing touches for a polished result.',
    defaultMinutes: 120,
    badge: 'Premium Detail',
    hubDescriptionTitle: 'Full valet',
    hubBullets: [
      'Full interior and exterior clean',
      'Thorough wash and interior cleaning',
      'Finishing touches for a polished result',
    ],
  },
  {
    id: 'emerald-wash',
    service_name: 'Diamond Wash',
    defaultDesc:
      'A premium full-service clean designed to deliver the best possible finish. Includes detailed interior and exterior care with enhanced finishing for maximum shine and presentation.',
    defaultMinutes: 135,
    badge: 'Premium Detail',
    hubDescriptionTitle: 'Premium full detail',
    hubBullets: [
      'Premium full-service clean — best possible finish',
      'Detailed interior and exterior care',
      'Enhanced finishing for maximum shine and presentation',
    ],
  },
];

function money(n: any) {
  let v: number;
  if (typeof n === 'string') v = Number(n);
  else if (typeof n === 'number') v = n;
  else v = 0;
  if (!Number.isFinite(v)) return 0;
  return v;
}

export default function PhysicalServiceSelection() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { coords } = useLiveLocation();
  const sheetBottom = getCustomerBookingSheetScreenBottom();
  const cardWidth = getIndexTrackingCardWidth(width);
  const snapInterval = getIndexTrackingCardSnapInterval(width);
  const params = useLocalSearchParams();
  const locationId = params.locationId as string;
  const vehicleId = params.vehicleId as string;
  const scheduledAt = params.scheduledAt as string | undefined;
  const preSelectedServiceId = params.serviceId as TierId | undefined;

  const [selectedService, setSelectedService] = useState<TierId | null>(null);
  const [washType, setWashType] = useState<'exterior' | 'interior' | 'both' | null>(null);
  const [infoModalService, setInfoModalService] = useState<ServiceUI | null>(null);
  const [washTypeModalVisible, setWashTypeModalVisible] = useState(false);
  const scrollViewRef = useRef<ScrollView>(null);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  const [loading, setLoading] = useState(true);
  const [services, setServices] = useState<ServiceUI[]>([]);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [checkoutSubmitting, setCheckoutSubmitting] = useState(false);
  const [hubLocation, setHubLocation] = useState<{ latitude: number; longitude: number; name: string; address: string } | null>(null);
  /** Vehicle size for pricing: small / medium / large / xl / xxl (from selected vehicle) */
  const [vehicleSizeKey, setVehicleSizeKey] = useState<'small' | 'medium' | 'large' | 'xl' | 'xxl'>('medium');

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  useEffect(() => {
    if (!locationId) {
      setLoading(false);
      setLoadError('Missing location.');
      return;
    }
    loadHubLocation();
    loadTierPrices();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [locationId]);

  // Load vehicle to get size for pricing (cards show price for your vehicle size)
  useEffect(() => {
    if (!vehicleId) {
      setVehicleSizeKey('medium');
      return;
    }
    let cancelled = false;
    (async () => {
      const { data, error } = await supabase
        .from('vehicles')
        .select('id, make, model, type, size')
        .eq('id', vehicleId)
        .maybeSingle();
      if (cancelled) return;
      if (error || !data) {
        setVehicleSizeKey('medium');
        return;
      }
      const v = data as { make?: string; model?: string; type?: string; size?: string };
      if (v.size === 'small' || v.size === 'medium' || v.size === 'large' || v.size === 'xl' || v.size === 'xxl') {
        setVehicleSizeKey(v.size);
        return;
      }
      const engineSize = getVehicleSize({ make: v.make, model: v.model, type: v.type });
      let key: 'small' | 'medium' | 'large' | 'xl' | 'xxl' = 'medium';
      if (engineSize === 'SMALL') key = 'small';
      else if (engineSize === 'XXL') key = 'xxl';
      else if (engineSize === 'XL') key = 'xl';
      else if (engineSize === 'LARGE') key = 'large';
      setVehicleSizeKey(key);
    })();
    return () => { cancelled = true; };
  }, [vehicleId]);

  const loadHubLocation = async () => {
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id, name, address, latitude, longitude')
        .eq('id', locationId)
        .single();

      if (error) throw error;
      if (data?.latitude != null && data?.longitude != null) {
        const hub = {
          latitude: Number(data.latitude),
          longitude: Number(data.longitude),
          name: data.name || 'Car Wash',
          address: data.address || '',
        };
        setHubLocation(hub);
      }
    } catch (err) {
      console.error('Error loading hub location:', err);
    }
  };

  const loadTierPrices = async () => {
    try {
      setLoading(true);
      setLoadError(null);

      const { data, error } = await supabase
        .from('location_services')
        .select('service_name, price, duration_minutes, is_enabled')
        .eq('location_id', locationId);

      if (error) throw error;

      const rows = (data || []) as Array<{
        service_name: string | null;
        price: number | null;
        duration_minutes: number | null;
        is_enabled: boolean | null;
      }>;

      const map = new Map<string, { price: number; minutes: number; enabled: boolean }>();
      rows.forEach((r) => {
        const name = (r.service_name || '').trim();
        if (!name) return;
        map.set(name, {
          price: money(r.price),
          minutes: typeof r.duration_minutes === 'number' && r.duration_minutes > 0 ? r.duration_minutes : 0,
          enabled: r.is_enabled === null || r.is_enabled === undefined ? true : !!r.is_enabled,
        });
      });

      const built: ServiceUI[] = TIERS.map((t) => {
        const hit = map.get(t.service_name);
        const minutes = hit?.minutes ? hit.minutes : t.defaultMinutes;
        const durText = `${minutes} min`;

        return {
          id: t.id,
          name: HUB_WASH_DISPLAY_NAME[t.id],
          desc: t.defaultDesc,
          minutes,
          dur: durText,
          price: hit?.price ?? 0,
          is_enabled: hit?.enabled ?? false,
          badge: t.badge,
          bulletPoints: t.hubBullets,
          descriptionTitle: t.hubDescriptionTitle,
        };
      }).filter((s) => s.is_enabled);

      setServices(built);

      if (preSelectedServiceId && built.some((b) => b.id === preSelectedServiceId)) {
        setSelectedService(preSelectedServiceId);
        if (preSelectedServiceId !== 'bronze-wash') setWashType('both');
      } else {
        setSelectedService((prev) => {
          if (!prev) return prev;
          const stillThere = built.some((b) => b.id === prev);
          return stillThere ? prev : null;
        });
      }
    } catch (e: any) {
      console.error('[PhysicalServiceSelection] loadTierPrices error:', e);
      setLoadError(e?.message || 'Failed to load pricing.');
      setServices([]);
    } finally {
      setLoading(false);
    }
  };

  const handleServiceSelect = async (serviceId: TierId) => {
    await hapticFeedback('light');
    setSelectedService(serviceId);
    if (serviceId === 'bronze-wash') {
      setWashType(null);
      setWashTypeModalVisible(true);
    } else {
      setWashType('both');
    }
  };

  // When opening from hub details with a pre-selected service, scroll to that card so user sees price and can continue
  useEffect(() => {
    if (services.length === 0 || !selectedService) return;
    const index = services.findIndex((s) => s.id === selectedService);
    if (index < 0) return;
    const timer = setTimeout(() => {
      scrollViewRef.current?.scrollTo({
        x: index * snapInterval,
        animated: true,
      });
    }, 300);
    return () => clearTimeout(timer);
  }, [services, selectedService]);

  const handleWashTypeSelect = async (type: 'exterior' | 'interior' | 'both') => {
    await hapticFeedback('light');
    setWashType(type);
    setWashTypeModalVisible(false);
  };

  const syncSelectionFromScrollIndex = (index: number) => {
    const s = services[index];
    if (!s) return;
    setSelectedService(s.id);
    if (s.id === 'bronze-wash') {
      setWashType(null);
    } else {
      setWashType('both');
    }
  };

  const selectedServiceData = useMemo(
    () => services.find((s) => s.id === selectedService) || null,
    [services, selectedService]
  );

  const serviceContinueAccent = selectedServiceData ? TIER_COLORS[selectedServiceData.id].main : SKY;
  const serviceContinueReady = !!(
    selectedService &&
    selectedServiceData &&
    Number.isFinite(selectedServiceData.price) &&
    selectedServiceData.price > 0 &&
    (selectedService !== 'bronze-wash' || !!washType)
  );

  // Calculate pricing tiers (S/M/L/XL/XXL) – same as info icon modal
  const getPriceTiers = (basePrice: number) => {
    return {
      small: basePrice,
      medium: Math.round(basePrice * 1.2 * 100) / 100,
      large: Math.round(basePrice * 1.4 * 100) / 100,
      xl: Math.round(basePrice * 1.6 * 100) / 100,
      xxl: Math.round(basePrice * 1.85 * 100) / 100,
    };
  };

  /** Price for the selected vehicle size (used on cards and for booking) */
  const getPriceForVehicleSize = (basePrice: number) => {
    const tiers = getPriceTiers(basePrice);
    return tiers[vehicleSizeKey];
  };

  const bronzeExteriorPrice = selectedServiceData ? getPriceForVehicleSize(selectedServiceData.price) : 0;
  const bronzeInteriorPrice = selectedServiceData ? getPriceForVehicleSize(selectedServiceData.price) : 0;

  const onPrimaryContinue = async () => {
    if (!locationId || !vehicleId || !selectedService) return;
    const selected = services.find((s) => s.id === selectedService);
    if (!selected) return;

    if (!Number.isFinite(selected.price) || selected.price <= 0) {
      Alert.alert('Unavailable', 'This service does not have a price set yet. Please pick another option.');
      return;
    }

    if (selectedService === 'bronze-wash' && !washType) {
      setWashTypeModalVisible(true);
      return;
    }

    await hapticFeedback('medium');

    const finalPrice = getPriceForVehicleSize(selected.price);
    const effectiveWashType: 'exterior' | 'interior' | 'both' =
      selectedService === 'bronze-wash' ? (washType as 'exterior' | 'interior') : 'both';

    const baseParams = {
      serviceId: selectedService,
      vehicleId,
      locationId,
      washType: effectiveWashType,
      price: String(finalPrice),
    };

    if (scheduledAt) {
      if (!user?.id) {
        Alert.alert('Sign in required', 'Please sign in to complete your booking.');
        return;
      }
      const catalogSvc = serviceOptions.find((s) => s.id === selectedService);
      if (!catalogSvc) return;

      try {
        setCheckoutSubmitting(true);
        const hub = await fetchCarWashHub(locationId);
        if (!hub) {
          Alert.alert('Error', 'Could not load this location.');
          return;
        }
        const bookingId = await createHubPendingPaymentBooking({
          userId: user.id,
          vehicleId,
          hub,
          service: { id: catalogSvc.id, name: catalogSvc.name },
          price: finalPrice,
          washType: effectiveWashType,
          scheduledAt,
        });
        router.replace({
          pathname: '/owner/booking/payment',
          params: { bookingId },
        });
      } catch (err: unknown) {
        if (err instanceof ActiveBookingBlockedError) {
          Alert.alert(
            'One booking at a time',
            'You already have an active booking. Please complete or cancel it before starting a new one.',
            [
              { text: 'OK', style: 'cancel' },
              {
                text: 'View my booking',
                onPress: () =>
                  router.push({ pathname: '/owner/booking/tracking', params: { bookingId: err.activeBookingId } } as any),
              },
            ]
          );
        } else {
          console.error('[PhysicalService] booking error', err);
          const message = err && typeof err === 'object' && 'message' in err ? String((err as { message: string }).message) : 'Unable to create booking';
          Alert.alert('Error', message);
        }
      } finally {
        setCheckoutSubmitting(false);
      }
    } else {
      router.push({
        pathname: '/owner/booking/physical/schedule',
        params: baseParams,
      });
    }
  };

  const handleExitBooking = async () => {
    await hapticFeedback('light');
    router.replace('/owner/owner-dashboard' as any);
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <AppHeader 
          title="Select Service" 
          showBack={true}
          onBack={() => router.back()}
        />
        <View style={styles.loadingWrap}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading prices...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (loadError) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <AppHeader 
          title="Select Service" 
          showBack={true}
          onBack={() => router.back()}
        />
        <View style={styles.loadingWrap}>
          <Ionicons name="alert-circle-outline" size={44} color={SKY} style={{ opacity: 0.9 }} />
          <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320 }]}>{loadError}</Text>
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              loadTierPrices();
            }}
            style={styles.retryBtn}
            activeOpacity={0.85}
          >
            <LinearGradient colors={[SKY, '#60A5FA']} style={styles.retryGrad}>
              <Ionicons name="refresh" size={18} color="#fff" />
              <Text style={styles.retryText}>Retry</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  if (!services.length) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <AppHeader 
          title="Select Service" 
          showBack={true}
          onBack={() => router.back()}
        />
        <View style={styles.loadingWrap}>
          <Ionicons name="pricetag-outline" size={44} color={SKY} style={{ opacity: 0.9 }} />
          <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320 }]}>
            This location hasn't enabled any services yet.
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      {hubLocation && Number.isFinite(hubLocation.latitude) && Number.isFinite(hubLocation.longitude) ? (
        <PhysicalBookingHubMapLayer
          hubLatitude={hubLocation.latitude}
          hubLongitude={hubLocation.longitude}
          userLatitude={coords?.latitude}
          userLongitude={coords?.longitude}
          mapPaddingBottom={sheetBottom + 52}
        />
      ) : (
        <Video
          source={BOOKING_FLOW_VIDEO}
          style={StyleSheet.absoluteFill}
          shouldPlay
          isLooping
          isMuted
          resizeMode={ResizeMode.COVER}
        />
      )}

      <AppHeader 
        title="Select Service" 
        subtitle={hubLocation?.name || 'Choose your wash service'}
        showBack={true}
        onBack={() => router.back()}
        rightAction={
          <TouchableOpacity 
            onPress={handleExitBooking} 
            style={styles.exitButton}
            activeOpacity={0.7}
          >
            <Ionicons name="close" size={22} color="#FFFFFF" />
          </TouchableOpacity>
        }
      />

      <Animated.View style={[styles.cardsContainer, { opacity: fadeAnim, bottom: sheetBottom }]}>
        <View style={[styles.vehicleBottomSheet, { paddingBottom: Math.max(insets.bottom, 8) }]}>
          <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} />
          <LinearGradient colors={HEADER_STYLE_CARD_GRADIENT} style={StyleSheet.absoluteFill} />
          <LinearGradient
            colors={['rgba(255,255,255,0.16)', 'rgba(255,255,255,0.02)', 'transparent']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.locationSheetSheen}
          />
          <BookingSheetPremiumLayers />
          <View style={styles.locationSheetHandle} />
          {selectedServiceData ? (
            <View style={styles.vehicleSelectedBannerWrap}>
              <View style={styles.vehicleSelectedBanner}>
                <Ionicons name="sparkles-outline" size={14} color={serviceContinueAccent} />
                <Text style={[styles.vehicleSelectedBannerText, { color: serviceContinueAccent }]} numberOfLines={1}>
                  Selected: {selectedServiceData.name}
                </Text>
              </View>
            </View>
          ) : null}
          <ScrollView
            ref={scrollViewRef}
            horizontal
            showsHorizontalScrollIndicator={false}
            style={styles.bookingStepHorizontalScroll}
            contentContainerStyle={styles.bookingIndexOptionsScrollVehicle}
            snapToInterval={snapInterval}
            decelerationRate="fast"
            snapToAlignment="start"
            onMomentumScrollEnd={(e) => {
              const index = Math.round(e.nativeEvent.contentOffset.x / snapInterval);
              syncSelectionFromScrollIndex(index);
            }}
          >
            {services.map((service) => {
              const isSelected = selectedService === service.id;
              const tierColor = TIER_COLORS[service.id];

              return (
                <TouchableOpacity
                  key={service.id}
                  activeOpacity={0.92}
                  onPress={() => void handleServiceSelect(service.id)}
                  style={[ix.cardWrap, { width: cardWidth }]}
                >
                  <IndexTrackingCardShell
                    accentColor={tierColor.main}
                    style={{
                      borderColor: isSelected ? tierColor.main + 'AA' : 'rgba(148,163,184,0.35)',
                      borderWidth: 2,
                    }}
                  >
                    <View style={ix.optionCardTopRow}>
                      <ServiceTierSpongeIcon accentColor={tierColor.main} iconName={getServiceTierLeadIconName(service.id)} />
                      <View style={ix.optionTitleMain}>
                        <View style={[ix.optionKickerRow, ix.optionKickerSlot]}>
                          {service.badge ? (
                            <View
                              style={[
                                styles.serviceBadgePill,
                                {
                                  backgroundColor: tierColor.main + '30',
                                  borderColor: tierColor.main + '50',
                                  flexShrink: 1,
                                  maxWidth: '52%',
                                },
                              ]}
                            >
                              <Text style={[styles.serviceBadgePillText, { color: tierColor.main }]} numberOfLines={1}>
                                {service.badge}
                              </Text>
                            </View>
                          ) : null}
                        </View>
                        <Text style={ix.optionTitle} numberOfLines={2}>
                          {service.name}
                        </Text>
                        <Text style={ix.optionSubtitle} numberOfLines={2}>
                          {service.dur} · Prices vary
                        </Text>
                        <View style={styles.serviceCardTaglineSlot}>
                          {WASH_TIER_TAGLINES[service.id] ? (
                            <Text style={[styles.tierTagline, { color: tierColor.main + 'CC' }]} numberOfLines={2}>
                              {WASH_TIER_TAGLINES[service.id]}
                            </Text>
                          ) : null}
                        </View>
                      </View>
                      <TouchableOpacity
                        style={[ix.optionInfoBtn, { borderColor: tierColor.main + '40', backgroundColor: tierColor.main + '15' }]}
                        onPress={() => { hapticFeedback('light'); setInfoModalService(service); }}
                        activeOpacity={0.85}
                        accessibilityLabel="Service details"
                        accessibilityRole="button"
                      >
                        <Ionicons name="information-circle-outline" size={22} color={tierColor.main} />
                      </TouchableOpacity>
                    </View>
                    <View style={ix.optionFooterRow}>
                      <View style={[ix.optionFooterLeft, styles.serviceCardFooterRow]}>
                        {isSelected && selectedService === 'bronze-wash' ? (
                          <TouchableOpacity
                            onPress={() => setWashTypeModalVisible(true)}
                            style={[styles.washTypeChipSmall, { backgroundColor: tierColor.main + '22', borderColor: tierColor.main + '44' }]}
                            activeOpacity={0.8}
                          >
                            {washType ? (
                              <>
                                <Ionicons
                                  name={washType === 'exterior' ? 'car-sport-outline' : 'home-outline'}
                                  size={14}
                                  color={tierColor.main}
                                />
                                <Text style={[styles.washTypeChipSmallText, { color: tierColor.main }]}>
                                  {washType === 'exterior' ? 'Exterior' : 'Interior'}
                                </Text>
                              </>
                            ) : (
                              <Text style={[styles.washTypeChipSmallText, { color: tierColor.main }]}>Set clean area</Text>
                            )}
                          </TouchableOpacity>
                        ) : null}
                        {services.length > 1 ? (
                          <View style={[ix.optionStatusPill, { backgroundColor: 'rgba(148,163,184,0.12)' }]}>
                            <View style={[ix.optionStatusDot, { backgroundColor: '#94A3B8' }]} />
                            <Text style={[ix.optionStatusText, { color: '#94A3B8' }]}>Swipe to compare</Text>
                          </View>
                        ) : null}
                      </View>
                    </View>
                  </IndexTrackingCardShell>
                </TouchableOpacity>
              );
            })}
          </ScrollView>
          <View style={[styles.sheetPrimaryCtaRow, styles.sheetPrimaryCtaRowVehicleStep]}>
            <View style={{ width: cardWidth }}>
              <TouchableOpacity
                style={[
                  customerMapTrackingSheetActionStyles.bookingInfoActionCard,
                  customerMapTrackingSheetActionStyles.bookingInfoCard,
                  styles.bookingSheetTrackingCta,
                  {
                    borderColor: serviceContinueAccent + '8A',
                    opacity: serviceContinueReady ? 1 : 0.45,
                  },
                ]}
                onPress={() => void onPrimaryContinue()}
                disabled={!serviceContinueReady || checkoutSubmitting}
                activeOpacity={0.85}
              >
                <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
                <LinearGradient
                  colors={[serviceContinueAccent + '59', 'rgba(15,23,42,0.65)']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 0, y: 1 }}
                  style={StyleSheet.absoluteFill}
                  pointerEvents="none"
                />
                <Ionicons name="arrow-forward-circle" size={18} color={serviceContinueAccent} style={{ zIndex: 1 }} />
                <View style={customerMapTrackingSheetActionStyles.bookingInfoCardTextWrap}>
                  <Text style={[styles.bookingSheetCtaLabel, { color: serviceContinueAccent }]}>
                    {checkoutSubmitting ? 'Creating booking…' : 'Continue to valeter'}
                  </Text>
                </View>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Animated.View>

      <BookingBottomSheetOverlay visible={!!infoModalService} onClose={() => setInfoModalService(null)} maxHeightRatio={0.88}>
        {infoModalService ? (() => {
              const tc = TIER_COLORS[infoModalService.id];
              return (
                <>
                  <View style={[styles.serviceInfoHero, { borderBottomColor: tc.light + '35' }]}>
                    <Text style={[styles.infoModalTitle, { color: colors.headerText }]} numberOfLines={2}>{infoModalService.name}</Text>
                    {infoModalService.badge ? (
                        <View style={[styles.infoModalBadge, { backgroundColor: tc.light, borderColor: tc.border }]}>
                          <Text style={[styles.infoModalBadgeText, { color: tc.main }]}>{infoModalService.badge}</Text>
                        </View>
                      ) : null}
                  </View>
                    <ScrollView
                      style={styles.infoModalScroll}
                      contentContainerStyle={styles.infoModalScrollContent}
                      showsVerticalScrollIndicator
                    >
                    <View style={[styles.infoModalPriceRow, { borderLeftColor: tc.main }]}>
                      <Text style={[styles.infoModalPrice, { color: tc.main }]}>£{infoModalService.price.toFixed(0)}</Text>
                      <View style={styles.infoModalDuration}>
                        <Ionicons name="time-outline" size={14} color="#64748B" />
                        <Text style={styles.infoModalDurationText}>{infoModalService.dur}</Text>
                      </View>
                    </View>
                    {infoModalService.descriptionTitle ? (
                      <Text style={[styles.infoModalDescTitle, { color: tc.main }]}>{infoModalService.descriptionTitle}</Text>
                    ) : null}
                    <Text style={styles.infoModalDesc}>{infoModalService.desc}</Text>
                    {infoModalService.bulletPoints && infoModalService.bulletPoints.length > 0 && (
                      <View style={styles.infoModalSection}>
                        <View style={styles.infoModalSectionTitleRow}>
                          <Ionicons name="checkmark-done-circle" size={16} color={tc.main} />
                          <Text style={[styles.infoModalSectionTitle, { color: tc.main }]}>Includes</Text>
                        </View>
                        {infoModalService.bulletPoints.map((f) => (
                          <View key={f} style={styles.infoModalFeatureRow}>
                            <Ionicons name="checkmark-circle" size={18} color={tc.main} />
                            <Text style={styles.infoModalFeatureText}>{f}</Text>
                          </View>
                        ))}
                      </View>
                    )}
                    <View style={[styles.infoModalSection, { borderTopColor: tc.light + '50' }]}>
                      <View style={styles.infoModalSectionTitleRow}>
                        <Ionicons name="car-sport-outline" size={16} color={tc.main} />
                        <Text style={[styles.infoModalSectionTitle, { color: tc.main }]}>Price by size</Text>
                      </View>
                      <View style={styles.infoModalTiers}>
                        <View style={[styles.infoModalTierItem, { backgroundColor: tc.light + '15', borderColor: tc.light + '35' }]}>
                          <Text style={styles.infoModalTierLabel}>S</Text>
                          <Text style={[styles.infoModalTierValue, { color: tc.main }]}>£{getPriceTiers(infoModalService.price).small.toFixed(0)}</Text>
                        </View>
                        <View style={[styles.infoModalTierItem, { backgroundColor: tc.light + '15', borderColor: tc.light + '35' }]}>
                          <Text style={styles.infoModalTierLabel}>M</Text>
                          <Text style={[styles.infoModalTierValue, { color: tc.main }]}>£{getPriceTiers(infoModalService.price).medium.toFixed(0)}</Text>
                        </View>
                        <View style={[styles.infoModalTierItem, { backgroundColor: tc.light + '15', borderColor: tc.light + '35' }]}>
                          <Text style={styles.infoModalTierLabel}>L</Text>
                          <Text style={[styles.infoModalTierValue, { color: tc.main }]}>£{getPriceTiers(infoModalService.price).large.toFixed(0)}</Text>
                        </View>
                        <View style={[styles.infoModalTierItem, { backgroundColor: tc.light + '15', borderColor: tc.light + '35' }]}>
                          <Text style={styles.infoModalTierLabel}>XL</Text>
                          <Text style={[styles.infoModalTierValue, { color: tc.main }]}>£{getPriceTiers(infoModalService.price).xl.toFixed(0)}</Text>
                        </View>
                        <View style={[styles.infoModalTierItem, { backgroundColor: tc.light + '15', borderColor: tc.light + '35' }]}>
                          <Text style={styles.infoModalTierLabel}>XXL</Text>
                          <Text style={[styles.infoModalTierValue, { color: tc.main }]}>£{getPriceTiers(infoModalService.price).xxl.toFixed(0)}</Text>
                        </View>
                      </View>
                    </View>
                    </ScrollView>
                  <TouchableOpacity
                    onPress={() => setInfoModalService(null)}
                    style={[styles.infoModalDoneBtn, { backgroundColor: tc.main }]}
                    activeOpacity={0.9}
                  >
                    <Text style={styles.infoModalDoneText}>Close</Text>
                  </TouchableOpacity>
                </>
              );
            })() : null}
      </BookingBottomSheetOverlay>

      <BookingBottomSheetOverlay
        visible={washTypeModalVisible}
        onClose={() => setWashTypeModalVisible(false)}
        maxHeightRatio={0.88}
      >
        <View style={styles.washTypeSheetHeader}>
          <View style={[styles.washTypeModalBadge, { backgroundColor: TIER_COLORS['bronze-wash'].main }]}>
            <MaterialCommunityIcons name="car-wash" size={18} color="#0F172A" />
            <Text style={styles.washTypeModalBadgeText}>Bronze Wash</Text>
          </View>
          <Text style={styles.washTypeModalTitle}>What do you want cleaned?</Text>
          <Text style={styles.washTypeModalSubtitle}>
            Exterior or interior — both include our quick & affordable bronze treatment
          </Text>
        </View>
        <View style={styles.washTypeModalOptions}>
          <TouchableOpacity
            onPress={() => void handleWashTypeSelect('exterior')}
            style={[styles.washTypeModalOption, { borderColor: TIER_COLORS['bronze-wash'].border }]}
            activeOpacity={0.85}
          >
            <View style={[styles.washTypeModalOptionIcon, { backgroundColor: TIER_COLORS['bronze-wash'].light }]}>
              <Ionicons name="car-sport-outline" size={32} color={TIER_COLORS['bronze-wash'].main} />
            </View>
            <View style={styles.washTypeModalOptionBody}>
              <Text style={styles.washTypeModalOptionLabel}>Exterior</Text>
              <Text style={styles.washTypeModalOptionDesc}>
                Wheels & arches, snow foam, hand wash, rinse, dry, windows & mirrors
              </Text>
            </View>
            <Text style={[styles.washTypeModalOptionPrice, { color: TIER_COLORS['bronze-wash'].main }]}>
              £{(bronzeExteriorPrice || 0).toFixed(0)}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => void handleWashTypeSelect('interior')}
            style={[styles.washTypeModalOption, { borderColor: TIER_COLORS['bronze-wash'].border }]}
            activeOpacity={0.85}
          >
            <View style={[styles.washTypeModalOptionIcon, { backgroundColor: TIER_COLORS['bronze-wash'].light }]}>
              <Ionicons name="layers-outline" size={32} color={TIER_COLORS['bronze-wash'].main} />
            </View>
            <View style={styles.washTypeModalOptionBody}>
              <Text style={styles.washTypeModalOptionLabel}>Interior</Text>
              <Text style={styles.washTypeModalOptionDesc}>
                Vacuum, wipe-down, steering wheel, glass & air freshener
              </Text>
            </View>
            <Text style={[styles.washTypeModalOptionPrice, { color: TIER_COLORS['bronze-wash'].main }]}>
              £{(bronzeInteriorPrice || 0).toFixed(0)}
            </Text>
          </TouchableOpacity>
        </View>
      </BookingBottomSheetOverlay>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  cardsContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    width: '100%',
  },
  vehicleBottomSheet: {
    width: '100%',
    paddingTop: 2,
    ...PREMIUM_BOOKING_MAP_SHEET_GLASS,
  },
  locationSheetSheen: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.9,
  },
  locationSheetHandle: {
    width: 42,
    height: 4,
    borderRadius: 2,
    alignSelf: 'center',
    marginTop: 10,
    marginBottom: 4,
    backgroundColor: 'rgba(255,255,255,0.55)',
  },
  bookingStepHorizontalScroll: {
    flexGrow: 0,
    flexShrink: 0,
  },
  bookingIndexOptionsScrollVehicle: {
    marginTop: 18,
    paddingLeft: 14,
    paddingRight: 12,
    gap: 10,
  },
  sheetPrimaryCtaRow: {
    paddingLeft: 14,
    paddingRight: 14,
    paddingTop: 0,
    marginTop: -10,
    paddingBottom: 2,
  },
  sheetPrimaryCtaRowVehicleStep: {
    marginTop: 10,
  },
  bookingSheetTrackingCta: {
    flex: 0,
    alignSelf: 'stretch',
    width: '100%',
    minHeight: 50,
    paddingVertical: 11,
    paddingHorizontal: 14,
    borderRadius: 24,
    gap: 8,
  },
  bookingSheetCtaLabel: {
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 0.15,
    includeFontPadding: false,
  },
  vehicleSelectedBannerWrap: {
    paddingHorizontal: 14,
    paddingTop: 2,
    paddingBottom: 10,
  },
  vehicleSelectedBanner: {
    marginTop: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(56,189,248,0.45)',
    backgroundColor: 'rgba(56,189,248,0.12)',
    alignSelf: 'flex-start',
  },
  vehicleSelectedBannerText: {
    fontSize: 11,
    fontWeight: '700',
  },
  content: { flex: 1 },
  loadingWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, paddingHorizontal: 24 },
  loadingText: { color: SKY, fontSize: 14 },
  retryBtn: { marginTop: 10, borderRadius: 16, overflow: 'hidden' },
  retryGrad: { flexDirection: 'row', gap: 8, alignItems: 'center', justifyContent: 'center', paddingVertical: 12, paddingHorizontal: 18 },
  retryText: { color: '#fff', fontWeight: '800' },
  modernCard: {
    padding: 12,
    overflow: 'hidden',
  },
  modernCardSelected: {
    borderWidth: 0,
    borderColor: 'transparent',
    shadowColor: SKY,
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  cardTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  iconWrap: {
    width: 36,
    height: 36,
    borderRadius: 10,
    marginRight: 8,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardContent: {
    flex: 1,
    minWidth: 0,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 2,
  },
  titleAndBadge: {
    flex: 1,
    minWidth: 0,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flexWrap: 'wrap',
  },
  cardTitle: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '800',
  },
  serviceBadgePill: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
    borderWidth: 1,
    alignSelf: 'flex-start',
  },
  serviceBadgePillText: {
    fontSize: 11,
    fontWeight: '700',
  },
  cardSubtitle: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '600',
  },
  cardMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 4,
  },
  quickHint: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 9,
    paddingVertical: 4,
    borderRadius: 10,
    borderWidth: 1,
  },
  quickHintText: {
    fontSize: 11,
    fontWeight: '600',
  },
  serviceCardSelected: {
    elevation: 4,
    shadowOpacity: 0.18,
    shadowRadius: 10,
  },
  badgePill: {
    alignSelf: 'flex-start',
    marginBottom: 6,
    zIndex: 2,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.35)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.12,
    shadowRadius: 4,
    elevation: 2,
  },
  badgePillIconWrap: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: 'rgba(15,23,42,0.25)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  badgePillText: {
    color: '#0F172A',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.25,
    maxWidth: 110,
  },
  cardInner: {
    padding: 16,
    paddingTop: 14,
  },
  cardContentRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
  },
  cardMain: {
    flex: 1,
    minWidth: 0,
    paddingRight: 44,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  serviceIconWrap: {
    width: 52,
    height: 52,
    borderRadius: 16,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  selectedCheck: {
    width: 22,
    height: 22,
    borderRadius: 11,
    justifyContent: 'center',
    alignItems: 'center',
  },
  serviceName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 6,
    letterSpacing: -0.2,
  },
  serviceReinforcement: {
    color: '#87CEEB',
    fontSize: 12,
    marginBottom: 6,
    fontStyle: 'italic',
  },
  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  statPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: 'rgba(148,163,184,0.12)',
    paddingHorizontal: 8,
    paddingVertical: 5,
    borderRadius: 8,
  },
  statText: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '600',
  },
  servicePrice: {
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: -0.3,
  },
  serviceCardInfoBtn: {
    position: 'absolute',
    top: 12,
    right: 12,
    zIndex: 10,
  },
  tierBadgeBox: {
    width: 72,
    height: 72,
    marginLeft: 14,
  },
  tierBadgeTouch: {
    width: '100%',
    height: '100%',
    borderRadius: 16,
    borderWidth: 1.5,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },

  washTypeChip: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 12,
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
    gap: 8,
  },
  washTypeChipText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
    flex: 1,
  },
  washTypeChipSmall: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 5,
    paddingHorizontal: 9,
    borderRadius: 8,
    borderWidth: 1,
    gap: 4,
    maxWidth: 132,
    flexShrink: 1,
  },
  washTypeChipSmallText: {
    fontSize: 11,
    fontWeight: '700',
  },
  serviceCardFooterRow: {
    flexWrap: 'nowrap',
    gap: 8,
    alignItems: 'center',
  },
  serviceCardTaglineSlot: {
    justifyContent: 'flex-start',
  },
  tierTagline: {
    marginTop: 6,
    fontSize: 12,
    fontWeight: '600',
    lineHeight: 16,
  },
  washTypeSheetHeader: {
    paddingBottom: 16,
    gap: 10,
  },
  washTypeModalBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  washTypeModalBadgeText: {
    color: '#0F172A',
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  washTypeModalTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 6,
  },
  washTypeModalSubtitle: {
    color: '#94A3B8',
    fontSize: 14,
    lineHeight: 20,
  },
  washTypeModalOptions: {
    padding: 20,
    gap: 12,
  },
  washTypeModalOption: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1.5,
    backgroundColor: 'rgba(205,127,50,0.06)',
  },
  washTypeModalOptionIcon: {
    width: 56,
    height: 56,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  washTypeModalOptionBody: {
    flex: 1,
    minWidth: 0,
  },
  washTypeModalOptionLabel: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 4,
  },
  washTypeModalOptionDesc: {
    color: '#94A3B8',
    fontSize: 13,
    lineHeight: 18,
  },
  washTypeModalOptionPrice: {
    fontSize: 18,
    fontWeight: '800',
    marginLeft: 12,
  },
  ctaWrapper: {
    marginTop: 10,
    paddingHorizontal: 16,
    alignItems: 'center',
  },
  ctaButton: {
    borderRadius: HEADER_BORDER_RADIUS,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
  },
  ctaGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    paddingHorizontal: 20,
    gap: 10,
  },
  ctaText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '900',
  },
  // Info modal – clean, matches app
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(10,25,41,0.78)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  serviceInfoHero: {
    marginBottom: 10,
    paddingBottom: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    gap: 8,
  },
  infoModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(5,15,30,0.88)',
    justifyContent: 'flex-end',
  },
  infoModalCard: {
    width: '100%',
    height: '90%',
    maxHeight: '90%',
    backgroundColor: '#1E293B',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    borderWidth: 1.5,
    borderBottomWidth: 0,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.35,
    shadowRadius: 24,
    elevation: 12,
  },
  infoModalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 18,
    paddingHorizontal: 20,
    paddingLeft: 24,
    borderBottomWidth: 1,
    position: 'relative',
  },
  infoModalAccent: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 4,
    borderTopLeftRadius: 2,
    borderBottomLeftRadius: 2,
  },
  infoModalHeaderContent: { flex: 1, marginLeft: 8 },
  infoModalTitle: {
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 4,
    color: '#F9FAFB',
  },
  infoModalBadge: {
    alignSelf: 'flex-start',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 10,
    borderWidth: 1,
  },
  infoModalBadgeText: { fontSize: 12, fontWeight: '700' },
  infoModalCloseBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(148,163,184,0.18)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoModalScrollWrap: {
    flex: 1,
    minHeight: 0,
  },
  infoModalScroll: {
    flex: 1,
    paddingHorizontal: 20,
  },
  infoModalScrollContent: {
    paddingTop: 18,
    paddingBottom: 24,
  },
  infoModalPriceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
    paddingLeft: 14,
    borderLeftWidth: 4,
    borderRadius: 2,
  },
  infoModalPrice: { fontSize: 26, fontWeight: '800' },
  infoModalDuration: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  infoModalDurationText: { color: '#94A3B8', fontSize: 14, fontWeight: '600' },
  infoModalDescTitle: {
    fontSize: 13,
    fontWeight: '700',
    marginBottom: 6,
    letterSpacing: 0.2,
  },
  infoModalDesc: {
    color: '#94A3B8',
    fontSize: 14,
    lineHeight: 22,
    marginBottom: 20,
  },
  infoModalSection: {
    marginBottom: 20,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(148,163,184,0.15)',
  },
  infoModalSectionTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  infoModalSectionTitle: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
  },
  infoModalFeatureRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
    marginBottom: 12,
  },
  infoModalFeatureText: {
    color: '#E2E8F0',
    fontSize: 14,
    flex: 1,
    lineHeight: 21,
  },
  infoModalTiers: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 6,
  },
  infoModalTierItem: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 8,
    borderRadius: 14,
    borderWidth: 1,
  },
  infoModalTierLabel: {
    color: '#94A3B8',
    fontSize: 11,
    fontWeight: '700',
    marginBottom: 4,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  infoModalTierValue: { fontSize: 16, fontWeight: '800' },
  infoModalDoneBtn: {
    marginHorizontal: 20,
    marginTop: 8,
    marginBottom: 20,
    paddingVertical: 16,
    borderRadius: 14,
    alignItems: 'center',
  },
  infoModalDoneText: { color: '#fff', fontSize: 16, fontWeight: '800' },

  exitButton: {
    width: 40,
    height: 40,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
});
