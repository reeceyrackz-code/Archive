import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Animated,
  Easing,
  Image,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Video, ResizeMode } from 'expo-av';
import { supabase } from '../../../src/lib/supabase';
import { colors } from '../../../src/constants/colors';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import {
  HEADER_STYLE_CARD_GRADIENT,
} from '../../../src/constants/bookingCardTheme';
import CustomerMapTrackingSheetShell, {
  customerMapTrackingSheetActionStyles,
  trackingInnerLayoutStyles,
} from '../../../src/components/booking/CustomerMapTrackingSheetShell';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { setPendingRatingBookingId } from '../../../src/utils/pendingCustomerRating';
import AnimatedProgress from '../../../src/components/booking/AnimatedProgress';
import {
  getStatusProgress,
  getStatusMessage,
  getStages,
  getStageProgressPercent,
  getRingColorForStep,
  isCustomerDetailingService,
  normalizeStatusForTracking,
} from '../../../src/utils/trackingStatusHelpers';
import { removeBookingFromDeviceCalendar } from '../../../src/services/BookingCalendarSync';
import { ValeterStatsService } from '../../../src/services/Valeterstatsservice';
import BookingPaymentSheet from '../../../src/components/booking/BookingPaymentSheet';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { getServiceDisplayName, getServiceDescription } from '../../../src/utils/serviceNameMapper';
import { serviceOptions, detailingServiceOptions, repairServiceOptions } from '../../../src/constants/serviceOptions';
import {
  ARRIVED_STAGE_VIDEO,
  BOOKING_FLOW_VIDEO,
  CONNECTING_STAGE_VIDEO,
  DONE_STAGE_VIDEO,
  ENROUTE_STAGE_VIDEO,
  WASHING_STAGE_VIDEO,
} from '../../assets/assetExports';

const SKY = colors.SKY ?? '#38BDF8';

function trackingMapTopPad(insetsTop: number) {
  return insetsTop + HEADER_CONTENT_OFFSET;
}

function moneyGBP(value: unknown) {
  const n = Number(value);
  if (!Number.isFinite(n)) return '0.00';
  return n.toFixed(2);
}

/** Price line in details: show em dash when total not stored yet */
function moneyGBPOrDash(value: unknown) {
  if (value == null || value === '') return '—';
  const n = Number(value);
  if (!Number.isFinite(n)) return '—';
  return n.toFixed(2);
}

function bookingIdFromSearchParams(params: { bookingId?: string | string[] }): string {
  const v = params.bookingId;
  if (typeof v === 'string' && v.length > 0) return v;
  if (Array.isArray(v) && typeof v[0] === 'string' && v[0].length > 0) return v[0];
  return '';
}

function normalizeBookingRow(raw: Record<string, unknown> | null | undefined): BookingRow | null {
  if (!raw || typeof raw !== 'object') return null;
  const locRaw = raw.location;
  let locLat: number | undefined;
  let locLng: number | undefined;
  let locAddress: string | undefined;
  if (locRaw && typeof locRaw === 'object') {
    const o = locRaw as Record<string, unknown>;
    const la = o.latitude ?? o.lat;
    const lo = o.longitude ?? o.lng;
    if (typeof la === 'number' && Number.isFinite(la)) locLat = la;
    else if (typeof la === 'string') {
      const n = parseFloat(la);
      if (Number.isFinite(n)) locLat = n;
    }
    if (typeof lo === 'number' && Number.isFinite(lo)) locLng = lo;
    else if (typeof lo === 'string') {
      const n = parseFloat(lo);
      if (Number.isFinite(n)) locLng = n;
    }
    if (typeof o.address === 'string' && o.address.trim()) locAddress = o.address.trim();
  }

  const numOrNull = (v: unknown): number | null => {
    if (v == null || v === '') return null;
    const n = typeof v === 'number' ? v : parseFloat(String(v));
    return Number.isFinite(n) ? n : null;
  };

  const lat = numOrNull(raw.location_lat) ?? (locLat != null ? locLat : null);
  const lng = numOrNull(raw.location_lng) ?? (locLng != null ? locLng : null);
  const flatAddr = typeof raw.location_address === 'string' ? raw.location_address.trim() : '';
  const location_address = flatAddr || locAddress || null;

  return {
    id: String(raw.id ?? ''),
    status: String(raw.status ?? 'pending_valeter_acceptance'),
    service_type:
      raw.service_type != null && String(raw.service_type).trim() ? String(raw.service_type).trim() : null,
    service_name:
      raw.service_name != null && String(raw.service_name).trim() ? String(raw.service_name).trim() : null,
    location_lat: lat,
    location_lng: lng,
    location_address,
    valeter_id: raw.valeter_id != null ? String(raw.valeter_id) : null,
    price: numOrNull(raw.price),
    add_ons_total: numOrNull(raw.add_ons_total),
    discount_amount: numOrNull(raw.discount_amount),
    wash_type: raw.wash_type != null ? String(raw.wash_type) : null,
  };
}

function getServiceSummaryLines(serviceType: string | null, serviceName: string | null): string[] {
  const display = getServiceDisplayName(serviceType, serviceName);
  const isDetailing =
    (serviceType || '').toLowerCase().includes('detail') ||
    display.toLowerCase().includes('detail');
  const allPackages = [...serviceOptions, ...detailingServiceOptions, ...repairServiceOptions];
  const opts = isDetailing ? [...detailingServiceOptions, ...repairServiceOptions] : serviceOptions;
  let opt = serviceType ? allPackages.find((o) => o.id === serviceType) : undefined;
  if (!opt && serviceType) opt = opts.find((o) => o.id === serviceType);
  if (!opt) opt = allPackages.find((o) => o.name === display);
  if (opt?.confirmationSummary?.length) return opt.confirmationSummary;
  if (opt?.bulletPoints?.length) return opt.bulletPoints.slice(0, 8);
  return [getServiceDescription(display)];
}

type BookingRow = {
  id: string;
  status: string;
  service_type: string | null;
  service_name: string | null;
  location_lat: number | null;
  location_lng: number | null;
  location_address: string | null;
  valeter_id: string | null;
  price?: number | null;
  add_ons_total?: number | null;
  discount_amount?: number | null;
  wash_type?: string | null;
};

type ValeterInfo = {
  fullName: string;
  photoUrl: string | null;
  totalJobs: number;
  reviews: number;
  rating: number;
  experienceMonths: number;
  onTimePercentage: number;
};

function statusTitle(status: string): string {
  if (status === 'pending_valeter_acceptance') return 'Connecting to your pro';
  if (status === 'pending_payment') return 'Awaiting payment';
  if (status === 'scheduled') return 'Accepted';
  if (status === 'confirmed' || status === 'valeter_assigned') return 'Accepted';
  if (status === 'en_route') return 'On the way';
  if (status === 'arrived') return 'Arrived';
  if (status === 'in_progress') return 'In progress';
  if (status === 'completed') return 'Completed';
  return 'Tracking';
}

const TRACK_STEPS = [
  { key: 'confirmed', label: 'Accepted', icon: 'checkmark-circle-outline' as const },
  { key: 'en_route', label: 'On the way', icon: 'car-outline' as const },
  { key: 'arrived', label: 'Arrived', icon: 'location-outline' as const },
  { key: 'in_progress', label: 'Washing', icon: 'water-outline' as const },
  { key: 'completed', label: 'Done', icon: 'sparkles-outline' as const },
];

const RING_COLORS = ['#38BDF8', '#10B981', '#8B5CF6', '#F59E0B'];

function stageAccent(status: string): { color: string; icon: keyof typeof Ionicons.glyphMap } {
  if (status === 'pending_payment') return { color: '#C2410C', icon: 'wallet-outline' };
  if (status === 'scheduled' || status === 'confirmed' || status === 'valeter_assigned')
    return { color: '#8B5CF6', icon: 'checkmark-circle-outline' };
  if (status === 'en_route') return { color: '#38BDF8', icon: 'car-outline' };
  if (status === 'arrived') return { color: '#F59E0B', icon: 'navigate-circle-outline' };
  if (status === 'in_progress') return { color: '#10B981', icon: 'water-outline' };
  if (status === 'completed') return { color: '#10B981', icon: 'sparkles-outline' };
  return { color: '#38BDF8', icon: 'person-circle-outline' };
}

const TRACKING_PAGE_SHEET_SCALE = 0.88;

export default function BookingTrackingRedesigned() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const bookingId = bookingIdFromSearchParams(params as { bookingId?: string | string[] });
  const [booking, setBooking] = useState<BookingRow | null>(null);
  const [valeterLoc, setValeterLoc] = useState<{ latitude: number; longitude: number } | null>(null);
  const [loading, setLoading] = useState(true);
  const [ringColorIndex, setRingColorIndex] = useState(0);
  const [showWasherSheet, setShowWasherSheet] = useState(false);
  const [washerLoading, setWasherLoading] = useState(false);
  const [washerInfo, setWasherInfo] = useState<ValeterInfo | null>(null);
  const [cancelling, setCancelling] = useState(false);
  const [valeterName, setValeterName] = useState<string>('Washer');
  const [secondsLeft, setSecondsLeft] = useState(10 * 60);
  const [openingChat, setOpeningChat] = useState(false);
  const [showPaymentSheet, setShowPaymentSheet] = useState(false);
  const stepPulse = useRef(new Animated.Value(0)).current;
  const stageGlow = useRef(new Animated.Value(0)).current;
  const ctaPulse = useRef(new Animated.Value(0)).current;
  const hasAutoCancelledRef = useRef(false);
  /** Ensures we only auto-navigate to rate & tip once when the job completes. */
  const hasNavigatedToCompletionRef = useRef(false);
  /** 2s Done-stage delay before opening the rating screen. */
  const completionNavTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  /** True while the delayed navigation is scheduled but has not run yet. */
  const completionNavScheduledRef = useRef(false);

  const loadBooking = useCallback(async () => {
    if (!bookingId) return;
    let q = supabase.from('bookings').select('*').eq('id', bookingId);
    if (user?.id) {
      q = q.eq('user_id', user.id);
    }
    const { data, error } = await q.maybeSingle();
    if (error) {
      if (__DEV__) console.warn('[tracking] loadBooking', error.message);
      setBooking(null);
      setLoading(false);
      return;
    }
    const row = normalizeBookingRow(data as Record<string, unknown>);
    if (!row || !row.id) {
      setBooking(null);
      setLoading(false);
      return;
    }
    setBooking(row);
    if (row.valeter_id) {
      const { data: profileData } = await supabase
        .from('profiles')
        .select('full_name')
        .eq('id', row.valeter_id)
        .maybeSingle();
      setValeterName((profileData as { full_name?: string | null } | null)?.full_name || 'Washer');
      const { data: p } = await supabase
        .from('valeter_presence')
        .select('last_lat,last_lng')
        .eq('user_id', row.valeter_id)
        .maybeSingle();
      if (p?.last_lat != null && p?.last_lng != null) {
        setValeterLoc({ latitude: Number(p.last_lat), longitude: Number(p.last_lng) });
      } else {
        setValeterLoc(null);
      }
    } else {
      setValeterName('Washer');
      setValeterLoc(null);
    }
    setLoading(false);
  }, [bookingId, user?.id]);

  useEffect(() => {
    if (!bookingId) {
      router.replace('/owner/owner-dashboard' as any);
      return;
    }
    void loadBooking();
    const timer = setInterval(() => {
      void loadBooking();
    }, 15000);
    return () => clearInterval(timer);
  }, [bookingId, loadBooking]);

  useEffect(() => {
    if (!bookingId) return;
    const channel = supabase
      .channel(`tracking-booking-${bookingId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'bookings',
          filter: `id=eq.${bookingId}`,
        },
        () => {
          void loadBooking();
        },
      )
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [bookingId, loadBooking]);

  useEffect(() => {
    hasNavigatedToCompletionRef.current = false;
    if (completionNavTimerRef.current) {
      clearTimeout(completionNavTimerRef.current);
      completionNavTimerRef.current = null;
    }
    completionNavScheduledRef.current = false;
  }, [bookingId]);

  const bookingStatus = booking?.status;
  const bookingIdRef = useRef(bookingId);
  bookingIdRef.current = bookingId;

  useEffect(() => {
    if (!bookingId || loading) return;
    if (bookingStatus !== 'completed') return;
    if (hasNavigatedToCompletionRef.current) return;

    if (completionNavTimerRef.current) {
      clearTimeout(completionNavTimerRef.current);
      completionNavTimerRef.current = null;
    }

    completionNavScheduledRef.current = true;
    completionNavTimerRef.current = setTimeout(() => {
      completionNavTimerRef.current = null;
      completionNavScheduledRef.current = false;
      hasNavigatedToCompletionRef.current = true;
      void hapticFeedback('success');
      router.replace({
        pathname: '/owner/booking/completion',
        params: { bookingId, celebrated: '1' },
      } as any);
    }, 2000);

    return () => {
      if (completionNavTimerRef.current) {
        clearTimeout(completionNavTimerRef.current);
        completionNavTimerRef.current = null;
      }
      completionNavScheduledRef.current = false;
    };
  }, [bookingStatus, bookingId, loading]);

  useEffect(() => {
    return () => {
      if (completionNavScheduledRef.current) {
        void setPendingRatingBookingId(bookingIdRef.current);
      }
      if (completionNavTimerRef.current) {
        clearTimeout(completionNavTimerRef.current);
        completionNavTimerRef.current = null;
      }
      completionNavScheduledRef.current = false;
    };
  }, []);

  useEffect(() => {
    const vid = booking?.valeter_id;
    if (!vid) return;
    const channel = supabase
      .channel(`tracking-presence-${vid}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'valeter_presence',
          filter: `user_id=eq.${vid}`,
        },
        (payload) => {
          const n = payload.new as { last_lat?: number; last_lng?: number };
          if (n?.last_lat != null && n?.last_lng != null) {
            setValeterLoc({ latitude: Number(n.last_lat), longitude: Number(n.last_lng) });
          }
        },
      )
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [booking?.valeter_id]);

  const loadWasherInfo = useCallback(async () => {
    const valeterId = booking?.valeter_id;
    if (!valeterId) {
      setWasherInfo(null);
      return;
    }
    setWasherLoading(true);
    try {
      const [profileRes, fallbackRes, stats] = await Promise.all([
        supabase
          .from('valeter_profiles')
          .select('full_name, profile_photo_url')
          .eq('user_id', valeterId)
          .maybeSingle(),
        supabase
          .from('profiles')
          .select('full_name, profile_picture')
          .eq('id', valeterId)
          .maybeSingle(),
        ValeterStatsService.getValeterStats(valeterId),
      ]);
      const profile = profileRes.data as { full_name?: string | null; profile_photo_url?: string | null } | null;
      const fallback = fallbackRes.data as { full_name?: string | null; profile_picture?: string | null } | null;
      setWasherInfo({
        fullName: profile?.full_name || fallback?.full_name || valeterName || 'Washer',
        photoUrl: profile?.profile_photo_url || fallback?.profile_picture || null,
        totalJobs: stats.totalJobs || 0,
        reviews: stats.customerReviews || 0,
        rating: stats.averageRating || 0,
        experienceMonths: stats.experienceMonths || 1,
        onTimePercentage: stats.onTimePercentage || 0,
      });
    } catch {
      setWasherInfo({
        fullName: valeterName || 'Washer',
        photoUrl: null,
        totalJobs: 0,
        reviews: 0,
        rating: 0,
        experienceMonths: 1,
        onTimePercentage: 0,
      });
    } finally {
      setWasherLoading(false);
    }
  }, [booking?.valeter_id, valeterName]);

  const cancelBooking = useCallback(async () => {
    if (!booking?.id || cancelling) return;
    const uid = user?.id;
    if (!uid) {
      Alert.alert('Sign in required', 'Please sign in again to cancel this booking.');
      return;
    }
    setCancelling(true);
    try {
      const { data: updatedRow, error } = await supabase
        .from('bookings')
        .update({
          status: 'cancelled',
          cancelled_at: new Date().toISOString(),
          cancelled_by: 'customer',
          cancellation_reason: 'Cancelled by customer from tracking',
        })
        .eq('id', booking.id)
        .eq('user_id', uid)
        .select('id')
        .maybeSingle();
      if (error) throw error;
      if (!updatedRow) {
        Alert.alert(
          'Could not cancel',
          'Your account may not own this booking, or it was already updated. Pull to refresh or open the booking from My washes.',
        );
        return;
      }
      await removeBookingFromDeviceCalendar(booking.id);
      router.replace('/owner/owner-dashboard' as any);
    } catch (e: unknown) {
      const msg = e && typeof e === 'object' && 'message' in e ? String((e as { message?: string }).message) : '';
      Alert.alert(
        'Could not cancel',
        msg
          ? `${msg}\n\nIf this keeps happening, check that you own this booking and it can still be cancelled.`
          : 'Please try again in a moment.',
      );
    } finally {
      setCancelling(false);
    }
  }, [booking?.id, cancelling, user?.id]);

  const autoCancelBookingOnTimeout = useCallback(async () => {
    if (!booking?.id) return;
    try {
      const { error } = await supabase
        .from('bookings')
        .update({
          status: 'cancelled',
          cancelled_at: new Date().toISOString(),
          cancelled_by: 'system',
          cancellation_reason: 'No valeter accepted within 10 minutes',
        })
        .eq('id', booking.id);
      if (error) throw error;
      await removeBookingFromDeviceCalendar(booking.id);
      Alert.alert('Booking timed out', 'No pro accepted in time, so this booking was cancelled.');
      router.replace('/owner/owner-dashboard' as any);
    } catch {
      Alert.alert('Could not auto-cancel', 'Please try again in a moment.');
    }
  }, [booking?.id]);

  useEffect(() => {
    const pulseLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(stepPulse, {
          toValue: 1,
          duration: 620,
          easing: Easing.inOut(Easing.quad),
          useNativeDriver: true,
        }),
        Animated.timing(stepPulse, {
          toValue: 0,
          duration: 620,
          easing: Easing.inOut(Easing.quad),
          useNativeDriver: true,
        }),
      ]),
    );
    pulseLoop.start();
    return () => {
      pulseLoop.stop();
    };
  }, [stepPulse]);

  useEffect(() => {
    // Stage transition flash on card whenever status or payment state changes.
    stageGlow.setValue(0);
    Animated.sequence([
      Animated.timing(stageGlow, { toValue: 1, duration: 260, useNativeDriver: true }),
      Animated.timing(stageGlow, { toValue: 0, duration: 520, useNativeDriver: true }),
    ]).start();
  }, [booking?.status, stageGlow]);

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(ctaPulse, { toValue: 1, duration: 900, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
        Animated.timing(ctaPulse, { toValue: 0, duration: 900, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [ctaPulse]);

  useEffect(() => {
    const colorTimer = setInterval(() => {
      setRingColorIndex((prev) => (prev + 1) % RING_COLORS.length);
    }, 1400);
    return () => clearInterval(colorTimer);
  }, []);

  useEffect(() => {
    if ((booking?.status || '') !== 'pending_valeter_acceptance') {
      hasAutoCancelledRef.current = false;
      setSecondsLeft(10 * 60);
      return;
    }
    const id = setInterval(() => {
      setSecondsLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(id);
  }, [booking?.status]);

  useEffect(() => {
    if ((booking?.status || '') !== 'pending_valeter_acceptance') return;
    if (secondsLeft > 0) return;
    if (hasAutoCancelledRef.current) return;
    hasAutoCancelledRef.current = true;
    void autoCancelBookingOnTimeout();
  }, [secondsLeft, booking?.status, autoCancelBookingOnTimeout]);

  const isDetailingJob = useMemo(
    () => isCustomerDetailingService(booking?.service_type, booking?.service_name),
    [booking?.service_type, booking?.service_name],
  );
  const stages = useMemo(
    () => getStages((booking?.status as any) || 'pending_valeter_acceptance', isDetailingJob, false),
    [booking?.status, isDetailingJob],
  );
  const stageProgressPercent = useMemo(
    () => getStageProgressPercent((booking?.status as any) || 'pending_valeter_acceptance', isDetailingJob, false),
    [booking?.status, isDetailingJob],
  );
  const statusRingColor = useMemo(
    () => getRingColorForStep((booking?.status as any) || 'pending_valeter_acceptance') || SKY,
    [booking?.status],
  );
  const activeRingColor = RING_COLORS[ringColorIndex] ?? SKY;
  const currentStepScale = stepPulse.interpolate({
    inputRange: [0, 1],
    outputRange: [1, 1.1],
  });
  const currentStepOpacity = stepPulse.interpolate({
    inputRange: [0, 1],
    outputRange: [0.92, 1],
  });
  const paymentCompleted = (booking?.status || '') !== 'pending_payment';
  const primarySheetAction = useMemo(() => {
    const s = booking?.status || '';
    if (s === 'pending_payment') {
      return {
        kind: 'pay' as const,
        label: 'Pay now',
        icon: 'wallet-outline' as keyof typeof Ionicons.glyphMap,
        accent: '#EA580C',
      };
    }
    return {
      kind: 'details' as const,
      label: 'Booking details',
      icon: 'car-outline' as keyof typeof Ionicons.glyphMap,
      accent: SKY,
    };
  }, [booking?.status]);
  const stageCta = stageAccent(booking?.status || '');
  const ctaScale = ctaPulse.interpolate({ inputRange: [0, 1], outputRange: [1, 1.01] });
  const ctaGlowOpacity = ctaPulse.interpolate({ inputRange: [0, 1], outputRange: [0.2, 0.5] });
  const stageGlowOpacity = stageGlow.interpolate({ inputRange: [0, 1], outputRange: [0.02, 0.38] });
  const timerLabel = useMemo(() => {
    const mins = Math.floor(secondsLeft / 60);
    const secs = secondsLeft % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }, [secondsLeft]);
  const timerAccent = useMemo(() => {
    if (secondsLeft <= 60) return '#EF4444';
    if (secondsLeft <= 180) return '#C2410C';
    return SKY;
  }, [secondsLeft]);
  const timerHint = useMemo(() => {
    if (secondsLeft <= 60) return 'Final minute to match';
    if (secondsLeft <= 180) return 'Matching soon';
    return 'Connecting to your pro';
  }, [secondsLeft]);
  const bookingServiceDisplay = useMemo(
    () => getServiceDisplayName(booking?.service_type, booking?.service_name),
    [booking?.service_type, booking?.service_name],
  );
  const serviceSummaryLines = useMemo(
    () => getServiceSummaryLines(booking?.service_type ?? null, booking?.service_name ?? null),
    [booking?.service_type, booking?.service_name],
  );
  const currentStatusTitle = statusTitle(booking?.status || 'tracking');
  const currentStatusMessage = getStatusMessage(
    (booking?.status as any) || 'pending_valeter_acceptance',
    null,
    isDetailingJob,
  );

  /** Full-screen stage loops (Accepted → En route → Arrived → Washing → Done). See `app/assets/assetExports`. */
  const trackingStageVideoSource = useMemo(() => {
    const s = normalizeStatusForTracking(String(booking?.status ?? ''));
    if (s === 'pending_valeter_acceptance') return CONNECTING_STAGE_VIDEO;
    if (s === 'confirmed' || s === 'valeter_assigned') return BOOKING_FLOW_VIDEO;
    if (s === 'en_route') return ENROUTE_STAGE_VIDEO;
    if (s === 'arrived') return ARRIVED_STAGE_VIDEO;
    if (s === 'in_progress') return WASHING_STAGE_VIDEO;
    if (s === 'completed') return DONE_STAGE_VIDEO;
    return null;
  }, [booking?.status]);

  const showStatusSubtext =
    currentStatusMessage.trim().toLowerCase() !== currentStatusTitle.trim().toLowerCase();

  const cardInner = (
    <Animated.View
      style={[
        styles.gamifiedCardWrap,
        styles.gamifiedCardLower,
        { borderColor: activeRingColor + '8A', shadowColor: activeRingColor },
      ]}
    >
      <Animated.View
        pointerEvents="none"
        style={[
          StyleSheet.absoluteFillObject,
          styles.gamifiedStageOverlay,
          { backgroundColor: activeRingColor, opacity: stageGlowOpacity },
        ]}
      />
      <View style={trackingInnerLayoutStyles.row}>
        <View style={trackingInnerLayoutStyles.body}>
          <Text style={trackingInnerLayoutStyles.kicker}>{bookingServiceDisplay}</Text>
          <Text style={[trackingInnerLayoutStyles.status, { color: activeRingColor }]}>
            {currentStatusTitle}
          </Text>
          {showStatusSubtext ? (
            <Text style={styles.statusSubtext} numberOfLines={2}>
              {currentStatusMessage}
            </Text>
          ) : null}
        </View>
        <View
          style={[
            trackingInnerLayoutStyles.ringWrap,
            { borderColor: activeRingColor + '90', backgroundColor: activeRingColor + '18' },
          ]}
        >
          <AnimatedProgress
            progress={getStatusProgress((booking?.status as any) || 'pending_valeter_acceptance')}
            size={70}
            strokeWidth={6}
            showPercentage
            percentageFontSize={12}
            color={statusRingColor}
            spin
            colorCycle={RING_COLORS}
          />
        </View>
      </View>
      <View style={styles.cardProgressStrip}>
        <View style={styles.cardProgressTrack}>
          <View style={[styles.cardProgressFill, { width: `${stageProgressPercent}%`, backgroundColor: activeRingColor }]} />
        </View>
        <View style={styles.stepTrack}>
        {stages.map((step) => {
          const done = step.done;
          const current = step.current;
          const fallback = TRACK_STEPS.find((s) => s.label.toLowerCase() === String(step.label).toLowerCase());
          const iconName = fallback?.icon || 'ellipse-outline';
          return (
            <View key={step.label} style={styles.stepItem}>
              <Animated.View
                style={[
                  styles.stepDot,
                  done && styles.stepDotDone,
                  current && styles.stepDotCurrent,
                  current && {
                    borderColor: activeRingColor,
                    shadowColor: activeRingColor,
                    transform: [{ scale: currentStepScale }],
                    opacity: currentStepOpacity,
                  },
                ]}
              >
                <Ionicons
                  name={iconName}
                  size={12}
                  color={done ? '#FFFFFF' : current ? activeRingColor : 'rgba(148,163,184,0.85)'}
                />
              </Animated.View>
              <Text style={[styles.stepLabel, current && styles.stepLabelCurrent, current && { color: activeRingColor }]} numberOfLines={2}>
                {step.label}
              </Text>
            </View>
          );
        })}
        </View>
      </View>
    </Animated.View>
  );

  const actionRow = (
    <View style={[customerMapTrackingSheetActionStyles.bookingInfoRow, styles.actionRowLower]}>
      <TouchableOpacity
        style={[styles.trackActionIconBtn, styles.trackActionIconBtnCancel]}
        onPress={() => {
          void hapticFeedback('light');
          Alert.alert(
            'Cancel booking?',
            'This will cancel your active booking.',
            [
              { text: 'Keep booking', style: 'cancel' },
              { text: 'Cancel booking', style: 'destructive', onPress: () => { void cancelBooking(); } },
            ],
          );
        }}
        activeOpacity={0.85}
      >
        <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
        <LinearGradient
          colors={['rgba(239,68,68,0.34)', 'rgba(15,23,42,0.65)']}
          start={{ x: 0, y: 0 }}
          end={{ x: 0, y: 1 }}
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
        />
        {cancelling ? (
          <ActivityIndicator size="small" color="#EF4444" />
        ) : (
          <Ionicons name="close" size={18} color="#EF4444" style={{ zIndex: 1 }} />
        )}
      </TouchableOpacity>
      <Animated.View style={[styles.bookingDetailsCtaWrap, { transform: [{ scale: ctaScale }] }]}>
        <TouchableOpacity
          style={[
            customerMapTrackingSheetActionStyles.bookingInfoActionCard,
            customerMapTrackingSheetActionStyles.bookingInfoCard,
            styles.bookingDetailsBtn,
            { borderColor: primarySheetAction.accent + '8A' },
          ]}
          onPress={() => {
            void hapticFeedback('light');
            if (primarySheetAction.kind === 'pay') {
              if (!bookingId) return;
              setShowPaymentSheet(true);
              return;
            }
            setShowWasherSheet(true);
            void loadWasherInfo();
          }}
          activeOpacity={0.85}
        >
          <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
          <LinearGradient
            colors={[primarySheetAction.accent + '59', 'rgba(15,23,42,0.65)']}
            start={{ x: 0, y: 0 }}
            end={{ x: 0, y: 1 }}
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
          />
          <Animated.View
            pointerEvents="none"
            style={[StyleSheet.absoluteFillObject, { opacity: ctaGlowOpacity, backgroundColor: primarySheetAction.accent + '45' }]}
          />
          <Ionicons name={primarySheetAction.icon} size={20} color={primarySheetAction.accent} style={{ zIndex: 1 }} />
          <View style={customerMapTrackingSheetActionStyles.bookingInfoCardTextWrap}>
            <Text
              style={[
                customerMapTrackingSheetActionStyles.bookingInfoCardText,
                styles.bookingDetailsTextFix,
                { color: primarySheetAction.accent },
              ]}
            >
              {primarySheetAction.label}
            </Text>
          </View>
        </TouchableOpacity>
      </Animated.View>
      <TouchableOpacity
        style={[styles.trackActionIconBtn, !paymentCompleted && styles.trackActionIconBtnDisabled]}
        onPress={() => {
          if (!paymentCompleted || !bookingId) return;
          void hapticFeedback('light');
          router.push({ pathname: '/owner/booking/chat', params: { bookingId } } as any);
        }}
        activeOpacity={0.85}
      >
        <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
        <LinearGradient
          colors={[
            paymentCompleted ? 'rgba(56,189,248,0.34)' : 'rgba(148,163,184,0.24)',
            'rgba(15,23,42,0.65)',
          ]}
          start={{ x: 0, y: 0 }}
          end={{ x: 0, y: 1 }}
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
        />
        <Ionicons
          name="chatbubble-ellipses-outline"
          size={18}
          color={paymentCompleted ? SKY : 'rgba(148,163,184,0.85)'}
          style={{ zIndex: 1 }}
        />
      </TouchableOpacity>
    </View>
  );

  const stageVideoKey = normalizeStatusForTracking(String(booking?.status ?? ''));

  return (
    <View style={styles.container}>
      <View style={StyleSheet.absoluteFill}>
        {trackingStageVideoSource ? (
          <Video
            key={stageVideoKey}
            source={trackingStageVideoSource}
            style={StyleSheet.absoluteFill}
            resizeMode={ResizeMode.COVER}
            shouldPlay
            isLooping
            isMuted
          />
        ) : (
          <LinearGradient
            colors={['#0c1929', '#020617', '#0f172a']}
            start={{ x: 0.5, y: 0 }}
            end={{ x: 0.5, y: 1 }}
            style={StyleSheet.absoluteFill}
          />
        )}
      </View>
      <AppHeader
        title="Live tracking"
        subtitle={currentStatusTitle}
        showBack
        onBack={() => router.back()}
        primaryColor={SKY}
      />
      {(booking?.status || '') === 'pending_valeter_acceptance' ? (
        <View
          pointerEvents="none"
          style={[styles.topTimerWrap, { top: trackingMapTopPad(insets.top) + 4 }]}
        >
          <Animated.View style={{ transform: [{ scale: ctaScale }] }}>
          <View style={[styles.topTimerPill, { borderColor: timerAccent + '88', shadowColor: timerAccent }]}>
            <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
            <LinearGradient
              colors={[timerAccent + '40', 'rgba(2,6,23,0.88)']}
              start={{ x: 0, y: 0 }}
              end={{ x: 0, y: 1 }}
              style={StyleSheet.absoluteFill}
              pointerEvents="none"
            />
            <Animated.View pointerEvents="none" style={[StyleSheet.absoluteFillObject, { opacity: ctaGlowOpacity, backgroundColor: timerAccent + '2A' }]} />
            <View style={styles.topTimerInner}>
              <Ionicons name="time-outline" size={16} color={timerAccent} />
              <Text style={[styles.topTimerText, { color: timerAccent }]}>{timerLabel}</Text>
              <View style={[styles.topTimerDot, { backgroundColor: timerAccent }]} />
            </View>
            <Text style={styles.topTimerHint}>{timerHint}</Text>
          </View>
          </Animated.View>
        </View>
      ) : null}
      <CustomerMapTrackingSheetShell
        accentColor={SKY}
        showInfoButton={false}
        showChatButton={false}
        onDragDismiss={() => router.back()}
        bottomOffset={0}
        sheetHeightScale={TRACKING_PAGE_SHEET_SCALE}
        cardInner={cardInner}
        actionRow={actionRow}
        panelFooter={null}
      />
      <BookingPaymentSheet
        visible={showPaymentSheet}
        bookingId={bookingId}
        onClose={() => setShowPaymentSheet(false)}
        onPaid={() => {
          setShowPaymentSheet(false);
          void loadBooking();
        }}
      />
      <Modal visible={showWasherSheet} transparent animationType="fade" onRequestClose={() => setShowWasherSheet(false)}>
        <Pressable style={styles.washerSheetBackdrop} onPress={() => setShowWasherSheet(false)}>
          <Pressable style={styles.washerSheetWrap} onPress={(e) => e.stopPropagation()}>
            <BlurView intensity={24} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
            <LinearGradient
              colors={HEADER_STYLE_CARD_GRADIENT}
              start={{ x: 0, y: 0 }}
              end={{ x: 0, y: 1 }}
              style={StyleSheet.absoluteFill}
              pointerEvents="none"
            />
            <LinearGradient
              colors={['rgba(255,255,255,0.16)', 'rgba(255,255,255,0.02)', 'transparent']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.washerSheetSheen}
              pointerEvents="none"
            />
            <View style={styles.washerHandle} />
            {washerLoading ? (
              <View style={styles.washerLoadingWrap}>
                <ActivityIndicator size="small" color={SKY} />
                <Text style={styles.washerLoadingText}>Loading washer info...</Text>
              </View>
            ) : (
              <ScrollView contentContainerStyle={styles.washerSheetContent} showsVerticalScrollIndicator={false}>
                <View style={styles.washerSheetHeaderRow}>
                  <View style={{ flex: 1 }} />
                  <TouchableOpacity onPress={() => setShowWasherSheet(false)} activeOpacity={0.8}>
                    <Ionicons name="close" size={22} color="rgba(226,232,240,0.9)" />
                  </TouchableOpacity>
                </View>
                <View style={styles.washerProfileTop}>
                  {washerInfo?.photoUrl ? (
                    <Image source={{ uri: washerInfo.photoUrl }} style={styles.washerAvatar} />
                  ) : (
                    <View style={styles.washerAvatarFallback}>
                      <Ionicons name="person" size={30} color={SKY} />
                    </View>
                  )}
                  <View style={styles.washerHeaderText}>
                    <Text style={styles.washerName}>{washerInfo?.fullName || 'Washer'}</Text>
                    <Text style={styles.washerSub}>Mobile valeter</Text>
                    <Text style={styles.washerEta}>Arriving in 1 minute</Text>
                  </View>
                </View>
                <View style={styles.verifyList}>
                  <Text style={styles.verifyLine}>✓ Verified Wish-a-Wash Pro</Text>
                  <Text style={styles.verifyLine}>✓ Fully insured</Text>
                  <Text style={styles.verifyLine}>✓ Background checked</Text>
                </View>
                <TouchableOpacity
                  style={styles.sheetMessageBtn}
                  onPress={() => {
                    if (!bookingId || openingChat) return;
                    setOpeningChat(true);
                    router.push({ pathname: '/owner/booking/chat', params: { bookingId } } as any);
                    setTimeout(() => setOpeningChat(false), 900);
                  }}
                  activeOpacity={openingChat ? 1 : 0.85}
                >
                  <Ionicons name="chatbubble-ellipses-outline" size={18} color="#F8FAFC" />
                  <Text style={styles.sheetMessageBtnText}>{openingChat ? 'Opening...' : 'Message'}</Text>
                </TouchableOpacity>
                <Text style={styles.sectionLabel}>Wash you&apos;re getting</Text>
                <Text style={styles.serviceMain}>{bookingServiceDisplay}</Text>
                {booking?.wash_type ? (
                  <Text style={styles.washTypeLine}>
                    Wash type:{' '}
                    {booking.wash_type === 'exterior'
                      ? 'Exterior'
                      : booking.wash_type === 'interior'
                        ? 'Interior'
                        : String(booking.wash_type)}
                  </Text>
                ) : null}
                <Text style={styles.priceMain}>£{moneyGBPOrDash(booking?.price)}</Text>
                {(Number(booking?.add_ons_total) || 0) > 0 ? (
                  <Text style={styles.addOnsLine}>Add-ons: £{moneyGBP(booking?.add_ons_total)}</Text>
                ) : null}
                {Number(booking?.discount_amount) > 0 ? (
                  <Text style={styles.discountLine}>Discount: -£{moneyGBP(booking?.discount_amount)}</Text>
                ) : null}
                <Text style={styles.sectionLabel}>What&apos;s included</Text>
                {serviceSummaryLines.map((item, idx) => (
                  <Text key={`${idx}-${item.slice(0, 24)}`} style={styles.includedRow}>
                    • {item}
                  </Text>
                ))}
                <Text style={[styles.sectionLabel, { marginTop: 14 }]}>Location</Text>
                <Text style={styles.locationLine}>
                  {booking?.location_address || 'Address will appear here once the booking location is saved.'}
                </Text>
                <TouchableOpacity
                  style={styles.washerCancelInModalBtn}
                  onPress={() => {
                    void hapticFeedback('light');
                    setShowWasherSheet(false);
                    Alert.alert(
                      'Cancel booking?',
                      'This will cancel your active booking.',
                      [
                        { text: 'Keep booking', style: 'cancel' },
                        { text: 'Cancel booking', style: 'destructive', onPress: () => { void cancelBooking(); } },
                      ],
                    );
                  }}
                  activeOpacity={0.85}
                >
                  <Text style={styles.washerCancelInModalText}>Cancel booking</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.washerCloseBtn}
                  onPress={() => setShowWasherSheet(false)}
                  activeOpacity={0.85}
                >
                  <Text style={styles.washerCloseBtnText}>Close</Text>
                </TouchableOpacity>
              </ScrollView>
            )}
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  topTimerWrap: {
    position: 'absolute',
    alignSelf: 'center',
    zIndex: 30,
  },
  topTimerPill: {
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.42)',
    overflow: 'hidden',
    minWidth: 188,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.26,
    shadowRadius: 12,
    elevation: 6,
  },
  topTimerInner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingTop: 10,
    paddingBottom: 4,
    paddingHorizontal: 18,
  },
  topTimerText: {
    color: SKY,
    fontSize: 15,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  topTimerDot: {
    width: 6,
    height: 6,
    borderRadius: 999,
  },
  topTimerHint: {
    color: 'rgba(226,232,240,0.88)',
    fontSize: 11,
    fontWeight: '700',
    textAlign: 'center',
    paddingBottom: 10,
    paddingHorizontal: 12,
  },
  gamifiedCardWrap: {
    borderRadius: 24,
    overflow: 'hidden',
    borderWidth: 0,
    shadowOpacity: 0.28,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 0 },
    elevation: 8,
  },
  gamifiedCardLower: {
    marginTop: 0,
  },
  gamifiedStageOverlay: {
    borderRadius: 24,
  },
  marker: { width: 40, height: 40 },
  statusSubtext: {
    marginTop: 2,
    color: 'rgba(226,232,240,0.92)',
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 17,
  },
  stepTrack: {
    marginTop: 5,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 3,
  },
  cardProgressStrip: {
    borderTopWidth: 0,
    paddingTop: 5,
    marginTop: 8,
    paddingHorizontal: 3,
    paddingBottom: 4,
  },
  trackActionIconBtn: {
    width: 46,
    height: 46,
    borderRadius: 24,
    borderWidth: 1,
    borderColor: SKY + '8A',
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 8,
  },
  trackActionIconBtnCancel: {
    borderColor: 'rgba(239,68,68,0.6)',
  },
  trackActionIconBtnDisabled: {
    borderColor: 'rgba(148,163,184,0.5)',
  },
  bookingDetailsCtaWrap: {
    flex: 1,
  },
  actionRowLower: {
    marginTop: 6,
    paddingBottom: 0,
  },
  bookingDetailsBtn: {
    borderColor: 'rgba(56,189,248,0.55)',
    borderRadius: 24,
    minHeight: 52,
    paddingVertical: 12,
  },
  bookingDetailsTextFix: {
    lineHeight: 20,
    paddingBottom: 1,
    includeFontPadding: false,
  },
  cardProgressTrack: {
    height: 3,
    backgroundColor: 'rgba(148,163,184,0.25)',
    borderRadius: 1,
    overflow: 'hidden',
    marginBottom: 3,
  },
  cardProgressFill: {
    height: '100%',
    borderRadius: 1,
  },
  stepItem: {
    flex: 1,
    alignItems: 'center',
    minWidth: 0,
    paddingHorizontal: 1,
  },
  stepDot: {
    width: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 1,
    borderColor: 'rgba(100,116,139,0.45)',
    backgroundColor: 'rgba(30,41,59,0.55)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 3,
  },
  stepDotDone: {
    borderColor: SKY,
    backgroundColor: SKY,
  },
  stepDotCurrent: {
    borderColor: '#F59E0B',
    backgroundColor: 'rgba(245,158,11,0.2)',
    shadowOpacity: 0.48,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 0 },
    elevation: 6,
  },
  stepLabel: {
    color: 'rgba(148,163,184,0.96)',
    fontSize: 10.5,
    lineHeight: 12,
    fontWeight: '700',
    textAlign: 'center',
  },
  stepLabelCurrent: {
    color: '#F8FAFC',
  },
  footer: {
    marginTop: 12,
    alignItems: 'center',
    paddingBottom: 6,
  },
  footerText: {
    color: 'rgba(226,232,240,0.88)',
    fontSize: 12,
    fontWeight: '600',
  },
  washerSheetBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(2,6,23,0.36)',
    justifyContent: 'flex-end',
  },
  washerSheetWrap: {
    width: '100%',
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.3)',
    overflow: 'hidden',
    minHeight: '52%',
    maxHeight: '78%',
  },
  washerSheetSheen: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.95,
  },
  washerHandle: {
    width: 44,
    height: 5,
    borderRadius: 999,
    backgroundColor: 'rgba(226,232,240,0.35)',
    alignSelf: 'center',
    marginTop: 10,
    marginBottom: 8,
  },
  washerLoadingWrap: {
    paddingVertical: 34,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  washerLoadingText: {
    color: 'rgba(226,232,240,0.86)',
    fontSize: 13,
    fontWeight: '600',
  },
  washerSheetHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  washerSheetTitle: {
    color: '#F8FAFC',
    fontSize: 18,
    fontWeight: '800',
  },
  washerSheetContent: {
    paddingHorizontal: 18,
    paddingBottom: 20,
  },
  washerProfileTop: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 14,
    gap: 12,
  },
  washerAvatar: {
    width: 66,
    height: 66,
    borderRadius: 33,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.5)',
  },
  washerAvatarFallback: {
    width: 66,
    height: 66,
    borderRadius: 33,
    backgroundColor: 'rgba(56,189,248,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.35)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  washerHeaderText: {
    flex: 1,
  },
  washerName: {
    color: '#F8FAFC',
    fontSize: 19,
    fontWeight: '800',
  },
  washerSub: {
    color: 'rgba(148,163,184,0.92)',
    fontSize: 13,
    fontWeight: '600',
    marginTop: 2,
  },
  washerEta: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
    marginTop: 4,
  },
  verifyList: {
    gap: 6,
    marginBottom: 12,
  },
  verifyLine: {
    color: 'rgba(226,232,240,0.9)',
    fontSize: 14,
    fontWeight: '600',
  },
  sheetMessageBtn: {
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.35)',
    backgroundColor: 'rgba(255,255,255,0.04)',
    minHeight: 46,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    marginBottom: 14,
  },
  sheetMessageBtnText: {
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '700',
  },
  sectionLabel: {
    color: SKY,
    fontSize: 13,
    fontWeight: '800',
    marginBottom: 6,
    textTransform: 'uppercase',
    letterSpacing: 0.4,
  },
  serviceMain: {
    color: '#F8FAFC',
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 4,
  },
  washTypeLine: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 6,
  },
  addOnsLine: {
    color: 'rgba(226,232,240,0.9)',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
  },
  discountLine: {
    color: '#34D399',
    fontSize: 14,
    fontWeight: '700',
    marginBottom: 6,
  },
  priceMain: {
    color: '#F8FAFC',
    fontSize: 24,
    fontWeight: '800',
    marginBottom: 10,
  },
  includedRow: {
    color: 'rgba(226,232,240,0.9)',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 2,
  },
  locationLine: {
    color: 'rgba(226,232,240,0.9)',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 14,
  },
  washerStatGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    rowGap: 10,
    marginBottom: 12,
  },
  washerStatCard: {
    width: '48.5%',
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.35)',
    backgroundColor: 'rgba(255,255,255,0.04)',
    paddingHorizontal: 14,
    paddingVertical: 12,
    gap: 4,
  },
  washerStatValue: {
    color: '#F8FAFC',
    fontSize: 16,
    fontWeight: '800',
  },
  washerStatLabel: {
    color: 'rgba(148,163,184,0.9)',
    fontSize: 12,
    fontWeight: '600',
  },
  washerWideStat: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.35)',
    backgroundColor: 'rgba(255,255,255,0.04)',
    paddingHorizontal: 14,
    paddingVertical: 12,
    marginBottom: 14,
  },
  washerWideStatText: {
    color: 'rgba(226,232,240,0.93)',
    fontSize: 13,
    fontWeight: '600',
  },
  washerCancelInModalBtn: {
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'rgba(248,113,113,0.55)',
    backgroundColor: 'rgba(127,29,29,0.25)',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    marginBottom: 10,
  },
  washerCancelInModalText: {
    color: '#FECACA',
    fontSize: 14,
    fontWeight: '800',
  },
  washerCloseBtn: {
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.35)',
    backgroundColor: 'rgba(255,255,255,0.04)',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
  },
  washerCloseBtnText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '800',
  },
});
