import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Animated,
  Alert,
  ActivityIndicator,
  Modal,
  TextInput,
  Pressable,
  KeyboardAvoidingView,
  Platform,
  Dimensions,
  PanResponder,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import MapView, { Region, Marker, MapPressEvent, Circle } from 'react-native-maps';
import * as Location from 'expo-location';
import useLiveLocation from '../../../src/hooks/useLiveLocation';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import {
  serviceOptions,
  detailingServiceOptions,
  repairServiceOptions,
  REPAIR_PACKAGE_IDS,
  addOnOptions,
  ADD_ON_SECTION_TITLE,
  ADD_ON_SECTION_SUBTITLE,
  getAvailableAddOnIdsForService,
  LEGACY_ECO_SERVICE_ID_MAP,
} from '../../../src/constants/serviceOptions';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { BookingHeaderMapControlButton } from '../../../src/components/shared/BookingHeaderMapControlButton';
import { colors } from '../../../src/constants/colors';
import { customerTheme } from '../../../src/constants/customerTheme';
import {
  calculateDisplayPrice,
  getVehicleSize,
  mapServiceIdToWashId,
  FrontendPricingInput
} from '../../../src/pricing/pricingEngine';


import {
  BOOKING_CARD,
  HEADER_STYLE_CARD_GRADIENT,
  getIndexTrackingCardSnapInterval,
  getIndexTrackingCardWidth,
  PREMIUM_BOOKING_MAP_SHEET_GLASS,
} from '../../../src/constants/bookingCardTheme';
import IndexTrackingCardShell, { indexTrackingCardStyles as ix } from '../../../src/components/booking/IndexTrackingCardShell';
import ServiceTierSpongeIcon, { getServiceTierLeadIconName } from '../../../src/components/booking/ServiceTierSpongeIcon';
import BookingSheetPremiumLayers from '../../../src/components/booking/BookingSheetPremiumLayers';
import BookingBottomSheetOverlay from '../../../src/components/booking/BookingBottomSheetOverlay';
import { customerMapTrackingSheetActionStyles } from '../../../src/components/booking/CustomerMapTrackingSheetShell';
import { VehicleInfoOverlay } from '../../../src/components/booking/VehicleInfoOverlay';
import { fetchVehicleStats } from '../../../src/utils/vehicleStats';
import {
  DEFAULT_MAP_REGION,
  LOCATION_PICKER_MAP_STYLE,
  MAP_LOCKED_DARK,
  MAP_CAMERA_ANIMATION_DURATION,
} from '../../../src/constants/mapConstants';
import { MapMarkerCustomerVehicle } from '../../../src/components/maps/MapMarkerViews';
import { useAdaptiveLayout } from '../../../src/constants/adaptiveLayout';
import { useBookingFlowTheme } from '../../../src/contexts/BookingFlowThemeContext';

const SKY = colors.SKY;
const LOCATION_CARD_GREEN = colors.ECO_GREEN;
const DETAILING_YELLOW = colors.DETAILING_YELLOW;
const REPAIR_ACCENT = '#FB923C';
const LOCATION_PICKER_DELTA = 0.00045;

const SAVED_LOCATIONS_KEY = 'customer_saved_locations';
const BOOKING_DRAFT_KEY = 'booking_create_draft_v1';

type SavedLocationItem = {
  id: string;
  label: string;
  address: string;
  latitude: number;
  longitude: number;
};

/** Forward-geocode result row for address search (device geocoding via Expo, no Google API). */
type AddressGeocodeSuggestion = {
  id: string;
  description: string;
  latitude: number;
  longitude: number;
};

type Vehicle = {
  id: string;
  type?: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  is_default: boolean;
  size?: string;
  image_url?: string | null;
  photo?: string | null;
};


/** Strip color for service card side border: wash tiers, or yellow for all detailing services. */
function getServiceStripColor(serviceId: string, fallback: string): string {
  const id = serviceId.toLowerCase();
  const washKey = LEGACY_ECO_SERVICE_ID_MAP[id] ?? id;
  const washMap: Record<string, string> = {
    'bronze-wash': '#92400E',
    'silver-wash': '#C0C0C0',
    'gold-wash': '#EAB308',
    'platinum-wash': '#334155',
    'emerald-wash': '#22D3EE',
  };
  if (washMap[washKey]) return washMap[washKey];
  if (REPAIR_PACKAGE_IDS.includes(id)) return REPAIR_ACCENT;
  const detailingIds = ['ceramic-coating', 'machine-polishing', 'soft-top-restoration', 'mould-removal'];
  if (detailingIds.includes(id)) return DETAILING_YELLOW;
  return fallback;
}

type BookingStep = 'location' | 'vehicle' | 'service';

type ServiceMode = 'wash' | 'detailing' | 'repair';

function getBookingHeaderConfig(step: BookingStep): { title: string; subtitle: string; backStep: BookingStep | null } {
  switch (step) {
    case 'location':
      return { title: 'Set location', subtitle: 'Set where your washer will arrive', backStep: null };
    case 'vehicle':
      return { title: 'Choose your vehicle', subtitle: 'Swipe to compare your vehicles', backStep: null };
    default:
      return { title: 'Choose your package', subtitle: 'Swipe to compare packages', backStep: 'vehicle' };
  }
}

/** Short tier explainer on service cards (mobile wash tiers). */
function getWashPackageTagline(serviceId: string): string | null {
  const id = serviceId.toLowerCase();
  const tierId = LEGACY_ECO_SERVICE_ID_MAP[id] ?? id;
  const map: Record<string, string> = {
    'bronze-wash': 'Interior OR exterior',
    'silver-wash': 'Interior + Exterior',
    'gold-wash': 'Interior Deep Clean',
    'platinum-wash': 'Full Valet',
    'emerald-wash': 'Premium Full Detail',
    'headlight-restoration': 'Lens clarity restore',
    'scratch-removal': 'Light scratch & swirl care',
    'paint-chip-repair': 'Chip touch-in & protection',
    'trim-restoration': 'Faded plastic revived',
    'leather-repair': 'Scuffs, wear & small tears',
  };
  return map[tierId] ?? null;
}

// eslint-disable-next-line sonarjs/cognitive-complexity -- multi-step booking flow; logic split via getBookingHeaderConfig and step renderers
export default function BookingCreate() {
  const params = useLocalSearchParams<{
    serviceMode?: string;
    customerOffersWater?: string;
    customerOffersElectricity?: string;
    preferredValeterId?: string;
    latitude?: string;
    longitude?: string;
    address?: string;
    startAtVehicle?: string;
    openAddressOverlay?: string;
  }>();
  const offersWater = false;
  const offersElectricity = false;
  const [infoService, setInfoService] = useState<{ id?: string; name?: string; icon?: string; price?: number | string; desc?: string; bulletPoints?: string[]; descriptionTitle?: string } | null>(null);
  const [infoVehicle, setInfoVehicle] = useState<Vehicle | null>(null);
  const [vehicleStats, setVehicleStats] = useState<{ washCount: number; lastCleanedAt: string | null; cleanRating: number | null }>({ washCount: 0, lastCleanedAt: null, cleanRating: null });
  const [showAddressOverlay, setShowAddressOverlay] = useState(false);
  const [addressSearchInput, setAddressSearchInput] = useState('');
  const [addressSearching, setAddressSearching] = useState(false);
  const [addressSuggestions, setAddressSuggestions] = useState<AddressGeocodeSuggestion[]>([]);
  const [loadingSuggestions, setLoadingSuggestions] = useState(false);
  const [showInlineSuggestions, setShowInlineSuggestions] = useState(false);
  const suggestDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const suggestRequestRef = useRef(0);
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { setTheme } = useBookingFlowTheme();
  const [currentStep, setCurrentStep] = useState<BookingStep>('vehicle');
  const [selectedLocation, setSelectedLocation] = useState<{ latitude: number; longitude: number; address: string } | null>(null);
  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [selectedVehicle, setSelectedVehicle] = useState<string | null>(null);
  const [washType, setWashType] = useState<'exterior' | 'interior' | null>(null);
  const [serviceMode, setServiceMode] = useState<ServiceMode>(() => {
    const m = (params.serviceMode as string | undefined)?.toLowerCase();
    if (m === 'repair') return 'repair';
    if (m === 'detailing') return 'detailing';
    return 'wash';
  });
  const [selectedAddOns, setSelectedAddOns] = useState<string[]>([]);
  const [showAddOnsModal, setShowAddOnsModal] = useState(false);
  const [showBronzeWashTypeOverlay, setShowBronzeWashTypeOverlay] = useState(false);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const adaptive = useAdaptiveLayout();
  /** Same width math as `booking/index` (`SCREEN_W` → `getIndexTrackingCardWidth`). */
  const windowWidth = Dimensions.get('window').width;
  const trackingCardWidth = getIndexTrackingCardWidth(windowWidth);
  const trackingSnapInterval = getIndexTrackingCardSnapInterval(windowWidth);
  const locationVehicleCardWidth =
    Math.min(adaptive.contentMaxWidth, adaptive.width) - adaptive.horizontalPadding * 2;
  const { coords: liveCoords } = useLiveLocation();
  const [region, setRegion] = useState<Region | null>(null);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [savedLocations, setSavedLocations] = useState<SavedLocationItem[]>([]);

  const mapRef = useRef<MapView>(null);
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const stepSlideAnim = useRef(new Animated.Value(0)).current;
  const sheetDragY = useRef(new Animated.Value(0)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;
  const pickerGeocodeDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pickerGeocodeRequestRef = useRef(0);

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, { toValue: 1.2, duration: 1000, useNativeDriver: true }),
        Animated.timing(markerPulse, { toValue: 1, duration: 1000, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  useEffect(() => {
    loadVehicles();
  }, [user?.id]);

  useEffect(() => {
    setTheme(serviceMode === 'wash' ? 'wash' : 'detailing');
  }, [serviceMode, setTheme]);

  useEffect(() => {
    setSelectedService(null);
    setWashType(null);
    setSelectedAddOns([]);
    setShowBronzeWashTypeOverlay(false);
    setShowAddOnsModal(false);
  }, [serviceMode]);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(BOOKING_DRAFT_KEY);
        if (!raw || !active) return;
        const draft = JSON.parse(raw);
        Alert.alert(
          'Resume booking?',
          'You have an unfinished booking. Do you want to continue where you left off?',
          [
            {
              text: 'Start over',
              style: 'destructive',
              onPress: () => {
                void AsyncStorage.removeItem(BOOKING_DRAFT_KEY);
              },
            },
            {
              text: 'Resume',
              onPress: () => {
                if (!active) return;
                if (draft.currentStep) setCurrentStep(draft.currentStep);
                if (draft.selectedLocation) setSelectedLocation(draft.selectedLocation);
                if (draft.selectedService) setSelectedService(draft.selectedService);
                if (draft.selectedVehicle) setSelectedVehicle(draft.selectedVehicle);
                if (draft.serviceMode === 'wash' || draft.serviceMode === 'detailing' || draft.serviceMode === 'repair') {
                  setServiceMode(draft.serviceMode);
                }
                if (draft.washType) setWashType(draft.washType);
                if (Array.isArray(draft.selectedAddOns)) setSelectedAddOns(draft.selectedAddOns);
                if (typeof draft.addressSearchInput === 'string') setAddressSearchInput(draft.addressSearchInput);
                if (draft.region) setRegion(draft.region);
              },
            },
          ]
        );
      } catch {}
    })();
    return () => {
      active = false;
    };
  }, []);

  const saveBookingDraft = async () => {
    try {
      await AsyncStorage.setItem(
        BOOKING_DRAFT_KEY,
        JSON.stringify({
          currentStep,
          selectedLocation,
          selectedService,
          selectedVehicle,
          serviceMode,
          washType,
          selectedAddOns,
          addressSearchInput,
          region,
        })
      );
    } catch {}
  };

  const clearBookingDraft = async () => {
    try {
      await AsyncStorage.removeItem(BOOKING_DRAFT_KEY);
    } catch {}
  };

  const promptExitBookingFlow = () => {
    Alert.alert(
      'Exit booking?',
      'Would you like to resume this booking later or start over next time?',
      [
        {
          text: 'Cancel',
          style: 'cancel',
          onPress: () => {
            Animated.spring(sheetDragY, {
              toValue: 0,
              useNativeDriver: true,
              damping: 24,
              stiffness: 260,
            }).start();
          },
        },
        {
          text: 'Start over',
          style: 'destructive',
          onPress: () => {
            void clearBookingDraft();
            router.replace('/owner/owner-dashboard' as any);
          },
        },
        {
          text: 'Resume later',
          onPress: () => {
            void saveBookingDraft();
            router.replace('/owner/owner-dashboard' as any);
          },
        },
      ]
    );
  };

  const sheetPanResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: (_, g) => g.dy > 4 && Math.abs(g.dy) > Math.abs(g.dx),
      onPanResponderMove: (_, g) => {
        const y = Math.max(0, Math.min(g.dy, 220));
        sheetDragY.setValue(y);
      },
      onPanResponderRelease: (_, g) => {
        if (g.dy > 90) {
          Animated.timing(sheetDragY, { toValue: 120, duration: 140, useNativeDriver: true }).start(() => {
            promptExitBookingFlow();
          });
          return;
        }
        Animated.spring(sheetDragY, {
          toValue: 0,
          useNativeDriver: true,
          damping: 24,
          stiffness: 260,
        }).start();
      },
    })
  ).current;

  useEffect(() => {
    const lat = params.latitude ? Number(params.latitude) : NaN;
    const lng = params.longitude ? Number(params.longitude) : NaN;
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) return;
    const addr = (params.address as string) || 'Selected Location';
    const coords = { latitude: lat, longitude: lng };
    setSelectedLocation({ ...coords, address: addr });
    setRegion({ ...coords, latitudeDelta: LOCATION_PICKER_DELTA, longitudeDelta: LOCATION_PICKER_DELTA });
    setCurrentStep('vehicle');
    if (params.openAddressOverlay === 'true') {
      setShowAddressOverlay(false);
      setShowInlineSuggestions(true);
    }
  }, [params.latitude, params.longitude, params.address, params.startAtVehicle, params.openAddressOverlay]);

  useEffect(() => {
    stepSlideAnim.setValue(24);
    Animated.timing(stepSlideAnim, {
      toValue: 0,
      duration: 320,
      useNativeDriver: true,
    }).start();
  }, [currentStep]);

  // Get user location and use it as default for the location box (current location = default unless user changes it)
  useEffect(() => {
    const applyCoords = (coords: { latitude: number; longitude: number }) => {
      setUserLocation(coords);
      setRegion({
        latitude: coords.latitude,
        longitude: coords.longitude,
        latitudeDelta: LOCATION_PICKER_DELTA,
        longitudeDelta: LOCATION_PICKER_DELTA,
      });
    };

    if (liveCoords) {
      applyCoords({ latitude: liveCoords.latitude, longitude: liveCoords.longitude });
    } else {
      (async () => {
        try {
          const { status } = await Location.requestForegroundPermissionsAsync();
          if (status !== 'granted') return;
          const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
          const coords = { latitude: location.coords.latitude, longitude: location.coords.longitude };
          applyCoords(coords);
        } catch (error) {
          console.warn('Error getting location:', error);
        }
      })();
    }
  }, [liveCoords]);

  // Default selectedLocation to current location when we first get userLocation (same as Wishv3 applyCoords)
  useEffect(() => {
    if (!userLocation || selectedLocation !== null) return;
    (async () => {
      try {
        const [result] = await Location.reverseGeocodeAsync(userLocation);
        const addr = result
          ? `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim() || 'Current Location'
          : 'Current Location';
        setSelectedLocation({ ...userLocation, address: addr });
      } catch {
        setSelectedLocation({ ...userLocation, address: 'Current Location' });
      }
    })();
  }, [userLocation, selectedLocation]);

  // Load saved locations for the dropdown (same list as Settings > Saved locations)
  useEffect(() => {
    if (!user?.id) return;
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(`${SAVED_LOCATIONS_KEY}_${user.id}`);
        if (!raw) {
          setSavedLocations([]);
          return;
        }
        const parsed = JSON.parse(raw);
        const list = Array.isArray(parsed) ? parsed : [];
        const labels: Record<string, string> = { home: 'Home', work: 'Work', gym: 'Gym', other: 'Other' };
        setSavedLocations(
          list.map((item: { id: string; label: string; customLabel?: string; address: string; latitude: number; longitude: number }) => ({
            id: item.id,
            label: item.customLabel || labels[item.label] || item.label,
            address: item.address,
            latitude: item.latitude,
            longitude: item.longitude,
          }))
        );
      } catch {
        setSavedLocations([]);
      }
    })();
  }, [user?.id]);

  // When service or wash type changes, drop any selected add-ons that are no longer allowed
  useEffect(() => {
    const isNonWash = serviceMode === 'detailing' || serviceMode === 'repair';
    const allowed = selectedService
      ? getAvailableAddOnIdsForService(selectedService, washType ?? '', isNonWash)
      : [];
    setSelectedAddOns((prev) => prev.filter((id) => allowed.includes(id)));
  }, [selectedService, washType, serviceMode]);

  const resolvePickerAddress = async (coords: { latitude: number; longitude: number }) => {
    const requestId = Date.now();
    pickerGeocodeRequestRef.current = requestId;
    try {
      const [result] = await Location.reverseGeocodeAsync(coords);
      if (pickerGeocodeRequestRef.current !== requestId) return;
      const addr = result
        ? `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim() || 'Selected Location'
        : 'Selected Location';
      setSelectedLocation({ ...coords, address: addr });
    } catch (e) {
      if (pickerGeocodeRequestRef.current === requestId) {
        setSelectedLocation({ ...coords, address: 'Selected Location' });
      }
      console.warn('Reverse geocode error:', e);
    }
  };

  const handleMapPress = async (event: MapPressEvent) => {
    const coords = event.nativeEvent.coordinate;
    setRegion({
      latitude: coords.latitude,
      longitude: coords.longitude,
      latitudeDelta: LOCATION_PICKER_DELTA,
      longitudeDelta: LOCATION_PICKER_DELTA,
    });
    await resolvePickerAddress(coords);
    await hapticFeedback('light');
  };

  const handleUseCurrentLocation = async () => {
    await hapticFeedback('medium');
    if (userLocation) {
      setRegion({
        latitude: userLocation.latitude,
        longitude: userLocation.longitude,
        latitudeDelta: LOCATION_PICKER_DELTA,
        longitudeDelta: LOCATION_PICKER_DELTA,
      });
      try {
        const [result] = await Location.reverseGeocodeAsync(userLocation);
        if (result) {
          const addr = `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim() || 'Current Location';
          setSelectedLocation({ ...userLocation, address: addr });
        }
      } catch (e) {
        console.warn('Reverse geocode error:', e);
      }
    }
  };

  const handlePickSavedLocation = (item: SavedLocationItem) => {
    hapticFeedback('light');
    const coords = { latitude: item.latitude, longitude: item.longitude };
    setRegion({ ...coords, latitudeDelta: LOCATION_PICKER_DELTA, longitudeDelta: LOCATION_PICKER_DELTA });
    setSelectedLocation({ ...coords, address: item.address });
    setAddressSearchInput('');
    setAddressSuggestions([]);
    setShowAddressOverlay(false);
  };

  const closeAddressOverlayWithoutSaving = () => {
    setAddressSearchInput('');
    setAddressSuggestions([]);
    setShowAddressOverlay(false);
  };

  const openVehicleInfo = async (vehicle: Vehicle) => {
    hapticFeedback('light');
    setInfoVehicle(vehicle);
    setVehicleStats({ washCount: 0, lastCleanedAt: null, cleanRating: null });
    try {
      const stats = await fetchVehicleStats(vehicle.id);
      setVehicleStats({ washCount: stats.washCount, lastCleanedAt: stats.lastCleanedAt, cleanRating: stats.cleanRating });
    } catch {
      setVehicleStats({ washCount: 0, lastCleanedAt: null, cleanRating: null });
    }
  };

  useEffect(() => {
    const allowSuggest = showAddressOverlay || currentStep === 'location';
    if (!allowSuggest) {
      setAddressSuggestions([]);
      return;
    }
    const q = addressSearchInput.trim();
    if (q.length < 2) {
      setAddressSuggestions([]);
      return;
    }
    if (suggestDebounceRef.current) clearTimeout(suggestDebounceRef.current);
    suggestDebounceRef.current = setTimeout(async () => {
      const reqId = ++suggestRequestRef.current;
      setLoadingSuggestions(true);
      try {
        const results = await Location.geocodeAsync(q);
        if (suggestRequestRef.current !== reqId) return;
        if (!results?.length) {
          setAddressSuggestions([]);
          return;
        }
        const max = Math.min(results.length, 8);
        const items: AddressGeocodeSuggestion[] = [];
        for (let i = 0; i < max; i++) {
          const r = results[i];
          let description = q;
          try {
            const [rev] = await Location.reverseGeocodeAsync({ latitude: r.latitude, longitude: r.longitude });
            if (rev) {
              const line = `${rev.street || ''} ${rev.city || ''} ${rev.postalCode || ''}`.trim();
              if (line) description = line;
            }
          } catch {
            /* keep query as label */
          }
          items.push({
            id: `${r.latitude.toFixed(5)}-${r.longitude.toFixed(5)}-${i}`,
            description,
            latitude: r.latitude,
            longitude: r.longitude,
          });
        }
        if (suggestRequestRef.current === reqId) setAddressSuggestions(items);
      } catch {
        if (suggestRequestRef.current === reqId) setAddressSuggestions([]);
      } finally {
        if (suggestRequestRef.current === reqId) setLoadingSuggestions(false);
      }
    }, 320);
    return () => {
      if (suggestDebounceRef.current) clearTimeout(suggestDebounceRef.current);
    };
  }, [showAddressOverlay, currentStep, addressSearchInput]);

  const handleSelectSuggestion = async (suggestion: AddressGeocodeSuggestion) => {
    setAddressSearching(true);
    setAddressSuggestions([]);
    try {
      const coords = { latitude: suggestion.latitude, longitude: suggestion.longitude };
      setRegion({ ...coords, latitudeDelta: LOCATION_PICKER_DELTA, longitudeDelta: LOCATION_PICKER_DELTA });
      setSelectedLocation({ ...coords, address: suggestion.description });
      setShowAddressOverlay(false);
      setAddressSearchInput('');
      await hapticFeedback('medium');
    } finally {
      setAddressSearching(false);
    }
  };

  const handleAddressSearch = async () => {
    const q = addressSearchInput.trim();
    if (!q) return;
    setAddressSearching(true);
    try {
      const results = await Location.geocodeAsync(q);
      if (results?.length && results.length > 0) {
        const { latitude, longitude } = results[0];
        const coords = { latitude, longitude };
        setRegion({ ...coords, latitudeDelta: LOCATION_PICKER_DELTA, longitudeDelta: LOCATION_PICKER_DELTA });
        const [rev] = await Location.reverseGeocodeAsync(coords);
        const addr = rev
          ? `${rev.street || ''} ${rev.city || ''} ${rev.postalCode || ''}`.trim() || q
          : q;
        setSelectedLocation({ ...coords, address: addr });
        setShowAddressOverlay(false);
        setAddressSearchInput('');
        await hapticFeedback('medium');
      } else {
        Alert.alert('Address not found', 'Try a different address or more specific search.');
      }
    } catch (e) {
      Alert.alert('Search failed', (e as Error)?.message || 'Could not find that address.');
    } finally {
      setAddressSearching(false);
    }
  };

  const loadVehicles = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('*')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false });

      if (error) throw error;
      const rows = (data || []).map((r: any) => ({ ...r, image_url: r.image_url ?? r.photo ?? null }));
      setVehicles(rows);
      if (rows.length > 0) {
        const defaultVehicle = rows.find((v: Vehicle) => v.is_default) || rows[0];
        setSelectedVehicle(defaultVehicle.id);
      }
    } catch (error) {
      console.error('Error loading vehicles:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLocationAndVehicleContinue = async () => {
    if (!selectedLocation) {
      Alert.alert('Location Required', 'Please select a location on the map or use your current location.');
      return;
    }
    await hapticFeedback('medium');
    setCurrentStep('vehicle');
  };

  /** Advance to service step with a specific vehicle (single tap; avoids stale selectedVehicle). */
  const proceedToServiceWithVehicle = async (vehicleId: string) => {
    await hapticFeedback('medium');
    setSelectedVehicle(vehicleId);
    setCurrentStep('service');
  };

  type ServicePickOutcome = 'bronze-overlay' | 'addons-modal' | 'ready';

  const isDetailingOrRepairPackage = serviceMode === 'detailing' || serviceMode === 'repair';

  const currentServiceOptions =
    serviceMode === 'wash'
      ? serviceOptions
      : serviceMode === 'repair'
        ? repairServiceOptions
        : detailingServiceOptions;

  const handleServiceSelect = async (serviceId: string): Promise<ServicePickOutcome> => {
    await hapticFeedback('light');
    const nextOption = currentServiceOptions.find((s) => s.id === serviceId);
    setSelectedAddOns((prev) => prev.filter((id) => !nextOption?.includedAddOnIds?.includes(id)));
    setSelectedService(serviceId);
    if (serviceId === 'bronze-wash') {
      setShowBronzeWashTypeOverlay(true);
      return 'bronze-overlay';
    }
    setWashType(null);
    const allowed = getAvailableAddOnIdsForService(serviceId, '', isDetailingOrRepairPackage);
    const opts = addOnOptions.filter(
      (a) => allowed.includes(a.id) && !nextOption?.includedAddOnIds?.includes(a.id)
    );
    if (opts.length > 0) {
      setShowAddOnsModal(true);
      return 'addons-modal';
    }
    return 'ready';
  };

  /** Build valeter params from explicit ids so we can navigate in the same tap as selection (no stale state). */
  const navigateToValeterSelection = async (args: {
    serviceId: string;
    vehicleId: string;
    location: { latitude: number; longitude: number; address: string };
    washType: string;
  }) => {
    const nextOption = currentServiceOptions.find((s) => s.id === args.serviceId);
    const washKeyForAddOns: '' | 'exterior' | 'interior' | 'both' =
      args.serviceId !== 'bronze-wash'
        ? ''
        : args.washType === 'exterior' || args.washType === 'interior' || args.washType === 'both'
          ? args.washType
          : '';
    const allowed = getAvailableAddOnIdsForService(
      args.serviceId,
      washKeyForAddOns,
      serviceMode === 'detailing' || serviceMode === 'repair'
    );
    const filteredAddOns = selectedAddOns.filter((id) => !nextOption?.includedAddOnIds?.includes(id));
    const effective = filteredAddOns.filter((id) => allowed.includes(id));
    const extrasTotal = effective.reduce((sum, id) => {
      const addOn = addOnOptions.find((a) => a.id === id);
      return sum + (addOn?.price ?? 0);
    }, 0);
    await hapticFeedback('medium');
    const discountAmount = 0;
    const vehicleRow = vehicles.find((v) => v.id === args.vehicleId);
    const washIdForPrice = mapServiceIdToWashId(args.serviceId);
    let computedServiceBase = nextOption?.price ?? 25;
    if (washIdForPrice && vehicleRow) {
      const breakdown = calculateDisplayPrice({
        washId: washIdForPrice,
        vehicleSize: getVehicleSize(vehicleRow),
        isMobile: true,
        isPhysicalLocation: false,
        scheduledDateTime: new Date(),
      });
      if (breakdown.finalDisplayPriceGBP > 0) {
        computedServiceBase = breakdown.finalDisplayPriceGBP;
      }
    }
    const valeterParams: Record<string, string> = {
      serviceId: args.serviceId,
      vehicleId: args.vehicleId,
      latitude: args.location.latitude.toString(),
      longitude: args.location.longitude.toString(),
      address: args.location.address,
      washType: args.washType,
      serviceMode: serviceMode,
      addOnIds: effective.length ? effective.join(',') : '',
      addOnsTotal: extrasTotal.toString(),
      customerOffersWater: 'false',
      customerOffersElectricity: 'false',
      discountAmount: discountAmount.toString(),
      serviceBasePriceGBP: computedServiceBase.toFixed(2),
    };
    if (params.preferredValeterId) valeterParams.preferredValeterId = params.preferredValeterId;
    router.push({
      pathname: '/owner/booking/valeter-selection',
      params: valeterParams,
    });
  };

  const handleWashTypeSelect = async (type: 'exterior' | 'interior') => {
    await hapticFeedback('light');
    setWashType(type);
    setShowBronzeWashTypeOverlay(false);
    const bronze = serviceOptions.find((s) => s.id === 'bronze-wash');
    const allowed = getAvailableAddOnIdsForService('bronze-wash', type, false);
    const opts = addOnOptions.filter(
      (a) => allowed.includes(a.id) && !bronze?.includedAddOnIds?.includes(a.id)
    );
    if (opts.length > 0) {
      setShowAddOnsModal(true);
      return;
    }
  };

  const handleServiceContinue = async () => {
    if (!selectedService || !selectedVehicle || !selectedLocation) return;
    if (serviceMode === 'wash' && selectedService === 'bronze-wash' && !washType) {
      return;
    }
    await navigateToValeterSelection({
      serviceId: selectedService,
      vehicleId: selectedVehicle,
      location: selectedLocation,
      washType: washType || '',
    });
  };
  const selectedServiceData = currentServiceOptions.find(s => s.id === selectedService);
  const selectedVehicleData = vehicles.find(v => v.id === selectedVehicle);

  const allowedAddOnIds = selectedService
    ? getAvailableAddOnIdsForService(selectedService, washType ?? '', isDetailingOrRepairPackage)
    : [];
  const availableAddOnOptions = addOnOptions.filter(
    (a) => allowedAddOnIds.includes(a.id) && !selectedServiceData?.includedAddOnIds?.includes(a.id)
  );

  const effectiveSelectedAddOns = selectedAddOns.filter((id) => allowedAddOnIds.includes(id));
  const addOnsTotal = effectiveSelectedAddOns.reduce((sum, id) => {
    const addOn = addOnOptions.find(a => a.id === id);
    return sum + (addOn?.price ?? 0);
  }, 0);

  const basePrice = (() => {
    if (!selectedServiceData || !selectedVehicleData || selectedService == null) return null;
    const washId = mapServiceIdToWashId(selectedService);
    if (washId) {
      const vehicleSize = getVehicleSize(selectedVehicleData);
      const input: FrontendPricingInput = {
        washId,
        vehicleSize,
        isMobile: true,
        isPhysicalLocation: false,
        scheduledDateTime: new Date(),
      };
      const breakdown = calculateDisplayPrice(input);
      return breakdown?.finalDisplayPriceGBP ?? selectedServiceData.price;
    }
    return selectedServiceData.price;
  })();

  const totalWithAddOns = basePrice == null ? null : basePrice + addOnsTotal;

  const serviceContinueReady =
    Boolean(selectedService && selectedVehicle && selectedLocation) &&
    !(serviceMode === 'wash' && selectedService === 'bronze-wash' && !washType);

  const serviceContinueAccent = selectedServiceData?.colors[0] ?? SKY;
  const addOnsSheetAccent = selectedServiceData?.colors[0] ?? SKY;

  const toggleAddOn = (id: string) => {
    hapticFeedback('light');
    setSelectedAddOns((prev) => {
      if (prev.includes(id)) return prev.filter((x) => x !== id);
      return [...prev, id];
    });
  };

  const headerConfig = getBookingHeaderConfig(currentStep);
  const headerTitle = headerConfig.title;
  const headerSubtitle = headerConfig.subtitle;
  const headerOnBack = headerConfig.backStep === null ? undefined : () => setCurrentStep(headerConfig.backStep!);

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      {/* Location uses map; vehicle/service use booking hero loops. */}
      <View style={StyleSheet.absoluteFill}>
        {currentStep === 'vehicle' || currentStep === 'service' ? (
          <MapView
            ref={mapRef}
            style={StyleSheet.absoluteFill}
            region={
              (() => {
                const c = selectedLocation || userLocation;
                if (c) {
                  return {
                    latitude: c.latitude,
                    longitude: c.longitude,
                    latitudeDelta: 0.055,
                    longitudeDelta: 0.055,
                  };
                }
                return region ?? DEFAULT_MAP_REGION;
              })()
            }
            onRegionChangeComplete={(r) => {
              if (currentStep === 'vehicle' || currentStep === 'service') setRegion(r);
            }}
            mapPadding={{
              top: 0,
              right: 0,
              bottom: 190 + Math.max(insets.bottom, 10),
              left: 0,
            }}
            legalLabelInsets={{
              top: 0,
              right: 8,
              bottom: 190 + Math.max(insets.bottom, 10) - 36,
              left: 8,
            }}
            showsUserLocation={false}
            showsMyLocationButton={false}
            toolbarEnabled={false}
            customMapStyle={LOCATION_PICKER_MAP_STYLE}
            userInterfaceStyle={MAP_LOCKED_DARK}
            scrollEnabled
            zoomEnabled
            rotateEnabled={false}
            pitchEnabled={false}
          >
            {(selectedLocation || userLocation) && (
              <>
                <Circle
                  center={{
                    latitude: (selectedLocation || userLocation)!.latitude,
                    longitude: (selectedLocation || userLocation)!.longitude,
                  }}
                  radius={12 * 1609.34}
                  strokeColor={`${SKY}88`}
                  fillColor={`${SKY}16`}
                  strokeWidth={2}
                />
                <Marker
                  coordinate={{
                    latitude: (selectedLocation || userLocation)!.latitude,
                    longitude: (selectedLocation || userLocation)!.longitude,
                  }}
                >
                  <MapMarkerCustomerVehicle size={42} variant="pin" />
                </Marker>
              </>
            )}
          </MapView>
        ) : (
          <MapView
            ref={mapRef}
            style={StyleSheet.absoluteFill}
            region={region ?? DEFAULT_MAP_REGION}
            onPress={currentStep === 'location' ? (e) => { void handleMapPress(e); } : () => {}}
            onRegionChangeComplete={(nextRegion) => {
              if (currentStep !== 'location') return;
              const coords = { latitude: nextRegion.latitude, longitude: nextRegion.longitude };
              if (pickerGeocodeDebounceRef.current) clearTimeout(pickerGeocodeDebounceRef.current);
              pickerGeocodeDebounceRef.current = setTimeout(() => {
                void resolvePickerAddress(coords);
              }, 280);
            }}
            showsUserLocation
            showsMyLocationButton={false}
            toolbarEnabled={false}
            customMapStyle={LOCATION_PICKER_MAP_STYLE}
            userInterfaceStyle={MAP_LOCKED_DARK}
            mapPadding={{
              top: 0,
              right: 0,
              bottom:
                currentStep === 'location'
                  ? 280 + Math.max(insets.bottom, 14)
                  : 190 + Math.max(insets.bottom, 10),
              left: 0,
            }}
            legalLabelInsets={{
              top: 0,
              right: 8,
              bottom:
                currentStep === 'location'
                  ? 280 + Math.max(insets.bottom, 14) - 42
                  : 190 + Math.max(insets.bottom, 10) - 24,
              left: 8,
            }}
          >
            {userLocation && (
              <Marker coordinate={userLocation}>
                <MapMarkerCustomerVehicle size={42} variant="pin" />
              </Marker>
            )}
          </MapView>
        )}
        {currentStep === 'location' && (
          <View pointerEvents="none" style={styles.centerPickerWrap}>
            <Animated.View style={[styles.centerPickerPin, { transform: [{ scale: markerPulse }] }]}>
              <MapMarkerCustomerVehicle size={44} variant="car" />
            </Animated.View>
          </View>
        )}
      </View>

      <AppHeader
        title={headerTitle}
        subtitle={headerSubtitle}
        showBack={currentStep !== 'vehicle'}
        onBack={headerOnBack ?? (() => {})}
        rightAction={
          currentStep === 'location' ? (
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <BookingHeaderMapControlButton
                onPress={async () => {
                  hapticFeedback('light');
                  await handleUseCurrentLocation();
                  const center = userLocation ?? selectedLocation ?? region;
                  if (center && mapRef.current) {
                    const r = { latitude: center.latitude, longitude: center.longitude, latitudeDelta: LOCATION_PICKER_DELTA, longitudeDelta: LOCATION_PICKER_DELTA };
                    setRegion(r);
                    mapRef.current.animateToRegion(r, MAP_CAMERA_ANIMATION_DURATION);
                  }
                }}
                accentColor={SKY}
                accessibilityLabel="Use current location"
              />
              {selectedLocation ? (
                <TouchableOpacity
                  onPress={() => { void handleLocationAndVehicleContinue(); }}
                  style={styles.exitButton}
                  activeOpacity={0.8}
                >
                  <Ionicons name="checkmark" size={22} color="#FFFFFF" />
                </TouchableOpacity>
              ) : null}
            </View>
          ) : undefined
        }
      />

      {currentStep === 'location' && (
        <View style={[styles.inlineSearchWrap, { top: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + 12 }]}>
          <View style={styles.inlineSearchRow}>
            <Ionicons name="search" size={18} color={SKY} />
            <TextInput
              style={styles.inlineSearchInput}
              placeholder="Search address or postcode"
              placeholderTextColor="#94A3B8"
              value={addressSearchInput}
              onChangeText={(text) => {
                setAddressSearchInput(text);
                setShowInlineSuggestions(true);
              }}
              onSubmitEditing={() => { void handleAddressSearch(); }}
              returnKeyType="search"
            />
            <TouchableOpacity
              onPress={() => { void handleAddressSearch(); }}
              style={styles.inlineSearchGo}
              activeOpacity={0.8}
            >
              <Ionicons name="arrow-forward" size={16} color="#FFFFFF" />
            </TouchableOpacity>
          </View>
          {showInlineSuggestions && addressSuggestions.length > 0 && (
            <ScrollView style={styles.inlineSuggestionsList} keyboardShouldPersistTaps="handled">
              {addressSuggestions.map((s) => (
                <TouchableOpacity
                  key={s.id}
                  style={styles.inlineSuggestionItem}
                  onPress={() => { void handleSelectSuggestion(s); setShowInlineSuggestions(false); }}
                  activeOpacity={0.8}
                >
                  <Ionicons name="location-outline" size={16} color={SKY} />
                  <Text style={styles.inlineSuggestionText} numberOfLines={1}>{s.description}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          )}
        </View>
      )}

      

      {/* Floating cards container - matches Book Your Wash */}
      <Animated.View
        style={[
          styles.cardsContainer,
          {
            opacity: fadeAnim,
            transform: [{ translateY: Animated.add(slideAnim, sheetDragY) }],
            paddingBottom:
              currentStep === 'vehicle' || currentStep === 'service'
                ? 0
                : Math.max(insets.bottom, 4) + 22,
            paddingHorizontal: currentStep === 'vehicle' || currentStep === 'service' ? 0 : adaptive.horizontalPadding,
          },
        ]}
        {...sheetPanResponder.panHandlers}
      >
        <Animated.View style={{ transform: [{ translateX: stepSlideAnim }] }}>
        {/* Step 1: Location only */}
        {/* Step 2: Vehicle selection */}
        {currentStep === 'vehicle' && (
          <View style={[styles.vehicleBottomSheet, { paddingBottom: Math.max(insets.bottom, 8) }]}>
            <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} />
            <LinearGradient colors={HEADER_STYLE_CARD_GRADIENT} style={StyleSheet.absoluteFill} />
            <LinearGradient
              colors={['rgba(255,255,255,0.16)', 'rgba(255,255,255,0.02)', 'transparent']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.locationSheetSheen}
            />
            <BookingSheetPremiumLayers />
            <View style={styles.locationSheetHandle} />
            {selectedVehicleData ? (
              <View style={styles.vehicleSelectedBannerWrap}>
                <View style={styles.vehicleSelectedBanner}>
                  <Ionicons name="checkmark-circle" size={14} color={SKY} />
                  <Text style={styles.vehicleSelectedBannerText} numberOfLines={1}>
                    Selected: {selectedVehicleData.make} {selectedVehicleData.model}
                  </Text>
                </View>
              </View>
            ) : null}
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              style={styles.bookingStepHorizontalScroll}
              contentContainerStyle={styles.bookingIndexOptionsScrollVehicle}
              snapToInterval={trackingSnapInterval}
              decelerationRate="fast"
              snapToAlignment="start"
            >
              {loading ? (
                <View style={[ix.cardWrap, { width: trackingCardWidth }]}>
                  <IndexTrackingCardShell accentColor={SKY}>
                    <View style={styles.combinedVehicleLoading}>
                      <ActivityIndicator size="small" color={SKY} />
                      <Text style={styles.combinedVehicleLoadingText}>Loading vehicles...</Text>
                    </View>
                  </IndexTrackingCardShell>
                </View>
              ) : vehicles.length === 0 ? (
                <View style={[ix.cardWrap, { width: trackingCardWidth }]}>
                  <IndexTrackingCardShell accentColor={SKY}>
                    <View style={styles.combinedVehicleEmpty}>
                      <Text style={styles.combinedVehicleEmptyText}>No vehicles found</Text>
                      <TouchableOpacity onPress={() => router.push('/owner/settings/vehicle-management')} style={styles.addButton} activeOpacity={0.85}>
                        <LinearGradient colors={['rgba(56,189,248,0.3)', 'rgba(30,41,59,0.55)']} style={styles.addButtonGradient}>
                          <Ionicons name="add-circle" size={20} color="#FFFFFF" />
                          <Text style={styles.addButtonText}>Add Vehicle</Text>
                        </LinearGradient>
                      </TouchableOpacity>
                    </View>
                  </IndexTrackingCardShell>
                </View>
              ) : (
                vehicles.map((vehicle) => {
                  const isVehicleSelected = selectedVehicle === vehicle.id;
                  return (
                    <TouchableOpacity
                      key={vehicle.id}
                      activeOpacity={0.92}
                      onPress={() => {
                        hapticFeedback('light');
                        setSelectedVehicle(vehicle.id);
                      }}
                      style={[ix.cardWrap, { width: trackingCardWidth }]}
                    >
                      <IndexTrackingCardShell
                        accentColor={SKY}
                        style={
                          isVehicleSelected
                            ? { borderColor: SKY + '90', borderWidth: 2 }
                            : undefined
                        }
                      >
                        <View style={ix.optionCardTopRow}>
                          <View style={[ix.optionIconBadge, { borderColor: SKY + '55', backgroundColor: SKY + '35' }]}>
                            <Ionicons name="car-sport" size={22} color={SKY} />
                          </View>
                          <View style={ix.optionTitleMain}>
                            <Text style={ix.optionKicker}>YOUR VEHICLE</Text>
                            <Text style={ix.optionTitle} numberOfLines={1}>
                              {vehicle.make} {vehicle.model}
                            </Text>
                            <Text style={ix.optionSubtitle} numberOfLines={2}>
                              {vehicle.color}
                              {vehicle.registration ? ` · ${vehicle.registration}` : ''}
                              {vehicle.is_default ? ' · Default' : ''}
                            </Text>
                            <Text style={styles.vehiclePricingHint} numberOfLines={2}>
                              Used to calculate pricing & time
                            </Text>
                          </View>
                          <TouchableOpacity
                            style={[ix.optionInfoBtn, { borderColor: SKY + '40', backgroundColor: SKY + '15' }]}
                            onPress={() => { hapticFeedback('light'); openVehicleInfo(vehicle); }}
                            activeOpacity={0.85}
                            accessibilityLabel="Vehicle information"
                            accessibilityRole="button"
                          >
                            <Ionicons name="information-circle-outline" size={22} color={SKY} />
                          </TouchableOpacity>
                        </View>
                        {vehicles.length > 1 ? (
                          <View style={ix.optionFooterRow}>
                            <View style={ix.optionFooterLeft}>
                              <View style={[ix.optionStatusPill, { backgroundColor: 'rgba(148,163,184,0.12)' }]}>
                                <View style={[ix.optionStatusDot, { backgroundColor: '#94A3B8' }]} />
                                <Text style={[ix.optionStatusText, { color: '#94A3B8' }]}>Swipe to compare</Text>
                              </View>
                            </View>
                          </View>
                        ) : null}
                      </IndexTrackingCardShell>
                    </TouchableOpacity>
                  );
                })
              )}
            </ScrollView>
            {!loading && vehicles.length > 0 ? (
              <View style={[styles.sheetPrimaryCtaRow, styles.sheetPrimaryCtaRowVehicleStep]}>
                <View style={{ width: trackingCardWidth }}>
                  <TouchableOpacity
                    style={[
                      customerMapTrackingSheetActionStyles.bookingInfoActionCard,
                      customerMapTrackingSheetActionStyles.bookingInfoCard,
                      styles.bookingSheetTrackingCta,
                      { borderColor: SKY + '8A', opacity: selectedVehicle ? 1 : 0.45 },
                    ]}
                    onPress={() => {
                      if (!selectedVehicle) return;
                      void proceedToServiceWithVehicle(selectedVehicle);
                    }}
                    disabled={!selectedVehicle}
                    activeOpacity={0.85}
                  >
                    <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
                    <LinearGradient
                      colors={[SKY + '59', 'rgba(15,23,42,0.65)']}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 0, y: 1 }}
                      style={StyleSheet.absoluteFill}
                      pointerEvents="none"
                    />
                    <Ionicons name="arrow-forward-circle" size={18} color={SKY} style={{ zIndex: 1 }} />
                    <View style={customerMapTrackingSheetActionStyles.bookingInfoCardTextWrap}>
                      <Text style={[styles.bookingSheetCtaLabel, { color: SKY }]}>Continue</Text>
                    </View>
                  </TouchableOpacity>
                </View>
              </View>
            ) : null}
          </View>
        )}

        {/* Step 3: Service Selection */}
        {currentStep === 'service' && (
          <View style={[styles.vehicleBottomSheet, { paddingBottom: Math.max(insets.bottom, 8) }]}>
            <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} />
            <LinearGradient colors={HEADER_STYLE_CARD_GRADIENT} style={StyleSheet.absoluteFill} />
            <LinearGradient
              colors={['rgba(255,255,255,0.16)', 'rgba(255,255,255,0.02)', 'transparent']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.locationSheetSheen}
            />
            <BookingSheetPremiumLayers />
            <View style={styles.locationSheetHandle} />
            <View style={[styles.serviceModeToggle, { paddingHorizontal: 12, marginBottom: 6 }]}>
              <TouchableOpacity
                onPress={() => {
                  hapticFeedback('light');
                  setServiceMode('wash');
                }}
                style={[
                  customerMapTrackingSheetActionStyles.bookingInfoActionCard,
                  customerMapTrackingSheetActionStyles.bookingInfoCard,
                  styles.bookingSheetTrackingCta,
                  styles.serviceModeToggleSegment,
                  {
                    borderColor: serviceMode === 'wash' ? SKY + '8A' : 'rgba(148,163,184,0.38)',
                  },
                ]}
                activeOpacity={0.85}
              >
                <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
                <LinearGradient
                  colors={
                    serviceMode === 'wash'
                      ? [SKY + '59', 'rgba(15,23,42,0.65)']
                      : ['rgba(51,65,85,0.5)', 'rgba(15,23,42,0.72)']
                  }
                  start={{ x: 0, y: 0 }}
                  end={{ x: 0, y: 1 }}
                  style={StyleSheet.absoluteFill}
                  pointerEvents="none"
                />
                <LinearGradient
                  colors={['rgba(255,255,255,0.16)', 'rgba(255,255,255,0.03)', 'transparent']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={StyleSheet.absoluteFill}
                  pointerEvents="none"
                />
                <Ionicons
                  name="water-outline"
                  size={18}
                  color={serviceMode === 'wash' ? SKY : 'rgba(148,163,184,0.85)'}
                  style={{ zIndex: 1 }}
                />
                <Text
                  style={[
                    styles.bookingSheetCtaLabel,
                    {
                      color: serviceMode === 'wash' ? SKY : 'rgba(148,163,184,0.9)',
                      zIndex: 1,
                      flexShrink: 1,
                    },
                  ]}
                  numberOfLines={1}
                  adjustsFontSizeToFit
                  minimumFontScale={0.85}
                >
                  Wash
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  hapticFeedback('light');
                  setServiceMode('detailing');
                }}
                style={[
                  customerMapTrackingSheetActionStyles.bookingInfoActionCard,
                  customerMapTrackingSheetActionStyles.bookingInfoCard,
                  styles.bookingSheetTrackingCta,
                  styles.serviceModeToggleSegment,
                  {
                    borderColor:
                      serviceMode === 'detailing' ? DETAILING_YELLOW + '8A' : 'rgba(148,163,184,0.38)',
                  },
                ]}
                activeOpacity={0.85}
              >
                <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
                <LinearGradient
                  colors={
                    serviceMode === 'detailing'
                      ? [DETAILING_YELLOW + '59', 'rgba(15,23,42,0.65)']
                      : ['rgba(51,65,85,0.5)', 'rgba(15,23,42,0.72)']
                  }
                  start={{ x: 0, y: 0 }}
                  end={{ x: 0, y: 1 }}
                  style={StyleSheet.absoluteFill}
                  pointerEvents="none"
                />
                <LinearGradient
                  colors={['rgba(255,255,255,0.16)', 'rgba(255,255,255,0.03)', 'transparent']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={StyleSheet.absoluteFill}
                  pointerEvents="none"
                />
                <Ionicons
                  name="diamond-outline"
                  size={18}
                  color={serviceMode === 'detailing' ? DETAILING_YELLOW : 'rgba(234,179,8,0.55)'}
                  style={{ zIndex: 1 }}
                />
                <Text
                  style={[
                    styles.bookingSheetCtaLabel,
                    {
                      color: serviceMode === 'detailing' ? DETAILING_YELLOW : 'rgba(234,179,8,0.75)',
                      zIndex: 1,
                      flexShrink: 1,
                    },
                  ]}
                  numberOfLines={1}
                  adjustsFontSizeToFit
                  minimumFontScale={0.85}
                >
                  Detail
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  hapticFeedback('light');
                  setServiceMode('repair');
                }}
                style={[
                  customerMapTrackingSheetActionStyles.bookingInfoActionCard,
                  customerMapTrackingSheetActionStyles.bookingInfoCard,
                  styles.bookingSheetTrackingCta,
                  styles.serviceModeToggleSegment,
                  {
                    borderColor:
                      serviceMode === 'repair' ? REPAIR_ACCENT + 'AA' : 'rgba(148,163,184,0.38)',
                  },
                ]}
                activeOpacity={0.85}
              >
                <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
                <LinearGradient
                  colors={
                    serviceMode === 'repair'
                      ? [REPAIR_ACCENT + '59', 'rgba(15,23,42,0.65)']
                      : ['rgba(51,65,85,0.5)', 'rgba(15,23,42,0.72)']
                  }
                  start={{ x: 0, y: 0 }}
                  end={{ x: 0, y: 1 }}
                  style={StyleSheet.absoluteFill}
                  pointerEvents="none"
                />
                <LinearGradient
                  colors={['rgba(255,255,255,0.16)', 'rgba(255,255,255,0.03)', 'transparent']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={StyleSheet.absoluteFill}
                  pointerEvents="none"
                />
                <Ionicons
                  name="construct-outline"
                  size={18}
                  color={serviceMode === 'repair' ? REPAIR_ACCENT : 'rgba(251,146,60,0.45)'}
                  style={{ zIndex: 1 }}
                />
                <Text
                  style={[
                    styles.bookingSheetCtaLabel,
                    {
                      color: serviceMode === 'repair' ? REPAIR_ACCENT : 'rgba(251,146,60,0.75)',
                      zIndex: 1,
                      flexShrink: 1,
                    },
                  ]}
                  numberOfLines={1}
                  adjustsFontSizeToFit
                  minimumFontScale={0.85}
                >
                  Repair
                </Text>
              </TouchableOpacity>
            </View>
            {selectedServiceData ? (
              <View style={styles.vehicleSelectedBannerWrap}>
                <View style={styles.vehicleSelectedBanner}>
                  <Ionicons name="sparkles-outline" size={14} color={SKY} />
                  <Text style={styles.vehicleSelectedBannerText} numberOfLines={1}>
                    Selected: {selectedServiceData.name}
                  </Text>
                </View>
              </View>
            ) : null}
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              style={styles.bookingStepHorizontalScroll}
              contentContainerStyle={styles.bookingIndexOptionsScrollVehicle}
              snapToInterval={trackingSnapInterval}
              decelerationRate="fast"
              snapToAlignment="start"
            >
              {currentServiceOptions.map((service) => {
                const isSelected = selectedService === service.id;
                const serviceColor = service.colors[0];
                const priceLine =
                  isSelected && totalWithAddOns != null
                    ? `£${totalWithAddOns.toFixed(2)} total`
                    : 'Prices vary';

                const packageTagline =
                  getWashPackageTagline(service.id) ?? service.descriptionTitle ?? '';
                return (
                  <TouchableOpacity
                    key={service.id}
                    activeOpacity={0.92}
                    onPress={() => {
                      void (async () => {
                        hapticFeedback('light');
                        await handleServiceSelect(service.id);
                      })();
                    }}
                    style={[ix.cardWrap, { width: trackingCardWidth }]}
                  >
                    <IndexTrackingCardShell
                      accentColor={serviceColor}
                      style={{
                        borderColor: isSelected ? serviceColor + 'AA' : 'rgba(148,163,184,0.35)',
                        borderWidth: 2,
                      }}
                    >
                      <View style={ix.optionCardTopRow}>
                        <ServiceTierSpongeIcon accentColor={serviceColor} iconName={getServiceTierLeadIconName(service.id)} />
                        <View style={ix.optionTitleMain}>
                          <View style={[ix.optionKickerRow, ix.optionKickerSlot]}>
                            {service.badge ? (
                              <View
                                style={[
                                  styles.serviceBadgePill,
                                  { backgroundColor: serviceColor + '30', borderColor: serviceColor + '50', flexShrink: 1, maxWidth: '52%' },
                                ]}
                              >
                                <Text style={[styles.serviceBadgePillText, { color: serviceColor }]} numberOfLines={1}>
                                  {service.badge}
                                </Text>
                              </View>
                            ) : null}
                          </View>
                          <Text style={ix.optionTitle} numberOfLines={2}>
                            {service.name}
                          </Text>
                          <Text style={ix.optionSubtitle} numberOfLines={2}>
                            {service.dur} · {priceLine}
                          </Text>
                          <View style={styles.serviceCardTaglineSlot}>
                            {packageTagline ? (
                              <Text style={[styles.servicePackageTagline, { color: serviceColor + 'CC' }]} numberOfLines={2}>
                                {packageTagline}
                              </Text>
                            ) : null}
                          </View>
                        </View>
                        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                          {isSelected && effectiveSelectedAddOns.length > 0 ? (
                            <TouchableOpacity
                              onPress={(e) => {
                                e.stopPropagation?.();
                                hapticFeedback('light');
                                setShowAddOnsModal(true);
                              }}
                              activeOpacity={0.85}
                              style={[styles.addOnsCountBesideInfo, { borderColor: serviceColor + '55' }]}
                              hitSlop={{ top: 8, bottom: 8, left: 4, right: 4 }}
                            >
                              <Text style={[styles.addOnsCountPlus, { color: serviceColor }]}>+</Text>
                              <Text style={[styles.addOnsCountNumber, { color: serviceColor }]}>
                                {effectiveSelectedAddOns.length}
                              </Text>
                            </TouchableOpacity>
                          ) : null}
                          <TouchableOpacity
                            style={[ix.optionInfoBtn, { borderColor: serviceColor + '40', backgroundColor: serviceColor + '15' }]}
                            onPress={() => { hapticFeedback('light'); setInfoService(service); }}
                            activeOpacity={0.85}
                            accessibilityLabel="Service details"
                            accessibilityRole="button"
                          >
                            <Ionicons name="information-circle-outline" size={22} color={serviceColor} />
                          </TouchableOpacity>
                        </View>
                      </View>
                      <View style={ix.optionFooterRow}>
                        <View style={[ix.optionFooterLeft, styles.serviceCardFooterRow]}>
                          {isSelected && selectedService === 'bronze-wash' ? (
                            <TouchableOpacity
                              onPress={() => setShowBronzeWashTypeOverlay(true)}
                              style={[styles.washTypeChipSmall, { backgroundColor: serviceColor + '22', borderColor: serviceColor + '44' }]}
                              activeOpacity={0.8}
                            >
                              {washType ? (
                                <>
                                  <Ionicons
                                    name={washType === 'exterior' ? 'car-sport-outline' : 'home-outline'}
                                    size={14}
                                    color={serviceColor}
                                  />
                                  <Text style={[styles.washTypeChipSmallText, { color: serviceColor }]}>
                                    {washType === 'exterior' ? 'Exterior' : 'Interior'}
                                  </Text>
                                </>
                              ) : (
                                <Text style={[styles.washTypeChipSmallText, { color: serviceColor }]}>Set clean area</Text>
                              )}
                            </TouchableOpacity>
                          ) : null}
                          {currentServiceOptions.length > 1 ? (
                            <View style={[ix.optionStatusPill, { backgroundColor: 'rgba(148,163,184,0.12)' }]}>
                              <View style={[ix.optionStatusDot, { backgroundColor: '#94A3B8' }]} />
                              <Text style={[ix.optionStatusText, { color: '#94A3B8' }]}>Swipe to compare</Text>
                            </View>
                          ) : null}
                        </View>
                      </View>
                    </IndexTrackingCardShell>
                  </TouchableOpacity>
                );
              })}
            </ScrollView>
            <View style={[styles.sheetPrimaryCtaRow, styles.sheetPrimaryCtaRowVehicleStep]}>
              {isDetailingOrRepairPackage && selectedService ? (
                <Text
                  style={[
                    styles.conditionMicrocopy,
                    styles.sheetDetailingMicrocopy,
                    { width: trackingCardWidth },
                    serviceMode === 'repair' ? { color: REPAIR_ACCENT + 'CC' } : null,
                  ]}
                >
                  {serviceMode === 'repair'
                    ? 'Repair work is condition-based. Results vary by lens and vehicle condition.'
                    : 'Detailing is condition-based. Results vary by vehicle condition.'}
                </Text>
              ) : null}
              <View style={{ width: trackingCardWidth }}>
                <TouchableOpacity
                  style={[
                    customerMapTrackingSheetActionStyles.bookingInfoActionCard,
                    customerMapTrackingSheetActionStyles.bookingInfoCard,
                    styles.bookingSheetTrackingCta,
                    {
                      borderColor: serviceContinueAccent + '8A',
                      opacity: serviceContinueReady ? 1 : 0.45,
                    },
                  ]}
                  onPress={() => void handleServiceContinue()}
                  disabled={!serviceContinueReady}
                  activeOpacity={0.85}
                >
                  <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
                  <LinearGradient
                    colors={[serviceContinueAccent + '59', 'rgba(15,23,42,0.65)']}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 0, y: 1 }}
                    style={StyleSheet.absoluteFill}
                    pointerEvents="none"
                  />
                  <Ionicons name="arrow-forward-circle" size={18} color={serviceContinueAccent} style={{ zIndex: 1 }} />
                  <View style={customerMapTrackingSheetActionStyles.bookingInfoCardTextWrap}>
                    <Text style={[styles.bookingSheetCtaLabel, { color: serviceContinueAccent }]}>Continue to valeter</Text>
                  </View>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        )}
        </Animated.View>

        <BookingBottomSheetOverlay visible={!!infoService} onClose={() => setInfoService(null)} maxHeightRatio={0.9}>
          {infoService ? (
            <>
              <View style={styles.serviceInfoSheetHero}>
                <Text style={[styles.serviceInfoSheetName, { color: customerTheme.primary }]} numberOfLines={2}>
                  {infoService.name}
                  {infoService.id === 'bronze-wash' && washType
                    ? ` · ${washType === 'exterior' ? 'Exterior' : 'Interior'}`
                    : ''}
                </Text>
                <Text style={[styles.serviceInfoSheetPrice, { color: customerTheme.primary }]}>£{infoService.price}</Text>
              </View>
              <ScrollView
                style={styles.serviceInfoScroll}
                contentContainerStyle={styles.infoModalScrollContent}
                showsVerticalScrollIndicator
              >
                {infoService.descriptionTitle ? (
                  <Text style={[styles.infoModalDescTitle, { color: customerTheme.primary }]}>{infoService.descriptionTitle}</Text>
                ) : null}
                <Text style={styles.infoModalDesc}>
                  {(() => {
                    if (infoService.id === 'bronze-wash' && washType === 'exterior') {
                      return 'A quick exterior refresh to keep your vehicle looking clean and presentable.';
                    }
                    if (infoService.id === 'bronze-wash' && washType === 'interior') {
                      return "A light interior refresh designed to tidy and freshen your vehicle's cabin.";
                    }
                    return infoService.desc ?? '';
                  })()}
                </Text>
                {(() => {
                  let bulletPoints: string[];
                  if (infoService.id === 'bronze-wash' && washType === 'exterior') {
                    bulletPoints = [
                      'Wheels and wheel arches cleaned',
                      'Snow foam pre-wash applied',
                      'Safe exterior hand wash',
                      'Vehicle fully rinsed',
                      'Exterior hand dried',
                      'Windows and mirrors cleaned',
                      'Ideal for regular maintenance washes and light dirt removal',
                    ];
                  } else if (infoService.id === 'bronze-wash' && washType === 'interior') {
                    bulletPoints = [
                      'Rubbish removed',
                      'Interior vacuum (seats, carpets, and mats)',
                      'Dashboard and main surfaces wiped down',
                      'Steering wheel cleaned',
                      'Interior glass cleaned',
                      'Air freshener applied',
                      'Perfect for maintaining a clean and comfortable interior between deeper cleans',
                    ];
                  } else {
                    bulletPoints = infoService.bulletPoints ?? [];
                  }
                  return bulletPoints.length > 0 ? (
                    <View style={styles.infoModalBullets}>
                      {bulletPoints.map((point: string) => (
                        <View key={point} style={styles.infoModalBulletRow}>
                          <View style={[styles.infoModalBulletDot, { backgroundColor: customerTheme.primary }]} />
                          <Text style={styles.infoModalBulletText}>{point}</Text>
                        </View>
                      ))}
                    </View>
                  ) : null;
                })()}
                {effectiveSelectedAddOns.length > 0 ? (
                  <View style={styles.infoModalAddOns}>
                    <Text style={styles.infoModalAddOnsTitle}>Selected add-ons</Text>
                    {effectiveSelectedAddOns.map((id) => {
                      const addOn = addOnOptions.find((a) => a.id === id);
                      if (!addOn) return null;
                      return (
                        <View key={addOn.id} style={styles.infoModalAddOnRow}>
                          <Ionicons name={addOn.icon as any} size={18} color={customerTheme.primary} />
                          <Text style={styles.infoModalAddOnName}>{addOn.name}</Text>
                          <Text style={styles.infoModalAddOnPrice}>+£{addOn.price}</Text>
                        </View>
                      );
                    })}
                    <View style={styles.infoModalAddOnTotal}>
                      <Text style={styles.infoModalAddOnTotalLabel}>Total</Text>
                      <Text style={styles.infoModalAddOnTotalValue}>+£{addOnsTotal}</Text>
                    </View>
                  </View>
                ) : null}
              </ScrollView>
              <TouchableOpacity onPress={() => setInfoService(null)} style={styles.infoModalDoneWrap} activeOpacity={0.9}>
                <LinearGradient colors={[customerTheme.primary, customerTheme.primary + 'E6']} style={styles.infoModalDoneBtn}>
                  <Text style={styles.infoModalDoneText}>Done</Text>
                </LinearGradient>
              </TouchableOpacity>
            </>
          ) : null}
        </BookingBottomSheetOverlay>

        <VehicleInfoOverlay
          visible={!!infoVehicle}
          vehicle={infoVehicle ? { ...infoVehicle, mot_expiry: (infoVehicle as any).mot_expiry ?? null, mot_expiry_date: (infoVehicle as any).mot_expiry_date ?? null, mileage: (infoVehicle as any).mileage ?? null, tax_status: (infoVehicle as any).tax_status ?? null, tax_due_date: (infoVehicle as any).tax_due_date ?? null, tax_expiry: (infoVehicle as any).tax_expiry ?? null } : null}
          stats={vehicleStats}
          accentColor={customerTheme.primary}
          onClose={() => setInfoVehicle(null)}
        />

        {/* Address search bottom sheet */}
        <BookingBottomSheetOverlay visible={showAddressOverlay} onClose={closeAddressOverlayWithoutSaving} maxHeightRatio={0.92}>
          <KeyboardAvoidingView
            style={styles.addressOverlayKeyboardWrap}
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          >
            <View style={styles.addressOverlayContent}>
              <View style={styles.addressOverlayContentInner}>
                <Text style={styles.addressOverlayTitle}>Change location</Text>
                <Text style={styles.addressOverlaySubtitle}>Current location is default. Pick a saved place or search.</Text>
                <TouchableOpacity
                  style={styles.addressOverlayUseCurrent}
                  onPress={async () => {
                    await handleUseCurrentLocation();
                    closeAddressOverlayWithoutSaving();
                  }}
                  activeOpacity={0.8}
                >
                  <Ionicons name="locate" size={18} color={SKY} />
                  <Text style={styles.addressOverlayUseCurrentText}>Use current location</Text>
                </TouchableOpacity>
                {savedLocations.length > 0 && (
                  <>
                    <Text style={styles.addressOverlaySavedLabel}>Saved locations</Text>
                    <ScrollView style={styles.addressOverlaySavedList} keyboardShouldPersistTaps="handled" nestedScrollEnabled>
                      {savedLocations.map((item) => (
                        <TouchableOpacity
                          key={item.id}
                          style={styles.addressOverlaySavedItem}
                          onPress={() => handlePickSavedLocation(item)}
                          activeOpacity={0.8}
                        >
                          <Ionicons name="location" size={18} color={SKY} />
                          <View style={styles.addressOverlaySavedItemText}>
                            <Text style={styles.addressOverlaySavedItemLabel}>{item.label}</Text>
                            <Text style={styles.addressOverlaySavedItemAddress} numberOfLines={1}>{item.address}</Text>
                          </View>
                          <Ionicons name="chevron-forward" size={18} color="#64748B" />
                        </TouchableOpacity>
                      ))}
                    </ScrollView>
                  </>
                )}
                <Text style={styles.addressOverlaySearchLabel}>Or search for an address</Text>
                <TextInput
                  style={styles.addressOverlayInput}
                  placeholder="Find your postcode..."
                  placeholderTextColor="#64748B"
                  value={addressSearchInput}
                  onChangeText={setAddressSearchInput}
                  onFocus={() => {
                    setAddressSearchInput('');
                    setAddressSuggestions([]);
                    setLoadingSuggestions(false);
                  }}
                  onSubmitEditing={handleAddressSearch}
                  returnKeyType="search"
                  autoCapitalize="none"
                />
                {loadingSuggestions && (
                  <View style={styles.addressSuggestionsLoading}>
                    <ActivityIndicator size="small" color={SKY} />
                  </View>
                )}
                {!loadingSuggestions && addressSuggestions.length > 0 && (
                  <ScrollView
                    style={styles.addressSuggestionsList}
                    keyboardShouldPersistTaps="handled"
                    nestedScrollEnabled
                  >
                    {addressSuggestions.map((s) => (
                      <TouchableOpacity
                        key={s.id}
                        style={styles.addressSuggestionItem}
                        onPress={() => handleSelectSuggestion(s)}
                        activeOpacity={0.7}
                      >
                        <Ionicons name="location-outline" size={18} color={SKY} />
                        <Text style={styles.addressSuggestionText} numberOfLines={2}>{s.description}</Text>
                      </TouchableOpacity>
                    ))}
                  </ScrollView>
                )}
                <View style={styles.addressOverlayButtons}>
                  <TouchableOpacity style={styles.addressOverlayCancel} onPress={closeAddressOverlayWithoutSaving} activeOpacity={0.8}>
                    <Text style={styles.addressOverlayCancelText}>Cancel</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[styles.addressOverlaySearch, addressSearching && { opacity: 0.7 }]}
                    onPress={handleAddressSearch}
                    disabled={addressSearching}
                    activeOpacity={0.8}
                  >
                    {addressSearching ? (
                      <ActivityIndicator size="small" color="#fff" />
                    ) : (
                      <>
                        <Ionicons name="search" size={18} color="#fff" />
                        <Text style={styles.addressOverlaySearchText}>Search</Text>
                      </>
                    )}
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </KeyboardAvoidingView>
        </BookingBottomSheetOverlay>

        {/* Add-ons bottom sheet */}
        <BookingBottomSheetOverlay
          visible={showAddOnsModal}
          onClose={() => setShowAddOnsModal(false)}
          maxHeightRatio={0.96}
          sheetStyle={styles.addOnsOverlaySheet}
        >
          <View style={styles.addOnsSheetRoot}>
            <View style={styles.addOnsModalContentInner}>
              <View style={styles.addOnsModalHeader}>
                <View style={styles.addOnsModalTitleRow}>
                  <View style={[styles.addOnsModalTitleIcon, { backgroundColor: addOnsSheetAccent + '22' }]}>
                    <Ionicons name="add-circle" size={24} color={addOnsSheetAccent} />
                  </View>
                  <Text style={styles.addOnsModalTitle}>{ADD_ON_SECTION_TITLE}</Text>
                </View>
              </View>
              <Text style={styles.addOnsModalSubtitle}>{ADD_ON_SECTION_SUBTITLE}</Text>

              {availableAddOnOptions.length > 0 ? (
                <ScrollView
                  style={styles.addOnsModalList}
                  contentContainerStyle={styles.addOnsModalListContent}
                  showsVerticalScrollIndicator
                  bounces
                  keyboardShouldPersistTaps="handled"
                >
                  {availableAddOnOptions.map((addOn) => {
                    const isSelected = selectedAddOns.includes(addOn.id);
                    return (
                      <TouchableOpacity
                        key={addOn.id}
                        onPress={() => toggleAddOn(addOn.id)}
                        style={[styles.addOnsModalRow, isSelected && { backgroundColor: addOnsSheetAccent + '12', borderColor: addOnsSheetAccent + '35' }]}
                        activeOpacity={0.75}
                      >
                        <View style={[styles.addOnsModalRowIcon, isSelected && { backgroundColor: addOnsSheetAccent + '25' }]}>
                          <Ionicons name={(addOn.icon ?? 'add') as keyof typeof Ionicons.glyphMap} size={22} color={isSelected ? addOnsSheetAccent : '#94A3B8'} />
                        </View>
                        <View style={styles.addOnsModalRowBody}>
                          <Text style={styles.addOnsModalRowName}>{addOn.name}</Text>
                          <Text style={styles.addOnsModalRowDesc} numberOfLines={2}>{addOn.desc}</Text>
                          <Text style={[styles.addOnsModalRowPriceInline, isSelected && { color: addOnsSheetAccent }]}>+£{addOn.price}</Text>
                        </View>
                        <View style={[styles.addOnsModalCheck, isSelected && { backgroundColor: addOnsSheetAccent, borderColor: addOnsSheetAccent }]}>
                          {isSelected ? <Ionicons name="checkmark" size={14} color="#FFFFFF" /> : null}
                        </View>
                      </TouchableOpacity>
                    );
                  })}
                </ScrollView>
              ) : (
                <View style={styles.addOnsModalEmptyState}>
                  <Text style={styles.addOnsModalEmptyText}>No add-ons available for this service.</Text>
                </View>
              )}
            </View>
            <View style={styles.addOnsModalFooterWrap}>
              {effectiveSelectedAddOns.length > 0 && (
                <View style={[styles.addOnsModalFooter, { backgroundColor: addOnsSheetAccent + '15', borderColor: addOnsSheetAccent + '30' }]}>
                  <Text style={styles.addOnsModalFooterLabel}>Add-ons total</Text>
                  <Text style={[styles.addOnsModalFooterValue, { color: addOnsSheetAccent }]}>+£{addOnsTotal.toFixed(2)}</Text>
                </View>
              )}
              <TouchableOpacity
                onPress={() => {
                  hapticFeedback('light');
                  setShowAddOnsModal(false);
                }}
                style={[styles.addOnsModalDone, { backgroundColor: addOnsSheetAccent + '28', borderColor: addOnsSheetAccent + '50' }]}
                activeOpacity={0.85}
              >
                <Text style={styles.addOnsModalDoneText}>Done</Text>
              </TouchableOpacity>
            </View>
          </View>
        </BookingBottomSheetOverlay>

        {/* Bronze wash: exterior / interior bottom sheet */}
        <BookingBottomSheetOverlay
          visible={showBronzeWashTypeOverlay}
          onClose={() => setShowBronzeWashTypeOverlay(false)}
          maxHeightRatio={0.62}
          sheetStyle={{ borderColor: getServiceStripColor('bronze-wash', SKY) + '50' }}
        >
          <View style={styles.bronzeWashTypeModalContentInner}>
            <View style={[styles.bronzeWashTypeModalAccent, { backgroundColor: getServiceStripColor('bronze-wash', SKY) }]} />
            <View style={styles.bronzeWashTypeModalHeader}>
              <View>
                <Text style={styles.bronzeWashTypeModalTitle}>Bronze Wash</Text>
                <Text style={styles.bronzeWashTypeModalSubtitle}>What do you want cleaned?</Text>
              </View>
            </View>
            <View style={styles.bronzeWashTypeModalOptions}>
              <TouchableOpacity onPress={() => handleWashTypeSelect('exterior')} style={[styles.bronzeWashTypeModalOption, { borderColor: getServiceStripColor('bronze-wash', SKY) + '40' }]} activeOpacity={0.85}>
                <View style={[styles.bronzeWashTypeModalOptionIcon, { backgroundColor: getServiceStripColor('bronze-wash', SKY) + '20' }]}>
                  <Ionicons name="car-sport-outline" size={26} color={getServiceStripColor('bronze-wash', SKY)} />
                </View>
                <View style={styles.bronzeWashTypeModalOptionText}>
                  <Text style={styles.bronzeWashTypeModalOptionLabel}>Exterior</Text>
                  <Text style={styles.bronzeWashTypeModalOptionDesc}>Snow foam, hand wash, wheels, dry & windows</Text>
                </View>
                <Ionicons name="chevron-forward" size={18} color="#64748B" />
              </TouchableOpacity>
              <TouchableOpacity onPress={() => handleWashTypeSelect('interior')} style={[styles.bronzeWashTypeModalOption, { borderColor: getServiceStripColor('bronze-wash', SKY) + '40' }]} activeOpacity={0.85}>
                <View style={[styles.bronzeWashTypeModalOptionIcon, { backgroundColor: getServiceStripColor('bronze-wash', SKY) + '20' }]}>
                  <Ionicons name="layers-outline" size={26} color={getServiceStripColor('bronze-wash', SKY)} />
                </View>
                <View style={styles.bronzeWashTypeModalOptionText}>
                  <Text style={styles.bronzeWashTypeModalOptionLabel}>Interior</Text>
                  <Text style={styles.bronzeWashTypeModalOptionDesc}>Vacuum, wipe-down, glass & air freshener</Text>
                </View>
                <Ionicons name="chevron-forward" size={18} color="#64748B" />
              </TouchableOpacity>
            </View>
          </View>
        </BookingBottomSheetOverlay>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  videoLoadingSkeleton: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: colors.BG ?? '#0A1929',
    zIndex: 9999,
    elevation: 999,
  },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    width: 56,
    height: 56,
    borderRadius: 28,
    borderWidth: 1.5,
    borderColor: 'rgba(126,184,212,0.5)',
    backgroundColor: 'rgba(2,6,23,0.36)',
    shadowColor: '#38BDF8',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.28,
    shadowRadius: 10,
    elevation: 7,
  },
  userMarker: {
    width: 42,
    height: 42,
  },
  selectedLocationMarker: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  selectedLocationMarkerInner: {
    width: 48,
    height: 48,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 6,
  },
  selectedLocationMarkerCar: {
    width: 48,
    height: 48,
  },
  centerPickerWrap: {
    ...StyleSheet.absoluteFillObject,
    alignItems: 'center',
    justifyContent: 'center',
  },
  centerPickerPin: {
    width: 54,
    height: 54,
    borderRadius: 27,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(135,206,235,0.22)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.45)',
  },
  centerPickerCar: {
    width: 42,
    height: 42,
  },
  recenterButton: {
    position: 'absolute',
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 100,
  },
  recenterButtonFloating: {
    position: 'absolute',
    zIndex: 1000,
    width: 50,
    height: 50,
    borderRadius: 24,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: SKY + '8A',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 8,
  },
  currentLocationButton: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15, 23, 42, 0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  exitButton: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
    elevation: 8,
  },
  cardsContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingTop: 10,
  },
  locationSheetShell: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    minHeight: 300,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderTopWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
    backgroundColor: 'rgba(2,6,23,0.08)',
    overflow: 'hidden',
  },
  locationSheetSheen: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.9,
  },
  locationSheetHandle: {
    width: 42,
    height: 4,
    borderRadius: 2,
    alignSelf: 'center',
    marginTop: 10,
    marginBottom: 4,
    backgroundColor: 'rgba(255,255,255,0.55)',
  },
  stepDots: {
    position: 'absolute',
    left: 16,
    flexDirection: 'row',
    gap: 8,
    zIndex: 100,
  },
  stepDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(148,163,184,0.4)',
  },
  stepDotDone: {
    backgroundColor: SKY,
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  stepDotActive: {
    backgroundColor: SKY,
    width: 12,
    height: 8,
    borderRadius: 4,
  },
  modernCard: {
    padding: 12,
    overflow: 'hidden',
    borderRadius: 22,
    borderWidth: 1,
    borderColor: 'rgba(126,184,212,0.35)',
    backgroundColor: 'rgba(255,255,255,0.04)',
    minHeight: 142,
  },
  locationPremiumCardWrap: {
    marginVertical: 2,
  },
  locationPremiumCard: {
    overflow: 'hidden',
    borderRadius: 22,
    borderWidth: 1,
    backgroundColor: 'rgba(255,255,255,0.04)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.22,
    shadowRadius: 14,
    elevation: 7,
  },
  locationPremiumDarkOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(2,6,23,0.2)',
  },
  locationPremiumGlowOverlay: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 22,
    borderWidth: 1,
    backgroundColor: 'transparent',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.45,
    shadowRadius: 14,
    elevation: 4,
  },
  locationPremiumContent: {
    padding: 14,
  },
  locationV2Card: {
    borderRadius: 22,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.35)',
    backgroundColor: 'rgba(255,255,255,0.04)',
    padding: 14,
    marginBottom: 10,
  },
  locationV2Header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  locationV2Icon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: SKY + '55',
    backgroundColor: SKY + '20',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
  },
  locationV2TitleWrap: { flex: 1 },
  locationV2Kicker: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  locationV2Title: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '800',
    marginTop: 1,
  },
  locationV2Address: {
    color: '#E2E8F0',
    fontSize: 14,
    lineHeight: 20,
    fontWeight: '600',
  },
  locationV2AddressMuted: {
    color: '#94A3B8',
    fontSize: 13,
    lineHeight: 18,
  },
  locationV2Hint: {
    marginTop: 8,
    color: SKY,
    fontSize: 12,
    fontWeight: '700',
  },
  resourcesV2Card: {
    borderRadius: 22,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.35)',
    backgroundColor: 'rgba(255,255,255,0.04)',
    padding: 14,
    marginBottom: 6,
  },
  locationSectionKicker: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 10,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 1.4,
    marginBottom: 6,
  },
  modernCardEmpty: {
    alignItems: 'center',
  },
  modernCardSelected: {
    borderColor: SKY + '90',
    shadowColor: SKY,
    shadowOpacity: 0.28,
    shadowRadius: 12,
    elevation: 6,
  },
  cardTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  iconWrap: {
    width: 46,
    height: 46,
    borderRadius: 14,
    marginRight: 10,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  iconGradient: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardContent: {
    flex: 1,
    minWidth: 0,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  titleAndBadge: {
    flex: 1,
    minWidth: 0,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flexWrap: 'wrap',
  },
  serviceTitleActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    flexShrink: 0,
  },
  addOnsCountBesideInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
    backgroundColor: 'rgba(15,23,42,0.65)',
    borderWidth: 1,
  },
  addOnsCountPlus: {
    fontSize: 14,
    fontWeight: '800',
    marginTop: -1,
  },
  addOnsCountNumber: {
    fontSize: 13,
    fontWeight: '800',
    minWidth: 14,
    textAlign: 'center',
  },
  cardTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
  },
  serviceBadgePill: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
    borderWidth: 1,
    alignSelf: 'flex-start',
  },
  serviceBadgePillText: {
    fontSize: 11,
    fontWeight: '700',
  },
  cardSubtitle: {
    color: 'rgba(226,232,240,0.86)',
    fontSize: 12,
    fontWeight: '600',
  },
  serviceReinforcement: {
    color: '#87CEEB',
    fontSize: 12,
    marginTop: 4,
    fontStyle: 'italic',
  },
  locationMicrocopy: {
    marginTop: 4,
    fontSize: 12,
    fontWeight: '600',
    color: SKY,
  },
  locationFooter: {
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.12)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  locationFooterText: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 0.3,
    textTransform: 'uppercase',
  },
  washTypeQuestion: {
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 6,
  },
  badgeSmall: {
    paddingHorizontal: 6,
    paddingVertical: 4,
    borderRadius: 10,
    borderWidth: 1,
  },
  titleRowRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  changeBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    backgroundColor: SKY + '15',
    borderWidth: 1,
    borderColor: SKY + '30',
  },
  changeBtnText: {
    color: SKY,
    fontSize: 12,
    fontWeight: '600',
  },
  changeBtnFullWidth: {
    marginTop: 10,
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 12,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.35)',
  },
  changeBtnSeparate: {
    marginTop: 10,
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 12,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.35)',
  },
  cardMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 6,
    marginTop: 6,
  },
  quickHint: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(126,184,212,0.28)',
    backgroundColor: 'rgba(30,41,59,0.45)',
  },
  quickHintText: {
    fontSize: 11,
    fontWeight: '700',
  },
  createVehicleMetaPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 9,
    paddingVertical: 4,
    borderRadius: 10,
    borderWidth: 0,
  },
  createVehicleMetaPillText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#10B981',
  },
  washTypeChipSmall: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 5,
    paddingHorizontal: 9,
    borderRadius: 8,
    borderWidth: 1,
    gap: 4,
    maxWidth: 132,
    flexShrink: 1,
  },
  washTypeChipSmallText: {
    fontSize: 11,
    fontWeight: '700',
  },
  serviceCardFooterRow: {
    flexWrap: 'nowrap',
    gap: 8,
    alignItems: 'center',
  },
  serviceCardTaglineSlot: {
    marginTop: 0,
    justifyContent: 'flex-start',
  },
  infoIconBtn: {
    padding: 6,
    borderRadius: 10,
  },
  ctaDivider: {
    height: 1,
    marginTop: 14,
    marginBottom: 12,
    borderRadius: 1,
  },
  conditionMicrocopy: {
    color: '#94A3B8',
    fontSize: 13,
    lineHeight: 18,
    fontStyle: 'italic',
    textAlign: 'center',
  },
  vehicleStepWrap: {
    paddingHorizontal: 16,
    marginBottom: 8,
  },
  locationRowAboveCards: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 10,
    paddingHorizontal: 14,
    marginBottom: 10,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: SKY + '30',
  },
  locationRowValue: {
    flex: 1,
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  /** Mobile service/package steps: extra top inset so cards sit lower in the sheet. */
  bookingIndexOptionsScroll: {
    marginTop: 24,
    paddingLeft: 14,
    paddingRight: 12,
    gap: 10,
  },
  /** Mobile choose-your-vehicle step: cards sit slightly higher. */
  bookingIndexOptionsScrollVehicle: {
    marginTop: 18,
    paddingLeft: 14,
    paddingRight: 12,
    gap: 10,
  },
  vehicleCardStrip: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 5,
    borderTopLeftRadius: 16,
    borderBottomLeftRadius: 16,
    zIndex: 1,
  },
  locationCardStrip: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 5,
    borderTopLeftRadius: 16,
    borderBottomLeftRadius: 16,
    zIndex: 1,
  },
  emptyContent: {
    alignItems: 'center',
    paddingVertical: 24,
  },
  emptyText: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
    marginTop: 14,
    marginBottom: 4,
  },
  emptySubtext: {
    color: '#94A3B8',
    fontSize: 13,
    textAlign: 'center',
    marginBottom: 16,
  },
  loadingContainer: {
    paddingVertical: 40,
    paddingHorizontal: 20,
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: SKY,
    fontSize: 15,
    fontWeight: '700',
  },
  addButton: {
    borderRadius: 18,
    overflow: 'hidden',
    marginTop: 16,
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  addButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 18,
    paddingVertical: 12,
    gap: 8,
  },
  addButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  carPhotoBox: {
    width: 56,
    height: 56,
    borderRadius: 14,
    overflow: 'hidden',
    marginLeft: 10,
  },
  /* Vehicle cards – compact, below location row */
  vehicleCard: {
    padding: 14,
    overflow: 'hidden',
    position: 'relative',
  },
  vehicleCardSelected: {
    borderWidth: 0,
    borderColor: 'transparent',
    shadowColor: SKY,
    shadowOpacity: 0.12,
    shadowRadius: 8,
    elevation: 4,
  },
  vehicleCardInfoIcon: {
    position: 'absolute',
    top: 10,
    right: 10,
    zIndex: 1,
  },
  vehicleCardTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  vehicleCardCarIcon: {
    width: 44,
    height: 44,
    borderRadius: 14,
    marginRight: 10,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  vehicleCardContent: {
    flex: 1,
    minWidth: 0,
    paddingRight: 36,
  },
  vehicleCardTitle: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '800',
    marginBottom: 2,
  },
  vehicleCardColourRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 6,
    marginBottom: 6,
  },
  vehicleCardSubtitle: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '500',
  },
  vehicleCardMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 6,
    marginTop: 4,
  },
  vehicleCardDefaultBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 6,
    backgroundColor: 'rgba(16,185,129,0.12)',
  },
  vehicleCardDefaultText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#FBBF24',
  },
  vehicleCardPhotoBox: {
    width: 44,
    height: 44,
    borderRadius: 10,
    overflow: 'hidden',
    marginLeft: 8,
  },
  vehicleCardPhotoSmall: {
    width: 44,
    height: 44,
  },
  vehicleCardPhotoPlaceholder: {
    width: 44,
    height: 44,
    backgroundColor: 'rgba(135,206,235,0.08)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  vehicleCardDivider: {
    height: 1,
    marginTop: 10,
    marginBottom: 8,
    borderRadius: 1,
    opacity: 0.6,
  },
  /* Combined location + vehicle single card */
  combinedCardScroll: {
    maxHeight: 340,
  },
  locationVehicleDivider: {
    height: 1,
    backgroundColor: 'rgba(135,206,235,0.25)',
    marginHorizontal: 14,
    marginVertical: 4,
  },
  combinedVehicleSection: {
    paddingHorizontal: 14,
    paddingBottom: 14,
  },
  combinedVehicleSectionTitle: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 8,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  combinedVehicleLoading: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 12,
  },
  combinedVehicleLoadingText: {
    color: '#94A3B8',
    fontSize: 14,
  },
  combinedVehicleEmpty: {
    paddingVertical: 8,
    alignItems: 'center',
  },
  combinedVehicleEmptyText: {
    color: '#94A3B8',
    fontSize: 14,
    marginBottom: 10,
  },
  combinedVehicleList: {
    paddingRight: 8,
    flexDirection: 'row',
  },
  vehicleRowInCard: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: 'rgba(148,163,184,0.25)',
    backgroundColor: 'rgba(15,23,42,0.4)',
    minWidth: 160,
    maxWidth: 200,
    marginRight: 10,
  },
  vehicleRowInCardSelected: {
    borderColor: SKY + '66',
    backgroundColor: SKY + '12',
  },
  vehicleRowIcon: {
    width: 40,
    height: 40,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  vehicleRowContent: {
    flex: 1,
    minWidth: 0,
  },
  vehicleRowTitle: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '700',
    marginBottom: 2,
  },
  vehicleRowSubtitle: {
    color: '#94A3B8',
    fontSize: 12,
  },
  vehicleRowInfoBtn: {
    padding: 4,
  },
  vehicleCardCta: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 10,
    borderWidth: 1.5,
    gap: 6,
  },
  vehicleCardCtaText: {
    fontSize: 14,
    fontWeight: '600',
  },
  carPhotoTouch: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
    overflow: 'hidden',
    backgroundColor: 'rgba(0,0,0,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  carPhotoSmall: {
    width: 56,
    height: 56,
  },
  carPhotoPlaceholder: {
    width: 56,
    height: 56,
    backgroundColor: 'rgba(135,206,235,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  washTypeRow: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 12,
  },
  washTypePillClean: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.3)',
  },
  washTypePillTextClean: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '600',
  },
  bronzeWashTypeOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  bronzeWashTypeModalContent: {
    width: '100%',
    minHeight: 280,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    borderWidth: 1,
    overflow: 'hidden',
    backgroundColor: 'transparent',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 12,
    elevation: 6,
  },
  bronzeWashTypeModalContentInner: {
    minHeight: 260,
    paddingHorizontal: 20,
    paddingTop: 14,
    paddingBottom: 20,
  },
  bronzeWashTypeModalAccent: {
    height: 4,
    width: '100%',
  },
  bronzeWashTypeModalHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    paddingBottom: 14,
  },
  bronzeWashTypeModalTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    letterSpacing: -0.3,
    marginBottom: 2,
  },
  bronzeWashTypeModalSubtitle: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 20,
  },
  bronzeWashTypeModalClose: {
    padding: 4,
  },
  bronzeWashTypeModalOptions: {
    gap: 10,
  },
  bronzeWashTypeModalOption: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    borderWidth: 1.5,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  bronzeWashTypeModalOptionIcon: {
    width: 48,
    height: 48,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    justifyContent: 'center',
    alignItems: 'center',
  },
  bronzeWashTypeModalOptionText: {
    flex: 1,
  },
  bronzeWashTypeModalOptionLabel: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '700',
    marginBottom: 2,
  },
  bronzeWashTypeModalOptionDesc: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '500',
    lineHeight: 18,
  },
  serviceStepWrap: {
    width: '100%',
  },
  vehicleBottomSheet: {
    width: '100%',
    paddingTop: 2,
    ...PREMIUM_BOOKING_MAP_SHEET_GLASS,
  },
  /** Stops the row from stretching in the column so the Continue bar sits tight under the cards. */
  bookingStepHorizontalScroll: {
    flexGrow: 0,
    flexShrink: 0,
  },
  /** Aligns with tracking sheet: tight gap under cards, CTA width matches swipe card (`trackingCardWidth`). */
  sheetPrimaryCtaRow: {
    paddingLeft: 14,
    paddingRight: 14,
    paddingTop: 0,
    marginTop: -10,
    paddingBottom: 2,
  },
  /** Choose-your-vehicle step only: leave visual gap below swipe cards. */
  sheetPrimaryCtaRowVehicleStep: {
    marginTop: 10,
  },
  /** Mirrors `tracking.tsx` `bookingDetailsBtn` — compact vs default `bookingInfoCard`. */
  bookingSheetTrackingCta: {
    flex: 0,
    alignSelf: 'stretch',
    width: '100%',
    minHeight: 50,
    paddingVertical: 11,
    paddingHorizontal: 14,
    borderRadius: 24,
    gap: 8,
  },
  bookingSheetCtaLabel: {
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 0.15,
    includeFontPadding: false,
  },
  sheetDetailingMicrocopy: {
    marginBottom: 2,
    paddingHorizontal: 0,
    textAlign: 'center',
    alignSelf: 'center',
  },
  vehicleSheetHeaderRow: {
    paddingHorizontal: 14,
    paddingTop: 6,
    paddingBottom: 6,
  },
  vehicleSheetTitle: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
  vehicleSheetKicker: {
    color: 'rgba(148,163,184,0.9)',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.1,
    textTransform: 'uppercase',
    marginBottom: 3,
  },
  vehicleSheetSubtitle: {
    marginTop: 3,
    color: 'rgba(226,232,240,0.85)',
    fontSize: 11,
    fontWeight: '600',
  },
  vehiclePricingHint: {
    marginTop: 6,
    fontSize: 11,
    color: 'rgba(148,163,184,0.95)',
    fontWeight: '600',
    lineHeight: 15,
  },
  servicePackageTagline: {
    marginTop: 6,
    fontSize: 12,
    fontWeight: '600',
    lineHeight: 16,
  },
  vehicleSelectedBanner: {
    marginTop: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(56,189,248,0.45)',
    backgroundColor: 'rgba(56,189,248,0.12)',
    alignSelf: 'flex-start',
  },
  vehicleSelectedBannerText: {
    color: SKY,
    fontSize: 11,
    fontWeight: '700',
  },
  resourcesToggleFixed: {
    position: 'absolute',
    left: 16,
    right: 16,
    zIndex: 10,
  },
  inlineSearchWrap: {
    position: 'absolute',
    left: 16,
    right: 16,
    zIndex: 120,
  },
  inlineSearchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    backgroundColor: 'rgba(2,6,23,0.78)',
    paddingHorizontal: 12,
    paddingVertical: 10,
  },
  inlineSearchInput: {
    flex: 1,
    color: '#F8FAFC',
    fontSize: 14,
    fontWeight: '600',
    paddingVertical: 0,
  },
  inlineSearchGo: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
  },
  inlineSuggestionsList: {
    marginTop: 8,
    maxHeight: 180,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.16)',
    backgroundColor: 'rgba(2,6,23,0.88)',
    overflow: 'hidden',
  },
  inlineSuggestionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.08)',
  },
  inlineSuggestionText: {
    flex: 1,
    color: '#E2E8F0',
    fontSize: 13,
    fontWeight: '600',
  },
  resourcesHelperText: {
    marginTop: 8,
    paddingHorizontal: 8,
    color: 'rgba(241,245,249,0.85)',
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
  },
  serviceModeToggle: {
    flexDirection: 'row',
    gap: 8,
    paddingHorizontal: 4,
  },
  /** Same chrome as Continue CTA (`bookingSheetTrackingCta`); equal width like original two-toggle row. */
  serviceModeToggleSegment: {
    flex: 1,
    minWidth: 0,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalAddOnsSection: {
    marginTop: 14,
    paddingTop: 14,
    borderTopWidth: 1,
    borderTopColor: customerTheme.primary + '20',
  },
  modalAddOnsTitle: {
    color: customerTheme.primary,
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1,
    textTransform: 'uppercase',
    marginBottom: 10,
  },
  modalAddOnRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 6,
  },
  modalAddOnName: {
    color: colors.headerText,
    fontSize: 13,
    fontWeight: '600',
    flex: 1,
  },
  modalAddOnPrice: {
    color: customerTheme.primary,
    fontSize: 13,
    fontWeight: '700',
  },
  modalAddOnTotal: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: customerTheme.primary + '18',
  },
  modalAddOnTotalLabel: {
    color: colors.headerSubtext,
    fontSize: 13,
    fontWeight: '600',
  },
  modalAddOnTotalValue: {
    color: customerTheme.primary,
    fontSize: 15,
    fontWeight: '800',
  },
  addOnsModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  addOnsModalContent: {
    width: '100%',
    height: '85%',
    maxHeight: 560,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.35)',
    overflow: 'hidden',
  },
  addOnsModalContentInner: {
    flex: 1,
    minHeight: 0,
    padding: 20,
  },
  addOnsSheetRoot: {
    flex: 1,
    minHeight: 0,
  },
  addOnsOverlaySheet: {
    height: '86%',
  },
  addOnsModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  addOnsModalTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  addOnsModalTitleIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: SKY + '22',
    alignItems: 'center',
    justifyContent: 'center',
  },
  addOnsModalTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
  },
  addOnsModalCloseBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(148,163,184,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  addOnsModalSubtitle: {
    color: '#94A3B8',
    fontSize: 14,
    marginBottom: 16,
    lineHeight: 20,
  },
  addOnsModalList: {
    flex: 1,
    minHeight: 200,
  },
  addOnsModalListContent: {
    paddingBottom: 16,
  },
  addOnsModalEmptyState: {
    flex: 1,
    minHeight: 140,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 18,
  },
  addOnsModalEmptyText: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
  },
  addOnsModalRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 14,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.15)',
    marginBottom: 10,
  },
  addOnsModalRowSelected: {
    backgroundColor: SKY + '12',
    borderColor: SKY + '35',
  },
  addOnsModalRowIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: 'rgba(148,163,184,0.12)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  addOnsModalRowIconSelected: {
    backgroundColor: SKY + '25',
  },
  addOnsModalRowBody: {
    flex: 1,
    minWidth: 0,
  },
  addOnsModalRowName: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
    marginBottom: 2,
  },
  addOnsModalRowDesc: {
    color: '#94A3B8',
    fontSize: 12,
    lineHeight: 17,
    marginBottom: 4,
  },
  addOnsModalRowPriceInline: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '800',
  },
  addOnsModalRowPriceSelected: {
    color: SKY,
  },
  addOnsModalCheck: {
    width: 26,
    height: 26,
    borderRadius: 13,
    borderWidth: 2,
    borderColor: 'rgba(148,163,184,0.45)',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 8,
  },
  addOnsModalCheckSelected: {
    backgroundColor: SKY,
    borderColor: SKY,
  },
  addOnsModalFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderRadius: 14,
    backgroundColor: SKY + '15',
    borderWidth: 1,
    borderColor: SKY + '30',
    marginTop: 12,
    marginBottom: 12,
  },
  addOnsModalFooterWrap: {
    paddingHorizontal: 20,
    paddingBottom: 10,
  },
  addOnsModalFooterLabel: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '700',
  },
  addOnsModalFooterValue: {
    color: SKY,
    fontSize: 18,
    fontWeight: '800',
  },
  addOnsModalDone: {
    paddingVertical: 16,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 14,
    backgroundColor: SKY + '28',
    borderWidth: 1,
    borderColor: SKY + '50',
  },
  addOnsModalDoneText: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
  },
  serviceCardRight: {
    alignItems: 'flex-end',
    gap: 6,
  },
  servicePriceClean: {
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  serviceIconWrap: {
    width: 48,
    height: 48,
    borderRadius: 14,
    borderWidth: 1.5,
    justifyContent: 'center',
    alignItems: 'center',
  },
  selectedCheck: {
    width: 24,
    height: 24,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoIconBtnInCard: {
    padding: 4,
  },
  serviceName: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 8,
    letterSpacing: -0.2,
  },
  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  statPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: 'rgba(148,163,184,0.15)',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
  },
  statText: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '600',
  },
  servicePrice: {
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  serviceBadgeBox: {
    width: 64,
    height: 64,
    marginLeft: 12,
  },
  serviceBadgeTouch: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
    borderWidth: 1.5,
    justifyContent: 'center',
    alignItems: 'center',
  },
  washTypeSection: {
    marginTop: 4,
    gap: 12,
  },
  washTypeTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: -0.2,
  },
  washTypeOptions: {
    flexDirection: 'row',
    gap: 12,
  },
  washTypePill: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderRadius: 14,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.25)',
    backgroundColor: 'rgba(135,206,235,0.08)',
  },
  washTypePillSelected: {
    borderColor: SKY,
    backgroundColor: SKY + '20',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  washTypePillText: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 15,
    fontWeight: '700',
  },
  continueBtn: {
    height: 54,
    borderRadius: 18,
    overflow: 'hidden',
    marginTop: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.5,
    shadowRadius: 12,
    elevation: 12,
    width: '100%',
  },
  continueBtnGradient: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingHorizontal: 20,
  },
  continueBtnText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  // Modal styles
  infoModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  infoModalCard: {
    width: '100%',
    height: '90%',
    maxHeight: '90%',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    overflow: 'hidden',
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderBottomWidth: 0,
    borderColor: 'rgba(126,184,212,0.5)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 16 },
    shadowOpacity: 0.4,
    shadowRadius: 28,
    elevation: 16,
  },
  infoModalHeaderBar: {
    paddingTop: 20,
    paddingBottom: 16,
    paddingHorizontal: 20,
    position: 'relative',
  },
  infoModalHeaderLabel: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1.2,
    marginBottom: 4,
  },
  infoModalHeaderTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: '800',
    letterSpacing: -0.2,
    paddingRight: 44,
  },
  infoModalHeaderSubtitle: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 16,
    fontWeight: '600',
  },
  infoModalHeaderPrice: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 15,
    fontWeight: '700',
    marginTop: 4,
  },
  infoModalCloseBtn: {
    position: 'absolute',
    top: 16,
    right: 16,
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0,0,0,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoModalDescTitle: {
    color: customerTheme.primary,
    fontSize: 13,
    fontWeight: '700',
    marginBottom: 6,
    letterSpacing: 0.2,
  },
  infoModalScrollWrap: {
    flex: 1,
    minHeight: 0,
  },
  infoModalScroll: {
    flex: 1,
    paddingHorizontal: 20,
  },
  infoModalScrollContent: {
    paddingTop: 4,
    paddingBottom: 24,
  },
  vehicleSelectedBannerWrap: {
    paddingHorizontal: 14,
    paddingTop: 2,
    paddingBottom: 10,
  },
  serviceInfoSheetHero: {
    marginBottom: 10,
    paddingBottom: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'rgba(255,255,255,0.1)',
  },
  serviceInfoSheetName: {
    fontSize: 20,
    fontWeight: '800',
    letterSpacing: -0.2,
    color: '#F8FAFC',
  },
  serviceInfoSheetPrice: {
    fontSize: 22,
    fontWeight: '800',
    marginTop: 8,
  },
  serviceInfoScroll: {
    maxHeight: 440,
  },
  infoModalDesc: {
    color: '#94A3B8',
    fontSize: 14,
    lineHeight: 22,
    marginBottom: 16,
  },
  infoModalBullets: {
    gap: 10,
    marginBottom: 16,
  },
  infoModalBulletRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  infoModalBulletDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  infoModalBulletText: {
    color: '#E2E8F0',
    fontSize: 14,
    lineHeight: 20,
    flex: 1,
  },
  infoModalAddOns: {
    marginTop: 12,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(148,163,184,0.2)',
  },
  infoModalAddOnsTitle: {
    color: '#94A3B8',
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1,
    textTransform: 'uppercase',
    marginBottom: 10,
  },
  infoModalAddOnRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 6,
  },
  infoModalAddOnName: {
    color: '#F1F5F9',
    fontSize: 14,
    fontWeight: '600',
    flex: 1,
  },
  infoModalAddOnPrice: {
    color: customerTheme.primary,
    fontSize: 14,
    fontWeight: '700',
  },
  infoModalAddOnTotal: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: 'rgba(148,163,184,0.15)',
  },
  infoModalAddOnTotalLabel: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '600',
  },
  infoModalAddOnTotalValue: {
    color: customerTheme.primary,
    fontSize: 16,
    fontWeight: '800',
  },
  infoModalDoneWrap: {
    marginHorizontal: 20,
    marginTop: 8,
    marginBottom: 20,
    borderRadius: 14,
    overflow: 'hidden',
  },
  infoModalDoneBtn: {
    paddingVertical: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  infoModalDoneText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  infoModalVehiclePhotoWrap: {
    height: 140,
    borderRadius: 14,
    overflow: 'hidden',
    marginBottom: 16,
    backgroundColor: 'rgba(0,0,0,0.2)',
  },
  infoModalVehiclePhoto: {
    width: '100%',
    height: '100%',
  },
  infoModalVehiclePhotoPlaceholder: {
    width: '100%',
    height: '100%',
    backgroundColor: customerTheme.primary + '18',
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoModalVehicleTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '800',
    textAlign: 'center',
    marginBottom: 18,
    letterSpacing: -0.2,
  },
  infoModalVehicleRows: {
    gap: 12,
  },
  infoModalVehicleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  infoModalVehicleRowText: {
    color: '#94A3B8',
    fontSize: 14,
    lineHeight: 20,
    flex: 1,
  },
  addressOverlayKeyboardWrap: {
    flex: 1,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(2,6,23,0.45)',
    justifyContent: 'flex-end',
    alignItems: 'center',
    padding: 24,
    paddingBottom: 40,
  },
  addressOverlayContent: {
    width: '100%',
    borderRadius: 26,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.25)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.35,
    shadowRadius: 24,
    elevation: 24,
    overflow: 'hidden',
  },
  addressOverlayContentInner: {
    padding: 24,
  },
  addressOverlayTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 4,
    letterSpacing: 0.2,
  },
  addressOverlaySubtitle: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 14,
    marginBottom: 12,
    lineHeight: 20,
  },
  addressOverlayUseCurrent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 12,
    marginBottom: 16,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: SKY + '18',
    borderWidth: 1,
    borderColor: SKY + '35',
  },
  addressOverlayUseCurrentText: {
    color: SKY,
    fontSize: 15,
    fontWeight: '700',
  },
  addressOverlaySavedLabel: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 8,
  },
  addressOverlaySavedList: {
    maxHeight: 160,
    marginBottom: 16,
  },
  addressOverlaySavedItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 12,
    marginBottom: 4,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(15,23,42,0.5)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.25)',
    gap: 10,
  },
  addressOverlaySavedItemText: {
    flex: 1,
  },
  addressOverlaySavedItemLabel: {
    color: '#F1F5F9',
    fontSize: 15,
    fontWeight: '700',
  },
  addressOverlaySavedItemAddress: {
    color: '#94A3B8',
    fontSize: 13,
    marginTop: 2,
  },
  addressOverlaySearchLabel: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 8,
  },
  addressOverlayInput: {
    backgroundColor: '#0F172A',
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    paddingHorizontal: 18,
    paddingVertical: 16,
    color: '#F9FAFB',
    fontSize: 16,
    borderWidth: 1.5,
    borderColor: SKY + '30',
  },
  addressSuggestionsLoading: { paddingVertical: 12, alignItems: 'center' },
  addressSuggestionsList: { maxHeight: 200, marginTop: 8 },
  addressSuggestionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 12,
    paddingHorizontal: 14,
    backgroundColor: 'rgba(15,23,42,0.8)',
    borderRadius: 12,
    marginBottom: 6,
    borderWidth: 1,
    borderColor: SKY + '20',
  },
  addressSuggestionText: { color: '#F1F5F9', fontSize: 14, flex: 1 },
  addressOverlayButtons: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 24,
  },
  addressOverlayCancel: {
    flex: 1,
    paddingVertical: 16,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(148,163,184,0.18)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.3)',
    alignItems: 'center',
  },
  addressOverlayCancelText: {
    color: '#94A3B8',
    fontSize: 16,
    fontWeight: '700',
  },
  addressOverlaySearchWrap: {
    flex: 1,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
  },
  addressOverlaySearch: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    paddingHorizontal: 20,
  },
  addressOverlaySearchText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  modalContent: {
    backgroundColor: 'transparent',
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    padding: 24,
    borderWidth: 1.5,
    borderColor: customerTheme.primary + '35',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.5,
    shadowRadius: 20,
    elevation: 20,
  },
  modalContentTouch: {
    width: '100%',
    maxWidth: 320,
    maxHeight: '82%',
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: customerTheme.primary + '30',
  },
  modalContentBlur: {
    flex: 1,
    overflow: 'hidden',
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    paddingBottom: 16,
  },
  modalHeaderHubStyle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: customerTheme.primary + '20',
  },
  modalTitleHubStyle: {
    color: customerTheme.primary,
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  modalCloseBtn: {
    padding: 4,
  },
  modalScrollContent: {
    maxHeight: 360,
    paddingHorizontal: 16,
    paddingTop: 14,
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  modalIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: customerTheme.primary + '25',
  },
  modalTitleContainer: {
    flex: 1,
  },
  modalTitle: {
    color: colors.headerText,
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 2,
  },
  modalPrice: {
    color: customerTheme.primary,
    fontSize: 16,
    fontWeight: '800',
  },
  modalDescription: {
    color: colors.headerSubtext,
    fontSize: 13,
    lineHeight: 20,
    marginBottom: 12,
    opacity: 0.95,
  },
  bulletPointsContainer: {
    gap: 8,
    marginBottom: 14,
  },
  bulletPoint: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
  },
  bulletPointText: {
    color: colors.headerText,
    fontSize: 13,
    lineHeight: 18,
    flex: 1,
    opacity: 0.92,
  },
  modalCloseButton: {
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
    shadowColor: customerTheme.primary,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 3,
  },
  modalCloseButtonGradient: {
    padding: 12,
    alignItems: 'center',
  },
  modalCloseButtonText: {
    color: '#FFFFFF',
    fontWeight: '800',
    fontSize: 16,
    letterSpacing: 0.3,
  },
});
