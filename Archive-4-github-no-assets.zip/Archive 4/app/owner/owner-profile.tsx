// app/owner/owner-profile.tsx

import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Image,
  ActivityIndicator,
  TextInput,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system/legacy';
import AppHeader from '../../src/components/shared/AppHeader';
import { SkeletonList } from '../../src/components/shared/SkeletonLoader';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { useOwnerScrollContentPadding } from '../../src/hooks/useOwnerScrollContentPadding';
import { colors } from '../../src/constants/colors';
import { useToast } from '../../src/contexts/ToastContext';
import { formatDisplayName } from '../../src/utils/formatDisplayName';
import GradientIconBox from '../../src/components/shared/GradientIconBox';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;
const LIGHT_SKY = colors.LIGHT_SKY;

interface Stats {
  totalBookings: number;
  ecoWashes: number;
  averageRating: number;
  completedServices: number;
}

const base64ToUint8Array = (base64: string) => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
  let str = base64.replace(/[^A-Za-z0-9+/=]/g, '');
  let output = '';
  let bc = 0;
  let bs: number;
  let buffer: string;
  let idx = 0;
  while ((buffer = str.charAt(idx++))) {
    const val = chars.indexOf(buffer);
    if (val === -1) continue;
    bs = bc % 4 ? (bs! * 64) + val : val;
    if (bc++ % 4) output += String.fromCharCode(255 & (bs >> ((-2 * bc) & 6)));
  }
  const bytes = new Uint8Array(output.length);
  for (let i = 0; i < output.length; i += 1) bytes[i] = output.charCodeAt(i);
  return bytes;
};

const getContentTypeAndExt = (uri: string) => {
  const extGuess = uri.split('?')[0].split('.').pop()?.toLowerCase();
  if (extGuess === 'png') return { contentType: 'image/png', ext: 'png' };
  if (extGuess === 'webp') return { contentType: 'image/webp', ext: 'webp' };
  if (extGuess === 'heic' || extGuess === 'heif') return { contentType: 'image/heic', ext: 'heic' };
  return { contentType: 'image/jpeg', ext: 'jpg' };
};

const uploadProfilePictureToSupabase = async (imageUri: string, userId: string) => {
  const base64 = await FileSystem.readAsStringAsync(imageUri, {
    encoding: FileSystem.EncodingType.Base64,
  });
  const bytes = base64ToUint8Array(base64);
  if (!bytes.length) throw new Error('Photo read failed (0 bytes). Please pick another image.');

  const { contentType, ext } = getContentTypeAndExt(imageUri);
  const filePath = `${userId}/profile_picture.${ext}`;

  // Upload (overwrite each time)
  const { error: uploadError } = await supabase.storage
    .from('uploads')
    .upload(filePath, bytes, {
      contentType,
      upsert: true,
    });

  if (uploadError) throw uploadError;

  // Get public URL
  const { data } = supabase.storage.from('uploads').getPublicUrl(filePath);
  if (!data?.publicUrl) throw new Error('Failed to get public URL');

  return data.publicUrl;
};


const cleanUrl = (u?: string | null) => {
  if (!u) return null;
  const s = String(u);
  return s.split('?')[0];
};

const toPublicAvatarUrl = (value?: string | null): string | null => {
  const raw = String(value || '').trim();
  if (!raw) return null;
  if (/^https?:\/\//i.test(raw)) return cleanUrl(raw);

  const path = raw.replace(/^\/+/, '');
  if (!path) return null;
  const { data } = supabase.storage.from('uploads').getPublicUrl(path);
  return cleanUrl(data?.publicUrl ?? null);
};

// ✅ Backwards-compatible mediaTypes for expo-image-picker
const getImagePickerMediaTypes = () => {
  const anyPicker: any = ImagePicker;
  if (anyPicker?.MediaType?.Images) return anyPicker.MediaType.Images;
  if (anyPicker?.MediaType?.Image) return [anyPicker.MediaType.Image];
  if (anyPicker?.MediaTypeOptions?.Images) return anyPicker.MediaTypeOptions.Images;
  return anyPicker?.MediaTypeOptions?.All ?? undefined;
};

// ✅ Resolve the actual avatar file in storage so we don’t assume profile_picture.jpg exists
const resolveAvatarUrl = async (userId: string): Promise<string | null> => {
  try {
    const folders = [`${userId}`, `users/${userId}`];
    let resolvedPath: string | null = null;

    for (const folder of folders) {
      const { data: files, error } = await supabase.storage
        .from('uploads')
        .list(folder, {
          limit: 50,
          offset: 0,
          // sortBy exists in newer supabase-js; safe to ignore if unsupported
          // @ts-ignore
          sortBy: { column: 'updated_at', order: 'desc' },
        } as any);

      if (error || !files || files.length === 0) continue;

      // Prefer profile_picture* if present, else newest file
      const preferred =
        (files as any[]).find((f) => String(f?.name || '').toLowerCase().startsWith('profile_picture')) ??
        (files as any[])[0];

      if (!preferred?.name) continue;
      resolvedPath = `${folder}/${preferred.name}`;
      break;
    }

    if (!resolvedPath) return null;

    const { data: publicData } = supabase.storage.from('uploads').getPublicUrl(resolvedPath);
    const url = publicData?.publicUrl;

    if (!url) return null;

    return `${cleanUrl(url)}?v=${Date.now()}`;
  } catch {
    return null;
  }
};

export default function OwnerProfile() {
  const scrollPad = useOwnerScrollContentPadding(true);
  const { user, logout, updateUser } = useAuth();
  const { showToast } = useToast();

  const [profileName, setProfileName] = useState<string>('');
  const [profileEmail, setProfileEmail] = useState<string>('');
  const [profilePicture, setProfilePicture] = useState<string | null>(null);
  const [uploadingPicture, setUploadingPicture] = useState(false);

  const [loading, setLoading] = useState(true);
  const [loadingStats, setLoadingStats] = useState(true);

  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const [stats, setStats] = useState<Stats>({
    totalBookings: 0,
    ecoWashes: 0,
    averageRating: 0,
    completedServices: 0,
  });

  // Fallback + cache
  const lastPickedUriRef = useRef<string | null>(null);
  const savedPublicUrlRef = useRef<string | null>(null);
  const lastFailedUrlRef = useRef<string | null>(null);

  const loadProfile = async (userId: string) => {
    try {
      // 1) Load profile data
      const { data: profileData, error } = await supabase
        .from('profiles')
        .select('full_name, profile_picture')
        .eq('id', userId)
        .maybeSingle();

      if (error) {
        console.warn('[profile] load error', error);
      }

      if (profileData) {
        setProfileName(profileData.full_name || user?.name || 'Customer');

        // 2) Always use the Supabase profile value first
        if (profileData.profile_picture) {
          const clean = toPublicAvatarUrl(profileData.profile_picture);
          if (clean) {
            setProfilePicture(`${clean}?v=${Date.now()}`);
            savedPublicUrlRef.current = clean;
          } else {
            setProfilePicture(null);
            savedPublicUrlRef.current = null;
          }
        } else {
          const resolved = await resolveAvatarUrl(userId);
          const clean = cleanUrl(resolved);
          if (clean) {
            setProfilePicture(`${clean}?v=${Date.now()}`);
            savedPublicUrlRef.current = clean;
          } else {
            setProfilePicture(null);
            savedPublicUrlRef.current = null;
          }
        }
      } else {
        setProfileName(user?.name || 'Customer');
        setProfilePicture(null);
        savedPublicUrlRef.current = null;
      }

      setProfileEmail(user?.email || '');
    } catch (err) {
      console.error('[profile] load error', err);
    }
  };


  const loadStats = async (userId: string) => {
    setLoadingStats(true);
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('id, status, completed_at, service_type, rating')
        .eq('user_id', userId);

      if (error) throw error;

      const rows = data ?? [];
      const completed = rows.filter((b: any) => b?.status === 'completed' || b?.completed_at != null);

      const totalBookings = completed.length;
      const completedServices = completed.length;
      const ecoWashes = completed.filter((b: any) =>
        String(b?.service_type || '').toLowerCase().includes('eco')
      ).length;

      const ratings = completed
        .map((b: any) => Number(b.rating))
        .filter((n: number) => Number.isFinite(n) && n >= 1 && n <= 5);

      const averageRating =
        ratings.length > 0 ? ratings.reduce((a: number, b: number) => a + b, 0) / ratings.length : 0;

      setStats({
        totalBookings,
        ecoWashes,
        averageRating,
        completedServices,
      });
    } catch (error) {
      console.error('Error loading stats:', error);
      setStats({
        totalBookings: 0,
        ecoWashes: 0,
        averageRating: 0,
        completedServices: 0,
      });
    } finally {
      setLoadingStats(false);
    }
  };

  useEffect(() => {
    if (!user?.id) return;

    const loadAll = async () => {
      setLoading(true);
      try {
        await loadProfile(user.id);
        await loadStats(user.id);
      } finally {
        setLoading(false);
      }
    };

    loadAll();
  }, [user?.id]);

  const handlePickImage = async () => {
    if (!user?.id) return;

    try {
      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted) {
        Alert.alert('Permission needed', 'Please allow photo library access.');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: getImagePickerMediaTypes(),
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      } as any);

      if ((result as any).canceled || !(result as any).assets?.[0]?.uri) return;

      const imageUri = (result as any).assets[0].uri as string;
      lastPickedUriRef.current = imageUri;
      setProfilePicture(imageUri);
      setUploadingPicture(true);

      // Upload to Supabase storage and persist URL on profile row.
      const uploadedUrl = await uploadProfilePictureToSupabase(imageUri, user.id);
      const clean = cleanUrl(uploadedUrl);
      if (!clean) throw new Error('Could not resolve uploaded photo URL');

      const { error: profileError } = await supabase
        .from('profiles')
        .update({ profile_picture: clean })
        .eq('id', user.id);

      if (profileError) throw profileError;

      savedPublicUrlRef.current = clean;
      setProfilePicture(`${clean}?v=${Date.now()}`);
      lastPickedUriRef.current = null;

      // Best-effort context sync; profile row is already saved.
      if (updateUser) {
        try {
          await updateUser({ profilePicture: clean });
        } catch (syncErr) {
          console.warn('[profile] updateUser(profilePicture) failed:', syncErr);
        }
      }
    } catch (err: any) {
      console.error('[profile] image upload error', err);
      Alert.alert('Error', err?.message || 'Failed to upload profile picture');
      if (savedPublicUrlRef.current) {
        setProfilePicture(`${savedPublicUrlRef.current}?v=${Date.now()}`);
      }
    } finally {
      setUploadingPicture(false);
    }
  };


  const handleSaveProfile = async () => {
    if (!user?.id) return;

    try {
      setIsSaving(true);

      let avatarUrlClean = savedPublicUrlRef.current ?? cleanUrl(profilePicture);

      // Safety net in case a local URI is still pending.
      if (profilePicture && !String(profilePicture).startsWith('http')) {
        setUploadingPicture(true);
        const uploadedUrl = await uploadProfilePictureToSupabase(profilePicture, user.id);
        avatarUrlClean = cleanUrl(uploadedUrl);
        savedPublicUrlRef.current = avatarUrlClean;
        if (avatarUrlClean) setProfilePicture(`${avatarUrlClean}?v=${Date.now()}`);

        setUploadingPicture(false);
      }

      // Update profile in profiles table (name + profile_picture)
      const updateData: { full_name: string; profile_picture?: string | null } = { 
        full_name: profileName,
      };
      if (avatarUrlClean?.startsWith('http')) updateData.profile_picture = avatarUrlClean;

      const { error: profileError } = await supabase.from('profiles').update(updateData).eq('id', user.id);
      if (profileError) throw profileError;

      // Update email if changed (requires auth update)
      if (profileEmail !== user.email) {
        const { error: emailError } = await supabase.auth.updateUser({ email: profileEmail });
        if (emailError) {
          Alert.alert('Email Update', 'Email verification sent to new email address. Please check your inbox.', [{ text: 'OK' }]);
        }
      }

      // Best-effort context sync; DB/auth updates above are source of truth.
      if (updateUser) {
        try {
          await updateUser({
            name: profileName,
            email: profileEmail,
            ...(avatarUrlClean?.startsWith('http') && { profilePicture: avatarUrlClean }),
          });
        } catch (syncErr) {
          console.warn('[profile] updateUser(save) failed:', syncErr);
        }
      }

      setIsEditing(false);
      showToast('Profile updated successfully!', 'success');
    } catch (error: any) {
      console.error('Error saving profile:', error);
      Alert.alert('Error', error?.message || 'Failed to save profile');
    } finally {
      setIsSaving(false);
      setUploadingPicture(false);
    }
  };

  const handleCancel = async () => {
    setProfileName(user?.name || '');
    setProfileEmail(user?.email || '');
    setIsEditing(false);

    // Reload from DB/storage to restore saved avatar and display name
    if (user?.id) {
      await loadProfile(user.id);
    }
  };

  const handleLogout = async () => {
    await logout();
    router.replace('/auth/login');
  };

  const renderProfileImageContent = () => {
    if (uploadingPicture) {
      return (
        <View style={styles.profilePicturePlaceholder}>
          <ActivityIndicator size="large" color={SKY} />
        </View>
      );
    }
    if (profilePicture) {
      return (
        <Image
          source={{ uri: profilePicture }}
          style={[styles.profilePicture, uploadingPicture && { opacity: 0.6 }]}
          onError={async () => {
            const failedClean = cleanUrl(profilePicture);
            if (lastFailedUrlRef.current !== failedClean) {
              lastFailedUrlRef.current = failedClean;
              if (__DEV__) {
                console.warn('[profile] avatar image failed to load, using placeholder');
              }
            }
            if (lastPickedUriRef.current) {
              setProfilePicture(lastPickedUriRef.current);
              return;
            }
            if (user?.id) {
              const resolved = await resolveAvatarUrl(user.id);
              const resolvedClean = cleanUrl(resolved);
              if (resolvedClean && resolvedClean !== failedClean) {
                setProfilePicture(resolved);
                return;
              }
            }
            setProfilePicture(null);
          }}
        />
      );
    }
    return (
      <View style={styles.profilePicturePlaceholder}>
        <GradientIconBox icon="person" preset="sky" boxSize={94} size={44} borderRadius={47} elevated />
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      <AppHeader
        title="Profile"
        subtitle="Account, preferences and activity"
        showBack
        onBack={() => { hapticFeedback('light'); router.back(); }}
        accountType="customer"
        {...(!loading
          ? {
              rightAction: (
                <TouchableOpacity
                  onPress={() => {
                    if (isEditing) handleCancel();
                    else setIsEditing(true);
                  }}
                  style={styles.editButton}
                  accessibilityRole="button"
                  accessibilityLabel={isEditing ? 'Cancel editing profile' : 'Edit profile'}
                >
                  <Text style={styles.editButtonText}>{isEditing ? 'Cancel' : 'Edit'}</Text>
                </TouchableOpacity>
              ),
            }
          : {})}
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, scrollPad]}
        showsVerticalScrollIndicator={false}
      >
        {loading ? (
          <View style={styles.profileLoadingWrap}>
            <SkeletonList count={7} />
          </View>
        ) : (
          <>
        {/* Profile Picture Section */}
        <View style={styles.profileSection}>
          <TouchableOpacity
            onPress={handlePickImage}
            style={styles.profilePictureContainer}
            disabled={uploadingPicture}
            activeOpacity={0.85}
            accessibilityRole="button"
            accessibilityLabel="Profile photo. Tap to change picture"
          >
            {renderProfileImageContent()}

            {!uploadingPicture && (
              <View style={styles.editBadge}>
                <Ionicons name="camera" size={14} color={BG} />
              </View>
            )}
          </TouchableOpacity>

          {isEditing ? (
            <>
              <TextInput
              style={styles.profileNameInput}
              value={profileName}
              onChangeText={setProfileName}
              placeholder="Enter your name"
              placeholderTextColor="#64748B"
            />
              <TextInput
                style={styles.profileEmailInput}
                value={profileEmail}
                onChangeText={setProfileEmail}
                placeholder="Enter your email"
                placeholderTextColor="#64748B"
                keyboardType="email-address"
                autoCapitalize="none"
              />
            </>
          ) : (
            <>
              <Text style={styles.profileName}>{formatDisplayName(profileName)}</Text>
              <Text style={styles.profileEmail}>{profileEmail}</Text>
            </>
          )}
        </View>

        {/* Analytics Section */}
        <View style={styles.analyticsSection}>
          <View style={styles.analyticsHeader}>
            <Text style={styles.sectionTitle}>Analytics</Text>
          </View>

          <View style={styles.analyticsCard}>
            <View style={styles.analyticsCardContent}>
              <View style={styles.analyticsIconWrapper}>
                <GradientIconBox icon="analytics" preset="cyan" boxSize={52} size={24} elevated />
              </View>
              <View style={styles.analyticsContent}>
                <Text style={styles.analyticsTitle}>Your Activity</Text>
                <Text style={styles.analyticsSubtitle}>Stats based on completed bookings</Text>

                {loadingStats ? (
                  <View style={styles.analyticsStatsRow}>
                    <ActivityIndicator size="small" color={SKY} />
                  </View>
                ) : (
                  <View style={styles.analyticsStatsRow}>
                    <View style={styles.analyticsStatItem}>
                      <Text style={styles.analyticsStatValue}>{stats.completedServices}</Text>
                      <Text style={styles.analyticsStatLabel}>Completed</Text>
                    </View>
                    <View style={styles.analyticsDivider} />
                    <View style={styles.analyticsStatItem}>
                      <Text style={styles.analyticsStatValue}>{stats.ecoWashes}</Text>
                      <Text style={styles.analyticsStatLabel}>Eco Washes</Text>
                    </View>
                    <View style={styles.analyticsDivider} />
                    <View style={styles.analyticsStatItem}>
                      <Text style={styles.analyticsStatValue}>{stats.averageRating.toFixed(1)}</Text>
                      <Text style={styles.analyticsStatLabel}>Avg Rating</Text>
                    </View>
                  </View>
                )}
              </View>
            </View>
          </View>
        </View>

        {/* Menu Items */}
        <View style={styles.menuSection}>
          <TouchableOpacity
            style={styles.menuItem}
            onPress={() => router.push('/owner/settings/appearance')}
            accessibilityRole="button"
            accessibilityLabel="Appearance. Theme and legal"
          >
            <View style={styles.menuIconWrapper}>
              <GradientIconBox icon="color-palette-outline" preset="sky" boxSize={36} size={18} elevated />
            </View>
            <View style={styles.menuContent}>
              <Text style={styles.menuTitle}>Appearance</Text>
              <Text style={styles.menuSubtitle}>Light & dark mode, legal</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="rgba(148,163,184,0.75)" />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.menuItem}
            onPress={() => router.push('/owner/features/referral-system')}
            accessibilityRole="button"
            accessibilityLabel="Referrals. Invite friends and earn rewards"
          >
            <View style={styles.menuIconWrapper}>
              <GradientIconBox icon="people" preset="purple" boxSize={36} size={18} elevated />
            </View>
            <View style={styles.menuContent}>
              <Text style={styles.menuTitle}>Referrals</Text>
              <Text style={styles.menuSubtitle}>Invite friends, earn rewards</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="rgba(148,163,184,0.75)" />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.menuItem}
            onPress={() => router.push('/owner/features/rewards')}
            accessibilityRole="button"
            accessibilityLabel="Rewards. Points, tiers and perks"
          >
            <View style={styles.menuIconWrapper}>
              <GradientIconBox icon="gift" preset="amber" boxSize={36} size={18} elevated />
            </View>
            <View style={styles.menuContent}>
              <Text style={styles.menuTitle}>Rewards</Text>
              <Text style={styles.menuSubtitle}>Points, tiers & perks</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="rgba(148,163,184,0.75)" />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.menuItem}
            onPress={() => router.push('/owner/settings/vehicle-management')}
            accessibilityRole="button"
            accessibilityLabel="My vehicles. Manage your vehicles"
          >
            <View style={styles.menuIconWrapper}>
              <GradientIconBox icon="car" preset="blue" boxSize={36} size={18} elevated />
            </View>
            <View style={styles.menuContent}>
              <Text style={styles.menuTitle}>My Vehicles</Text>
              <Text style={styles.menuSubtitle}>Manage your vehicles</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="rgba(148,163,184,0.75)" />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.menuItem}
            onPress={() => router.push('/owner/settings/payment-methods')}
            accessibilityRole="button"
            accessibilityLabel="Payment methods. Cards and payment options"
          >
            <View style={styles.menuIconWrapper}>
              <GradientIconBox icon="card-outline" preset="teal" boxSize={36} size={18} elevated />
            </View>
            <View style={styles.menuContent}>
              <Text style={styles.menuTitle}>Payment Methods</Text>
              <Text style={styles.menuSubtitle}>Cards & payment options</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="rgba(148,163,184,0.75)" />
          </TouchableOpacity>

        </View>

        {/* Save Button */}
        {isEditing && (
          <TouchableOpacity style={styles.saveButton} onPress={handleSaveProfile} disabled={isSaving}>
            <LinearGradient colors={[SKY, '#0EA5E9']} style={styles.saveGradient}>
              {isSaving ? (
                <ActivityIndicator size="small" color={LIGHT_SKY} />
              ) : (
                <>
                  <Ionicons name="checkmark" size={18} color={LIGHT_SKY} />
                  <Text style={styles.saveText}>Save Changes</Text>
                </>
              )}
            </LinearGradient>
          </TouchableOpacity>
        )}

        {/* Logout Button */}
        <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
          <LinearGradient colors={['#EF4444', '#DC2626']} style={styles.logoutGradient}>
            <Ionicons name="log-out" size={18} color={LIGHT_SKY} />
            <Text style={styles.logoutText}>Log Out</Text>
          </LinearGradient>
        </TouchableOpacity>
          </>
        )}
      </ScrollView>

    </SafeAreaView>
  );
}

// styles
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 120, paddingHorizontal: isSmallScreen ? 12 : 20 },
  profileLoadingWrap: { paddingTop: 12 },

  editButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 12,
    backgroundColor: 'rgba(15,23,42,0.5)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.18,
    shadowRadius: 6,
  },
  editButtonText: { color: '#60A5FA', fontSize: 14, fontWeight: '600' },

  profileSection: { alignItems: 'center', marginBottom: 32, marginTop: 20 },
  profilePictureContainer: { position: 'relative', marginBottom: 16 },
  profilePicture: { width: 100, height: 100, borderRadius: 50, borderWidth: 2.5, borderColor: SKY },
  profilePicturePlaceholder: {
    width: 100,
    height: 100,
    borderRadius: 50,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2.5,
    borderColor: SKY,
  },
  editBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2.5,
    borderColor: BG,
  },

  profileName: { color: colors.LIGHT_SKY, fontSize: isSmallScreen ? 20 : 22, fontWeight: 'bold', marginBottom: 6 },
  profileEmail: { color: colors.LIGHT_SKY, fontSize: isSmallScreen ? 12 : 14, fontWeight: '600' },

  profileNameInput: {
    color: colors.LIGHT_SKY,
    fontSize: isSmallScreen ? 24 : 28,
    fontWeight: 'bold',
    marginBottom: 8,
    textAlign: 'center',
    borderBottomWidth: 1,
    borderBottomColor: SKY,
    paddingBottom: 4,
    minWidth: 200,
  },
  profileEmailInput: {
    color: colors.LIGHT_SKY,
    fontSize: isSmallScreen ? 14 : 16,
    fontWeight: '600',
    textAlign: 'center',
    borderBottomWidth: 1,
    borderBottomColor: colors.LIGHT_SKY,
    paddingBottom: 4,
    minWidth: 200,
  },

  saveButton: {
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 10,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  saveGradient: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 12, gap: 8 },
  saveText: { color: LIGHT_SKY, fontSize: isSmallScreen ? 14 : 15, fontWeight: '700' },

  menuSection: { marginBottom: 32, gap: 10 },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(15,23,42,0.46)',
    borderRadius: 16,
    paddingVertical: 14,
    paddingHorizontal: 14,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.22)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.12,
    shadowRadius: 6,
    elevation: 2,
  },

  menuIconWrapper: {
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  menuContent: { flex: 1 },
  menuTitle: { color: colors.LIGHT_SKY, fontSize: isSmallScreen ? 14 : 15, fontWeight: '700', marginBottom: 2 },
  menuSubtitle: { color: SKY, fontSize: 11, fontWeight: '600' },

  logoutButton: {
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 16,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  logoutGradient: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 12, gap: 8 },
  logoutText: { color: LIGHT_SKY, fontSize: isSmallScreen ? 14 : 15, fontWeight: '700' },

  statsSection: { marginBottom: 32 },
  sectionTitle: { color: colors.LIGHT_SKY, fontSize: isSmallScreen ? 18 : 20, fontWeight: 'bold', marginBottom: 16 },

  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: 12 },
  statCard: {
    width: (width - (isSmallScreen ? 36 : 40)) / 2 - 6,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
  },
  statCardContent: { flexDirection: 'row', alignItems: 'center', padding: 14, gap: 12 },
  statIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  statIconWrapperGold: { backgroundColor: 'rgba(245,158,11,0.15)', borderColor: 'rgba(245,158,11,0.3)' },
  statIconWrapperGreen: { backgroundColor: 'rgba(16,185,129,0.15)', borderColor: 'rgba(16,185,129,0.3)' },
  statTextContainer: { flex: 1 },
  statNumber: { fontSize: isSmallScreen ? 20 : 22, fontWeight: '800', color: colors.LIGHT_SKY, marginBottom: 2, letterSpacing: -0.3 },
  statLabel: { fontSize: 11, color: SKY, fontWeight: '600', letterSpacing: 0.2 },

  analyticsSection: { marginBottom: 32 },
  analyticsHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  analyticsCard: {
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    overflow: 'hidden',
  },
  analyticsCardContent: { flexDirection: 'row', padding: 18, gap: 16 },
  analyticsIconWrapper: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  analyticsContent: { flex: 1 },
  analyticsTitle: { fontSize: 18, fontWeight: '700', color: colors.LIGHT_SKY, marginBottom: 4, letterSpacing: -0.3 },
  analyticsSubtitle: { fontSize: 12, color: SKY, marginBottom: 16, opacity: 0.8 },

  analyticsStatsRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 16 },
  analyticsStatItem: { flex: 1, alignItems: 'center' },
  analyticsStatValue: { fontSize: 20, fontWeight: '800', color: colors.LIGHT_SKY, marginBottom: 4, letterSpacing: -0.3 },
  analyticsStatLabel: { fontSize: 10, color: SKY, fontWeight: '600', opacity: 0.8 },
  analyticsDivider: { width: 1, height: 32, backgroundColor: 'rgba(135,206,235,0.2)', marginHorizontal: 8 },

});
