import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  TextInput,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import AppHeader from '../../../src/components/shared/AppHeader';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { useOwnerScrollContentPadding } from '../../../src/hooks/useOwnerScrollContentPadding';
import { CONTENT_PADDING_H, SECTION_GAP } from '../../../src/constants/pageStyles';
import { colors } from '../../../src/constants/colors';
import GradientIconBox from '../../../src/components/shared/GradientIconBox';
import { accentToGradient } from '../../../src/utils/accentGradient';
import { BORDER_RADIUS, FONT_SIZES, SPACING } from '../../../src/constants/designTokens';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;

export default function ReportIssue() {
  const scrollPad = useOwnerScrollContentPadding(true);
  useAuth();
  const [issueType, setIssueType] = useState('');
  const [issueDescription, setIssueDescription] = useState('');
  const [bookingId, setBookingId] = useState('');

  const issueTypes = [
    { id: 'service', label: 'Service Issue', icon: 'car' },
    { id: 'payment', label: 'Payment Problem', icon: 'card' },
    { id: 'valeter', label: 'Valeter Issue', icon: 'person' },
    { id: 'app', label: 'App Problem', icon: 'phone-portrait' },
    { id: 'other', label: 'Other', icon: 'help-circle' },
  ];

  const handleSubmit = () => {
    if (!issueType || !issueDescription) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }
    Alert.alert('Success', 'Your issue has been reported. We\'ll get back to you soon!');
    router.back();
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      <AppHeader
        title="Report Issue"
        subtitle="Tell us what happened"
        variant="dashboard"
        accountType="customer"
        showBack
        onBack={() => { hapticFeedback('light'); router.back(); }}
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingHorizontal: CONTENT_PADDING_H, ...scrollPad }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Issue Type Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Issue Type *</Text>
          <View style={styles.typeGrid}>
            {issueTypes.map((type) => (
              <TouchableOpacity
                key={type.id}
                style={[
                  styles.typeCard,
                  issueType === type.id && styles.typeCardSelected,
                ]}
                onPress={() => setIssueType(type.id)}
              >
                <GradientIconBox
                  icon={type.icon as keyof typeof Ionicons.glyphMap}
                  colors={
                    issueType === type.id ? accentToGradient('#0A1929') : accentToGradient(SKY)
                  }
                  boxSize={44}
                  size={22}
                  borderRadius={14}
                  elevated
                />
                <Text
                  style={[
                    styles.typeLabel,
                    issueType === type.id && styles.typeLabelSelected,
                  ]}
                >
                  {type.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Booking ID */}
        <View style={styles.section}>
          <Text style={styles.inputLabel}>Booking ID (Optional)</Text>
          <TextInput
            style={styles.input}
            value={bookingId}
            onChangeText={setBookingId}
            placeholder="Enter booking ID if related"
            placeholderTextColor="#6B7280"
          />
        </View>

        {/* Description */}
        <View style={styles.section}>
          <Text style={styles.inputLabel}>Description *</Text>
          <TextInput
            style={[styles.input, styles.textArea]}
            value={issueDescription}
            onChangeText={setIssueDescription}
            placeholder="Please describe the issue in detail..."
            placeholderTextColor="#6B7280"
            multiline
            numberOfLines={6}
            textAlignVertical="top"
          />
        </View>

        {/* Submit Button */}
        <TouchableOpacity style={styles.submitButton} onPress={handleSubmit}>
          <LinearGradient colors={[SKY, '#0EA5E9']} style={styles.submitGradient}>
            <Ionicons name="send" size={20} color="#0A1929" />
            <Text style={styles.submitText}>Submit Report</Text>
          </LinearGradient>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 120, paddingHorizontal: isSmallScreen ? SPACING.md : SPACING.xl },
  section: {
    marginBottom: SECTION_GAP,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? FONT_SIZES.base : FONT_SIZES.lg,
    fontWeight: '700',
    marginBottom: SPACING.md,
  },
  typeGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  typeCard: {
    width: (width - (isSmallScreen ? 48 : 60)) / 2 - 6,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
    elevation: 4,
  },
  typeCardSelected: {
    backgroundColor: SKY,
    borderColor: SKY,
  },
  typeLabel: {
    color: '#F9FAFB',
    fontSize: 13,
    fontWeight: '700',
    marginTop: 8,
    textAlign: 'center',
  },
  typeLabelSelected: {
    color: '#0A1929',
  },
  inputLabel: {
    color: '#87CEEB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 8,
  },
  input: {
    backgroundColor: 'rgba(15,23,42,0.5)',
    borderRadius: BORDER_RADIUS.md,
    padding: SPACING.lg,
    color: '#F9FAFB',
    fontSize: FONT_SIZES.base,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 1,
  },
  textArea: {
    minHeight: 120,
    paddingTop: 14,
  },
  submitButton: {
    borderRadius: BORDER_RADIUS.md,
    overflow: 'hidden',
    marginTop: 8,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 8,
  },
  submitGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    gap: 8,
  },
  submitText: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: '700',
  },
});

