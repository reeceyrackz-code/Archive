import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  Pressable,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import MapView, { MapPressEvent, Region } from 'react-native-maps';
import * as Location from 'expo-location';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  CUSTOMER_SAVED_LOCATIONS_KEY,
  loadCustomerSavedLocations,
  type CustomerSavedLocation,
} from '../../../src/utils/customerSavedLocations';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import AppHeader from '../../../src/components/shared/AppHeader';
import EmptyState from '../../../src/components/shared/EmptyState';
import LoadingScreen from '../../../src/components/LoadingScreen';
import GlassCard from '@/components/booking/GlassCard';
import GradientIconBox from '../../../src/components/shared/GradientIconBox';
import { colors } from '../../../src/constants/colors';
import { useOwnerScrollContentPadding } from '../../../src/hooks/useOwnerScrollContentPadding';
import { CONTENT_PADDING_H } from '../../../src/constants/pageStyles';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { LOCATION_PICKER_MAP_STYLE, MAP_LOCKED_DARK } from '../../../src/constants/mapConstants';
import { BORDER_RADIUS, FONT_SIZES, SPACING } from '../../../src/constants/designTokens';

const SKY = colors.SKY;

type LocationLabelId = CustomerSavedLocation['label'];
type SavedLocation = CustomerSavedLocation;

const LABELS: { id: LocationLabelId; icon: string; title: string }[] = [
  { id: 'home', icon: 'home', title: 'Home' },
  { id: 'work', icon: 'briefcase', title: 'Work' },
  { id: 'gym', icon: 'barbell', title: 'Gym' },
  { id: 'other', icon: 'location', title: 'Other' },
];

async function saveLocations(userId: string, locations: SavedLocation[]) {
  await AsyncStorage.setItem(`${CUSTOMER_SAVED_LOCATIONS_KEY}_${userId}`, JSON.stringify(locations));
}

export default function SavedLocations() {
  const scrollPad = useOwnerScrollContentPadding(true);
  const { user } = useAuth();
  const [locations, setLocations] = useState<SavedLocation[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<SavedLocation | null>(null);
  const [editLabel, setEditLabel] = useState<LocationLabelId>('home');
  const [editAddress, setEditAddress] = useState('');
  const [editLat, setEditLat] = useState<number>(51.5074);
  const [editLng, setEditLng] = useState<number>(-0.1278);
  const [addressSearching, setAddressSearching] = useState(false);
  const [searchDone, setSearchDone] = useState(false);
  const userEditedAddressRef = useRef(false);
  const editMapRef = useRef<MapView>(null);

  useEffect(() => {
    if (!user?.id) return;
    loadCustomerSavedLocations(user.id).then((list) => {
      setLocations(list);
      setLoading(false);
    });
  }, [user?.id]);

  const openAdd = async (label: LocationLabelId) => {
    await hapticFeedback('light');
    userEditedAddressRef.current = false;
    setSearchDone(false);
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission needed', 'Location permission is required.');
        return;
      }
      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const [result] = await Location.reverseGeocodeAsync(loc.coords);
      const addr = result
        ? `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim() || 'Current location'
        : 'Current location';

      setEditLabel(label);
      setEditAddress(addr);
      setEditLat(loc.coords.latitude);
      setEditLng(loc.coords.longitude);
      setEditing({
        id: `new-${Date.now()}`,
        label,
        address: addr,
        latitude: loc.coords.latitude,
        longitude: loc.coords.longitude,
      });
    } catch {
      Alert.alert('Error', 'Could not get location.');
    }
  };

  const openEdit = (loc: SavedLocation) => {
    hapticFeedback('light');
    userEditedAddressRef.current = false;
    setSearchDone(true);
    setEditing(loc);
    setEditLabel(loc.label);
    setEditAddress(loc.address);
    setEditLat(loc.latitude);
    setEditLng(loc.longitude);
  };

  const handleMapPress = async (e: MapPressEvent) => {
    const { latitude, longitude } = e.nativeEvent.coordinate;
    setEditLat(latitude);
    setEditLng(longitude);
    if (userEditedAddressRef.current) return;
    try {
      const [result] = await Location.reverseGeocodeAsync({ latitude, longitude });
      const addr = result
        ? `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim() || 'Selected location'
        : 'Selected location';
      setEditAddress(addr);
    } catch {}
  };

  const handleAddressChange = (text: string) => {
    userEditedAddressRef.current = true;
    setEditAddress(text);
    setSearchDone(false);
  };

  const handleAddressSearch = async () => {
    const q = editAddress.trim();
    if (!q) return;
    await hapticFeedback('light');
    setAddressSearching(true);
    try {
      const results = await Location.geocodeAsync(q);
      if (results?.length && results.length > 0) {
        const { latitude, longitude } = results[0];
        setEditLat(latitude);
        setEditLng(longitude);
        const [rev] = await Location.reverseGeocodeAsync({ latitude, longitude });
        const addr = rev
          ? `${rev.street || ''} ${rev.city || ''} ${rev.postalCode || ''}`.trim() || q
          : q;
        setEditAddress(addr);
        setSearchDone(true);
        editMapRef.current?.animateToRegion(
          { latitude, longitude, latitudeDelta: 0.001, longitudeDelta: 0.001 },
          350
        );
      } else {
        Alert.alert('Address not found', 'Try a different address or more specific search.');
      }
    } catch (e) {
      Alert.alert('Search failed', (e as Error)?.message || 'Could not find that address.');
    } finally {
      setAddressSearching(false);
    }
  };

  const saveLocation = async () => {
    if (!user?.id || !editAddress.trim()) return;
    await hapticFeedback('medium');

    const updated: SavedLocation = {
      id: editing!.id,
      label: editLabel,
      address: editAddress.trim(),
      latitude: editLat,
      longitude: editLng,
    };

    const isNew = editing!.id.startsWith('new-');
    let next: SavedLocation[];

    if (isNew) {
      if (editLabel !== 'other' && locations.some((l) => l.label === editLabel)) {
        Alert.alert('Already saved', `You already have a ${editLabel} location. Edit it instead.`);
        return;
      }
      next = [...locations, { ...updated, id: `loc-${Date.now()}` }];
    } else {
      next = locations.map((l) => (l.id === editing!.id ? updated : l));
    }

    setLocations(next);
    await saveLocations(user.id, next);
    setEditing(null);
  };

  const performRemoveLocation = async (id: string) => {
    if (!user?.id) return;
    const next = locations.filter((l) => l.id !== id);
    setLocations(next);
    await saveLocations(user.id, next);
    if (editing?.id === id) setEditing(null);
  };

  const deleteLocation = (id: string) => {
    Alert.alert('Remove location?', 'This cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: () => { void performRemoveLocation(id); },
      },
    ]);
  };

  /** List rows use a single title; internal label (home/work/…) is only for add-slot logic. */
  const SAVED_LOCATION_ROW_TITLE = 'Saved location';

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LoadingScreen />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <AppHeader title="Saved Locations" accountType="customer" showBack onBack={() => router.back()} />

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={[styles.scrollContent, { paddingHorizontal: CONTENT_PADDING_H, ...scrollPad }]}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <Text style={styles.subtitle}>Save addresses you use often. They’ll appear here as saved locations for quicker booking.</Text>

        {locations.length === 0 && (
          <EmptyState
            icon="location-outline"
            title="No saved locations"
            subtitle="Add a saved location below to use when booking."
            iconColor={SKY}
            style={styles.emptyState}
          />
        )}

        {locations.map((loc) => (
          <GlassCard key={loc.id} style={styles.card} borderRadius={16} accountType="customer">
            <View style={styles.cardRow}>
              <View style={styles.cardIcon}>
                <GradientIconBox icon="bookmark-outline" preset="sky" boxSize={44} size={22} borderRadius={14} elevated />
              </View>
              <View style={styles.cardText}>
                <Text style={styles.cardTitle}>{SAVED_LOCATION_ROW_TITLE}</Text>
                <Text style={styles.cardAddress} numberOfLines={2}>{loc.address}</Text>
              </View>
              <TouchableOpacity onPress={() => openEdit(loc)} style={styles.iconBtn} hitSlop={12} activeOpacity={0.7}>
                <Ionicons name="pencil" size={18} color={SKY} />
              </TouchableOpacity>
              <TouchableOpacity onPress={() => deleteLocation(loc.id)} style={styles.deleteIconBtn} hitSlop={12} activeOpacity={0.7}>
                <Ionicons name="trash-outline" size={20} color="#EF4444" />
              </TouchableOpacity>
            </View>
          </GlassCard>
        ))}

        <Text style={styles.sectionTitle}>Add location</Text>
        <View style={styles.addGrid}>
          {LABELS.map((l) => {
            const canAdd = l.id === 'other' || !locations.some((x) => x.label === l.id);
            return (
              <TouchableOpacity
                key={l.id}
                style={[styles.addBtn, !canAdd && styles.addBtnDisabled]}
                onPress={() => canAdd && openAdd(l.id)}
                disabled={!canAdd}
                activeOpacity={0.8}
                hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
              >
                <View style={[styles.addIcon, !canAdd && styles.addIconDisabled]}>
                  <GradientIconBox
                    icon={l.icon as keyof typeof Ionicons.glyphMap}
                    preset={canAdd ? 'sky' : 'gray'}
                    boxSize={44}
                    size={22}
                    borderRadius={14}
                    elevated={canAdd}
                  />
                </View>
                <Text style={[styles.addLabel, !canAdd && styles.addLabelDisabled]}>{l.title}</Text>
                {!canAdd && <Text style={styles.addHint}>Saved</Text>}
              </TouchableOpacity>
            );
          })}
        </View>
      </ScrollView>

      {editing && (
        <Pressable style={styles.modal} onPress={() => setEditing(null)}>
          <KeyboardAvoidingView
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
            style={styles.modalInner}
          >
            <Pressable style={styles.modalContent} onPress={(e) => e.stopPropagation()}>
              <Text style={styles.modalTitle}>{editing.id.startsWith('new-') ? 'Add saved location' : 'Edit saved location'}</Text>
              <View style={styles.editMapWrap}>
                <MapView
                  ref={editMapRef}
                  style={styles.map}
                  region={{
                    latitude: editLat,
                    longitude: editLng,
                    latitudeDelta: 0.001,
                    longitudeDelta: 0.001,
                  }}
                  onPress={handleMapPress}
                  customMapStyle={LOCATION_PICKER_MAP_STYLE}
                  userInterfaceStyle={MAP_LOCKED_DARK}
                />
                <TouchableOpacity
                  onPress={() => {
                    hapticFeedback('light');
                    const r: Region = { latitude: editLat, longitude: editLng, latitudeDelta: 0.001, longitudeDelta: 0.001 };
                    editMapRef.current?.animateToRegion(r, 350);
                  }}
                  style={styles.editMapRecenterButton}
                  activeOpacity={0.7}
                >
                  <Ionicons name="locate" size={20} color={SKY} />
                </TouchableOpacity>
              </View>
              <TextInput
                style={styles.input}
                value={editAddress}
                onChangeText={handleAddressChange}
                onSubmitEditing={searchDone ? undefined : handleAddressSearch}
                placeholder="Address"
                placeholderTextColor={colors.inputPlaceholderMuted}
              />
              <View style={styles.modalBtns}>
                <TouchableOpacity style={styles.cancelBtn} onPress={() => setEditing(null)} hitSlop={12}>
                  <Text style={styles.cancelText}>Cancel</Text>
                </TouchableOpacity>
                {searchDone ? (
                  <TouchableOpacity style={styles.saveBtn} onPress={saveLocation} disabled={!editAddress.trim()} hitSlop={12} activeOpacity={0.85}>
                    <LinearGradient colors={[SKY, '#0EA5E9']} style={styles.saveGrad}>
                      <Text style={styles.saveText}>Save</Text>
                    </LinearGradient>
                  </TouchableOpacity>
                ) : (
                  <TouchableOpacity
                    style={styles.saveBtn}
                    onPress={handleAddressSearch}
                    disabled={!editAddress.trim() || addressSearching}
                    hitSlop={12}
                    activeOpacity={0.85}
                  >
                    <LinearGradient colors={[SKY, '#0EA5E9']} style={styles.saveGrad}>
                      {addressSearching ? (
                        <Text style={styles.saveText}>Searching…</Text>
                      ) : (
                        <Text style={styles.saveText}>Search</Text>
                      )}
                    </LinearGradient>
                  </TouchableOpacity>
                )}
              </View>
            </Pressable>
          </KeyboardAvoidingView>
        </Pressable>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  scroll: { flex: 1 },
  scrollContent: {},
  subtitle: { color: '#94A3B8', fontSize: 14, marginBottom: 20 },
  emptyState: { minHeight: 200, marginBottom: 16 },
  card: { padding: SPACING.lg, marginBottom: SPACING.md },
  cardRow: { flexDirection: 'row', alignItems: 'center' },
  cardIcon: {
    marginRight: 12,
  },
  cardText: { flex: 1, minWidth: 0 },
  cardTitle: { color: '#F9FAFB', fontSize: FONT_SIZES.base, fontWeight: '700', marginBottom: SPACING.xs },
  cardAddress: { color: '#94A3B8', fontSize: FONT_SIZES.sm + 1 },
  iconBtn: { padding: 8 },
  deleteIconBtn: {
    padding: 8,
    borderRadius: 10,
    backgroundColor: 'rgba(239,68,68,0.1)',
  },
  sectionTitle: { color: colors.textOnDarkPrimary, fontSize: FONT_SIZES.lg, fontWeight: '800', marginTop: SPACING.xxl, marginBottom: SPACING.md },
  addGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  addBtn: {
    width: '47%',
    padding: SPACING.lg,
    borderRadius: BORDER_RADIUS.md,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  addBtnDisabled: { opacity: 0.6 },
  addIcon: {
    marginBottom: 8,
    alignItems: 'center',
  },
  addIconDisabled: {},
  addLabel: { color: '#F9FAFB', fontSize: 15, fontWeight: '700' },
  addLabelDisabled: { color: '#64748B' },
  addHint: { color: '#64748B', fontSize: 11, marginTop: 4 },
  modal: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'center', padding: 20 },
  modalInner: { width: '100%', maxHeight: '85%' },
  modalContent: { backgroundColor: '#1E293B', borderRadius: 20, padding: 20 },
  modalTitle: { color: '#F9FAFB', fontSize: FONT_SIZES.lg, fontWeight: '800', marginBottom: SPACING.md },
  editMapWrap: { height: 180, borderRadius: 12, marginBottom: 12, overflow: 'hidden', position: 'relative' },
  map: { width: '100%', height: '100%', borderRadius: 12 },
  editMapRecenterButton: {
    position: 'absolute',
    top: 8,
    right: 8,
    zIndex: 10,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  input: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 12,
    padding: 14,
    color: '#F9FAFB',
    fontSize: 15,
    marginBottom: 16,
  },
  modalBtns: { flexDirection: 'row', gap: 12 },
  cancelBtn: {
    flex: 1,
    padding: 14,
    borderRadius: 12,
    backgroundColor: 'rgba(100,116,139,0.3)',
    alignItems: 'center',
  },
  cancelText: { color: '#F9FAFB', fontSize: 16, fontWeight: '600' },
  saveBtn: { flex: 1, borderRadius: 12, overflow: 'hidden' },
  saveGrad: { padding: 14, alignItems: 'center' },
  saveText: { color: '#FFF', fontSize: 16, fontWeight: '700' },
});
