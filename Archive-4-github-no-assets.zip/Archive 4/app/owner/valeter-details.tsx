/**
 * Deep-link target: valeter profile opens as bottom sheet (same as Explore).
 */
import React, { useEffect, useMemo, useState } from 'react';
import { View, StyleSheet, Alert } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import ValeterProfileBottomSheet from '../../src/components/valeter/ValeterProfileBottomSheet';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { getActiveBookingForCustomer } from '../../src/utils/activeBookingGuard';

export default function ValeterDetails() {
  const { user } = useAuth();
  const params = useLocalSearchParams<{ valeterId?: string | string[] }>();
  const valeterId = useMemo(() => {
    const raw = params.valeterId;
    if (typeof raw === 'string') return raw;
    if (Array.isArray(raw) && raw[0]) return raw[0];
    return null;
  }, [params.valeterId]);

  const [open, setOpen] = useState(true);

  useEffect(() => {
    if (!valeterId && router.canGoBack()) router.back();
  }, [valeterId]);

  if (!valeterId) {
    return null;
  }

  return (
    <View style={styles.wrap}>
      <ValeterProfileBottomSheet
        visible={open}
        onClose={() => {
          setOpen(false);
          if (router.canGoBack()) router.back();
        }}
        valeterId={valeterId}
        seed={valeterId ? { id: valeterId } : null}
        onRequestBook={async () => {
          if (!valeterId) return;
          await hapticFeedback('medium');
          if (user?.id) {
            const active = await getActiveBookingForCustomer(user.id);
            if (active) {
              Alert.alert(
                'One booking at a time',
                'Finish or cancel your current booking first.',
                [
                  { text: 'Cancel', style: 'cancel' },
                  {
                    text: 'View booking',
                    onPress: () =>
                      router.push({ pathname: '/owner/track', params: { bookingId: active.id } } as any),
                  },
                ]
              );
              return;
            }
          }
          router.push({
            pathname: '/owner/booking/create',
            params: { preferredValeterId: valeterId },
          });
          setOpen(false);
          if (router.canGoBack()) router.back();
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: 'transparent' },
});
