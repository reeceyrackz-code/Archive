import { Alert } from 'react-native';

export interface NotificationData {
  title: string;
  message: string;
  type?: 'info' | 'success' | 'warning' | 'error';
}

export class SimpleNotificationService {
  private static instance: SimpleNotificationService;

  private constructor() {}

  public static getInstance(): SimpleNotificationService {
    if (!SimpleNotificationService.instance) {
      SimpleNotificationService.instance = new SimpleNotificationService();
    }
    return SimpleNotificationService.instance;
  }

  // Show a simple alert notification
  showNotification(data: NotificationData): void {
    Alert.alert(data.title, data.message, [
      { text: 'OK', style: 'default' }
    ]);
  }

  // Job-specific notification methods
  showJobAlert(jobData: any): void {
    this.showNotification({
      title: '🚗 New Valet Available!',
      message: `£${jobData.price} - ${jobData.vehicleType} valet in ${jobData.distance}`,
      type: 'info'
    });
  }

  showJobAccepted(jobData: any): void {
    this.showNotification({
      title: '✅ Job accepted',
      message: `Head to ${jobData.customerName ?? 'the customer'} for this wash`,
      type: 'success'
    });
  }

  showJobCompleted(jobData: any): void {
    this.showNotification({
      title: '🎉 Job Completed!',
      message: `You earned £${jobData.earnings} for this service`,
      type: 'success'
    });
  }

  showPaymentConfirmation(paymentData: any): void {
    this.showNotification({
      title: '💳 Payment Successful!',
      message: `£${paymentData.amount} charged for ${paymentData.service}`,
      type: 'success'
    });
  }

  /** Customer-facing: valeter has arrived for the wash / valet */
  showValeterArrival(customerData: { valeterName?: string; proName?: string }): void {
    const name = customerData.valeterName ?? customerData.proName ?? 'Your valeter';
    this.showNotification({
      title: 'Valeter arrived',
      message: `${name} is here and ready for your wash`,
      type: 'info'
    });
  }

  showServiceStarted(): void {
    this.showNotification({
      title: 'Service Started!',
      message: 'Your vehicle wash is now in progress',
      type: 'info'
    });
  }

  showServiceCompleted(): void {
    this.showNotification({
      title: '✨ Service Completed!',
      message: 'Your vehicle wash is finished. Please rate your experience!',
      type: 'success'
    });
  }

  showEarningsUpdate(earningsData: any): void {
    this.showNotification({
      title: '💰 Earnings Updated!',
      message: `You've earned £${earningsData.amount} this week`,
      type: 'success'
    });
  }

  showPromotionalOffer(promoData: any): void {
    this.showNotification({
      title: '🎁 Special Offer!',
      message: promoData.message,
      type: 'info'
    });
  }
}

// Export singleton instance
export const simpleNotificationService = SimpleNotificationService.getInstance();

export default simpleNotificationService;
