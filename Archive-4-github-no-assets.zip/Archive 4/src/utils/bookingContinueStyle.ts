import type { ViewStyle } from 'react-native';
import { colors } from '../constants/colors';

/** Horizontal gradient + radii/shadows aligned with booking flow “Continue” CTAs. */
export const BOOKING_CONTINUE_RADIUS = 18;

const HEX6 = /^#?([0-9A-Fa-f]{6})$/;

function normalizeHex(color: string): string | null {
  const m = color.trim().match(HEX6);
  if (!m) return null;
  return `#${m[1].toUpperCase()}`;
}

/** Darken a 6-digit hex for a generic gradient end when no brand pair exists. */
export function bookingGradientEnd(startHex: string, factor = 0.62): string {
  const hex = normalizeHex(startHex);
  if (!hex) return startHex;
  const n = parseInt(hex.slice(1), 16);
  const r = (n >> 16) & 255;
  const g = (n >> 8) & 255;
  const b = n & 255;
  const clamp = (v: number) =>
    Math.max(0, Math.min(255, Math.round(v * factor)));
  const rr = clamp(r);
  const gg = clamp(g);
  const bb = clamp(b);
  return `#${rr.toString(16).padStart(2, '0')}${gg.toString(16).padStart(2, '0')}${bb.toString(16).padStart(2, '0')}`;
}

const GRADIENT_END_BY_START: Record<string, string> = {
  '#EAB308': colors.DETAILING_YELLOW_DARK,
  '#10B981': '#059669',
  '#87CEEB': colors.ICON_SKY_DARK,
  '#7EB8D4': '#4A7A8E',
  '#84CC16': '#65A30D',
};

export function bookingContinueGradient(accent: string): [string, string] {
  const key = normalizeHex(accent) ?? accent.trim().toUpperCase();
  const end = GRADIENT_END_BY_START[key] ?? bookingGradientEnd(accent);
  return [accent, end];
}

/** Bottom stop for vertical Continue glass (matches `GradientIconBox`). */
export const BOOKING_CONTINUE_GLASS_FOOT = 'rgba(15,23,42,0.65)' as const;

/** Vertical gradient for large chrome surfaces (headers, tab bar rail). */
export function bookingContinueVerticalTint(accent: string): [string, string] {
  const hex = normalizeHex(accent);
  if (hex) return [`${hex}59`, BOOKING_CONTINUE_GLASS_FOOT];
  return ['rgba(56,189,248,0.35)', BOOKING_CONTINUE_GLASS_FOOT];
}

/** Accent-tinted border matching Continue CTAs (`accent + "8A"` when hex). */
export function bookingContinueChromeBorder(accent: string): string {
  const hex = normalizeHex(accent);
  if (hex) return `${hex}8A`;
  return 'rgba(255,255,255,0.22)';
}

export const bookingContinueHeaderShadow = (accent: string) => ({
  shadowColor: accent,
  shadowOffset: { width: 0, height: 4 } as const,
  shadowOpacity: 0.4,
  shadowRadius: 12,
  elevation: 10 as const,
});

/** Softer shadow for full-bleed header bars (blur + gradient). */
export const bookingContinueHeaderBarShadow = (accent: string) => ({
  shadowColor: accent,
  shadowOffset: { width: 0, height: 10 } as const,
  shadowOpacity: 0.28,
  shadowRadius: 20,
  elevation: 14 as const,
});

/** Frosted circular control on Continue-style headers (optional accent border). */
export function appHeaderChromeIconButtonStyle(accent?: string): ViewStyle {
  return {
    width: 40,
    height: 40,
    borderRadius: BOOKING_CONTINUE_RADIUS,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.14)',
    borderWidth: 1,
    borderColor: accent ? bookingContinueChromeBorder(accent) : 'rgba(255,255,255,0.35)',
  };
}
