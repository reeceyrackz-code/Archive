/** Fixed window (matches typical hub slot generation) for minimal schedule calendar UI. */
export const BOOKING_SCHEDULE_CALENDAR_DAY_COUNT = 7;

export function startOfLocalDay(d: Date): Date {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

export function pad2(n: number): string {
  return String(n).padStart(2, '0');
}

export function localDayKey(d: Date): string {
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

/** Next N local calendar days starting today (inclusive). */
export function bookingScheduleWindowDays(count = BOOKING_SCHEDULE_CALENDAR_DAY_COUNT): Date[] {
  const out: Date[] = [];
  const base = startOfLocalDay(new Date());
  for (let i = 0; i < count; i++) {
    const d = new Date(base);
    d.setDate(base.getDate() + i);
    out.push(startOfLocalDay(d));
  }
  return out;
}
