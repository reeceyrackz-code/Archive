import { supabase } from '../lib/supabase';
import AsyncStorage from '@react-native-async-storage/async-storage';

/**
 * One booking at a time: statuses that count as "customer has an active booking".
 * Customer cannot start a new booking while they have one in any of these statuses.
 */
export const ACTIVE_CUSTOMER_BOOKING_STATUSES = [
  'pending',
  'pending_business_acceptance',
  'pending_valeter_acceptance',
  'pending_payment',
  'confirmed',
  'valeter_assigned',
  'en_route',
  'arrived',
  'scheduled',
  'in_progress',
] as const;
const ACTIVE_CUSTOMER_BOOKING_STATUSES_FALLBACK = ACTIVE_CUSTOMER_BOOKING_STATUSES.filter(
  (s) => s !== 'pending_business_acceptance'
);

export type ActiveBookingStatus = (typeof ACTIVE_CUSTOMER_BOOKING_STATUSES)[number];

const MANUAL_START_KEY = 'wishawash:manual-start-bookings:v1';
const ACTIVE_LEAD_MINUTES = 60;

async function getManualStartIds(): Promise<Set<string>> {
  try {
    const raw = await AsyncStorage.getItem(MANUAL_START_KEY);
    if (!raw) return new Set();
    const arr = JSON.parse(raw) as string[];
    return new Set(Array.isArray(arr) ? arr : []);
  } catch {
    return new Set();
  }
}

export async function isBookingManuallyStarted(bookingId: string): Promise<boolean> {
  const ids = await getManualStartIds();
  return ids.has(bookingId);
}

async function saveManualStartIds(ids: Set<string>): Promise<void> {
  await AsyncStorage.setItem(MANUAL_START_KEY, JSON.stringify([...ids]));
}

export async function markBookingManuallyStarted(bookingId: string): Promise<void> {
  const ids = await getManualStartIds();
  ids.add(bookingId);
  await saveManualStartIds(ids);
}

/**
 * Returns the customer's current active booking (if any).
 * Use before creating a new booking to enforce one booking at a time.
 */
export async function getActiveBookingForCustomer(
  userId: string
): Promise<{ id: string; status: string } | null> {
  let { data, error } = await supabase
    .from('bookings')
    .select('id, status, scheduled_at')
    .eq('user_id', userId)
    .in('status', [...ACTIVE_CUSTOMER_BOOKING_STATUSES])
    .order('created_at', { ascending: false })
    .limit(30);

  if (error?.code === '22P02') {
    const retry = await supabase
      .from('bookings')
      .select('id, status, scheduled_at')
      .eq('user_id', userId)
      .in('status', [...ACTIVE_CUSTOMER_BOOKING_STATUSES_FALLBACK])
      .order('created_at', { ascending: false })
      .limit(30);
    data = retry.data;
    error = retry.error;
  }

  if (error) {
    console.warn('[activeBookingGuard] getActiveBookingForCustomer error:', error);
    return null;
  }
  const rows = (data || []) as { id: string; status: string; scheduled_at?: string | null }[];
  if (rows.length === 0) return null;

  const manualStartIds = await getManualStartIds();
  const now = Date.now();

  const active = rows.find((row) => {
    if (row.status !== 'scheduled' && row.status !== 'confirmed') return true;
    if (manualStartIds.has(row.id)) return true;
    if (!row.scheduled_at) return false;
    const startAt = new Date(row.scheduled_at).getTime();
    if (!Number.isFinite(startAt)) return false;
    return startAt - now <= ACTIVE_LEAD_MINUTES * 60 * 1000;
  });

  return active ? { id: active.id, status: active.status } : null;
}
