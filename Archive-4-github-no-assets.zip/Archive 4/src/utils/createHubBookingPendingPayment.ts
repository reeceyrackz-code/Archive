import { supabase } from '../lib/supabase';
import { syncBookingToDeviceCalendar } from '../services/BookingCalendarSync';
import type { Hub } from '../types/booking';

const BOOKING_CUSTOMER_COL = 'user_id';

export type HubLike = Pick<Hub, 'id' | 'name' | 'address' | 'latitude' | 'longitude'>;

export type CreateHubBookingPendingPaymentInput = {
  userId: string;
  vehicleId: string;
  hub: HubLike;
  serviceId: string;
  serviceName: string;
  displayPrice: number;
  washType: string | null | undefined;
  scheduledAt: string;
};

/**
 * Inserts a hub (studio) booking with `pending_payment` and returns the new row id.
 * Calendar sync matches the former physical confirm screens.
 */
export async function createHubBookingPendingPayment(
  input: CreateHubBookingPendingPaymentInput
): Promise<{ ok: true; bookingId: string } | { ok: false; message: string }> {
  const insertPayload: Record<string, unknown> = {
    [BOOKING_CUSTOMER_COL]: input.userId,
    vehicle_id: input.vehicleId,
    location_id: input.hub.id,
    service_type: input.serviceId,
    service_name: input.serviceName,
    price: input.displayPrice,
    wash_type: input.washType ?? null,
    status: 'pending_payment',
    scheduled_at: input.scheduledAt,
    location_address: input.hub.address,
    location_lat: input.hub.latitude,
    location_lng: input.hub.longitude,
  };

  const { data, error } = await supabase.from('bookings').insert(insertPayload).select('id').single();

  if (error) {
    return { ok: false, message: error.message };
  }

  const bookingId = (data as { id: string }).id;

  void syncBookingToDeviceCalendar({
    id: bookingId,
    serviceName: input.serviceName,
    serviceType: input.serviceId,
    address: input.hub.address ?? null,
    scheduledAt: input.scheduledAt,
  });

  return { ok: true, bookingId };
}
