/** @deprecated use registerPushTokenWithSupabase from ./pushNotifications */
export { registerPushTokenWithSupabase as registerPushToken } from './pushNotifications';