import { customerTheme } from './customerTheme';

export type AccountType = 'customer' | 'valeter' | 'business';

export type ThemeMode = 'light' | 'dark';

export interface AccountTheme {
  primary: string;
  primaryAlt: string;
  background: [string, string];
  headerBackground?: [string, string];
  glassBorder: string;
  glassBorderAlt?: string;
  accent: string;
  accentAlt: string;
  cardBackground?: string;
  cardBackgroundGradient?: [string, string];
  cardBorder?: string;
  textPrimary?: string;
  textSecondary?: string;
  textOnBackground?: string;
  iconPrimary?: string;
  mode?: ThemeMode;
  statusOnlineCardBg?: string;
  statusOnlineAccent?: string;
  navBarBackground?: string;
  navBarBottomDark?: string;
  navActiveGlow?: string;
  iconHighlight?: string;
  shadowColor?: string;
  shadowOpacity?: number;
  shadowRadius?: number;
  iconCircleBg?: string;
  iconCircleBgHighlight?: string;
}

const SKY_BLUE = '#7DD3FC';
const VALETER_BLUE = '#5B9FC9';
const VALETER_BLUE_ALT = '#4A8BB0';

/** Light theme — muted blue–navy (reference `wishawasherwithconnect`). */
const LIGHT_PRIMARY = '#7EB8D4';
const LIGHT_SKY = '#6B9AAA';
const LIGHT_GRADIENT: [string, string] = ['#4A7A8E', '#152238'];

export const valeterLightTheme: AccountTheme = {
  primary: LIGHT_PRIMARY,
  primaryAlt: LIGHT_SKY,
  background: LIGHT_GRADIENT,
  headerBackground: ['rgba(74,122,142,0.48)', 'rgba(21,34,56,0.42)'],
  glassBorder: 'rgba(126,184,212,0.5)',
  cardBorder: 'rgba(126,184,212,0.5)',
  cardBackground: 'rgba(255,255,255,0.06)',
  cardBackgroundGradient: ['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.04)'],
  accent: LIGHT_PRIMARY,
  accentAlt: LIGHT_SKY,
  textPrimary: '#F1F5F9',
  textSecondary: 'rgba(241,245,249,0.88)',
  textOnBackground: 'rgba(241,245,249,0.7)',
  iconPrimary: LIGHT_PRIMARY,
  mode: 'light',
  statusOnlineCardBg: 'rgba(16,185,129,0.2)',
  statusOnlineAccent: '#10B981',
  navBarBackground: 'rgba(26,47,74,0.22)',
  navBarBottomDark: '#152238',
  navActiveGlow: LIGHT_PRIMARY,
  iconHighlight: LIGHT_PRIMARY,
  shadowColor: 'rgba(0,0,0,0.2)',
  shadowOpacity: 0.18,
  shadowRadius: 6,
  iconCircleBg: 'rgba(126,184,212,0.28)',
  iconCircleBgHighlight: 'rgba(126,184,212,0.22)',
};

export const businessLightTheme: AccountTheme = {
  ...valeterLightTheme,
  primary: LIGHT_PRIMARY,
  primaryAlt: LIGHT_SKY,
  accent: LIGHT_PRIMARY,
  accentAlt: LIGHT_SKY,
  iconPrimary: LIGHT_PRIMARY,
  iconHighlight: LIGHT_PRIMARY,
};

export const customerLightTheme: AccountTheme = {
  primary: LIGHT_PRIMARY,
  primaryAlt: LIGHT_SKY,
  background: customerTheme.backgroundGradient,
  headerBackground: ['rgba(74,122,142,0.48)', 'rgba(21,34,56,0.42)'],
  glassBorder: 'rgba(126,184,212,0.5)',
  cardBorder: 'rgba(126,184,212,0.5)',
  cardBackground: 'rgba(255,255,255,0.06)',
  cardBackgroundGradient: ['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.04)'],
  accent: LIGHT_PRIMARY,
  accentAlt: LIGHT_SKY,
  textPrimary: '#F1F5F9',
  textSecondary: 'rgba(241,245,249,0.88)',
  textOnBackground: 'rgba(241,245,249,0.7)',
  iconPrimary: LIGHT_PRIMARY,
  mode: 'light',
  statusOnlineCardBg: 'rgba(16,185,129,0.2)',
  statusOnlineAccent: '#10B981',
  navBarBackground: 'rgba(26,47,74,0.22)',
  navBarBottomDark: '#152238',
  navActiveGlow: LIGHT_PRIMARY,
  iconHighlight: LIGHT_PRIMARY,
  shadowColor: 'rgba(0,0,0,0.2)',
  shadowOpacity: 0.18,
  shadowRadius: 6,
  iconCircleBg: 'rgba(126,184,212,0.28)',
  iconCircleBgHighlight: 'rgba(126,184,212,0.22)',
};

export const accountThemes: Record<AccountType, AccountTheme> = {
  customer: {
    primary: '#87CEEB',
    primaryAlt: '#5BA3C7',
    background: ['#0A1929', '#050D14'],
    headerBackground: ['rgba(10,25,41,0.7)', 'rgba(5,13,20,0.8)'],
    glassBorder: 'rgba(135,206,235,0.3)',
    cardBackgroundGradient: ['rgba(15,35,58,0.6)', 'rgba(10,25,41,0.5)'],
    accent: '#87CEEB',
    accentAlt: '#5BA3C7',
    mode: 'dark',
    statusOnlineCardBg: 'rgba(16,185,129,0.2)',
    statusOnlineAccent: '#10B981',
    navBarBackground: 'rgba(10,25,41,0.85)',
    navBarBottomDark: '#050D14',
    navActiveGlow: '#87CEEB',
    iconHighlight: '#87CEEB',
    shadowColor: 'rgba(0,0,0,0.4)',
    shadowOpacity: 0.3,
    shadowRadius: 8,
    iconCircleBg: 'rgba(135,206,235,0.2)',
    iconCircleBgHighlight: 'rgba(135,206,235,0.15)',
  },

  valeter: {
    primary: VALETER_BLUE,
    primaryAlt: VALETER_BLUE_ALT,
    background: ['#0A1929', '#050D14'],
    headerBackground: ['rgba(10,25,41,0.7)', 'rgba(5,13,20,0.8)'],
    glassBorder: 'rgba(59,130,246,0.4)',
    cardBorder: 'rgba(59,130,246,0.3)',
    cardBackgroundGradient: ['rgba(15,35,58,0.6)', 'rgba(10,25,41,0.5)'],
    accent: VALETER_BLUE,
    accentAlt: VALETER_BLUE_ALT,
    mode: 'dark',
    statusOnlineCardBg: 'rgba(16,185,129,0.2)',
    statusOnlineAccent: '#10B981',
    navBarBackground: 'rgba(10,25,41,0.85)',
    navBarBottomDark: '#050D14',
    navActiveGlow: VALETER_BLUE,
    iconHighlight: VALETER_BLUE,
    shadowColor: 'rgba(0,0,0,0.4)',
    shadowOpacity: 0.3,
    shadowRadius: 8,
    iconCircleBg: 'rgba(59,130,246,0.2)',
    iconCircleBgHighlight: 'rgba(59,130,246,0.15)',
  },

  business: {
    primary: SKY_BLUE,
    primaryAlt: '#5BA3C7',
    background: ['#0A1929', '#050D14'],
    headerBackground: ['rgba(10,25,41,0.7)', 'rgba(5,13,20,0.8)'],
    glassBorder: 'rgba(125,211,252,0.4)',
    cardBorder: 'rgba(125,211,252,0.3)',
    cardBackgroundGradient: ['rgba(15,35,58,0.6)', 'rgba(10,25,41,0.5)'],
    accent: SKY_BLUE,
    accentAlt: '#5BA3C7',
    mode: 'dark',
    statusOnlineCardBg: 'rgba(16,185,129,0.2)',
    statusOnlineAccent: '#10B981',
    navBarBackground: 'rgba(10,25,41,0.85)',
    navBarBottomDark: '#050D14',
    navActiveGlow: SKY_BLUE,
    iconHighlight: SKY_BLUE,
    shadowColor: 'rgba(0,0,0,0.4)',
    shadowOpacity: 0.3,
    shadowRadius: 8,
    iconCircleBg: 'rgba(125,211,252,0.2)',
    iconCircleBgHighlight: 'rgba(125,211,252,0.15)',
  },
};

export const getAccountTheme = (accountType: AccountType, mode?: ThemeMode): AccountTheme => {
  if (mode === 'light') {
    if (accountType === 'customer') return customerLightTheme;
    if (accountType === 'valeter') return valeterLightTheme;
    if (accountType === 'business') return businessLightTheme;
  }
  return accountThemes[accountType];
};
