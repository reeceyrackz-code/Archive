/**
 * Soft brand-wave tint for the customer dashboard only (light app theme).
 * Low-opacity stops so the root shell gradient stays dominant — tweak alphas here if you want more or less colour.
 */
export const SUBTLE_WAVE_DASHBOARD_TINT_ENABLED = true;

/** Brand wave hues (#E0F2F1, #D4E157, #90E0EF, #00B4D8, #A7D129, #1B2D4F) at whisper strength; last stop fades out. */
export const subtleWaveDashboardTint = {
  colors: [
    'rgba(224, 242, 241, 0.09)',
    'rgba(212, 225, 87, 0.045)',
    'rgba(144, 224, 239, 0.055)',
    'rgba(0, 180, 216, 0.065)',
    'rgba(167, 209, 41, 0.035)',
    'rgba(27, 45, 79, 0)',
  ] as const,
  locations: [0, 0.2, 0.42, 0.58, 0.78, 1] as const,
  start: { x: 0, y: 0 } as const,
  end: { x: 1, y: 1 } as const,
};
