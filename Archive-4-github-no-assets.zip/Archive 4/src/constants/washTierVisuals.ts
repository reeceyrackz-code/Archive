import { serviceOptions } from './serviceOptions';

/** Tier accent for wash packages (icons + fills — no tier PNGs). */
export const WASH_TIER_UI: Record<
  string,
  { main: string; light: string; border: string }
> = {
  'bronze-wash': { main: '#CD7F32', light: 'rgba(205,127,50,0.28)', border: 'rgba(205,127,50,0.55)' },
  'silver-wash': { main: '#A8A8A8', light: 'rgba(168,168,168,0.24)', border: 'rgba(168,168,168,0.5)' },
  'gold-wash': { main: '#FFD700', light: 'rgba(255,215,0,0.22)', border: 'rgba(255,215,0,0.5)' },
  'platinum-wash': { main: '#E5E4E2', light: 'rgba(229,228,226,0.22)', border: 'rgba(229,228,226,0.5)' },
  'emerald-wash': { main: '#22D3EE', light: 'rgba(34,211,238,0.24)', border: 'rgba(34,211,238,0.48)' },
};

export function washTierIconName(tierId: string): string {
  return serviceOptions.find((o) => o.id === tierId)?.icon ?? 'water-outline';
}
