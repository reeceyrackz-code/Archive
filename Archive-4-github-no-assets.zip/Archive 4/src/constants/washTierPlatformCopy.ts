/**
 * Locked global wash tier order (ids): Bronze → Silver → Gold → Platinum → Diamond.
 * Mobile (valeter) vs on-site (hub) copy lives in serviceOptions + physical TIERS respectively.
 */

export const WASH_TIER_ORDER_IDS = [
  'bronze-wash',
  'silver-wash',
  'gold-wash',
  'platinum-wash',
  'emerald-wash',
] as const;

/** Hub / on-site card & list titles — Gold differs from mobile (interior-focused on-site). */
export const HUB_WASH_DISPLAY_NAME: Record<(typeof WASH_TIER_ORDER_IDS)[number], string> = {
  'bronze-wash': 'Bronze Wash',
  'silver-wash': 'Silver Wash',
  'gold-wash': 'Gold Wash (Interior Focused)',
  'platinum-wash': 'Platinum Wash',
  'emerald-wash': 'Diamond Wash',
};
