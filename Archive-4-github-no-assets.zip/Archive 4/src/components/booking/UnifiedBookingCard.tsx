import React from 'react';
import { View, StyleSheet, TouchableOpacity, ViewStyle, Image, ImageSourcePropType } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { colors } from '../../constants/colors';
import { BOOKING_CARD, HEADER_STYLE_CARD_GRADIENT, HEADER_STYLE_CARD_BORDER } from '../../constants/bookingCardTheme';
import { hapticFeedback } from '../../services/HapticFeedbackService';

const SKY = colors.SKY;
const CARD_RADIUS = BOOKING_CARD.BORDER_RADIUS;
const STRIP_WIDTH = 3;
const CARD_PADDING = 12;

export interface UnifiedBookingCardProps {
  children: React.ReactNode;
  onPress?: () => void;
  style?: ViewStyle;
  contentStyle?: ViewStyle;
  /** Accent colour for strip and border (e.g. SKY for wash, PREMIUM_PURPLE for detailing). Default SKY. */
  stripColor?: string;
  /** Blur intensity. Default 18 (lighter look). */
  intensity?: number;
  /** Show the curved left strip. Default true. */
  showStrip?: boolean;
  /** Use semi-transparent header-style background (same as Book a Service header). Default true. */
  headerStyle?: boolean;
  /** When set, fills the whole card (including border/strip) with this image; gradient/blur are skipped. */
  backgroundImage?: ImageSourcePropType;
  /** Overlay style applied on top of backgroundImage (e.g. dark tint for readability). */
  backgroundImageOverlay?: ViewStyle;
}

/**
 * Unified card design for wash hub and mobile valeter flows: semi-transparent header-style
 * gradient, BlurView, curved border. Use for all booking flow cards and tracking.
 */
export default function UnifiedBookingCard({
  children,
  onPress,
  style,
  contentStyle,
  stripColor = SKY,
  intensity = 28,
  showStrip = false,
  headerStyle = true,
  backgroundImage,
  backgroundImageOverlay,
}: Readonly<UnifiedBookingCardProps>) {
  const borderColor = headerStyle ? HEADER_STYLE_CARD_BORDER : stripColor + '25';
  const useFullCardImage = Boolean(backgroundImage);

  const cardContent = (
    <View style={[styles.card, { borderColor }]}>
      {!useFullCardImage && (
        <>
          {headerStyle && (
            <LinearGradient
              colors={HEADER_STYLE_CARD_GRADIENT}
              start={{ x: 0, y: 0 }}
              end={{ x: 0, y: 1 }}
              style={StyleSheet.absoluteFill}
            />
          )}
          <BlurView
            intensity={intensity}
            tint="dark"
            style={[StyleSheet.absoluteFill, styles.blur]}
          />
        </>
      )}
      {showStrip && (
        <View style={[styles.strip, { backgroundColor: stripColor }]} />
      )}
      <View style={[styles.inner, contentStyle]}>{children}</View>
    </View>
  );

  const wrapperStyle = [styles.touchable, style];
  const wrapperContent = (
    <>
      {useFullCardImage && backgroundImage && (
        <>
          <Image source={backgroundImage} style={styles.backgroundImageFull} resizeMode="cover" />
          {backgroundImageOverlay != null && (
            <View style={[StyleSheet.absoluteFill, backgroundImageOverlay]} pointerEvents="none" />
          )}
        </>
      )}
      {cardContent}
    </>
  );

  if (onPress) {
    return (
      <TouchableOpacity
        activeOpacity={0.9}
        onPress={() => { hapticFeedback('light'); onPress(); }}
        style={wrapperStyle}
      >
        {wrapperContent}
      </TouchableOpacity>
    );
  }

  return (
    <View style={[styles.wrapper, style]}>
      {wrapperContent}
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    borderRadius: CARD_RADIUS,
    overflow: 'hidden',
    shadowColor: 'transparent',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0,
    shadowRadius: 0,
    elevation: 0,
  },
  touchable: {
    borderRadius: CARD_RADIUS,
    overflow: 'hidden',
    shadowColor: 'transparent',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0,
    shadowRadius: 0,
    elevation: 0,
  },
  card: {
    borderRadius: CARD_RADIUS,
    overflow: 'hidden',
    borderWidth: 0,
    padding: CARD_PADDING,
  },
  /** At wrapper level so it fills the entire card (edge to edge, including border and strip). */
  backgroundImageFull: {
    ...StyleSheet.absoluteFillObject,
  },
  blur: {
    borderRadius: CARD_RADIUS,
    overflow: 'hidden',
  },
  strip: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: STRIP_WIDTH,
    borderTopLeftRadius: CARD_RADIUS,
    borderBottomLeftRadius: CARD_RADIUS,
  },
  inner: {},
});
