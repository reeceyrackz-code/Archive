import React, { useMemo } from 'react';
import { StyleSheet } from 'react-native';
import MapView, { Marker, Region } from 'react-native-maps';
import { BOOKING_MAP_STYLE, MAP_LOCKED_DARK } from '../../constants/mapConstants';
import { MapMarkerScheduledHub, MapMarkerCustomerVehicle } from '../maps/MapMarkerViews';

type Props = {
  hubLatitude: number | null | undefined;
  hubLongitude: number | null | undefined;
  userLatitude?: number | null;
  userLongitude?: number | null;
  mapPaddingBottom: number;
  /** Space below status bar + header (map attribution clears the sheet). */
  topMapPadding?: number;
};

/**
 * Full-screen map behind physical booking sheets — hub pin + optional customer pin, padding above bottom sheet.
 */
export default function PhysicalBookingHubMapLayer({
  hubLatitude,
  hubLongitude,
  userLatitude,
  userLongitude,
  mapPaddingBottom,
  topMapPadding = 92,
}: Readonly<Props>) {
  const region = useMemo((): Region | null => {
    const hLat = Number(hubLatitude);
    const hLng = Number(hubLongitude);
    if (!Number.isFinite(hLat) || !Number.isFinite(hLng)) return null;
    const uLat = userLatitude != null ? Number(userLatitude) : NaN;
    const uLng = userLongitude != null ? Number(userLongitude) : NaN;
    if (Number.isFinite(uLat) && Number.isFinite(uLng)) {
      const minLa = Math.min(hLat, uLat);
      const maxLa = Math.max(hLat, uLat);
      const minLo = Math.min(hLng, uLng);
      const maxLo = Math.max(hLng, uLng);
      const pad = 0.012;
      return {
        latitude: (minLa + maxLa) / 2,
        longitude: (minLo + maxLo) / 2,
        latitudeDelta: Math.max(0.018, maxLa - minLa + pad * 2),
        longitudeDelta: Math.max(0.018, maxLo - minLo + pad * 2),
      };
    }
    return { latitude: hLat, longitude: hLng, latitudeDelta: 0.045, longitudeDelta: 0.045 };
  }, [hubLatitude, hubLongitude, userLatitude, userLongitude]);

  if (!region) return null;

  return (
    <MapView
      style={StyleSheet.absoluteFill}
      initialRegion={region}
      region={region}
      customMapStyle={BOOKING_MAP_STYLE}
      userInterfaceStyle={MAP_LOCKED_DARK}
      mapPadding={{ top: topMapPadding, right: 14, bottom: mapPaddingBottom, left: 14 }}
      legalLabelInsets={{ top: 0, right: 8, bottom: Math.max(8, mapPaddingBottom - 32), left: 8 }}
      scrollEnabled
      zoomEnabled
      rotateEnabled={false}
      pitchEnabled={false}
      toolbarEnabled={false}
      showsUserLocation={false}
    >
      <Marker coordinate={{ latitude: Number(hubLatitude), longitude: Number(hubLongitude) }} tracksViewChanges={false}>
        <MapMarkerScheduledHub variant="wash" />
      </Marker>
      {userLatitude != null &&
      userLongitude != null &&
      Number.isFinite(Number(userLatitude)) &&
      Number.isFinite(Number(userLongitude)) ? (
        <Marker
          coordinate={{ latitude: Number(userLatitude), longitude: Number(userLongitude) }}
          tracksViewChanges={false}
        >
          <MapMarkerCustomerVehicle size={36} variant="pin" />
        </Marker>
      ) : null}
    </MapView>
  );
}
