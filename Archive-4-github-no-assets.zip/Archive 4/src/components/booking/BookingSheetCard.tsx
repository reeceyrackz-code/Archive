/**
 * Inner surfaces for map booking bottom sheets — replaces legacy UnifiedBookingCard.
 * Single frosted panel + accent strip; no nested BlurView (sheet already uses BusinessSheetBackground).
 */
import React from 'react';
import {
  View,
  StyleSheet,
  Pressable,
  Image,
  type ViewStyle,
  type ImageSourcePropType,
} from 'react-native';
import { colors } from '../../constants/colors';
import {
  BOOKING_CARD,
  BOOKING_INNER_CARD_BACKGROUND,
  BOOKING_INNER_CARD_BORDER,
  BOOKING_STEP_CARD_MIN_HEIGHT,
} from '../../constants/bookingCardTheme';
import { hapticFeedback } from '../../services/HapticFeedbackService';

export type BookingSheetCardHaptic = 'light' | 'medium' | false;

const STRIP_W = 3;
const RADIUS = BOOKING_CARD.BORDER_RADIUS;
const PAD = 12;
const SKY = colors.SKY;

export type BookingSheetCardProps = {
  children: React.ReactNode;
  onPress?: () => void;
  style?: ViewStyle;
  contentStyle?: ViewStyle;
  stripColor?: string;
  /** Unused — kept for drop-in compatibility with old call sites. */
  intensity?: number;
  showStrip?: boolean;
  headerStyle?: boolean;
  /** Default `light`. Set `false` when the handler already triggers haptics. */
  hapticOnPress?: BookingSheetCardHaptic;
  backgroundImage?: ImageSourcePropType;
  backgroundImageOverlay?: ViewStyle;
  /** Match tracking card height; default `BOOKING_STEP_CARD_MIN_HEIGHT` when `uniformStepHeight` is true. */
  uniformStepHeight?: boolean;
  minHeight?: number;
};

export default function BookingSheetCard({
  children,
  onPress,
  style,
  contentStyle,
  stripColor = SKY,
  showStrip = false,
  headerStyle = true,
  hapticOnPress = 'light',
  backgroundImage,
  backgroundImageOverlay,
  uniformStepHeight = false,
  minHeight: minHeightProp,
}: Readonly<BookingSheetCardProps>) {
  const useImg = Boolean(backgroundImage);
  const borderColor = headerStyle !== false ? BOOKING_INNER_CARD_BORDER : stripColor + '25';
  const minH = minHeightProp ?? (uniformStepHeight ? BOOKING_STEP_CARD_MIN_HEIGHT : undefined);

  const face = (
    <View style={[styles.cardFace, { borderColor }, minH != null ? styles.cardFaceFill : null]}>
      {!useImg ? <View style={styles.solidFill} /> : null}
      {useImg && backgroundImage ? (
        <>
          <Image source={backgroundImage} style={styles.bgImg} resizeMode="cover" />
          {backgroundImageOverlay != null ? (
            <View style={[StyleSheet.absoluteFill, backgroundImageOverlay]} pointerEvents="none" />
          ) : null}
        </>
      ) : null}
      {showStrip !== false ? (
        <View style={[styles.strip, { backgroundColor: stripColor, width: STRIP_W }]} />
      ) : null}
      <View
        style={[
          styles.inner,
          showStrip === false ? styles.innerNoStrip : null,
          minH != null ? styles.innerUniform : null,
          contentStyle,
        ]}
      >
        {children}
      </View>
    </View>
  );

  const rootSize = minH != null ? { minHeight: minH } : null;

  if (onPress) {
    return (
      <Pressable
        accessibilityRole="button"
        onPress={() => {
          if (hapticOnPress) void hapticFeedback(hapticOnPress);
          onPress();
        }}
        style={({ pressed }) => [styles.root, rootSize, style, pressed && styles.pressed]}
      >
        {face}
      </Pressable>
    );
  }

  return <View style={[styles.root, rootSize, style]}>{face}</View>;
}

const styles = StyleSheet.create({
  root: {
    borderRadius: RADIUS,
    overflow: 'hidden',
  },
  pressed: {
    opacity: 0.92,
  },
  cardFace: {
    borderRadius: RADIUS,
    overflow: 'hidden',
    borderWidth: 0,
    position: 'relative',
    shadowColor: 'transparent',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0,
    shadowRadius: 0,
    elevation: 0,
  },
  cardFaceFill: {
    flex: 1,
  },
  solidFill: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: BOOKING_INNER_CARD_BACKGROUND,
  },
  bgImg: {
    ...StyleSheet.absoluteFillObject,
    width: '100%',
    height: '100%',
  },
  strip: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    borderTopLeftRadius: RADIUS,
    borderBottomLeftRadius: RADIUS,
  },
  inner: {
    paddingTop: PAD,
    paddingBottom: PAD,
    paddingRight: PAD,
    paddingLeft: PAD + STRIP_W,
  },
  innerNoStrip: {
    paddingLeft: PAD,
  },
  innerUniform: {
    flexGrow: 1,
    justifyContent: 'center',
  },
});
