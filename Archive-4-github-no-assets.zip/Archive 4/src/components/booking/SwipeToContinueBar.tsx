import React, { useRef, useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  PanResponder,
  Dimensions,
  ViewStyle,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { hapticFeedback, hapticSuccess } from '../../services/HapticFeedbackService';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const TRACK_HEIGHT = 56;
const THUMB_SIZE = 44;
const TRACK_PADDING = 5;
const THRESHOLD_RATIO = 0.72; // trigger when thumb passes 72% of track (easier to complete)

const CONFETTI_COLORS = ['#10B981', '#60A5FA', '#FBBF24', '#A855F7', '#EC4899', '#14B8A6'];
const PARTICLE_COUNT = 10;

/** Small confetti burst - particles fly out from center and fade */
function ConfettiBurst({ trigger }: Readonly<{ trigger: number }>) {
  const particles = useRef(
    Array.from({ length: PARTICLE_COUNT }, () => ({
      anim: new Animated.Value(0),
      angle: (Math.random() * 360 * Math.PI) / 180,
      dist: 24 + Math.random() * 24,
      color: CONFETTI_COLORS[Math.floor(Math.random() * CONFETTI_COLORS.length)],
      size: 4 + Math.random() * 4,
    }))
  ).current;

  useEffect(() => {
    if (trigger === 0) return;
    particles.forEach((p) => p.anim.setValue(0));
    Animated.parallel(
      particles.map((p) =>
        Animated.timing(p.anim, {
          toValue: 1,
          duration: 450,
          useNativeDriver: true,
        })
      )
    ).start();
  }, [trigger]);

  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="none">
      {particles.map((p) => {
        const x = Math.cos(p.angle) * p.dist;
        const y = Math.sin(p.angle) * p.dist;
        return (
          <Animated.View
            key={`${p.angle}-${p.dist}-${p.color}-${p.size}`}
            style={[
              {
                position: 'absolute',
                left: '50%',
                top: '50%',
                width: p.size,
                height: p.size,
                marginLeft: -p.size / 2,
                marginTop: -p.size / 2,
                borderRadius: p.size / 2,
                backgroundColor: p.color,
                transform: [
                  {
                    translateX: p.anim.interpolate({
                      inputRange: [0, 1],
                      outputRange: [0, x],
                    }),
                  },
                  {
                    translateY: p.anim.interpolate({
                      inputRange: [0, 1],
                      outputRange: [0, y],
                    }),
                  },
                  {
                    scale: p.anim.interpolate({
                      inputRange: [0, 0.3, 1],
                      outputRange: [1, 1.2, 0],
                    }),
                  },
                ],
              },
            ]}
          />
        );
      })}
    </View>
  );
}

export interface SwipeToContinueBarProps {
  onComplete: () => void;
  /** Label shown on the track (e.g. "Swipe to continue", "Continue") */
  label?: string;
  /** Accent color for track and thumb. Default #0EA5E9 (SKY). */
  accentColor?: string;
  /** When true, bar is greyed out and does not trigger. */
  disabled?: boolean;
  style?: ViewStyle;
}

export default function SwipeToContinueBar({
  onComplete,
  label = 'Swipe to continue',
  accentColor = '#0EA5E9',
  disabled = false,
  style,
}: Readonly<SwipeToContinueBarProps>) {
  const trackWidth = Math.min(SCREEN_WIDTH - 56, 320) - TRACK_PADDING * 2;
  const maxDrag = trackWidth - THUMB_SIZE - TRACK_PADDING * 2;
  const threshold = maxDrag * THRESHOLD_RATIO;

  const thumbX = useRef(new Animated.Value(0)).current;
  const pingScale = useRef(new Animated.Value(1)).current;
  const completed = useRef(false);
  const lastDx = useRef(0);
  const milestonesCrossed = useRef([false, false, false]); // 25%, 50%, 75%
  const [burstTrigger, setBurstTrigger] = useState(0);
  const disabledRef = useRef(disabled);
  disabledRef.current = disabled;

  const triggerMilestone = (index: number) => {
    if (milestonesCrossed.current[index]) return;
    milestonesCrossed.current[index] = true;
    hapticFeedback('light');
    setBurstTrigger((t) => t + 1);
  };

  const runPing = (callback?: () => void) => {
    pingScale.setValue(1);
    Animated.sequence([
      Animated.timing(pingScale, {
        toValue: 1.35,
        duration: 100,
        useNativeDriver: true,
      }),
      Animated.timing(pingScale, {
        toValue: 1,
        duration: 180,
        useNativeDriver: true,
      }),
    ]).start(() => callback?.());
  };

  const panResponder = useRef(
    PanResponder.create({
      // Claim on touch start so we own the gesture (parent ScrollView won't steal it)
      onStartShouldSetPanResponder: () => !disabledRef.current && !completed.current,
      onStartShouldSetPanResponderCapture: () => !disabledRef.current && !completed.current,
      onMoveShouldSetPanResponder: () => false,
      onMoveShouldSetPanResponderCapture: () => false,
      onPanResponderGrant: () => {},
      onPanResponderMove: (_, g) => {
        if (disabledRef.current || completed.current) return;
        const dx = Math.max(0, Math.min(g.dx, maxDrag));
        lastDx.current = dx;
        thumbX.setValue(dx);
        if (dx >= maxDrag * 0.25) triggerMilestone(0);
        if (dx >= maxDrag * 0.5) triggerMilestone(1);
        if (dx >= maxDrag * 0.75) triggerMilestone(2);
      },
      onPanResponderRelease: (_, g) => {
        if (disabledRef.current || completed.current) return;
        // Use max of release dx and last move dx (release sometimes reports 0 on some devices)
        const dx = Math.max(g.dx, lastDx.current);
        if (dx >= threshold) {
          completed.current = true;
          thumbX.setValue(maxDrag);
          setBurstTrigger((t) => t + 1); // 100% confetti
          hapticSuccess(); // fire-and-forget
          runPing(); // visual only
          onComplete(); // advance immediately so next stage always runs
        } else {
          Animated.spring(thumbX, {
            toValue: 0,
            useNativeDriver: true,
            speed: 18,
            bounciness: 8,
          }).start();
        }
      },
    })
  ).current;

  useEffect(() => {
    completed.current = false;
    lastDx.current = 0;
    milestonesCrossed.current = [false, false, false];
    thumbX.setValue(0);
  }, [disabled]);

  const trackBg = disabled ? 'rgba(71, 85, 105, 0.25)' : accentColor + '22';
  const thumbColor = disabled ? '#64748B' : accentColor;
  const borderColor = disabled ? 'rgba(100, 116, 139, 0.4)' : accentColor + '45';

  return (
    <View style={[styles.wrapper, style]}>
      <View
        style={[
          styles.track,
          {
            width: trackWidth + TRACK_PADDING * 2,
            height: TRACK_HEIGHT + TRACK_PADDING * 2,
            backgroundColor: trackBg,
            borderColor,
          },
        ]}
        {...panResponder.panHandlers}
      >
        <View style={[styles.trackInner, { width: trackWidth, height: TRACK_HEIGHT }]}>
          {burstTrigger > 0 && (
            <View style={styles.burstWrap}>
              <ConfettiBurst key={burstTrigger} trigger={burstTrigger} />
            </View>
          )}
          <Text
            style={[styles.label, { color: disabled ? '#64748B' : '#94A3B8' }]}
            numberOfLines={1}
            pointerEvents="none"
          >
            {label}
          </Text>
          <Animated.View
            style={[
              styles.thumbWrap,
              {
                width: trackWidth - TRACK_PADDING * 2,
                height: TRACK_HEIGHT,
                left: TRACK_PADDING,
                top: TRACK_PADDING,
              },
            ]}
            pointerEvents="none"
          >
            <Animated.View
              style={[
                styles.thumb,
                {
                  backgroundColor: thumbColor,
                  transform: [
                    { translateX: thumbX },
                    { scale: pingScale },
                  ],
                },
              ]}
            >
              <Ionicons name="arrow-forward" size={24} color="#FFFFFF" />
            </Animated.View>
          </Animated.View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    alignSelf: 'stretch',
    alignItems: 'center',
    marginTop: 4,
  },
  track: {
    borderRadius: 16,
    borderWidth: 2,
    padding: TRACK_PADDING,
    justifyContent: 'center',
  },
  trackInner: {
    borderRadius: 12,
    overflow: 'visible',
    justifyContent: 'center',
  },
  burstWrap: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 10,
    overflow: 'hidden',
    pointerEvents: 'none',
  },
  label: {
    position: 'absolute',
    left: 0,
    right: 0,
    textAlign: 'center',
    fontSize: 15,
    fontWeight: '800',
    zIndex: 0,
  },
  thumbWrap: {
    position: 'absolute',
    justifyContent: 'center',
    zIndex: 1,
  },
  thumb: {
    width: THUMB_SIZE,
    height: THUMB_SIZE,
    borderRadius: THUMB_SIZE / 2,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 4,
    shadowColor: '#0EA5E9',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.35,
    shadowRadius: 6,
  },
});
