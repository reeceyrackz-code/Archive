import React from 'react';
import { View, StyleSheet, Platform } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import {
  BOOKING_CONTINUE_RADIUS,
  bookingContinueVerticalTint,
  bookingContinueChromeBorder,
} from '../../utils/bookingContinueStyle';
import { LEGACY_ECO_SERVICE_ID_MAP } from '../../constants/serviceOptions';

export function getServiceTierLeadIconName(
  serviceId: string,
): React.ComponentProps<typeof Ionicons>['name'] {
  const raw = serviceId.toLowerCase();
  const id = LEGACY_ECO_SERVICE_ID_MAP[raw] ?? raw;
  const map: Record<string, React.ComponentProps<typeof Ionicons>['name']> = {
    'bronze-wash': 'water-outline',
    'silver-wash': 'layers-outline',
    'gold-wash': 'sunny-outline',
    'platinum-wash': 'ribbon-outline',
    'emerald-wash': 'leaf-outline',
    'ceramic-coating': 'diamond-outline',
    'machine-polishing': 'disc-outline',
    'soft-top-restoration': 'umbrella-outline',
    'mould-removal': 'shield-outline',
    'headlight-restoration': 'bulb-outline',
    'scratch-removal': 'color-filter-outline',
    'paint-chip-repair': 'medkit-outline',
    'trim-restoration': 'albums-outline',
    'leather-repair': 'shirt-outline',
  };
  return map[id] ?? 'sparkles-outline';
}

/**
 * Tier lead icon — same glass + vertical tint + accent border treatment as Continue CTAs.
 */
export default function ServiceTierSpongeIcon({
  accentColor,
  iconName,
  boxSize = 44,
  iconSize = 22,
}: Readonly<{
  accentColor: string;
  iconName: React.ComponentProps<typeof Ionicons>['name'];
  boxSize?: number;
  iconSize?: number;
}>) {
  const vertical = bookingContinueVerticalTint(accentColor);
  const borderCol = bookingContinueChromeBorder(accentColor);

  return (
    <View style={{ width: boxSize, height: boxSize }}>
      <View
        style={[
          styles.chrome,
          {
            width: boxSize,
            height: boxSize,
            borderRadius: BOOKING_CONTINUE_RADIUS,
            borderColor: borderCol,
          },
        ]}
      >
        <BlurView
          intensity={22}
          tint="dark"
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
          {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
        />
        <LinearGradient
          colors={vertical}
          start={{ x: 0, y: 0 }}
          end={{ x: 0, y: 1 }}
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
        />
        <View style={styles.iconCenter} pointerEvents="none">
          <Ionicons name={iconName} size={iconSize} color={accentColor} />
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  chrome: {
    overflow: 'hidden',
    borderWidth: 1,
    position: 'relative',
  },
  iconCenter: {
    ...StyleSheet.absoluteFillObject,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
