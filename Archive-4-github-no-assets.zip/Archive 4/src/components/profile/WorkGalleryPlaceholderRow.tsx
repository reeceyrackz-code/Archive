import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors } from '../../constants/colors';
import GradientIconBox from '../shared/GradientIconBox';

const SKY = colors.SKY ?? '#38BDF8';

const SLOT_COUNT = 5;

/**
 * Placeholder grid for “their work” photos (real URLs can replace later).
 */
export function WorkGalleryPlaceholderRow({
  sectionLabel = 'Their work',
}: {
  sectionLabel?: string;
}) {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionLabel}>{sectionLabel}</Text>
      <View style={styles.row}>
        {Array.from({ length: SLOT_COUNT }, (_, i) => (
          <View key={i} style={styles.cell}>
            <GradientIconBox
              icon="camera-outline"
              colors={[SKY, `${SKY}CC`]}
              boxSize={40}
              borderRadius={12}
              muted
              size={20}
            />
          </View>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  section: {
    marginBottom: 16,
  },
  sectionLabel: {
    color: 'rgba(226,232,240,0.88)',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.1,
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  row: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  cell: {
    width: 56,
    height: 56,
    borderRadius: 14,
    backgroundColor: 'rgba(15,23,42,0.55)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.22)',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
