import React from 'react';
import { TouchableOpacity, StyleSheet, Platform, ActivityIndicator } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import {
  BOOKING_CONTINUE_RADIUS,
  bookingContinueHeaderShadow,
} from '../../utils/bookingContinueStyle';
import { customerMapTrackingSheetActionStyles } from '../booking/CustomerMapTrackingSheetShell';
import { colors } from '../../constants/colors';

type BookingHeaderMapControlButtonProps = {
  onPress: () => void;
  /** Matches booking Continue CTAs (e.g. detailing yellow, eco green). */
  accentColor?: string;
  accessibilityLabel?: string;
  /** Touch target; default matches AppHeader chrome. */
  size?: number;
  iconSize?: number;
  loading?: boolean;
};

/**
 * Locate / recenter control for map booking screens — same glass + gradient stack as sheet Continue buttons.
 */
export function BookingHeaderMapControlButton({
  onPress,
  accentColor = colors.SKY,
  accessibilityLabel = 'Use current location on map',
  size = 40,
  iconSize = 20,
  loading = false,
}: BookingHeaderMapControlButtonProps) {
  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={loading}
      activeOpacity={0.85}
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel}
      style={[
        customerMapTrackingSheetActionStyles.bookingInfoActionCard,
        {
          width: size,
          height: size,
          borderRadius: BOOKING_CONTINUE_RADIUS,
          borderWidth: 1,
          borderColor: `${accentColor}8A`,
          alignItems: 'center',
          justifyContent: 'center',
          overflow: 'hidden',
          ...bookingContinueHeaderShadow(accentColor),
        },
      ]}
    >
      <BlurView
        intensity={26}
        tint="dark"
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
        {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
      />
      <LinearGradient
        colors={[`${accentColor}59`, 'rgba(15,23,42,0.65)']}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      {loading ? (
        <ActivityIndicator size="small" color={accentColor} style={{ zIndex: 1 }} />
      ) : (
        <Ionicons name="locate" size={iconSize} color={accentColor} style={{ zIndex: 1 }} />
      )}
    </TouchableOpacity>
  );
}
