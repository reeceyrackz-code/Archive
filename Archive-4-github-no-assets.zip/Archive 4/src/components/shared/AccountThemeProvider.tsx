import React, { createContext, useContext, ReactNode, useMemo } from 'react';
import {
  AccountType,
  getAccountTheme,
  AccountTheme,
  ThemeMode,
} from '../../constants/accountThemes';
import { useThemeOptional } from '../../contexts/ThemeContext';

interface AccountThemeContextValue {
  accountType: AccountType;
  theme: AccountTheme;
  mode: ThemeMode;
  setMode: (mode: ThemeMode) => void;
  toggleMode: () => void;
}

const AccountThemeContext = createContext<AccountThemeContextValue | undefined>(undefined);

interface AccountThemeProviderProps {
  accountType: AccountType;
  children: ReactNode;
}

export function AccountThemeProvider({ accountType, children }: AccountThemeProviderProps) {
  const themeCtx = useThemeOptional();
  const mode: ThemeMode = themeCtx?.colorScheme === 'dark' ? 'dark' : 'light';

  const theme = useMemo(() => getAccountTheme(accountType, mode), [accountType, mode]);

  const setMode = (next: ThemeMode) => {
    themeCtx?.setColorScheme(next);
  };

  const toggleMode = () => {
    themeCtx?.toggleDarkMode();
  };

  const value = useMemo(
    () => ({ accountType, theme, mode, setMode, toggleMode }),
    [accountType, theme, mode]
  );

  return <AccountThemeContext.Provider value={value}>{children}</AccountThemeContext.Provider>;
}

export function useAccountTheme(): AccountThemeContextValue {
  const context = useContext(AccountThemeContext);
  const themeOptional = useThemeOptional();
  const mode: ThemeMode = themeOptional?.colorScheme === 'dark' ? 'dark' : 'light';

  if (!context) {
    return {
      accountType: 'customer',
      theme: getAccountTheme('customer', mode),
      mode,
      setMode: (m) => themeOptional?.setColorScheme(m),
      toggleMode: themeOptional?.toggleDarkMode ?? (() => {}),
    };
  }
  return context;
}
