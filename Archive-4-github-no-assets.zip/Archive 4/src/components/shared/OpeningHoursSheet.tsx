/**
 * Structured weekly hours in a glass modal — avoids long free-text strips on hub screens.
 */
import React, { useMemo, useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  Pressable,
  Platform,
  ScrollView,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors } from '../../constants/colors';
import { WWSheetCloseButton } from '../ui';

const DAY_NAMES_SHORT = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export type OpeningHourRow = {
  day_of_week: number;
  is_open: boolean;
  open_time?: string | null;
  close_time?: string | null;
};

function formatHHMM(t: string | null | undefined): string {
  if (!t) return '— —';
  return t.slice(0, 5);
}

function parseMinutes(t: string | null | undefined): number | null {
  if (!t) return null;
  const m = t.trim().match(/^(\d{1,2}):(\d{2})/);
  if (!m) return null;
  return parseInt(m[1], 10) * 60 + parseInt(m[2], 10);
}

/** One-line teaser for list rows (open until / opens when / closed). */
export function getOpeningHoursTeaser(hours: OpeningHourRow[]): string {
  if (!hours.length) return 'Hours not listed';
  const byDay = new Map(hours.map((h) => [h.day_of_week, h]));
  const now = new Date();
  const dow = now.getDay();
  const nowMin = now.getHours() * 60 + now.getMinutes();
  const today = byDay.get(dow);

  if (today?.is_open && today.open_time && today.close_time) {
    const o = parseMinutes(today.open_time);
    const c = parseMinutes(today.close_time);
    if (o != null && c != null && c > o) {
      if (nowMin >= o && nowMin < c) {
        return `Open · until ${formatHHMM(today.close_time)}`;
      }
      if (nowMin < o) {
        return `Closed · opens ${formatHHMM(today.open_time)}`;
      }
    }
  }

  for (let i = 1; i <= 7; i++) {
    const d = (dow + i) % 7;
    const h = byDay.get(d);
    if (h?.is_open && h.open_time && h.close_time) {
      const dayWord = i === 1 ? 'tomorrow' : DAY_NAMES_SHORT[d];
      return `Closed · opens ${dayWord} ${formatHHMM(h.open_time)}`;
    }
  }

  return 'Closed · see weekly schedule';
}

/** Whether the location is within today's open window (local time). False if hours missing or today closed. */
export function isLocationOpenNow(hours: OpeningHourRow[]): boolean {
  if (!hours.length) return true;
  const byDay = new Map(hours.map((h) => [h.day_of_week, h]));
  const now = new Date();
  const dow = now.getDay();
  const nowMin = now.getHours() * 60 + now.getMinutes();
  const today = byDay.get(dow);
  if (today?.is_open && today.open_time && today.close_time) {
    const o = parseMinutes(today.open_time);
    const c = parseMinutes(today.close_time);
    if (o != null && c != null && c > o) {
      return nowMin >= o && nowMin < c;
    }
  }
  return false;
}

type Props = {
  visible: boolean;
  onClose: () => void;
  hours: OpeningHourRow[];
  accentColor?: string;
  title?: string;
};

export default function OpeningHoursSheet({
  visible,
  onClose,
  hours,
  accentColor = colors.SKY,
  title = 'Operating hours',
}: Readonly<Props>) {
  const insets = useSafeAreaInsets();
  const todayDow = new Date().getDay();
  const [nowLabel, setNowLabel] = useState('');
  useEffect(() => {
    if (!visible) return;
    const tick = () => {
      try {
        setNowLabel(
          new Date().toLocaleString(undefined, {
            weekday: 'short',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
          })
        );
      } catch {
        setNowLabel('');
      }
    };
    tick();
    const id = setInterval(tick, 60_000);
    return () => clearInterval(id);
  }, [visible]);

  const sortedDays = useMemo(() => {
    const byDay = new Map(hours.map((h) => [h.day_of_week, h]));
    return [0, 1, 2, 3, 4, 5, 6].map((d) => ({
      dow: d,
      label: DAY_NAMES_SHORT[d],
      row: byDay.get(d),
    }));
  }, [hours]);

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <View style={styles.root}>
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} accessibilityRole="button" accessibilityLabel="Dismiss" />
        <View style={[styles.sheet, { paddingBottom: Math.max(20, insets.bottom + 12) }]}>
          <BlurView intensity={Platform.OS === 'ios' ? 32 : 22} tint="dark" style={StyleSheet.absoluteFill} />
          <LinearGradient
            colors={['rgba(15,23,42,0.97)', 'rgba(8,15,35,0.98)']}
            style={[StyleSheet.absoluteFill, { borderRadius: 22 }]}
          />
          <View style={[styles.sheetGlowTop, { backgroundColor: `${accentColor}22` }]} />

          <View style={styles.sheetHeader}>
            <View style={styles.sheetHeaderTitles}>
              <Text style={styles.kicker}>SCHEDULE</Text>
              <Text style={styles.sheetTitle}>{title}</Text>
              {nowLabel ? (
                <View style={styles.liveClockRow}>
                  <View style={[styles.pulseDot, { backgroundColor: accentColor }]} />
                  <Text style={styles.liveClockText}>{nowLabel}</Text>
                </View>
              ) : null}
            </View>
            <WWSheetCloseButton onPress={onClose} hitSlop={12} accessibilityLabel="Close" />
          </View>

          <ScrollView
            style={styles.scroll}
            contentContainerStyle={styles.scrollContent}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
          >
            {sortedDays.map(({ dow, label, row }) => {
              const isToday = dow === todayDow;
              const open =
                !!(row?.is_open && row.open_time && row.close_time);
              const closedDay = !!row && !row.is_open;
              const openStart = open ? formatHHMM(row!.open_time) : '';
              const openEnd = open ? formatHHMM(row!.close_time) : '';
              return (
                <View
                  key={dow}
                  style={[
                    styles.dayRow,
                    isToday && { backgroundColor: `${accentColor}14`, borderColor: `${accentColor}44` },
                    isToday && styles.dayRowToday,
                  ]}
                >
                  <View style={styles.dayRowLeft}>
                    <Text style={[styles.dayLabel, isToday && { color: accentColor }]}>{label}</Text>
                    {isToday ? (
                      <View style={[styles.todayPill, { borderColor: `${accentColor}66` }]}>
                        <Text style={[styles.todayPillText, { color: accentColor }]}>TODAY</Text>
                      </View>
                    ) : null}
                  </View>
                  <View style={styles.timesCol}>
                    {open ? (
                      <>
                        <Text style={styles.timeDigits} numberOfLines={1}>
                          {openStart}
                        </Text>
                        <Text style={styles.timeSep}>→</Text>
                        <Text style={styles.timeDigits} numberOfLines={1}>
                          {openEnd}
                        </Text>
                      </>
                    ) : (
                      <Text
                        style={[
                          styles.timeClosed,
                          closedDay ? styles.timeClosedEmphasis : styles.timeClosedMuted,
                        ]}
                      >
                        {closedDay ? 'CLOSED' : '— —'}
                      </Text>
                    )}
                  </View>
                </View>
              );
            })}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const mono = Platform.select({ ios: 'Menlo', android: 'monospace', default: 'monospace' });

const styles = StyleSheet.create({
  root: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(0,0,0,0.55)',
  },
  sheet: {
    marginHorizontal: 12,
    marginBottom: Platform.OS === 'ios' ? 8 : 12,
    borderRadius: 22,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.28)',
    overflow: 'hidden',
    maxHeight: '78%',
    paddingTop: 18,
    paddingHorizontal: 16,
  },
  sheetGlowTop: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 3,
  },
  sheetHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    marginBottom: 14,
    zIndex: 1,
  },
  sheetHeaderIcon: { marginRight: 12, marginTop: 2 },
  sheetHeaderTitles: { flex: 1, paddingRight: 8 },
  kicker: {
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 2,
    color: 'rgba(148,163,184,0.9)',
    marginBottom: 4,
  },
  sheetTitle: {
    fontSize: 20,
    fontWeight: '800',
    color: '#F9FAFB',
    letterSpacing: -0.4,
  },
  liveClockRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 8,
  },
  pulseDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
    opacity: 0.95,
  },
  liveClockText: {
    fontSize: 13,
    fontWeight: '600',
    color: 'rgba(226,232,240,0.88)',
    fontVariant: ['tabular-nums'],
  },
  scroll: { maxHeight: 420 },
  scrollContent: { paddingBottom: 8 },
  dayRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    paddingHorizontal: 12,
    marginBottom: 6,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.18)',
    backgroundColor: 'rgba(15,23,42,0.35)',
  },
  dayRowToday: {
    borderWidth: 1,
  },
  dayRowLeft: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  dayLabel: {
    fontSize: 15,
    fontWeight: '800',
    color: 'rgba(248,250,252,0.95)',
    width: 36,
  },
  todayPill: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
    borderWidth: 1,
    backgroundColor: 'rgba(15,23,42,0.5)',
  },
  todayPillText: { fontSize: 9, fontWeight: '900', letterSpacing: 0.6 },
  timesCol: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  timeDigits: {
    fontFamily: mono,
    fontSize: 15,
    fontWeight: '700',
    color: '#E0F2FE',
    fontVariant: ['tabular-nums'],
  },
  timeSep: {
    fontFamily: mono,
    fontSize: 12,
    color: 'rgba(148,163,184,0.75)',
    fontWeight: '600',
  },
  timeClosed: {
    fontFamily: mono,
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 1,
  },
  timeClosedEmphasis: {
    color: 'rgba(251,146,60,0.95)',
  },
  timeClosedMuted: {
    color: 'rgba(148,163,184,0.75)',
  },
});
