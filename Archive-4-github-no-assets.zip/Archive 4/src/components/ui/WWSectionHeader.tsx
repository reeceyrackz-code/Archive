import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ViewStyle,
  TextStyle,
} from 'react-native';
import { colors } from '../../constants/colors';

interface WWSectionHeaderProps {
  title: string;
  subtitle?: string;
  action?: React.ReactNode;
  style?: ViewStyle;
  titleStyle?: TextStyle;
}

export default function WWSectionHeader({
  title,
  subtitle,
  action,
  style,
  titleStyle,
}: WWSectionHeaderProps) {
  return (
    <View style={[styles.container, style]}>
      <View style={styles.textContainer}>
        <Text style={[styles.title, titleStyle]}>{title}</Text>
        {subtitle && <Text style={styles.subtitle}>{subtitle}</Text>}
      </View>
      {action && <View style={styles.action}>{action}</View>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  textContainer: {
    flex: 1,
  },
  title: {
    color: colors.textOnDarkPrimary,
    fontSize: 18,
    fontWeight: '900',
    letterSpacing: 0.3,
    marginBottom: 4,
  },
  subtitle: {
    color: colors.greyMedium,
    fontSize: 13,
    fontWeight: '500',
  },
  action: {
    marginLeft: 12,
  },
});
