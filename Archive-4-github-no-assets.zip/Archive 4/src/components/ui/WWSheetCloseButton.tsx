import React, { useRef } from 'react';
import { TouchableOpacity, StyleSheet, View, Animated, type ViewStyle } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';
import { hapticFeedback } from '../../services/HapticFeedbackService';

const SKY = colors.SKY;
const PRESS_SCALE = 0.96;

export interface WWSheetCloseButtonProps {
  onPress: () => void;
  accessibilityLabel?: string;
  style?: ViewStyle;
  /** Outer width and height (default 48, matches booking primary min height). */
  size?: number;
  iconSize?: number;
  hitSlop?: { top?: number; bottom?: number; left?: number; right?: number } | number;
}

/**
 * Dismiss control for modals / bottom sheets — same glass + sky border treatment as {@link WWPrimaryButton}.
 */
export default function WWSheetCloseButton({
  onPress,
  accessibilityLabel = 'Close',
  style,
  size = 48,
  iconSize = 22,
  hitSlop = { top: 8, bottom: 8, left: 8, right: 8 },
}: WWSheetCloseButtonProps) {
  const scaleAnim = useRef(new Animated.Value(1)).current;
  const borderRadius = size / 2;

  const handlePress = () => {
    hapticFeedback('medium');
    onPress();
  };

  return (
    <Animated.View style={[{ transform: [{ scale: scaleAnim }] }, style]}>
      <TouchableOpacity
        onPress={handlePress}
        onPressIn={() => {
          Animated.spring(scaleAnim, { toValue: PRESS_SCALE, useNativeDriver: true, speed: 50 }).start();
        }}
        onPressOut={() => {
          Animated.spring(scaleAnim, { toValue: 1, useNativeDriver: true, speed: 50 }).start();
        }}
        hitSlop={hitSlop}
        activeOpacity={0.85}
        accessibilityRole="button"
        accessibilityLabel={accessibilityLabel}
        style={[styles.container, { width: size, height: size, borderRadius }]}
      >
        <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
        <LinearGradient
          colors={[SKY + '59', 'rgba(15,23,42,0.65)']}
          start={{ x: 0, y: 0 }}
          end={{ x: 0, y: 1 }}
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
        />
        <LinearGradient
          colors={['rgba(255,255,255,0.16)', 'rgba(255,255,255,0.03)', 'transparent']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
        />
        <View style={styles.iconLayer} pointerEvents="none">
          <Ionicons name="close" size={iconSize} color={colors.textOnDarkPrimary} />
        </View>
      </TouchableOpacity>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: SKY + '8A',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 8,
  },
  iconLayer: {
    ...StyleSheet.absoluteFillObject,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1,
  },
});
