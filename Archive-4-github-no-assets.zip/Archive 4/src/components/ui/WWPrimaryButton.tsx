import React, { useRef } from 'react';
import {
  TouchableOpacity,
  Text,
  StyleSheet,
  ActivityIndicator,
  View,
  ViewStyle,
  TextStyle,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';
import { hapticFeedback } from '../../services/HapticFeedbackService';

const SKY = colors.SKY;
const PRESS_SCALE = 0.98;

interface WWPrimaryButtonProps {
  title: string;
  onPress: () => void;
  disabled?: boolean;
  loading?: boolean;
  style?: ViewStyle;
  textStyle?: TextStyle;
  /** Legacy emoji / text glyph before the label */
  icon?: string;
  /** Ionicons name — booking-flow standard for confirm / pay / complete CTAs */
  leftIconName?: React.ComponentProps<typeof Ionicons>['name'];
  leftIconSize?: number;
}

export default function WWPrimaryButton({
  title,
  onPress,
  disabled = false,
  loading = false,
  style,
  textStyle,
  icon,
  leftIconName,
  leftIconSize = 20,
}: WWPrimaryButtonProps) {
  const scaleAnim = useRef(new Animated.Value(1)).current;

  const handlePressIn = () => {
    if (disabled || loading) return;
    Animated.spring(scaleAnim, { toValue: PRESS_SCALE, useNativeDriver: true, speed: 50 }).start();
  };
  const handlePressOut = () => {
    Animated.spring(scaleAnim, { toValue: 1, useNativeDriver: true, speed: 50 }).start();
  };

  const handlePress = () => {
    if (!disabled && !loading) {
      hapticFeedback('medium');
      onPress();
    }
  };

  return (
    <Animated.View style={[{ transform: [{ scale: scaleAnim }] }]}>
      <TouchableOpacity
        onPress={handlePress}
        onPressIn={handlePressIn}
        onPressOut={handlePressOut}
        disabled={disabled || loading}
        activeOpacity={0.85}
        style={[styles.container, disabled && styles.disabled, style]}
      >
        <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
        <LinearGradient
          colors={disabled ? ['rgba(100,116,139,0.38)', 'rgba(71,85,105,0.42)'] : [SKY + '59', 'rgba(15,23,42,0.65)']}
          start={{ x: 0, y: 0 }}
          end={{ x: 0, y: 1 }}
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
        />
        <LinearGradient
          colors={['rgba(255,255,255,0.16)', 'rgba(255,255,255,0.03)', 'transparent']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.sheen}
          pointerEvents="none"
        />
        <View style={styles.gradient}>
          {loading ? (
            <ActivityIndicator color={colors.textOnDarkPrimary} size="small" />
          ) : (
            <>
              {leftIconName ? (
                <Ionicons name={leftIconName} size={leftIconSize} color={colors.textOnDarkPrimary} />
              ) : icon ? (
                <Text style={styles.icon}>{icon}</Text>
              ) : null}
              <Text style={[styles.text, textStyle]}>{title}</Text>
            </>
          )}
        </View>
      </TouchableOpacity>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    minHeight: 50,
    borderRadius: 24,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: SKY + '8A',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 8,
  },
  gradient: {
    minHeight: 50,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 11,
    paddingHorizontal: 14,
    gap: 8,
  },
  sheen: {
    ...StyleSheet.absoluteFillObject,
  },
  text: {
    color: colors.textOnDarkPrimary,
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.35,
  },
  icon: {
    marginRight: 8,
    fontSize: 18,
  },
  disabled: {
    opacity: 0.5,
  },
});
