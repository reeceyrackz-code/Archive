import React from 'react';
import { StyleSheet } from 'react-native';
import Animated from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';

type SplashBackgroundProps = {
  colors: readonly [string, string];
  opacity?: number;
};

export default function SplashBackground({ colors, opacity = 1 }: Readonly<SplashBackgroundProps>) {
  return (
    <Animated.View style={[StyleSheet.absoluteFillObject, { opacity }]}>
      <LinearGradient colors={[colors[0], colors[1]]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} />
    </Animated.View>
  );
}
