/**
 * Single "pro profile" layout - Hinge-inspired hero, prompts, washes, reviews.
 * Shared by Explore sheet and Hub details screen.
 */
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, Image, ActivityIndicator } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { WashHubPlaceholder } from '../shared/washValeterPlaceholders';
import GradientIconBox from '../shared/GradientIconBox';
import SheetQuickIcon from '../shared/SheetQuickIcon';
import { colors } from '../../constants/colors';
import { serviceOptions } from '../../constants/serviceOptions';
import { HUB_WASH_DISPLAY_NAME } from '../../constants/washTierPlatformCopy';
import { detailingServiceOptions, repairServiceOptions } from '../../constants/serviceOptions';
import { WASH_TIER_UI, washTierIconName } from '../../constants/washTierVisuals';
import {
  DETAILING_IMAGE,
  CERAMIC_DETAIL_IMAGE,
  SOFTOP_DETAIL_IMAGE,
  MOULD_DETAIL_IMAGE,
  HEADLIGHT_DETAIL_IMAGE,
} from '../../../app/assets/_assetExports';
import { getOpeningHoursTeaser, type OpeningHourRow } from '../shared/OpeningHoursSheet';

const SKY = colors.SKY;
const DETAILING_YELLOW = colors.DETAILING_YELLOW;

export type HubProfileService = {
  service_name: string;
  price: number;
  duration_minutes: number;
  is_enabled?: boolean;
};

export type HubProfileReview = {
  rating: number;
  review: string | null;
  reviewerName: string;
};

function serviceNameToTier(name: string): { id: string; label: string } | null {
  const n = (name || '').trim();
  if (n === 'Bronze Wash') return { id: 'bronze-wash', label: 'Bronze' };
  if (n === 'Silver Wash') return { id: 'silver-wash', label: 'Silver' };
  if (n === 'Gold Wash') return { id: 'gold-wash', label: 'Gold' };
  if (n === 'Platinum Wash') return { id: 'platinum-wash', label: 'Platinum' };
  if (n === 'Diamond Wash' || n === 'Emerald Wash') return { id: 'emerald-wash', label: 'Diamond' };
  return null;
}

/** Global tier order: Bronze → Silver → Gold → Platinum → Diamond. */
const TIER_ORDER = ['Bronze Wash', 'Silver Wash', 'Gold Wash', 'Platinum Wash', 'Diamond Wash'] as const;

function matchesHubTierRow(tierName: (typeof TIER_ORDER)[number], serviceName: string): boolean {
  const n = (serviceName || '').trim();
  if (tierName === 'Diamond Wash') return n === 'Diamond Wash' || n === 'Emerald Wash';
  return n === tierName;
}

export type HubProfileBodyProps = {
  name: string;
  kicker: string;
  address: string | null;
  rating: number | null;
  reviewCount: number | null;
  isOpen?: boolean;
  ecoWashing?: boolean | null;
  detailingOffered?: boolean | null;
  offersMobile?: boolean | null;
  openingHours: OpeningHourRow[];
  onOpenHours: () => void;
  services: HubProfileService[];
  reviews: HubProfileReview[];
  extrasLoading: boolean;
  accentColor: string;
  borderGlass: string;
  onWashTierPress?: (tierId: string) => void;
  prepend?: React.ReactNode;
  profileImageUrl?: string | null;
};

export default function HubProfileBody({
  name,
  kicker,
  address,
  rating,
  reviewCount,
  isOpen = true,
  ecoWashing,
  detailingOffered,
  offersMobile,
  openingHours,
  onOpenHours,
  services,
  reviews,
  extrasLoading,
  accentColor,
  borderGlass,
  onWashTierPress,
  prepend,
  profileImageUrl,
}: Readonly<HubProfileBodyProps>) {
  /** Set true when hub hero images are wired end-to-end; until then show camera placeholder. */
  const HUB_HERO_PHOTO_ENABLED = false;
  const [heroImageFailed, setHeroImageFailed] = useState(false);
  useEffect(() => {
    setHeroImageFailed(false);
  }, [profileImageUrl]);

  const trimmedProfileUrl = profileImageUrl?.trim() ?? '';
  const showHeroPhoto = HUB_HERO_PHOTO_ENABLED && trimmedProfileUrl.length > 0 && !heroImageFailed;

  const tierServices = TIER_ORDER.map((tierName) =>
    services.find((s) => matchesHubTierRow(tierName, s.service_name || ''))
  ).filter(Boolean) as HubProfileService[];

  return (
    <>
      <View style={[styles.heroWrap, { borderColor: borderGlass }]}>
        {showHeroPhoto ? (
          <Image
            source={{ uri: trimmedProfileUrl }}
            style={StyleSheet.absoluteFillObject}
            resizeMode="cover"
            onError={() => setHeroImageFailed(true)}
          />
        ) : (
          <WashHubPlaceholder iconSize={64} iconName="camera-outline" style={StyleSheet.absoluteFillObject} />
        )}
        <LinearGradient colors={['transparent', 'rgba(2,6,23,0.92)']} style={styles.heroGradient} />
        <View style={styles.heroTextBlock}>
          <Text style={styles.heroKicker}>{kicker}</Text>
          <Text style={styles.heroTitle} numberOfLines={3}>
            {name}
          </Text>
          <View style={styles.heroMetaRow}>
            {rating != null ? (
              <View style={styles.heroMetaPill}>
                <Ionicons name="star" size={14} color="#FBBF24" />
                <Text style={styles.heroMetaText}>{Number(rating).toFixed(1)}</Text>
                {reviewCount != null && reviewCount > 0 ? (
                  <Text style={styles.heroMetaMuted}>- {reviewCount} reviews</Text>
                ) : null}
              </View>
            ) : null}
            <View style={[styles.statusMini, !isOpen && styles.statusMiniClosed]}>
              <View style={[styles.statusDot, isOpen && styles.statusDotOn]} />
              <Text style={[styles.statusMiniText, !isOpen && styles.statusMiniTextClosed]}>{isOpen ? 'Open' : 'Closed'}</Text>
            </View>
          </View>
        </View>
      </View>

      {prepend}

      <View style={styles.section}>
        <Text style={styles.sectionKicker}>ABOUT THIS SPOT</Text>
        {address ? (
          <View style={styles.addrRow}>
            <SheetQuickIcon icon="map" preset="purple" />
            <Text style={styles.addrText}>{address}</Text>
          </View>
        ) : null}
        <View style={styles.traitRow}>
          {ecoWashing ? (
            <View style={[styles.traitChip, { borderColor: borderGlass }]}>
              <SheetQuickIcon icon="leaf-outline" preset="emerald" size="chip" />
              <Text style={styles.traitText}>Eco</Text>
            </View>
          ) : null}
          {detailingOffered ? (
            <View style={[styles.traitChip, { borderColor: borderGlass }]}>
              <SheetQuickIcon icon="sparkles-outline" preset="amber" size="chip" />
              <Text style={styles.traitText}>Detailing</Text>
            </View>
          ) : null}
          {offersMobile ? (
            <View style={[styles.traitChip, { borderColor: borderGlass }]}>
              <SheetQuickIcon icon="car-sport-outline" preset="blue" size="chip" />
              <Text style={styles.traitText}>Mobile</Text>
            </View>
          ) : null}
        </View>
      </View>

      {openingHours.length > 0 ? (
        <Pressable
          onPress={onOpenHours}
          style={({ pressed }) => [styles.hoursCard, { borderColor: borderGlass }, pressed && styles.pressed]}
        >
          <Text style={styles.sectionKicker}>HOURS</Text>
          <View style={styles.hoursRow}>
            <SheetQuickIcon icon="time-outline" preset="cyan" />
            <View style={{ flex: 1 }}>
              <Text style={styles.hoursTeaser} numberOfLines={2}>
                {getOpeningHoursTeaser(openingHours)}
              </Text>
              <Text style={styles.hoursHint}>Tap for full schedule</Text>
            </View>
            <Ionicons name="chevron-forward" size={18} color="rgba(255,255,255,0.4)" />
          </View>
        </Pressable>
      ) : null}

      <View style={styles.section}>
        <Text style={styles.sectionKicker}>POPULAR WASHES</Text>
        {extrasLoading ? (
          <ActivityIndicator color={accentColor} style={{ marginVertical: 20 }} />
        ) : tierServices.length === 0 ? (
          <Text style={styles.mutedCenter}>Tiers appear when this hub publishes pricing.</Text>
        ) : (
          <View style={[styles.washList, { borderColor: borderGlass }]}>
            {tierServices.map((s) => {
              const tier = serviceNameToTier(s.service_name);
              if (!tier) return null;
              const option = serviceOptions.find((o) => o.id === tier.id);
              const label =
                tier.id in HUB_WASH_DISPLAY_NAME
                  ? HUB_WASH_DISPLAY_NAME[tier.id as keyof typeof HUB_WASH_DISPLAY_NAME]
                  : option?.name ?? `${tier.label} Wash`;
              const tierUi = WASH_TIER_UI[tier.id] ?? WASH_TIER_UI['bronze-wash'];
              const tierIcon = washTierIconName(tier.id) as keyof typeof Ionicons.glyphMap;
              const dur = s.duration_minutes > 0 ? `${s.duration_minutes} min` : null;
              return (
                <Pressable
                  key={s.service_name}
                  onPress={() => onWashTierPress?.(tier.id)}
                  style={({ pressed }) => [styles.washRow, pressed && styles.pressed]}
                  disabled={!onWashTierPress}
                >
                  <GradientIconBox
                    icon={tierIcon}
                    colors={[tierUi.main, tierUi.main]}
                    boxSize={48}
                    borderRadius={15}
                    elevated
                  />
                  <View style={{ flex: 1 }}>
                    <Text style={styles.washName}>{label}</Text>
                    {dur ? <Text style={styles.washDur}>{dur}</Text> : null}
                  </View>
                  <Text style={[styles.washPrice, { color: accentColor }]}>Prices vary</Text>
                  {onWashTierPress ? <Ionicons name="chevron-forward" size={18} color="rgba(255,255,255,0.35)" /> : null}
                </Pressable>
              );
            })}
          </View>
        )}
      </View>

      {detailingOffered ? (
        <View style={styles.section}>
          <Text style={styles.sectionKicker}>ALSO INTO</Text>
          <Text style={styles.sectionSub}>Detailing - tap booking for exact paint-care pricing.</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.detailScroll}>
            {[...repairServiceOptions, ...detailingServiceOptions].slice(0, 14).map((d) => {
              let img = DETAILING_IMAGE;
              if (d.id === 'ceramic-coating') img = CERAMIC_DETAIL_IMAGE;
              else if (d.id === 'soft-top-restoration') img = SOFTOP_DETAIL_IMAGE;
              else if (d.id === 'mould-removal') img = MOULD_DETAIL_IMAGE;
              else if (d.id === 'headlight-restoration') img = HEADLIGHT_DETAIL_IMAGE;
              return (
                <View key={d.id} style={[styles.detailCard, { borderColor: borderGlass }]}>
                  <Image source={img} style={styles.detailImg} resizeMode="cover" />
                  <Text style={styles.detailName} numberOfLines={2}>
                    {d.name}
                  </Text>
                  <Text style={[styles.detailFrom, { color: accentColor }]}>Prices vary</Text>
                </View>
              );
            })}
          </ScrollView>
        </View>
      ) : null}

      <View style={styles.section}>
        <Text style={styles.sectionKicker}>WHAT CUSTOMERS SAY</Text>
        {extrasLoading ? (
          <ActivityIndicator color={accentColor} style={{ marginVertical: 16 }} />
        ) : reviews.length === 0 ? (
          <View style={[styles.reviewsEmpty, { borderColor: borderGlass }]}>
            <SheetQuickIcon icon="chatbox-ellipses-outline" preset="gray" />
            <Text style={styles.reviewsEmptyText}>No reviews yet - book a wash and be the first to share.</Text>
          </View>
        ) : (
          <View style={styles.reviewsStack}>
            {reviews.slice(0, 8).map((rev, idx) => (
              <View key={`${rev.reviewerName}-${idx}`} style={[styles.quoteCard, { borderColor: borderGlass }]}>
                <Text style={styles.quoteMark}>"</Text>
                <View style={styles.quoteTop}>
                  <Ionicons name="star" size={14} color="#FBBF24" />
                  <Text style={styles.quoteRating}>{rev.rating.toFixed(1)}</Text>
                  <Text style={styles.quoteBy}>{rev.reviewerName}</Text>
                </View>
                {rev.review ? (
                  <Text style={styles.quoteBody}>{rev.review}</Text>
                ) : (
                  <Text style={styles.quoteMuted}>Rated without a comment</Text>
                )}
              </View>
            ))}
          </View>
        )}
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  heroWrap: {
    height: 216,
    marginHorizontal: -4,
    borderRadius: 22,
    overflow: 'hidden',
    marginBottom: 16,
    borderWidth: 1,
  },
  heroGradient: { ...StyleSheet.absoluteFillObject },
  heroTextBlock: {
    position: 'absolute',
    left: 16,
    right: 16,
    bottom: 16,
  },
  heroKicker: {
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 2.2,
    color: 'rgba(226,232,240,0.85)',
    marginBottom: 6,
  },
  heroTitle: {
    fontSize: 28,
    fontWeight: '800',
    color: '#F8FAFC',
    letterSpacing: -0.8,
    lineHeight: 32,
    marginBottom: 10,
  },
  heroMetaRow: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 10 },
  heroMetaPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 999,
    backgroundColor: 'rgba(15,23,42,0.55)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.35)',
  },
  heroMetaText: { fontSize: 14, fontWeight: '800', color: '#F9FAFB' },
  heroMetaMuted: { fontSize: 13, fontWeight: '600', color: 'rgba(226,232,240,0.75)' },
  statusMini: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 999,
    backgroundColor: 'rgba(16,185,129,0.18)',
    borderWidth: 1,
    borderColor: 'rgba(34,197,94,0.4)',
  },
  statusMiniClosed: {
    backgroundColor: 'rgba(239,68,68,0.15)',
    borderColor: 'rgba(248,113,113,0.4)',
  },
  statusDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: 'rgba(34,197,94,0.6)' },
  statusDotOn: { backgroundColor: '#4ADE80' },
  statusMiniText: { fontSize: 12, fontWeight: '800', color: '#86EFAC' },
  statusMiniTextClosed: { color: '#FCA5A5' },
  section: { marginBottom: 22 },
  sectionKicker: {
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 2,
    color: 'rgba(148,163,184,0.95)',
    marginBottom: 10,
  },
  sectionSub: { fontSize: 13, color: 'rgba(203,213,225,0.88)', marginBottom: 12, lineHeight: 19 },
  addrRow: { flexDirection: 'row', gap: 10, alignItems: 'flex-start', marginBottom: 12 },
  addrText: { flex: 1, fontSize: 15, color: '#E2E8F0', lineHeight: 22 },
  traitRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  traitChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 999,
    backgroundColor: 'rgba(15,23,42,0.45)',
    borderWidth: 1,
  },
  traitText: { fontSize: 12, fontWeight: '700', color: '#F1F5F9' },
  hoursCard: {
    borderRadius: 18,
    borderWidth: 1,
    padding: 14,
    marginBottom: 22,
    backgroundColor: 'rgba(15,23,42,0.35)',
  },
  hoursRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginTop: 6 },
  hoursTeaser: { fontSize: 15, fontWeight: '700', color: '#F9FAFB' },
  hoursHint: { fontSize: 12, color: 'rgba(148,163,184,0.9)', marginTop: 4 },
  washList: {
    borderRadius: 18,
    borderWidth: 1,
    overflow: 'hidden',
    backgroundColor: 'rgba(15,23,42,0.28)',
  },
  washRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 14,
    paddingHorizontal: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'rgba(148,163,184,0.15)',
  },
  washName: { fontSize: 16, fontWeight: '700', color: '#F8FAFC' },
  washDur: { fontSize: 12, color: 'rgba(148,163,184,0.95)', marginTop: 2 },
  washPrice: { fontSize: 17, fontWeight: '800' },
  detailScroll: { gap: 12, paddingVertical: 4 },
  detailCard: {
    width: 132,
    borderRadius: 14,
    overflow: 'hidden',
    borderWidth: 1,
    backgroundColor: 'rgba(15,23,42,0.4)',
    paddingBottom: 10,
  },
  detailImg: { width: '100%', height: 88 },
  detailName: { fontSize: 12, fontWeight: '700', color: '#F1F5F9', marginHorizontal: 8, marginTop: 8, minHeight: 32 },
  detailFrom: { fontSize: 13, fontWeight: '800', marginHorizontal: 8, marginTop: 4 },
  reviewsStack: { gap: 12 },
  quoteCard: {
    borderRadius: 18,
    borderWidth: 1,
    padding: 16,
    backgroundColor: 'rgba(15,23,42,0.38)',
  },
  quoteMark: {
    fontSize: 42,
    fontWeight: '800',
    color: 'rgba(125,211,252,0.22)',
    lineHeight: 44,
    marginTop: -8,
    marginBottom: -6,
  },
  quoteTop: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 },
  quoteRating: { fontSize: 15, fontWeight: '800', color: '#F9FAFB' },
  quoteBy: { fontSize: 13, fontWeight: '600', color: 'rgba(148,163,184,0.95)', marginLeft: 4, flex: 1 },
  quoteBody: { fontSize: 15, lineHeight: 22, color: '#E2E8F0', fontStyle: 'italic' },
  quoteMuted: { fontSize: 14, color: 'rgba(148,163,184,0.85)', fontStyle: 'italic' },
  reviewsEmpty: {
    alignItems: 'center',
    padding: 24,
    borderRadius: 16,
    borderWidth: 1,
    gap: 10,
  },
  reviewsEmptyText: { fontSize: 14, color: 'rgba(148,163,184,0.95)', textAlign: 'center', lineHeight: 20 },
  mutedCenter: { fontSize: 14, color: 'rgba(148,163,184,0.9)', textAlign: 'center', paddingVertical: 12 },
  pressed: { opacity: 0.88 },
});
