import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  Easing,
  Image,
  LayoutChangeEvent,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useThemeOptional } from '../contexts/ThemeContext';
import { customerTheme } from '../constants/customerTheme';
import { colors } from '../constants/colors';
import { APP_LOGO_SOURCE } from '../constants/appAssets';
import { SHADOWS } from '../constants/designTokens';

const LOGO_SIZE = 132;
const LOGO_BORDER_RADIUS = 28;
const SKY = colors.SKY;
const PULSE_MS = 1400;

interface LoadingScreenProps {
  /** 0–1 boot progress; when omitted, shows an indeterminate (shimmer) bar. */
  progress?: number;
  /** Optional status line under the bar. */
  message?: string;
}

export default function LoadingScreen({ progress, message }: Readonly<LoadingScreenProps>) {
  const themeContext = useThemeOptional();
  const theme = themeContext?.theme ?? customerTheme;
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const shimmerAnim = useRef(new Animated.Value(0)).current;
  const [trackWidth, setTrackWidth] = useState(0);
  const determinate = progress != null;

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.06,
          duration: PULSE_MS,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: PULSE_MS,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [pulseAnim]);

  useEffect(() => {
    if (determinate) return;
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(shimmerAnim, {
          toValue: 1,
          duration: 1200,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.timing(shimmerAnim, {
          toValue: 0,
          duration: 0,
          useNativeDriver: true,
        }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [determinate, shimmerAnim]);

  const onTrackLayout = (e: LayoutChangeEvent) => {
    setTrackWidth(e.nativeEvent.layout.width);
  };

  const pct = determinate ? Math.round(Math.min(100, Math.max(0, progress! * 100))) : null;

  const shimmerTranslate =
    trackWidth > 0
      ? shimmerAnim.interpolate({
          inputRange: [0, 1],
          outputRange: [-trackWidth * 0.4, trackWidth * 1.05],
        })
      : 0;

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={theme.backgroundGradient}
        style={StyleSheet.absoluteFill}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
      />

      <View style={styles.content}>
        <Animated.View style={[styles.logoWrapper, { transform: [{ scale: pulseAnim }] }]}>
          <View style={styles.logoInner}>
            <Image source={APP_LOGO_SOURCE} style={styles.logoImage} resizeMode="contain" />
          </View>
        </Animated.View>

        <View style={styles.brandContainer}>
          <Text style={styles.brandTitle}>Wish a Wash</Text>
          <Text style={styles.brandSubtitle}>Your Wish, Our Wash</Text>
        </View>

        <View style={styles.barSection} onLayout={onTrackLayout}>
          <View style={styles.progressBarTrack}>
            {determinate ? (
              <LinearGradient
                colors={[SKY, colors.ICON_SKY, '#0EA5E9']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={[styles.progressBarFill, { width: `${pct}%` }]}
              />
            ) : (
              <>
                <View style={styles.indeterminateTrackDim} />
                <Animated.View
                  style={[
                    styles.shimmerChunk,
                    {
                      transform: [{ translateX: shimmerTranslate }],
                    },
                  ]}
                >
                  <LinearGradient
                    colors={['transparent', 'rgba(255,255,255,0.45)', 'transparent']}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 0 }}
                    style={StyleSheet.absoluteFill}
                  />
                </Animated.View>
              </>
            )}
          </View>

          {determinate && pct != null ? (
            <Text style={styles.percentText}>{pct}%</Text>
          ) : null}

          {(message || !determinate) && (
            <Text style={styles.statusText} numberOfLines={2}>
              {message ?? 'Loading…'}
            </Text>
          )}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  content: {
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
    paddingHorizontal: 28,
    width: '100%',
  },
  logoWrapper: {
    width: LOGO_SIZE,
    height: LOGO_SIZE,
    borderRadius: LOGO_BORDER_RADIUS,
    backgroundColor: colors.surfaceOverlayMid,
    overflow: 'hidden',
    ...SHADOWS.xl,
    shadowOffset: { width: 0, height: 6 },
    shadowRadius: 14,
    borderWidth: 2,
    borderColor: colors.borderLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  logoInner: {
    width: LOGO_SIZE,
    height: LOGO_SIZE,
    borderRadius: LOGO_BORDER_RADIUS,
    overflow: 'hidden',
  },
  logoImage: {
    width: LOGO_SIZE,
    height: LOGO_SIZE,
    borderRadius: LOGO_BORDER_RADIUS,
  },
  brandContainer: {
    alignItems: 'center',
    marginBottom: 28,
  },
  brandTitle: {
    fontSize: 26,
    fontWeight: '800',
    color: colors.LIGHT_SKY,
    marginBottom: 4,
    textShadowColor: 'rgba(135, 206, 235, 0.45)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 8,
    letterSpacing: 0.8,
  },
  brandSubtitle: {
    fontSize: 14,
    color: SKY,
    textAlign: 'center',
    fontWeight: '600',
    letterSpacing: 0.25,
    opacity: 0.9,
  },
  barSection: {
    width: '100%',
    maxWidth: 300,
    alignSelf: 'center',
  },
  progressBarTrack: {
    height: 8,
    borderRadius: 8,
    backgroundColor: 'rgba(255,255,255,0.12)',
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.22)',
  },
  progressBarFill: {
    height: '100%',
    borderRadius: 7,
    minWidth: 0,
  },
  indeterminateTrackDim: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(15,23,42,0.35)',
  },
  shimmerChunk: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: '42%',
  },
  percentText: {
    marginTop: 10,
    fontSize: 13,
    fontWeight: '700',
    color: SKY,
    textAlign: 'center',
    letterSpacing: 0.5,
  },
  statusText: {
    marginTop: 8,
    fontSize: 13,
    color: 'rgba(241,245,249,0.72)',
    textAlign: 'center',
    fontWeight: '500',
    lineHeight: 18,
  },
});
