import React, { useEffect, useRef } from 'react';
import { View, StyleSheet, Animated, Dimensions } from 'react-native';
import { AccountType, getAccountTheme } from '../../constants/accountThemes';
import { colors } from '../../constants/colors';
import { useThemeOptional } from '../../contexts/ThemeContext';

const { width, height } = Dimensions.get('window');

/** Soft lime from customer “Book a service” hero gradient — used for a few bubbles only. */
const BOOK_SERVICE_BUBBLE_FILL = 'rgba(202, 224, 80, 0.26)';

interface BubbleBackgroundProps {
  accountType?: AccountType;
  bubbleCount?: number;
}

interface Bubble {
  translateY: Animated.Value;
  translateX: Animated.Value;
  opacity: Animated.Value;
  scale: Animated.Value;
  size: number;
  leftPosition: number;
  duration: number;
  delay: number;
}

export default function BubbleBackground({ 
  accountType = 'customer',
  bubbleCount = 6 
}: BubbleBackgroundProps) {
  const themeCtx = useThemeOptional();
  const mode = themeCtx?.colorScheme === 'dark' ? 'dark' : 'light';
  const theme = getAccountTheme(accountType, mode);
  
  // Get theme color for bubbles
  const getBubbleColor = () => {
    if (accountType === 'business') {
      // Green tints for business
      return theme.primary || '#84CC16';
    } else if (accountType === 'customer') {
      // Blue/sky tints for customer
      return colors.SKY || '#87CEEB';
    } else {
      // Valeter - use existing sky color
      return colors.SKY || '#87CEEB';
    }
  };

  const bubbleColor = getBubbleColor();
  
  const bubbles = useRef<Bubble[]>(
    Array.from({ length: bubbleCount }, (_, i) => ({
      translateY: new Animated.Value(0),
      translateX: new Animated.Value(0),
      opacity: new Animated.Value(0.1 + Math.random() * 0.2),
      scale: new Animated.Value(0.8 + Math.random() * 0.4),
      size: 20 + Math.random() * 30,
      leftPosition: Math.random() * width,
      duration: 8000 + Math.random() * 7000, // 8-15 seconds
      delay: i * 1000,
    }))
  ).current;

  useEffect(() => {
    const timeouts: ReturnType<typeof setTimeout>[] = [];
    const runningAnimations: Animated.CompositeAnimation[] = [];

    bubbles.forEach((bubble) => {
      const animateBubble = () => {
        const verticalAnim = Animated.loop(
          Animated.sequence([
            Animated.timing(bubble.translateY, {
              toValue: -height * 0.3 - bubble.size,
              duration: bubble.duration,
              useNativeDriver: true,
            }),
            Animated.timing(bubble.translateY, {
              toValue: 0,
              duration: 0,
              useNativeDriver: true,
            }),
          ])
        );

        const horizontalAnim = Animated.loop(
          Animated.sequence([
            Animated.timing(bubble.translateX, {
              toValue: 20 + Math.random() * 30,
              duration: bubble.duration * 0.7,
              useNativeDriver: true,
            }),
            Animated.timing(bubble.translateX, {
              toValue: -20 - Math.random() * 30,
              duration: bubble.duration * 0.7,
              useNativeDriver: true,
            }),
          ])
        );

        const scaleAnim = Animated.loop(
          Animated.sequence([
            Animated.timing(bubble.scale, {
              toValue: 1.2,
              duration: bubble.duration * 0.5,
              useNativeDriver: true,
            }),
            Animated.timing(bubble.scale, {
              toValue: 0.8,
              duration: bubble.duration * 0.5,
              useNativeDriver: true,
            }),
          ])
        );

        const opacityAnim = Animated.loop(
          Animated.sequence([
            Animated.timing(bubble.opacity, {
              toValue: 0.3,
              duration: bubble.duration * 0.6,
              useNativeDriver: true,
            }),
            Animated.timing(bubble.opacity, {
              toValue: 0.1,
              duration: bubble.duration * 0.6,
              useNativeDriver: true,
            }),
          ])
        );

        const parallel = Animated.parallel([
          verticalAnim,
          horizontalAnim,
          scaleAnim,
          opacityAnim,
        ]);
        runningAnimations.push(parallel);
        parallel.start();
      };

      const timeout = setTimeout(animateBubble, bubble.delay);
      timeouts.push(timeout);
    });

    return () => {
      timeouts.forEach((t) => clearTimeout(t));
      runningAnimations.forEach((anim) => anim.stop());
    };
  }, []);

  return (
    <View style={styles.container} pointerEvents="none">
      {bubbles.map((bubble, index) => {
        const useBookServiceTint =
          accountType === 'customer' && (index === 1 || index === 4);
        const fill = useBookServiceTint ? BOOK_SERVICE_BUBBLE_FILL : bubbleColor;
        const bubbleStyle = {
          position: 'absolute' as const,
          left: bubble.leftPosition,
          bottom: -bubble.size,
          width: bubble.size,
          height: bubble.size,
          borderRadius: bubble.size / 2,
          backgroundColor: fill,
          transform: [
            { translateY: bubble.translateY },
            { translateX: bubble.translateX },
            { scale: bubble.scale },
          ],
          opacity: bubble.opacity,
        };

        return <Animated.View key={index} style={bubbleStyle} />;
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 0,
    overflow: 'hidden',
  },
});


