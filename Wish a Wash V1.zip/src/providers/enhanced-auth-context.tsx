// src/providers/enhanced-auth-context.tsx
import React, { createContext, useContext, useEffect, useMemo, useRef, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Linking from 'expo-linking';
import { supabase, SUPABASE_AUTH_STORAGE_KEY } from '../lib/supabase';
import type { Session, User as SbUser } from '@supabase/supabase-js';
import { applyReferralCodeToUser } from '../services/LoyaltyService';
import { nameFromAppleFullName } from '../utils/profileSetupGate';

/* ---------------- Types ---------------- */

export interface Organization {
  id: string;
  name: string;
  registrationNumber?: string;
  address?: string;
  contactEmail: string;
  contactPhone?: string;
  isVerified: boolean;
  insuranceVerified: boolean;
  licenseVerified: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  userType: 'customer' | 'valeter' | 'organization';
  organizationId?: string;
  organizationType?: 'independent' | 'registered';
  profilePicture?: string;
  isVerified: boolean;
  verificationType: 'none' | 'profile' | 'car';
  totalWashes: number;
  tier: 'bronze' | 'silver' | 'gold' | 'platinum';
  tierPoints: number;
  joinDate: string;
}

interface AuthContextType {
  user: User | null;
  /** True while we’re bootstrapping session/profile OR mid-auth mutations. */
  isLoading: boolean;
  /** True when the role (userType) is reliable; use this for routing. */
  authReady: boolean;

  login: (email: string, password: string) => Promise<boolean>;
  loginWithGoogle: () => Promise<boolean>;
  loginWithApple: (
    credential: {
      identityToken?: string | null;
      nonce?: string | null;
      fullName?: { givenName?: string | null; familyName?: string | null; middleName?: string | null } | null;
    },
    seed?: Partial<User>
  ) => Promise<boolean>;
  logout: () => Promise<void>;
  register: (userData: Omit<User, 'id' | 'joinDate'> & {
    password: string;
    isIndividualValeter?: boolean;
    organizationId?: string;
    /** NEW: for org signups */
    orgName?: string;
    contactName?: string;
    referralCode?: string;
  }) => Promise<boolean>;
  registerWithGoogle: (seed?: Partial<User> & { referralCode?: string }) => Promise<boolean>;
  registerWithApple: (
    credential: {
      identityToken?: string | null;
      nonce?: string | null;
      fullName?: { givenName?: string | null; familyName?: string | null; middleName?: string | null } | null;
    },
    seed?: Partial<User> & { referralCode?: string }
  ) => Promise<boolean>;
  updateUser: (updates: Partial<User>) => Promise<void>;
  updatePassword: (currentPassword: string, newPassword: string) => Promise<void>;
  updateProfile: (updates: Partial<User>) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  autoLoginCustomer: () => Promise<void>;
  autoLoginValeter: () => Promise<void>;
  hasAdminAccess: () => boolean;
  isBusinessOwner: () => boolean;
  markWelcomeSeen: (userType: 'customer' | 'valeter') => Promise<void>;
  hasSeenWelcome: (userType: 'customer' | 'valeter') => Promise<boolean>;
  isIndividualValeter: () => boolean;
  isOrganizationValeter: () => boolean;
  requiresIndividualDocuments: () => boolean;
  requiresOrganizationDocuments: () => boolean;
  getOrganization: () => Organization | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);
const SESSION_KEY = 'user_session';

/* ---------------- Utils ---------------- */

function withTimeout<T>(p: Promise<T>, ms: number, label: string): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const t = setTimeout(() => {
      console.warn(`[Auth TIMEOUT] ${label} timed out after ${ms}ms`);
      reject(new Error(`timeout:${label}`));
    }, ms);
    p.then(v => { clearTimeout(t); resolve(v); })
     .catch(e => { clearTimeout(t); reject(e); });
  });
}

/* ---------------- Helpers ---------------- */

// Known customer emails that should always be treated as customers
const KNOWN_CUSTOMER_EMAILS = [
  // 'deanlingard@yahoo.co.uk',
  // 'customer@test.com',
].map(e => e.toLowerCase());

// Known valeter emails that should always be treated as valeters
const KNOWN_VALETER_EMAILS = [
  // 'lingardodeano@gmail.com',
  // 'valeter@test.com',
].map(e => e.toLowerCase());

const toAppUser = (sbUser: SbUser, profile: any): User => {
  const md = sbUser.user_metadata ?? {};
  const email = (sbUser.email ?? '').toLowerCase();
  
  // Email-based override: check known customer/valeter emails first
  let role: User['userType'] = 'customer';
  if (KNOWN_CUSTOMER_EMAILS.includes(email)) {
    role = 'customer';
  } else if (KNOWN_VALETER_EMAILS.includes(email)) {
    role = 'valeter';
  } else {
    // Fall back to database/profile values
    role = (profile?.user_type ??
      md.userType ??
      'customer') as User['userType'];
  }

  return {
    id: sbUser.id,
    email: sbUser.email ?? '',
    name: profile?.full_name ?? md.full_name ?? md.name ?? '',
    phone: profile?.phone ?? md.phone ?? '',
    userType: role,
    organizationId: profile?.organization_id ?? md.organizationId ?? undefined,
    organizationType: (profile?.organization_type ?? md.organizationType) as User['organizationType'],
    profilePicture: profile?.profile_picture ?? md.profilePicture ?? undefined,
    isVerified: !!profile?.is_verified,
    verificationType: (profile?.verification_type ?? 'none') as User['verificationType'],
    totalWashes: profile?.total_washes ?? 0,
    tier: (profile?.tier ?? 'bronze') as User['tier'],
    tierPoints: profile?.tier_points ?? 0,
    joinDate: (profile?.created_at ?? sbUser.created_at ?? new Date().toISOString()),
  };
};

const upsertProfile = async (sbUser: SbUser, seed?: Partial<User> & { referralCode?: string }) => {
  // Build payload, but OMIT user_type unless we actually have one.
  const payload: Record<string, any> = {
    id: sbUser.id,
    email: sbUser.email,
  };

  const name =
    seed?.name ??
    sbUser.user_metadata?.full_name ??
    sbUser.user_metadata?.name ??
    null;
  if (name) payload.full_name = name;

  const phone = seed?.phone ?? sbUser.user_metadata?.phone ?? null;
  if (phone) payload.phone = phone;

  const resolvedUserType = seed?.userType ?? sbUser.user_metadata?.userType ?? null;
  if (resolvedUserType) payload.user_type = resolvedUserType; // <— only set if known

  // Other fields: only set if defined — don’t blast defaults onto existing rows
  if (typeof seed?.isVerified === 'boolean') payload.is_verified = seed.isVerified;
  if (seed?.verificationType) payload.verification_type = seed.verificationType;
  if (typeof seed?.totalWashes === 'number') payload.total_washes = seed.totalWashes;
  if (seed?.tier) payload.tier = seed.tier;
  if (typeof seed?.tierPoints === 'number') payload.tier_points = seed.tierPoints;

  const orgId = seed?.organizationId ?? sbUser.user_metadata?.organizationId;
  if (orgId !== undefined && orgId !== null) payload.organization_id = orgId;

  const orgType = seed?.organizationType ?? sbUser.user_metadata?.organizationType;
  if (orgType !== undefined && orgType !== null) payload.organization_type = orgType;

  // INSERT ONLY; ignore duplicates. This will NOT overwrite existing rows.
  const { error } = await supabase
    .from('profiles')
    .insert(payload, { onConflict: 'id', ignoreDuplicates: true });

  if (error) console.warn('[Auth] profiles insert-if-not-exists error:', error.message);
};

const fetchProfile = async (userId: string) => {
  
  // Fetch from profiles table (user_type is stored here, not in a separate users table)
  const { data: profileData, error: profileError } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .maybeSingle();
  
  if (profileError) {
    console.warn('[Auth DEBUG] fetchProfile (profiles) error:', profileError.message);
  }
  
  // user_type is stored in profiles table, not a separate users table
  const mergedData = {
    ...profileData,
    user_type: profileData?.user_type ?? null,
  };
  
  return mergedData;
};

const isInvalidRefreshTokenError = (e: any): boolean => {
  const msg = String(e?.message || '').toLowerCase();
  return (
    msg.includes('refresh token') ||
    msg.includes('invalid refresh token') ||
    msg.includes('refresh token not found') ||
    msg.includes('refresh_token') ||
    e?.status === 400
  );
};

const clearAuthStorage = async () => {
  try {
    await AsyncStorage.removeItem(SUPABASE_AUTH_STORAGE_KEY);
    const keys = await AsyncStorage.getAllKeys();
    const legacyKeys = keys.filter((k) => k.includes('-auth-token') && k.startsWith('sb-'));
    if (legacyKeys.length > 0) await AsyncStorage.multiRemove(legacyKeys);
  } catch {
    // ignore
  }
};

/** Create & link organization after first login (email confirmation safe). */
async function ensureOrgAfterLogin(u: SbUser) {
  const md = u.user_metadata ?? {};
  const isOrgUser = md.userType === 'organization';
  const hasOrgId = !!md.organizationId;

  if (!isOrgUser || hasOrgId) return;

  const orgName = md.pendingOrgName ?? 'Organization';
  const contactName = md.pendingContactName ?? md.full_name ?? 'Owner';

  // 1) Create organization
  const { data: orgRow, error: orgErr } = await supabase
    .from('organizations')
    .insert({
      name: orgName,
      contact_name: contactName,
      contact_email: u.email,
      //created_by: u.id,
      //business_type: 'valeting',
    })
    .select('id')
    .maybeSingle();

  if (orgErr || !orgRow?.id) {
    console.warn('[Auth DEBUG] ensureOrgAfterLogin: org insert failed:', orgErr?.message);
    return;
  }

  const orgId = orgRow.id as string;

  // 2) Link profile
  const { error: profErr } = await supabase
    .from('profiles')
    .update({ organization_id: orgId, user_type: 'organization' })
    .eq('id', u.id);

  if (profErr) {
    console.warn('[Auth DEBUG] ensureOrgAfterLogin: profile link failed:', profErr.message);
    return;
  }

  // 3) Update auth metadata
  await supabase.auth.updateUser({
    data: {
      organizationId: orgId,
      pendingOrgName: null,
      pendingContactName: null,
    },
  });
}

/* ---------------- Provider ---------------- */

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);

  // isLoading: true while bootstrapping + while any auth action runs.
  const [isLoading, setIsLoading] = useState(true);

  // authReady: true when we know userType reliably (metadata OR profile),
  // OR when there’s no logged-in user.
  const [authReady, setAuthReady] = useState(false);

  // prevent double-setting on boot
  const bootDoneRef = useRef(false);
  // Track if login is in progress to prevent race conditions with onAuthStateChange
  const loginInProgressRef = useRef(false);

  // initial session + listener
  useEffect(() => {
    let mounted = true;

    (async () => {
      setIsLoading(true);
      setAuthReady(false);

      try {
        const { data } = await withTimeout(
          supabase.auth.getSession(),
          3000,
          'getSession'
        );

        const s: Session | null = data?.session ?? null;

        if (s?.user) {
          const md = s.user.user_metadata ?? {};

          // If metadata has userType we can render minimal immediately.
          const mdHasRole = !!md.userType;

          if (mdHasRole) {
            const minimal = toAppUser(s.user, null);
            if (mounted) {
              setUser(minimal);
              await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(minimal));
              setAuthReady(true); // role is reliable from metadata
            }
          }

          // Regardless, try to enrich with profile (don't block > 3s total).
          try {
            const profile = await withTimeout(fetchProfile(s.user.id), 3000, 'fetchProfile(bootstrap)');
            const enriched = toAppUser(s.user, profile);
            
            // Automatic correction: if email-based override changed the role, update database
            const email = (s.user.email ?? '').toLowerCase();
            const shouldBeCustomer = KNOWN_CUSTOMER_EMAILS.includes(email);
            const shouldBeValeter = KNOWN_VALETER_EMAILS.includes(email);
            
            let finalUser = enriched;
            if (shouldBeCustomer && enriched.userType !== 'customer') {
              // Update profile table (fire and forget, don't block)
              supabase
                .from('profiles')
                .update({ user_type: 'customer' })
                .eq('id', s.user.id)
                .then(() => {
                  supabase.auth.updateUser({ data: { userType: 'customer' } });
                });
              // Use corrected role immediately
              finalUser = { ...enriched, userType: 'customer' };
            } else if (shouldBeValeter && enriched.userType !== 'valeter') {
              // Update profile table (fire and forget, don't block)
              supabase
                .from('profiles')
                .update({ user_type: 'valeter' })
                .eq('id', s.user.id)
                .then(() => {
                  supabase.auth.updateUser({ data: { userType: 'valeter' } });
                });
              // Use corrected role immediately
              finalUser = { ...enriched, userType: 'valeter' };
            }
            
            await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(finalUser));
            if (mounted) {
              setUser(finalUser);
              setAuthReady(true); // role now reliable from profile
            }
          } catch (e: any) {
            console.warn('[Auth DEBUG] bootstrap profile fetch failed:', e?.message || e);
            // If we didn't already mark authReady via metadata, try cache as fallback
            if (!mdHasRole) {
              const cached = await AsyncStorage.getItem(SESSION_KEY);
              if (cached && mounted) {
                const cachedUser = JSON.parse(cached) as User;
                setUser(cachedUser);
                setAuthReady(!!cachedUser?.userType);
              } else {
                // Still no reliable userType, keep user but mark ready to avoid permanent block
                setAuthReady(true);
              }
            }
          }
        } else {
          // No live session: try cache quickly.
          const cached = await AsyncStorage.getItem(SESSION_KEY);
          if (cached && mounted) {
            const cachedUser = JSON.parse(cached) as User;
            setUser(cachedUser);
            setAuthReady(true);
          } else {
            if (mounted) {
              setUser(null);
              setAuthReady(true);
            }
          }
        }
      } catch (e: any) {
        console.warn('[Auth WARN] getSession failed:', e?.message || e);
        // Invalid/expired refresh token: clear Supabase session so it stops retrying
        const isInvalidRefresh = isInvalidRefreshTokenError(e);
        if (isInvalidRefresh) {
          try {
            await supabase.auth.signOut({ scope: 'local' });
            await clearAuthStorage();
            await AsyncStorage.removeItem(SESSION_KEY);
          } catch (_) {
            /* ignore */
          }
        }
        const cached = await AsyncStorage.getItem(SESSION_KEY);
        if (cached && mounted && !isInvalidRefresh) {
          const cachedUser = JSON.parse(cached) as User;
          setUser(cachedUser);
          setAuthReady(true);
        } else if (mounted) {
          setUser(null);
          setAuthReady(true);
        }
      } finally {
        if (mounted) {
          setIsLoading(false);
          bootDoneRef.current = true;
        }
      }
    })();

    const { data: sub } = supabase.auth.onAuthStateChange((event, newSession) => {
      // Avoid race with bootstrap: we still handle but rely on mounted flags
      (async () => {
        try {
          if (!newSession?.user) {
            await AsyncStorage.removeItem(SESSION_KEY);
            setUser(null);
            setAuthReady(true);
            return;
          }

          // 🔹 Create+link org after first login if needed (email confirmation safe)
          if (event === 'SIGNED_IN') {
            await ensureOrgAfterLogin(newSession.user);
          }

          // Check if login is in progress - don't override if login() is handling it
          if (loginInProgressRef.current) {
            return;
          }

          const md = newSession.user.user_metadata ?? {};
          const mdHasRole = !!md.userType;

          // Minimal immediately if metadata role exists
          if (mdHasRole) {
            const minimal = toAppUser(newSession.user, null);
            await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(minimal));
            setUser(minimal);
            setAuthReady(true);
          } else {
            // hold authReady until profile fetch completes or times out
            setAuthReady(false);
          }

          // Enrich in background
          try {
            const profile = await withTimeout(fetchProfile(newSession.user.id), 3000, 'fetchProfile(onChange)');
            const enriched = toAppUser(newSession.user, profile);
            
            // Automatic correction: if email-based override changed the role, update database
            const email = (newSession.user.email ?? '').toLowerCase();
            const shouldBeCustomer = KNOWN_CUSTOMER_EMAILS.includes(email);
            const shouldBeValeter = KNOWN_VALETER_EMAILS.includes(email);
            
            if (shouldBeCustomer && enriched.userType !== 'customer') {
              // Update profile table
              await supabase
                .from('profiles')
                .update({ user_type: 'customer' })
                .eq('id', newSession.user.id);
              // Update auth metadata
              await supabase.auth.updateUser({
                data: { userType: 'customer' }
              });
              // Re-fetch and update user
              const correctedProfile = await fetchProfile(newSession.user.id);
              const corrected = toAppUser(newSession.user, correctedProfile);
              await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(corrected));
              setUser(corrected);
              setAuthReady(true);
            } else if (shouldBeValeter && enriched.userType !== 'valeter') {
              // Update profile table
              await supabase
                .from('profiles')
                .update({ user_type: 'valeter' })
                .eq('id', newSession.user.id);
              // Update auth metadata
              await supabase.auth.updateUser({
                data: { userType: 'valeter' }
              });
              // Re-fetch and update user
              const correctedProfile = await fetchProfile(newSession.user.id);
              const corrected = toAppUser(newSession.user, correctedProfile);
              await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(corrected));
              setUser(corrected);
              setAuthReady(true);
            } else {
            await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(enriched));
            setUser(enriched);
            setAuthReady(true);
            }
          } catch (e: any) {
            console.warn('[Auth DEBUG] onAuthStateChange enrich failed:', e?.message || e);
            if (!mdHasRole) {
              // Fall back to cached reliability
              const cached = await AsyncStorage.getItem(SESSION_KEY);
              if (cached) {
                const cachedUser = JSON.parse(cached) as User;
                setUser(cachedUser);
                setAuthReady(!!cachedUser?.userType);
              } else {
                setAuthReady(true);
              }
            }
          }
        } catch (e: any) {
          console.warn('[Auth DEBUG] onAuthStateChange handler error:', e?.message || e);
          setAuthReady(true);
        } finally {
          // We don't toggle isLoading here; it's for UI spinners during explicit actions
        }
      })();
    });

    return () => {
      sub.subscription.unsubscribe();
      // mounted=false to avoid setting state after unmount
    };
  }, []);

  /* -------- API -------- */

  const finalizeAuthUser = async (sbUser: SbUser, seed?: Partial<User>): Promise<boolean> => {
    try {
      await upsertProfile(sbUser, seed);
      let profile = await withTimeout(fetchProfile(sbUser.id), 3000, 'fetchProfile(finalizeAuthUser)');

      // Apple (and other IdPs) may only send name once — fill empty profiles when seed has it.
      const seedName = seed?.name?.trim();
      if (seedName && !(profile?.full_name || '').trim()) {
        await supabase.from('profiles').update({ full_name: seedName }).eq('id', sbUser.id);
        profile = { ...(profile || {}), full_name: seedName };
      }

      const appUser = toAppUser(sbUser, profile);
      await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(appUser));
      setUser(appUser);
      setAuthReady(true);
      return true;
    } catch (e: any) {
      console.warn('[Auth DEBUG] finalizeAuthUser error:', e?.message || e);
      return false;
    }
  };

  const waitForOAuthRedirect = (timeoutMs = 90000): Promise<string> => {
    return new Promise((resolve, reject) => {
      let done = false;
      const clean = () => {
        sub.remove();
        clearTimeout(t);
      };
      const finish = (url: string) => {
        if (done) return;
        done = true;
        clean();
        resolve(url);
      };
      const sub = Linking.addEventListener('url', ({ url }) => {
        if (url?.startsWith('waw://')) finish(url);
      });
      const t = setTimeout(() => {
        if (done) return;
        done = true;
        clean();
        reject(new Error('oauth_redirect_timeout'));
      }, timeoutMs);
      Linking.getInitialURL()
        .then((url) => {
          if (url?.startsWith('waw://')) finish(url);
        })
        .catch(() => {});
    });
  };

  const completeOAuthFromUrl = async (url: string): Promise<SbUser | null> => {
    const parsed = Linking.parse(url);
    const qp = (parsed.queryParams ?? {}) as Record<string, string | undefined>;
    const accessToken = qp.access_token;
    const refreshToken = qp.refresh_token;
    const code = qp.code;
    if (qp.error_description || qp.error) {
      throw new Error(qp.error_description || qp.error || 'OAuth failed');
    }
    if (accessToken && refreshToken) {
      const { data, error } = await supabase.auth.setSession({
        access_token: accessToken,
        refresh_token: refreshToken,
      });
      if (error) throw error;
      return data.user ?? null;
    }
    if (code) {
      const { data, error } = await supabase.auth.exchangeCodeForSession(code);
      if (error) throw error;
      return data.user ?? null;
    }
    return null;
  };

  const loginWithGoogle = async (): Promise<boolean> => {
    setIsLoading(true);
    setAuthReady(false);
    try {
      const redirectTo = Linking.createURL('auth/callback');
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo,
          skipBrowserRedirect: true,
          queryParams: {
            access_type: 'offline',
            prompt: 'consent',
          },
        },
      });
      if (error || !data?.url) {
        setAuthReady(true);
        return false;
      }
      await Linking.openURL(data.url);
      const callbackUrl = await waitForOAuthRedirect();
      const sbUser = await completeOAuthFromUrl(callbackUrl);
      if (!sbUser) {
        setAuthReady(true);
        return false;
      }
      return await finalizeAuthUser(sbUser);
    } catch (e: any) {
      console.warn('[Auth DEBUG] loginWithGoogle error:', e?.message || e);
      setAuthReady(true);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const registerWithGoogle = async (seed?: Partial<User> & { referralCode?: string }): Promise<boolean> => {
    const ok = await loginWithGoogle();
    if (!ok) return false;
    const current = await supabase.auth.getUser();
    const sbUser = current.data.user;
    if (sbUser) {
      const userType = seed?.userType ?? 'customer';
      await supabase.auth.updateUser({ data: { userType } });
      await finalizeAuthUser(sbUser, { ...seed, userType });
      if (seed?.referralCode) {
        await applyReferralCodeToUser(sbUser.id, seed.referralCode);
      }
    }
    return true;
  };

  const loginWithApple = async (
    credential: {
      identityToken?: string | null;
      nonce?: string | null;
      fullName?: { givenName?: string | null; familyName?: string | null; middleName?: string | null } | null;
    },
    seed?: Partial<User>
  ): Promise<boolean> => {
    const token = credential?.identityToken;
    if (!token) return false;
    setIsLoading(true);
    setAuthReady(false);
    try {
      const idTokenPayload = credential?.nonce
        ? { provider: 'apple' as const, token, nonce: credential.nonce }
        : { provider: 'apple' as const, token };
      const { data, error } = await supabase.auth.signInWithIdToken({
        ...idTokenPayload,
      });
      if (error || !data?.user) {
        setAuthReady(true);
        return false;
      }
      const appleName = nameFromAppleFullName(credential?.fullName);
      const mergedSeed: Partial<User> = { ...(seed || {}) };
      if (appleName && !mergedSeed.name) mergedSeed.name = appleName;
      return await finalizeAuthUser(data.user, Object.keys(mergedSeed).length ? mergedSeed : undefined);
    } catch (e: any) {
      console.warn('[Auth DEBUG] loginWithApple error:', e?.message || e);
      setAuthReady(true);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const registerWithApple = async (
    credential: {
      identityToken?: string | null;
      nonce?: string | null;
      fullName?: { givenName?: string | null; familyName?: string | null; middleName?: string | null } | null;
    },
    seed?: Partial<User> & { referralCode?: string }
  ): Promise<boolean> => {
    const appleName = nameFromAppleFullName(credential?.fullName);
    const mergedSeed: Partial<User> & { referralCode?: string } = { ...(seed || {}) };
    if (appleName && !mergedSeed.name) mergedSeed.name = appleName;

    const ok = await loginWithApple(credential, mergedSeed);
    if (!ok) return false;
    const current = await supabase.auth.getUser();
    const sbUser = current.data.user;
    if (sbUser) {
      const userType = mergedSeed.userType ?? 'customer';
      await supabase.auth.updateUser({ data: { userType } });
      await finalizeAuthUser(sbUser, { ...mergedSeed, userType });
      if (mergedSeed.referralCode) {
        await applyReferralCodeToUser(sbUser.id, mergedSeed.referralCode);
      }
    }
    return true;
  };

  const login = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true);
    setAuthReady(false);
    loginInProgressRef.current = true;
    try {
      const { data, error } = await withTimeout(
        supabase.auth.signInWithPassword({ email, password }),
        5000,
        'signInWithPassword'
      );
      if (error || !data.user) {
        setAuthReady(true);
        return false;
      }

      // Minimal now if metadata has role
      const md = data.user.user_metadata ?? {};
      const mdHasRole = !!md.userType;
      if (mdHasRole) {
        const minimal = toAppUser(data.user, null);
        await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(minimal));
        setUser(minimal);
        setAuthReady(true);
      }

      // Enrich in background
      (async () => {
        try {
          const profile = await withTimeout(fetchProfile(data.user.id), 3000, 'fetchProfile(login)');
          if(!profile){
            await upsertProfile(data.user);
              }
          const enriched = toAppUser(data.user, profile);
          
          // Automatic correction: if email-based override changed the role, update database
          const email = (data.user.email ?? '').toLowerCase();
          const shouldBeCustomer = KNOWN_CUSTOMER_EMAILS.includes(email);
          const shouldBeValeter = KNOWN_VALETER_EMAILS.includes(email);
          
          if (shouldBeCustomer && enriched.userType !== 'customer') {
            // Update profile table
            await supabase
              .from('profiles')
              .update({ user_type: 'customer' })
              .eq('id', data.user.id);
            // Update auth metadata
            await supabase.auth.updateUser({
              data: { userType: 'customer' }
            });
            // Re-fetch and update user
            const correctedProfile = await fetchProfile(data.user.id);
            const corrected = toAppUser(data.user, correctedProfile);
            await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(corrected));
            setUser(corrected);
            setAuthReady(true);
          } else if (shouldBeValeter && enriched.userType !== 'valeter') {
            // Update profile table
            await supabase
              .from('profiles')
              .update({ user_type: 'valeter' })
              .eq('id', data.user.id);
            // Update auth metadata
            await supabase.auth.updateUser({
              data: { userType: 'valeter' }
            });
            // Re-fetch and update user
            const correctedProfile = await fetchProfile(data.user.id);
            const corrected = toAppUser(data.user, correctedProfile);
            await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(corrected));
            setUser(corrected);
            setAuthReady(true);
          } else {
          await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(enriched));
          setUser(enriched);
          setAuthReady(true);
          }
        } catch (e: any) {
          console.warn('[Auth DEBUG] login enrichment failed:', e?.message || e);
          if (!mdHasRole) {
            setAuthReady(true);
          }
        }
      })();

      return true;
    } catch (e: any) {
      console.warn('[Auth DEBUG] login error:', e?.message || e);
      setAuthReady(true);
      loginInProgressRef.current = false;
      return false;
    } finally {
      setIsLoading(false);
      // Clear login flag after a short delay to allow state to settle
      setTimeout(() => {
        loginInProgressRef.current = false;
      }, 500);
    }
  };

  const logout = async (): Promise<void> => {
    setIsLoading(true);
    setAuthReady(false);
    try {
      await withTimeout(supabase.auth.signOut(), 3000, 'signOut');
      await AsyncStorage.removeItem(SESSION_KEY);
      setUser(null);
    } catch (e: any) {
      console.warn('[Auth DEBUG] logout error:', e?.message || e);
    } finally {
      setIsLoading(false);
      setAuthReady(true);
    }
  };

  const register: AuthContextType['register'] = async (userData) => {
    setIsLoading(true);
    setAuthReady(false);
    try {
      const {
        email, password, name, phone, userType,
        organizationId, organizationType, profilePicture,
        orgName, contactName,
        referralCode,
      } = userData;

      // With email confirmation ON, we only stash intent here.
      const { data, error } = await withTimeout(
        supabase.auth.signUp({
          email,
          password,
          options: {
            data: {
              full_name: contactName ?? name, // human's name
              name: contactName ?? name,
              phone,
              userType,
              organizationId,      // probably null for org sign-up
              organizationType,
              profilePicture,
              referralCode,
              // used post-login
              pendingOrgName: userType === 'organization' ? (orgName ?? name) : null,
              pendingContactName: userType === 'organization' ? (contactName ?? name) : null,
            },
          },
        }),
        5000,
        'signUp'
      );
      if (error) {
        setAuthReady(true);
        return false;
      }

      if (data.user) {
        // Minimal now if metadata has role
        const md = data.user.user_metadata ?? {};
        const mdHasRole = !!md.userType;
        if (mdHasRole) {
          const minimal = toAppUser(data.user, null);
          await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(minimal));
          setUser(minimal);
          setAuthReady(true);
        }

        // Enrich later (profile upsert with whatever we have)
        (async () => {
          try {
            await upsertProfile(data.user, {
              name: contactName ?? name,
              phone,
              userType,
              organizationId,
              organizationType,
              profilePicture,
              referralCode,
              verificationType: 'none',
              isVerified: false,
              totalWashes: 0,
              tier: 'bronze',
              tierPoints: 0,
            });
            if (referralCode) {
              await applyReferralCodeToUser(data.user.id, referralCode);
            }
            const profile = await withTimeout(fetchProfile(data.user.id), 3000, 'fetchProfile(register)');
            const enriched = toAppUser(data.user, profile);
            await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(enriched));
            setUser(enriched);
            setAuthReady(true);
          } catch (e: any) {
            console.warn('[Auth DEBUG] register enrichment failed:', e?.message || e);
            if (!mdHasRole) {
              setAuthReady(true);
            }
          }
        })();
      } else {
        setAuthReady(true);
      }

      return true;
    } catch (e: any) {
      console.warn('[Auth DEBUG] register error:', e?.message || e);
      setAuthReady(true);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const updateUser = async (updates: Partial<User>): Promise<void> => {
    if (!user) {
      return;
    }

    const md: Record<string, any> = {};
    if (updates.name) md.full_name = updates.name;
    if (updates.phone) md.phone = updates.phone;
    if (updates.userType) md.userType = updates.userType;
    if (updates.organizationId) md.organizationId = updates.organizationId;
    if (updates.organizationType) md.organizationType = updates.organizationType;
    if (updates.profilePicture) md.profilePicture = updates.profilePicture;

    try {
      setIsLoading(true);
      if (Object.keys(md).length) {
        await withTimeout(supabase.auth.updateUser({ data: md }), 3000, 'updateUser(auth)');
      }

      const patch: any = {};
      if (updates.name) patch.full_name = updates.name;
      if (updates.phone) patch.phone = updates.phone;
      if (updates.userType) patch.user_type = updates.userType;
      if (updates.organizationId) patch.organization_id = updates.organizationId;
      if (updates.organizationType) patch.organization_type = updates.organizationType;
      if (updates.profilePicture) patch.profile_picture = updates.profilePicture;
      if (typeof updates.isVerified === 'boolean') patch.is_verified = updates.isVerified;
      if (updates.verificationType) patch.verification_type = updates.verificationType;
      if (typeof updates.totalWashes === 'number') patch.total_washes = updates.totalWashes;
      if (updates.tier) patch.tier = updates.tier;
      if (typeof updates.tierPoints === 'number') patch.tier_points = updates.tierPoints;

      if (Object.keys(patch).length) {
        await withTimeout(supabase.from('profiles').update(patch).eq('id', user.id), 4000, 'updateProfile(row)');
      }

      const { data } = await withTimeout(supabase.auth.getUser(), 3000, 'getUser(refresh)');
      const profile = data.user ? await withTimeout(fetchProfile(data.user.id), 3000, 'fetchProfile(refresh)') : null;
      const appUser = data.user ? toAppUser(data.user, profile) : null;
      if (appUser) await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(appUser));
      setUser(appUser);
    } catch (e: any) {
      console.warn('[Auth DEBUG] updateUser error:', e?.message || e);
    } finally {
      setIsLoading(false);
    }
  };

  const updatePassword = async (_currentPassword: string, newPassword: string): Promise<void> => {
    const { error } = await withTimeout(supabase.auth.updateUser({ password: newPassword }), 3000, 'updatePassword');
    if (error) {
      console.warn('[Auth DEBUG] updatePassword error:', error.message);
      throw error;
    }
  };

  const updateProfile = async (updates: Partial<User>): Promise<void> => updateUser(updates);

  const resetPassword = async (email: string): Promise<void> => {
    const { error } = await withTimeout(
      supabase.auth.resetPasswordForEmail(email, { redirectTo: 'waw://reset-password' }),
      3000,
      'resetPassword'
    );
    if (error) {
      console.warn('[Auth DEBUG] resetPassword error:', error.message);
      throw error;
    }
  };

  const autoLoginCustomer = async () => {
    // Dev shortcut disabled. Keep the helper in place so it can be re-enabled deliberately if needed.
    // await login('customer@test.com', 'password123');
  };
  const autoLoginValeter = async () => {
    // Dev shortcut disabled. Keep the helper in place so it can be re-enabled deliberately if needed.
    // await login('valeter@test.com', 'password123');
  };

  const hasAdminAccess = (): boolean => (user?.email?.toLowerCase?.() ?? '') === 'admin@wishawash.com';
  const isBusinessOwner = (): boolean => user?.userType === 'organization';

  const markWelcomeSeen = async (userType: 'customer' | 'valeter') => {
    await AsyncStorage.setItem(`welcome_seen_${userType}`, 'true');
  };
  const hasSeenWelcome = async (userType: 'customer' | 'valeter') => {
    const seen = await AsyncStorage.getItem(`welcome_seen_${userType}`);
    return seen === 'true';
  };

  const isIndividualValeter = (): boolean =>
    user?.userType === 'valeter' && user?.organizationType !== 'registered';

  const isOrganizationValeter = (): boolean =>
    user?.userType === 'valeter' && user?.organizationType === 'registered';

  const requiresIndividualDocuments = (): boolean =>
    user?.userType === 'valeter' && !user?.isVerified && user?.organizationType !== 'registered';

  const requiresOrganizationDocuments = (): boolean =>
    user?.userType === 'valeter' && user?.organizationType === 'registered' && !user?.isVerified;

  const getOrganization = (): Organization | null => {
    if (!user?.organizationId) return null;
    return {
      id: user.organizationId,
      name: 'Organization',
      contactEmail: user.email,
      isVerified: false,
      insuranceVerified: false,
      licenseVerified: false,
      createdAt: new Date(),
      updatedAt: new Date(),
    } as Organization;
  };

  const value: AuthContextType = useMemo(() => ({
    user,
    isLoading,
    authReady,

    login,
    loginWithGoogle,
    loginWithApple,
    logout,
    register,
    registerWithGoogle,
    registerWithApple,
    updateUser,
    updatePassword,
    updateProfile,
    resetPassword,
    autoLoginCustomer,
    autoLoginValeter,
    hasAdminAccess,
    isBusinessOwner,
    markWelcomeSeen,
    hasSeenWelcome,
    isIndividualValeter,
    isOrganizationValeter,
    requiresIndividualDocuments,
    requiresOrganizationDocuments,
    getOrganization,
  }), [user, isLoading, authReady]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = (): AuthContextType => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
};

export default AuthProvider;
