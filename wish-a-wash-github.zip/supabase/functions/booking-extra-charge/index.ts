import { createClient } from 'npm:@supabase/supabase-js@2';
import Stripe from 'npm:stripe@14.25.0';

const SUPABASE_URL = Deno.env.get('SUPABASE_URL') ?? '';
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';
const STRIPE_SECRET_KEY = Deno.env.get('STRIPE_SECRET_KEY') ?? '';

const stripe = new Stripe(STRIPE_SECRET_KEY, {
  apiVersion: '2024-06-20',
});

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

function json(status: number, body: Record<string, unknown>) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

async function getAuthedUserId(req: Request): Promise<string | null> {
  const authHeader = req.headers.get('Authorization') ?? '';
  const token = authHeader.replace('Bearer ', '').trim();
  if (!token) return null;

  const admin = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
  const { data, error } = await admin.auth.getUser(token);
  if (error || !data?.user?.id) return null;
  return data.user.id;
}

function parseRequestPayload(content: string | null) {
  if (!content) return null;
  try {
    const parsed = JSON.parse(content) as Record<string, any>;
    if (parsed?.kind !== 'booking_payment_request') return null;
    return parsed;
  } catch {
    return null;
  }
}

async function loadBusinessStripeAccount(admin: ReturnType<typeof createClient>, organizationId: string) {
  if (!organizationId) return null;

  const { data, error } = await admin
    .from('profiles')
    .select('id,stripe_account_id,stripe_connect_status,user_type,organization_id')
    .eq('organization_id', organizationId)
    .eq('user_type', 'organization')
    .maybeSingle();

  if (error || !data) return null;

  const stripeAccountId = String((data as any).stripe_account_id || '');
  if (!stripeAccountId) return null;

  return {
    kind: 'business' as const,
    profileId: String((data as any).id || ''),
    organizationId,
    stripeAccountId,
  };
}

async function loadValeterStripeAccount(admin: ReturnType<typeof createClient>, valeterId: string) {
  if (!valeterId) return null;

  const { data, error } = await admin
    .from('valeter_profiles')
    .select('user_id,stripe_account_id,stripe_connect_status')
    .eq('user_id', valeterId)
    .maybeSingle();

  if (error || !data) return null;

  const stripeAccountId = String((data as any).stripe_account_id || '');
  if (!stripeAccountId) return null;

  return {
    kind: 'valeter' as const,
    profileId: String((data as any).user_id || valeterId),
    stripeAccountId,
  };
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY || !STRIPE_SECRET_KEY) {
    return json(500, { error: 'Missing function environment variables.' });
  }

  try {
    const userId = await getAuthedUserId(req);
    if (!userId) return json(401, { error: 'Unauthorized' });

    const body = await req.json().catch(() => ({}));
    const action = String(body?.action || '');
    if (action !== 'create_payment_intent') {
      return json(400, { error: 'Unsupported action.' });
    }

    const bookingId = String(body?.bookingId || '');
    const requestMessageId = String(body?.requestMessageId || '');
    if (!bookingId || !requestMessageId) {
      return json(400, { error: 'bookingId and requestMessageId are required.' });
    }

    const admin = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const { data: booking, error: bookingErr } = await admin
      .from('bookings')
      .select('id, user_id, valeter_id, organization_id, location_id, status')
      .eq('id', bookingId)
      .maybeSingle();

    if (bookingErr || !booking) {
      return json(404, { error: 'Booking not found.' });
    }

    if (String(booking.user_id || '') !== userId) {
      return json(403, { error: 'Only the booking customer can pay this request.' });
    }

    const { data: requestMessage, error: requestErr } = await admin
      .from('booking_messages')
      .select('id, booking_id, sender_id, sender_role, message_type, content')
      .eq('id', requestMessageId)
      .eq('booking_id', bookingId)
      .maybeSingle();

    if (requestErr || !requestMessage) {
      return json(404, { error: 'Payment request message not found.' });
    }

    if (String(requestMessage.message_type || '') !== 'payment_request') {
      return json(400, { error: 'Message is not a payment request.' });
    }

    const payload = parseRequestPayload(requestMessage.content);
    if (!payload) {
      return json(400, { error: 'Payment request payload is invalid.' });
    }

    const amount = Number(payload.amount || 0);
    const currency = String(payload.currency || 'gbp').toLowerCase();
    if (!Number.isFinite(amount) || amount <= 0) {
      return json(400, { error: 'Payment request amount is invalid.' });
    }

    const locationId = String(booking.location_id || '');
    const organizationId = String(booking.organization_id || '');
    const valeterId = String(booking.valeter_id || '');

    let recipient =
      locationId
        ? await (async () => {
            const { data: location, error: locationErr } = await admin
              .from('car_wash_locations')
              .select('id, organization_id')
              .eq('id', locationId)
              .maybeSingle();
            if (locationErr || !location) return null;
            const resolvedOrgId = String((location as any).organization_id || organizationId || '');
            return loadBusinessStripeAccount(admin, resolvedOrgId);
          })()
        : null;

    if (!recipient && organizationId) {
      recipient = await loadBusinessStripeAccount(admin, organizationId);
    }

    if (!recipient && valeterId) {
      recipient = await loadValeterStripeAccount(admin, valeterId);
    }

    if (!recipient) {
      return json(409, {
        error: 'No connected Stripe account found for this booking.',
      });
    }

    const connectedAccountId = recipient.stripeAccountId;

    const platformFee = Math.max(0, Math.round(Number(payload.platformFee || amount * 0.05) * 100));
    const amountCents = Math.round(amount * 100);

    const paymentIntent = await stripe.paymentIntents.create({
      amount: amountCents,
      currency,
      automatic_payment_methods: { enabled: true },
      application_fee_amount: platformFee,
      transfer_data: { destination: connectedAccountId },
      metadata: {
        booking_id: bookingId,
        request_message_id: requestMessageId,
        customer_id: userId,
        valeter_id: valeterId || undefined,
        recipient_kind: recipient.kind,
        recipient_profile_id: recipient.profileId,
        recipient_organization_id: recipient.kind === 'business' ? recipient.organizationId : undefined,
        request_kind: 'booking_extra_charge',
      },
    });

    const nextDetails = {
      ...(payload || {}),
      paymentIntentId: paymentIntent.id,
      paymentIntentClientSecret: paymentIntent.client_secret,
      payment_intent_created_at: new Date().toISOString(),
      status: 'pending',
      recipientKind: recipient.kind,
      recipientProfileId: recipient.profileId,
      recipientStripeAccountId: connectedAccountId,
    };

    await admin
      .from('booking_messages')
      .update({
        content: JSON.stringify(nextDetails),
      } as any)
      .eq('id', requestMessageId);

    return json(200, {
      paymentIntentId: paymentIntent.id,
      clientSecret: paymentIntent.client_secret,
      amount: amountCents,
      currency,
    });
  } catch (e: any) {
    return json(500, { error: e?.message || 'Unexpected server error.' });
  }
});
