import React, { useRef } from 'react';
import {
  TouchableOpacity,
  Text,
  StyleSheet,
  ActivityIndicator,
  View,
  ViewStyle,
  TextStyle,
  Animated,
  Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import { colors } from '../../constants/colors';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import {
  BOOKING_CONTINUE_RADIUS,
  CONTINUE_CTA_ICON_NAME,
  bookingContinueChromeBorder,
  bookingContinueGlassTop,
  BOOKING_CONTINUE_GLASS_FOOT,
  bookingContinueHeaderShadow,
  bookingContinueIconColor,
} from '../../utils/bookingContinueStyle';

const PRESS_SCALE = 0.98;

export interface ContinueCTAButtonProps {
  title: string;
  onPress: () => void;
  /** Brand / account accent (hex preferred) */
  accentColor: string;
  disabled?: boolean;
  loading?: boolean;
  style?: ViewStyle;
  textStyle?: TextStyle;
  variant?: 'primary' | 'secondary';
  /** Optional node before title (e.g. custom icon). Continue chevron still trails by default. */
  leading?: React.ReactNode;
  /** @default true — Archive 4 Continue convention */
  showTrailingChevron?: boolean;
}

/**
 * Single Continue-style CTA: glass + vertical tint + sheen + accent rim + trailing chevron-forward.
 * Matches Archive 4 `WWPrimaryButton` / booking flow.
 */
export default function ContinueCTAButton({
  title,
  onPress,
  accentColor,
  disabled = false,
  loading = false,
  style,
  textStyle,
  variant = 'primary',
  leading,
  showTrailingChevron = true,
}: Readonly<ContinueCTAButtonProps>) {
  const scaleAnim = useRef(new Animated.Value(1)).current;
  const borderCol = bookingContinueChromeBorder(accentColor);
  const iconTint = bookingContinueIconColor(accentColor);
  const androidBlurProps =
    Platform.OS === 'android' ? ({ experimentalBlurMethod: 'dimezisBlurView' as const }) : {};

  const handlePressIn = () => {
    if (disabled || loading) return;
    Animated.spring(scaleAnim, { toValue: PRESS_SCALE, useNativeDriver: true, speed: 50 }).start();
  };
  const handlePressOut = () => {
    Animated.spring(scaleAnim, { toValue: 1, useNativeDriver: true, speed: 50 }).start();
  };

  const handlePress = () => {
    if (!disabled && !loading) {
      hapticFeedback('medium');
      onPress();
    }
  };

  const chevronColor =
    variant === 'primary' ? colors.textOnDarkPrimary : iconTint;

  const inner = loading ? (
    <ActivityIndicator color={variant === 'primary' ? colors.textOnDarkPrimary : iconTint} size="small" />
  ) : (
    <>
      {leading ?? null}
      <Text
        style={[
          styles.text,
          variant === 'secondary' && { color: colors.textOnDarkPrimary },
          textStyle,
        ]}
        numberOfLines={1}
      >
        {title}
      </Text>
      {showTrailingChevron ? (
        <Ionicons
          name={CONTINUE_CTA_ICON_NAME}
          size={18}
          color={chevronColor}
          style={styles.trailingIcon}
        />
      ) : null}
    </>
  );

  if (variant === 'secondary') {
    return (
      <Animated.View style={[{ transform: [{ scale: scaleAnim }] }, style]}>
        <TouchableOpacity
          onPress={handlePress}
          onPressIn={handlePressIn}
          onPressOut={handlePressOut}
          disabled={disabled || loading}
          activeOpacity={0.88}
          style={[
            styles.containerSecondary,
            {
              borderColor: borderCol,
              opacity: disabled ? 0.55 : 1,
            },
            bookingContinueHeaderShadow(accentColor),
          ]}
        >
          <BlurView
            intensity={22}
            tint="dark"
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
            {...androidBlurProps}
          />
          <LinearGradient
            colors={[bookingContinueGlassTop(accentColor), BOOKING_CONTINUE_GLASS_FOOT]}
            start={{ x: 0, y: 0 }}
            end={{ x: 0, y: 1 }}
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
          />
          <LinearGradient
            colors={['rgba(255,255,255,0.1)', 'rgba(255,255,255,0.02)', 'transparent']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.sheen}
            pointerEvents="none"
          />
          <View style={styles.row}>{inner}</View>
        </TouchableOpacity>
      </Animated.View>
    );
  }

  return (
    <Animated.View style={[{ transform: [{ scale: scaleAnim }] }, style]}>
      <TouchableOpacity
        onPress={handlePress}
        onPressIn={handlePressIn}
        onPressOut={handlePressOut}
        disabled={disabled || loading}
        activeOpacity={1}
        style={[
          styles.container,
          {
            borderColor: disabled ? 'rgba(148,163,184,0.35)' : borderCol,
            opacity: disabled ? 0.55 : 1,
          },
          bookingContinueHeaderShadow(accentColor),
        ]}
      >
        <BlurView
          intensity={26}
          tint="dark"
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
          {...androidBlurProps}
        />
        <LinearGradient
          colors={
            disabled
              ? ['rgba(100,116,139,0.38)', 'rgba(71,85,105,0.42)']
              : [bookingContinueGlassTop(accentColor), BOOKING_CONTINUE_GLASS_FOOT]
          }
          start={{ x: 0, y: 0 }}
          end={{ x: 0, y: 1 }}
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
        />
        <LinearGradient
          colors={['rgba(255,255,255,0.16)', 'rgba(255,255,255,0.03)', 'transparent']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.sheen}
          pointerEvents="none"
        />
        <View style={styles.row}>{inner}</View>
      </TouchableOpacity>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    minHeight: 52,
    borderRadius: BOOKING_CONTINUE_RADIUS,
    overflow: 'hidden',
    borderWidth: 1,
  },
  containerSecondary: {
    width: '100%',
    minHeight: 52,
    borderRadius: BOOKING_CONTINUE_RADIUS,
    overflow: 'hidden',
    borderWidth: 1,
  },
  sheen: {
    ...StyleSheet.absoluteFillObject,
  },
  row: {
    minHeight: 52,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 11,
    paddingHorizontal: 16,
    gap: 8,
  },
  text: {
    color: colors.textOnDarkPrimary,
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.35,
    flexShrink: 1,
  },
  trailingIcon: {
    marginLeft: 0,
  },
});
