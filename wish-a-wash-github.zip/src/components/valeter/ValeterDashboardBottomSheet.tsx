import React, { useCallback, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  PanResponder,
  ScrollView,
  RefreshControl,
  Platform,
  Dimensions,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import GradientIconBox, { LocationStyleIconBox } from '../shared/GradientIconBox';
import { getServiceDisplayName } from '../../utils/serviceNameMapper';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { HEADER_STYLE_CARD_GRADIENT } from '../../constants/bookingCardTheme';

const { height: SCREEN_HEIGHT } = Dimensions.get('window');
const COLLAPSED_HEIGHT = 200;
const EXPANDED_RATIO = 0.52;

export type UpcomingJobRow = {
  id: string;
  service_type?: string;
  service_name?: string | null;
  scheduled_at?: string | null;
  price?: number;
  location_address?: string | null;
  status?: string;
};

type ValeterDashboardBottomSheetProps = Readonly<{
  earnings: number;
  jobsCompleted: number;
  jobRequestCount: number;
  upcomingJobs: UpcomingJobRow[];
  isOnline: boolean;
  nearbyCustomerCount: number;
  accent: string;
  headerGradient?: readonly [string, string];
  onRecenter: () => void;
  onUpcomingJobPress?: (job: UpcomingJobRow) => void;
  refreshing?: boolean;
  onRefresh?: () => void;
  children?: React.ReactNode;
}>;

function formatUpcomingWhen(iso?: string | null): string {
  if (!iso) return 'Scheduled';
  const d = new Date(iso);
  const now = new Date();
  const isToday =
    d.getDate() === now.getDate() &&
    d.getMonth() === now.getMonth() &&
    d.getFullYear() === now.getFullYear();
  const time = d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
  if (isToday) return `Today · ${time}`;
  const tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const isTomorrow =
    d.getDate() === tomorrow.getDate() &&
    d.getMonth() === tomorrow.getMonth() &&
    d.getFullYear() === tomorrow.getFullYear();
  if (isTomorrow) return `Tomorrow · ${time}`;
  return d.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
}

export default function ValeterDashboardBottomSheet({
  earnings,
  jobsCompleted,
  jobRequestCount,
  upcomingJobs,
  isOnline,
  nearbyCustomerCount,
  accent,
  headerGradient = HEADER_STYLE_CARD_GRADIENT,
  onRecenter,
  onUpcomingJobPress,
  refreshing = false,
  onRefresh,
  children,
}: ValeterDashboardBottomSheetProps) {
  const insets = useSafeAreaInsets();
  const expandedHeight = useMemo(
    () => Math.min(SCREEN_HEIGHT * EXPANDED_RATIO, SCREEN_HEIGHT - insets.top - 120),
    [insets.top]
  );
  const collapsedHeight = COLLAPSED_HEIGHT + insets.bottom;
  const expandedTotal = expandedHeight + insets.bottom;

  const [expanded, setExpanded] = useState(false);
  const sheetHeight = useRef(new Animated.Value(collapsedHeight)).current;
  const dragStartHeight = useRef(collapsedHeight);

  const snapTo = useCallback(
    (toExpanded: boolean) => {
      setExpanded(toExpanded);
      Animated.spring(sheetHeight, {
        toValue: toExpanded ? expandedTotal : collapsedHeight,
        useNativeDriver: false,
        tension: 68,
        friction: 12,
      }).start();
    },
    [collapsedHeight, expandedTotal, sheetHeight]
  );

  const panResponder = useMemo(
    () =>
      PanResponder.create({
        onMoveShouldSetPanResponder: (_, g) => Math.abs(g.dy) > 6,
        onPanResponderGrant: () => {
          sheetHeight.stopAnimation((v) => {
            dragStartHeight.current = typeof v === 'number' ? v : collapsedHeight;
          });
        },
        onPanResponderMove: (_, g) => {
          const next = Math.min(expandedTotal, Math.max(collapsedHeight, dragStartHeight.current - g.dy));
          sheetHeight.setValue(next);
        },
        onPanResponderRelease: (_, g) => {
          const mid = (collapsedHeight + expandedTotal) / 2;
          sheetHeight.stopAnimation((v) => {
            const current = typeof v === 'number' ? v : collapsedHeight;
            const shouldExpand = g.vy < -0.35 || (g.vy <= 0.35 && current > mid);
            snapTo(shouldExpand);
          });
        },
      }),
    [collapsedHeight, expandedTotal, sheetHeight, snapTo]
  );

  const toggleExpanded = async () => {
    await hapticFeedback('light');
    snapTo(!expanded);
  };

  const upcomingCount = upcomingJobs.length;

  return (
    <Animated.View
      style={[
        styles.sheet,
        {
          height: sheetHeight,
          paddingBottom: insets.bottom,
          borderColor: `${accent}35`,
        },
      ]}
    >
      <BlurView
        intensity={Platform.OS === 'ios' ? 72 : 88}
        tint="dark"
        style={StyleSheet.absoluteFill}
        {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
      />
      <LinearGradient
        colors={[`${headerGradient[0]}E8`, `${headerGradient[1] ?? headerGradient[0]}F0`, 'rgba(10,25,41,0.96)']}
        style={StyleSheet.absoluteFill}
      />
      <LinearGradient
        colors={[`${accent}18`, 'transparent']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0 }}
        style={styles.sheetAccentLine}
        pointerEvents="none"
      />

      <View {...panResponder.panHandlers}>
        <TouchableOpacity onPress={toggleExpanded} activeOpacity={0.9} style={styles.handleTouch}>
          <View style={[styles.handle, { backgroundColor: `${accent}55` }]} />
        </TouchableOpacity>

        <View style={styles.sheetTopRow}>
          <View style={styles.sheetTitleBlock}>
            <Text style={styles.sheetEyebrow}>Today</Text>
            <Text style={styles.sheetTitle}>Your shift</Text>
          </View>
          <TouchableOpacity onPress={onRecenter} style={[styles.recenterBtn, { borderColor: `${accent}40` }]} activeOpacity={0.85}>
            <Ionicons name="locate" size={18} color={accent} />
            <Text style={[styles.recenterLabel, { color: accent }]}>Recenter</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.statsRow}>
          <View style={[styles.statTile, { borderColor: `${accent}28` }]}>
            <LocationStyleIconBox icon="wallet-outline" preset="green" variant="nav" />
            <Text style={[styles.statValue, { color: accent }]}>£{Number(earnings || 0).toFixed(2)}</Text>
            <Text style={styles.statLabel}>Earnings</Text>
          </View>
          <View style={[styles.statTile, { borderColor: `${accent}28` }]}>
            <LocationStyleIconBox icon="checkmark-done-outline" preset="sky" variant="nav" />
            <Text style={styles.statValue}>{jobsCompleted}</Text>
            <Text style={styles.statLabel}>Completed</Text>
          </View>
          <View style={[styles.statTile, { borderColor: `${accent}28` }]}>
            <LocationStyleIconBox icon="car" preset="amber" variant="nav" />
            <Text style={[styles.statValue, jobRequestCount > 0 && { color: accent }]}>{jobRequestCount}</Text>
            <Text style={styles.statLabel}>Requests</Text>
          </View>
        </View>

        <View style={styles.statusRow}>
          <View
            style={[
              styles.statusPill,
              { borderColor: isOnline ? 'rgba(74,222,128,0.35)' : 'rgba(248,113,113,0.35)' },
            ]}
          >
            <View style={[styles.statusDot, { backgroundColor: isOnline ? '#4ADE80' : '#F87171' }]} />
            <Text style={styles.statusLabel}>{isOnline ? 'Online' : 'Offline'}</Text>
          </View>
          {isOnline ? (
            <Text style={styles.nearbyHint}>
              {nearbyCustomerCount === 1
                ? '1 customer nearby'
                : `${nearbyCustomerCount} customers nearby`}
            </Text>
          ) : (
            <Text style={styles.nearbyHintMuted}>Go online to see nearby customers</Text>
          )}
        </View>
      </View>

      <ScrollView
        style={styles.sheetScroll}
        contentContainerStyle={styles.sheetScrollContent}
        showsVerticalScrollIndicator={false}
        bounces={expanded}
        scrollEnabled={expanded}
        refreshControl={
          onRefresh ? <RefreshControl tintColor={accent} refreshing={refreshing} onRefresh={onRefresh} /> : undefined
        }
      >
        {upcomingCount > 0 ? (
          <View style={styles.upcomingSection}>
            <Text style={styles.sectionTitle}>Upcoming jobs</Text>
            {upcomingJobs.map((job) => (
              <TouchableOpacity
                key={job.id}
                style={[styles.upcomingRow, { borderColor: `${accent}22` }]}
                activeOpacity={0.88}
                onPress={() => onUpcomingJobPress?.(job)}
              >
                <GradientIconBox icon="time-outline" preset="cyan" boxSize={36} borderRadius={12} size={18} />
                <View style={styles.upcomingCopy}>
                  <Text style={styles.upcomingTitle} numberOfLines={1}>
                    {getServiceDisplayName(job.service_type, job.service_name)}
                  </Text>
                  <Text style={styles.upcomingMeta} numberOfLines={1}>
                    {formatUpcomingWhen(job.scheduled_at)}
                  </Text>
                </View>
                <Text style={[styles.upcomingPrice, { color: accent }]}>
                  £{Number(job.price || 0).toFixed(0)}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        ) : (
          <View style={styles.emptyUpcoming}>
            <Text style={styles.emptyUpcomingText}>No upcoming jobs scheduled</Text>
          </View>
        )}

        {children}
      </ScrollView>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  sheet: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    borderWidth: 1,
    overflow: 'hidden',
    zIndex: 40,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.28,
    shadowRadius: 16,
    elevation: 24,
  },
  sheetAccentLine: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 2,
  },
  handleTouch: {
    alignItems: 'center',
    paddingTop: 10,
    paddingBottom: 6,
  },
  handle: {
    width: 40,
    height: 4,
    borderRadius: 2,
  },
  sheetTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    marginBottom: 12,
  },
  sheetTitleBlock: {
    flex: 1,
    minWidth: 0,
  },
  sheetEyebrow: {
    color: 'rgba(249,250,251,0.5)',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  sheetTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    marginTop: 2,
  },
  recenterBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 12,
    backgroundColor: 'rgba(15,23,42,0.55)',
    borderWidth: 1,
  },
  recenterLabel: {
    fontSize: 13,
    fontWeight: '700',
  },
  statsRow: {
    flexDirection: 'row',
    gap: 8,
    paddingHorizontal: 16,
    marginBottom: 8,
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10,
    paddingHorizontal: 16,
    marginBottom: 4,
  },
  statusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 5,
    paddingHorizontal: 10,
    borderRadius: 20,
    borderWidth: 1,
    backgroundColor: 'rgba(15,23,42,0.45)',
  },
  statusDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
  },
  statusLabel: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '700',
  },
  nearbyHint: {
    flex: 1,
    textAlign: 'right',
    color: 'rgba(249,250,251,0.65)',
    fontSize: 12,
    fontWeight: '600',
  },
  nearbyHintMuted: {
    flex: 1,
    textAlign: 'right',
    color: 'rgba(249,250,251,0.4)',
    fontSize: 12,
    fontWeight: '600',
  },
  statTile: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 6,
    borderRadius: 14,
    borderWidth: 1,
    backgroundColor: 'rgba(15,23,42,0.45)',
    gap: 4,
  },
  statValue: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    marginTop: 2,
  },
  statLabel: {
    color: 'rgba(249,250,251,0.55)',
    fontSize: 10,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.3,
  },
  sheetScroll: {
    flex: 1,
  },
  sheetScrollContent: {
    paddingHorizontal: 16,
    paddingTop: 8,
    paddingBottom: 16,
    gap: 12,
  },
  sectionTitle: {
    color: 'rgba(249,250,251,0.55)',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  upcomingSection: {
    gap: 8,
  },
  upcomingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    padding: 12,
    borderRadius: 14,
    borderWidth: 1,
    backgroundColor: 'rgba(15,23,42,0.4)',
  },
  upcomingCopy: {
    flex: 1,
    minWidth: 0,
  },
  upcomingTitle: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '700',
  },
  upcomingMeta: {
    color: 'rgba(249,250,251,0.55)',
    fontSize: 12,
    fontWeight: '600',
    marginTop: 2,
  },
  upcomingPrice: {
    fontSize: 15,
    fontWeight: '800',
  },
  emptyUpcoming: {
    paddingVertical: 8,
    alignItems: 'center',
  },
  emptyUpcomingText: {
    color: 'rgba(249,250,251,0.45)',
    fontSize: 13,
    fontWeight: '600',
  },
});
