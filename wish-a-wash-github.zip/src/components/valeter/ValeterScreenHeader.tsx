import React from 'react';
import { usePathname } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import AppHeader, { HEADER_CONTENT_GAP, HEADER_HEIGHT } from '../shared/AppHeader';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import { ValeterMapHomeButton } from './ValeterNavSidebar';
import { hasValeterMapHomeNavigation } from '../../utils/valeterNavigation';

type ValeterScreenHeaderProps = Omit<
  React.ComponentProps<typeof AppHeader>,
  'accountType' | 'fullWidth' | 'flushTop'
> & {
  accountType?: 'valeter';
  /** Show map-home on the left (default: all non-immersive valeter sub-pages). */
  mapHome?: boolean;
};

/**
 * Standard flush-top, full-width frosted AppHeader for valeter pages.
 * Map-home icon is embedded on the left for sub-pages; immersive flows keep back navigation.
 */
export default function ValeterScreenHeader({
  accountType = 'valeter',
  leftAction,
  mapHome,
  ...rest
}: Readonly<ValeterScreenHeaderProps>) {
  const pathname = usePathname() ?? '';
  const { theme } = useAccountTheme();
  const accent = theme?.primary ?? '#38BDF8';
  const useMapHome = mapHome ?? hasValeterMapHomeNavigation(pathname);

  return (
    <AppHeader
      accountType={accountType}
      fullWidth
      flushTop
      leftAction={
        leftAction ?? (useMapHome ? <ValeterMapHomeButton color={accent} headerInline /> : undefined)
      }
      {...rest}
    />
  );
}

/** Scroll padding below a flush-top valeter header (includes safe area). */
export function useValeterHeaderContentOffset(extraGap = HEADER_CONTENT_GAP) {
  const insets = useSafeAreaInsets();
  return insets.top + HEADER_HEIGHT + extraGap;
}

export {
  HEADER_CONTENT_OFFSET,
  HEADER_CONTENT_GAP,
  HEADER_HEIGHT,
  DASHBOARD_HEADER_HEIGHT,
  DASHBOARD_HEADER_CONTENT_OFFSET,
  headerTotalHeight,
  dashboardHeaderTotalHeight,
} from '../shared/AppHeader';
