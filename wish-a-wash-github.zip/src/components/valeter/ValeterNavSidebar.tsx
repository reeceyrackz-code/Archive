import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Modal,
  Pressable,
  ScrollView,
  Platform,
  Dimensions,
  Image,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { usePathname, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import GradientIconBox, { LocationStyleIconBox } from '../shared/GradientIconBox';
import { accentToGradient } from '../../utils/accentGradient';
import { useAuth } from '../../providers/enhanced-auth-context';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import type { IconGlyphName } from '../shared/iconGlyphTypes';
import { DASHBOARD_HEADER_HEIGHT } from '../shared/AppHeader';
import { isValeterDashboardRoute } from '../../utils/valeterNavigation';

const SIDEBAR_WIDTH = Math.min(300, Dimensions.get('window').width * 0.84);

export const VALETER_MAP_ROUTE = '/valeter/valeter-dashboard';

/** Dashboard map has no bottom tab bar — use this for bottom inset. */
export const VALETER_CONTENT_BOTTOM_PAD = 20;

type NavItem = {
  id: string;
  label: string;
  subtitle?: string;
  icon: IconGlyphName;
  route: string;
  tone?: 'default' | 'money' | 'alert';
  badgeCount?: number;
};

const GO_TO_NAV: NavItem[] = [
  { id: 'messages', label: 'Messages', icon: 'chatbubbles', route: '/valeter/inbox' },
  { id: 'job-requests', label: 'Job requests', icon: 'car', route: '/valeter/jobs', tone: 'alert' },
];

const ACCOUNT_SETTINGS: NavItem[] = [
  { id: 'profile', label: 'Profile', icon: 'person', route: '/valeter/profile/valeter-profile' },
  { id: 'personal', label: 'Personal info', icon: 'person-circle', route: '/valeter/profile/valeter-personal-info' },
  { id: 'vehicle', label: 'Vehicle', icon: 'car-sport', route: '/valeter/profile/valeter-vehicle-info' },
  { id: 'services', label: 'Services & pricing', icon: 'wallet-outline', route: '/valeter/profile/valeter-services', tone: 'money' },
];

const WORK_SETTINGS: NavItem[] = [
  { id: 'hours', label: 'Working hours', icon: 'calendar', route: '/valeter/settings/working-hours' },
  { id: 'radius', label: 'Service radius', icon: 'navigate', route: '/valeter/settings/distance-covering' },
  { id: 'notifications-prefs', label: 'Notifications', icon: 'notifications', route: '/valeter/profile/valeter-notification-preferences' },
];

const FINANCE_SETTINGS: NavItem[] = [
  { id: 'history', label: 'Job history', icon: 'time', route: '/valeter/features/job-history' },
  { id: 'wash-history', label: 'Earnings', icon: 'wallet-outline', route: '/valeter/valeter-wash-history', tone: 'money' },
  { id: 'stripe', label: 'Stripe payouts', icon: 'wallet-outline', route: '/valeter/stripe-connect', tone: 'money' },
];

const SUPPORT_SETTINGS: NavItem[] = [
  { id: 'terms', label: 'Terms', icon: 'document-text', route: '/valeter/terms' },
  { id: 'support', label: 'Help & support', icon: 'help-circle', route: '/valeter/support/help-support' },
];

type ValeterNavContextValue = {
  open: () => void;
  close: () => void;
  toggle: () => void;
  visible: boolean;
  jobRequestCount: number;
  setJobRequestCount: (count: number) => void;
};

const ValeterNavContext = createContext<ValeterNavContextValue | null>(null);

export function useValeterNav() {
  const ctx = useContext(ValeterNavContext);
  if (!ctx) {
    return {
      open: () => {},
      close: () => {},
      toggle: () => {},
      visible: false,
      jobRequestCount: 0,
      setJobRequestCount: () => {},
    };
  }
  return ctx;
}

/** Sync live job-request count from the dashboard into the sidebar badges. */
export function useSyncValeterNavJobRequests(count: number) {
  const { setJobRequestCount } = useValeterNav();
  useEffect(() => {
    setJobRequestCount(count);
  }, [count, setJobRequestCount]);
}

export function ValeterMenuButton({ color, headerInline = false }: Readonly<{ color?: string; headerInline?: boolean }>) {
  const { toggle } = useValeterNav();
  const accent = color ?? '#F9FAFB';

  if (headerInline) {
    return (
      <TouchableOpacity
        onPress={async () => {
          await hapticFeedback('light');
          toggle();
        }}
        style={styles.headerInlineBtn}
        hitSlop={12}
        accessibilityRole="button"
        accessibilityLabel="Open menu"
      >
        <LocationStyleIconBox variant="inline" icon="menu" colors={accentToGradient(accent)} />
      </TouchableOpacity>
    );
  }

  return (
    <TouchableOpacity
      onPress={async () => {
        await hapticFeedback('light');
        toggle();
      }}
      style={styles.menuBtn}
      hitSlop={12}
      accessibilityRole="button"
      accessibilityLabel="Open menu"
    >
      <BlurView
        intensity={Platform.OS === 'ios' ? 48 : 64}
        tint="dark"
        style={StyleSheet.absoluteFill}
        {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
      />
      <LinearGradient
        colors={['rgba(255,255,255,0.14)', 'rgba(255,255,255,0.04)']}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <View style={[styles.menuBtnInner, { borderColor: `${accent}44` }]}>
        <Ionicons name="menu" size={22} color={accent} />
      </View>
    </TouchableOpacity>
  );
}

/** Return to map home — used in page headers on valeter sub-pages. */
export function ValeterMapHomeButton({ color, headerInline = false }: Readonly<{ color?: string; headerInline?: boolean }>) {
  const router = useRouter();
  const pathname = usePathname();
  const accent = color ?? '#F9FAFB';

  const goMap = async () => {
    await hapticFeedback('light');
    if (isValeterDashboardRoute(pathname || '')) return;
    router.replace(VALETER_MAP_ROUTE);
  };

  if (headerInline) {
    return (
      <TouchableOpacity
        onPress={goMap}
        style={styles.headerInlineBtn}
        hitSlop={12}
        accessibilityRole="button"
        accessibilityLabel="Back to map"
      >
        <LocationStyleIconBox variant="inline" icon="map" colors={accentToGradient(accent)} />
      </TouchableOpacity>
    );
  }

  return (
    <TouchableOpacity
      onPress={goMap}
      style={styles.menuBtn}
      hitSlop={12}
      accessibilityRole="button"
      accessibilityLabel="Back to map"
    >
      <BlurView
        intensity={Platform.OS === 'ios' ? 48 : 64}
        tint="dark"
        style={StyleSheet.absoluteFill}
        {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
      />
      <LinearGradient
        colors={['rgba(255,255,255,0.14)', 'rgba(255,255,255,0.04)']}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <View style={[styles.menuBtnInner, { borderColor: `${accent}44` }]}>
        <Ionicons name="map" size={22} color={accent} />
      </View>
    </TouchableOpacity>
  );
}

/** Jobs + messages shortcuts on the map — right edge, outside the sidebar. */
export function ValeterMapQuickActions({
  accent,
  jobRequestCount = 0,
  messageCount = 0,
}: Readonly<{ accent: string; jobRequestCount?: number; messageCount?: number }>) {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const go = async (route: string) => {
    await hapticFeedback('light');
    router.push(route);
  };

  const items = [
    { id: 'jobs', icon: 'car' as IconGlyphName, route: '/valeter/jobs', count: jobRequestCount, label: 'Job requests' },
    { id: 'messages', icon: 'chatbubbles' as IconGlyphName, route: '/valeter/inbox', count: messageCount, label: 'Messages' },
  ];

  return (
    <View style={[styles.mapQuickActions, { top: insets.top + DASHBOARD_HEADER_HEIGHT + 12 }]} pointerEvents="box-none">
      {items.map((item) => (
        <TouchableOpacity
          key={item.id}
          onPress={() => go(item.route)}
          style={[styles.mapQuickActionBtn, { borderColor: `${accent}40` }]}
          activeOpacity={0.88}
          accessibilityRole="button"
          accessibilityLabel={item.label}
        >
          <BlurView
            intensity={Platform.OS === 'ios' ? 52 : 68}
            tint="dark"
            style={StyleSheet.absoluteFill}
            {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
          />
          <LinearGradient
            colors={['rgba(255,255,255,0.14)', 'rgba(255,255,255,0.04)']}
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
          />
          <Ionicons name={item.icon} size={22} color={accent} />
          {item.count > 0 ? (
            <View style={[styles.mapQuickBadge, { backgroundColor: accent }]}>
              <Text style={styles.mapQuickBadgeText}>{item.count > 9 ? '9+' : item.count}</Text>
            </View>
          ) : null}
        </TouchableOpacity>
      ))}
    </View>
  );
}

/** Top-left map home on valeter sub-pages. */
export function ValeterFloatingMapHomeButton() {
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const accent = theme?.primary ?? '#38BDF8';
  return (
    <View style={[styles.floatingMenuWrap, { top: insets.top + 8 }]} pointerEvents="box-none">
      <ValeterMapHomeButton color={accent} />
    </View>
  );
}

function settingsRowPreset(tone?: NavItem['tone']): 'green' | 'amber' | 'sky' {
  if (tone === 'money') return 'green';
  if (tone === 'alert') return 'amber';
  return 'sky';
}

function SettingsRow({
  item,
  accent,
  onPress,
}: Readonly<{ item: NavItem; accent: string; onPress: () => void }>) {
  const preset = settingsRowPreset(item.tone);
  const badge = item.badgeCount && item.badgeCount > 0 ? item.badgeCount : 0;
  return (
    <TouchableOpacity onPress={onPress} style={styles.settingsRow} activeOpacity={0.85}>
      <LocationStyleIconBox icon={item.icon} preset={preset} variant="nav" />
      <Text style={styles.settingsRowLabel}>{item.label}</Text>
      {badge > 0 ? (
        <View style={[styles.navBadge, { backgroundColor: accent }]}>
          <Text style={styles.navBadgeText}>{badge > 9 ? '9+' : badge}</Text>
        </View>
      ) : null}
      <Ionicons name="chevron-forward" size={16} color="rgba(249,250,251,0.35)" />
    </TouchableOpacity>
  );
}

function SettingsGroup({
  title,
  items,
  accent,
  onNavigate,
}: Readonly<{
  title: string;
  items: NavItem[];
  accent: string;
  onNavigate: (route: string) => void;
}>) {
  return (
    <View style={styles.settingsGroup}>
      <Text style={styles.groupTitle}>{title}</Text>
      <View style={styles.groupCard}>
        {items.map((item, index) => (
          <View key={item.id}>
            {index > 0 ? <View style={styles.groupDivider} /> : null}
            <SettingsRow item={item} accent={accent} onPress={() => onNavigate(item.route)} />
          </View>
        ))}
      </View>
    </View>
  );
}

export function ValeterNavProvider({ children }: Readonly<{ children: React.ReactNode }>) {
  const [visible, setVisible] = useState(false);
  const [jobRequestCount, setJobRequestCount] = useState(0);
  const pathname = usePathname();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const { logout, user } = useAuth();
  const accent = theme?.primary ?? '#38BDF8';
  const headerBg = theme?.headerBackground ?? theme?.background ?? ['#0A1929', '#1E3A8A'];

  const open = useCallback(() => setVisible(true), []);
  const close = useCallback(() => setVisible(false), []);
  const toggle = useCallback(() => setVisible((v) => !v), []);

  const ctx = useMemo(
    () => ({ open, close, toggle, visible, jobRequestCount, setJobRequestCount }),
    [open, close, toggle, visible, jobRequestCount]
  );

  const goToNav = useMemo(
    () =>
      GO_TO_NAV.map((item) =>
        item.id === 'job-requests' && jobRequestCount > 0
          ? { ...item, badgeCount: jobRequestCount }
          : item
      ),
    [jobRequestCount]
  );

  const navigate = useCallback(
    async (route: string) => {
      await hapticFeedback('light');
      close();
      if (pathname === route) return;
      router.push(route);
    },
    [close, pathname, router]
  );

  const displayName = user?.name || 'Car Care Pro';
  const avatarUri = user?.profilePicture;

  return (
    <ValeterNavContext.Provider value={ctx}>
      {children}
      <Modal visible={visible} transparent animationType="slide" onRequestClose={close}>
        <View style={styles.modalRoot}>
          <View style={[styles.panel, { width: SIDEBAR_WIDTH }]}>
            <BlurView
              intensity={Platform.OS === 'ios' ? 80 : 92}
              tint="dark"
              style={StyleSheet.absoluteFill}
              {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
            />
            <LinearGradient
              colors={[`${headerBg[0]}F2`, `${headerBg[1] ?? headerBg[0]}FA`, '#0A1929F5']}
              style={StyleSheet.absoluteFill}
            />
            <LinearGradient
              colors={[`${accent}22`, 'transparent']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.panelAccentGlow}
              pointerEvents="none"
            />

            <View style={[styles.panelInner, { paddingTop: insets.top + 14, paddingBottom: insets.bottom + 16 }]}>
              <View style={styles.panelHeader}>
                <Text style={styles.panelEyebrow}>Command</Text>
                <TouchableOpacity onPress={close} style={styles.closeBtn} hitSlop={12}>
                  <Ionicons name="close" size={22} color="#F9FAFB" />
                </TouchableOpacity>
              </View>

              <View style={[styles.userCard, { borderColor: `${accent}35` }]}>
                <View style={styles.userAvatarWrap}>
                  {avatarUri ? (
                    <Image source={{ uri: avatarUri }} style={styles.userAvatar} />
                  ) : (
                    <GradientIconBox icon="person" preset="sky" boxSize={52} borderRadius={16} elevated size={26} />
                  )}
                </View>
                <View style={styles.userCopy}>
                  <Text style={styles.userName} numberOfLines={1}>{displayName}</Text>
                  <Text style={[styles.userRole, { color: accent }]}>Valeter · Wish-a-Wash</Text>
                </View>
              </View>

              <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>
                <SettingsGroup title="Go to" items={goToNav} accent={accent} onNavigate={navigate} />
                <SettingsGroup title="Account" items={ACCOUNT_SETTINGS} accent={accent} onNavigate={navigate} />
                <SettingsGroup title="Work setup" items={WORK_SETTINGS} accent={accent} onNavigate={navigate} />
                <SettingsGroup title="Earnings" items={FINANCE_SETTINGS} accent={accent} onNavigate={navigate} />
                <SettingsGroup title="Support" items={SUPPORT_SETTINGS} accent={accent} onNavigate={navigate} />

                <TouchableOpacity
                  style={styles.logoutBtn}
                  onPress={async () => {
                    close();
                    await hapticFeedback('medium');
                    await logout();
                  }}
                  activeOpacity={0.85}
                >
                  <Ionicons name="log-out-outline" size={20} color="#FCA5A5" />
                  <Text style={styles.logoutText}>Log out</Text>
                </TouchableOpacity>
              </ScrollView>
            </View>
          </View>
          <Pressable style={styles.backdrop} onPress={close} />
        </View>
      </Modal>
    </ValeterNavContext.Provider>
  );
}

const styles = StyleSheet.create({
  menuBtn: {
    width: 44,
    height: 44,
    borderRadius: 14,
    overflow: 'hidden',
  },
  menuBtnInner: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderRadius: 14,
  },
  headerInlineBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
    flexShrink: 0,
  },
  floatingMenuWrap: {
    position: 'absolute',
    left: 16,
    zIndex: 100,
  },
  mapQuickActions: {
    position: 'absolute',
    right: 16,
    zIndex: 30,
    gap: 10,
    alignItems: 'center',
  },
  mapQuickActionBtn: {
    width: 48,
    height: 48,
    borderRadius: 14,
    borderWidth: 1,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
  },
  mapQuickBadge: {
    position: 'absolute',
    top: -4,
    right: -4,
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    paddingHorizontal: 4,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#0A1929',
  },
  mapQuickBadgeText: {
    color: '#0A1929',
    fontSize: 10,
    fontWeight: '900',
  },
  modalRoot: {
    flex: 1,
    flexDirection: 'row',
  },
  backdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  panel: {
    height: '100%',
    borderRightWidth: 1,
    borderRightColor: 'rgba(255,255,255,0.1)',
    overflow: 'hidden',
  },
  panelAccentGlow: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 180,
  },
  panelInner: {
    flex: 1,
    paddingHorizontal: 16,
  },
  panelHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 14,
  },
  panelEyebrow: {
    color: 'rgba(249,250,251,0.55)',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.4,
    textTransform: 'uppercase',
  },
  closeBtn: {
    width: 36,
    height: 36,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  userCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 14,
    borderRadius: 18,
    borderWidth: 1,
    backgroundColor: 'rgba(15,23,42,0.55)',
    marginBottom: 18,
  },
  userAvatarWrap: {
    width: 52,
    height: 52,
    borderRadius: 16,
    overflow: 'hidden',
  },
  userAvatar: {
    width: 52,
    height: 52,
    borderRadius: 16,
  },
  userCopy: {
    flex: 1,
    minWidth: 0,
  },
  userName: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
    letterSpacing: -0.2,
  },
  userRole: {
    fontSize: 12,
    fontWeight: '600',
    marginTop: 3,
  },
  scroll: {
    flex: 1,
  },
  groupTitle: {
    color: 'rgba(249,250,251,0.45)',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1,
    textTransform: 'uppercase',
    marginBottom: 8,
    marginTop: 4,
  },
  settingsGroup: {
    marginBottom: 16,
  },
  groupCard: {
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
    backgroundColor: 'rgba(15,23,42,0.45)',
    overflow: 'hidden',
  },
  groupDivider: {
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.06)',
    marginLeft: 56,
  },
  settingsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 13,
    paddingHorizontal: 14,
  },
  settingsRowLabel: {
    flex: 1,
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '600',
  },
  navBadge: {
    minWidth: 20,
    height: 20,
    borderRadius: 10,
    paddingHorizontal: 5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  navBadgeText: {
    color: '#0A1929',
    fontSize: 11,
    fontWeight: '900',
  },
  logoutBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 8,
    marginBottom: 12,
    paddingVertical: 14,
    borderRadius: 14,
    backgroundColor: 'rgba(239,68,68,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(248,113,113,0.28)',
  },
  logoutText: {
    color: '#FCA5A5',
    fontSize: 15,
    fontWeight: '700',
  },
});
