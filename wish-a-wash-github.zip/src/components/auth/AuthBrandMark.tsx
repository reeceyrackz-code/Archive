import React from 'react';
import { View, StyleSheet, Platform, Image } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { colors } from '../../constants/colors';
import { ICON_AUTH } from '../../../assets/authExports';
import { BOOKING_CONTINUE_RADIUS, bookingContinueChromeBorder } from '../../utils/bookingContinueStyle';

type AuthBrandMarkSize = 'sm' | 'md' | 'lg';

type AuthBrandMarkProps = {
  size?: AuthBrandMarkSize;
};

const BRAND_SIZES = {
  sm: { frame: 96, logo: 82, wrapMarginBottom: 2 },
  md: { frame: 112, logo: 96, wrapMarginBottom: 4 },
  lg: { frame: 136, logo: 118, wrapMarginBottom: 8 },
} as const;

export default function AuthBrandMark({ size = 'md' }: AuthBrandMarkProps) {
  const rim = bookingContinueChromeBorder(colors.SKY);
  const brandSize = BRAND_SIZES[size];
  return (
    <View
      style={[styles.wrap, { marginBottom: brandSize.wrapMarginBottom }]}
      accessibilityRole="image"
      accessibilityLabel="Wish a Washer logo"
    >
      <View
        style={[
          styles.frame,
          {
            width: brandSize.frame,
            height: brandSize.frame,
            borderColor: rim,
          },
        ]}
      >
        <BlurView
          intensity={Platform.OS === 'ios' ? 26 : 20}
          tint="dark"
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
          {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
        />
        <LinearGradient
          colors={['rgba(135,206,235,0.42)', 'rgba(15,40,71,0.72)']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
        />
        <LinearGradient
          colors={['rgba(255,255,255,0.2)', 'transparent']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.sheen}
          pointerEvents="none"
        />
        <View style={styles.inner}>
          <Image
            source={ICON_AUTH}
            style={{ width: brandSize.logo, height: brandSize.logo }}
            resizeMode="contain"
          />
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { alignItems: 'center' },
  sheen: { ...StyleSheet.absoluteFillObject },
  frame: {
    borderRadius: BOOKING_CONTINUE_RADIUS,
    overflow: 'hidden',
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  inner: { alignItems: 'center', justifyContent: 'center', padding: 8 },
});
