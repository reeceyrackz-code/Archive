// app/valeter/PowerfulDriverDashboard.tsx
import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Dimensions,
  ScrollView,
  Modal,
  Alert,
  ActivityIndicator,
  Platform,
  Image,
  Pressable,
  TextInput,
  Easing,
  StatusBar,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { router } from 'expo-router';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import MapView, { Marker, Region } from 'react-native-maps';
import { useAuth } from '../../providers/enhanced-auth-context';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import AppHeader, { DASHBOARD_HEADER_HEIGHT } from '../shared/AppHeader';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { SCREEN_PADDING_H, SECTION_GAP, CARD_GAP } from '../../constants/premiumTokens';
import * as Location from 'expo-location';
import { supabase } from '../../lib/supabase';
import GradientNotificationBell from '../shared/GradientNotificationBell';
import GradientIconBox, { LocationStyleIconBox } from '../shared/GradientIconBox';
import { accentToGradient } from '../../utils/accentGradient';
import { CONTINUE_CTA_ICON_NAME } from '../../utils/bookingContinueStyle';
import DefaultLoadingSkeleton from '../shared/DefaultLoadingSkeleton';
import useLiveLocation from '../../hooks/useLiveLocation';
import { ValeterMenuButton, useSyncValeterNavJobRequests } from '../valeter/ValeterNavSidebar';
import ValeterDashboardBottomSheet from '../valeter/ValeterDashboardBottomSheet';
import { registerPushToken } from '../../services/registerPushToken';
import {
  notifyValeterJobRequest,
  preparePhoneNotifications,
} from '../../services/valeterJobPhoneNotifications';
import { getServiceDisplayName } from '../../utils/serviceNameMapper';
import { fetchRadiusPreference } from '../../utils/radiusPreference';
import {
  fetchProfileById,
  fetchProfilesByIds,
  resolveCustomerAvatarsForUserIds,
} from '../../utils/customerProfiles';
import { valeterStripeConnectService } from '../../services/valeterStripeConnectService';
import AnimatedProgress from '../booking/AnimatedProgress';
import { getStatusProgress } from '../../utils/trackingStatusHelpers';
import {
  assertNoScheduleConflictForOffer,
  loadValeterScheduleBlocks,
  offerOverlapsSchedule,
  valeterScheduleAllowsJobOffer,
} from '../../services/valeterScheduleConflict';
import { colors } from '../../constants/colors';
import { DARK_MAP_STYLE } from '../../constants/mapStyles';
import { HEADER_STYLE_CARD_GRADIENT } from '../../constants/bookingCardTheme';
import { syncValeterExternalCalendarBusyToSupabase } from '../../services/valeterExternalCalendarBusy';
import { themeBackgroundGradient } from '../../utils/themeGradient';

const ICON_AUTH_IMAGE = require('../../../assets/icon-auth.png');

const { width } = Dimensions.get('window');
const SKY = colors.SKY ?? '#38BDF8';
const isSmallScreen = width < 375;
const ANDROID_BLUR_METHOD =
  Platform.OS === 'android' ? ({ experimentalBlurMethod: 'dimezisBlurView' as const } as const) : {};
const STATUS_HERO_BUTTON_SIZE = 214;
const STATUS_SPARKLE_ORBITS = [
  { dx: 44, dy: -44, delay: 0, size: 12 },
  { dx: -46, dy: -30, delay: 40, size: 10 },
  { dx: 52, dy: 26, delay: 80, size: 11 },
  { dx: -34, dy: 48, delay: 120, size: 9 },
  { dx: 0, dy: -56, delay: 160, size: 13 },
  { dx: 0, dy: 58, delay: 200, size: 9 },
] as const;

function getStatusRingColor(status: string): string {
  switch (status) {
    case 'pending_payment':
      return '#F59E0B';
    case 'confirmed':
      return '#8B5CF6';
    case 'en_route':
    case 'arrived':
      return '#10B981';
    case 'in_progress':
      return SKY;
    default:
      return SKY;
  }
}

// All statuses that count as "active" — card disappears only when completed or cancelled
const ACTIVE_JOB_STATUSES = ['pending_payment', 'scheduled', 'confirmed', 'en_route', 'arrived', 'in_progress'] as const;
type ActiveJob = {
  id: string;
  status: string;
  service_type: string;
  service_name: string | null;
  location_address: string | null;
  location_lat: number | null;
  location_lng: number | null;
  price: number;
  user_id: string | null;
};

function haversineMi(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 3959;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function isUpcomingBookingRow(b: Record<string, unknown>, now: number): boolean {
  const scheduledAt = typeof b.scheduled_at === 'string' ? b.scheduled_at : null;
  if (!scheduledAt) return false;
  if (new Date(scheduledAt).getTime() <= now) return false;
  const s = typeof b.status === 'string' ? b.status : '';
  return !['completed', 'cancelled', 'valeter_timeout'].includes(s);
}

function bookingSortTimestamp(row: Record<string, unknown>): number {
  if (typeof row.scheduled_at === 'string') return new Date(row.scheduled_at).getTime();
  if (typeof row.created_at === 'string') return new Date(row.created_at).getTime();
  return 0;
}

function compareEnrichedBookings(a: Record<string, unknown>, b: Record<string, unknown>, now: number): number {
  const aUp = isUpcomingBookingRow(a, now);
  const bUp = isUpcomingBookingRow(b, now);
  if (aUp && !bUp) return -1;
  if (!aUp && bUp) return 1;
  if (aUp && bUp) {
    return new Date(String(a.scheduled_at)).getTime() - new Date(String(b.scheduled_at)).getTime();
  }
  return bookingSortTimestamp(b) - bookingSortTimestamp(a);
}

function optionalNumberCoord(value: unknown): number | null {
  return value == null ? null : Number(value);
}

type YourJobSheetItem = {
  id: string;
  service_type?: string | null;
  service_name?: string | null;
  customer_photo?: string | null;
  customer_name?: string | null;
  scheduled_at?: string | null;
  location_address?: string | null;
  price?: number | string | null;
  _type?: string;
  status?: string;
};

function yourJobStatusSubtitle(job: YourJobSheetItem): string {
  if (job._type === 'upcoming') return 'Upcoming';
  if (job.status === 'completed') return 'Completed';
  if (job.status === 'in_progress') return 'Active';
  return 'Confirmed';
}

function formatRequestDistanceLine(distance: number, driveTimeMinutes?: number): string {
  if (distance <= 0) return '';
  if (driveTimeMinutes != null) return `${distance} mi · ~${driveTimeMinutes} min`;
  return `${distance} mi`;
}

function recentBookingStillVisible(b: Record<string, unknown>, thirtyMs: number): boolean {
  const st = typeof b.status === 'string' ? b.status.toLowerCase() : '';
  if (st !== 'completed' && st !== 'valeter_timeout') return true;
  const ref =
    (typeof b.completed_at === 'string' ? b.completed_at : null) ||
    (typeof b.updated_at === 'string' ? b.updated_at : null) ||
    (typeof b.created_at === 'string' ? b.created_at : null);
  if (!ref) return true;
  const t = new Date(ref).getTime();
  if (!Number.isFinite(t)) return true;
  return Date.now() - t <= thirtyMs;
}

async function notifyJobRequestIfAllowed(
  userId: string,
  booking: { id: string; service_name?: string | null; price?: number | null; location_address?: string | null }
): Promise<void> {
  const ok = await valeterScheduleAllowsJobOffer(userId, booking);
  if (!ok) return;
  await notifyValeterJobRequest({
    bookingId: booking.id,
    serviceName: booking.service_name,
    price: booking.price,
    locationAddress: booking.location_address,
  });
}

interface JobRequest {
  id: string;
  serviceName: string;
  distance: number;
  driveTimeMinutes?: number;
  price: number;
  customerName: string;
  address: string;
  timeRemaining: number;
  location_lat: number | null;
  location_lng: number | null;
  scheduledAt?: string | null;
  requestSentAt?: string | null;
  serviceType?: string;
  serviceNameRaw?: string | null;
}

interface TodayStats {
  hoursOnline: string;
  jobsCompleted: number;
  earnings: number;
}

function useDashboardFadeIn(fadeAnim: Animated.Value) {
  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 800,
      useNativeDriver: true,
    }).start();
  }, [fadeAnim]);
}

function useStatusRingAnimations(
  isOnline: boolean,
  statusRingPulse: Animated.Value,
  statusSheenAnim: Animated.Value,
  statusRingLoopRef: React.RefObject<Animated.CompositeAnimation | null>,
  statusSheenLoopRef: React.RefObject<Animated.CompositeAnimation | null>
) {
  useEffect(() => {
    statusRingLoopRef.current?.stop?.();
    statusSheenLoopRef.current?.stop?.();
    statusRingPulse.setValue(0);
    statusRingLoopRef.current = Animated.loop(
      Animated.sequence([
        Animated.timing(statusRingPulse, {
          toValue: 1,
          duration: isOnline ? 1800 : 2200,
          easing: Easing.out(Easing.cubic),
          useNativeDriver: true,
        }),
        Animated.timing(statusRingPulse, {
          toValue: 0,
          duration: 0,
          useNativeDriver: true,
        }),
      ])
    );
    statusRingLoopRef.current.start();

    if (isOnline) {
      statusSheenAnim.setValue(0);
      statusSheenLoopRef.current = Animated.loop(
        Animated.timing(statusSheenAnim, {
          toValue: 1,
          duration: 5400,
          easing: Easing.linear,
          useNativeDriver: true,
        })
      );
      statusSheenLoopRef.current.start();
    } else {
      statusSheenAnim.setValue(0);
    }

    return () => {
      statusRingLoopRef.current?.stop?.();
      statusSheenLoopRef.current?.stop?.();
    };
  }, [isOnline, statusRingPulse, statusSheenAnim, statusRingLoopRef, statusSheenLoopRef]);
}

function useStatusMorphAnimation(
  isOnline: boolean,
  loadingPresence: boolean,
  statusMorphAnim: Animated.Value
) {
  useEffect(() => {
    if (loadingPresence) return;
    Animated.timing(statusMorphAnim, {
      toValue: isOnline ? 1 : 0,
      duration: isOnline ? 420 : 520,
      easing: Easing.inOut(Easing.cubic),
      useNativeDriver: true,
    }).start();
  }, [isOnline, loadingPresence, statusMorphAnim]);
}

async function handleJobRequestInsert(
  userId: string,
  booking: {
    id: string;
    status?: string;
    service_name?: string | null;
    price?: number | null;
    location_address?: string | null;
  },
  loadJobRequests: () => void
): Promise<void> {
  if (booking.status !== 'pending_valeter_acceptance') return;
  loadJobRequests();
  await notifyJobRequestIfAllowed(userId, booking);
}

function handleJobRequestUpdate(
  userId: string,
  booking: {
    id: string;
    status?: string;
    service_name?: string | null;
    price?: number | null;
    location_address?: string | null;
  },
  loadJobRequests: () => void,
  setJobRequests: React.Dispatch<React.SetStateAction<JobRequest[]>>
): void {
  if (booking.status === 'pending_valeter_acceptance') {
    loadJobRequests();
    notifyJobRequestIfAllowed(userId, booking).catch(() => undefined);
    return;
  }
  setJobRequests((prev) => prev.filter((r) => r.id !== booking.id));
}

function advanceJobRequestTimers(
  prev: JobRequest[],
  onTimeout: (jobId: string) => void
): JobRequest[] {
  return prev
    .map((req) => {
      if (req.timeRemaining <= 1) {
        onTimeout(req.id);
        return { ...req, timeRemaining: 0 };
      }
      return { ...req, timeRemaining: req.timeRemaining - 1 };
    })
    .filter((req) => req.timeRemaining > 0);
}

function useValeterJobRequestRealtime(
  userId: string | undefined,
  isOnline: boolean,
  loadJobRequests: () => void,
  setJobRequests: React.Dispatch<React.SetStateAction<JobRequest[]>>
) {
  useEffect(() => {
    if (!userId || !isOnline) return;

    const channel = supabase
      .channel('job-requests')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'bookings',
          filter: `valeter_id=eq.${userId}`,
        },
        (payload) => {
          const booking = payload.new as {
            id: string;
            status?: string;
            service_name?: string | null;
            price?: number | null;
            location_address?: string | null;
          };
          handleJobRequestInsert(userId, booking, loadJobRequests).catch(() => undefined);
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'bookings',
          filter: `valeter_id=eq.${userId}`,
        },
        (payload) => {
          const booking = payload.new as {
            id: string;
            status?: string;
            service_name?: string | null;
            price?: number | null;
            location_address?: string | null;
          };
          handleJobRequestUpdate(userId, booking, loadJobRequests, setJobRequests);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [userId, isOnline, loadJobRequests, setJobRequests]);
}

function useValeterJobRequestCountdown(
  jobRequests: JobRequest[],
  handleJobTimeout: (jobId: string) => void,
  setJobRequests: React.Dispatch<React.SetStateAction<JobRequest[]>>
) {
  useEffect(() => {
    if (jobRequests.length === 0) return;

    const interval = setInterval(() => {
      setJobRequests((prev) => advanceJobRequestTimers(prev, handleJobTimeout));
    }, 1000);

    return () => clearInterval(interval);
  }, [jobRequests, handleJobTimeout, setJobRequests]);
}

type DashboardActiveJobSectionProps = Readonly<{
  activeJobLoading: boolean;
  activeJob: ActiveJob | null;
  activeJobMapRegion: Region | null;
  customerNameActive: string;
  onOpenTrip: () => void;
}>;

function DashboardActiveJobSection({
  activeJobLoading,
  activeJob,
  activeJobMapRegion,
  customerNameActive,
  onOpenTrip,
}: DashboardActiveJobSectionProps) {
  if (activeJobLoading) {
    return (
      <View style={styles.activeBookingSection}>
        <View style={styles.activeBookingLoadingWrap}>
          <DefaultLoadingSkeleton message="Checking active job…" />
        </View>
      </View>
    );
  }
  if (!activeJob) return null;

  return (
    <View style={styles.activeBookingSection}>
      <TouchableOpacity activeOpacity={0.92} onPress={onOpenTrip} style={[styles.activeBookingCard, styles.activeBookingCardGlow]}>
        <View style={styles.activeBookingMapContainer}>
          {activeJobMapRegion ? (
            <>
              <MapView
                style={StyleSheet.absoluteFill}
                region={activeJobMapRegion}
                scrollEnabled={false}
                zoomEnabled={false}
                pitchEnabled={false}
                rotateEnabled={false}
                showsUserLocation
              >
                {activeJob.location_lat != null && activeJob.location_lng != null && (
                  <Marker coordinate={{ latitude: activeJob.location_lat, longitude: activeJob.location_lng }}>
                    <View style={[styles.mapMarkerContainer, { backgroundColor: 'rgba(135,206,235,0.9)' }]}>
                      <Ionicons name="location" size={20} color="#0A1929" />
                    </View>
                  </Marker>
                )}
              </MapView>
              <LinearGradient colors={['transparent', 'rgba(0,0,0,0.75)']} style={StyleSheet.absoluteFill} />
            </>
          ) : (
            <LinearGradient colors={['rgba(135,206,235,0.24)', 'rgba(30,58,138,0.3)']} style={StyleSheet.absoluteFill} />
          )}
          <View style={styles.activeBookingCardOverlayWrap}>
            <BlurView intensity={Platform.OS === 'ios' ? 48 : 72} tint="dark" style={StyleSheet.absoluteFill} />
            <View style={styles.activeBookingCardOverlay}>
              <View style={styles.activeBookingRingWrap}>
                <AnimatedProgress progress={getStatusProgress(activeJob.status as any)} size={72} strokeWidth={8} showPercentage={true} color={getStatusRingColor(activeJob.status)} />
              </View>
              <View style={styles.activeBookingCardContent}>
                <View style={styles.activeBookingLiveChip}>
                  <View style={styles.activeBookingLiveDot} />
                  <Text style={styles.activeBookingLiveText}>LIVE</Text>
                </View>
                <Text style={styles.activeBookingTitle}>Active job</Text>
                <Text style={styles.activeBookingSubtitle} numberOfLines={1}>
                  {getServiceDisplayName(activeJob.service_type, activeJob.service_name)}
                </Text>
                <Text style={styles.activeBookingValeter} numberOfLines={1}>Customer: {customerNameActive}</Text>
                <View style={styles.activeBookingStatusPill}>
                  <Text style={styles.activeBookingStatusText}>Track job</Text>
                  <Ionicons name={CONTINUE_CTA_ICON_NAME} size={14} color="#0A1929" />
                </View>
              </View>
            </View>
          </View>
        </View>
        <View style={styles.activeBookingBottomRow}>
          <BlurView intensity={Platform.OS === 'ios' ? 64 : 88} tint="dark" style={StyleSheet.absoluteFill} />
          <View style={styles.activeBookingBottomRowInner}>
            <View style={styles.activeBookingPriceWrap}>
              <LocationStyleIconBox variant="micro" icon="wallet-outline" preset="green" />
              <Text style={styles.activeBookingPrice}>£{Number(activeJob.price || 0).toFixed(2)}</Text>
            </View>
            <View style={styles.activeBookingCta}>
              <Text style={styles.activeBookingMetaCta}>Track job</Text>
              <Ionicons name="chevron-forward" size={18} color={SKY} />
            </View>
          </View>
        </View>
      </TouchableOpacity>
    </View>
  );
}

export default function PowerfulDriverDashboard() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();

  const [recentBookings, setRecentBookings] = useState<any[]>([]);
  const [isOnline, setIsOnline] = useState(false);
  const [loadingPresence, setLoadingPresence] = useState(true);
  const [toggling, setToggling] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const [jobRequests, setJobRequests] = useState<JobRequest[]>([]);
  const [nearbyCustomerCount, setNearbyCustomerCount] = useState(0);
  const [todayStats, setTodayStats] = useState<TodayStats>({
    hoursOnline: '0h 0m',
    jobsCompleted: 0,
    earnings: 0,
  });

  const [profileName, setProfileName] = useState<string>('Car Care Pro');

  const [activeJob, setActiveJob] = useState<ActiveJob | null>(null);
  const [activeJobLoading, setActiveJobLoading] = useState(false);
  const [selectedYourJob, setSelectedYourJob] = useState<YourJobSheetItem | null>(null);
  const [activeJobMapRegion, setActiveJobMapRegion] = useState<Region | null>(null);
  const [customerNameActive, setCustomerNameActive] = useState<string>('Customer');
  const statusRingPulse = useRef(new Animated.Value(0)).current;
  const statusRingLoopRef = useRef<any>(null);
  const statusSheenAnim = useRef(new Animated.Value(0)).current;
  const statusSheenLoopRef = useRef<any>(null);
  const statusFlashOpacity = useRef(new Animated.Value(0)).current;
  const statusMascotSpinAnim = useRef(new Animated.Value(0)).current;
  const statusMorphAnim = useRef(new Animated.Value(0)).current;
  const [statusFlashColor, setStatusFlashColor] = useState<string>('#10B981');
  const statusSparkleAnims = useRef<Animated.Value[]>(
    Array.from({ length: STATUS_SPARKLE_ORBITS.length }, () => new Animated.Value(0))
  ).current;

  const [showLocationPicker, setShowLocationPicker] = useState(false);
  const [pickedLocationLabel, setPickedLocationLabel] = useState<string | null>(null);
  const [locationSearchQuery, setLocationSearchQuery] = useState('');
  const [locationSearching, setLocationSearching] = useState(false);

  const { coords, cityLabel, loading: locationLoading, refresh } = useLiveLocation();

  const fadeAnim = useRef(new Animated.Value(0)).current;

  useDashboardFadeIn(fadeAnim);

  useStatusRingAnimations(
    isOnline,
    statusRingPulse,
    statusSheenAnim,
    statusRingLoopRef,
    statusSheenLoopRef
  );

  useStatusMorphAnimation(isOnline, loadingPresence, statusMorphAnim);

  const playStatusFlash = async (nextOnline: boolean) => {
    setStatusFlashColor(nextOnline ? '#10B981' : '#EF4444');
    statusFlashOpacity.stopAnimation();
    statusFlashOpacity.setValue(0);
    Animated.sequence([
      Animated.timing(statusFlashOpacity, {
        toValue: 0.28,
        duration: 220,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),
      Animated.timing(statusFlashOpacity, {
        toValue: 0.16,
        duration: 160,
        easing: Easing.inOut(Easing.quad),
        useNativeDriver: true,
      }),
      Animated.timing(statusFlashOpacity, {
        toValue: 0,
        duration: 700,
        easing: Easing.in(Easing.quad),
        useNativeDriver: true,
      }),
    ]).start();
  };

  const playStatusSparkles = useCallback(() => {
    statusSparkleAnims.forEach((anim, index) => {
      anim.stopAnimation();
      anim.setValue(0);
      Animated.sequence([
        Animated.delay(STATUS_SPARKLE_ORBITS[index].delay),
        Animated.timing(anim, {
          toValue: 1,
          duration: 850,
          easing: Easing.out(Easing.cubic),
          useNativeDriver: true,
        }),
      ]).start(() => {
        anim.setValue(0);
      });
    });
  }, [statusSparkleAnims]);

  const playMascotSpin = useCallback(() => {
    statusMascotSpinAnim.stopAnimation();
    statusMascotSpinAnim.setValue(0);
    Animated.timing(statusMascotSpinAnim, {
      toValue: 1,
      duration: 560,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start(() => {
      statusMascotSpinAnim.setValue(0);
    });
  }, [statusMascotSpinAnim]);

  const ensureStripeConnectComplete = useCallback(async () => {
    if (!user?.id) return false;
    try {
      const stripeStatus = await valeterStripeConnectService.getStatus(user.id);
      if (stripeStatus.stripeConnectStatus === 'completed') {
        return true;
      }
    } catch (error) {
      console.warn('[presence] stripe status check failed:', error);
    }
    Alert.alert(
      'Stripe Connect required',
      'Complete Stripe Connect before you go online or accept washes.'
    );
    return false;
  }, [user?.id]);

  const handleToggleOnline = async () => {
    if (loadingPresence || toggling) return;
    if (!isOnline) {
      const canGoOnline = await ensureStripeConnectComplete();
      if (!canGoOnline) return;
    }
    playMascotSpin();
    playStatusSparkles();
    await playStatusFlash(!isOnline);
    await toggleOnline();
  };

  const loadValeterName = async (userId: string) => {
    // 1) valeter_profiles.full_name (primary - saved from profile page)
    try {
      const { data: vp } = await supabase
        .from('valeter_profiles')
        .select('full_name')
        .eq('user_id', userId)
        .maybeSingle();

      const name = (vp?.full_name || '').trim();
      if (name) return name;
    } catch {}

    // 2) profiles.full_name (fallback)
    try {
      const { data: p } = await supabase
        .from('profiles')
        .select('full_name')
        .eq('id', userId)
        .maybeSingle();

      const name = (p?.full_name || '').trim();
      if (name) return name;
    } catch {}

    // 3) auth context / fallback
    const maybe = (user?.name || '').trim();
    if (maybe) return maybe;

    return 'Car Care Pro';
  };

  const loadRecentBookings = useCallback(async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select(
          'id, service_type, service_name, status, price, scheduled_at, location_address, user_id, created_at, completed_at, updated_at'
        )
        .eq('valeter_id', user.id)
        .in('status', [
          'completed',
          'confirmed',
          'in_progress',
          'scheduled',
          'pending_payment',
          'en_route',
          'arrived',
          'pending_valeter_acceptance',
          'valeter_assigned',
        ])
        .limit(40);

      if (error) {
        console.warn('[Dashboard] loadRecentBookings error:', error);
        setRecentBookings([]);
        return;
      }
      if (!data?.length) {
        setRecentBookings([]);
        return;
      }

      const ids = [
        ...new Set(
          data
            .map((b: { user_id?: string | null }) => b.user_id)
            .filter((id): id is string => typeof id === 'string' && id.length > 0)
        ),
      ];
      const profiles = await fetchProfilesByIds(ids);
      const photos = ids.length > 0 ? resolveCustomerAvatarsForUserIds(ids, profiles) : new Map();
      const now = Date.now();
      const thirtyMs = 30 * 24 * 60 * 60 * 1000;

      const enriched = data
        .map((b: Record<string, unknown>) => {
          const uid = typeof b.user_id === 'string' ? b.user_id : null;
          const p = uid ? profiles.get(uid) : undefined;
          return {
            ...b,
            customer_name: p?.full_name || p?.name || 'Customer',
            customer_photo: uid ? photos.get(uid) ?? null : null,
          };
        })
        .filter((b: Record<string, unknown>) => recentBookingStillVisible(b, thirtyMs));

      enriched.sort((a, b) => compareEnrichedBookings(a, b, now));

      setRecentBookings(enriched);
    } catch (e) {
      console.warn('[Dashboard] loadRecentBookings error:', e);
      setRecentBookings([]);
    }
  }, [user?.id]);

  // Load initial online status + subscribe to realtime
  useEffect(() => {
    if (!user?.id) return;
    let mounted = true;

    (async () => {
      setLoadingPresence(true);

      // ✅ Name at top should be the valeter's name
      const name = await loadValeterName(user.id);
      if (mounted) setProfileName(name);

      // Load recent bookings and today's earnings (real data from jobs)
      const todayStart = new Date();
      todayStart.setHours(0, 0, 0, 0);
      const todayEnd = new Date(todayStart);
      todayEnd.setDate(todayEnd.getDate() + 1);

      const [todayRes] = await Promise.all([
        supabase
          .from('bookings')
          .select('id, status, price, scheduled_at')
          .eq('valeter_id', user.id)
          .gte('scheduled_at', todayStart.toISOString())
          .lt('scheduled_at', todayEnd.toISOString()),
        loadRecentBookings(),
      ]);

      if (mounted && todayRes.data) {
        const completedToday = (todayRes.data as any[]).filter((b) => b.status === 'completed');
        const earningsToday = completedToday.reduce((sum: number, b: any) => sum + (Number(b.price) || 0), 0);
        setTodayStats({
          hoursOnline: '0h 0m',
          jobsCompleted: completedToday.length,
          earnings: Math.round(earningsToday * 100) / 100,
        });
      }

      // presence
      const { data, error } = await supabase
        .from('valeter_presence')
        .select('is_online')
        .eq('user_id', user.id)
        .maybeSingle();

      if (!mounted) return;
      if (error) console.warn('[presence] read error', error);

      setIsOnline(!!data?.is_online);
      setLoadingPresence(false);
    })();

    const channel = supabase
      .channel('presence-self')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'valeter_presence',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          const row: any = payload.new ?? payload.old;
          if (row && typeof row.is_online === 'boolean') setIsOnline(row.is_online);
        }
      )
      .subscribe();

    return () => {
      mounted = false;
      supabase.removeChannel(channel);
    };
  }, [user?.id, loadRecentBookings]);

  useEffect(() => {
    if (!user?.id) return;
    preparePhoneNotifications().catch(() => undefined);
    registerPushToken().catch(() => undefined);
  }, [user?.id]);

  // When valeter is already online (e.g. after login), refresh their location once so map/jobs show current position
  const locationRefreshedOnMount = useRef(false);
  useEffect(() => {
    if (!user?.id || !isOnline || loadingPresence || locationRefreshedOnMount.current) return;
    locationRefreshedOnMount.current = true;
    (async () => {
      try {
        const { status } = await Location.getForegroundPermissionsAsync();
        if (status !== 'granted') return;
        const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
        const lat = Number(loc.coords.latitude.toFixed(6));
        const lng = Number(loc.coords.longitude.toFixed(6));
        await supabase.rpc('update_my_presence', {
          p_is_online: true,
          p_last_lat: lat,
          p_last_lng: lng,
        });
      } catch (e) {
        console.warn('[ValeterDashboard] Refresh location on load failed:', e);
      }
    })();
  }, [user?.id, isOnline, loadingPresence]);

  const REQUEST_TIMEOUT_SECONDS = 300; // 5 min to accept

  const loadJobRequests = useCallback(async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select(
          'id, service_name, service_type, location_address, location_lat, location_lng, price, scheduled_at, request_sent_at, created_at, user_id'
        )
        .eq('valeter_id', user.id)
        .eq('status', 'pending_valeter_acceptance')
        .order('request_sent_at', { ascending: false })
        .limit(20);

      if (error) throw error;

      const rows = data || [];
      const userIds = [...new Set(rows.map((r: any) => r.user_id).filter(Boolean))] as string[];
      const { commitmentWindows, externalBusy } = await loadValeterScheduleBlocks(user.id);
      const [presenceRes, profilesMap] = await Promise.all([
        supabase.from('valeter_presence').select('last_lat, last_lng').eq('user_id', user.id).maybeSingle(),
        fetchProfilesByIds(userIds),
      ]);
      const vLat = presenceRes.data?.last_lat;
      const vLng = presenceRes.data?.last_lng;

      const nowSec = Math.floor(Date.now() / 1000);
      const list: JobRequest[] = rows.map((r: any) => {
        const sentAt = r.request_sent_at || r.created_at;
        const endSec = sentAt ? Math.floor(new Date(sentAt).getTime() / 1000) + REQUEST_TIMEOUT_SECONDS : nowSec + REQUEST_TIMEOUT_SECONDS;
        const timeRemaining = Math.max(0, endSec - nowSec);
        let distance = 0;
        let driveTimeMinutes: number | undefined;
        if (vLat != null && vLng != null && r.location_lat != null && r.location_lng != null) {
          distance = Math.round(haversineMi(vLat, vLng, r.location_lat, r.location_lng) * 10) / 10;
          driveTimeMinutes = Math.round(distance * 2);
        }
        const profile = r.user_id ? profilesMap.get(r.user_id) : null;
        const customerName = profile?.full_name?.trim() || 'Customer';
        return {
          id: r.id,
          serviceName: getServiceDisplayName(r.service_type, r.service_name),
          distance,
          driveTimeMinutes,
          price: Number(r.price) || 0,
          customerName,
          address: r.location_address || '',
          timeRemaining,
          location_lat: optionalNumberCoord(r.location_lat),
          location_lng: optionalNumberCoord(r.location_lng),
          scheduledAt: r.scheduled_at ?? null,
          requestSentAt: r.request_sent_at || r.created_at || null,
          serviceType: typeof r.service_type === 'string' ? r.service_type : undefined,
          serviceNameRaw: r.service_name ?? null,
        };
      });
      const listFiltered = list.filter(
        (req) =>
          !offerOverlapsSchedule(
            req.scheduledAt,
            req.requestSentAt,
            req.serviceType,
            req.serviceNameRaw ?? undefined,
            commitmentWindows,
            externalBusy
          )
      );
      setJobRequests(listFiltered);
    } catch (e) {
      console.warn('[Dashboard] loadJobRequests error', e);
      setJobRequests([]);
    }
  }, [user?.id]);

  const loadNearbyCustomerCount = useCallback(async () => {
    if (!user?.id || !isOnline) {
      setNearbyCustomerCount(0);
      return;
    }
    try {
      const { data: presence } = await supabase
        .from('valeter_presence')
        .select('last_lat, last_lng')
        .eq('user_id', user.id)
        .maybeSingle();
      if (!presence?.last_lat || !presence?.last_lng) {
        setNearbyCustomerCount(0);
        return;
      }
      const { value: radiusMi } = await fetchRadiusPreference(user.id);
      const r = radiusMi ?? 10;
      const { data: bookings } = await supabase
        .from('bookings')
        .select('user_id, location_lat, location_lng')
        .in('status', ['pending_valeter_acceptance', 'pending_payment', 'confirmed', 'scheduled'])
        .not('location_lat', 'is', null)
        .not('location_lng', 'is', null);
      const valeterLat = presence.last_lat;
      const valeterLng = presence.last_lng;
      const inRadius = (bookings || []).filter(
        (b: any) =>
          b.location_lat &&
          b.location_lng &&
          haversineMi(valeterLat, valeterLng, b.location_lat, b.location_lng) <= r
      );
      setNearbyCustomerCount(new Set(inRadius.map((b: any) => b.user_id)).size);
    } catch {
      setNearbyCustomerCount(0);
    }
  }, [user?.id, isOnline]);

  useSyncValeterNavJobRequests(jobRequests.length);

  // Load job requests when online (initial + when going online)
  useEffect(() => {
    if (!user?.id || !isOnline) {
      setNearbyCustomerCount(0);
      return;
    }
    loadJobRequests();
    loadNearbyCustomerCount();
  }, [user?.id, isOnline, loadJobRequests, loadNearbyCustomerCount]);

  useValeterJobRequestRealtime(user?.id, isOnline, loadJobRequests, setJobRequests);

  const goOnlineWithLocation = async () => {
    const uid = user?.id;
    if (!uid) throw new Error('not-signed-in');
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission needed', 'Location permission is required to go online so customers can find you.');
      throw new Error('location-permission-denied');
    }
    const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
    const lat = Number(loc.coords.latitude.toFixed(6));
    const lng = Number(loc.coords.longitude.toFixed(6));

    const { error } = await supabase.rpc('update_my_presence', {
      p_is_online: true,
      p_last_lat: lat,
      p_last_lng: lng,
    });
    if (error) throw error;
    syncValeterExternalCalendarBusyToSupabase(uid, true).catch(() => undefined);
  };

  const goOffline = async () => {
    const { error } = await supabase.rpc('set_online', { p_is_online: false });
    if (error) throw error;
  };

  const toggleOnline = async () => {
    try {
      if (!user?.id) return;
      setToggling(true);
      await hapticFeedback('medium');

      if (isOnline) {
        await goOffline();
      } else {
        await goOnlineWithLocation();
      }

      setIsOnline(!isOnline);
    } catch (e) {
      console.error('[presence] toggle error', e);
      Alert.alert('Error', 'Could not update your online status. Try again.');
    } finally {
      setToggling(false);
    }
  };

  const handleAcceptJob = async (jobId: string) => {
    if (!user?.id) return;
    try {
      const canAccept = await ensureStripeConnectComplete();
      if (!canAccept) return;
      await hapticFeedback('medium');
      const req = jobRequests.find((r) => r.id === jobId);
      const gate = await assertNoScheduleConflictForOffer(user.id, {
        scheduled_at: req?.scheduledAt,
        request_sent_at: req?.requestSentAt,
        service_type: req?.serviceType,
        service_name: req?.serviceNameRaw,
      });
      if (!gate.ok) {
        Alert.alert('Schedule clash', gate.message);
        return;
      }
      const { error } = await supabase
        .from('bookings')
        .update({
          valeter_id: user.id,
          status: 'pending_payment',
        })
        .eq('id', jobId);

      if (error) throw error;

      setJobRequests((prev) => prev.filter((r) => r.id !== jobId));
      router.push({ pathname: '/valeter/jobs/tracking', params: { jobId } } as any);
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to accept job');
    }
  };

  const handleDeclineJob = async (jobId: string) => {
    try {
      await hapticFeedback('light');
      const { error } = await supabase
        .from('bookings')
        .update({
          status: 'valeter_declined',
          valeter_response_at: new Date().toISOString(),
        })
        .eq('id', jobId);

      if (error) throw error;
      setJobRequests((prev) => prev.filter((r) => r.id !== jobId));
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to decline job');
    }
  };

  const handleJobTimeout = async (jobId: string) => {
    try {
      await supabase.from('bookings').update({ status: 'valeter_timeout' }).eq('id', jobId);
    } catch (e) {
      console.error('Timeout update failed:', e);
    }
  };

  useValeterJobRequestCountdown(jobRequests, handleJobTimeout, setJobRequests);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const displayLocationLabel = pickedLocationLabel ?? cityLabel ?? 'Set location';

  const handleUseCurrentLocation = async () => {
    try {
      await hapticFeedback('light');
      setPickedLocationLabel(null);
      const { status } = await Location.getForegroundPermissionsAsync();
      if (status !== 'granted') {
        const req = await Location.requestForegroundPermissionsAsync();
        if (req.status !== 'granted') {
          Alert.alert('Permission needed', 'Location permission is required to use current location.');
          return;
        }
      }
      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const lat = Number(loc.coords.latitude.toFixed(6));
      const lng = Number(loc.coords.longitude.toFixed(6));
      if (user?.id && isOnline) {
        await supabase.rpc('update_my_presence', { p_is_online: true, p_last_lat: lat, p_last_lng: lng });
      }
      await refresh();
      setShowLocationPicker(false);
    } catch (e) {
      console.warn('[Dashboard] use current location error', e);
      Alert.alert('Error', 'Could not get current location. Try again.');
    }
  };

  const handleSearchLocation = async () => {
    const query = locationSearchQuery.trim();
    if (!query) return;
    try {
      setLocationSearching(true);
      await hapticFeedback('light');
      const results = await Location.geocodeAsync(query);
      if (results && results.length > 0) {
        const first = results[0];
        const lat = first.latitude;
        const lng = first.longitude;
        setPickedLocationLabel(query);
        if (user?.id && isOnline) {
          await supabase.rpc('update_my_presence', {
            p_is_online: true,
            p_last_lat: Number(lat.toFixed(6)),
            p_last_lng: Number(lng.toFixed(6)),
          });
        }
        setShowLocationPicker(false);
        setLocationSearchQuery('');
      } else {
        Alert.alert('No results', 'No location found for that address. Try a different search.');
      }
    } catch (e) {
      console.warn('[Dashboard] geocode error', e);
      Alert.alert('Error', 'Could not find that location. Try again.');
    } finally {
      setLocationSearching(false);
    }
  };

  const loadActiveJob = useCallback(async () => {
    if (!user?.id) return;
    try {
      setActiveJobLoading(true);
      const { data, error } = await supabase
        .from('bookings')
        .select('id,status,service_type,service_name,location_address,location_lat,location_lng,price,user_id')
        .eq('valeter_id', user.id)
        .in('status', ACTIVE_JOB_STATUSES as any)
        .order('request_sent_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error || !data) {
        setActiveJob(null);
        setActiveJobMapRegion(null);
        return;
      }

      const lat = optionalNumberCoord(data.location_lat);
      const lng = optionalNumberCoord(data.location_lng);

      setActiveJob({
        id: data.id,
        status: data.status,
        service_type: data.service_type,
        service_name: data.service_name ?? null,
        location_address: data.location_address ?? null,
        location_lat: lat,
        location_lng: lng,
        price: Number(data.price ?? 0),
        user_id: data.user_id ?? null,
      });

      if (lat != null && lng != null) {
        setActiveJobMapRegion({
          latitude: lat,
          longitude: lng,
          latitudeDelta: 0.02,
          longitudeDelta: 0.02,
        });
      } else {
        setActiveJobMapRegion(null);
      }

      if (data.user_id) {
        const profile = await fetchProfileById(data.user_id);
        setCustomerNameActive(profile?.full_name || 'Customer');
      } else {
        setCustomerNameActive('Customer');
      }
    } catch (e) {
      console.warn('[Dashboard] loadActiveJob error:', e);
      setActiveJob(null);
      setActiveJobMapRegion(null);
    } finally {
      setActiveJobLoading(false);
    }
  }, [user?.id]);

  useEffect(() => {
    if (!user?.id) return;
    loadActiveJob();
    const channel = supabase
      .channel(`valeter-active-job-${user.id}`)
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'bookings', filter: `valeter_id=eq.${user.id}` },
        () => { loadActiveJob(); }
      )
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user?.id, loadActiveJob]);

  const loadTodayStats = useCallback(async () => {
    if (!user?.id) return;
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    const todayEnd = new Date(todayStart);
    todayEnd.setDate(todayEnd.getDate() + 1);
    const { data } = await supabase
      .from('bookings')
      .select('id, status, price, completed_at')
      .eq('valeter_id', user.id)
      .eq('status', 'completed')
      .gte('completed_at', todayStart.toISOString())
      .lt('completed_at', todayEnd.toISOString());
    const completedToday = data || [];
    const earningsToday = completedToday.reduce((sum: number, b: any) => sum + (Number(b.price) || 0), 0);
    setTodayStats({
      hoursOnline: '0h 0m',
      jobsCompleted: completedToday.length,
      earnings: Math.round(earningsToday * 100) / 100,
    });
  }, [user?.id]);

  const onRefresh = async () => {
    setRefreshing(true);
    try {
      if (user?.id) {
        const name = await loadValeterName(user.id);
        setProfileName(name);
        await loadActiveJob();
        await loadJobRequests();
        await loadNearbyCustomerCount();
        await loadTodayStats();
        await loadRecentBookings();
      }
      await new Promise((resolve) => setTimeout(resolve, 700));
    } finally {
      setRefreshing(false);
    }
  };

  const accent = theme.primary || '#3B82F6';
  const upcomingJobs = useMemo(() => {
    const now = Date.now();
    return recentBookings
      .filter((b: any) => {
        if (!b.scheduled_at || new Date(b.scheduled_at).getTime() <= now) return false;
        const s = String(b.status);
        return !['completed', 'cancelled', 'valeter_timeout'].includes(s);
      })
      .slice(0, 8);
  }, [recentBookings]);
  const firstJobRequest = jobRequests[0] ?? null;

  const firstJobRequestMapRegion = useMemo((): Region | null => {
    if (!firstJobRequest?.location_lat || !firstJobRequest?.location_lng) return null;
    const jLat = firstJobRequest.location_lat;
    const jLng = firstJobRequest.location_lng;
    const vLat = coords?.latitude;
    const vLng = coords?.longitude;
    if (vLat != null && vLng != null) {
      const minLat = Math.min(jLat, vLat);
      const maxLat = Math.max(jLat, vLat);
      const minLng = Math.min(jLng, vLng);
      const maxLng = Math.max(jLng, vLng);
      const latDelta = Math.max((maxLat - minLat) * 2, 0.012);
      const lngDelta = Math.max((maxLng - minLng) * 2, 0.012);
      return {
        latitude: (minLat + maxLat) / 2,
        longitude: (minLng + maxLng) / 2,
        latitudeDelta: latDelta,
        longitudeDelta: lngDelta,
      };
    }
    return { latitude: jLat, longitude: jLng, latitudeDelta: 0.02, longitudeDelta: 0.02 };
  }, [firstJobRequest?.location_lat, firstJobRequest?.location_lng, coords?.latitude, coords?.longitude]);

  const statusRingPulseScale = statusRingPulse.interpolate({
    inputRange: [0, 1],
    outputRange: [1, 1.34],
  });
  const statusRingPulseOpacity = statusRingPulse.interpolate({
    inputRange: [0, 0.15, 1],
    outputRange: [0.55, 0.45, 0],
  });
  const statusRingPulseScaleSoft = statusRingPulse.interpolate({
    inputRange: [0, 0.4, 1],
    outputRange: [1, 1.08, 1.22],
  });
  const statusRingPulseOpacitySoft = statusRingPulse.interpolate({
    inputRange: [0, 0.4, 0.65, 1],
    outputRange: [0, 0.35, 0.22, 0],
  });

  const statusMascotSpin = statusMascotSpinAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '360deg'],
  });
  const statusSheenRotate = statusSheenAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '360deg'],
  });

  const heroMorphOpacity = statusMorphAnim.interpolate({
    inputRange: [0, 0.5, 1],
    outputRange: [1, 0.25, 0],
  });
  const heroMorphScale = statusMorphAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [1, 0.68],
  });
  const heroMorphTranslateY = statusMorphAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [0, -36],
  });

  const pillMorphOpacity = statusMorphAnim.interpolate({
    inputRange: [0, 0.42, 1],
    outputRange: [0, 0.55, 1],
  });
  const pillMorphScale = statusMorphAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [0.9, 1],
  });
  const pillMorphTranslateY = statusMorphAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [-10, 0],
  });
  const mapOfflineTintOpacity = statusMorphAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [1, 0],
  });

  const pulseRingColor = isOnline ? 'rgba(74,222,128,0.8)' : 'rgba(248,113,113,0.82)';
  const pulseRingSoftColor = isOnline ? 'rgba(34,197,94,0.42)' : 'rgba(248,113,113,0.38)';

  const mapRef = useRef<MapView | null>(null);

  const dashboardMapRegion = useMemo((): Region => {
    const points: { lat: number; lng: number }[] = [];
    if (coords?.latitude != null && coords?.longitude != null) {
      points.push({ lat: coords.latitude, lng: coords.longitude });
    }
    if (activeJob?.location_lat != null && activeJob?.location_lng != null) {
      points.push({ lat: activeJob.location_lat, lng: activeJob.location_lng });
    }
    if (firstJobRequest?.location_lat != null && firstJobRequest?.location_lng != null) {
      points.push({ lat: firstJobRequest.location_lat, lng: firstJobRequest.location_lng });
    }
    if (points.length === 0) {
      return {
        latitude: 51.5074,
        longitude: -0.1278,
        latitudeDelta: 0.08,
        longitudeDelta: 0.08,
      };
    }
    if (points.length === 1) {
      return {
        latitude: points[0].lat,
        longitude: points[0].lng,
        latitudeDelta: 0.045,
        longitudeDelta: 0.045,
      };
    }
    const minLat = Math.min(...points.map((p) => p.lat));
    const maxLat = Math.max(...points.map((p) => p.lat));
    const minLng = Math.min(...points.map((p) => p.lng));
    const maxLng = Math.max(...points.map((p) => p.lng));
    return {
      latitude: (minLat + maxLat) / 2,
      longitude: (minLng + maxLng) / 2,
      latitudeDelta: Math.max((maxLat - minLat) * 2.4, 0.02),
      longitudeDelta: Math.max((maxLng - minLng) * 2.4, 0.02),
    };
  }, [coords?.latitude, coords?.longitude, activeJob, firstJobRequest]);

  const handleMapRecenter = () => {
    hapticFeedback('light');
    mapRef.current?.animateToRegion(dashboardMapRegion, 450);
  };

  const handleOpenTrip = () => {
    if (!activeJob?.id) return;
    hapticFeedback('light');
    router.push({ pathname: '/valeter/trips', params: { jobId: activeJob.id } } as any);
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />
      <MapView
        ref={mapRef}
        style={StyleSheet.absoluteFill}
        region={dashboardMapRegion}
        showsUserLocation
        showsMyLocationButton={false}
        customMapStyle={DARK_MAP_STYLE}
      >
        {activeJob?.location_lat != null && activeJob?.location_lng != null ? (
          <Marker coordinate={{ latitude: activeJob.location_lat, longitude: activeJob.location_lng }}>
            <View style={[styles.mapMarkerJob, { backgroundColor: '#10B981' }]}>
              <Ionicons name="location" size={18} color="#0A1929" />
            </View>
          </Marker>
        ) : null}
        {firstJobRequest?.location_lat != null && firstJobRequest?.location_lng != null ? (
          <Marker coordinate={{ latitude: firstJobRequest.location_lat, longitude: firstJobRequest.location_lng }}>
            <View style={[styles.mapMarkerJob, { backgroundColor: accent }]}>
              <Ionicons name="car" size={16} color="#fff" />
            </View>
          </Marker>
        ) : null}
      </MapView>
      <Animated.View
        pointerEvents="none"
        style={[StyleSheet.absoluteFill, styles.mapOfflineTint, { opacity: mapOfflineTintOpacity }]}
      />
      <LinearGradient
        colors={['transparent', 'rgba(10,25,41,0.2)', 'rgba(10,25,41,0.75)']}
        style={styles.mapBottomScrim}
        pointerEvents="none"
      />
      <View pointerEvents="none" style={StyleSheet.absoluteFill}>
        <Animated.View
          style={[
            StyleSheet.absoluteFill,
            {
              backgroundColor: statusFlashColor,
              opacity: statusFlashOpacity,
            },
          ]}
        />
      </View>
      <SafeAreaView style={styles.mapSafe} edges={[]} pointerEvents="box-none">
        <AppHeader
          variant="dashboard"
          fullWidth
          flushTop
          title={profileName || 'Car Care Pro'}
          subtitle={displayLocationLabel}
          onSubtitlePress={() => { hapticFeedback('light'); setShowLocationPicker(true); }}
          accountType="valeter"
          showBack={false}
          dashboardInlineRightAction
          leftAction={<ValeterMenuButton color={accent} headerInline />}
          rightAction={
            <TouchableOpacity onPress={() => router.push('/valeter/notifications')} style={{ padding: 0 }}>
              <GradientNotificationBell count={jobRequests.length} onPress={() => router.push('/valeter/notifications')} />
            </TouchableOpacity>
          }
        />

        <Animated.View
          pointerEvents={isOnline ? 'auto' : 'none'}
          style={[
            styles.mapOnlinePill,
            styles.mapOnlinePillFloating,
            {
              top: insets.top + DASHBOARD_HEADER_HEIGHT + 16,
              left: isSmallScreen ? 12 : SCREEN_PADDING_H,
              right: isSmallScreen ? 12 : SCREEN_PADDING_H,
              borderColor: isOnline ? 'rgba(74,222,128,0.55)' : 'rgba(248,113,113,0.45)',
              opacity: pillMorphOpacity,
              transform: [{ translateY: pillMorphTranslateY }, { scale: pillMorphScale }],
            },
          ]}
        >
          <Pressable
            onPress={handleToggleOnline}
            disabled={loadingPresence || toggling}
            style={styles.mapOnlinePillPressable}
          >
            <BlurView
              intensity={Platform.OS === 'ios' ? 50 : 68}
              tint="dark"
              style={StyleSheet.absoluteFill}
              {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
            />
            <View style={[styles.mapOnlineDot, { backgroundColor: isOnline ? '#4ADE80' : '#F87171' }]} />
            <View style={styles.mapOnlineCopy}>
              <Text style={styles.mapOnlineTitle}>{isOnline ? 'You are online' : 'You are offline'}</Text>
              <Text style={styles.mapOnlineSub}>{isOnline ? 'Accepting wash requests' : 'Tap to go online'}</Text>
            </View>
            {loadingPresence || toggling ? (
              <ActivityIndicator size="small" color="#F9FAFB" />
            ) : (
              <Ionicons name={isOnline ? 'pause-circle' : 'play-circle'} size={26} color={isOnline ? '#4ADE80' : '#F87171'} />
            )}
          </Pressable>
        </Animated.View>

        <Animated.View
          pointerEvents={isOnline ? 'none' : 'auto'}
          style={[
            styles.statusHeroFloating,
            {
              top: insets.top + DASHBOARD_HEADER_HEIGHT + 12,
              opacity: heroMorphOpacity,
              transform: [{ translateY: heroMorphTranslateY }, { scale: heroMorphScale }],
            },
          ]}
        >
          <Pressable
            onPress={handleToggleOnline}
            disabled={loadingPresence || toggling}
            style={styles.statusHeroPressable}
          >
            {isOnline === false ? (
              <View style={styles.statusHeroCopy}>
                <Text style={[styles.statusHeroTitle, styles.statusHeroTitleOffline]}>Tap to go online</Text>
              </View>
            ) : null}
            <View style={styles.statusHeroWrap}>
              <View style={styles.statusHeroButtonArea}>
                <Animated.View
                  pointerEvents="none"
                  style={[
                    styles.statusHeroPulseRing,
                    {
                      borderColor: pulseRingColor,
                      transform: [{ scale: statusRingPulseScale }],
                      opacity: statusRingPulseOpacity,
                    },
                  ]}
                />
                <Animated.View
                  pointerEvents="none"
                  style={[
                    styles.statusHeroPulseRing,
                    styles.statusHeroPulseRingOnlineSoft,
                    {
                      borderColor: pulseRingSoftColor,
                      transform: [{ scale: statusRingPulseScaleSoft }],
                      opacity: statusRingPulseOpacitySoft,
                    },
                  ]}
                />

                <View style={[styles.statusHeroGlow, isOnline ? styles.statusHeroGlowOnline : styles.statusHeroGlowOffline]} />

                {isOnline ? (
                  <Animated.View
                    pointerEvents="none"
                    style={[styles.statusHeroSheen, { transform: [{ rotate: statusSheenRotate }] }]}
                  >
                    <View style={[styles.statusHeroSheenBand, { backgroundColor: 'rgba(134,239,172,0.14)' }]} />
                  </Animated.View>
                ) : null}

                <View style={[styles.statusHeroButton, isOnline ? styles.statusHeroButtonOnline : styles.statusHeroButtonOffline]}>
                  <Animated.View
                    style={[
                      styles.statusHeroButtonInner,
                      isOnline ? styles.statusHeroButtonInnerOnline : styles.statusHeroButtonInnerOffline,
                      { transform: [{ rotate: statusMascotSpin }] },
                    ]}
                  >
                    <View style={styles.statusHeroImageRing}>
                      <View style={[styles.statusHeroImageInner, isOnline ? styles.statusHeroImageInnerOnline : styles.statusHeroImageInnerOffline]}>
                        <Image source={ICON_AUTH_IMAGE} style={styles.statusHeroMascot} resizeMode="contain" />
                      </View>
                    </View>
                  </Animated.View>

                  {loadingPresence || toggling ? (
                    <View style={styles.statusHeroLoadingOverlay}>
                      <ActivityIndicator size="small" color="#F9FAFB" />
                    </View>
                  ) : null}
                </View>
              </View>
            </View>
          </Pressable>
        </Animated.View>
      </SafeAreaView>

      <ValeterDashboardBottomSheet
        earnings={todayStats.earnings}
        jobsCompleted={todayStats.jobsCompleted}
        jobRequestCount={jobRequests.length}
        upcomingJobs={upcomingJobs}
        isOnline={isOnline}
        nearbyCustomerCount={nearbyCustomerCount}
        accent={accent}
        headerGradient={themeBackgroundGradient(theme?.headerBackground, HEADER_STYLE_CARD_GRADIENT)}
        onRecenter={handleMapRecenter}
        onUpcomingJobPress={(job) => {
          hapticFeedback('light');
          setSelectedYourJob({ ...job, _type: 'upcoming' });
        }}
        refreshing={refreshing}
        onRefresh={onRefresh}
      >
        <Animated.View style={{ opacity: fadeAnim }}>
            <DashboardActiveJobSection
              activeJobLoading={activeJobLoading}
              activeJob={activeJob}
              activeJobMapRegion={activeJobMapRegion}
              customerNameActive={customerNameActive}
              onOpenTrip={handleOpenTrip}
            />

            {/* New job request — single premium card with live map background */}
            {firstJobRequest && (
              <View style={styles.belowQuickWrap}>
                <View style={[styles.requestCard, styles.requestCardWithMap]}>
                  {firstJobRequestMapRegion ? (
                    <>
                      <MapView
                        style={styles.requestCardMap}
                        region={firstJobRequestMapRegion}
                        scrollEnabled={false}
                        zoomEnabled={false}
                        pitchEnabled={false}
                        rotateEnabled={false}
                        customMapStyle={DARK_MAP_STYLE}
                      >
                        {coords?.latitude != null && coords?.longitude != null && (
                          <Marker coordinate={{ latitude: coords.latitude, longitude: coords.longitude }} title="You">
                            <View style={[styles.requestCardMapMarkerYou, { backgroundColor: accent }]}>
                              <Ionicons name="location" size={12} color="#fff" />
                            </View>
                          </Marker>
                        )}
                        <Marker coordinate={{ latitude: firstJobRequest.location_lat!, longitude: firstJobRequest.location_lng! }} title={firstJobRequest.serviceName}>
                          <View style={styles.requestCardMapMarkerJob}>
                            <Ionicons name="car" size={12} color="#fff" />
                          </View>
                        </Marker>
                      </MapView>
                      <LinearGradient
                        colors={['rgba(0,0,0,0.35)', 'rgba(0,0,0,0.7)', 'rgba(0,0,0,0.85)']}
                        style={StyleSheet.absoluteFill}
                        start={{ x: 0.5, y: 0 }}
                        end={{ x: 0.5, y: 1 }}
                      />
                      <BlurView
                        intensity={Platform.OS === 'ios' ? 28 : 48}
                        tint="dark"
                        style={[StyleSheet.absoluteFill, { opacity: 0.85 }]}
                        {...ANDROID_BLUR_METHOD}
                      />
                    </>
                  ) : null}
                  <View style={styles.requestCardContent}>
                    <View style={styles.requestCardBadge}>
                      <View style={styles.requestCardBadgeDot} />
                      <Text style={styles.requestCardBadgeText}>New request</Text>
                    </View>
                    <View style={styles.requestHeader}>
                      <View style={styles.requestTitleRow}>
                        <Text style={styles.requestTitle}>{firstJobRequest.serviceName}</Text>
                        {firstJobRequest.price >= 40 && (
                          <View style={styles.requestHighValueBadge}>
                            <Ionicons name="star" size={12} color="#FBBF24" />
                            <Text style={styles.requestHighValueText}>High value</Text>
                          </View>
                        )}
                      </View>
                      <View style={styles.requestTimer}>
                        <Ionicons name="time" size={12} color="#fff" />
                        <Text style={styles.requestTimerText}>{formatTime(firstJobRequest.timeRemaining)}</Text>
                      </View>
                    </View>
                    <Text style={styles.requestCustomer}>{firstJobRequest.customerName}</Text>
                    <Text style={styles.requestAddress} numberOfLines={2}>{firstJobRequest.address}</Text>
                    <View style={styles.requestMeta}>
                      <Text style={styles.requestPrice}>£{firstJobRequest.price}</Text>
                      {firstJobRequest.distance > 0 && (
                        <Text style={styles.requestDistance}>
                          {formatRequestDistanceLine(firstJobRequest.distance, firstJobRequest.driveTimeMinutes)}
                        </Text>
                      )}
                      {jobRequests.length > 1 && <Text style={styles.requestMore}>+{jobRequests.length - 1} more</Text>}
                    </View>
                    <View style={styles.requestActions}>
                      <TouchableOpacity style={styles.acceptBtn} onPress={() => handleAcceptJob(firstJobRequest.id)} activeOpacity={0.8}>
                        <GradientIconBox
                          icon="checkmark"
                          borderless
                          boxSize={28}
                          size={16}
                          colors={['rgba(255,255,255,0.38)', 'rgba(255,255,255,0.14)']}
                        />
                        <Text style={styles.acceptBtnText}>Accept</Text>
                      </TouchableOpacity>
                      <TouchableOpacity style={styles.declineBtn} onPress={() => handleDeclineJob(firstJobRequest.id)} activeOpacity={0.8}>
                        <Text style={styles.declineBtnText}>Decline</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              </View>
            )}
        </Animated.View>
      </ValeterDashboardBottomSheet>
      <Modal visible={showLocationPicker} transparent animationType="slide">
        <Pressable style={styles.locationPickerOverlay} onPress={() => setShowLocationPicker(false)}>
          <Pressable style={styles.locationPickerSheet} onPress={(e) => e.stopPropagation()}>
            <View style={styles.locationPickerHandle} />
            <Text style={styles.locationPickerTitle}>Location</Text>
            <Text style={styles.locationPickerSubtitle}>Choose how to set your location</Text>
            <TouchableOpacity
              style={styles.locationPickerOption}
              onPress={handleUseCurrentLocation}
              disabled={locationLoading}
              activeOpacity={0.8}
            >
              <View style={styles.locationPickerOptionIcon}>
                <Ionicons name="navigate" size={22} color={SKY} />
              </View>
              <View style={styles.locationPickerOptionText}>
                <Text style={styles.locationPickerOptionTitle}>Use current location</Text>
                <Text style={styles.locationPickerOptionSub}>GPS will update your position</Text>
              </View>
              {locationLoading ? <ActivityIndicator size="small" color={SKY} /> : <Ionicons name="chevron-forward" size={18} color="rgba(249,250,251,0.5)" />}
            </TouchableOpacity>
            <View style={styles.locationPickerDivider} />
            <Text style={styles.locationPickerSearchLabel}>Search for a place</Text>
            <View style={styles.locationPickerSearchRow}>
              <TextInput
                style={styles.locationPickerSearchInput}
                placeholder="Address or place name"
                placeholderTextColor="rgba(249,250,251,0.4)"
                value={locationSearchQuery}
                onChangeText={setLocationSearchQuery}
                onSubmitEditing={handleSearchLocation}
                returnKeyType="search"
              />
              <TouchableOpacity
                style={[styles.locationPickerSearchBtn, locationSearching && styles.locationPickerSearchBtnDisabled]}
                onPress={handleSearchLocation}
                disabled={locationSearching || !locationSearchQuery.trim()}
                activeOpacity={0.8}
              >
                {locationSearching ? <ActivityIndicator size="small" color="#0A1929" /> : <Ionicons name="search" size={20} color="#0A1929" />}
              </TouchableOpacity>
            </View>
            <TouchableOpacity style={styles.locationPickerCancel} onPress={() => setShowLocationPicker(false)} activeOpacity={0.8}>
              <Text style={styles.locationPickerCancelText}>Cancel</Text>
            </TouchableOpacity>
          </Pressable>
        </Pressable>
      </Modal>

      {/* Your job detail bottom sheet */}
      <Modal
        visible={!!selectedYourJob}
        transparent
        animationType="slide"
        onRequestClose={() => setSelectedYourJob(null)}
      >
        <View style={styles.yourJobSheetContainer}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setSelectedYourJob(null)}>
            <BlurView intensity={40} tint="dark" style={StyleSheet.absoluteFill} />
          </Pressable>
          <View style={[styles.yourJobSheet, { paddingBottom: Math.max(insets?.bottom ?? 0, 24) }]} pointerEvents="box-none">
            {selectedYourJob ? (
              <>
                <View style={styles.yourJobSheetHandle} />
                <View style={styles.yourJobSheetHeader}>
                  <Text style={styles.yourJobSheetTitle}>{getServiceDisplayName(selectedYourJob.service_type, selectedYourJob.service_name) || selectedYourJob.service_name || 'Job'}</Text>
                  <Text style={[styles.yourJobSheetSubtitle, { color: accent }]}>
                    {yourJobStatusSubtitle(selectedYourJob)}
                  </Text>
                </View>
                <View style={styles.yourJobSheetPhotoHero}>
                  {selectedYourJob.customer_photo ? (
                    <Image
                      source={{ uri: selectedYourJob.customer_photo }}
                      style={[styles.yourJobSheetPhotoHeroImg, { borderColor: `${accent}55` }]}
                      resizeMode="cover"
                    />
                  ) : (
                    <View
                      style={[
                        styles.yourJobSheetPhotoHeroImg,
                        styles.yourJobSheetPhotoHeroPlaceholder,
                        { borderColor: `${accent}40` },
                      ]}
                    >
                      <Ionicons name="person" size={40} color={accent} />
                    </View>
                  )}
                </View>
                <View style={styles.yourJobSheetCustomer}>
                  <View style={styles.yourJobSheetCustomerText}>
                    <Text style={styles.yourJobSheetCustomerLabel}>Customer</Text>
                    <Text style={styles.yourJobSheetCustomerName} numberOfLines={2}>
                      {selectedYourJob.customer_name || 'Customer'}
                    </Text>
                  </View>
                </View>
                <ScrollView style={styles.yourJobSheetScroll} showsVerticalScrollIndicator={false}>
                  {selectedYourJob.scheduled_at ? (
                    <View style={styles.yourJobSheetRow}>
                      <Ionicons name="calendar-outline" size={20} color={accent} />
                      <Text style={styles.yourJobSheetLabel}>Scheduled</Text>
                      <Text style={styles.yourJobSheetValue}>
                        {new Date(selectedYourJob.scheduled_at).toLocaleString('en-GB', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </Text>
                    </View>
                  ) : null}
                  {selectedYourJob.location_address ? (
                    <View style={styles.yourJobSheetRow}>
                      <Ionicons name="location-outline" size={20} color={accent} />
                      <Text style={styles.yourJobSheetLabel}>Address</Text>
                      <Text style={styles.yourJobSheetValue}>{selectedYourJob.location_address}</Text>
                    </View>
                  ) : null}
                  <View style={styles.yourJobSheetRow}>
                    <LocationStyleIconBox variant="inline" icon="wallet-outline" colors={accentToGradient(accent)} />
                    <Text style={styles.yourJobSheetLabel}>Price</Text>
                    <Text style={[styles.yourJobSheetValue, styles.yourJobSheetPrice, { color: accent }]}>
                      £{Number(selectedYourJob.price || 0).toFixed(2)}
                    </Text>
                  </View>
                </ScrollView>
                <View style={styles.yourJobSheetActions}>
                  <TouchableOpacity
                    style={[styles.yourJobSheetCloseBtn, { borderColor: `${accent}50` }]}
                    onPress={() => {
                      hapticFeedback('light');
                      setSelectedYourJob(null);
                    }}
                    activeOpacity={0.85}
                  >
                    <Text style={[styles.yourJobSheetCloseBtnText, { color: accent }]}>Close</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[styles.yourJobSheetViewBtn, { backgroundColor: accent }]}
                    onPress={() => {
                      hapticFeedback('light');
                      setSelectedYourJob(null);
                      router.push({ pathname: '/valeter/jobs/tracking', params: { jobId: selectedYourJob.id } } as any);
                    }}
                    activeOpacity={0.85}
                  >
                    <Ionicons name="navigate" size={18} color="#fff" />
                    <Text style={styles.yourJobSheetViewBtnText}>View trip</Text>
                  </TouchableOpacity>
                </View>
              </>
            ) : null}
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },
  mapSafe: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 2,
  },
  mapOnlinePillFloating: {
    position: 'absolute',
    zIndex: 12,
  },
  statusHeroFloating: {
    position: 'absolute',
    left: 0,
    right: 0,
    zIndex: 11,
    alignItems: 'center',
  },
  statusHeroPressable: {
    alignItems: 'center',
  },
  mapOnlinePillPressable: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 16,
    overflow: 'hidden',
    flex: 1,
  },
  mapBottomScrim: {
    ...StyleSheet.absoluteFillObject,
    top: '35%',
  },
  mapOfflineTint: {
    backgroundColor: 'rgba(10, 25, 41, 0.58)',
  },
  mapOnlinePill: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 16,
    backgroundColor: 'rgba(15,23,42,0.65)',
    borderWidth: 1,
    overflow: 'hidden',
  },
  mapOnlineDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  mapOnlineCopy: {
    flex: 1,
    minWidth: 0,
  },
  mapOnlineTitle: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '800',
  },
  mapOnlineSub: {
    color: 'rgba(249,250,251,0.62)',
    fontSize: 12,
    fontWeight: '600',
    marginTop: 2,
  },
  mapMarkerJob: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#fff',
  },

  /* Uber-style: minimal top bar */
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SCREEN_PADDING_H,
    paddingBottom: 12,
  },
  avatarWrap: { marginRight: 12 },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.1)',
  },
  topBarCenter: { flex: 1, minWidth: 0 },
  topBarTitle: {
    fontSize: 18,
    fontWeight: '700',
    letterSpacing: -0.3,
  },
  topBarLocationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 4,
    gap: 8,
    minHeight: 22,
  },
  locationPickerTouchable: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    minWidth: 0,
  },
  topBarSub: {
    fontSize: 13,
    marginTop: 2,
  },
  onlinePill: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    backgroundColor: 'rgba(107,114,128,0.35)',
    gap: 5,
  },
  onlinePillOn: {
    backgroundColor: 'rgba(16,185,129,0.35)',
  },
  onlinePillDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#9CA3AF',
  },
  onlinePillDotOn: {
    backgroundColor: '#10B981',
  },
  onlinePillText: {
    fontSize: 11,
    fontWeight: '700',
    color: 'rgba(249,250,251,0.7)',
  },
  onlinePillTextOn: {
    color: '#6EE7B7',
  },
  bellWrap: { padding: 4 },

  scrollView: { flex: 1 },
  scrollContent: {},
  headerProfilePicWrap: {
    width: 44,
    height: 44,
    borderRadius: 14,
    overflow: 'hidden',
  },
  headerProfilePic: {
    width: 44,
    height: 44,
    borderRadius: 14,
  },
  bookingButtonsSection: {
    flexDirection: 'column',
    gap: 12,
    marginBottom: 12,
  },

  techCommandStrip: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 4,
  },
  techHudCell: {
    flex: 1,
    minWidth: 0,
    paddingVertical: 10,
    paddingHorizontal: 10,
    borderRadius: 14,
    backgroundColor: 'rgba(15,23,42,0.72)',
    borderWidth: 1,
    borderColor: 'rgba(56,189,248,0.18)',
  },
  techHudCellLive: {
    borderColor: 'rgba(74,222,128,0.35)',
    backgroundColor: 'rgba(16,185,129,0.08)',
  },
  techHudCellAlert: {
    borderColor: 'rgba(251,191,36,0.45)',
    backgroundColor: 'rgba(245,158,11,0.08)',
  },
  techHudLabel: {
    color: 'rgba(148,163,184,0.9)',
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 1.4,
    marginBottom: 4,
  },
  techHudValueRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    position: 'relative',
  },
  techHudLiveRing: {
    position: 'absolute',
    left: 0,
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#4ADE80',
  },
  techHudLiveDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  techHudValue: {
    color: '#F8FAFC',
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  techHudValueMono: {
    fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace',
    fontSize: 14,
    letterSpacing: -0.3,
  },
  techSectionTagRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 2,
    marginBottom: -4,
  },
  techSectionTagDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#38BDF8',
  },
  techSectionTag: {
    color: 'rgba(56,189,248,0.95)',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.6,
  },
  techGridLine: {
    position: 'absolute',
    backgroundColor: 'rgba(56,189,248,0.35)',
  },
  techGridLineH: {
    left: 0,
    right: 0,
    height: StyleSheet.hairlineWidth,
  },
  techGridLineV: {
    top: 0,
    bottom: 0,
    width: StyleSheet.hairlineWidth,
  },
  techScanBeam: {
    position: 'absolute',
    left: 0,
    right: 0,
    height: 48,
    backgroundColor: 'rgba(56,189,248,0.07)',
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: 'rgba(56,189,248,0.22)',
  },
  techCorner: {
    position: 'absolute',
    width: 14,
    height: 14,
    zIndex: 3,
  },
  techCornerTL: {
    top: 8,
    left: 8,
    borderTopWidth: 2,
    borderLeftWidth: 2,
  },
  techCornerTR: {
    top: 8,
    right: 8,
    borderTopWidth: 2,
    borderRightWidth: 2,
  },
  techCornerBL: {
    bottom: 8,
    left: 8,
    borderBottomWidth: 2,
    borderLeftWidth: 2,
  },
  techCornerBR: {
    bottom: 8,
    right: 8,
    borderBottomWidth: 2,
    borderRightWidth: 2,
  },
  activeBookingSectionInset: {
    marginTop: 4,
    gap: 8,
  },
  yourHubSurfaceTech: {
    borderColor: 'rgba(56,189,248,0.16)',
    backgroundColor: 'rgba(15,23,42,0.55)',
  },

  valeterAvailabilityHeroCard: {
    borderRadius: 32,
    overflow: 'hidden',
    position: 'relative',
    borderWidth: 0,
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 14 },
    shadowOpacity: 0.26,
    shadowRadius: 32,
    elevation: 16,
  },
  valeterAvailabilityHeroGlassFallback: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(15,23,42,0.38)',
  },
  valeterAvailabilityHeroGlassRim: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 32,
    borderWidth: 1,
  },
  valeterAvailabilityHeroGlassTopGlow: {
    ...StyleSheet.absoluteFillObject,
    borderTopLeftRadius: 32,
    borderTopRightRadius: 32,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.32)',
  },
  valeterAvailabilityPulseRing: {
    position: 'absolute',
    top: 8,
    left: 8,
    right: 8,
    bottom: 8,
    borderRadius: 28,
    borderWidth: 2,
    borderColor: 'rgba(74,222,128,0.65)',
  },
  valeterAvailabilityHeroContent: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 18,
    paddingHorizontal: 20,
    gap: 14,
    zIndex: 1,
  },
  valeterAvailabilityMascotWrap: {
    width: 56,
    height: 56,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.35)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  valeterAvailabilityMascot: {
    width: 44,
    height: 44,
  },
  valeterAvailabilityDot: {
    position: 'absolute',
    bottom: 2,
    right: 2,
    width: 12,
    height: 12,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: 'rgba(15,23,42,0.9)',
  },
  valeterAvailabilityHeroTextWrap: {
    flex: 1,
    minWidth: 0,
    gap: 3,
  },
  valeterAvailabilityHeroTitle: {
    color: '#F8FAFC',
    fontSize: isSmallScreen ? 19 : 20,
    fontWeight: '800',
    letterSpacing: 0.15,
  },
  valeterAvailabilityHeroSubtitle: {
    color: 'rgba(255,255,255,0.72)',
    fontSize: 13,
    fontWeight: '600',
    lineHeight: 17,
  },
  valeterAvailabilityLocation: {
    color: 'rgba(255,255,255,0.5)',
    fontSize: 11,
    fontWeight: '600',
    marginTop: 2,
  },
  valeterAvailabilityHeroChevron: {
    width: 42,
    height: 42,
    alignItems: 'center',
    justifyContent: 'center',
  },
  jobsPreviewPressable: {
    width: '100%',
    marginTop: 0,
  },
  jobsPreviewTechFrame: {
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(56,189,248,0.14)',
    backgroundColor: 'rgba(15,23,42,0.35)',
    padding: 12,
  },
  jobsPreviewInline: {
    paddingHorizontal: 0,
    paddingTop: 0,
    paddingBottom: 0,
    backgroundColor: 'transparent',
  },
  jobsPreviewInlineHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 10,
    paddingHorizontal: 4,
    gap: 12,
  },
  jobsPreviewHeaderTextWrap: {
    flex: 1,
    minWidth: 0,
  },
  jobsPreviewEyebrow: {
    color: 'rgba(135,206,235,0.95)',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
    marginBottom: 2,
  },
  jobsPreviewTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  jobsPreviewSubtitle: {
    marginTop: 2,
    color: 'rgba(255,255,255,0.7)',
    fontSize: 13,
    lineHeight: 17,
  },
  jobsPreviewHeaderBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: 'rgba(135,206,235,0.14)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  jobsPreviewHeaderBadgeText: {
    color: '#F9FAFB',
    fontSize: 11,
    fontWeight: '800',
  },
  jobsPreviewMapShell: {
    height: 176,
    borderRadius: 18,
    overflow: 'hidden',
    backgroundColor: 'rgba(15,23,42,0.72)',
    marginBottom: 10,
    position: 'relative',
    borderWidth: 1,
    borderColor: 'rgba(56,189,248,0.14)',
  },
  jobsPreviewEmptyMap: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    backgroundColor: 'rgba(15,23,42,0.72)',
  },
  jobsPreviewEmptyText: {
    color: 'rgba(255,255,255,0.65)',
    fontSize: 13,
    fontWeight: '600',
  },
  jobsPreviewMapBadgeRow: {
    position: 'absolute',
    top: 10,
    left: 10,
    right: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 8,
  },
  jobsPreviewMapBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 8,
    paddingVertical: 5,
    borderRadius: 999,
    backgroundColor: 'rgba(10,25,41,0.72)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  jobsPreviewMapBadgeText: {
    color: '#F9FAFB',
    fontSize: 11,
    fontWeight: '700',
  },
  jobsPreviewMarkerYou: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#fff',
  },
  jobsPreviewMarkerJob: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: 'rgba(245,158,11,0.95)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#fff',
  },
  jobsPreviewMarkerActive: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: 'rgba(16,185,129,0.95)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#fff',
  },
  jobsPreviewFooter: {
    paddingHorizontal: 4,
    gap: 2,
  },
  jobsPreviewFooterText: {
    color: '#F9FAFB',
    fontSize: 13,
    fontWeight: '800',
  },
  jobsPreviewFooterHint: {
    color: 'rgba(255,255,255,0.55)',
    fontSize: 11,
    fontWeight: '600',
  },
  yourHubSection: {
    marginTop: 6,
    paddingTop: 4,
  },
  yourHubSurface: {
    padding: 14,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  yourHubHeader: {
    marginBottom: 12,
  },
  yourHubHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  yourHubHeaderTextWrap: {
    flex: 1,
    minWidth: 0,
  },
  yourHubTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '900',
    letterSpacing: -0.2,
    marginBottom: 2,
  },
  yourHubSubtitle: {
    color: 'rgba(255,255,255,0.62)',
    fontSize: 12,
    fontWeight: '600',
  },
  hubStatsStrip: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 14,
    paddingVertical: 12,
    paddingHorizontal: 8,
    borderRadius: 16,
    backgroundColor: 'rgba(15,23,42,0.45)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.06)',
  },
  hubStatCell: {
    flex: 1,
    alignItems: 'center',
    gap: 2,
  },
  hubStatValue: {
    color: '#F8FAFC',
    fontSize: 18,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  hubStatLabel: {
    color: 'rgba(255,255,255,0.55)',
    fontSize: 11,
    fontWeight: '600',
  },
  hubStatDivider: {
    width: 1,
    height: 28,
    backgroundColor: 'rgba(255,255,255,0.1)',
  },
  quickActionsRow: {
    marginTop: 4,
    flexDirection: 'row',
    width: '100%',
    gap: 12,
  },
  quickActionPressable: {
    flex: 1,
    minWidth: 0,
  },
  quickActionItem: {
    flex: 1,
    alignItems: 'center',
    gap: 8,
    minWidth: 0,
    opacity: 0.95,
  },
  quickActionIconBox: {
    width: 56,
    height: 56,
    borderRadius: 16,
  },
  quickActionItemLabel: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
  },

  heroCardWrap: { marginBottom: CARD_GAP },
  /* Below quick actions — new unified UI */
  belowQuickWrap: { marginBottom: 16 },
  dailyStatsWrap: { marginBottom: 14 },
  statusHeroWrap: {
    position: 'relative',
    alignItems: 'center',
    justifyContent: 'center',
  },
  statusHeroCopy: {
    alignItems: 'center',
    marginBottom: 14,
    paddingHorizontal: 20,
  },
  statusHeroCopyOnline: {},
  statusHeroCopyOffline: {},
  statusHeroTitle: {
    fontSize: 17,
    fontWeight: '800',
    letterSpacing: 0.3,
    textAlign: 'center',
  },
  statusHeroTitleOnline: {
    color: '#4ADE80',
  },
  statusHeroTitleOffline: {
    color: '#F87171',
  },
  statusHeroSubtitle: {
    color: 'rgba(226,232,240,0.72)',
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
  },
  statusSparkleLayer: {
    ...StyleSheet.absoluteFillObject,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'visible',
    zIndex: 4,
  },
  statusSparkle: {
    position: 'absolute',
    alignItems: 'center',
    justifyContent: 'center',
  },
  statusHeroButtonArea: {
    width: STATUS_HERO_BUTTON_SIZE + 36,
    height: STATUS_HERO_BUTTON_SIZE + 36,
    alignItems: 'center',
    justifyContent: 'center',
  },
  statusHeroPulseRing: {
    position: 'absolute',
    top: '50%',
    left: '50%',
    width: STATUS_HERO_BUTTON_SIZE,
    height: STATUS_HERO_BUTTON_SIZE,
    marginTop: -(STATUS_HERO_BUTTON_SIZE / 2),
    marginLeft: -(STATUS_HERO_BUTTON_SIZE / 2),
    borderRadius: STATUS_HERO_BUTTON_SIZE / 2,
    borderWidth: 2,
  },
  statusHeroPulseRingOnline: {
    borderColor: 'rgba(74,222,128,0.8)',
  },
  statusHeroPulseRingOnlineSoft: {
    borderWidth: 1.5,
    borderColor: 'rgba(34,197,94,0.42)',
  },
  statusHeroButton: {
    width: STATUS_HERO_BUTTON_SIZE,
    height: STATUS_HERO_BUTTON_SIZE,
    borderRadius: STATUS_HERO_BUTTON_SIZE / 2,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1.5,
    overflow: 'hidden',
    shadowOffset: { width: 0, height: 18 },
    shadowOpacity: 0.45,
    shadowRadius: 28,
    elevation: 14,
  },
  statusHeroButtonOnline: {
    backgroundColor: 'rgba(16,185,129,0.18)',
    borderColor: 'rgba(74,222,128,0.8)',
    shadowColor: '#10B981',
  },
  statusHeroButtonOffline: {
    backgroundColor: 'rgba(239,68,68,0.18)',
    borderColor: 'rgba(248,113,113,0.82)',
    shadowColor: '#EF4444',
  },
  statusHeroGlow: {
    position: 'absolute',
    top: '50%',
    left: '50%',
    width: 228,
    height: 228,
    marginTop: -114,
    marginLeft: -114,
    borderRadius: 114,
    opacity: 0.38,
  },
  statusHeroGlowOnline: {
    backgroundColor: 'rgba(34,197,94,0.18)',
  },
  statusHeroGlowOffline: {
    backgroundColor: 'rgba(239,68,68,0.16)',
  },
  statusHeroSheen: {
    position: 'absolute',
    top: '50%',
    left: '50%',
    width: 260,
    height: 260,
    marginTop: -130,
    marginLeft: -130,
    borderRadius: 130,
    alignItems: 'center',
    justifyContent: 'center',
  },
  statusHeroSheenBand: {
    width: 294,
    height: 36,
    borderRadius: 999,
    opacity: 0.45,
  },
  statusHeroBadge: {
    position: 'absolute',
    top: 18,
    alignSelf: 'center',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
    borderWidth: 1,
    zIndex: 2,
  },
  statusHeroBadgeOnline: {
    backgroundColor: 'rgba(34,197,94,0.18)',
    borderColor: 'rgba(134,239,172,0.55)',
  },
  statusHeroBadgeOffline: {
    backgroundColor: 'rgba(239,68,68,0.14)',
    borderColor: 'rgba(252,165,165,0.55)',
  },
  statusHeroBadgeDot: {
    width: 5,
    height: 5,
    borderRadius: 2.5,
  },
  statusHeroBadgeDotOn: { backgroundColor: '#86EFAC' },
  statusHeroBadgeDotOff: { backgroundColor: '#FCA5A5' },
  statusHeroBadgeText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 0.8,
  },
  statusHeroButtonInner: {
    width: 186,
    height: 186,
    borderRadius: 93,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(15,23,42,0.18)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
    shadowColor: '#000',
    shadowOpacity: 0.18,
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 10,
    elevation: 2,
  },
  statusHeroButtonInnerOnline: {},
  statusHeroButtonInnerOffline: {},
  statusHeroImageRing: {
    width: 178,
    height: 178,
    borderRadius: 89,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
  },
  statusHeroImageInner: {
    width: 170,
    height: 170,
    borderRadius: 85,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(9,14,25,0.22)',
    overflow: 'hidden',
  },
  statusHeroImageInnerOnline: {
    backgroundColor: 'rgba(9,14,25,0.18)',
  },
  statusHeroImageInnerOffline: {
    backgroundColor: 'rgba(9,14,25,0.26)',
  },
  statusHeroMascot: {
    width: 158,
    height: 158,
  },
  statusHeroLoadingOverlay: {
    position: 'absolute',
    inset: 0,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: 'rgba(15,23,42,0.22)',
  },
  statusHeroLoadingText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '700',
  },
  statusHeroActionPill: {
    marginTop: 4,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 18,
    paddingVertical: 10,
    borderRadius: 999,
    borderWidth: 1,
  },
  statusHeroActionPillOnline: {
    backgroundColor: 'rgba(34,197,94,0.08)',
    borderColor: 'rgba(34,197,94,0.26)',
  },
  statusHeroActionPillOffline: {
    backgroundColor: 'rgba(239,68,68,0.08)',
    borderColor: 'rgba(239,68,68,0.26)',
  },
  statusHeroActionDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  statusHeroActionDotOn: {
    backgroundColor: '#4ADE80',
  },
  statusHeroActionDotOff: {
    backgroundColor: '#F87171',
  },
  statusHeroActionText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '900',
    letterSpacing: 0.8,
  },
  statusHeroHelp: {
    color: 'rgba(226,232,240,0.68)',
    fontSize: 12,
    lineHeight: 16,
    textAlign: 'center',
    marginTop: 4,
  },
  dailyStatsCard: {
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.12,
    shadowRadius: 8,
    elevation: 3,
  },
  dailyStatsGlow: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 1.5,
    zIndex: 2,
    opacity: 0.6,
  },
  dailyStatsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    paddingVertical: 14,
    paddingHorizontal: 12,
    zIndex: 2,
  },
  dailyStatItemCombined: {
    flex: 1,
    alignItems: 'stretch',
    justifyContent: 'center',
    gap: 10,
    minWidth: 0,
  },
  dailyStatItem: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  dailyStatActionButton: {
    width: '100%',
    borderRadius: 14,
    paddingVertical: 10,
    paddingHorizontal: 12,
    marginTop: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  dailyStatActionWrap: {
    paddingHorizontal: 12,
    paddingBottom: 12,
    paddingTop: 8,
  },
  dailyStatActionIcon: {
    marginLeft: -2,
  },
  dailyStatActionTextBlock: {
    flex: 1,
    minWidth: 0,
  },
  dailyStatActionTitle: {
    color: '#F9FAFB',
    fontSize: 13,
    fontWeight: '800',
    marginBottom: 1,
  },
  dailyStatActionSubtitle: {
    color: 'rgba(249,250,251,0.62)',
    fontSize: 10,
    fontWeight: '600',
  },
  dailyStatIconWrap: {
    width: 42,
    height: 42,
    borderRadius: 14,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 6,
  },
  dailyStatValue: {
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 2,
  },
  dailyStatLabel: {
    fontSize: 11,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 0.3,
  },
  dailyStatDivider: {
    width: 1,
    height: 32,
    borderRadius: 1,
  },
  statusDot: { width: 8, height: 8, borderRadius: 4 },
  requestCardBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    gap: 6,
    marginBottom: 10,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 10,
    backgroundColor: 'rgba(239,68,68,0.2)',
  },
  requestCardBadgeDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#EF4444' },
  requestCardBadgeText: { color: '#FCA5A5', fontSize: 12, fontWeight: '700' },
  mapPreviewCard: {
    borderRadius: 22,
    overflow: 'hidden',
    borderWidth: 1.5,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.22,
    shadowRadius: 14,
    elevation: 5,
  },
  mapPreviewGlowLine: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 2,
    zIndex: 2,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 8,
    elevation: 2,
  },
  mapPreviewInner: { zIndex: 2 },
  mapPreviewHeader: {
    paddingHorizontal: 18,
    paddingTop: 16,
    paddingBottom: 12,
  },
  mapPreviewHeaderBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 12,
    borderWidth: 1,
  },
  mapPreviewTitle: { fontSize: 15, fontWeight: '800', letterSpacing: 0.3 },
  mapPreviewMapWrap: {
    height: 200,
    marginHorizontal: 14,
    marginBottom: 14,
    borderRadius: 14,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  mapPreviewMap: { width: '100%', height: '100%' },
  mapPreviewMapVignette: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    pointerEvents: 'none',
  },
  mapPreviewMarkerYou: {
    width: 34,
    height: 34,
    borderRadius: 17,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.35,
    shadowRadius: 4,
    elevation: 4,
  },
  mapPreviewMarkerJob: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: 'rgba(245,158,11,0.95)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2.5,
    borderColor: 'rgba(255,255,255,0.9)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 3,
    elevation: 3,
  },
  mapPreviewSummary: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 14,
    paddingHorizontal: 18,
    paddingTop: 14,
    paddingBottom: 16,
    borderTopWidth: 1,
  },
  mapPreviewSummaryText: {
    color: 'rgba(249,250,251,0.9)',
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  mapPreviewSummaryAccent: {
    fontWeight: '800',
  },
  yourJobsSection: { marginTop: SECTION_GAP - 8, marginBottom: 28 },
  yourJobsScrollContent: {
    paddingRight: SCREEN_PADDING_H,
    gap: 8,
    paddingVertical: 4,
    lineHeight: 14,
  },
  jobCardHoriz: {
    width: 136,
    paddingVertical: 10,
    paddingHorizontal: 10,
    borderTopLeftRadius: 18,
    borderTopRightRadius: 8,
    borderBottomRightRadius: 18,
    borderBottomLeftRadius: 8,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1.5,
    overflow: 'visible',
    position: 'relative',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 3,
  },
  jobCardHorizTouch: {
    width: '100%',
  },
  jobCardHorizTopRow: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    minHeight: 18,
    marginBottom: 4,
  },
  jobCardHorizDismiss: {
    paddingTop: 2,
    paddingRight: 2,
    paddingBottom: 0,
    paddingLeft: 0,
    zIndex: 6,
  },
  jobCardHorizCustomerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 6,
    minWidth: 0,
  },
  jobCardHorizAvatar: {
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  jobCardHorizAvatarPlaceholder: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  jobCardHorizCustomerName: {
    flex: 1,
    color: 'rgba(249,250,251,0.92)',
    fontSize: 11,
    fontWeight: '700',
    minWidth: 0,
  },
  jobCardHorizTitle: { color: '#F9FAFB', fontSize: 13, fontWeight: '700', marginBottom: 2 },
  jobCardHorizSub: { color: 'rgba(249,250,251,0.65)', fontSize: 11, marginBottom: 4 },
  jobCardHorizPrice: { color: SKY, fontSize: 14, fontWeight: '800' },
  jobRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 14,
    marginBottom: 8,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 14,
    gap: 12,
  },
  jobRowIcon: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  jobRowIconDone: { backgroundColor: 'rgba(16,185,129,0.2)' },
  jobRowBody: { flex: 1, minWidth: 0 },
  jobRowTitle: { color: '#F9FAFB', fontSize: 15, fontWeight: '600', marginBottom: 2 },
  jobRowSub: { color: 'rgba(249,250,251,0.6)', fontSize: 13 },
  jobRowPrice: { color: '#F9FAFB', fontSize: 15, fontWeight: '700' },
  /* Hero: one primary CTA */
  heroCard: {},
  heroInner: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 0,
    gap: 14,
  },
  heroInnerOnline: {
    backgroundColor: '#059669',
  },
  heroInnerOffline: {
    backgroundColor: '#374151',
  },
  heroDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  heroTextBlock: { flex: 1, minWidth: 0 },
  heroTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 2,
  },
  heroSub: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 14,
    fontWeight: '500',
  },

  /* Single job request card — premium floating style */
  requestCard: {
    marginBottom: CARD_GAP,
    padding: 18,
    borderRadius: 22,
    backgroundColor: 'rgba(59,130,246,0.18)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 20,
    elevation: 6,
  },
  requestCardWithMap: {
    overflow: 'hidden',
    position: 'relative',
    padding: 0,
  },
  requestCardMap: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
  },
  requestCardMapMarkerYou: {
    width: 24,
    height: 24,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#fff',
  },
  requestCardMapMarkerJob: {
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: 'rgba(245,158,11,0.95)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.9)',
  },
  requestCardContent: {
    padding: 18,
    zIndex: 2,
  },
  requestHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  requestTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flex: 1,
    minWidth: 0,
  },
  requestTitle: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '700',
  },
  requestTimer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    backgroundColor: 'rgba(239,68,68,0.8)',
  },
  requestTimerText: { color: '#fff', fontSize: 12, fontWeight: '700' },
  requestHighValueBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 8,
    backgroundColor: 'rgba(251,191,36,0.25)',
    borderWidth: 1,
    borderColor: 'rgba(251,191,36,0.5)',
  },
  requestHighValueText: { color: '#FBBF24', fontSize: 11, fontWeight: '700' },
  requestCustomer: {
    color: 'rgba(249,250,251,0.9)',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
  },
  requestAddress: {
    color: 'rgba(249,250,251,0.75)',
    fontSize: 13,
    marginBottom: 12,
    lineHeight: 18,
  },
  requestMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 14,
  },
  requestPrice: {
    color: '#FCD34D',
    fontSize: 18,
    fontWeight: '800',
  },
  requestDistance: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
    fontWeight: '600',
  },
  requestMore: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 13,
    fontWeight: '600',
  },
  requestActions: {
    flexDirection: 'row',
    gap: 10,
  },
  acceptBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    borderRadius: 12,
    backgroundColor: '#10B981',
  },
  acceptBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  declineBtn: {
    paddingVertical: 14,
    paddingHorizontal: 20,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.5)',
    justifyContent: 'center',
  },
  declineBtnText: { color: '#EF4444', fontSize: 15, fontWeight: '700' },

  /* Section + list */
  section: { marginBottom: 28 },
  sectionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '700',
  },
  seeAll: { fontSize: 14, fontWeight: '600' },
  listRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 14,
    marginBottom: 6,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 12,
    gap: 12,
  },
  listRowIcon: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  listRowIconDone: { backgroundColor: 'rgba(16,185,129,0.2)' },
  listRowBody: { flex: 1, minWidth: 0 },
  listRowTitle: { color: '#F9FAFB', fontSize: 15, fontWeight: '600', marginBottom: 2 },
  listRowSub: { color: 'rgba(249,250,251,0.6)', fontSize: 13 },
  listRowPrice: { color: '#F9FAFB', fontSize: 15, fontWeight: '700' },
  emptyBlock: {
    alignItems: 'center',
    paddingVertical: 24,
    paddingHorizontal: 20,
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderRadius: 12,
    gap: 8,
  },
  emptyText: { color: 'rgba(249,250,251,0.6)', fontSize: 14 },
  emptyLink: { fontSize: 14, fontWeight: '700' },

  /* Quick links row */
  quickRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8,
    marginBottom: 16,
  },
  quickItem: {
    alignItems: 'center',
    minWidth: 72,
  },
  quickIconWrap: {
    width: 48,
    height: 48,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  quickLabel: {
    color: 'rgba(249,250,251,0.85)',
    fontSize: 12,
    fontWeight: '600',
  },

  /* Legacy book-wash card styles (unused on valeter dashboard) */
  bookWashGlassFallback: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(14,165,233,0.35)',
  },
  bookWashCard: {
    borderRadius: 22,
    overflow: 'hidden',
    marginBottom: 14,
    position: 'relative',
    borderWidth: StyleSheet.hairlineWidth * 2,
    borderColor: 'rgba(255,255,255,0.16)',
  },
  bookWashCardContent: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 18,
    gap: 14,
  },
  bookWashCardIconWrap: {},
  bookWashCardTextWrap: { flex: 1, minWidth: 0 },
  bookWashCardTitle: {
    color: '#F8FAFC',
    fontSize: 17,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  bookWashCardSubtitle: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 12,
    fontWeight: '500',
    marginTop: 2,
  },
  bookWashCardChevron: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.04)',
  },
  valeterJobsGlassInner: {
    paddingTop: 12,
    paddingBottom: 14,
    paddingHorizontal: 12,
  },
  valeterQuickActionsGlassInner: {
    paddingTop: 14,
    paddingBottom: 14,
    paddingHorizontal: 12,
  },
  quickActionGlassFallback: {
    backgroundColor: 'rgba(15,23,42,0.4)',
  },
  quickActionsHeader: {
    marginBottom: 10,
  },
  quickActionsTitle: {
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '800',
    letterSpacing: 0.15,
  },
  quickActionsSubtitle: {
    color: 'rgba(226,232,240,0.72)',
    fontSize: 11,
    fontWeight: '500',
    marginTop: 3,
  },
  quickActionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    rowGap: 10,
  },
  quickActionGridItem: {
    width: '48%',
  },
  quickActionGridItemFull: {
    width: '100%',
  },
  quickActionGridButton: {
    flexDirection: 'column',
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    gap: 10,
    width: '100%',
    minHeight: 98,
    paddingVertical: 14,
    paddingHorizontal: 12,
    borderRadius: 20,
    backgroundColor: 'transparent',
    borderWidth: 1.5,
    overflow: 'hidden',
    position: 'relative',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 3,
  },
  quickActionGridIcon: {
    marginBottom: 12,
  },
  quickActionGridLabel: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 0.14,
    textAlign: 'left',
    paddingHorizontal: 0,
    flexShrink: 1,
    minWidth: 0,
    lineHeight: 18,
  },

  /* Active Job — same as customer ActiveBookingSection */
  activeBookingSection: {
    marginHorizontal: 20,
    marginBottom: 22,
  },
  activeBookingLoadingWrap: {
    borderRadius: 22,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    backgroundColor: 'rgba(255,255,255,0.03)',
    padding: 0,
    minHeight: 220,
    alignItems: 'stretch',
  },
  activeBookingCard: {
    borderRadius: 22,
    overflow: 'hidden',
    backgroundColor: 'rgba(10,25,41,0.65)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.22)',
    shadowColor: '#0A1929',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 16,
    elevation: 8,
  },
  activeBookingCardGlow: {
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.12,
    shadowRadius: 14,
  },
  activeBookingMapContainer: {
    height: 208,
    borderRadius: 0,
    overflow: 'hidden',
    position: 'relative',
  },
  activeBookingCardOverlayWrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    overflow: 'hidden',
  },
  activeBookingCardOverlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingBottom: 58,
    gap: 16,
  },
  activeBookingRingWrap: {
    width: 80,
    height: 80,
    alignItems: 'center',
    justifyContent: 'center',
  },
  activeBookingCardContent: { flex: 1, minWidth: 0 },
  activeBookingLiveChip: {
    alignSelf: 'flex-start',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 9,
    paddingVertical: 4,
    borderRadius: 8,
    marginBottom: 6,
    backgroundColor: 'rgba(16,185,129,0.28)',
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.45)',
  },
  activeBookingLiveDot: {
    width: 5,
    height: 5,
    borderRadius: 3,
    backgroundColor: '#10B981',
  },
  activeBookingLiveText: {
    color: 'rgba(255,255,255,0.98)',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 0.8,
  },
  activeBookingTitle: {
    color: 'rgba(255,255,255,0.98)',
    fontSize: 17,
    fontWeight: '800',
    letterSpacing: 0.35,
    marginBottom: 2,
  },
  activeBookingSubtitle: {
    color: 'rgba(255,255,255,0.88)',
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 0.1,
  },
  activeBookingValeter: {
    color: 'rgba(255,255,255,0.72)',
    fontSize: 12,
    fontWeight: '600',
    marginTop: 5,
    letterSpacing: 0.05,
  },
  activeBookingStatusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 13,
    paddingVertical: 8,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.98)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.4)',
    marginTop: 8,
  },
  activeBookingStatusText: {
    color: '#0A1929',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  activeBookingBottomRow: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 18,
    paddingVertical: 14,
    paddingBottom: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.06)',
    overflow: 'hidden',
  },
  activeBookingBottomRowInner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
  },
  activeBookingPriceWrap: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  activeBookingPrice: {
    color: 'rgba(255,255,255,0.95)',
    fontSize: 15,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  activeBookingCta: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  activeBookingMetaCta: {
    color: SKY,
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.15,
  },
  mapMarkerContainer: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  locationPickerOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  locationPickerSheet: {
    backgroundColor: '#0A1929',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingHorizontal: 20,
    paddingTop: 12,
    paddingBottom: 34,
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  locationPickerHandle: {
    width: 36,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(249,250,251,0.3)',
    alignSelf: 'center',
    marginBottom: 20,
  },
  locationPickerTitle: { fontSize: 20, fontWeight: '800', color: '#F9FAFB', marginBottom: 4 },
  locationPickerSubtitle: { fontSize: 13, color: 'rgba(249,250,251,0.6)', marginBottom: 20 },
  locationPickerOption: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    marginBottom: 16,
  },
  locationPickerOptionIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 14,
  },
  locationPickerOptionText: { flex: 1, minWidth: 0 },
  locationPickerOptionTitle: { fontSize: 16, fontWeight: '700', color: '#F9FAFB', marginBottom: 2 },
  locationPickerOptionSub: { fontSize: 12, color: 'rgba(249,250,251,0.6)' },
  locationPickerDivider: { height: 1, backgroundColor: 'rgba(255,255,255,0.08)', marginVertical: 16 },
  locationPickerSearchLabel: { fontSize: 14, fontWeight: '600', color: 'rgba(249,250,251,0.8)', marginBottom: 10 },
  locationPickerSearchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 20,
  },
  locationPickerSearchInput: {
    flex: 1,
    height: 48,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    paddingHorizontal: 16,
    fontSize: 16,
    color: '#F9FAFB',
  },
  locationPickerSearchBtn: {
    width: 48,
    height: 48,
    borderRadius: 14,
    backgroundColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
  },
  locationPickerSearchBtnDisabled: { opacity: 0.6 },
  locationPickerCancel: {
    paddingVertical: 14,
    alignItems: 'center',
  },
  locationPickerCancelText: { fontSize: 16, fontWeight: '600', color: SKY },

  yourJobSheetContainer: { flex: 1, justifyContent: 'flex-end' },
  yourJobSheet: {
    backgroundColor: '#0F2847',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingHorizontal: 24,
    paddingTop: 12,
    maxHeight: '85%',
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  yourJobSheetHandle: {
    width: 40,
    height: 5,
    backgroundColor: 'rgba(255,255,255,0.25)',
    borderRadius: 3,
    alignSelf: 'center',
    marginBottom: 20,
  },
  yourJobSheetHeader: { marginBottom: 12 },
  yourJobSheetPhotoHero: { alignItems: 'center', marginBottom: 14 },
  yourJobSheetPhotoHeroImg: {
    width: 96,
    height: 96,
    borderRadius: 48,
    borderWidth: 2,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  yourJobSheetPhotoHeroPlaceholder: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  yourJobSheetTitle: { color: '#F9FAFB', fontSize: 20, fontWeight: '800', marginBottom: 4 },
  yourJobSheetSubtitle: { fontSize: 14, fontWeight: '600' },
  yourJobSheetCustomer: {
    marginBottom: 18,
    paddingVertical: 12,
    paddingHorizontal: 14,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 16,
  },
  yourJobSheetCustomerText: { flex: 1, minWidth: 0 },
  yourJobSheetCustomerLabel: { color: '#94A3B8', fontSize: 12, fontWeight: '600', marginBottom: 4 },
  yourJobSheetCustomerName: { color: '#F9FAFB', fontSize: 17, fontWeight: '700' },
  yourJobSheetScroll: { maxHeight: 280, marginBottom: 16 },
  yourJobSheetRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 14,
  },
  yourJobSheetLabel: { color: '#94A3B8', fontSize: 14, fontWeight: '600', minWidth: 90 },
  yourJobSheetValue: { flex: 1, color: '#F9FAFB', fontSize: 15, fontWeight: '600' },
  yourJobSheetPrice: { fontSize: 18, fontWeight: '800' },
  yourJobSheetActions: { flexDirection: 'row', gap: 12 },
  yourJobSheetCloseBtn: {
    flex: 1,
    paddingVertical: 16,
    borderRadius: 14,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  yourJobSheetCloseBtnText: { fontSize: 16, fontWeight: '700' },
  yourJobSheetViewBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    borderRadius: 14,
  },
  yourJobSheetViewBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});
