import React from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import ReanimatedSwipeable from 'react-native-gesture-handler/ReanimatedSwipeable';
import type { IconGlyphName } from './iconGlyphTypes';
import GradientIconBox, { LocationStyleIconBox } from './GradientIconBox';
import { accentToGradient } from '../../utils/accentGradient';
import { hapticFeedback } from '../../services/HapticFeedbackService';

export type NotificationInboxGlyph = IconGlyphName;

export type NotificationInboxRowProps = {
  title: string;
  message: string;
  timeLine: string;
  icon: NotificationInboxGlyph;
  accentColor: string;
  onPress?: () => void;
  onDismiss?: () => void;
  showChevron?: boolean;
  chevronAccentColor?: string;
  dismissMode?: 'icon' | 'swipe';
  /** Renders an urgent strip (business high-priority items). */
  priorityUrgent?: boolean;
  priorityColor?: string;
  /** Muted, non-interactive row (e.g. completed jobs). */
  disabled?: boolean;
};

/**
 * Shared notification list row — frosted chrome lead icon, time row, optional chevron & dismiss.
 * Used by valeter and business full inbox + business header dropdown.
 */
export function NotificationInboxRow({
  title,
  message,
  timeLine,
  icon,
  accentColor,
  onPress,
  onDismiss,
  showChevron = false,
  chevronAccentColor,
  dismissMode = 'icon',
  priorityUrgent = false,
  priorityColor = '#EF4444',
  disabled = false,
}: Readonly<NotificationInboxRowProps>) {
  const chevron = chevronAccentColor ?? accentColor;
  const safeTitle = (title || '').trim() || 'Notification';
  const safeMessage = (message || '').trim() || 'Tap to view details';
  const safeTimeLine = (timeLine || '').trim() || 'Just now';
  const canPress = Boolean(onPress) && !disabled;

  const renderCard = () => (
    <Pressable
      onPress={canPress ? onPress : undefined}
      disabled={!canPress}
      style={({ pressed }) => [
        styles.card,
        disabled && styles.cardDisabled,
        pressed && canPress && styles.cardPressed,
      ]}
    >
      <GradientIconBox
        icon={icon}
        colors={accentToGradient(disabled ? '#64748B' : accentColor)}
        boxSize={42}
        size={21}
      />
      <View style={styles.cardBody}>
        <Text style={[styles.cardTitle, disabled && styles.cardTitleDisabled]} numberOfLines={2}>
          {safeTitle}
        </Text>
        <Text style={[styles.cardMessage, disabled && styles.cardMessageDisabled]} numberOfLines={2}>
          {safeMessage}
        </Text>
        <View style={styles.cardTimeRow}>
          <LocationStyleIconBox variant="micro" icon="time-outline" preset="gray" />
          <Text style={[styles.cardTime, disabled && styles.cardTimeDisabled]}>{safeTimeLine}</Text>
        </View>
        {priorityUrgent ? (
          <View style={[styles.priorityBadge, { borderColor: `${priorityColor}45` }]}>
            <View style={[styles.priorityDot, { backgroundColor: priorityColor }]} />
            <Text style={[styles.priorityText, { color: priorityColor }]}>Urgent</Text>
          </View>
        ) : null}
      </View>
      {showChevron && canPress ? (
        <View style={styles.chevronWrap}>
          <LocationStyleIconBox variant="inline" icon="chevron-forward" colors={accentToGradient(chevron)} />
        </View>
      ) : null}
    </Pressable>
  );

  return (
    <View style={styles.notificationRow}>
      {onDismiss && dismissMode === 'swipe' ? (
        <ReanimatedSwipeable
          containerStyle={styles.swipeableContainer}
          overshootRight={false}
          renderRightActions={() => (
            <View style={styles.swipeActionWrap}>
              <Pressable
                style={({ pressed }) => [
                  styles.swipeAction,
                  { backgroundColor: 'rgba(239,68,68,0.18)' },
                  pressed && styles.swipeActionPressed,
                ]}
                onPress={async () => {
                  await hapticFeedback('light');
                  onDismiss();
                }}
                accessibilityLabel="Dismiss notification"
              >
                <Text style={styles.swipeActionText}>Delete</Text>
              </Pressable>
            </View>
          )}
        >
          {renderCard()}
        </ReanimatedSwipeable>
      ) : (
        renderCard()
      )}
      {onDismiss && dismissMode !== 'swipe' ? (
        <Pressable
          style={({ pressed }) => [styles.dismissButton, pressed && styles.dismissPressed]}
          onPress={async () => {
            await hapticFeedback('light');
            onDismiss();
          }}
          hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
          accessibilityLabel="Dismiss notification"
        >
          <LocationStyleIconBox variant="inline" icon="close-circle-outline" preset="red" />
        </Pressable>
      ) : null}
    </View>
  );
}

/** Map business feed types to glyph + accent (hex) for {@link NotificationInboxRow}. */
export function businessNotificationIconAccent(
  type: 'booking' | 'booking_update' | 'team_request' | 'team_update',
  themePrimary: string
): { icon: NotificationInboxGlyph; accent: string } {
  switch (type) {
    case 'booking':
      return { icon: 'calendar-outline', accent: themePrimary };
    case 'booking_update':
      return { icon: 'sync-outline', accent: '#3B82F6' };
    case 'team_request':
      return { icon: 'person-add-outline', accent: '#10B981' };
    case 'team_update':
      return { icon: 'people-outline', accent: '#8B5CF6' };
    default:
      return { icon: 'notifications-outline', accent: themePrimary };
  }
}

const styles = StyleSheet.create({
  notificationRow: {
    flexDirection: 'row',
    alignItems: 'stretch',
    gap: 6,
  },
  swipeableContainer: {
    flex: 1,
    minWidth: 0,
  },
  card: {
    flex: 1,
    minWidth: 0,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 16,
    padding: 14,
    paddingRight: 10,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  cardPressed: {
    opacity: 0.92,
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  cardDisabled: {
    opacity: 0.42,
    backgroundColor: 'rgba(255,255,255,0.03)',
    borderColor: 'rgba(255,255,255,0.05)',
  },
  cardBody: {
    flex: 1,
    minWidth: 0,
    marginLeft: 14,
    gap: 4,
  },
  cardTitle: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
    lineHeight: 20,
  },
  cardTitleDisabled: {
    color: 'rgba(249,250,251,0.45)',
  },
  cardMessage: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '500',
  },
  cardMessageDisabled: {
    color: 'rgba(249,250,251,0.35)',
  },
  cardTimeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 6,
  },
  cardTime: {
    color: 'rgba(249,250,251,0.5)',
    fontSize: 12,
    fontWeight: '500',
  },
  cardTimeDisabled: {
    color: 'rgba(249,250,251,0.28)',
  },
  chevronWrap: {
    marginLeft: 6,
    justifyContent: 'center',
  },
  dismissButton: {
    width: 44,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 8,
  },
  dismissPressed: {
    opacity: 0.75,
  },
  swipeActionWrap: {
    marginLeft: 8,
  },
  swipeAction: {
    width: 98,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
  },
  swipeActionPressed: {
    opacity: 0.85,
  },
  swipeActionText: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.4,
  },
  priorityBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 8,
    borderWidth: 1,
    marginTop: 8,
    backgroundColor: 'rgba(239,68,68,0.08)',
  },
  priorityDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  priorityText: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.5,
    textTransform: 'uppercase' as const,
  },
});
