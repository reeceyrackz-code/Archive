import {
  isValeterRoutePath,
} from './authRole';

/** Map home — bottom tabs hidden; sidebar menu used instead. */
export function isValeterDashboardRoute(pathname: string): boolean {
  const p = pathname.replace(/\/$/, '');
  return p === '/valeter/valeter-dashboard' || p.endsWith('/valeter/valeter-dashboard');
}

/** Valeter screens with an inline map-home control in their own header chrome. */
export function isValeterInlineMapHomeRoute(pathname: string): boolean {
  const p = pathname.replace(/\/$/, '');
  return (
    p === '/valeter/jobs' ||
    p === '/valeter/inbox' ||
    p === '/valeter/notifications' ||
    p === '/valeter/profile/valeter-profile'
  );
}

/** Full-screen flows — no floating menu (tracking, trip, accept, chat). */
export function isValeterImmersiveRoute(pathname = ''): boolean {
  const p = pathname;
  return (
    p.includes('/jobs/tracking') ||
    p.includes('/valeter/trips') ||
    p.includes('/jobs/accept') ||
    p.includes('/jobs/complete') ||
    (p.includes('/valeter/') && p.includes('/chat'))
  );
}

/** Valeter sub-pages that use map-home instead of a back chevron (floating or inline). */
export function hasValeterMapHomeNavigation(pathname: string): boolean {
  if (!isValeterRoutePath(pathname)) return false;
  if (isValeterDashboardRoute(pathname)) return false;
  if (isValeterImmersiveRoute(pathname)) return false;
  return true;
}
