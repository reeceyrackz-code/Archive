import { supabase } from '../lib/supabase';

export interface CustomerProfileRow {
  id: string;
  full_name?: string | null;
  name?: string | null;
  email?: string | null;
  phone?: string | null;
  profile_picture?: string | null;
  avatar_url?: string | null;
  logo?: string | null;
}

/** Postgres undefined_column (42703) or PostgREST schema-cache miss for a column. */
export function isMissingDbColumnError(error: { code?: string; message?: string } | null | undefined): boolean {
  if (!error) return false;
  if (error.code === '42703') return true;
  const msg = (error.message ?? '').toLowerCase();
  return msg.includes('does not exist') || msg.includes('schema cache');
}

/**
 * Normalize avatar URLs for `Image`. Strips simple cache-bust queries on plain HTTPS URLs.
 * Preserves query strings for Supabase signed URLs (`token=`, `/object/sign/`) — stripping breaks loading.
 */
function cleanUrl(u?: string | null): string | null {
  if (!u) return null;
  const s = String(u).trim();
  if (!s) return null;
  if (/^https?:\/\//i.test(s)) {
    const lower = s.toLowerCase();
    if (lower.includes('token=') || lower.includes('/object/sign/')) {
      return s;
    }
    const q = s.indexOf('?');
    if (q === -1) return s;
    return s.slice(0, q) || s;
  }
  return s;
}

/**
 * Customer app stores owner photos in `profiles.profile_picture`: either a full https URL
 * or a path in the `uploads` bucket (see Archive owner-profile `toPublicAvatarUrl`).
 */
export function resolveCustomerProfilePictureUrl(value?: string | null): string | null {
  const raw = String(value || '').trim();
  if (!raw) return null;
  if (/^https?:\/\//i.test(raw)) {
    return cleanUrl(raw);
  }
  const path = raw.replace(/^\/+/, '');
  if (!path) return null;
  const { data } = supabase.storage.from('uploads').getPublicUrl(path);
  return cleanUrl(data?.publicUrl ?? null);
}

/** Prefer customer primary field order, then fallbacks (some rows only have logo). */
export function resolveCustomerAvatarFromProfileRow(p: {
  profile_picture?: string | null;
  avatar_url?: string | null;
  logo?: string | null;
} | null | undefined): string | null {
  if (!p) return null;
  for (const raw of [p.profile_picture, p.avatar_url, p.logo]) {
    const u = resolveCustomerProfilePictureUrl(raw);
    if (u) return u;
  }
  return null;
}

/**
 * Same as {@link resolveCustomerAvatarFromProfileRow} but uses a short-lived signed URL for
 * storage paths when the `uploads` bucket is private (public `getPublicUrl` 403s in Image).
 */
export async function resolveCustomerAvatarFromProfileRowAsync(p: {
  profile_picture?: string | null;
  avatar_url?: string | null;
  logo?: string | null;
} | null | undefined): Promise<string | null> {
  if (!p) return null;
  for (const raw of [p.profile_picture, p.avatar_url, p.logo]) {
    if (!raw?.trim()) continue;
    const t = raw.trim();
    if (/^https?:\/\//i.test(t)) {
      return cleanUrl(t);
    }
    const path = t.replace(/^\/+/, '');
    if (!path) continue;
    try {
      const { data, error } = await supabase.storage.from('uploads').createSignedUrl(path, 3600);
      if (!error && data?.signedUrl) {
        return cleanUrl(data.signedUrl);
      }
    } catch {
      // bucket missing or no permission — fall through
    }
  }
  return resolveCustomerAvatarFromProfileRow(p);
}

/**
 * Avatar URLs for booking lists / dashboards: public `uploads` URLs via {@link resolveCustomerProfilePictureUrl}
 * (storage path → `getPublicUrl`). Same behavior as single-row {@link resolveCustomerAvatarFromProfileRow}.
 */
export function resolveCustomerAvatarsForUserIds(
  ids: string[],
  profileMap: Map<string, CustomerProfileRow>
): Map<string, string | null> {
  const out = new Map<string, string | null>();
  for (const id of ids) {
    out.set(id, resolveCustomerAvatarFromProfileRow(profileMap.get(id)));
  }
  return out;
}

export async function fetchProfilesByIds(ids: string[]): Promise<Map<string, CustomerProfileRow>> {
  if (!ids.length) {
    return new Map();
  }

  try {
    const fullRes = await supabase
      .from('profiles')
      .select('id, full_name, name, email, phone, profile_picture, logo')
      .in('id', ids);

    const res =
      fullRes.error && isMissingDbColumnError(fullRes.error)
        ? await supabase
            .from('profiles')
            .select('id, full_name, name, email, phone, profile_picture, avatar_url')
            .in('id', ids)
        : fullRes;

    const { data, error } = res;

    if (error || !data) {
      if (error && !isMissingDbColumnError(error)) {
        console.warn('[customerProfiles] fetchProfilesByIds error:', error);
      }
      return new Map();
    }

    const map = new Map<string, CustomerProfileRow>();
    data.forEach((profile) => {
      if (profile?.id) {
        map.set(profile.id, profile as CustomerProfileRow);
      }
    });
    return map;
  } catch (err) {
    console.warn('[customerProfiles] fetchProfilesByIds exception:', err);
    return new Map();
  }
}

export async function fetchProfileById(id?: string | null): Promise<CustomerProfileRow | null> {
  if (!id) return null;
  const map = await fetchProfilesByIds([id]);
  return map.get(id) ?? null;
}
