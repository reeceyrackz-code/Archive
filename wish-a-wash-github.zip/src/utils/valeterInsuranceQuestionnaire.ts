import { Alert } from 'react-native';

export const VALETER_INSURANCE_ALERT_TITLE = 'Insurance required';

export const VALETER_INSURANCE_ALERT_MESSAGE =
  'Business insurance is needed before you can join the platform. This safety measure protects you and the customers seeking your services.';

export function valeterInsuranceDetailsComplete(
  hasBusinessInsurance: 'yes' | 'no' | null,
  insuranceProvider: string,
  insuranceType: string,
  policyNumber: string
): boolean {
  if (hasBusinessInsurance !== 'yes') return false;
  return (
    insuranceProvider.trim().length > 0 &&
    insuranceType.trim().length > 0 &&
    policyNumber.trim().length > 0
  );
}

export function showValeterInsuranceRequiredAlert(): void {
  Alert.alert(VALETER_INSURANCE_ALERT_TITLE, VALETER_INSURANCE_ALERT_MESSAGE);
}
