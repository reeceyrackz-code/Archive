import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system/legacy';
import { Buffer } from 'buffer';
import { Alert } from 'react-native';
import { supabase } from '../lib/supabase';

const BUCKET = 'uploads';
const MEDIA_FOLDER = 'booking_messages';

type BookingMessageInsert = {
  booking_id: string;
  sender_id: string;
  sender_role: string;
  message_type: 'image';
  content: string;
  media_url: string;
};

type BookingMessageRow = {
  id: string;
  booking_id: string;
  sender_id: string;
  sender_role: string;
  message_type: string;
  content: string | null;
  media_url: string | null;
  voice_duration_seconds: number | null;
  created_at: string;
};

function resolveMediaTypes(): any {
  const anyPicker: any = ImagePicker as any;
  if (anyPicker?.MediaTypeOptions?.Images) return anyPicker.MediaTypeOptions.Images;
  return ['images'] as any;
}

async function uriToArrayBuffer(localUri: string): Promise<ArrayBuffer> {
  let uri = localUri;

  if (uri.startsWith('content://')) {
    const cacheDir = FileSystem.cacheDirectory ?? FileSystem.documentDirectory ?? '';
    if (!cacheDir) throw new Error('No cache/document directory available on this device');
    const dest = `${cacheDir}booking_${Date.now()}.jpg`;
    await FileSystem.copyAsync({ from: uri, to: dest });
    uri = dest;
  }

  if (uri.startsWith('ph://')) {
    throw new Error('Unsupported photo URI (ph://).');
  }

  const info = await FileSystem.getInfoAsync(uri);
  if (!info.exists) {
    throw new Error(`Photo file does not exist: ${uri}`);
  }

  const base64 = await FileSystem.readAsStringAsync(uri, { encoding: 'base64' as any });
  const buf = Buffer.from(base64, 'base64');
  return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
}

async function uploadBookingMedia(localUri: string, bookingId: string, senderId: string): Promise<string> {
  const bytes = await uriToArrayBuffer(localUri);
  const storagePath = `${MEDIA_FOLDER}/${bookingId}/${senderId}_${Date.now()}.jpg`;
  const { data, error } = await supabase.storage.from(BUCKET).upload(storagePath, bytes, {
    contentType: 'image/jpeg',
    upsert: false,
  });
  if (error) throw error;

  const { data: pub } = supabase.storage.from(BUCKET).getPublicUrl(data?.path ?? storagePath);
  const publicUrl = pub?.publicUrl ?? null;
  if (!publicUrl) throw new Error('Failed to generate a public URL for the photo.');
  return publicUrl;
}

export async function captureBookingPhoto(): Promise<{ uri: string } | null> {
  const perm = await ImagePicker.requestCameraPermissionsAsync();
  if (!perm.granted) {
    throw new Error('Camera permission is required to take a photo.');
  }

  const result = await ImagePicker.launchCameraAsync({
    mediaTypes: resolveMediaTypes(),
    quality: 0.85,
    allowsEditing: false,
    exif: false,
    copyToCacheDirectory: true,
  } as any);

  if (result.canceled) return null;
  const asset = result.assets?.[0];
  if (!asset?.uri) return null;
  return { uri: asset.uri };
}

export async function confirmBookingPhotoRequired(title: string, message: string): Promise<boolean> {
  return new Promise((resolve) => {
    let settled = false;
    const finish = (value: boolean) => {
      if (settled) return;
      settled = true;
      resolve(value);
    };

    Alert.alert(title, message, [
      { text: 'Cancel', style: 'cancel', onPress: () => finish(false) },
      { text: 'Take photo', onPress: () => finish(true) },
    ], {
      cancelable: true,
      onDismiss: () => finish(false),
    });
  });
}

export async function sendBookingPhotoMessage(params: {
  bookingId: string;
  senderId: string;
  senderRole: string;
  content: string;
  localUri: string;
}): Promise<BookingMessageRow> {
  const mediaUrl = await uploadBookingMedia(params.localUri, params.bookingId, params.senderId);
  const insert: BookingMessageInsert = {
    booking_id: params.bookingId,
    sender_id: params.senderId,
    sender_role: params.senderRole,
    message_type: 'image',
    content: params.content,
    media_url: mediaUrl,
  };

  const { data, error } = await supabase
    .from('booking_messages')
    .insert(insert)
    .select('id, booking_id, sender_id, sender_role, message_type, content, media_url, voice_duration_seconds, created_at')
    .single();

  if (error) throw error;
  if (!data) throw new Error('Failed to send photo message.');
  return data as BookingMessageRow;
}

export async function promptAndSendBookingPhotoMessage(params: {
  bookingId: string;
  senderId: string;
  senderRole: string;
  content: string;
  promptTitle: string;
  promptMessage: string;
}): Promise<BookingMessageRow | null> {
  const confirmed = await confirmBookingPhotoRequired(params.promptTitle, params.promptMessage);
  if (!confirmed) return null;

  const photo = await captureBookingPhoto();
  if (!photo) return null;

  return sendBookingPhotoMessage({
    bookingId: params.bookingId,
    senderId: params.senderId,
    senderRole: params.senderRole,
    content: params.content,
    localUri: photo.uri,
  });
}
