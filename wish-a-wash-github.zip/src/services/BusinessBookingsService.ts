/**
 * Loads active bookings for a business organization.
 * Used by both the business dashboard and the business bookings page.
 * Fetches by: org locations (location_id + location_address), org valeters (valeter_id), and fallback organization_id on bookings.
 *
 * For a customer booking at a car wash (e.g. Shiny Suds) to appear here, the booking row must have:
 * - location_id = that location's id, OR
 * - location_address matching the location's address, OR
 * - valeter_id = one of the org's valeters, OR
 * - organization_id = the org id (if the column exists).
 * Bookings appear here when they have location_id, location_address, valeter_id, or organization_id matching this org (set by your backend or DB trigger).
 */
import { supabase } from '../lib/supabase';
import {
  fetchProfilesByIds,
  resolveCustomerAvatarsForUserIds,
  type CustomerProfileRow,
} from '../utils/customerProfiles';

function getDisplayNameFromProfile(
  profile: Pick<CustomerProfileRow, 'full_name' | 'name' | 'email'> | undefined,
  fallback: string
): string {
  const fullName = profile?.full_name?.trim();
  if (fullName) return fullName;

  const name = profile?.name?.trim();
  if (name) return name;

  const email = profile?.email?.trim();
  if (email) {
    const localPart = email.split('@')[0]?.replace(/[._-]+/g, ' ').trim();
    if (localPart) {
      return localPart
        .split(' ')
        .filter(Boolean)
        .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
        .join(' ');
    }
  }

  return fallback;
}

const ACTIVE_STATUSES = [
  'pending',
  'pending_business_acceptance',
  'pending_valeter_acceptance',
  'pending_payment',
  'confirmed',
  'valeter_assigned',
  'en_route',
  'arrived',
  'in_progress',
  'scheduled',
] as const;

/** Active + terminal rows for business home “recent / upcoming” strip — no `cancelled` (never show on dashboard). */
const DASHBOARD_HOME_STRIP_STATUSES: readonly string[] = [
  ...ACTIVE_STATUSES,
  'completed',
  'valeter_timeout',
];

/**
 * Drop cancelled jobs entirely. Drop past `scheduled_at` rows that are still “open” (e.g. confirmed)
 * so the strip never shows them as active/upcoming once the slot has passed — only completed,
 * valeter_timeout, or live (assigned / en route / in progress / arrived) past-slot rows stay visible.
 */
function shouldIncludeBookingInDashboardStrip(r: { status?: string; scheduled_at?: string | null }): boolean {
  const st = String(r.status ?? '').toLowerCase();
  if (st === 'cancelled') return false;

  const scheduledAt = r.scheduled_at ?? null;
  if (!scheduledAt) return true;

  const slot = new Date(scheduledAt).getTime();
  if (!Number.isFinite(slot)) return true;
  if (slot > Date.now()) return true;

  if (st === 'completed' || st === 'valeter_timeout') return true;
  if (
    st === 'valeter_assigned' ||
    st === 'in_progress' ||
    st === 'en_route' ||
    st === 'arrived'
  ) {
    return true;
  }
  return false;
}

const DASHBOARD_COMPLETED_MAX_AGE_MS = 30 * 24 * 60 * 60 * 1000;

/** Hide completed / timeout strip rows older than 30 days (by completion or update time). */
function shouldIncludeCompletedBookingByAge(r: {
  status?: string;
  completed_at?: string | null;
  updated_at?: string | null;
  created_at?: string | null;
}): boolean {
  const st = String(r.status ?? '').toLowerCase();
  if (st !== 'completed' && st !== 'valeter_timeout') return true;
  const ref = r.completed_at || r.updated_at || r.created_at;
  if (!ref) return true;
  const t = new Date(ref).getTime();
  if (!Number.isFinite(t)) return true;
  return Date.now() - t <= DASHBOARD_COMPLETED_MAX_AGE_MS;
}

async function collectMergedBookingRowsForOrg(
  organizationId: string,
  statuses: readonly string[],
  limit: number
): Promise<any[]> {
  const locationIds: string[] = [];
  const locationAddresses: string[] = [];
  let valeterIds: string[] = [];

  const { data: locations, error: locErr } = await supabase
    .from('car_wash_locations')
    .select('id, address, is_active, status')
    .eq('organization_id', organizationId);
  if (locErr) throw locErr;

  const activeLocations = (locations || []).filter(
    (l: any) => l.is_active !== false && l.status !== 'inactive'
  );
  activeLocations.forEach((l: any) => {
    if (l.id) locationIds.push(l.id);
    const addr = typeof l.address === 'string' ? l.address.trim() : '';
    if (addr) locationAddresses.push(addr);
  });

  const { data: valeters } = await supabase
    .from('profiles')
    .select('id')
    .eq('organization_id', organizationId)
    .eq('user_type', 'valeter');
  valeterIds = (valeters || []).map((v: any) => v.id);

  const selectFields =
    'id,created_at,completed_at,updated_at,status,location_address,location_id,location_lat,location_lng,service_type,service_name,valeter_id,user_id,price,scheduled_at';
  const statusList = [...statuses];
  const statusSet = new Set(statusList);
  const seen = new Set<string>();
  const rows: any[] = [];

  if (locationIds.length > 0) {
    const { data } = await supabase
      .from('bookings')
      .select(selectFields)
      .in('location_id', locationIds)
      .in('status', statusList as any)
      .order('created_at', { ascending: false })
      .limit(limit);
    (data || []).forEach((r: any) => {
      if (!seen.has(r.id)) {
        seen.add(r.id);
        rows.push(r);
      }
    });
  }
  if (locationAddresses.length > 0) {
    const { data } = await supabase
      .from('bookings')
      .select(selectFields)
      .in('location_address', locationAddresses)
      .in('status', statusList as any)
      .order('created_at', { ascending: false })
      .limit(limit);
    (data || []).forEach((r: any) => {
      if (!seen.has(r.id)) {
        seen.add(r.id);
        rows.push(r);
      }
    });
  }
  if (valeterIds.length > 0) {
    const { data } = await supabase
      .from('bookings')
      .select(selectFields)
      .in('valeter_id', valeterIds)
      .in('status', statusList as any)
      .order('created_at', { ascending: false })
      .limit(limit);
    (data || []).forEach((r: any) => {
      if (!seen.has(r.id)) {
        seen.add(r.id);
        rows.push(r);
      }
    });
  }

  try {
    const { data: orgData, error: orgQueryErr } = await supabase
      .from('bookings')
      .select(selectFields)
      .eq('organization_id', organizationId)
      .in('status', statusList as any)
      .order('created_at', { ascending: false })
      .limit(limit);
    if (!orgQueryErr && orgData) {
      orgData.forEach((r: any) => {
        if (!seen.has(r.id)) {
          seen.add(r.id);
          rows.push(r);
        }
      });
    }
    if (rows.length === 0 && !orgQueryErr) {
      const { data: orgDataAnyStatus } = await supabase
        .from('bookings')
        .select(selectFields)
        .eq('organization_id', organizationId)
        .order('created_at', { ascending: false })
        .limit(limit);
      (orgDataAnyStatus || []).forEach((r: any) => {
        if (!seen.has(r.id) && statusSet.has(String(r.status ?? ''))) {
          seen.add(r.id);
          rows.push(r);
        }
      });
    }
  } catch {
    // organization_id column may not exist; ignore
  }

  if (rows.length === 0 && locationIds.length > 0) {
    const { data: anyStatusByLocation } = await supabase
      .from('bookings')
      .select(selectFields)
      .in('location_id', locationIds)
      .order('created_at', { ascending: false })
      .limit(limit);
    (anyStatusByLocation || []).forEach((r: any) => {
      if (!seen.has(r.id) && statusSet.has(String(r.status ?? ''))) {
        seen.add(r.id);
        rows.push(r);
      }
    });
  }

  rows.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  return rows;
}

export interface BusinessDashboardJobRow {
  id: string;
  status: string;
  service_type: string;
  service_name: string | null;
  location_address: string | null;
  scheduled_at: string | null;
  price: number;
  created_at: string;
  customer_name: string;
  /** Customer auth id (`bookings.user_id`) for chat access checks */
  customer_user_id: string | null;
  customer_photo: string | null;
  assigned_valeter_name: string | null;
  assigned_valeter_photo: string | null;
  vehicle_registration: string | null;
  vehicle_make: string | null;
  vehicle_model: string | null;
}

/**
 * Bookings for the business dashboard “recent jobs” strip (upcoming + recent completed, etc.).
 */
export async function loadDashboardBookingsForOrganization(
  organizationId: string
): Promise<BusinessDashboardJobRow[]> {
  const rows = await collectMergedBookingRowsForOrg(
    organizationId,
    DASHBOARD_HOME_STRIP_STATUSES,
    80
  );
  const eligible = rows
    .filter(shouldIncludeBookingInDashboardStrip)
    .filter(shouldIncludeCompletedBookingByAge);
  if (eligible.length === 0) return [];

  const customerIds = [...new Set(eligible.map((r) => r.user_id).filter(Boolean))] as string[];
  const valeterIds = [...new Set(eligible.map((r) => r.valeter_id).filter(Boolean))] as string[];
  // Same customer profile source as valeter recent jobs (PowerfulDriverDashboard + fetchProfilesByIds).
  const customerProfiles =
    customerIds.length > 0 ? await fetchProfilesByIds(customerIds) : new Map();
  const customerPhotos =
    customerIds.length > 0
      ? resolveCustomerAvatarsForUserIds(customerIds, customerProfiles)
      : new Map<string, string | null>();
  const valeterProfiles = valeterIds.length > 0 ? await fetchProfilesByIds(valeterIds) : new Map();
  const valeterPhotos =
    valeterIds.length > 0
      ? resolveCustomerAvatarsForUserIds(valeterIds, valeterProfiles)
      : new Map<string, string | null>();

  const vehicleMap = new Map<string, { registration?: string; make?: string; model?: string }>();
  if (customerIds.length > 0) {
    try {
      const { data: vehicles } = await supabase
        .from('customer_vehicles')
        .select('user_id, registration, make, model')
        .in('user_id', customerIds)
        .eq('is_default', true);
      (vehicles || []).forEach((v: any) => {
        vehicleMap.set(v.user_id, {
          registration: v.registration ?? undefined,
          make: v.make ?? undefined,
          model: v.model ?? undefined,
        });
      });
    } catch {
      // customer_vehicles table may not exist
    }
  }

  return eligible.map((r) => {
    const scheduledAt = r.scheduled_at ?? null;
    const vehicle = r.user_id ? vehicleMap.get(r.user_id) : undefined;
    const p = r.user_id ? customerProfiles.get(r.user_id) : undefined;
    return {
      id: r.id,
      status: String(r.status ?? ''),
      service_type: r.service_type || 'Service',
      service_name: r.service_name ?? null,
      location_address: r.location_address ?? null,
      scheduled_at: scheduledAt,
      price: Number(r.price ?? 0),
      created_at: r.created_at,
      customer_name: getDisplayNameFromProfile(p, 'Customer'),
      customer_user_id: (r.user_id as string | null) ?? null,
      customer_photo: r.user_id ? customerPhotos.get(r.user_id) ?? null : null,
      assigned_valeter_name: r.valeter_id
        ? (valeterProfiles.get(r.valeter_id)?.full_name?.trim() ||
          valeterProfiles.get(r.valeter_id)?.name?.trim() ||
          'Car Care Pro')
        : null,
      assigned_valeter_photo: r.valeter_id ? valeterPhotos.get(r.valeter_id) ?? null : null,
      vehicle_registration: vehicle?.registration ?? null,
      vehicle_make: vehicle?.make ?? null,
      vehicle_model: vehicle?.model ?? null,
    };
  });
}

export interface BusinessActiveBooking {
  id: string;
  customer_id: string | null;
  status: string;
  service_type: string;
  service_name: string | null;
  location_address: string | null;
  location_lat: number | null;
  location_lng: number | null;
  scheduled_at: string | null;
  scheduled_time: string | null;
  price: number;
  customer_name: string;
  customer_profile_picture: string | null;
  customer_email: string | null;
  customer_phone: string | null;
  assigned_valeter_name: string | null;
  assigned_valeter_photo: string | null;
  vehicle_registration: string | null;
  vehicle_make: string | null;
  vehicle_model: string | null;
  created_at: string;
}

export async function loadActiveBookingsForOrganization(
  organizationId: string
): Promise<BusinessActiveBooking[]> {
  const rows = await collectMergedBookingRowsForOrg(
    organizationId,
    ACTIVE_STATUSES as unknown as readonly string[],
    100
  );

  if (rows.length === 0) {
    if (typeof __DEV__ !== 'undefined' && __DEV__) {
      console.warn(
        '[BusinessBookingsService] No active bookings for org',
        organizationId,
        '| See docs/BOOKINGS_NOT_SHOWING.md'
      );
    }
    return [];
  }

  const customerIds = [...new Set(rows.map((r) => r.user_id).filter(Boolean))] as string[];
  const valeterIdsFromRows = [...new Set(rows.map((r) => r.valeter_id).filter(Boolean))] as string[];

  const customerNameMap = new Map<string, string>();
  const customerEmailMap = new Map<string, string | null>();
  const customerPhoneMap = new Map<string, string | null>();
  const customerProfileRows = new Map<string, CustomerProfileRow>();
  if (customerIds.length > 0) {
    const customerProfiles = await fetchProfilesByIds(customerIds);
    customerIds.forEach((id) => {
      const p = customerProfiles.get(id);
      if (!p) return;
      customerNameMap.set(p.id, (p.full_name || p.name || 'Customer') as string);
      customerEmailMap.set(p.id, (p.email ?? null) as string | null);
      customerPhoneMap.set(p.id, (p.phone ?? null) as string | null);
      customerProfileRows.set(p.id, p);
    });
  }
  const customerPhotoMap =
    customerIds.length > 0
      ? resolveCustomerAvatarsForUserIds(customerIds, customerProfileRows)
      : new Map<string, string | null>();

  const valeterNameMap = new Map<string, string>();
  const valeterPhotoMap = new Map<string, string | null>();
  if (valeterIdsFromRows.length > 0) {
    const valeterProfiles = await fetchProfilesByIds(valeterIdsFromRows);
    const valeterPhotos = resolveCustomerAvatarsForUserIds(valeterIdsFromRows, valeterProfiles);
    valeterIdsFromRows.forEach((id) => {
      const p = valeterProfiles.get(id);
      valeterNameMap.set(id, getDisplayNameFromProfile(p, 'Valeter'));
      valeterPhotoMap.set(id, valeterPhotos.get(id) ?? null);
    });
  }

  const vehicleMap = new Map<string, { registration?: string; make?: string; model?: string }>();
  if (customerIds.length > 0) {
    try {
      const { data: vehicles } = await supabase
        .from('customer_vehicles')
        .select('user_id, registration, make, model')
        .in('user_id', customerIds)
        .eq('is_default', true);
      (vehicles || []).forEach((v: any) => {
        vehicleMap.set(v.user_id, {
          registration: v.registration ?? undefined,
          make: v.make ?? undefined,
          model: v.model ?? undefined,
        });
      });
    } catch {
      // customer_vehicles table may not exist
    }
  }

  return rows.map((r) => {
    const scheduledAt = r.scheduled_at ?? r.scheduled_time;
    const scheduledTime = scheduledAt
      ? new Date(scheduledAt).toLocaleString('en-GB', { hour: '2-digit', minute: '2-digit' })
      : null;
    const customerName = (r.user_id && customerNameMap.get(r.user_id)) || (r.customer_name ?? 'Customer');
    const vehicle = r.user_id ? vehicleMap.get(r.user_id) : undefined;
    return {
      id: r.id,
      customer_id: r.user_id ?? null,
      status: String(r.status ?? ''),
      service_type: r.service_type || 'Service',
      service_name: r.service_name ?? null,
      location_address: r.location_address ?? null,
      location_lat: r.location_lat ?? null,
      location_lng: r.location_lng ?? null,
      scheduled_at: scheduledAt ?? null,
      scheduled_time: scheduledTime,
      price: Number(r.price ?? 0),
      customer_name: customerName,
      customer_profile_picture: r.user_id ? customerPhotoMap.get(r.user_id) ?? null : null,
      customer_email: r.user_id ? customerEmailMap.get(r.user_id) ?? null : null,
      customer_phone: r.user_id ? customerPhoneMap.get(r.user_id) ?? null : null,
      assigned_valeter_name: r.valeter_id ? (valeterNameMap.get(r.valeter_id) || null) : null,
      assigned_valeter_photo: r.valeter_id ? (valeterPhotoMap.get(r.valeter_id) ?? null) : null,
      vehicle_registration: vehicle?.registration ?? null,
      vehicle_make: vehicle?.make ?? null,
      vehicle_model: vehicle?.model ?? null,
      created_at: r.created_at,
    };
  });
}

const HISTORY_STATUSES = ['completed', 'cancelled'] as const;

export interface BusinessHistoryBooking {
  id: string;
  customer_id: string | null;
  customer_name: string;
  /** Display URL from `profiles.profile_picture` (customer app / uploads bucket), resolved for Image. */
  customer_profile_picture: string | null;
  assigned_valeter_name: string | null;
  assigned_valeter_photo: string | null;
  service_type: string;
  service_name: string | null;
  location_address: string | null;
  location_lat: number | null;
  location_lng: number | null;
  scheduled_at: string | null;
  scheduled_time: string | null;
  status: string;
  price: number;
  created_at: string;
}

/**
 * Loads completed/cancelled bookings for the same org scope as active bookings.
 * Uses: org locations (location_id + location_address), org valeters (valeter_id), and organization_id fallback.
 */
export async function loadHistoryBookingsForOrganization(
  organizationId: string
): Promise<BusinessHistoryBooking[]> {
  const locationIds: string[] = [];
  const locationAddresses: string[] = [];
  let valeterIds: string[] = [];

  const { data: locations, error: locErr } = await supabase
    .from('car_wash_locations')
    .select('id, address, is_active, status')
    .eq('organization_id', organizationId);
  if (locErr) throw locErr;

  const activeLocations = (locations || []).filter(
    (l: any) => l.is_active !== false && l.status !== 'inactive'
  );
  activeLocations.forEach((l: any) => {
    if (l.id) locationIds.push(l.id);
    const addr = typeof l.address === 'string' ? l.address.trim() : '';
    if (addr) locationAddresses.push(addr);
  });

  const { data: valeters } = await supabase
    .from('profiles')
    .select('id')
    .eq('organization_id', organizationId)
    .eq('user_type', 'valeter');
  valeterIds = (valeters || []).map((v: any) => v.id);

  const selectFields = 'id,created_at,status,price,location_address,location_id,location_lat,location_lng,service_type,service_name,valeter_id,user_id,scheduled_at';
  const seen = new Set<string>();
  const rows: any[] = [];

  if (locationIds.length > 0) {
    const { data } = await supabase
      .from('bookings')
      .select(selectFields)
      .in('location_id', locationIds)
      .in('status', HISTORY_STATUSES as any)
      .order('created_at', { ascending: false })
      .limit(100);
    (data || []).forEach((r: any) => {
      if (!seen.has(r.id)) {
        seen.add(r.id);
        rows.push(r);
      }
    });
  }
  if (locationAddresses.length > 0) {
    const { data } = await supabase
      .from('bookings')
      .select(selectFields)
      .in('location_address', locationAddresses)
      .in('status', HISTORY_STATUSES as any)
      .order('created_at', { ascending: false })
      .limit(100);
    (data || []).forEach((r: any) => {
      if (!seen.has(r.id)) {
        seen.add(r.id);
        rows.push(r);
      }
    });
  }
  if (valeterIds.length > 0) {
    const { data } = await supabase
      .from('bookings')
      .select(selectFields)
      .in('valeter_id', valeterIds)
      .in('status', HISTORY_STATUSES as any)
      .order('created_at', { ascending: false })
      .limit(100);
    (data || []).forEach((r: any) => {
      if (!seen.has(r.id)) {
        seen.add(r.id);
        rows.push(r);
      }
    });
  }
  try {
    const { data: orgData, error: orgErr } = await supabase
      .from('bookings')
      .select(selectFields)
      .eq('organization_id', organizationId)
      .in('status', HISTORY_STATUSES as any)
      .order('created_at', { ascending: false })
      .limit(100);
    if (!orgErr && orgData) {
      orgData.forEach((r: any) => {
        if (!seen.has(r.id)) {
          seen.add(r.id);
          rows.push(r);
        }
      });
    }
  } catch {
    // organization_id column may not exist
  }

  if (rows.length === 0) return [];

  rows.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

  const userIds = [...new Set(rows.map((r) => r.user_id).filter(Boolean))] as string[];
  const historyValeterIds = [...new Set(rows.map((r) => r.valeter_id).filter(Boolean))] as string[];
  const customerProfiles = userIds.length > 0 ? await fetchProfilesByIds(userIds) : new Map();
  const historyPhotos =
    userIds.length > 0 ? resolveCustomerAvatarsForUserIds(userIds, customerProfiles) : new Map();
  const valeterProfiles =
    historyValeterIds.length > 0 ? await fetchProfilesByIds(historyValeterIds) : new Map();
  const valeterPhotos =
    historyValeterIds.length > 0
      ? resolveCustomerAvatarsForUserIds(historyValeterIds, valeterProfiles)
      : new Map();

  return rows.map((r) => {
    const scheduledAt = r.scheduled_at ?? null;
    const scheduledTime = scheduledAt
      ? new Date(scheduledAt).toLocaleString('en-GB', { hour: '2-digit', minute: '2-digit' })
      : null;
    const p = r.user_id ? customerProfiles.get(r.user_id) : undefined;
    return {
      id: r.id,
      customer_id: r.user_id ?? null,
      customer_name: getDisplayNameFromProfile(p, 'Customer'),
      customer_profile_picture: r.user_id ? historyPhotos.get(r.user_id) ?? null : null,
      assigned_valeter_name: r.valeter_id
        ? getDisplayNameFromProfile(valeterProfiles.get(r.valeter_id), 'Car Care Pro')
        : null,
      assigned_valeter_photo: r.valeter_id ? valeterPhotos.get(r.valeter_id) ?? null : null,
      service_type: r.service_type || 'Service',
      service_name: r.service_name ?? null,
      location_address: r.location_address ?? null,
      location_lat: r.location_lat ?? null,
      location_lng: r.location_lng ?? null,
      scheduled_at: scheduledAt,
      scheduled_time: scheduledTime,
      status: String(r.status ?? 'completed'),
      price: Number(r.price ?? 0),
      created_at: r.created_at,
    };
  });
}
