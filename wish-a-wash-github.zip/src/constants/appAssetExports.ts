/**
 * Asset requires rooted from the top-level assets folder so Metro resolves consistently.
 */
export const CAR_IMAGE = require('../../assets/car.png');
export const VALETER_IMAGE = require('../../assets/valeter.png');
export const VALETER_MAP_IMAGE = require('../../assets/valeter-map.png');
export const CARWASH_IMAGE = require('../../assets/carwash.png');
export const ICON = require('../../assets/icon.png');
export const ICON_AUTH = require('../../assets/icon-auth.png');
export const WASHER_IMAGE = require('../../assets/valeter.png');

export const BRONZE_IMAGE = require('../../assets/bronze.png');
export const SILVER_IMAGE = require('../../assets/silver.png');
export const GOLD_IMAGE = require('../../assets/Gold.png');
export const PLATINUM_IMAGE = require('../../assets/platinum.png');
export const EMERALD_IMAGE = require('../../assets/emerald.png');
export const DETAILING_HUB_IMAGE = require('../../assets/Detailing1.png');
export const CERAMIC_DETAIL_IMAGE = require('../../assets/Ceramic.png');
export const SOFTOP_DETAIL_IMAGE = require('../../assets/Softop.png');
export const MOULD_DETAIL_IMAGE = require('../../assets/mould.png');
export const HEADLIGHT_DETAIL_IMAGE = require('../../assets/headlight.png');
export const ONBOARDING_VIDEO = require('../../assets/onboarding.mp4');
