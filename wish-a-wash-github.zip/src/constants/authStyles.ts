import { Dimensions, Platform, StyleSheet } from 'react-native';
import { colors } from './colors';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

/** Gradient overlay colors for auth video background (shared by login/signup). */
export const AUTH_GRADIENT_COLORS = [
  'rgba(10,25,41,0.4)',
  'rgba(10,25,41,0.65)',
  'rgba(10,25,41,0.92)',
] as const;

/** Content overlay: darker gradient behind glass card for readability */
export const AUTH_CONTENT_OVERLAY_COLORS = [
  'rgba(10,25,41,0.5)',
  'rgba(10,25,41,0.75)',
  'rgba(10,25,41,0.95)',
] as const;

/** Hero logo dimensions on auth login/signup (Archive 2 layout). */
export const AUTH_HERO_LOGO_WIDTH = 380;
export const AUTH_HERO_LOGO_HEIGHT = 238;

/** Logo frame width as a fraction of the auth card content width. */
export const AUTH_LOGO_FRAME_WIDTH_RATIO = 1;

const sharedAuthStyleDefs = {
  root: { flex: 1, backgroundColor: '#0A1929' as const },
  keyboardView: { flex: 1 },
  scrollContent: {
    flexGrow: 1,
    paddingTop: Platform.OS === 'ios' ? 160 : 56,
    paddingBottom: 28,
    paddingHorizontal: isSmallScreen ? 20 : 24,
  },
  contentContainer: { flex: 1 },

  topRightLink: {
    position: 'absolute' as const,
    top: Platform.OS === 'ios' ? 50 : 24,
    right: 24,
    zIndex: 20,
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 999,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  topRightLinkText: {
    color: '#B8E0F0',
    fontWeight: '700' as const,
    fontSize: 14,
  },

  videoBackground: StyleSheet.absoluteFillObject,

  logoContainer: {
    alignItems: 'center' as const,
    width: '100%' as const,
    marginTop: 16,
    marginBottom: 8,
  },
  authLogoGlowWrap: {
    width: `${AUTH_LOGO_FRAME_WIDTH_RATIO * 100}%` as const,
    alignSelf: 'center' as const,
  },
  authLogoFrame: {
    width: '100%' as const,
    aspectRatio: AUTH_HERO_LOGO_WIDTH / AUTH_HERO_LOGO_HEIGHT,
    borderRadius: 16,
    overflow: 'hidden' as const,
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
    backgroundColor: 'transparent',
  },
  authHeroLogo: {
    width: '100%' as const,
    height: '100%' as const,
    borderRadius: 12,
  },

  headline: {
    fontSize: 22,
    fontWeight: '700' as const,
    color: 'rgba(255,255,255,0.98)',
    textAlign: 'center' as const,
    marginBottom: 4,
  },
  subtext: {
    fontSize: 15,
    fontWeight: '500' as const,
    color: 'rgba(255,255,255,0.72)',
    textAlign: 'center' as const,
    marginBottom: 22,
  },

  contentOverlayWrapper: {
    position: 'relative' as const,
    width: '100%' as const,
    borderRadius: 20,
    overflow: 'hidden' as const,
    marginBottom: 4,
  },

  glassCard: {
    borderRadius: 20,
    overflow: 'hidden' as const,
    paddingHorizontal: 20,
    paddingTop: 24,
    paddingBottom: 24,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.22,
    shadowRadius: 16,
    elevation: 8,
  },

  emailCtaButton: {
    backgroundColor: 'rgba(255,255,255,0.14)',
    borderRadius: 14,
    paddingVertical: 16,
    paddingHorizontal: 20,
    marginBottom: 16,
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
    gap: 10,
  },
  emailCtaButtonText: {
    fontSize: 16,
    fontWeight: '600' as const,
    color: 'rgba(255,255,255,0.95)',
  },

  dividerContainer: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    marginTop: 18,
    marginBottom: 16,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
  dividerText: {
    marginHorizontal: 12,
    color: 'rgba(255,255,255,0.6)',
    fontSize: 12,
    fontWeight: '600' as const,
  },

  socialIconRow: {
    flexDirection: 'row' as const,
    justifyContent: 'center' as const,
    alignItems: 'center' as const,
    gap: 14,
    marginTop: 2,
  },
  socialIconButton: {
    width: 56,
    height: 56,
    borderRadius: 16,
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
    backgroundColor: '#FFFFFF',
  },
  socialIconApple: {
    backgroundColor: '#FFFFFF',
  },
  socialIconGoogle: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.35)',
  },

  trustCopy: {
    marginTop: 20,
    paddingHorizontal: 8,
  },
  trustCopyText: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.55)',
    textAlign: 'center' as const,
    lineHeight: 18,
  },
  trustCopyLink: {
    color: '#87CEEB',
    fontWeight: '600' as const,
    textDecorationLine: 'underline' as const,
  },

  signupCtaRow: {
    flexDirection: 'row' as const,
    justifyContent: 'center' as const,
    alignItems: 'center' as const,
    marginTop: 12,
    marginBottom: 8,
    flexWrap: 'wrap' as const,
  },
  signupCtaText: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 13,
    fontWeight: '600' as const,
  },
  signupCtaLink: {
    color: '#87CEEB',
    fontWeight: '800' as const,
  },

  helpLink: {
    marginTop: 16,
    alignSelf: 'center' as const,
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    paddingVertical: 6,
    paddingHorizontal: 12,
  },
  helpLinkText: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.7)',
    fontWeight: '500' as const,
  },

  footer: {
    marginTop: 24,
    alignItems: 'center' as const,
  },
  footerText: {
    fontSize: 11,
    color: 'rgba(255,255,255,0.4)',
  },

  inputWrapper: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    backgroundColor: 'rgba(135,206,235,0.25)',
    borderRadius: 12,
    marginBottom: 12,
  },
  inputIconContainer: {
    width: 44,
    height: 48,
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
  },
  input: {
    flex: 1,
    color: colors.inputText,
    fontSize: 15,
    paddingRight: 12,
  },
};

export { sharedAuthStyleDefs };
