// app/index.tsx
import React, { useEffect, useState } from 'react';
import { useRouter, useRootNavigationState } from 'expo-router';
import { useAuth } from '../src/providers/enhanced-auth-context';
import LoadingScreen from '../src/components/LoadingScreen';
import { normalizeUserType } from '../src/utils/authRole';
import { termsAgreementService, type TermsStatus } from '../src/services/termsAgreementService';
import { businessOnboardingService } from '../src/services/businessOnboardingService';
import { valeterStripeConnectService } from '../src/services/valeterStripeConnectService';

type StripeConnectStatus =
  | 'not_started'
  | 'in_progress'
  | 'completed'
  | 'restricted'
  | 'rejected';

export default function Index() {
  const router = useRouter();
  const navReady = useRootNavigationState()?.key != null;
  const { user, isLoading, authReady } = useAuth();

  const [termsStatus, setTermsStatus] = useState<TermsStatus | null>(null);
  const [stripeStatus, setStripeStatus] = useState<StripeConnectStatus | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (!user || !authReady || isLoading) {
        setTermsStatus(null);
        setStripeStatus(null);
        return;
      }

      const userType = normalizeUserType(user?.userType, null) ?? undefined;
      const accountType = userType === 'organization' ? 'business' : userType === 'valeter' ? 'valeter' : null;
      if (!accountType) {
        setTermsStatus(null);
        setStripeStatus(null);
        return;
      }

      try {
        const [rec, stripeRec] = await Promise.all([
          termsAgreementService.load(accountType, user.id),
          accountType === 'business'
            ? businessOnboardingService.getStatus(user.id)
            : valeterStripeConnectService.getStatus(user.id),
        ]);
        if (!cancelled) setTermsStatus(rec.status);
        if (!cancelled) setStripeStatus(stripeRec.stripeConnectStatus);
      } catch {
        if (!cancelled) {
          setTermsStatus('pending');
          setStripeStatus('not_started');
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [authReady, isLoading, user?.id, user?.userType]);

  useEffect(() => {
    if (!navReady || !authReady || isLoading) return;
    const userType = normalizeUserType(user?.userType, null) ?? undefined;

    // 1) Not logged in → auth flow
    if (!user) {
      router.replace('/auth/login');
      return;
    }

    if (termsStatus === null || stripeStatus === null) {
      return;
    }

    if (termsStatus === 'declined') {
      if (userType === 'organization') {
        router.replace('/business/terms-blocked');
        return;
      }
      if (userType === 'valeter') {
        router.replace('/valeter/terms-blocked');
        return;
      }
    }

    if (termsStatus !== 'accepted') {
      if (userType === 'organization') {
        router.replace('/business/terms');
        return;
      }
      if (userType === 'valeter') {
        router.replace('/valeter/terms');
        return;
      }
    }

    if (stripeStatus === 'not_started' || stripeStatus === 'restricted' || stripeStatus === 'rejected') {
      if (userType === 'organization') {
        router.replace('/business/stripe-connect');
        return;
      }
      if (userType === 'valeter') {
        router.replace('/valeter/stripe-connect');
        return;
      }
      router.replace('/valeter/stripe-connect');
      return;
    }

    // 3) Ready → dashboards
    if (userType === 'valeter') {
      router.replace('/valeter/valeter-dashboard');
      return;
    }
    if (userType === 'organization') {
      router.replace('/business/dashboard');
      return;
    }

    // 4) Fallback
    router.replace('/valeter/valeter-dashboard');
  }, [navReady, authReady, isLoading, user, termsStatus, stripeStatus, router]);

  return <LoadingScreen overlay={false} />;
}
