import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert,
  Animated,
  Platform,
  ScrollView,
  StatusBar,
  KeyboardAvoidingView,
  Modal,
  Pressable,
  Linking,
  Image,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Video, ResizeMode, AVPlaybackStatus } from 'expo-av';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { router } from 'expo-router';
import { Ionicons as BrandGlyph } from '@expo/vector-icons';
import * as AppleAuthentication from 'expo-apple-authentication';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { supabase } from '../../src/lib/supabase';
import { colors } from '../../src/constants/colors';
import WWPrimaryButton from '../../src/components/ui/WWPrimaryButton';
import { AUTH_PAGES_VIDEO } from '../../assets/authExports';
import {
  sharedAuthStyleDefs,
  AUTH_GRADIENT_COLORS,
  AUTH_CONTENT_OVERLAY_COLORS,
} from '../../src/constants/authStyles';
import {
  isValeterRole,
  normalizeUserType,
} from '../../src/utils/authRole';

const TERMS_URL = 'https://wishawash.com/terms';
const PRIVACY_URL = 'https://wishawash.com/privacy';
const NEW_AUTH_LOGO = require('../../assets/newauthlogo.png');

export default function LoginScreen() {
  const { login, logout, loginWithApple } = useAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isAppleAvailable, setIsAppleAvailable] = useState(false);
  const [emailModalVisible, setEmailModalVisible] = useState(false);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const videoOpacity = useRef(new Animated.Value(0)).current;
  const logoGlow = useRef(new Animated.Value(0.94)).current;
  const buttonScale = useRef(new Animated.Value(1)).current;
  const videoRef = useRef<Video>(null);
  const [showPassword, setShowPassword] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const available =
          Platform.OS === 'ios' && (await AppleAuthentication.isAvailableAsync());
        setIsAppleAvailable(Boolean(available));
      } catch {
        setIsAppleAvailable(false);
      }
    })();
  }, []);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 800, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0, duration: 800, useNativeDriver: true }),
    ]).start();
  }, []);

  useEffect(() => {
    const pulse = Animated.loop(
      Animated.sequence([
        Animated.timing(logoGlow, { toValue: 1, duration: 2800, useNativeDriver: true }),
        Animated.timing(logoGlow, { toValue: 0.88, duration: 2800, useNativeDriver: true }),
      ])
    );
    pulse.start();
    return () => pulse.stop();
  }, [logoGlow]);

  const handlePressIn = () => {
    Animated.spring(buttonScale, { toValue: 0.98, useNativeDriver: true, speed: 50 }).start();
  };
  const handlePressOut = () => {
    Animated.spring(buttonScale, { toValue: 1, useNativeDriver: true, speed: 50 }).start();
  };

  const handlePlaybackStatusUpdate = (status: AVPlaybackStatus) => {
    if (!status.isLoaded || !videoRef.current) return;
    if (status.didJustFinish) {
      videoRef.current.setPositionAsync(0).then(() => videoRef.current?.playAsync()).catch(() => {});
      return;
    }
    if (status.durationMillis != null && status.positionMillis != null) {
      const remaining = status.durationMillis - status.positionMillis;
      if (remaining < 500 && remaining > 0) {
        videoRef.current.setPositionAsync(0).then(() => videoRef.current?.playAsync()).catch(() => {});
      }
    }
  };

  const handleVideoLoad = () => {
    Animated.timing(videoOpacity, {
      toValue: 1,
      duration: 700,
      useNativeDriver: true,
    }).start();
  };

  const finishRouting = () => {
    router.replace('/');
  };

  const getEffectiveRole = async (): Promise<string> => {
    const { data: authData, error: authErr } = await supabase.auth.getUser();
    if (authErr) throw authErr;
    const sbUser = authData?.user;
    if (!sbUser?.id) return '';
    const { data: profile, error: profErr } = await supabase
      .from('profiles')
      .select('user_type')
      .eq('id', sbUser.id)
      .maybeSingle();
    if (profErr) throw profErr;
    return normalizeUserType(profile?.user_type ?? (sbUser.user_metadata as any)?.userType, null) ?? '';
  };

  const safeLogout = async () => {
    try {
      if (typeof logout === 'function') await logout();
      else await supabase.auth.signOut();
    } catch {}
  };

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert('Error', 'Please enter both email and password');
      return;
    }
    await hapticFeedback('medium');
    setIsLoading(true);
    try {
      const ok = await login(email.trim(), password);
      if (!ok) {
        Alert.alert(
          'Login Failed',
          'Invalid email or password. If you just signed up, check your inbox and verify your email address before logging in for the first time.'
        );
        return;
      }

      const role = await getEffectiveRole();
      if (!isValeterRole(role)) {
        await safeLogout();
        Alert.alert(
          'Not a Car Care Pro account',
          'This app is for mobile valeters only. Sign in with a Car Care Pro account.'
        );
        return;
      }

      setEmailModalVisible(false);
      finishRouting();
    } catch (e: any) {
      Alert.alert('Login Failed', e?.message || 'Something went wrong. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAppleLogin = async () => {
    try {
      await hapticFeedback('light');
      const credential = await AppleAuthentication.signInAsync({
        requestedScopes: [
          AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
          AppleAuthentication.AppleAuthenticationScope.EMAIL,
        ],
      });
      if (typeof loginWithApple === 'function') {
        const ok = await loginWithApple(credential);
        if (!ok) {
          Alert.alert('Apple Sign In Failed', 'Could not authenticate with Apple.');
          return;
        }
      } else if (credential?.identityToken) {
        await AsyncStorage.setItem('appleIdentityToken', credential.identityToken);
      }

      const role = await getEffectiveRole();
      if (!isValeterRole(role)) {
        await safeLogout();
        Alert.alert(
          'Not a Car Care Pro account',
          'This app is for mobile valeters only. Sign in with a Car Care Pro account.'
        );
        return;
      }
      finishRouting();
    } catch (error: any) {
      if (error?.code === 'ERR_CANCELED') return;
      Alert.alert('Apple Sign In Failed', error?.message || 'Please try again.');
    }
  };

  const handleGoogleLogin = () => {
    Alert.alert('Coming soon', 'Sign in with Google coming soon.');
  };

  const handleForgotPassword = () => {
    Alert.alert('Check your emails', 'Password reset instructions have been sent to your email.');
  };

  const openEmailModal = () => {
    hapticFeedback('light');
    setEmailModalVisible(true);
  };

  const openLink = (url: string) => Linking.openURL(url).catch(() => {});

  return (
    <View style={styles.root}>
      <StatusBar translucent backgroundColor="transparent" barStyle="light-content" />

      <TouchableOpacity
        style={styles.topRightLink}
        onPress={() => router.push('/auth/signup' as any)}
        disabled={isLoading}
        activeOpacity={0.8}
      >
        <Text style={styles.topRightLinkText}>Sign up</Text>
      </TouchableOpacity>

      <Animated.View style={[StyleSheet.absoluteFill, { opacity: videoOpacity }]}>
        <Video
          ref={videoRef}
          source={AUTH_PAGES_VIDEO}
          style={styles.videoBackground}
          resizeMode={ResizeMode.COVER}
          shouldPlay
          isLooping
          isMuted
          progressUpdateIntervalMillis={30}
          onPlaybackStatusUpdate={handlePlaybackStatusUpdate}
          onLoad={handleVideoLoad}
        />
      </Animated.View>
      <View style={StyleSheet.absoluteFill} pointerEvents="none">
        <LinearGradient colors={[...AUTH_GRADIENT_COLORS]} style={StyleSheet.absoluteFill} />
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <Animated.View
            style={[styles.contentContainer, { opacity: fadeAnim, transform: [{ translateY: slideAnim }] }]}
          >
            <View style={styles.logoContainer}>
              <Animated.View style={[styles.authLogoGlowWrap, { opacity: logoGlow }]}>
                <View style={styles.authLogoFrame}>
                  <Image source={NEW_AUTH_LOGO} resizeMode="contain" style={styles.authHeroLogo} />
                </View>
              </Animated.View>
              <Text style={styles.subtext}>Sign in to provide washes.</Text>
            </View>

            <View style={styles.contentOverlayWrapper}>
              <View style={StyleSheet.absoluteFill} pointerEvents="none">
                <LinearGradient colors={[...AUTH_CONTENT_OVERLAY_COLORS]} style={StyleSheet.absoluteFill} />
              </View>
              <BlurView
                intensity={Platform.OS === 'ios' ? 40 : 24}
                tint="dark"
                style={styles.glassCard}
              >
                <TouchableOpacity
                  style={styles.emailCtaButton}
                  onPress={openEmailModal}
                  onPressIn={handlePressIn}
                  onPressOut={handlePressOut}
                  activeOpacity={1}
                  disabled={isLoading}
                >
                  <Animated.View style={{ transform: [{ scale: buttonScale }] }}>
                    <BrandGlyph name="mail-outline" size={22} color="rgba(255,255,255,0.95)" />
                  </Animated.View>
                  <Text style={styles.emailCtaButtonText}>Continue with Email</Text>
                </TouchableOpacity>

                <View style={styles.dividerContainer}>
                  <View style={styles.dividerLine} />
                  <Text style={styles.dividerText}>or continue with</Text>
                  <View style={styles.dividerLine} />
                </View>

                <View style={styles.socialIconRow}>
                  {isAppleAvailable && (
                    <TouchableOpacity
                      style={[styles.socialIconButton, styles.socialIconApple]}
                      onPress={handleAppleLogin}
                      onPressIn={handlePressIn}
                      onPressOut={handlePressOut}
                      activeOpacity={0.9}
                      accessibilityLabel="Continue with Apple"
                    >
                      <BrandGlyph name="logo-apple" size={24} color="#000000" />
                    </TouchableOpacity>
                  )}
                  <TouchableOpacity
                    style={[
                      styles.socialIconButton,
                      styles.socialIconGoogle,
                      { backgroundColor: 'rgba(255,255,255,0.18)', borderColor: 'rgba(255,255,255,0.18)', opacity: 0.72 },
                    ]}
                    onPress={handleGoogleLogin}
                    onPressIn={handlePressIn}
                    onPressOut={handlePressOut}
                    activeOpacity={0.9}
                    accessibilityLabel="Continue with Google"
                  >
                    <BrandGlyph name="logo-google" size={22} color="rgba(255,255,255,0.55)" />
                  </TouchableOpacity>
                </View>
              </BlurView>
            </View>

            <View style={styles.trustCopy}>
              <Text style={styles.trustCopyText}>
                By continuing, you agree to{' '}
                <Text style={styles.trustCopyLink} onPress={() => openLink(TERMS_URL)}>
                  Terms
                </Text>
                {' & '}
                <Text style={styles.trustCopyLink} onPress={() => openLink(PRIVACY_URL)}>
                  Privacy Policy
                </Text>
              </Text>
            </View>

            <View style={styles.signupCtaRow}>
              <Text style={styles.signupCtaText}>New here? </Text>
              <TouchableOpacity onPress={() => router.push('/auth/signup' as any)} activeOpacity={0.8}>
                <Text style={[styles.signupCtaText, styles.signupCtaLink]}>Create an account</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.footer}>
              <Text style={styles.footerText}>Wish a Wash v1.0.0 • © 2026</Text>
            </View>
          </Animated.View>
        </ScrollView>
      </KeyboardAvoidingView>

      <Modal
        visible={emailModalVisible}
        animationType="slide"
        transparent
        onRequestClose={() => setEmailModalVisible(false)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setEmailModalVisible(false)}>
          <KeyboardAvoidingView
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
            style={styles.modalKeyboardAvoid}
          >
            <Pressable style={styles.modalContent} onPress={(e) => e.stopPropagation()}>
              <BlurView intensity={60} tint="dark" style={styles.modalBlur}>
                <ScrollView
                  style={styles.modalScroll}
                  contentContainerStyle={styles.modalScrollContent}
                  keyboardShouldPersistTaps="handled"
                  showsVerticalScrollIndicator={false}
                >
                  <View style={styles.modalInner}>
                    <View style={styles.modalHeader}>
                      <Text style={styles.modalTitle}>Sign in with Email</Text>
                      <TouchableOpacity
                        onPress={() => setEmailModalVisible(false)}
                        hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
                      >
                        <BrandGlyph name="close" size={28} color="rgba(255,255,255,0.9)" />
                      </TouchableOpacity>
                    </View>

                    <Text style={styles.accountTypePill}>Car Care Pro</Text>

                    <View style={styles.inputWrapper}>
                      <View style={styles.inputIconContainer}>
                        <BrandGlyph name="mail-outline" size={20} color="rgba(255,255,255,0.7)" />
                      </View>
                      <TextInput
                        style={styles.input}
                        placeholder="Email address"
                        placeholderTextColor={colors.inputPlaceholder}
                        value={email}
                        onChangeText={setEmail}
                        autoCapitalize="none"
                        keyboardType="email-address"
                        autoComplete="email"
                      />
                    </View>

                    <View style={styles.inputWrapper}>
                      <View style={styles.inputIconContainer}>
                        <BrandGlyph name="lock-closed-outline" size={20} color="rgba(255,255,255,0.7)" />
                      </View>
                      <TextInput
                        style={styles.input}
                        placeholder="Password"
                        placeholderTextColor={colors.inputPlaceholder}
                        value={password}
                        onChangeText={setPassword}
                        secureTextEntry={!showPassword}
                        autoComplete="password"
                      />
                      <TouchableOpacity
                        style={styles.inputIconContainer}
                        onPress={() => setShowPassword((v) => !v)}
                        hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                      >
                        <BrandGlyph
                          name={showPassword ? 'eye-off-outline' : 'eye-outline'}
                          size={20}
                          color="rgba(255,255,255,0.7)"
                        />
                      </TouchableOpacity>
                    </View>

                    <TouchableOpacity style={styles.forgotPasswordLink} onPress={handleForgotPassword}>
                      <Text style={styles.forgotPasswordText}>Forgot password?</Text>
                    </TouchableOpacity>

                    <WWPrimaryButton
                      title={isLoading ? 'Signing in…' : 'Continue'}
                      onPress={() => handleLogin()}
                      disabled={isLoading}
                      loading={isLoading}
                      style={styles.loginButton}
                    />
                  </View>
                </ScrollView>
              </BlurView>
            </Pressable>
          </KeyboardAvoidingView>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  ...sharedAuthStyleDefs,
  forgotPasswordLink: { alignSelf: 'flex-end', marginBottom: 14 },
  forgotPasswordText: { color: '#87CEEB', fontWeight: '600' },
  loginButton: { marginTop: 4 },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  modalKeyboardAvoid: { width: '100%', maxHeight: '92%' },
  modalContent: { maxHeight: '92%', borderTopLeftRadius: 24, borderTopRightRadius: 24, overflow: 'hidden' },
  modalBlur: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    overflow: 'hidden',
    maxHeight: '100%',
  },
  modalScroll: { maxHeight: '100%' },
  modalScrollContent: { padding: 24, paddingBottom: 40 },
  modalInner: { padding: 0 },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: { fontSize: 20, fontWeight: '700', color: 'rgba(255,255,255,0.95)' },
  accountTypePill: {
    alignSelf: 'flex-start',
    marginBottom: 16,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: 'rgba(35,122,230,0.35)',
    borderWidth: 1,
    borderColor: 'rgba(35,122,230,0.55)',
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: '700',
  },
  saveBiometricLink: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 12,
    paddingVertical: 8,
  },
  saveBiometricText: { fontSize: 13, color: '#87CEEB', fontWeight: '600' },
});
