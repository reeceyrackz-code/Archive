import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { router } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import LoadingScreen from '../../src/components/LoadingScreen';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { clearBiometricCredentials } from '../../src/services/BiometricService';

export default function LogoutTestScreen() {
  const { logout } = useAuth();
  const [busy, setBusy] = useState(true);

  useEffect(() => {
    void handleHardLogout();
  }, []);

  const handleHardLogout = async () => {
    try {
      setBusy(true);
      await logout();
      await clearBiometricCredentials();
      await AsyncStorage.removeItem('user_session');
      await AsyncStorage.removeItem('onboarding_seen');
      router.replace('/auth/login');
    } catch (e: any) {
      Alert.alert('Logout failed', e?.message || 'Please try again.');
      setBusy(false);
    }
  };

  if (busy) {
    return <LoadingScreen message="Signing you out…" overlay={false} />;
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Session reset</Text>
      <Text style={styles.copy}>
        If the app got stuck on the wrong account, this clears the saved session and takes you back to login.
      </Text>
      <TouchableOpacity style={styles.button} onPress={() => void handleHardLogout()}>
        <Text style={styles.buttonText}>Sign out now</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
    backgroundColor: '#0F2847',
  },
  title: {
    color: '#FFFFFF',
    fontSize: 28,
    fontWeight: '800',
    marginBottom: 12,
    textAlign: 'center',
  },
  copy: {
    color: 'rgba(255,255,255,0.72)',
    fontSize: 15,
    lineHeight: 22,
    textAlign: 'center',
    maxWidth: 340,
    marginBottom: 24,
  },
  button: {
    backgroundColor: '#F7C948',
    borderRadius: 16,
    paddingVertical: 14,
    paddingHorizontal: 22,
    minWidth: 180,
    alignItems: 'center',
  },
  buttonText: {
    color: '#0F2847',
    fontSize: 16,
    fontWeight: '800',
  },
});
