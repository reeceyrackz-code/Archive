import React from 'react';
import TermsAgreementScreen from '../../src/components/shared/TermsAgreementScreen';

export default function ValeterTermsScreen() {
  return (
    <TermsAgreementScreen
      accountType="valeter"
      title="Valeter questionnaire"
      subtitle="Tell us how you work so we can keep your account setup in sync."
      version="v1.0"
      continuePath="/valeter/stripe-connect?mode=onboarding"
      blockedPath="/valeter/terms-blocked"
      footerNote="The same questionnaire record is used for both mobile-based and physical account types."
    />
  );
}
