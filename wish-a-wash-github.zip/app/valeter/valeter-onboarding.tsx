import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Dimensions,
  ScrollView,
  StatusBar,
  Image,
  Modal,
  Pressable,
  TextInput,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LinearGradient } from 'expo-linear-gradient';
import { Video, ResizeMode } from 'expo-av';
import { BlurView } from 'expo-blur';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { ChromeGlyph as Ionicons } from '../../src/components/shared/ChromeGlyph';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';
import ValeterScreenHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/valeter/ValeterScreenHeader';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { termsAgreementService } from '../../src/services/termsAgreementService';
import {
  showValeterInsuranceRequiredAlert,
  valeterInsuranceDetailsComplete,
} from '../../src/utils/valeterInsuranceQuestionnaire';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const valeterTheme = getAccountTheme('valeter');
const VALETER_PRIMARY = valeterTheme.primary;
const VALETER_PRIMARY_ALT = valeterTheme.primaryAlt;

// Upgraded modern colors - removed dark blue
const MODERN_BG = '#0F172A'; // Slightly lighter than #0A1929
const MODERN_CARD_BG = 'rgba(255,255,255,0.08)';
const MODERN_TEXT_PRIMARY = '#F8FAFC';
const MODERN_TEXT_SECONDARY = 'rgba(248,250,252,0.8)';
const QUESTIONNAIRE_STORAGE_KEY = 'valeter_onboarding_questionnaire_complete';

type YesNo = 'yes' | 'no';
type UnitBased = 'mobile_unit_based' | 'mobile' | 'unit';
type QuestionnaireAnswers = {
  keepCustomers: YesNo | null;
  keepCalendarAvailability: YesNo | null;
  shareContactDetails: YesNo | null;
  unitBased: UnitBased | null;
  hasBusinessInsurance: YesNo | null;
  insuranceProvider: string;
  insuranceType: string;
  policyNumber: string;
};

function resolveUnitBasedFromDetails(details: Record<string, unknown>, fallback: UnitBased): UnitBased {
  const ub = details.unitBased;
  if (ub === 'mobile_unit_based' || ub === 'mobile' || ub === 'unit') return ub;
  if (details.account_mode === 'physical') return 'unit';
  return fallback;
}

function onboardingNextButtonLabel(isLastStep: boolean, questionnaireComplete: boolean): string {
  if (isLastStep) {
    return questionnaireComplete ? 'Continue to Stripe Connect' : 'Complete questionnaire first';
  }
  return 'Next';
}

export default function ValeterOnboarding() {
  const { user, updateUser } = useAuth();
  const insets = useSafeAreaInsets();
  const [currentStep, setCurrentStep] = useState(0);
  const [questionnaireVisible, setQuestionnaireVisible] = useState(false);
  const [questionnaireComplete, setQuestionnaireComplete] = useState(false);
  const [questionnaireAnswers, setQuestionnaireAnswers] = useState<QuestionnaireAnswers>({
    keepCustomers: null,
    keepCalendarAvailability: null,
    shareContactDetails: null,
    unitBased: 'mobile_unit_based',
    hasBusinessInsurance: null,
    insuranceProvider: '',
    insuranceType: '',
    policyNumber: '',
  });
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const scaleAnim = useRef(new Animated.Value(0.9)).current;

  const steps = [
    {
      id: 'welcome-team',
      title: "Welcome to the Wish a Wash Team!",
      subtitle: "Your professional valeting journey begins here",
      description: "You're now part of an elite network of professional valeters. Get ready to build your business and deliver exceptional service to customers.",
      icon: 'sparkles',
      color: VALETER_PRIMARY,
      showLogo: true,
    },
    {
      id: 'flexible-earnings',
      title: "Flexible Work, Maximum Earnings",
      subtitle: "Work when you want, earn what you deserve",
      description: "Set your own schedule and keep up to 85% of your earnings. Build your business on your terms.",
      icon: 'wallet',
      color: VALETER_PRIMARY_ALT,
      showLogo: false,
    },
    {
      id: 'tools-support',
      title: "Professional Tools & Support",
      subtitle: "Everything you need to succeed",
      description: "Access to professional equipment, training resources, and dedicated support. We're here to help you grow your valeting business.",
      icon: 'construct',
      color: VALETER_PRIMARY,
      showLogo: false,
    },
    {
      id: 'reputation',
      title: "Build Your Reputation",
      subtitle: "Earn reviews and grow your customer base",
      description: "Every satisfied customer helps build your reputation. Great reviews lead to more bookings and higher earnings potential.",
      icon: 'star',
      color: VALETER_PRIMARY_ALT,
      showLogo: false,
    },
    {
      id: 'rewards',
      title: "Rewards & Recognition",
      subtitle: "Earn points and unlock exclusive benefits",
      description: "Complete washes, earn positive reviews, and unlock rewards like equipment upgrades, training courses, and priority support.",
      icon: 'trophy',
      color: VALETER_PRIMARY,
      showLogo: false,
    },
    {
      id: 'ready-start',
      title: "You're Ready to Start!",
      subtitle: "Your professional journey awaits",
      description: "Your account is set up and ready! Go online to start accepting bookings and begin your journey as a Wish a Wash professional.",
      icon: 'rocket',
      color: VALETER_PRIMARY_ALT,
      showLogo: false,
    },
    {
      id: 'track-progress',
      title: "Track Your Progress",
      subtitle: "Monitor your performance and earnings",
      description: "View detailed analytics, track your earnings, see customer ratings, and monitor your progress towards rewards and recognition.",
      icon: 'stats-chart',
      color: VALETER_PRIMARY,
      showLogo: false,
    },
    {
      id: 'get-started',
      title: "Let's Get Started!",
      subtitle: "Your success story begins now",
      description: "Everything is set up perfectly. Go online, accept your first booking, and start building your reputation as a professional valeter.",
      icon: 'checkmark-circle',
      color: VALETER_PRIMARY_ALT,
      showLogo: false,
    }
  ];

  useEffect(() => {
    animateStep();
  }, [currentStep]);

  useEffect(() => {
    let cancelled = false;

    const loadQuestionnaireState = async () => {
      try {
        if (!user?.id) {
          if (!cancelled) setQuestionnaireComplete(false);
          return;
        }

        const record = await termsAgreementService.load('valeter', user.id);
        const details = record.details || {};
        const completed = record.status === 'accepted';
        if (cancelled) return;
        setQuestionnaireComplete(completed);
        if (completed) {
          setQuestionnaireAnswers((prev) => ({
            ...prev,
            keepCustomers:
              details.keepCustomers === 'yes' || details.keepCustomers === 'no' ? details.keepCustomers : prev.keepCustomers,
            keepCalendarAvailability:
              details.keepCalendarAvailability === 'yes' || details.keepCalendarAvailability === 'no'
                ? details.keepCalendarAvailability
                : prev.keepCalendarAvailability,
            shareContactDetails:
              details.shareContactDetails === 'yes' || details.shareContactDetails === 'no'
                ? details.shareContactDetails
                : prev.shareContactDetails,
            unitBased: resolveUnitBasedFromDetails(details, prev.unitBased ?? 'mobile_unit_based'),
            hasBusinessInsurance:
              details.hasBusinessInsurance === 'yes' || details.hasBusinessInsurance === 'no'
                ? details.hasBusinessInsurance
                : prev.hasBusinessInsurance,
            insuranceProvider: typeof details.insuranceProvider === 'string' ? details.insuranceProvider : prev.insuranceProvider,
            insuranceType: typeof details.insuranceType === 'string' ? details.insuranceType : prev.insuranceType,
            policyNumber: typeof details.policyNumber === 'string' ? details.policyNumber : prev.policyNumber,
          }));
          await AsyncStorage.setItem(QUESTIONNAIRE_STORAGE_KEY, 'true');
        } else {
          await AsyncStorage.removeItem(QUESTIONNAIRE_STORAGE_KEY);
        }
      } catch (error) {
        console.warn('[ValeterOnboarding] questionnaire load error:', error);
      }
    };

    loadQuestionnaireState().catch(() => undefined);

    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  const animateStep = () => {
    fadeAnim.setValue(0);
    slideAnim.setValue(50);
    scaleAnim.setValue(0.9);

    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(scaleAnim, {
        toValue: 1,
        tension: 50,
        friction: 7,
        useNativeDriver: true,
      }),
    ]).start();
  };

  const completeOnboarding = async () => {
    try {
      if (user?.id) {
        await updateUser({ valeterOnboarded: true });
      }
      await AsyncStorage.setItem('valeter_onboarding_seen', 'true');
      await AsyncStorage.setItem('onboarding_seen', 'valeter');
      router.replace('/valeter/stripe-connect?mode=onboarding');
    } catch (error) {
      console.error('Error marking onboarding as seen:', error);
      try {
        if (user?.id) {
          await updateUser({ valeterOnboarded: true });
        }
        await AsyncStorage.setItem('valeter_onboarding_seen', 'true');
        await AsyncStorage.setItem('onboarding_seen', 'valeter');
      } catch {}
      router.replace('/valeter/stripe-connect?mode=onboarding');
    }
  };

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      completeOnboarding();
    }
  };

  const skipOnboarding = async () => {
    await hapticFeedback('light');
    completeOnboarding();
  };

  const updateQuestionnaire = <K extends keyof QuestionnaireAnswers>(
    key: K,
    value: QuestionnaireAnswers[K]
  ) => {
    setQuestionnaireAnswers((prev) => ({ ...prev, [key]: value }));
  };

  const questionnaireCanSubmit = () => {
    const a = questionnaireAnswers;
    const yesNoComplete =
      a.keepCustomers !== null && a.keepCalendarAvailability !== null && a.shareContactDetails !== null;
    const insuranceDetailsComplete = valeterInsuranceDetailsComplete(
      a.hasBusinessInsurance,
      a.insuranceProvider,
      a.insuranceType,
      a.policyNumber
    );
    return yesNoComplete && a.unitBased !== null && insuranceDetailsComplete;
  };

  const questionnaireCanAttemptContinue = () => {
    const a = questionnaireAnswers;
    const yesNoComplete =
      a.keepCustomers !== null && a.keepCalendarAvailability !== null && a.shareContactDetails !== null;
    if (!yesNoComplete || a.unitBased === null || a.hasBusinessInsurance === null) return false;
    if (a.hasBusinessInsurance === 'yes') {
      return valeterInsuranceDetailsComplete(
        a.hasBusinessInsurance,
        a.insuranceProvider,
        a.insuranceType,
        a.policyNumber
      );
    }
    return true;
  };

  const openQuestionnaire = async () => {
    await hapticFeedback('light');
    setQuestionnaireVisible(true);
  };

  const completeQuestionnaire = async () => {
    if (questionnaireAnswers.hasBusinessInsurance !== 'yes') {
      await hapticFeedback('medium');
      showValeterInsuranceRequiredAlert();
      return;
    }
    if (!questionnaireCanSubmit()) return;
    await hapticFeedback('medium');
    const questionnairePayload = {
      questionnaire_type: 'valeter_onboarding_questionnaire',
      account_mode: questionnaireAnswers.unitBased === 'unit' ? 'physical' : 'mobile_based',
      keepCustomers: questionnaireAnswers.keepCustomers,
      keepCalendarAvailability: questionnaireAnswers.keepCalendarAvailability,
      shareContactDetails: questionnaireAnswers.shareContactDetails,
      unitBased: questionnaireAnswers.unitBased,
      hasBusinessInsurance: questionnaireAnswers.hasBusinessInsurance,
      insuranceProvider: questionnaireAnswers.insuranceProvider,
      insuranceType: questionnaireAnswers.insuranceType,
      policyNumber: questionnaireAnswers.policyNumber,
    };
    if (user?.id) {
      await termsAgreementService.saveQuestionnaire('valeter', user.id, 'v1.0', questionnairePayload);
    }
    await AsyncStorage.setItem(QUESTIONNAIRE_STORAGE_KEY, 'true');
    await AsyncStorage.setItem(
      'valeter_onboarding_questionnaire_answers',
      JSON.stringify(questionnaireAnswers)
    );
    setQuestionnaireComplete(true);
    setQuestionnaireVisible(false);
  };

  const currentStepData = steps[currentStep];
  const videoRef = useRef<Video>(null);

  useEffect(() => {
    // Play video in loop when component mounts
    const playVideo = async () => {
      try {
        if (videoRef.current) {
          await videoRef.current.loadAsync(require('../../assets/onboarding.mp4'));
          await videoRef.current.playAsync();
          videoRef.current.setIsLoopingAsync(true);
          videoRef.current.setIsMutedAsync(true);
        }
      } catch (error) {
        console.error('Error playing video:', error);
      }
    };
    
    playVideo();
    
    return () => {
      // Cleanup on unmount
      videoRef.current?.unloadAsync();
    };
  }, []);

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={MODERN_BG} />
      
      {/* Video Background */}
      <Video
        ref={videoRef}
        source={require('../../assets/onboarding.mp4')}
        style={styles.videoBackground}
        resizeMode={ResizeMode.COVER}
        isLooping
        isMuted
        shouldPlay
        useNativeControls={false}
      />
      
      {/* Dark overlay - minimal for brightness */}
      <View style={styles.overlay} />
      
      {/* Gradient overlay - very minimal for sharp, bright video */}
      <LinearGradient 
        colors={['rgba(10,25,41,0.05)', 'rgba(37,99,235,0.08)']}
        style={styles.gradientOverlay} 
      />

      {/* Floating Header */}
      <ValeterScreenHeader
        title="Welcome to Wish a Wash"
        showBack={false}
       
        rightAction={
          <View style={styles.headerRightContent}>
            <View style={styles.progressContainer}>
              {steps.map((step, index) => (
                <View
                  key={step.id}
                  style={[
                    styles.progressDot,
                    index === currentStep && styles.progressDotActive,
                    index < currentStep && styles.progressDotCompleted
                  ]}
                />
              ))}
            </View>
            <TouchableOpacity onPress={skipOnboarding} style={styles.skipButton}>
              <Text style={styles.skipText}>Skip</Text>
            </TouchableOpacity>
          </View>
        }
      />

      {/* Content */}
      <ScrollView 
        style={styles.content} 
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[styles.contentContainer, { paddingTop: HEADER_CONTENT_OFFSET }]}
      >
        <Animated.View
          style={[
            styles.stepContainer,
            {
              opacity: fadeAnim,
              transform: [
                { translateY: slideAnim },
                { scale: scaleAnim }
              ],
            },
          ]}
        >
          <View style={styles.heroPanel}>
            <View style={styles.heroHeaderRow}>
              <View style={styles.heroPill}>
                <Ionicons name="sparkles-outline" size={14} color={VALETER_PRIMARY} />
                <Text style={styles.heroPillText}>{`Step ${currentStep + 1} of ${steps.length}`}</Text>
              </View>
              <View style={styles.heroMiniBadge}>
                <Text style={styles.heroMiniBadgeText}>Valeter onboarding</Text>
              </View>
            </View>

            <Text style={styles.heroEyebrow}>{currentStepData.subtitle}</Text>

            <View style={styles.iconContainer}>
              {currentStepData.showLogo ? (
                <BlurView intensity={30} tint="dark" style={styles.logoBlurContainer}>
                  <Image
                    source={require('../../assets/icon-auth.png')}
                    style={styles.logoImage}
                    resizeMode="cover"
                  />
                </BlurView>
              ) : (
                <BlurView intensity={20} tint="dark" style={styles.iconBlurContainer}>
                  <View style={[styles.iconWrapper, {
                    backgroundColor: currentStepData.color + '25',
                    borderColor: currentStepData.color + '60',
                  }]}>
                    <Ionicons name={currentStepData.icon as any} size={72} color={currentStepData.color} />
                  </View>
                </BlurView>
              )}
            </View>

            <Text style={styles.stepTitle}>{currentStepData.title}</Text>
            <Text style={styles.stepDescription}>{currentStepData.description}</Text>

            <View style={styles.heroFooterRow}>
              <View style={[styles.heroDot, { backgroundColor: VALETER_PRIMARY }]} />
              <Text style={styles.heroFooterText}>Your setup carries through to Stripe Connect next.</Text>
            </View>
          </View>

          {currentStep === steps.length - 1 ? (
            <TouchableOpacity
              onPress={openQuestionnaire}
              style={styles.questionnaireButton}
              activeOpacity={0.9}
            >
              <Text style={styles.questionnaireButtonText}>Onboarding questionnaire</Text>
              <Ionicons name="create-outline" size={18} color={VALETER_PRIMARY} />
            </TouchableOpacity>
          ) : null}

        </Animated.View>
      </ScrollView>

      {/* Footer */}
      <View style={[styles.footer, { paddingBottom: insets.bottom + 16 }]}>
        <TouchableOpacity
          style={styles.nextButton}
          onPress={nextStep}
          activeOpacity={0.8}
          disabled={currentStep === steps.length - 1 && !questionnaireComplete}
        >
          <LinearGradient
            colors={[VALETER_PRIMARY, VALETER_PRIMARY_ALT]}
            style={styles.nextButtonGradient}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
          >
            <Text style={styles.nextButtonText}>
              {onboardingNextButtonLabel(currentStep === steps.length - 1, questionnaireComplete)}
            </Text>
            <Ionicons
              name={currentStep === steps.length - 1 && !questionnaireComplete ? 'lock-closed' : 'arrow-forward'}
              size={20}
              color="#FFFFFF"
            />
          </LinearGradient>
        </TouchableOpacity>
      </View>

      <Modal
        visible={questionnaireVisible}
        transparent
        animationType="slide"
        onRequestClose={() => setQuestionnaireVisible(false)}
      >
        <View style={styles.modalBackdrop}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setQuestionnaireVisible(false)} />
          <ScrollView contentContainerStyle={styles.modalScrollContent} showsVerticalScrollIndicator={false}>
            <View style={styles.modalCard}>
              <View style={styles.modalHandle} />
              <Text style={styles.modalTitle}>Terms and conditions</Text>

              <View style={styles.questionBlock}>
                <Text style={styles.questionText}>
                  Do you agree to keep all customers you gain from Wish a Washer on the Wish a Washer app?
                </Text>
                <View style={styles.yesNoRow}>
                  {(['yes', 'no'] as YesNo[]).map((choice) => (
                    <TouchableOpacity
                      key={choice}
                      onPress={() => updateQuestionnaire('keepCustomers', choice)}
                      style={[
                        styles.choiceButton,
                        questionnaireAnswers.keepCustomers === choice && styles.choiceButtonActive,
                      ]}
                    >
                      <Text
                        style={[
                          styles.choiceButtonText,
                          questionnaireAnswers.keepCustomers === choice && styles.choiceButtonTextActive,
                        ]}
                      >
                        {choice === 'yes' ? 'Yes' : 'No'}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              <View style={styles.questionBlock}>
                <Text style={styles.questionText}>
                  It is your responsibility to keep your calendars availability up to date. Do you accept this responsibility?
                </Text>
                <View style={styles.yesNoRow}>
                  {(['yes', 'no'] as YesNo[]).map((choice) => (
                    <TouchableOpacity
                      key={choice}
                      onPress={() => updateQuestionnaire('keepCalendarAvailability', choice)}
                      style={[
                        styles.choiceButton,
                        questionnaireAnswers.keepCalendarAvailability === choice && styles.choiceButtonActive,
                      ]}
                    >
                      <Text
                        style={[
                          styles.choiceButtonText,
                          questionnaireAnswers.keepCalendarAvailability === choice && styles.choiceButtonTextActive,
                        ]}
                      >
                        {choice === 'yes' ? 'Yes' : 'No'}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              <View style={styles.questionBlock}>
                <Text style={styles.questionText}>
                  Do you agree to not share or promote your personal contact details to customers on the Wish a Washer app?
                </Text>
                <View style={styles.yesNoRow}>
                  {(['yes', 'no'] as YesNo[]).map((choice) => (
                    <TouchableOpacity
                      key={choice}
                      onPress={() => updateQuestionnaire('shareContactDetails', choice)}
                      style={[
                        styles.choiceButton,
                        questionnaireAnswers.shareContactDetails === choice && styles.choiceButtonActive,
                      ]}
                    >
                      <Text
                        style={[
                          styles.choiceButtonText,
                          questionnaireAnswers.shareContactDetails === choice && styles.choiceButtonTextActive,
                        ]}
                      >
                        {choice === 'yes' ? 'Yes' : 'No'}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              <View style={styles.questionBlock}>
                <Text style={styles.questionText}>Are you unit based? *</Text>
                <TouchableOpacity
                  onPress={() => updateQuestionnaire('unitBased', 'mobile_unit_based')}
                  style={styles.selectButton}
                  activeOpacity={0.9}
                >
                  <Text style={styles.selectButtonText}>Mobile + Unit Based</Text>
                  <Ionicons name="chevron-forward" size={20} color="rgba(34,34,34,0.45)" />
                </TouchableOpacity>
                <Text style={styles.helpText}>
                  Tap to keep the default selection for now. We can turn this into a picker later.
                </Text>
              </View>

              <View style={styles.questionBlock}>
                <Text style={styles.questionText}>Do you have business insurance? *</Text>
                <View style={styles.yesNoRow}>
                  {(['yes', 'no'] as YesNo[]).map((choice) => (
                    <TouchableOpacity
                      key={choice}
                      onPress={() => updateQuestionnaire('hasBusinessInsurance', choice)}
                      style={[
                        styles.choiceButton,
                        questionnaireAnswers.hasBusinessInsurance === choice && styles.choiceButtonActive,
                      ]}
                    >
                      <Text
                        style={[
                          styles.choiceButtonText,
                          questionnaireAnswers.hasBusinessInsurance === choice && styles.choiceButtonTextActive,
                        ]}
                      >
                        {choice === 'yes' ? 'Yes' : 'No'}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              {questionnaireAnswers.hasBusinessInsurance === 'yes' ? (
                <>
                  <View style={styles.questionBlock}>
                    <Text style={styles.questionText}>Who is your insurance provider? *</Text>
                    <TextInput
                      value={questionnaireAnswers.insuranceProvider}
                      onChangeText={(value) => updateQuestionnaire('insuranceProvider', value)}
                      placeholder="Insurance Provider"
                      placeholderTextColor="rgba(10,25,41,0.38)"
                      style={styles.textInput}
                    />
                  </View>

                  <View style={styles.questionBlock}>
                    <Text style={styles.questionText}>What type of insurance do you have? *</Text>
                    <TextInput
                      value={questionnaireAnswers.insuranceType}
                      onChangeText={(value) => updateQuestionnaire('insuranceType', value)}
                      placeholder="Insurance Type"
                      placeholderTextColor="rgba(10,25,41,0.38)"
                      style={styles.textInput}
                    />
                  </View>

                  <View style={styles.questionBlock}>
                    <Text style={styles.questionText}>What is your insurance policy number? *</Text>
                    <TextInput
                      value={questionnaireAnswers.policyNumber}
                      onChangeText={(value) => updateQuestionnaire('policyNumber', value)}
                      placeholder="Policy Number"
                      placeholderTextColor="rgba(10,25,41,0.38)"
                      style={styles.textInput}
                    />
                  </View>
                </>
              ) : null}

              <Text style={styles.termsFootnote}>
                By signing up you have read and are agreeable to our
                {'\n'}
                <Text style={styles.termsFootnoteLink}>Terms of Service & Privacy Policy</Text>
              </Text>

              <TouchableOpacity
                onPress={completeQuestionnaire}
                style={[
                  styles.modalPrimaryButton,
                  !questionnaireCanAttemptContinue() && styles.modalPrimaryButtonDisabled,
                ]}
                activeOpacity={0.9}
                disabled={!questionnaireCanAttemptContinue()}
              >
                <Text style={styles.modalPrimaryButtonText}>Continue</Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => setQuestionnaireVisible(false)}
                style={styles.modalSecondaryButton}
                activeOpacity={0.85}
              >
                <Text style={styles.modalSecondaryButtonText}>Close</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: MODERN_BG,
  },
  videoBackground: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    width: width,
    height: height,
    zIndex: 0,
    pointerEvents: 'none',
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.05)',
    zIndex: 1,
    pointerEvents: 'none',
  },
  gradientOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 2,
    pointerEvents: 'none',
  },
  skipButton: {
    paddingVertical: 8,
    paddingHorizontal: 14,
    backgroundColor: `${VALETER_PRIMARY}15`,
    borderWidth: 1,
    borderColor: `${VALETER_PRIMARY}30`,
    borderRadius: 10,
  },
  skipText: {
    fontFamily: 'Rubik_600SemiBold',
    color: VALETER_PRIMARY,
    fontSize: 14,
    letterSpacing: 0.2,
  },
  progressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  progressDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: `${VALETER_PRIMARY}25`,
  },
  progressDotActive: {
    backgroundColor: VALETER_PRIMARY,
    width: 24,
    height: 8,
    borderRadius: 4,
  },
  progressDotCompleted: {
    backgroundColor: VALETER_PRIMARY_ALT,
  },
  content: {
    flex: 1,
  },
  contentContainer: {
    paddingHorizontal: 24,
    paddingBottom: 20,
  },
  headerRightContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  stepContainer: {
    alignItems: 'center',
  },
  heroPanel: {
    width: '100%',
    borderRadius: 28,
    paddingHorizontal: 18,
    paddingVertical: 18,
    backgroundColor: 'rgba(10,25,41,0.52)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
    gap: 14,
  },
  heroHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: 10,
  },
  heroPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 999,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  heroPillText: {
    color: MODERN_TEXT_PRIMARY,
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.4,
  },
  heroMiniBadge: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 999,
    backgroundColor: `${VALETER_PRIMARY}18`,
    borderWidth: 1,
    borderColor: `${VALETER_PRIMARY}28`,
  },
  heroMiniBadgeText: {
    color: VALETER_PRIMARY,
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  heroEyebrow: {
    color: 'rgba(248,250,252,0.7)',
    fontSize: 13,
    fontWeight: '600',
    lineHeight: 18,
    textAlign: 'center',
  },
  iconContainer: {
    marginBottom: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoBlurContainer: {
    width: 180,
    height: 180,
    borderRadius: 90,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    elevation: 12,
  },
  logoImage: {
    width: '100%',
    height: '100%',
    borderRadius: 90,
  },
  iconBlurContainer: {
    width: 180,
    height: 180,
    borderRadius: 90,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    elevation: 12,
  },
  iconWrapper: {
    width: '100%',
    height: '100%',
    borderRadius: 90,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
  },
  stepTitle: {
    fontFamily: 'Rubik_600SemiBold',
    color: MODERN_TEXT_PRIMARY,
    fontSize: isSmallScreen ? 26 : 30,
    textAlign: 'center',
    marginBottom: 16,
    lineHeight: 36,
    letterSpacing: -0.3,
  },
  stepDescription: {
    fontFamily: 'Rubik_400Regular',
    color: MODERN_TEXT_SECONDARY,
    fontSize: isSmallScreen ? 16 : 17,
    textAlign: 'center',
    lineHeight: 26,
    paddingHorizontal: 20,
    letterSpacing: 0,
  },
  heroFooterRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    alignSelf: 'center',
    marginTop: 2,
  },
  heroDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  heroFooterText: {
    color: 'rgba(248,250,252,0.72)',
    fontSize: 12,
    lineHeight: 16,
    fontWeight: '600',
    textAlign: 'center',
  },
  footer: {
    paddingTop: 20,
  },
  nextButton: {
    borderRadius: 14,
    overflow: 'hidden',
    marginHorizontal: 24,
    shadowColor: VALETER_PRIMARY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.5,
    shadowRadius: 12,
    elevation: 10,
  },
  nextButtonDisabled: {
    opacity: 0.45,
  },
  nextButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    paddingHorizontal: 32,
  },
  nextButtonText: {
    fontFamily: 'Rubik_600SemiBold',
    color: '#FFFFFF',
    fontSize: 16,
    letterSpacing: 0.2,
  },
  questionnaireButton: {
    marginTop: 20,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(37,99,235,0.22)',
    backgroundColor: 'rgba(255,255,255,0.08)',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  questionnaireButtonText: {
    color: VALETER_PRIMARY,
    fontSize: 14,
    fontWeight: '700',
  },
  modalBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(2, 6, 23, 0.82)',
    justifyContent: 'flex-end',
  },
  modalScrollContent: {
    paddingTop: 80,
  },
  modalCard: {
    backgroundColor: 'rgba(10, 18, 32, 0.98)',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingHorizontal: 20,
    paddingTop: 10,
    paddingBottom: 24,
    borderTopWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  modalHandle: {
    alignSelf: 'center',
    width: 42,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(255,255,255,0.18)',
    marginBottom: 14,
  },
  modalTitle: {
    color: '#F8FAFC',
    fontSize: 22,
    fontWeight: '800',
    marginBottom: 8,
  },
  questionBlock: {
    marginBottom: 18,
  },
  questionText: {
    color: '#F8FAFC',
    fontSize: 18,
    lineHeight: 26,
    fontWeight: '600',
    marginBottom: 14,
  },
  yesNoRow: {
    flexDirection: 'row',
    gap: 12,
  },
  choiceButton: {
    flex: 1,
    minHeight: 58,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
  },
  choiceButtonActive: {
    backgroundColor: 'rgba(253,176,34,0.92)',
    borderColor: 'rgba(253,176,34,1)',
  },
  choiceButtonText: {
    color: '#E2E8F0',
    fontSize: 18,
    fontWeight: '500',
  },
  choiceButtonTextActive: {
    color: '#111827',
    fontWeight: '600',
  },
  selectButton: {
    minHeight: 60,
    borderRadius: 16,
    paddingHorizontal: 18,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  selectButtonText: {
    color: '#F8FAFC',
    fontSize: 18,
    fontWeight: '500',
  },
  helpText: {
    marginTop: 10,
    color: 'rgba(248,250,252,0.6)',
    fontSize: 12,
    lineHeight: 18,
  },
  textInput: {
    minHeight: 60,
    borderRadius: 16,
    paddingHorizontal: 18,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
    color: '#F8FAFC',
    fontSize: 18,
  },
  termsFootnote: {
    marginTop: 2,
    marginBottom: 18,
    color: 'rgba(248,250,252,0.68)',
    fontSize: 14,
    lineHeight: 20,
    textAlign: 'center',
  },
  termsFootnoteLink: {
    color: '#FDB022',
    fontWeight: '600',
  },
  modalPrimaryButton: {
    minHeight: 48,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FDE047',
    marginBottom: 10,
  },
  modalPrimaryButtonDisabled: {
    backgroundColor: 'rgba(253,224,71,0.42)',
  },
  modalPrimaryButtonText: {
    color: '#111827',
    fontSize: 15,
    fontWeight: '800',
  },
  modalSecondaryButton: {
    minHeight: 48,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
  },
  modalSecondaryButtonText: {
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '700',
  },
});
