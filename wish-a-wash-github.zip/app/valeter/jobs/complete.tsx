import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Dimensions,
  Animated,
  StatusBar,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import MapView, { Marker } from 'react-native-maps';
import { router, useLocalSearchParams } from 'expo-router';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { fetchProfileById } from '../../../src/utils/customerProfiles';
import ValeterScreenHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/valeter/ValeterScreenHeader';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { colors } from '../../../src/constants/colors';
import { VALETER_CONTENT_BOTTOM_PAD } from '../../../src/components/valeter/ValeterNavSidebar';
import { HEADER_STYLE_CARD_GRADIENT, HEADER_STYLE_CARD_BORDER, BOOKING_SHEET_DARK_OVERLAY } from '../../../src/constants/bookingCardTheme';
import { DARK_MAP_STYLE } from '../../../src/constants/mapStyles';
import { CAR_IMAGE } from '../../../src/constants/washerAssets';
import { themeBackgroundGradient } from '../../../src/utils/themeGradient';

const { width } = Dimensions.get('window');
const SKY = colors.SKY;
const BG = colors.BG;
const VALETER_BG_FALLBACK: [string, string] = ['#0A1929', '#2563EB'];

const RATING_LABELS: Record<number, string> = {
  1: 'Poor',
  2: 'Fair',
  3: 'Good',
  4: 'Very good',
  5: 'Excellent',
};

type CompletedJob = {
  location_lat?: number | string | null;
  location_lng?: number | string | null;
  location_address?: string | null;
  service_type?: string | null;
  service_name?: string | null;
  price?: number | string | null;
  valeter_rating?: number | null;
  user_id?: string | null;
};

function toOpaqueColor(s: string, alpha: number): string {
  if (s.includes('rgba')) {
    return s.replace(/,\s*[\d.]+\)$/, `, ${alpha})`);
  }
  return alpha === 1 ? `${s}FF` : `${s}EE`;
}

function resolveJobIdParam(jobId: string | string[] | undefined): string {
  if (typeof jobId === 'string') return jobId;
  if (Array.isArray(jobId)) return jobId[0] ?? '';
  return '';
}

export default function JobComplete() {
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const gradientBg = themeBackgroundGradient(theme?.background, VALETER_BG_FALLBACK);
  const params = useLocalSearchParams();
  const jobId = resolveJobIdParam(params.jobId);

  const [job, setJob] = useState<CompletedJob | null>(null);
  const [customerName, setCustomerName] = useState('Customer');
  const [customerRating, setCustomerRating] = useState<number>(0);
  const [ratingSaved, setRatingSaved] = useState(false);
  const [savingRating, setSavingRating] = useState(false);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const successScale = useRef(new Animated.Value(0)).current;

  const accent = theme?.primary ?? SKY;
  const rawSheet = themeBackgroundGradient(theme?.headerBackground, HEADER_STYLE_CARD_GRADIENT);
  const sheetGradient: [string, string] = [
    toOpaqueColor(rawSheet[0], 1),
    toOpaqueColor(rawSheet[1] || rawSheet[0], 0.93),
  ];
  const sheetBorder = theme?.glassBorder ?? HEADER_STYLE_CARD_BORDER;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.spring(successScale, { toValue: 1, tension: 50, friction: 7, useNativeDriver: true }),
    ]).start();
    loadJob();
  }, [jobId]);

  const loadJob = async () => {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('id', jobId)
        .single();

      if (error) throw error;
      setJob(data);
      if (data?.valeter_rating != null) {
        setCustomerRating(Number(data.valeter_rating));
        setRatingSaved(true);
      }
      if (data?.user_id) {
        const profile = await fetchProfileById(data.user_id);
        setCustomerName(profile?.full_name || 'Customer');
      } else {
        setCustomerName('Customer');
      }
    } catch (error) {
      console.error('Error loading job:', error);
    }
  };

  const handleRateCustomer = async (stars: number) => {
    if (ratingSaved || !jobId) return;
    hapticFeedback('light');
    setCustomerRating(stars);
    setSavingRating(true);
    try {
      const { error } = await supabase
        .from('bookings')
        .update({ valeter_rating: stars })
        .eq('id', jobId);
      if (error) throw error;
      setRatingSaved(true);
    } catch (e) {
      console.error('Error saving rating:', e);
    } finally {
      setSavingRating(false);
    }
  };

  const handleBackToQueue = () => {
    hapticFeedback('light');
    router.replace('/valeter/jobs');
  };

  const jobLat = job?.location_lat == null ? null : Number(job.location_lat);
  const jobLng = job?.location_lng == null ? null : Number(job.location_lng);
  const hasLocation = jobLat != null && jobLng != null;
  const mapRegion = hasLocation
    ? { latitude: jobLat, longitude: jobLng, latitudeDelta: 0.008, longitudeDelta: 0.008 }
    : { latitude: 51.5074, longitude: -0.1278, latitudeDelta: 0.05, longitudeDelta: 0.05 };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <StatusBar barStyle="light-content" backgroundColor={BG} />
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />

      <ValeterScreenHeader title="Job complete" showBack={false} />

      <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[
            styles.scrollContent,
            {
              paddingTop: HEADER_CONTENT_OFFSET,
              paddingBottom: VALETER_CONTENT_BOTTOM_PAD + insets.bottom + 24,
            },
          ]}
        >
          {/* Success */}
          <Animated.View style={[styles.successContainer, { transform: [{ scale: successScale }] }]}>
            <View style={[styles.successCircle, { borderColor: accent + '60' }]}>
              <Ionicons name="checkmark-done-circle" size={64} color="#10B981" />
            </View>
            <Text style={styles.successTitle}>Well done!</Text>
            <Text style={[styles.successSubtitle, { color: accent }]}>Job completed successfully</Text>
          </Animated.View>

          {/* Map card – job location */}
          {job && (
            <View style={[styles.card, { borderColor: sheetBorder }]}>
              <BlurView intensity={24} tint="dark" style={StyleSheet.absoluteFill} />
              <LinearGradient colors={sheetGradient} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1 }} style={StyleSheet.absoluteFill} />
              <View style={[StyleSheet.absoluteFill, styles.cardOverlay]} />
              <View style={styles.cardHeader}>
                <Ionicons name="location" size={20} color={accent} />
                <Text style={[styles.cardTitle, { color: accent }]}>Job location</Text>
              </View>
              <View style={styles.mapWrap}>
                <MapView
                  style={styles.map}
                  region={mapRegion}
                  scrollEnabled={false}
                  zoomEnabled={false}
                  pitchEnabled={false}
                  rotateEnabled={false}
                  customMapStyle={DARK_MAP_STYLE}
                >
                  {hasLocation && jobLat != null && jobLng != null && (
                    <Marker
                      coordinate={{ latitude: jobLat, longitude: jobLng }}
                      title={job?.location_address || 'Job'}
                      anchor={{ x: 0.5, y: 1 }}
                    >
                      <View style={styles.markerWrap}>
                        <Image source={CAR_IMAGE} style={styles.markerCarImage} resizeMode="contain" />
                      </View>
                    </Marker>
                  )}
                </MapView>
              </View>
              {job?.location_address ? (
                <Text style={styles.mapAddress} numberOfLines={2}>{job.location_address}</Text>
              ) : null}
            </View>
          )}

          {/* Job summary card */}
          {job && (
            <View style={[styles.card, { borderColor: sheetBorder }]}>
              <BlurView intensity={24} tint="dark" style={StyleSheet.absoluteFill} />
              <LinearGradient colors={sheetGradient} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1 }} style={StyleSheet.absoluteFill} />
              <View style={[StyleSheet.absoluteFill, styles.cardOverlay]} />
              <View style={styles.cardHeader}>
                <Ionicons name="wallet-outline" size={20} color={accent} />
                <Text style={[styles.cardTitle, { color: accent }]}>Job summary</Text>
              </View>
              <View style={styles.summaryRows}>
                <View style={styles.summaryRow}>
                  <Text style={styles.summaryLabel}>Service</Text>
                  <Text style={styles.summaryValue}>{getServiceDisplayName(job.service_type, job.service_name)}</Text>
                </View>
                <View style={styles.summaryRow}>
                  <Text style={styles.summaryLabel}>Earnings</Text>
                  <Text style={[styles.summaryValue, { color: accent }]}>£{Number(job.price || 0).toFixed(2)}</Text>
                </View>
                <View style={styles.summaryRow}>
                  <Text style={styles.summaryLabel}>Customer</Text>
                  <Text style={styles.summaryValue}>{customerName}</Text>
                </View>
              </View>
            </View>
          )}

          {/* Star rating – rate the customer */}
          {job && (
            <View style={[styles.card, { borderColor: sheetBorder }]}>
              <BlurView intensity={24} tint="dark" style={StyleSheet.absoluteFill} />
              <LinearGradient colors={sheetGradient} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1 }} style={StyleSheet.absoluteFill} />
              <View style={[StyleSheet.absoluteFill, styles.cardOverlay]} />
              <View style={styles.cardHeader}>
                <Ionicons name="star" size={20} color="#FBBF24" />
                <Text style={[styles.cardTitle, { color: '#FBBF24' }]}>Rate this customer</Text>
              </View>
              <View style={styles.starsRow}>
                {[1, 2, 3, 4, 5].map((star) => (
                  <TouchableOpacity
                    key={star}
                    onPress={() => handleRateCustomer(star)}
                    disabled={ratingSaved || savingRating}
                    style={styles.starBtn}
                    activeOpacity={0.8}
                  >
                    <Ionicons
                      name={customerRating >= star ? 'star' : 'star-outline'}
                      size={36}
                      color={customerRating >= star ? '#FBBF24' : 'rgba(148,163,184,0.5)'}
                    />
                  </TouchableOpacity>
                ))}
              </View>
              <Text style={styles.ratingLabel}>
                {customerRating === 0 && 'Tap to rate'}
                {customerRating > 0 && (RATING_LABELS[customerRating] ?? `${customerRating} stars`)}
                {ratingSaved && ' · Saved'}
              </Text>
            </View>
          )}

          {/* Celebration */}
          <View style={[styles.card, styles.celebrationCard, { borderColor: accent + '50' }]}>
            <BlurView intensity={20} tint="dark" style={StyleSheet.absoluteFill} />
            <LinearGradient colors={sheetGradient} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1 }} style={StyleSheet.absoluteFill} />
            <View style={[StyleSheet.absoluteFill, styles.cardOverlay]} />
            <View style={styles.celebrationContent}>
              <Ionicons name="trophy" size={40} color="#FBBF24" />
              <Text style={styles.celebrationTitle}>Great job!</Text>
              <Text style={styles.celebrationText}>You've earned this completion. Keep it up.</Text>
            </View>
          </View>

          {/* Back to jobs */}
          <TouchableOpacity onPress={handleBackToQueue} style={styles.backButton} activeOpacity={0.85}>
            <LinearGradient colors={[SKY, '#3B82F6']} style={styles.backGradient}>
              <Text style={styles.backText}>Back to jobs</Text>
              <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
            </LinearGradient>
          </TouchableOpacity>
        </ScrollView>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingTop: 16,
  },
  successContainer: {
    alignItems: 'center',
    marginBottom: 24,
  },
  successCircle: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: 'rgba(16,185,129,0.2)',
    borderWidth: 2,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  successTitle: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: '800',
    marginBottom: 4,
  },
  successSubtitle: {
    fontSize: 15,
    fontWeight: '600',
  },
  card: {
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    marginBottom: 16,
    padding: 16,
  },
  cardOverlay: {
    backgroundColor: BOOKING_SHEET_DARK_OVERLAY,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
    zIndex: 1,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: '800',
  },
  mapWrap: {
    height: 160,
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 10,
    zIndex: 1,
  },
  map: {
    width: '100%',
    height: '100%',
  },
  mapAddress: {
    fontSize: 12,
    color: '#94A3B8',
    zIndex: 1,
  },
  markerWrap: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  markerCarImage: { width: 36, height: 36 },
  summaryRows: {
    gap: 10,
    zIndex: 1,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  summaryLabel: {
    color: '#94A3B8',
    fontSize: 14,
  },
  summaryValue: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '700',
  },
  starsRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 8,
    marginBottom: 8,
    zIndex: 1,
  },
  starBtn: {
    padding: 4,
  },
  ratingLabel: {
    fontSize: 13,
    color: '#94A3B8',
    textAlign: 'center',
    zIndex: 1,
  },
  celebrationCard: {
    padding: 20,
  },
  celebrationContent: {
    alignItems: 'center',
    zIndex: 1,
  },
  celebrationTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    marginTop: 10,
    marginBottom: 4,
  },
  celebrationText: {
    color: '#E5E7EB',
    fontSize: 14,
    textAlign: 'center',
  },
  backButton: {
    width: '100%',
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  backGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 32,
    gap: 8,
  },
  backText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '800',
  },
});
