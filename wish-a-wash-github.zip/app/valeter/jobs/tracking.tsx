/**
 * Valeter job tracking – same UI as business booking tracking.
 * Full-screen map + inline bottom sheet with tracking progress, status action, and chat.
 */
import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  Dimensions,
  Animated,
  PanResponder,
  Image,
  type GestureResponderHandlers,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import MapView, { Marker, Polyline, Region } from 'react-native-maps';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { ValeterStatsService } from '../../../src/services/Valeterstatsservice';
import ValeterScreenHeader from '../../../src/components/valeter/ValeterScreenHeader';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import InfoBottomSheet from '../../../src/components/shared/InfoBottomSheet';
import AnimatedProgress from '../../../src/components/booking/AnimatedProgress';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { fetchProfileById } from '../../../src/utils/customerProfiles';
import { colors } from '../../../src/constants/colors';
import { GOOGLE_MAPS_API_KEY } from '../../../src/config/google-maps';
import LoadingScreen from '../../../src/components/LoadingScreen';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { DARK_MAP_STYLE } from '../../../src/constants/mapStyles';
import { HEADER_STYLE_CARD_GRADIENT, HEADER_STYLE_CARD_BORDER, BOOKING_SHEET_DARK_OVERLAY, BOOKING_SHEET_BLUR_INTENSITY } from '../../../src/constants/bookingCardTheme';
import { themeBackgroundGradient } from '../../../src/utils/themeGradient';
import {
  getStages,
  getStageProgressPercent,
  type StageItem,
} from '../../../src/utils/trackingStatusHelpers';
import { promptAndSendBookingPhotoMessage } from '../../../src/services/bookingChatMediaService';

const polyline = require('@mapbox/polyline');

const { height } = Dimensions.get('window');
const SKY = colors.SKY ?? '#38BDF8';

/** Valeter tracking sheet: ~40% of screen so card + vehicle + actions fit */
const TRACKING_SHEET_MAX_HEIGHT_RATIO = 0.4;
const SHEET_HEIGHT = height * TRACKING_SHEET_MAX_HEIGHT_RATIO;
const ACTIONS_BAR_HEIGHT = 52;
const TOTAL_SHEET_HEIGHT = SHEET_HEIGHT + ACTIONS_BAR_HEIGHT;
const DRAG_CLOSE_THRESHOLD = 80;
const DRAG_VELOCITY_THRESHOLD = 0.3;
const MAX_PEEK_DRAG = 48; // slight drag only; full swipe still closes

type JobStatus =
  | 'pending_valeter_acceptance'
  | 'pending_payment'
  | 'confirmed'
  | 'scheduled'
  | 'en_route'
  | 'arrived'
  | 'in_progress'
  | 'completed'
  | 'cancelled';

const ACTIVE_STATUSES: JobStatus[] = ['pending_valeter_acceptance', 'pending_payment', 'confirmed', 'en_route', 'arrived', 'in_progress'];

const DEFAULT_REGION: Region = {
  latitude: 51.5074,
  longitude: -0.1278,
  latitudeDelta: 0.05,
  longitudeDelta: 0.05,
};

type BookingJobRow = {
  id: string;
  status: JobStatus;
  user_id?: string | null;
  service_type?: string | null;
  service_name?: string | null;
  location_lat?: number | string | null;
  location_lng?: number | string | null;
  location_address?: string | null;
  price?: number | string | null;
  scheduled_at?: string | null;
  vehicle_registration?: string | null;
  vehicle_make?: string | null;
  vehicle_model?: string | null;
  vehicle_photo?: string | null;
};

function getJobProgress(status: JobStatus): number {
  switch (status) {
    case 'pending_valeter_acceptance':
    case 'pending_payment':
      return 10;
    case 'confirmed':
    case 'scheduled':
      return 25;
    case 'en_route':
      return 50;
    case 'arrived':
      return 70;
    case 'in_progress':
      return 90;
    case 'completed':
      return 100;
    case 'cancelled':
      return 0;
    default:
      return 20;
  }
}

function getJobStatusMessage(status: JobStatus): string {
  switch (status) {
    case 'pending_valeter_acceptance':
      return 'Accept the job — customer pays next';
    case 'pending_payment':
      return 'Awaiting customer payment';
    case 'confirmed':
    case 'scheduled':
      return 'Paid - ready to start journey';
    case 'en_route':
      return 'On the way to location';
    case 'arrived':
      return 'Arrived at location';
    case 'in_progress':
      return 'Service in progress';
    case 'completed':
      return 'Completed';
    case 'cancelled':
      return 'Cancelled';
    default:
      return 'Tracking job';
  }
}

function getTierForProgressValue(p: number): { color: string; glow: string } {
  if (p <= 25) return { color: '#F59E0B', glow: '#FBBF24' };
  if (p <= 50) return { color: '#8B5CF6', glow: '#A78BFA' };
  if (p <= 75) return { color: '#0EA5E9', glow: '#38BDF8' };
  return { color: '#10B981', glow: '#34D399' };
}

function haversineMi(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 3959;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function routerBack(router: { back: () => void; replace: (path: any) => void; canGoBack?: () => boolean }) {
  if (router.canGoBack?.()) {
    router.back();
    return;
  }
  router.replace('/valeter/valeter-dashboard');
}

async function loadVehicleDetailsForTracking(
  userId: string | null,
  setVehicleDetails: React.Dispatch<
    React.SetStateAction<{ registration?: string; make?: string; model?: string; photo?: string } | null>
  >
) {
  if (!userId) return;
  try {
    const { data } = await supabase
      .from('customer_vehicles')
      .select('registration, make, model, photo')
      .eq('user_id', userId)
      .eq('is_default', true)
      .limit(1)
      .maybeSingle();

    if (data) {
      const row = data as { registration?: string; make?: string; model?: string; photo?: string };
      const next: { registration?: string; make?: string; model?: string; photo?: string } = {};
      if (row.registration != null) next.registration = row.registration;
      if (row.make != null) next.make = row.make;
      if (row.model != null) next.model = row.model;
      if (row.photo != null) next.photo = row.photo;
      setVehicleDetails(next);
    }
  } catch (e) {
    console.warn('[JobTracking] loadVehicleDetails failed:', e);
  }
}

async function loadActiveJobForTracking(
  valeterId: string | null,
  setLoading: React.Dispatch<React.SetStateAction<boolean>>,
  setJob: React.Dispatch<React.SetStateAction<BookingJobRow | null>>,
  setStatus: React.Dispatch<React.SetStateAction<JobStatus>>,
  setCustomerName: React.Dispatch<React.SetStateAction<string>>,
  setRegion: React.Dispatch<React.SetStateAction<Region>>,
  setVehicleDetails: React.Dispatch<
    React.SetStateAction<{ registration?: string; make?: string; model?: string; photo?: string } | null>
  >
) {
  if (!valeterId) return;
  setLoading(true);
  try {
    const { data, error } = await supabase
      .from('bookings')
      .select('*')
      .eq('valeter_id', valeterId)
      .in('status', ACTIVE_STATUSES)
      .order('request_sent_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (error) throw error;
    if (data) {
      const row = data as BookingJobRow;
      setJob(row);
      setStatus(row.status);
      if (row.user_id) {
        const profile = await fetchProfileById(row.user_id);
        setCustomerName(profile?.full_name || 'Customer');
      }
      if (row.location_lat != null && row.location_lng != null) {
        setRegion({
          latitude: Number(row.location_lat),
          longitude: Number(row.location_lng),
          latitudeDelta: 0.012,
          longitudeDelta: 0.012,
        });
      }
      await loadVehicleDetailsForTracking(row.user_id ?? null, setVehicleDetails);
    }
  } catch (e) {
    console.error('Error loading active job:', e);
  } finally {
    setLoading(false);
  }
}

async function loadJobByIdForTracking(
  id: string,
  router: { back: () => void; replace: (path: any) => void; canGoBack?: () => boolean },
  setters: {
    setLoading: React.Dispatch<React.SetStateAction<boolean>>;
    setJob: React.Dispatch<React.SetStateAction<BookingJobRow | null>>;
    setStatus: React.Dispatch<React.SetStateAction<JobStatus>>;
    setCustomerName: React.Dispatch<React.SetStateAction<string>>;
    setRegion: React.Dispatch<React.SetStateAction<Region>>;
    setVehicleDetails: React.Dispatch<
      React.SetStateAction<{ registration?: string; make?: string; model?: string; photo?: string } | null>
    >;
  }
) {
  const {
    setLoading,
    setJob,
    setStatus,
    setCustomerName,
    setRegion,
    setVehicleDetails,
  } = setters;

  setLoading(true);
  try {
    const { data, error } = await supabase.from('bookings').select('*').eq('id', id).single();
    if (error || !data) {
      setLoading(false);
      Alert.alert('Error', 'Job not found');
      routerBack(router);
      return;
    }

    const row = data as BookingJobRow;
    setJob(row);
    setStatus(row.status);
    if (row.user_id) {
      const profile = await fetchProfileById(row.user_id);
      setCustomerName(profile?.full_name || 'Customer');
    }
    if (row.location_lat != null && row.location_lng != null) {
      setRegion({
        latitude: Number(row.location_lat),
        longitude: Number(row.location_lng),
        latitudeDelta: 0.012,
        longitudeDelta: 0.012,
      });
    }
    await loadVehicleDetailsForTracking(row.user_id ?? null, setVehicleDetails);
  } catch (e: any) {
    setLoading(false);
    Alert.alert('Error', e?.message ?? 'Failed to load job');
    routerBack(router);
  } finally {
    setLoading(false);
  }
}

async function acceptJobFromOfferForTracking(
  offerJobId: string | null,
  valeterId: string | null,
  setStatus: React.Dispatch<React.SetStateAction<JobStatus>>
) {
  if (!offerJobId || !valeterId) return;
  hapticFeedback('medium');
  try {
    const { error } = await supabase
      .from('bookings')
      .update({
        valeter_id: valeterId,
        status: 'pending_payment',
      })
      .eq('id', offerJobId);
    if (error) throw error;

    setStatus('pending_payment');
  } catch (e: any) {
    Alert.alert('Error', e?.message ?? 'Failed to accept job');
  }
}

async function updateJobStatusForTracking(
  newStatus: JobStatus,
  effectiveJobId: string | null,
  valeterId: string | null,
  setStatus: React.Dispatch<React.SetStateAction<JobStatus>>,
  router: { replace: (args: any) => void }
) {
  if (!effectiveJobId || !valeterId) return;
  hapticFeedback('medium');
  try {
    const payload: { status: string; completed_at?: string } = { status: newStatus };
    if (newStatus === 'completed') {
      payload.completed_at = new Date().toISOString();
    }

    const { error } = await supabase.from('bookings').update(payload).eq('id', effectiveJobId);
    if (error) throw error;

    setStatus(newStatus);
    if (newStatus === 'completed') {
      await ValeterStatsService.recordJobCompletion(valeterId, effectiveJobId);
      router.replace({ pathname: '/valeter/jobs/complete', params: { jobId: effectiveJobId } } as any);
    }
  } catch (e: any) {
    Alert.alert('Error', e?.message ?? 'Failed to update');
  }
}

function getNextActionForTracking(
  status: JobStatus,
  acceptJobFromOffer: () => void,
  updateStatus: (newStatus: JobStatus) => void,
  startWashWithPhoto: () => void,
  completeWashWithPhoto: () => void
): { label: string; action: () => void } | null {
  switch (status) {
    case 'pending_valeter_acceptance':
      return { label: 'Accept job', action: () => { acceptJobFromOffer(); } };
    case 'pending_payment':
      return null;
    case 'confirmed':
    case 'scheduled':
      return { label: 'Start journey', action: () => { updateStatus('en_route'); } };
    case 'en_route':
      return { label: 'Mark arrived', action: () => { updateStatus('arrived'); } };
    case 'arrived':
      return { label: 'Start wash', action: () => { startWashWithPhoto(); } };
    case 'in_progress':
      return { label: 'Mark complete', action: () => { completeWashWithPhoto(); } };
    default:
      return null;
  }
}

function cancelJobForTracking(args: {
  canCancel: boolean;
  effectiveJobId: string | null;
  setCancelling: React.Dispatch<React.SetStateAction<boolean>>;
  setStatus: React.Dispatch<React.SetStateAction<JobStatus>>;
  onOkPress: () => void;
}) {
  const { canCancel, effectiveJobId, setCancelling, setStatus, onOkPress } = args;
  if (!canCancel || !effectiveJobId) return;

  hapticFeedback('light');
  Alert.alert(
    'Cancel job',
    'Cancel this job? The customer will be notified.',
    [
      { text: 'No', style: 'cancel' },
      {
        text: 'Yes, cancel',
        style: 'destructive',
        onPress: () => {
          // Wrap async work so this callback itself stays `void`-returning.
          (async () => {
            setCancelling(true);
            const { error } = await supabase
              .from('bookings')
              .update({ status: 'cancelled' })
              .eq('id', effectiveJobId);
            if (error) {
              Alert.alert('Error', error.message);
            } else {
              setStatus('cancelled');
              Alert.alert('Cancelled', 'Job cancelled.', [{ text: 'OK', onPress: onOkPress }]);
            }
            setCancelling(false);
          })();
        },
      },
    ]
  );
}

type VehicleDetailsState = { registration?: string; make?: string; model?: string; photo?: string } | null;

type JobTrackingMainUIProps = Readonly<{
  themeBackground: readonly string[] | undefined;
  mapRegion: Region;
  setRegion: (region: Region) => void;
  customerCoords: { latitude: number; longitude: number } | null;
  routeCoordinates: { latitude: number; longitude: number }[] | null;
  dragOffset: Animated.Value;
  panHandlers: GestureResponderHandlers;
  sheetGradient: [string, string];
  sheetBorder: string;
  accent: string;
  onChat: () => void;
  onOpenInfo: () => void;
  fadeAnim: Animated.Value;
  cardPulseAnim: Animated.Value;
  job: BookingJobRow;
  status: JobStatus;
  statusMessage: string;
  etaMinutes: number | null;
  distanceMi: number | null;
  stages: StageItem[];
  stageProgressPercent: number;
  tier: { color: string; glow: string };
  vehicleDetails: VehicleDetailsState;
  nextAction: { label: string; action: () => void } | null;
  canCancel: boolean;
  cancelling: boolean;
  onCancel: () => void;
  infoSheetVisible: boolean;
  onCloseInfo: () => void;
  customerName: string;
}>;

function ValeterJobTrackingDetailsContent({
  accent,
  customerName,
  job,
  statusMessage,
  vehicleDetails,
}: Readonly<{
  accent: string;
  customerName: string;
  job: BookingJobRow;
  statusMessage: string;
  vehicleDetails: VehicleDetailsState;
}>) {
  return (
    <View style={styles.jobInfoProfile}>
      <View style={styles.jobInfoProfileHeader}>
        <View style={[styles.jobInfoAvatar, { borderColor: accent }]}>
          <Ionicons name="person" size={36} color={accent} />
        </View>
        <Text style={styles.jobInfoProfileName}>{customerName}</Text>
        <Text style={[styles.jobInfoProfileHeadline, { color: accent }]}>
          {getServiceDisplayName(job.service_type, job.service_name)}
        </Text>
        <View style={[styles.jobInfoProfileMeta, { backgroundColor: accent + '22', borderColor: accent + '44' }]}>
          <Ionicons name="person-circle-outline" size={14} color={accent} />
          <Text style={[styles.jobInfoOwnerLabel, { color: accent }]}>Customer</Text>
        </View>
      </View>

      <View style={[styles.jobInfoSection, { borderColor: accent + '30' }]}>
        <View style={styles.jobInfoSectionHeader}>
          <Ionicons name="time-outline" size={18} color={accent} />
          <Text style={[styles.jobInfoSectionTitle, { color: accent }]}>Status</Text>
        </View>
        <Text style={styles.jobInfoSectionText}>{statusMessage}</Text>
      </View>

      {vehicleDetails?.photo ? (
        <View style={[styles.jobInfoSection, { borderColor: accent + '30' }]}>
          <View style={styles.jobInfoSectionHeader}>
            <Ionicons name="car-outline" size={18} color={accent} />
            <Text style={[styles.jobInfoSectionTitle, { color: accent }]}>{"Customer's car"}</Text>
          </View>
          <View style={styles.carImageWrap}>
            <Image source={{ uri: vehicleDetails.photo }} style={styles.carImage} resizeMode="cover" />
          </View>
        </View>
      ) : null}
      {(vehicleDetails?.registration || vehicleDetails?.make || vehicleDetails?.model || job.vehicle_registration || job.vehicle_make || job.vehicle_model) ? (
        <View style={[styles.jobInfoSection, { borderColor: accent + '30' }]}>
          <View style={styles.jobInfoSectionHeader}>
            <Ionicons name="car-outline" size={18} color={accent} />
            <Text style={[styles.jobInfoSectionTitle, { color: accent }]}>Vehicle</Text>
          </View>
          <Text style={styles.jobInfoSectionText}>
            {[
              vehicleDetails?.registration ?? job.vehicle_registration,
              vehicleDetails?.make ?? job.vehicle_make,
              vehicleDetails?.model ?? job.vehicle_model,
            ].filter(Boolean).join(' · ') || '—'}
          </Text>
        </View>
      ) : null}

      <View style={[styles.jobInfoSection, { borderColor: accent + '30' }]}>
        <View style={styles.jobInfoSectionHeader}>
          <Ionicons name="location-outline" size={18} color={accent} />
          <Text style={[styles.jobInfoSectionTitle, { color: accent }]}>Location</Text>
        </View>
        <Text style={styles.jobInfoSectionText}>{job.location_address || '—'}</Text>
      </View>

      <View style={[styles.jobInfoSection, { borderColor: accent + '30' }]}>
        <View style={styles.jobInfoSectionHeader}>
          <Ionicons name="wallet-outline" size={18} color={accent} />
          <Text style={[styles.jobInfoSectionTitle, { color: accent }]}>Price</Text>
        </View>
        <Text style={[styles.jobInfoSectionText, styles.jobInfoPrice]}>£{Number(job.price ?? 0).toFixed(2)}</Text>
      </View>

      {job.scheduled_at ? (
        <View style={[styles.jobInfoSection, { borderColor: accent + '30' }]}>
          <View style={styles.jobInfoSectionHeader}>
            <Ionicons name="calendar-outline" size={18} color={accent} />
            <Text style={[styles.jobInfoSectionTitle, { color: accent }]}>Scheduled</Text>
          </View>
          <Text style={styles.jobInfoSectionText}>
            {new Date(job.scheduled_at).toLocaleString(undefined, { dateStyle: 'long', timeStyle: 'short' })}
          </Text>
        </View>
      ) : null}
    </View>
  );
}

function JobTrackingEmptyState({
  themeBackground,
}: Readonly<{ themeBackground: readonly string[] | undefined }>) {
  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={themeBackgroundGradient(themeBackground, HEADER_STYLE_CARD_GRADIENT)} style={StyleSheet.absoluteFill} />
      <BubbleBackground />
      <ValeterScreenHeader title="Tracking" showBack onBack={() => routerBack(router)} />
      <View style={styles.centered}>
        <Text style={styles.errorText}>No active job</Text>
        <TouchableOpacity onPress={() => router.push('/valeter/jobs')} style={styles.backBtn}>
          <Text style={styles.backBtnText}>View jobs</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

function TrackingStageDots({ stages, accent }: Readonly<{ stages: StageItem[]; accent: string }>) {
  return (
    <>
      {stages.map((stage) => {
        let stageIconColor = '#94A3B8';
        if (stage.current) stageIconColor = accent;

        let stageIcon: React.ReactNode;
        if (stage.done) {
          stageIcon = <Ionicons name="checkmark" size={10} color="#FFFFFF" />;
        } else {
          const glyph = stage.icon === 'location' ? 'locate' : stage.icon;
          stageIcon = <Ionicons name={glyph} size={10} color={stageIconColor} />;
        }
        return (
          <View key={stage.label} style={styles.smallStageItem}>
            <View style={[styles.smallStageDot, stage.done && styles.smallStageDotDone, stage.current && [styles.smallStageDotCurrent, { borderColor: accent }]]}>
              {stageIcon}
            </View>
            <Text style={[styles.smallStageLabel, stage.done && styles.smallStageLabelDone, stage.current && { color: accent, fontWeight: '700' }]} numberOfLines={1}>{stage.label}</Text>
          </View>
        );
      })}
    </>
  );
}

function TrackingVehicleSummary({
  vehiclePhoto,
  vehicleReg,
  vehicleMakeModel,
  accent,
}: Readonly<{
  vehiclePhoto?: string | null;
  vehicleReg?: string | null;
  vehicleMakeModel: string;
  accent: string;
}>) {
  if (!vehiclePhoto && !vehicleReg && !vehicleMakeModel) return null;
  return (
    <View style={styles.cardVehicleRow}>
      {vehiclePhoto ? (
        <Image source={{ uri: vehiclePhoto }} style={styles.cardVehiclePhoto} resizeMode="cover" />
      ) : (
        <View style={[styles.cardVehiclePhotoPlaceholder, { backgroundColor: accent + '25' }]}>
          <Ionicons name="car-outline" size={18} color={accent} />
        </View>
      )}
      <View style={styles.cardVehicleInfo}>
        {vehicleReg ? <Text style={[styles.cardVehicleReg, { color: accent }]}>{vehicleReg}</Text> : null}
        {vehicleMakeModel ? <Text style={styles.cardVehicleMake} numberOfLines={1}>{vehicleMakeModel}</Text> : null}
      </View>
    </View>
  );
}

function TrackingCenterAction({
  nextAction,
  status,
  accent,
  sheetGradient,
}: Readonly<{
  nextAction: { label: string; action: () => void } | null;
  status: JobStatus;
  accent: string;
  sheetGradient: [string, string];
}>) {
  if (nextAction) {
    return (
      <TouchableOpacity onPress={nextAction.action} style={[styles.bookingInfoCard, styles.bookingInfoActionCard, { borderColor: accent + '55' }]} activeOpacity={0.85}>
        <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
        <LinearGradient colors={sheetGradient} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1 }} style={StyleSheet.absoluteFill} pointerEvents="none" />
        <View style={[StyleSheet.absoluteFill, styles.trackSheetDarkOverlay]} pointerEvents="none" />
        <Ionicons name="arrow-forward" size={22} color={accent} />
        <View style={styles.bookingInfoCardTextWrap}>
          <Text style={[styles.bookingInfoCardText, { color: accent }]}>{nextAction.label}</Text>
        </View>
      </TouchableOpacity>
    );
  }
  if (status === 'pending_payment') {
    return (
      <View style={[styles.bookingInfoCard, styles.bookingInfoActionCardDisabled, { borderColor: accent + '35' }]}>
        <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
        <LinearGradient colors={sheetGradient} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1 }} style={StyleSheet.absoluteFill} pointerEvents="none" />
        <View style={[StyleSheet.absoluteFill, styles.trackSheetDarkOverlay]} pointerEvents="none" />
        <Ionicons name="wallet-outline" size={22} color="#F59E0B" />
        <View style={styles.bookingInfoCardTextWrap}>
          <Text style={[styles.bookingInfoCardText, styles.bookingInfoCardTextDisabled]}>Locked until customer pays</Text>
        </View>
      </View>
    );
  }
  return null;
}

function JobTrackingMainUI(props: JobTrackingMainUIProps) {
  const {
    themeBackground,
    mapRegion,
    setRegion,
    customerCoords,
    routeCoordinates,
    dragOffset,
    panHandlers,
    sheetGradient,
    sheetBorder,
    accent,
    onChat,
    onOpenInfo,
    fadeAnim,
    cardPulseAnim,
    job,
    status,
    statusMessage,
    etaMinutes,
    distanceMi,
    stages,
    stageProgressPercent,
    tier,
    vehicleDetails,
    nextAction,
    canCancel,
    cancelling,
    onCancel,
    infoSheetVisible,
    onCloseInfo,
    customerName,
  } = props;

  const mapRef = useRef<MapView | null>(null);
  const vehiclePhoto = vehicleDetails?.photo ?? job.vehicle_photo;
  const vehicleReg = vehicleDetails?.registration ?? job.vehicle_registration;
  const vehicleMakeModel = [vehicleDetails?.make ?? job.vehicle_make, vehicleDetails?.model ?? job.vehicle_model]
    .filter(Boolean)
    .join(' ');

  useEffect(() => {
    if (!routeCoordinates || routeCoordinates.length < 2) return;
    const timer = setTimeout(() => {
      mapRef.current?.fitToCoordinates(routeCoordinates, {
        edgePadding: { top: 120, right: 70, bottom: 260, left: 70 },
        animated: true,
      });
    }, 120);
    return () => clearTimeout(timer);
  }, [routeCoordinates]);

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={themeBackgroundGradient(themeBackground, HEADER_STYLE_CARD_GRADIENT)} style={StyleSheet.absoluteFill} />
      <BubbleBackground />

      <View style={styles.mapWrap}>
        <MapView
          ref={mapRef}
          style={StyleSheet.absoluteFill}
          region={mapRegion}
          onRegionChangeComplete={setRegion}
          customMapStyle={DARK_MAP_STYLE}
          mapPadding={{ top: 0, bottom: Math.round(height * TRACKING_SHEET_MAX_HEIGHT_RATIO) + 80, left: 0, right: 0 }}
          showsUserLocation
        >
          {routeCoordinates && routeCoordinates.length > 1 ? (
            <Polyline
              coordinates={routeCoordinates}
              strokeColor={accent}
              strokeWidth={5}
              lineJoin="round"
              lineCap="round"
            />
          ) : null}
          {customerCoords && (
            <Marker coordinate={customerCoords}>
              <View style={styles.jobMarker}>
                <Ionicons name="location" size={24} color="#fff" />
              </View>
            </Marker>
          )}
        </MapView>
      </View>

      <View style={styles.headerOverlay}>
        <ValeterScreenHeader title="Tracking" showBack onBack={() => routerBack(router)} />
      </View>

      <Animated.View
        style={[
          styles.trackingSheetContainer,
          { height: TOTAL_SHEET_HEIGHT, transform: [{ translateY: dragOffset }] },
        ]}
      >
        <View style={styles.trackSheetChatRow}>
          <TouchableOpacity onPress={onCancel} disabled={!canCancel || cancelling} style={[styles.trackSheetInfoBtn, styles.bookingInfoCancelBtn]} hitSlop={12} activeOpacity={0.8}>
            <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
            <LinearGradient colors={sheetGradient} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1 }} style={StyleSheet.absoluteFill} pointerEvents="none" />
            <View style={[StyleSheet.absoluteFill, styles.trackSheetDarkOverlay]} pointerEvents="none" />
            {cancelling ? (
              <ActivityIndicator size="small" color="#EF4444" />
            ) : (
              <Ionicons name="trash-outline" size={20} color={canCancel ? '#EF4444' : '#64748B'} style={styles.trackSheetInfoBtnIcon} />
            )}
          </TouchableOpacity>
        </View>

        <View style={[styles.trackSheetPanel, { borderColor: sheetBorder }]}>
          <BlurView intensity={BOOKING_SHEET_BLUR_INTENSITY} tint="dark" style={styles.bottomSheetBlur} pointerEvents="none" />
          <LinearGradient colors={sheetGradient} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1 }} style={StyleSheet.absoluteFill} pointerEvents="none" />
          <View style={[StyleSheet.absoluteFill, styles.trackSheetDarkOverlay]} pointerEvents="none" />
          <View style={[styles.trackSheetGlowLine, { backgroundColor: accent + '88', shadowColor: accent }]} pointerEvents="none" />
          <View style={styles.trackSheetDragArea} {...panHandlers} />
          <View style={[styles.trackSheetHandle, { backgroundColor: accent + '50' }]} />
          <View style={styles.trackSheetBody}>
            <Animated.View style={{ opacity: fadeAnim }}>
              <Animated.View style={[styles.smallTrackingCardWrap, { transform: [{ scale: cardPulseAnim }] }]}>
                <View style={[styles.smallTrackingCard, { borderColor: tier.color + '70' }]}>
                  <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} />
                  <LinearGradient colors={sheetGradient} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1 }} style={StyleSheet.absoluteFill} />
                  <View style={[StyleSheet.absoluteFill, styles.trackSheetDarkOverlay]} pointerEvents="none" />
                  <View style={[styles.smallTrackingCardGlowOverlay, { borderColor: tier.glow + '50', shadowColor: tier.glow }]} pointerEvents="none" />
                  <View style={styles.smallTrackingCardContent}>
                    <View style={styles.smallCardRow}>
                      <View style={styles.smallCardBody}>
                        <Text style={styles.smallCardService} numberOfLines={1}>{getServiceDisplayName(job.service_type, job.service_name)}</Text>
                        <Text style={[styles.smallCardStatus, { color: accent }]} numberOfLines={1}>{statusMessage}</Text>
                        {etaMinutes != null && distanceMi != null && (status === 'en_route' || status === 'confirmed' || status === 'scheduled') && (
                          <Text style={[styles.smallCardEta, { color: accent }]}>~{etaMinutes} min away · {distanceMi} mi</Text>
                        )}
                      </View>
                      <View style={[styles.smallRingWrap, { borderColor: accent + '60', backgroundColor: accent + '12' }]}>
                        <AnimatedProgress progress={getJobProgress(status)} size={58} strokeWidth={6} showPercentage color={accent} gamified futuristic />
                      </View>
                    </View>
                    <View style={styles.smallCardProgressWrap}>
                      <View style={[styles.smallCardProgressTrack, { borderColor: accent + '25' }]}>
                        <View style={[styles.smallCardProgressFill, { width: `${stageProgressPercent}%`, backgroundColor: accent }]} />
                      </View>
                      <View style={styles.smallStagesRow}>
                        <TrackingStageDots stages={stages} accent={accent} />
                      </View>
                    </View>
                    <TrackingVehicleSummary
                      vehiclePhoto={vehiclePhoto}
                      vehicleReg={vehicleReg}
                      vehicleMakeModel={vehicleMakeModel}
                      accent={accent}
                    />
                  </View>
                </View>
              </Animated.View>
              <View style={styles.bookingInfoRow}>
                <View style={styles.bookingInfoSideSlot}>
                  <TouchableOpacity onPress={onChat} style={[styles.trackSheetInfoBtn, { borderColor: accent + '55' }]} activeOpacity={0.85}>
                    <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
                    <LinearGradient colors={sheetGradient} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1 }} style={StyleSheet.absoluteFill} pointerEvents="none" />
                    <View style={[StyleSheet.absoluteFill, styles.trackSheetDarkOverlay]} pointerEvents="none" />
                    <Ionicons name="chatbubble-ellipses-outline" size={22} color={accent} style={styles.trackSheetInfoBtnIcon} />
                  </TouchableOpacity>
                </View>
                <View style={styles.bookingInfoCenterSlot}>
                  <TrackingCenterAction
                    nextAction={nextAction}
                    status={status}
                    accent={accent}
                    sheetGradient={sheetGradient}
                  />
                </View>
                <View style={styles.bookingInfoSideSlot}>
                  <TouchableOpacity onPress={() => { hapticFeedback('light'); onOpenInfo(); }} style={[styles.trackSheetInfoBtn, { borderColor: accent + '55' }]} activeOpacity={0.85}>
                    <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
                    <LinearGradient colors={sheetGradient} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1 }} style={StyleSheet.absoluteFill} pointerEvents="none" />
                    <View style={[StyleSheet.absoluteFill, styles.trackSheetDarkOverlay]} pointerEvents="none" />
                    <Ionicons name="information-circle-outline" size={22} color={accent} style={styles.trackSheetInfoBtnIcon} />
                  </TouchableOpacity>
                </View>
              </View>
            </Animated.View>
          </View>
        </View>
      </Animated.View>

      <InfoBottomSheet
        visible={infoSheetVisible}
        onClose={onCloseInfo}
        title="Job details"
        accentColor={accent}
        contentMaxHeight="78%"
      >
        <ValeterJobTrackingDetailsContent
          accent={accent}
          customerName={customerName}
          job={job}
          statusMessage={statusMessage}
          vehicleDetails={vehicleDetails}
        />
      </InfoBottomSheet>
    </SafeAreaView>
  );
}

export default function JobTracking() {
  const params = useLocalSearchParams<{ jobId?: string }>();
  const jobIdParam = typeof params.jobId === 'string' && params.jobId !== 'undefined' ? params.jobId : null;
  const { user } = useAuth();
  const { theme } = useAccountTheme();

  const [job, setJob] = useState<BookingJobRow | null>(null);
  const [customerName, setCustomerName] = useState('Customer');
  const [status, setStatus] = useState<JobStatus>('pending_payment');
  const [region, setRegion] = useState<Region>(DEFAULT_REGION);
  const [vehicleDetails, setVehicleDetails] = useState<{ registration?: string; make?: string; model?: string; photo?: string } | null>(null);
  const [cancelling, setCancelling] = useState(false);
  const [infoSheetVisible, setInfoSheetVisible] = useState(false);
  const [loading, setLoading] = useState(true);
  const [etaMinutes, setEtaMinutes] = useState<number | null>(null);
  const [distanceMi, setDistanceMi] = useState<number | null>(null);
  const [routeCoordinates, setRouteCoordinates] = useState<{ latitude: number; longitude: number }[] | null>(null);

  const effectiveJobId = job?.id ?? jobIdParam;
  const onOkPress = () => routerBack(router);

  useEffect(() => {
    if (jobIdParam) {
      loadJob(jobIdParam);
      return;
    }
    if (user?.id) loadActiveJob();
    else setLoading(false);
  }, [jobIdParam, user?.id]);

  useEffect(() => {
    if (!effectiveJobId) return;
    const ch = supabase
      .channel(`valeter-tracking-${effectiveJobId}`)
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'bookings', filter: `id=eq.${effectiveJobId}` },
        (payload) => {
          const next = (payload.new as { status?: unknown })?.status;
          if (next) setStatus(next as JobStatus);
          if (next === 'completed') {
            router.replace({ pathname: '/valeter/jobs/complete', params: { jobId: effectiveJobId } } as any);
          }
        }
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [effectiveJobId]);

  useEffect(() => {
    if (!user?.id || !job?.location_lat || !job?.location_lng) {
      setEtaMinutes(null);
      setDistanceMi(null);
      return;
    }
    let cancelled = false;
    (async () => {
      const { data } = await supabase
        .from('valeter_presence')
        .select('last_lat, last_lng')
        .eq('user_id', user.id)
        .maybeSingle();
      if (cancelled || !data?.last_lat || !data?.last_lng) return;
      const mi = haversineMi(data.last_lat, data.last_lng, Number(job.location_lat), Number(job.location_lng));
      const mins = Math.max(1, Math.round(mi * 2));
      setDistanceMi(Math.round(mi * 10) / 10);
      setEtaMinutes(mins);
    })();
    return () => { cancelled = true; };
  }, [user?.id, job?.id, job?.location_lat, job?.location_lng]);

  useEffect(() => {
    let cancelled = false;
    if (status !== 'en_route' || !user?.id || !job?.location_lat || !job?.location_lng) {
      setRouteCoordinates(null);
      return;
    }

    (async () => {
      try {
        const { data: presence } = await supabase
          .from('valeter_presence')
          .select('last_lat, last_lng')
          .eq('user_id', user.id)
          .maybeSingle();

        const originLat = presence?.last_lat == null ? null : Number(presence.last_lat);
        const originLng = presence?.last_lng == null ? null : Number(presence.last_lng);
        const destLat = Number(job.location_lat);
        const destLng = Number(job.location_lng);

        if (
          originLat == null ||
          originLng == null ||
          !Number.isFinite(originLat) ||
          !Number.isFinite(originLng) ||
          !Number.isFinite(destLat) ||
          !Number.isFinite(destLng)
        ) {
          setRouteCoordinates(null);
          return;
        }

        const url =
          `https://maps.googleapis.com/maps/api/directions/json` +
          `?origin=${originLat},${originLng}` +
          `&destination=${destLat},${destLng}` +
          `&mode=driving` +
          `&key=${GOOGLE_MAPS_API_KEY}`;

        const res = await fetch(url);
        const json = await res.json();
        const encoded = json?.routes?.[0]?.overview_polyline?.points;
        const decoded = typeof encoded === 'string' ? polyline.decode(encoded) : null;

        if (cancelled) return;

        if (Array.isArray(decoded) && decoded.length > 1) {
          setRouteCoordinates(
            decoded.map(([latitude, longitude]: [number, number]) => ({ latitude, longitude }))
          );
        } else {
          setRouteCoordinates([
            { latitude: originLat, longitude: originLng },
            { latitude: destLat, longitude: destLng },
          ]);
        }
      } catch (error) {
        console.warn('[JobTracking] route load failed:', error);
        if (!cancelled) {
          setRouteCoordinates(null);
        }
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [job?.location_lat, job?.location_lng, status, user?.id]);

  const loadActiveJob = () =>
    loadActiveJobForTracking(
      user?.id ?? null,
      setLoading,
      setJob,
      setStatus,
      setCustomerName,
      setRegion,
      setVehicleDetails
    );

  const loadJob = (id: string) =>
    loadJobByIdForTracking(
      id,
      router,
      { setLoading, setJob, setStatus, setCustomerName, setRegion, setVehicleDetails }
    );

  const acceptJobFromOffer = () => {
    acceptJobFromOfferForTracking(jobIdParam ?? job?.id ?? null, user?.id ?? null, setStatus);
  };

  const updateStatus = (newStatus: JobStatus) => {
    updateJobStatusForTracking(newStatus, effectiveJobId, user?.id ?? null, setStatus, router);
  };

  const startWashWithPhoto = async () => {
    if (!effectiveJobId || !user?.id) return;
    try {
      const sent = await promptAndSendBookingPhotoMessage({
        bookingId: effectiveJobId,
        senderId: user.id,
        senderRole: 'valeter',
        content: 'BEFORE IMAGE',
        promptTitle: 'Photo required',
        promptMessage: 'You need to take a picture before starting.',
      });
      if (!sent) return;
      updateStatus('in_progress');
    } catch (e: any) {
      Alert.alert('Photo required', e?.message ?? 'Could not take or send the photo.');
    }
  };

  const completeWashWithPhoto = async () => {
    if (!effectiveJobId || !user?.id) return;
    try {
      const sent = await promptAndSendBookingPhotoMessage({
        bookingId: effectiveJobId,
        senderId: user.id,
        senderRole: 'valeter',
        content: 'Finished IMAGE',
        promptTitle: 'Photo required',
        promptMessage: 'You need to take a picture before finishing.',
      });
      if (!sent) return;
      updateStatus('completed');
    } catch (e: any) {
      Alert.alert('Photo required', e?.message ?? 'Could not take or send the photo.');
    }
  };

  const canCancel = status !== 'completed' && status !== 'cancelled' && status !== 'pending_payment';
  const handleCancel = () =>
    cancelJobForTracking({
      canCancel,
      effectiveJobId,
      setCancelling,
      setStatus,
      onOkPress,
    });

  const handleChat = () => {
    hapticFeedback('light');
    router.push({ pathname: '/valeter/jobs/chat', params: { bookingId: effectiveJobId } } as any);
  };

  const customerCoords = useMemo(() => {
    if (!job) return null;
    const lat = job.location_lat;
    const lng = job.location_lng;
    if (lat == null || lng == null) return null;
    return { latitude: Number(lat), longitude: Number(lng) };
  }, [job]);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const cardPulseAnim = useRef(new Animated.Value(1)).current;
  const dragOffset = useRef(new Animated.Value(0)).current;

  const panResponder = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => true,
        onMoveShouldSetPanResponder: (_, g) => Math.abs(g.dy) > 5,
        onPanResponderMove: (_, g) => {
          const dy = g.dy;
          if (dy > 0) dragOffset.setValue(Math.min(dy, MAX_PEEK_DRAG));
        },
        onPanResponderRelease: (_, g) => {
          const { dy, vy } = g;
          const shouldClose = dy > DRAG_CLOSE_THRESHOLD || (dy > 30 && vy > DRAG_VELOCITY_THRESHOLD);
          if (shouldClose) {
            Animated.timing(dragOffset, {
              toValue: TOTAL_SHEET_HEIGHT,
              duration: 220,
              useNativeDriver: true,
            }).start(() => routerBack(router));
          } else {
            Animated.spring(dragOffset, {
              toValue: 0,
              useNativeDriver: true,
              damping: 25,
              stiffness: 300,
            }).start();
          }
        },
      }),
    [dragOffset]
  );

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 500, useNativeDriver: true }).start();
  }, []);

  useEffect(() => {
    const pulse = Animated.loop(
      Animated.sequence([
        Animated.timing(cardPulseAnim, { toValue: 1.008, duration: 2500, useNativeDriver: true }),
        Animated.timing(cardPulseAnim, { toValue: 1, duration: 2500, useNativeDriver: true }),
      ])
    );
    pulse.start();
    return () => pulse.stop();
  }, [cardPulseAnim]);

  useEffect(() => {
    if (status === 'cancelled') {
      router.replace('/valeter/valeter-dashboard');
    }
  }, [status, router]);

  if (status === 'completed' || status === 'cancelled') return null;

  if (loading) {
    return <LoadingScreen message="Loading…" />;
  }

  if (!job) {
    return <JobTrackingEmptyState themeBackground={theme.background} />;
  }

  const nextAction = getNextActionForTracking(
    status,
    acceptJobFromOffer,
    updateStatus,
    startWashWithPhoto,
    completeWashWithPhoto
  );
  const statusMessage = getJobStatusMessage(status);
  const isDetailing = job.service_type === 'detailing';
  const stages = getStages(status, !!isDetailing, true);
  const stageProgressPercent = getStageProgressPercent(status, !!isDetailing, true);
  const accent = theme.primary ?? SKY;
  const rawSheet = theme.headerBackground ?? HEADER_STYLE_CARD_GRADIENT;
  const toOpaque = (s: string, alpha: number) => {
    if (s.includes('rgba')) {
      return s.replace(/,\s*[\d.]+\)$/, `, ${alpha})`);
    }
    const suffix = alpha === 1 ? 'FF' : 'EE';
    return `${s}${suffix}`;
  };
  const sheetGradient = [toOpaque(rawSheet[0], 1), toOpaque(rawSheet[1] || rawSheet[0], 0.93)] as [string, string];
  const sheetBorder = theme.glassBorder ?? HEADER_STYLE_CARD_BORDER;
  const tier = getTierForProgressValue(getJobProgress(status));

  const mapRegion: Region = customerCoords
    ? { ...region, latitude: customerCoords.latitude, longitude: customerCoords.longitude }
    : region;

  return (
    <JobTrackingMainUI
      themeBackground={theme.background}
      mapRegion={mapRegion}
      setRegion={setRegion}
      customerCoords={customerCoords}
      dragOffset={dragOffset}
      panHandlers={panResponder.panHandlers}
      sheetGradient={sheetGradient}
      sheetBorder={sheetBorder}
      accent={accent}
      onChat={handleChat}
      onOpenInfo={() => setInfoSheetVisible(true)}
      fadeAnim={fadeAnim}
      cardPulseAnim={cardPulseAnim}
      job={job}
      status={status}
      statusMessage={statusMessage}
      etaMinutes={etaMinutes}
      distanceMi={distanceMi}
      stages={stages}
      stageProgressPercent={stageProgressPercent}
      tier={tier}
      vehicleDetails={vehicleDetails}
      nextAction={nextAction}
      canCancel={canCancel}
      cancelling={cancelling}
      onCancel={handleCancel}
      infoSheetVisible={infoSheetVisible}
      onCloseInfo={() => setInfoSheetVisible(false)}
      customerName={customerName}
      routeCoordinates={routeCoordinates}
    />
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 16 },
  errorText: { color: '#F9FAFB', fontSize: 16 },
  backBtn: { paddingVertical: 12, paddingHorizontal: 24, backgroundColor: SKY, borderRadius: 12 },
  backBtnText: { color: '#fff', fontWeight: '700' },
  loadingWrap: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 10 },
  loadingText: { color: SKY, fontSize: 14 },
  mapWrap: { ...StyleSheet.absoluteFillObject },
  headerOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 10,
  },
  trackingSheetContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
  },
  trackSheetChatRow: {
    flexDirection: 'row',
    gap: 10,
    paddingHorizontal: 20,
    paddingBottom: 6,
    marginBottom: 4,
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  trackSheetChatBtn: {
    overflow: 'hidden',
    borderRadius: 18,
    borderWidth: 1,
    paddingVertical: 12,
    paddingHorizontal: 20,
    minWidth: 100,
  },
  trackSheetArrivedBtn: {},
  trackSheetChatBtnContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    zIndex: 1,
  },
  trackSheetChatBtnText: {
    fontSize: 15,
    fontWeight: '700',
  },
  trackSheetInfoBtn: {
    overflow: 'hidden',
    width: 46,
    height: 46,
    borderRadius: 14,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  trackSheetInfoBtnIcon: { zIndex: 1 },
  trackSheetPanel: {
    flex: 1,
    backgroundColor: 'transparent',
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    overflow: 'hidden',
    paddingHorizontal: 20,
    paddingTop: 6,
    borderWidth: 1,
    borderBottomWidth: 0,
  },
  trackSheetGlowLine: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 2,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 8,
    elevation: 4,
  },
  trackSheetDarkOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: BOOKING_SHEET_DARK_OVERLAY,
  },
  bottomSheetBlur: {
    ...StyleSheet.absoluteFillObject,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
  },
  trackSheetDragArea: {
    width: '100%',
    height: 20,
    marginBottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  trackSheetHandle: {
    width: 36,
    height: 3,
    borderRadius: 2,
    alignSelf: 'center',
    marginBottom: 8,
  },
  trackSheetBody: {
    flex: 1,
    minHeight: 0,
    marginTop: 4,
    overflow: 'hidden',
  },
  smallTrackingCardWrap: { paddingHorizontal: 0 },
  smallTrackingCard: {
    overflow: 'hidden',
    borderRadius: 22,
    borderWidth: 1,
    backgroundColor: 'rgba(255,255,255,0.04)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 12,
    elevation: 6,
  },
  smallTrackingCardGlowOverlay: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 22,
    borderWidth: 1,
    backgroundColor: 'transparent',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.45,
    shadowRadius: 14,
    elevation: 4,
  },
  smallTrackingCardContent: {
    padding: 18,
    paddingVertical: 16,
  },
  smallCardRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  smallRingWrap: {
    marginLeft: 12,
    padding: 2,
    borderRadius: 31,
    borderWidth: 1,
  },
  smallCardBody: { flex: 1, minWidth: 0 },
  smallCardService: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 10,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 1.4,
    marginBottom: 2,
  },
  smallCardStatus: { fontSize: 15, fontWeight: '800', letterSpacing: 0.4 },
  smallCardEta: { fontSize: 12, fontWeight: '600', marginTop: 2, opacity: 0.9 },
  smallCardProgressWrap: { marginBottom: 10 },
  smallCardProgressTrack: {
    height: 4,
    borderRadius: 2,
    overflow: 'hidden',
    marginBottom: 8,
    borderWidth: 1,
  },
  smallCardProgressFill: { height: '100%', borderRadius: 2 },
  smallStagesRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  smallStageItem: { flex: 1, alignItems: 'center', minWidth: 0 },
  smallStageDot: {
    width: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: 'rgba(100,116,139,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 4,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.2)',
  },
  smallStageDotDone: {
    backgroundColor: 'rgba(16,185,129,0.9)',
    borderColor: '#10B981',
  },
  smallStageDotCurrent: {
    backgroundColor: SKY + '30',
    borderWidth: 1.5,
  },
  smallStageLabel: {
    fontSize: 9,
    fontWeight: '600',
    color: '#94A3B8',
    letterSpacing: 0.2,
  },
  smallStageLabelDone: { color: '#34D399', fontWeight: '700' },
  cardVehicleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 6,
    paddingTop: 6,
    borderTopWidth: 1,
    borderTopColor: 'rgba(148,163,184,0.12)',
    gap: 8,
  },
  cardVehiclePhoto: {
    width: 40,
    height: 28,
    borderRadius: 6,
  },
  cardVehiclePhotoPlaceholder: {
    width: 40,
    height: 28,
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardVehicleInfo: { flex: 1, minWidth: 0 },
  cardVehicleReg: {
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.4,
    marginBottom: 0,
  },
  cardVehicleMake: {
    fontSize: 10,
    color: '#94A3B8',
    fontWeight: '600',
  },
  bookingInfoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginTop: 10,
  },
  bookingInfoSideSlot: {
    width: 46,
    flexShrink: 0,
  },
  bookingInfoCenterSlot: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    minWidth: 0,
  },
  bookingInfoCard: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
    minWidth: 0,
    paddingVertical: 16,
    paddingHorizontal: 18,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderWidth: 1,
    gap: 12,
  },
  bookingInfoActionCard: {
    overflow: 'hidden',
    position: 'relative',
  },
  bookingInfoActionCardDisabled: {
    overflow: 'hidden',
    position: 'relative',
    opacity: 0.9,
  },
  bookingInfoCardTextWrap: { flex: 1, minWidth: 0, zIndex: 1 },
  bookingInfoCardText: { fontSize: 15, fontWeight: '700' },
  bookingInfoCardTextDisabled: { color: '#F59E0B', fontWeight: '600' },
  bookingInfoCancelBtn: {
    overflow: 'hidden',
    position: 'relative',
    width: 46,
    height: 46,
    borderRadius: 14,
    backgroundColor: 'rgba(239,68,68,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.4)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  jobMarker: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(30,58,138,0.9)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: SKY,
  },
  jobInfoProfile: { paddingBottom: 24 },
  jobInfoProfileHeader: {
    alignItems: 'center',
    paddingVertical: 20,
    paddingHorizontal: 16,
    marginBottom: 16,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  jobInfoAvatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 2,
    backgroundColor: 'rgba(255,255,255,0.06)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  jobInfoProfileName: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '800',
    marginBottom: 4,
    textAlign: 'center',
  },
  jobInfoProfileHeadline: {
    fontSize: 15,
    fontWeight: '600',
    marginBottom: 12,
    textAlign: 'center',
    opacity: 0.95,
  },
  jobInfoProfileMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 1,
  },
  jobInfoOwnerLabel: {
    fontSize: 12,
    fontWeight: '700',
  },
  jobInfoSection: {
    padding: 14,
    marginBottom: 12,
    borderRadius: 12,
    borderWidth: 1,
    backgroundColor: 'rgba(255,255,255,0.03)',
  },
  jobInfoSectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 6,
  },
  jobInfoSectionTitle: {
    fontSize: 13,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  jobInfoSectionText: {
    color: '#E2E8F0',
    fontSize: 15,
    lineHeight: 22,
    paddingLeft: 26,
  },
  jobInfoPrice: { fontWeight: '700', color: '#F9FAFB' },
  carImageWrap: {
    width: '100%',
    aspectRatio: 16 / 9,
    borderRadius: 10,
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.06)',
    marginTop: 8,
  },
  carImage: { width: '100%', height: '100%' },
});
