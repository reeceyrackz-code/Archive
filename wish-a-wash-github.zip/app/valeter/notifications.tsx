import React, { useCallback, useEffect, useMemo, useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  RefreshControl,
  TouchableOpacity,
  Alert,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';

import GradientIconBox from '../../src/components/shared/GradientIconBox';
import { NotificationInboxRow, type NotificationInboxGlyph } from '../../src/components/shared/NotificationInboxRow';
import DefaultLoadingSkeleton from '../../src/components/shared/DefaultLoadingSkeleton';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import ValeterScreenHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/valeter/ValeterScreenHeader';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { colors } from '../../src/constants/colors';
import { themeBackgroundGradient } from '../../src/utils/themeGradient';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { VALETER_CONTENT_BOTTOM_PAD } from '../../src/components/valeter/ValeterNavSidebar';
import { dismissValeterNotificationIds, loadDismissedValeterNotificationIds } from '../../src/services/valeterNotificationDismissals';

type JobStatus =
  | 'pending_payment'
  | 'confirmed'
  | 'en_route'
  | 'arrived'
  | 'in_progress'
  | 'completed';

type DocumentType = 'id_proof' | 'selfie' | 'profile_photo' | 'disclaimer_signed';

type DocumentStatus = 'pending' | 'approved' | 'rejected' | 'not_uploaded';

type ValeterNotificationType = 'job' | 'document' | 'compliance' | 'system';

interface ValeterNotification {
  id: string;
  title: string;
  message: string;
  createdAt: string;
  type: ValeterNotificationType;
  status?: string;
  priority?: 'low' | 'medium' | 'high';
  actionRoute?: string;
  actionParams?: Record<string, string>;
}

interface BookingRow {
  id: string;
  status: JobStatus;
  service_type: string | null;
  service_name: string | null;
  location_address: string | null;
  updated_at: string | null;
  created_at: string | null;
}

interface ValeterDocumentRow {
  id: string;
  type: DocumentType;
  status: DocumentStatus;
  name: string | null;
  rejection_reason?: string | null;
  uploaded_at?: string | null;
  updated_at?: string | null;
}

const DOC_LABELS: Record<DocumentType, string> = {
  id_proof: 'Proof of Identity',
  selfie: 'Selfie Photo',
  profile_photo: 'Profile Photo',
  disclaimer_signed: 'Terms & Conditions',
};

type SectionKey = 'today' | 'yesterday' | 'week' | 'older';

function getSectionKey(dateString: string): SectionKey {
  const d = new Date(dateString);
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const dayStart = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
  const diffDays = (today - dayStart) / (24 * 60 * 60 * 1000);
  if (diffDays <= 0) return 'today';
  if (diffDays <= 1) return 'yesterday';
  if (diffDays <= 7) return 'week';
  return 'older';
}

const SECTION_LABELS: Record<SectionKey, string> = {
  today: 'Today',
  yesterday: 'Yesterday',
  week: 'This week',
  older: 'Older',
};

const ACTIVE_JOB_NOTIFICATION_STATUSES = new Set([
  'pending_payment',
  'scheduled',
  'confirmed',
  'en_route',
  'arrived',
  'in_progress',
]);

function isJobNotificationActive(notification: ValeterNotification): boolean {
  if (notification.type !== 'job') return true;
  const status = typeof notification.status === 'string' ? notification.status.toLowerCase() : '';
  return ACTIVE_JOB_NOTIFICATION_STATUSES.has(status as JobStatus);
}

function jobNotificationIconMeta(status?: string): { icon: NotificationInboxGlyph; color: string; background: string } {
  let icon: NotificationInboxGlyph = 'briefcase-outline';
  if (status === 'completed') icon = 'checkmark-done-outline';
  else if (status === 'pending_payment') icon = 'wallet-outline';
  return { icon, color: '#10B981', background: 'rgba(16,185,129,0.15)' };
}

function documentNotificationIconMeta(status?: string): { icon: NotificationInboxGlyph; color: string; background: string } {
  if (status === 'rejected') {
    return { icon: 'close-circle-outline', color: '#F87171', background: 'rgba(248,113,113,0.15)' };
  }
  if (status === 'approved') {
    return { icon: 'checkmark-circle-outline', color: '#10B981', background: 'rgba(16,185,129,0.15)' };
  }
  return { icon: 'document-text-outline', color: colors.SKY, background: 'rgba(135,206,235,0.15)' };
}

const getIconMeta = (
  type: ValeterNotificationType,
  status?: string
): { icon: NotificationInboxGlyph; color: string; background: string } => {
  switch (type) {
    case 'job':
      return jobNotificationIconMeta(status);
    case 'document':
      return documentNotificationIconMeta(status);
    case 'compliance':
      return { icon: 'shield-checkmark-outline', color: '#FBBF24', background: 'rgba(251,191,36,0.2)' };
    default:
      return { icon: 'notifications-outline', color: colors.SKY, background: 'rgba(135,206,235,0.15)' };
  }
};

function formatUpdateCount(count: number): string {
  const label = count === 1 ? 'update' : 'updates';
  return `${count} ${label}`;
}

function NotificationListSeparator() {
  return <View style={{ height: 10 }} />;
}

type NotificationListItemProps = {
  item: ValeterNotification;
  fadeAnim: Animated.Value;
  primary: string;
  formatRelativeTime: (dateString: string) => string;
  onPress: (notification: ValeterNotification) => void;
  onDismiss: (notificationId: string) => void;
};

function ValeterNotificationListItem({
  item,
  fadeAnim,
  primary,
  formatRelativeTime,
  onPress,
  onDismiss,
}: Readonly<NotificationListItemProps>) {
  const iconMeta = getIconMeta(item.type, item.status);
  const inactive = !isJobNotificationActive(item);
  const canOpen = Boolean(item.actionRoute) && inactive === false;

  return (
    <Animated.View style={{ opacity: fadeAnim }}>
      <NotificationInboxRow
        title={item.title}
        message={item.message}
        timeLine={formatRelativeTime(item.createdAt)}
        icon={iconMeta.icon}
        accentColor={iconMeta.color}
        onPress={canOpen ? () => onPress(item) : undefined}
        onDismiss={() => onDismiss(item.id)}
        showChevron={canOpen}
        chevronAccentColor={primary}
        priorityUrgent={item.priority === 'high' && inactive === false}
        disabled={inactive}
      />
    </Animated.View>
  );
}

export default function ValeterNotifications() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const primary = theme.primary ?? colors.SKY;
  const backgroundColors = themeBackgroundGradient(theme.background, [colors.BG, colors.headerBg ?? colors.BG]);

  const [notifications, setNotifications] = useState<ValeterNotification[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const groupedSections = useMemo(() => {
    const order: SectionKey[] = ['today', 'yesterday', 'week', 'older'];
    const map = new Map<SectionKey, ValeterNotification[]>();
    order.forEach((k) => map.set(k, []));
    notifications.forEach((n) => {
      const key = getSectionKey(n.createdAt);
      map.get(key)!.push(n);
    });
    return order.map((key) => ({ key, data: map.get(key)! })).filter((s) => s.data.length > 0);
  }, [notifications]);

  const formatRelativeTime = useCallback((dateString: string) => {
    const date = new Date(dateString);
    if (Number.isNaN(date.getTime())) return '';
    const diff = Date.now() - date.getTime();
    const minute = 60 * 1000;
    const hour = 60 * minute;
    const day = 24 * hour;
    if (diff < minute) return 'Just now';
    if (diff < hour) {
      const m = Math.floor(diff / minute);
      return `${m} min${m === 1 ? '' : 's'} ago`;
    }
    if (diff < day) {
      const h = Math.floor(diff / hour);
      return `${h} hr${h === 1 ? '' : 's'} ago`;
    }
    const d = Math.floor(diff / day);
    if (d < 7) {
      return `${d} day${d === 1 ? '' : 's'} ago`;
    }
    return date.toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  }, []);

  const mapJobNotification = useCallback((job: BookingRow): ValeterNotification => {
    const statusCopy: Record<JobStatus, { title: string; message: string; priority: 'low' | 'medium' | 'high' }> = {
      pending_payment: {
        title: 'Awaiting Payment',
        message: 'Customer needs to complete payment before work can begin.',
        priority: 'medium',
      },
      confirmed: {
        title: 'Job Confirmed',
        message: 'Payment received. You can start travelling when ready.',
        priority: 'medium',
      },
      en_route: {
        title: 'En Route',
        message: 'Marked as en route. Keep the customer updated.',
        priority: 'low',
      },
      arrived: {
        title: 'Arrived On Site',
        message: 'Remember to start the service when you begin washing.',
        priority: 'medium',
      },
      in_progress: {
        title: 'Service In Progress',
        message: 'Complete the checklist before finishing the job.',
        priority: 'low',
      },
      completed: {
        title: 'Job Completed',
        message: 'Nice work! Submit photos and completion details if required.',
        priority: 'low',
      },
    };

    const copy = statusCopy[job.status] ?? statusCopy.confirmed;
    const serviceName = job.service_name || job.service_type || 'Service';
    const isActive = ACTIVE_JOB_NOTIFICATION_STATUSES.has(job.status);

    return {
      id: `job-${job.id}-${job.status}`,
      title: `${copy.title} · ${serviceName}`,
      message: copy.message,
      createdAt: job.updated_at || job.created_at || new Date().toISOString(),
      type: 'job',
      status: job.status,
      priority: copy.priority,
      actionRoute: isActive ? '/valeter/jobs/tracking' : undefined,
      actionParams: isActive ? { jobId: job.id } : undefined,
    };
  }, []);

  const mapDocumentNotification = useCallback((doc: ValeterDocumentRow): ValeterNotification => {
    const baseTitle = DOC_LABELS[doc.type] || 'Document';
    let title: string;
    let message: string;
    let priority: ValeterNotification['priority'];

    switch (doc.status) {
      case 'pending':
        title = `${baseTitle} pending review`;
        message = 'Hang tight—our compliance team is reviewing this upload.';
        priority = 'low';
        break;
      case 'approved':
        title = `${baseTitle} approved`;
        message = 'You are all set for this requirement.';
        priority = 'low';
        break;
      case 'rejected':
        title = `${baseTitle} rejected`;
        message = doc.rejection_reason
          ? doc.rejection_reason
          : 'Please resubmit this document with the requested corrections.';
        priority = 'high';
        break;
      case 'not_uploaded':
      default:
        title = `${baseTitle} missing`;
        message = 'Upload this document to stay compliant.';
        priority = 'high';
        break;
    }

    return {
      id: `doc-${doc.id}`,
      title,
      message,
      createdAt: doc.updated_at || doc.uploaded_at || new Date().toISOString(),
      type: 'document',
      status: doc.status,
      priority,
      actionRoute: '/valeter/profile/valeter-documents',
    };
  }, []);

  const computeComplianceReminder = useCallback(
    (documents: ValeterDocumentRow[] = [], profilePhotoUrl?: string | null): ValeterNotification | null => {
      const requiredTypes: DocumentType[] = ['id_proof', 'selfie', 'profile_photo', 'disclaimer_signed'];
      const uploadedTypes = new Set(documents.map((doc) => doc.type));
      let missingTypes = requiredTypes.filter((type) => !uploadedTypes.has(type));

      const hasApprovedProfilePhoto = profilePhotoUrl || documents.some(
        (doc) => doc.type === 'profile_photo' && doc.status === 'approved'
      );
      if (!hasApprovedProfilePhoto && !missingTypes.includes('profile_photo')) {
        missingTypes = [...missingTypes, 'profile_photo'];
      }

      if (missingTypes.length === 0) {
        return null;
      }

      const missingNames = missingTypes.map((type) => DOC_LABELS[type]);

      return {
        id: `compliance-${missingTypes.join('-')}`,
        title: missingTypes.length === 1 ? 'Document Required' : 'Documents Required',
        message: `Upload ${missingNames.join(', ')} to stay compliant.`,
        createdAt: new Date().toISOString(),
        type: 'compliance',
        priority: missingTypes.length > 1 ? 'high' : 'medium',
        actionRoute: '/valeter/profile/valeter-documents',
      };
    },
    []
  );

  const fetchNotifications = useCallback(async () => {
    if (!user?.id) return;
    if (!refreshing) setLoading(true);
    try {
      const [jobsRes, docsRes, profileRes] = await Promise.all([
        supabase
          .from('bookings')
          .select('id,status,service_type,service_name,location_address,updated_at,created_at')
          .eq('valeter_id', user.id)
          .order('updated_at', { ascending: false })
          .limit(30),
        supabase
          .from('valeter_documents')
          .select('id,type,status,name,rejection_reason,uploaded_at,updated_at')
          .eq('user_id', user.id),
        supabase
          .from('valeter_profiles')
          .select('profile_photo_url')
          .eq('user_id', user.id)
          .maybeSingle(),
      ]);

      const jobNotifications = (jobsRes.data ?? []).map((job) => mapJobNotification(job as BookingRow));
      const documentNotifications = (docsRes.data ?? []).map((doc) => mapDocumentNotification(doc as ValeterDocumentRow));

      const complianceNotification = computeComplianceReminder(
        (docsRes.data ?? []) as ValeterDocumentRow[],
        profileRes.data?.profile_photo_url
      );
      const complianceList = complianceNotification ? [complianceNotification] : [];
      const combined = [...jobNotifications, ...documentNotifications, ...complianceList].sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
      const dismissed = await loadDismissedValeterNotificationIds(user.id);
      const visible = combined.filter((n) => !dismissed.has(n.id));
      setNotifications(visible);
    } catch (error) {
      console.error('[ValeterNotifications] Failed to load notifications', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [user?.id, mapJobNotification, mapDocumentNotification, computeComplianceReminder, refreshing]);

  useEffect(() => {
    fetchNotifications();
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();
  }, [fetchNotifications]);

  useEffect(() => {
    if (!user?.id) return;
    const jobChannel = supabase
      .channel(`valeter-notifications-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'bookings',
          filter: `valeter_id=eq.${user.id}`,
        },
        () => fetchNotifications()
      )
      .subscribe();

    const docChannel = supabase
      .channel(`valeter-docs-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'valeter_documents',
          filter: `user_id=eq.${user.id}`,
        },
        () => fetchNotifications()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(jobChannel);
      supabase.removeChannel(docChannel);
    };
  }, [user?.id, fetchNotifications]);

  const handleRefresh = useCallback(() => {
    setRefreshing(true);
    fetchNotifications();
  }, [fetchNotifications]);

  const handleNotificationPress = useCallback((notification: ValeterNotification) => {
    if (notification.actionRoute) {
      router.push({
        pathname: notification.actionRoute,
        params: notification.actionParams ?? {},
      });
    }
  }, []);

  const removeNotification = useCallback(async (notificationId: string) => {
    if (user?.id) {
      await dismissValeterNotificationIds(user.id, [notificationId]);
    }
    setNotifications((prev) => prev.filter((n) => n.id !== notificationId));
  }, [user?.id]);

  const handleDeleteNotification = useCallback((notificationId: string) => {
    Alert.alert(
      'Delete Notification',
      'Are you sure you want to delete this notification?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => {
            void removeNotification(notificationId);
          },
        },
      ]
    );
  }, [removeNotification]);

  const removeAllNotifications = useCallback(async () => {
    if (user?.id) {
      await dismissValeterNotificationIds(
        user.id,
        notifications.map((n) => n.id)
      );
    }
    setNotifications([]);
  }, [notifications, user?.id]);

  const handleDeleteAll = useCallback(() => {
    if (notifications.length === 0) return;
    
    Alert.alert(
      'Delete All Notifications',
      `Are you sure you want to delete all ${notifications.length} notification${notifications.length === 1 ? '' : 's'}?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete All',
          style: 'destructive',
          onPress: () => {
            void removeAllNotifications();
          },
        },
      ]
    );
  }, [notifications, removeAllNotifications]);

  const listEmptyComponent = useMemo(
    () => (
      <Animated.View style={[styles.emptyState, { opacity: fadeAnim }]}>
        <View style={styles.emptyIconWrapper}>
          <GradientIconBox icon="notifications-off-outline" preset="sky" boxSize={88} size={44} />
        </View>
        <Text style={styles.emptyTitle}>All caught up</Text>
        <Text style={styles.emptySubtitle}>
          Job updates and compliance reminders will appear here.
        </Text>
      </Animated.View>
    ),
    [fadeAnim]
  );

  type ListItem = { type: 'header'; key: SectionKey; label: string } | { type: 'item'; item: ValeterNotification };
  const flatData = useMemo((): ListItem[] => {
    return groupedSections.flatMap((s) => [
      { type: 'header' as const, key: s.key, label: SECTION_LABELS[s.key] },
      ...s.data.map((item) => ({ type: 'item' as const, item })),
    ]);
  }, [groupedSections]);

  const renderItem = ({ item: row }: { item: ListItem }) => {
    if (row.type === 'header') {
      return (
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionHeaderText}>{row.label}</Text>
        </View>
      );
    }
    return (
      <ValeterNotificationListItem
        item={row.item}
        fadeAnim={fadeAnim}
        primary={primary}
        formatRelativeTime={formatRelativeTime}
        onPress={handleNotificationPress}
        onDismiss={handleDeleteNotification}
      />
    );
  };

  const headerRightAction =
    notifications.length > 0 ? (
      <TouchableOpacity
        onPress={async () => {
          await hapticFeedback('light');
          handleDeleteAll();
        }}
        style={styles.deleteAllButton}
        activeOpacity={0.7}
      >
        <Text style={[styles.deleteAllText, { color: primary }]}>Clear all</Text>
      </TouchableOpacity>
    ) : null;

  return (
    <View style={styles.container}>
      <LinearGradient colors={backgroundColors} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <ValeterScreenHeader title="Notifications" rightAction={headerRightAction} />

      {loading && notifications.length === 0 ? (
        <View style={[styles.loadingWrap, { paddingTop: HEADER_CONTENT_OFFSET + 8 }]}>
          <DefaultLoadingSkeleton message="Loading notifications…" variant="rich" />
        </View>
      ) : (
        <FlatList
          data={flatData}
          keyExtractor={(row) => (row.type === 'header' ? `h-${row.key}` : row.item.id)}
          renderItem={renderItem}
          contentContainerStyle={[
            styles.listContent,
            {
              paddingTop: HEADER_CONTENT_OFFSET + 8,
              paddingBottom: VALETER_CONTENT_BOTTOM_PAD + insets.bottom + 24,
            },
          ]}
          style={styles.list}
          ItemSeparatorComponent={NotificationListSeparator}
          ListEmptyComponent={listEmptyComponent}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={handleRefresh}
              tintColor={primary}
              colors={[primary]}
            />
          }
          ListHeaderComponent={
            notifications.length > 0 ? (
              <Animated.View style={[styles.headerSection, { opacity: fadeAnim }]}>
                <Text style={styles.headerSubtitle}>
                  {formatUpdateCount(notifications.length)}
                </Text>
              </Animated.View>
            ) : null
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  list: {
    flex: 1,
  },
  listContent: {
    paddingHorizontal: 20,
  },
  loadingWrap: {
    flex: 1,
  },
  separator: {
    height: 10,
  },
  deleteAllButton: {
    paddingVertical: 8,
    paddingHorizontal: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  deleteAllText: {
    fontSize: 15,
    fontWeight: '600',
  },
  headerSection: {
    marginBottom: 20,
  },
  headerSubtitle: {
    color: 'rgba(249,250,251,0.65)',
    fontSize: 14,
    fontWeight: '600',
  },
  sectionHeader: {
    paddingVertical: 12,
    paddingHorizontal: 0,
  },
  sectionHeaderText: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 0.4,
    textTransform: 'uppercase',
  },
  emptyState: {
    marginTop: 72,
    alignItems: 'center',
    paddingHorizontal: 32,
  },
  emptyIconWrapper: {
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '800',
    marginBottom: 10,
    letterSpacing: 0.2,
  },
  emptySubtitle: {
    color: 'rgba(249,250,251,0.75)',
    textAlign: 'center',
    lineHeight: 22,
    fontSize: 15,
    fontWeight: '500',
  },
});


