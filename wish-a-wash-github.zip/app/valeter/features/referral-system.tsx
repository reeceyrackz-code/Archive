import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Share,
  Alert,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import ValeterScreenHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/valeter/ValeterScreenHeader';
import GradientIconBox from '../../../src/components/shared/GradientIconBox';
import { colors } from '../../../src/constants/colors';
import { VALETER_CONTENT_BOTTOM_PAD } from '../../../src/components/valeter/ValeterNavSidebar';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;
const VALETER_BG_FALLBACK: [string, string] = ['#0A1929', '#2563EB'];

export default function ValeterReferralSystem() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const gradientBg = (theme?.background || VALETER_BG_FALLBACK) as [string, string];
  
  const generateShortCode = (userId: string | undefined): string => {
    if (!userId) return 'WAW000';
    return userId.replace(/-/g, '').substring(0, 6).toUpperCase() || 'WAW000';
  };
  
  const [referralCode] = useState(generateShortCode(user?.id));
  const [referrals] = useState<Array<{ id: string; name: string; date: string; status: string; reward: string }>>([]);

  const handleShare = async () => {
    try {
      await Share.share({
        message: `Join me on Wish a Wash as a valeter! Use my referral code: ${referralCode} and get £10 bonus when you complete your first job!`,
      });
    } catch (error) {
      Alert.alert('Error', 'Unable to share referral code');
    }
  };

  const handleCopy = () => {
    Alert.alert('Copied!', 'Referral code copied to clipboard');
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <ValeterScreenHeader title="Referrals" />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingTop: HEADER_CONTENT_OFFSET,
            paddingBottom: VALETER_CONTENT_BOTTOM_PAD + insets.bottom + 20,
            paddingHorizontal: 20,
          },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {/* Hero Section - Uber/LinkedIn Style */}
        <View style={styles.heroSection}>
          <View style={styles.heroIconContainer}>
            <Ionicons name="people" size={40} color="#F9FAFB" />
          </View>
          <Text style={styles.heroTitle}>Invite friends, earn £10</Text>
          <Text style={styles.heroSubtitle}>
            Get £10 for every valeter that signs up with your code and completes their first job.
          </Text>
        </View>

        {/* Code Card Section */}
        <View style={styles.codeCard}>
          <Text style={styles.codeLabel}>YOUR REFERRAL CODE</Text>
          <TouchableOpacity style={styles.codeBox} onPress={handleCopy} activeOpacity={0.7}>
            <Text style={styles.codeText}>{referralCode}</Text>
            <Ionicons name="copy-outline" size={20} color={SKY} />
          </TouchableOpacity>

          <TouchableOpacity style={styles.primaryButton} onPress={handleShare}>
            <Text style={styles.primaryButtonText}>Share Invite Link</Text>
          </TouchableOpacity>
        </View>

        {/* Stats Row */}
        <View style={styles.statsContainer}>
          <View style={styles.statBox}>
            <Text style={styles.statValue}>£0</Text>
            <Text style={styles.statLabel}>Total Earned</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statBox}>
            <Text style={styles.statValue}>{referrals.length}</Text>
            <Text style={styles.statLabel}>Invites Sent</Text>
          </View>
        </View>

        {/* Referrals List Section */}
        <View style={styles.referralsSection}>
          <View style={styles.listHeader}>
            <Text style={styles.sectionTitle}>Your Invites</Text>
            <TouchableOpacity>
              <Text style={styles.seeAllText}>See all</Text>
            </TouchableOpacity>
          </View>

          {referrals.length === 0 ? (
            <View style={styles.emptyState}>
              <GradientIconBox icon="mail-open-outline" preset="gray" boxSize={64} size={32} />
              <Text style={styles.emptyText}>No invites yet</Text>
              <Text style={styles.emptySubtext}>Share your code to start earning!</Text>
            </View>
          ) : (
            referrals.map((referral) => {
              const isCompleted = referral.status === 'Completed';
              return (
                <View key={referral.id} style={styles.referralItem}>
                  <View style={styles.referralAvatar}>
                    <Text style={styles.avatarText}>{referral.name.charAt(0)}</Text>
                  </View>
                  <View style={styles.referralInfo}>
                    <Text style={styles.referralName}>{referral.name}</Text>
                    <View style={styles.referralStatusRow}>
                      <View style={[styles.statusDot, isCompleted ? styles.dotCompleted : styles.dotPending]} />
                      <Text style={styles.referralDate}>{referral.status} • {referral.date}</Text>
                    </View>
                  </View>
                  <View style={styles.rewardContainer}>
                    <Text style={[styles.rewardText, isCompleted ? styles.rewardTextCompleted : styles.rewardTextPending]}>
                      {referral.reward}
                    </Text>
                  </View>
                </View>
              );
            })
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  scrollView: { flex: 1 },
  scrollContent: { padding: 20 },

  heroSection: {
    alignItems: 'center',
    marginBottom: 32,
    marginTop: 10,
  },
  heroIconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  heroTitle: {
    color: '#F9FAFB',
    fontSize: 28,
    fontWeight: '800',
    marginBottom: 8,
    textAlign: 'center',
  },
  heroSubtitle: {
    color: '#D1D5DB',
    fontSize: 15,
    textAlign: 'center',
    lineHeight: 22,
    paddingHorizontal: 20,
  },

  codeCard: {
    backgroundColor: 'rgba(10,25,41,0.6)',
    borderRadius: 24,
    padding: 24,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  codeLabel: {
    color: '#9CA3AF',
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 1.5,
    marginBottom: 12,
  },
  codeBox: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: 'rgba(0,0,0,0.2)',
    borderRadius: 16,
    paddingHorizontal: 20,
    paddingVertical: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.05)',
  },
  codeText: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: '700',
    letterSpacing: 2,
  },
  primaryButton: {
    backgroundColor: SKY,
    borderRadius: 16,
    paddingVertical: 16,
    alignItems: 'center',
  },
  primaryButtonText: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: '700',
  },

  statsContainer: {
    flexDirection: 'row',
    backgroundColor: 'rgba(10,25,41,0.4)',
    borderRadius: 20,
    padding: 20,
    marginBottom: 32,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.05)',
  },
  statBox: {
    flex: 1,
    alignItems: 'center',
  },
  statValue: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: '800',
    marginBottom: 4,
  },
  statLabel: {
    color: '#9CA3AF',
    fontSize: 13,
    fontWeight: '500',
  },
  statDivider: {
    width: 1,
    backgroundColor: 'rgba(255,255,255,0.1)',
    marginHorizontal: 20,
  },

  referralsSection: {
    marginBottom: 20,
  },
  listHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
  },
  seeAllText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  
  referralItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(10,25,41,0.4)',
    padding: 16,
    borderRadius: 20,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.05)',
  },
  referralAvatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  avatarText: {
    color: SKY,
    fontSize: 18,
    fontWeight: '700',
  },
  referralInfo: {
    flex: 1,
  },
  referralName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 4,
  },
  referralStatusRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    marginRight: 6,
  },
  dotCompleted: {
    backgroundColor: '#10B981',
  },
  dotPending: {
    backgroundColor: '#F59E0B',
  },
  referralDate: {
    color: '#9CA3AF',
    fontSize: 13,
  },
  rewardContainer: {
    marginLeft: 12,
  },
  rewardText: {
    fontSize: 15,
    fontWeight: '700',
  },
  rewardTextCompleted: {
    color: '#10B981',
  },
  rewardTextPending: {
    color: '#F59E0B',
  },

  emptyState: {
    alignItems: 'center',
    paddingVertical: 32,
    backgroundColor: 'rgba(10,25,41,0.4)',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.05)',
  },
  emptyIconCircle: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(255,255,255,0.05)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  emptyText: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 4,
  },
  emptySubtext: {
    color: '#9CA3AF',
    fontSize: 14,
  },
});
