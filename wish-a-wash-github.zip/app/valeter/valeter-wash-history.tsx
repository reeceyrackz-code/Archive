import React, { useState, useEffect, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  RefreshControl,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../../src/components/shared/ChromeGlyph';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { themeBackgroundGradient } from '../../src/utils/themeGradient';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import LoadingScreen from '../../src/components/LoadingScreen';
import ValeterScreenHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/valeter/ValeterScreenHeader';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import ValeterEarningsTradingChart, {
  buildEarningsChartSeries,
  sliceEarningsPeriod,
  type EarningsPeriod,
} from '../../src/components/valeter/ValeterEarningsTradingChart';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const VALETER_BG_FALLBACK: [string, string] = ['#0A1929', '#2563EB'];

export default function ValeterWashHistory() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const gradientBg = themeBackgroundGradient(theme?.background, VALETER_BG_FALLBACK);
  const accent = theme?.primary ?? '#38BDF8';
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [bookings, setBookings] = useState<any[]>([]);
  const [totalEarnings, setTotalEarnings] = useState(0);
  const [period, setPeriod] = useState<EarningsPeriod>('30D');
  const [stats, setStats] = useState({
    totalJobs: 0,
    thisMonth: 0,
    thisWeek: 0,
    averageRating: 0,
  });

  const loadBookings = async () => {
    if (!user?.id) return;
    try {
      const { data: allBookings, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('valeter_id', user.id);

      if (error) throw error;

      const bookingsList = allBookings || [];
      const completed = bookingsList.filter((b: any) =>
        ['completed', 'rated', 'closed'].includes(b.status)
      );

      const sorted = [...completed].sort((a: any, b: any) => {
        const dateA = a.updated_at || a.created_at || a.completed_at;
        const dateB = b.updated_at || b.created_at || b.completed_at;
        const timeA = dateA ? new Date(dateA).getTime() : 0;
        const timeB = dateB ? new Date(dateB).getTime() : 0;
        return timeB - timeA;
      });

      setBookings(sorted);

      const earnings = completed.reduce((sum: number, b: any) => sum + (Number(b.price) || 0), 0);
      setTotalEarnings(Math.round(earnings * 100) / 100);

      const now = new Date();
      const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const firstDayOfWeek = new Date(now);
      firstDayOfWeek.setDate(now.getDate() - now.getDay());

      const thisMonth = completed.filter((b: any) => {
        const date = b.updated_at || b.created_at || b.completed_at;
        return date && new Date(date) >= firstDayOfMonth;
      }).length;

      const thisWeek = completed.filter((b: any) => {
        const date = b.updated_at || b.created_at || b.completed_at;
        return date && new Date(date) >= firstDayOfWeek;
      }).length;

      setStats({
        totalJobs: completed.length,
        thisMonth,
        thisWeek,
        averageRating: 0,
      });
    } catch (error: any) {
      console.error('[ValeterWashHistory] Error loading bookings:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const fullSeries = useMemo(() => buildEarningsChartSeries(bookings), [bookings]);
  const chartPoints = useMemo(() => sliceEarningsPeriod(fullSeries, period), [fullSeries, period]);

  const periodEarnings = useMemo(
    () => chartPoints.reduce((sum, p) => sum + p.value, 0),
    [chartPoints]
  );

  useEffect(() => {
    loadBookings();
  }, [user?.id]);

  const onRefresh = () => {
    setRefreshing(true);
    loadBookings();
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LoadingScreen message="Loading earnings…" />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <ValeterScreenHeader
        title="Earnings"
        subtitle={`£${totalEarnings.toFixed(2)} lifetime`}
        rightAction={
          <TouchableOpacity onPress={loadBookings} style={[styles.refreshButton, { borderColor: `${accent}35` }]}>
            <Ionicons name="refresh" size={20} color={accent} />
          </TouchableOpacity>
        }
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingTop: HEADER_CONTENT_OFFSET + 8,
            paddingBottom: insets.bottom + 24,
          },
        ]}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={accent} />}
      >
        {fullSeries.length === 0 ? (
          <View style={[styles.emptyCard, { borderColor: `${accent}25` }]}>
            <Ionicons name="analytics-outline" size={40} color={accent} />
            <Text style={styles.emptyTitle}>No earnings yet</Text>
            <Text style={styles.emptySub}>Complete jobs to see your trading-style earnings chart here.</Text>
          </View>
        ) : (
          <ValeterEarningsTradingChart
            points={chartPoints}
            period={period}
            onPeriodChange={setPeriod}
            accent={accent}
          />
        )}

        <View style={styles.metricsRow}>
          <View style={[styles.metricTile, { borderColor: `${accent}22` }]}>
            <Text style={[styles.metricValue, { color: accent }]}>£{periodEarnings.toFixed(0)}</Text>
            <Text style={styles.metricLabel}>{period} revenue</Text>
          </View>
          <View style={[styles.metricTile, { borderColor: `${accent}22` }]}>
            <Text style={styles.metricValue}>{stats.thisWeek}</Text>
            <Text style={styles.metricLabel}>This week</Text>
          </View>
          <View style={[styles.metricTile, { borderColor: `${accent}22` }]}>
            <Text style={styles.metricValue}>{stats.totalJobs}</Text>
            <Text style={styles.metricLabel}>All jobs</Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollView: { flex: 1 },
  scrollContent: { paddingHorizontal: 20 },
  refreshButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.08)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
  },
  emptyCard: {
    alignItems: 'center',
    padding: 36,
    borderRadius: 20,
    borderWidth: 1,
    backgroundColor: 'rgba(15,23,42,0.45)',
    gap: 10,
    marginTop: 24,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
  },
  emptySub: {
    color: 'rgba(249,250,251,0.5)',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
    lineHeight: 20,
  },
  metricsRow: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 20,
  },
  metricTile: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 8,
    borderRadius: 14,
    borderWidth: 1,
    backgroundColor: 'rgba(15,23,42,0.45)',
    gap: 4,
  },
  metricValue: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: '800',
    fontVariant: ['tabular-nums'],
  },
  metricLabel: {
    color: 'rgba(249,250,251,0.45)',
    fontSize: 10,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.4,
    textAlign: 'center',
  },
});
