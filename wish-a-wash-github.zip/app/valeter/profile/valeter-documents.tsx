import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  Image,
  ActivityIndicator,
  SafeAreaView,
  Animated,
  StatusBar,
  Dimensions,
  Modal,
  LayoutAnimation,
  Platform,
  UIManager,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import { router } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import ValeterScreenHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/valeter/ValeterScreenHeader';
import { colors } from '../../../src/constants/colors';
import * as ImagePicker from 'expo-image-picker';

const VALETER_BG_FALLBACK: [string, string] = ['#0A1929', '#1E3A8A'];

import {
  valeterDocumentsSupabaseService,
  UploadedDocument,
} from '../../../src/services/ValeterDocumentsSupabaseService';
import LoadingScreen from '../../../src/components/LoadingScreen';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const IMAGE_MEDIA_TYPES: any =
  (ImagePicker as any)?.MediaType?.Images ? [(ImagePicker as any).MediaType.Images] : undefined;

type UiStatus = 'missing' | 'pending' | 'approved' | 'rejected';

interface RequiredDocument {
  id: string;
  name: string;
  description: string;
  required: boolean;
  type: 'photo';
  icon: string;
}

if (Platform.OS === 'android' && UIManager.setLayoutAnimationEnabledExperimental) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

export default function ValeterDocuments() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const gradientBg = (theme?.background || VALETER_BG_FALLBACK) as [string, string];

  const [documents, setDocuments] = useState<UploadedDocument[]>([]);
  const [uploading, setUploading] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const [showSourceModal, setShowSourceModal] = useState(false);
  const [selectedDocumentType, setSelectedDocumentType] =
    useState<RequiredDocument | null>(null);

  const scrollY = useRef(new Animated.Value(0)).current;

  // ===============================
  // HEADER ANIMATION
  // ===============================

  const headerHeight = scrollY.interpolate({
    inputRange: [0, 100],
    outputRange: [140, 100],
    extrapolate: 'clamp',
  });

  const headerOpacity = scrollY.interpolate({
    inputRange: [0, 50, 100],
    outputRange: [1, 0.8, 0.6],
    extrapolate: 'clamp',
  });

  // ===============================
  // DOCUMENT DEFINITIONS
  // ===============================

  const requiredDocuments: RequiredDocument[] = [
    {
      id: 'profile_photo',
      name: 'Profile Photo',
      description: 'Clear face shot on plain background',
      required: true,
      type: 'photo',
      icon: 'camera',
    },
    {
      id: 'driving_license',
      name: 'Driving Licence',
      description: 'Valid UK driving licence',
      required: true,
      type: 'photo',
      icon: 'car',
    },
    {
      id: 'vehicle_insurance',
      name: 'Vehicle Insurance',
      description: 'Comprehensive vehicle insurance',
      required: true,
      type: 'photo',
      icon: 'car-sport',
    },
  ];

  const supportingDocuments: RequiredDocument[] = [
    {
      id: 'dbs_check',
      name: 'DBS Check',
      description: 'Enhanced DBS certificate',
      required: false,
      type: 'photo',
      icon: 'shield-checkmark',
    },
    {
      id: 'public_liability',
      name: 'Public Liability Insurance',
      description: 'Minimum £2M coverage',
      required: false,
      type: 'photo',
      icon: 'document-text',
    },
    {
      id: 'id_proof',
      name: 'Proof of Identity',
      description: 'Valid government-issued ID',
      required: false,
      type: 'photo',
      icon: 'id-card',
    },
  ];

  // ===============================
  // DATA LOADING
  // ===============================

  useEffect(() => {
    if (!user?.id) return;

    loadDocuments();

    const unsubscribe =
      valeterDocumentsSupabaseService.subscribeToUserDocuments(
        user.id,
        loadDocuments
      );

    return unsubscribe;
  }, [user?.id]);

  const loadDocuments = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      const userDocs =
        await valeterDocumentsSupabaseService.listUserDocuments(user.id);
      setDocuments(userDocs);
    } catch {
      Alert.alert('Error', 'Failed to load documents');
    } finally {
      setLoading(false);
    }
  };

  // ===============================
  // HELPERS
  // ===============================

  const findDocumentForType = (docType: RequiredDocument) =>
    documents.find((d) => d.docTypeId === docType.id);

  const getUiStatus = (docType: RequiredDocument): UiStatus => {
    const doc = findDocumentForType(docType);
    if (!doc) return 'missing';
    if (doc.verificationStatus === 'approved') return 'approved';
    if (doc.verificationStatus === 'rejected') return 'rejected';
    return 'pending';
  };

  const getStatusColor = (status: UiStatus) => {
    switch (status) {
      case 'approved':
        return '#10B981';
      case 'rejected':
        return '#EF4444';
      case 'pending':
        return '#F59E0B';
      default:
        return '#6B7280';
    }
  };

  const getStatusIcon = (status: UiStatus) => {
    switch (status) {
      case 'approved':
        return 'checkmark-circle';
      case 'rejected':
        return 'close-circle';
      case 'pending':
        return 'time';
      default:
        return 'cloud-upload';
    }
  };

  const getStatusLabel = (status: UiStatus) => {
    switch (status) {
      case 'approved':
        return 'Approved';
      case 'rejected':
        return 'Rejected';
      case 'pending':
        return 'Pending';
      default:
        return 'Not uploaded';
    }
  };

  const toggleExpanded = (id: string) => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    setExpandedId((prev) => (prev === id ? null : id));
  };

  const closeSourceModal = () => {
    setShowSourceModal(false);
    setSelectedDocumentType(null);
  };

  const uploadSelectedDocument = async (localUri: string) => {
    if (!user?.id || !selectedDocumentType) return;
    const docType = selectedDocumentType;

    try {
      setUploading(docType.id);
      setShowSourceModal(false);

      await valeterDocumentsSupabaseService.uploadPhotoDocument({
        userId: user.id,
        docTypeId: docType.id,
        docName: docType.name,
        description: docType.description,
        localUri,
      });

      await loadDocuments();
      Alert.alert('Uploaded', `${docType.name} has been uploaded and is pending review.`);
    } catch (error: any) {
      Alert.alert('Upload failed', error?.message || 'Unable to upload this document right now.');
    } finally {
      setUploading(null);
      setSelectedDocumentType(null);
    }
  };

  const pickFromCamera = async () => {
    if (!selectedDocumentType) return;

    const permission = await ImagePicker.requestCameraPermissionsAsync();
    if (permission.status !== 'granted') {
      Alert.alert('Permission needed', 'Please allow camera access to take a document photo.');
      return;
    }

    const result = await ImagePicker.launchCameraAsync({
      mediaTypes: IMAGE_MEDIA_TYPES,
      quality: 0.8,
      allowsEditing: false,
    });

    if (result.canceled || !result.assets?.[0]?.uri) return;
    await uploadSelectedDocument(result.assets[0].uri);
  };

  const pickFromGallery = async () => {
    if (!selectedDocumentType) return;

    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (permission.status !== 'granted') {
      Alert.alert('Permission needed', 'Please allow photo library access to choose a document.');
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: IMAGE_MEDIA_TYPES,
      quality: 0.8,
      allowsEditing: false,
      selectionLimit: 1,
    });

    if (result.canceled || !result.assets?.[0]?.uri) return;
    await uploadSelectedDocument(result.assets[0].uri);
  };

  // ===============================
  // RENDER
  // ===============================

  if (loading) {
    return <LoadingScreen message="Loading documents…" />;
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={gradientBg[0]} />
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />

      <ValeterScreenHeader title="Documents" />

      <Animated.ScrollView
        style={styles.content}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        contentContainerStyle={{ paddingTop: HEADER_CONTENT_OFFSET, paddingBottom: 24, paddingHorizontal: 20 }}
      >
        {/* SUMMARY HEADER (no progress bar anymore) */}
        <View style={styles.summaryCard}>
          <View style={styles.summaryHeader}>
            <View style={styles.summaryIconWrapper}>
              <Ionicons name="checkmark-circle" size={28} color={SKY} />
            </View>
            <View style={styles.summaryTextContainer}>
              <Text style={styles.summaryTitle}>Document Verification</Text>
              <Text style={styles.summarySubtitle}>
                Required documents are needed to start. Supporting documents
                improve booking chances.
              </Text>
            </View>
          </View>
        </View>

        {/* REQUIRED DOCUMENTS */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Required Documents</Text>
          {requiredDocuments.map((doc) =>
            renderDocumentRow(doc)
          )}
        </View>

        {/* SUPPORTING DOCUMENTS */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Supporting Documents</Text>
          <Text style={styles.supportingHint}>
            These documents are not required to start using Wish a Wash, but they
            greatly improve your chances of receiving bookings.
          </Text>

          {supportingDocuments.map((doc) =>
            renderDocumentRow(doc)
          )}
        </View>
      </Animated.ScrollView>

      <Modal
        visible={showSourceModal}
        transparent
        animationType="slide"
        onRequestClose={closeSourceModal}
      >
        <TouchableOpacity activeOpacity={1} style={styles.modalOverlay} onPress={closeSourceModal}>
          <View style={styles.modalContent}>
            <LinearGradient colors={gradientBg} style={{ flex: 0 }}>
              <View style={styles.modalHeader}>
                <Text style={styles.modalTitle}>Upload {selectedDocumentType?.name}</Text>
                <TouchableOpacity onPress={closeSourceModal}>
                  <Ionicons name="close" size={24} color="#F9FAFB" />
                </TouchableOpacity>
              </View>

              <View style={styles.modalBody}>
                <TouchableOpacity style={styles.sourceOption} onPress={pickFromCamera}>
                  <LinearGradient
                    colors={['rgba(255,255,255,0.12)', 'rgba(255,255,255,0.06)']}
                    style={styles.sourceOptionGradient}
                  >
                    <View style={styles.sourceOptionIcon}>
                      <Ionicons name="camera-outline" size={26} color={SKY} />
                    </View>
                    <Text style={styles.sourceOptionTitle}>Take Photo</Text>
                    <Text style={styles.sourceOptionSubtitle}>Use your camera now</Text>
                  </LinearGradient>
                </TouchableOpacity>

                <TouchableOpacity style={styles.sourceOption} onPress={pickFromGallery}>
                  <LinearGradient
                    colors={['rgba(255,255,255,0.12)', 'rgba(255,255,255,0.06)']}
                    style={styles.sourceOptionGradient}
                  >
                    <View style={styles.sourceOptionIcon}>
                      <Ionicons name="images-outline" size={26} color={SKY} />
                    </View>
                    <Text style={styles.sourceOptionTitle}>Choose Photo</Text>
                    <Text style={styles.sourceOptionSubtitle}>Select from your gallery</Text>
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            </LinearGradient>
          </View>
        </TouchableOpacity>
      </Modal>
    </SafeAreaView>
  );

  // ===============================
  // ROW RENDERER (unchanged logic)
  // ===============================

  function renderDocumentRow(docType: RequiredDocument) {
    const status = getUiStatus(docType);
    const document = findDocumentForType(docType);
    const isExpanded = expandedId === docType.id;
    const isBusy = uploading === docType.id;

    return (
      <View key={docType.id} style={styles.documentCard}>
        <LinearGradient
          colors={['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.04)']}
          style={styles.documentGradient}
        >
          <TouchableOpacity
            activeOpacity={0.85}
            onPress={() => toggleExpanded(docType.id)}
            style={styles.row}
          >
            <View style={styles.rowLeft}>
              <View style={styles.documentIconWrapper}>
                <Ionicons name={docType.icon as any} size={22} color={SKY} />
              </View>
              <View style={styles.rowText}>
                <Text style={styles.documentName}>{docType.name}</Text>
                <Text style={styles.documentDescription}>{docType.description}</Text>
              </View>
            </View>

            <View style={styles.rowRight}>
              <View
                style={[
                  styles.statusPill,
                  {
                    backgroundColor: getStatusColor(status) + '20',
                    borderColor: getStatusColor(status) + '55',
                  },
                ]}
              >
                <Ionicons
                  name={getStatusIcon(status) as any}
                  size={14}
                  color={getStatusColor(status)}
                />
                <Text
                  style={[styles.statusPillText, { color: getStatusColor(status) }]}
                >
                  {getStatusLabel(status)}
                </Text>
              </View>

              <Ionicons
                name={isExpanded ? 'chevron-up' : 'chevron-down'}
                size={18}
                color="rgba(255,255,255,0.8)"
                style={{ marginLeft: 10 }}
              />
            </View>
          </TouchableOpacity>

          {isExpanded && (
            <View style={styles.expandWrap}>
              <View style={styles.divider} />

              {document ? (
                <View style={styles.expandContent}>
                  <View style={styles.documentPreview}>
                    {document.uri ? (
                      <Image source={{ uri: document.uri }} style={styles.previewImage} />
                    ) : (
                      <View style={styles.documentIcon}>
                        <Ionicons name="image" size={24} color={SKY} />
                      </View>
                    )}

                    <View style={styles.previewMeta}>
                      <Text style={styles.fileName}>{document.name}</Text>
                      <Text style={styles.uploadDate}>
                        Uploaded: {document.uploadDate.toLocaleDateString('en-GB')}
                      </Text>
                    </View>
                  </View>
                </View>
              ) : (
                <View style={styles.expandContent}>
                  <TouchableOpacity
                    style={[styles.uploadButton, isBusy && styles.uploadButtonDisabled]}
                    disabled={isBusy}
                    onPress={() => {
                      setSelectedDocumentType(docType);
                      setShowSourceModal(true);
                    }}
                  >
                    {isBusy ? (
                      <ActivityIndicator size="small" color="#0A1929" />
                    ) : (
                      <Ionicons name="cloud-upload" size={18} color="#0A1929" />
                    )}
                    <Text style={styles.uploadButtonText}>
                      {isBusy ? 'Uploading...' : 'Upload Photo'}
                    </Text>
                  </TouchableOpacity>
                </View>
              )}
            </View>
          )}
        </LinearGradient>
      </View>
    );
  }
}


const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  loadingText: { color: '#F9FAFB', fontSize: 16, marginTop: 16 },

  legacyHeader: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    backgroundColor: '#0A1929',
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(135,206,235,0.15)',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  legacyHeaderContent: { flex: 1, paddingHorizontal: isSmallScreen ? 16 : 20, paddingBottom: 12, justifyContent: 'flex-start' },
  legacyHeaderTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 8 },
  legacyBackButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  legacyHeaderTitle: { fontSize: isSmallScreen ? 20 : 22, fontWeight: '800', color: '#FFFFFF', flex: 1, textAlign: 'center' },
  legacyPlaceholder: { width: 40 },

  summaryCard: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 20,
    padding: 20,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  summaryHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 16, gap: 12 },
  summaryIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: 16,
    backgroundColor: 'rgba(135,206,235,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  summaryTextContainer: { flex: 1, minWidth: 0 },
  summaryTitle: { fontSize: isSmallScreen ? 18 : 20, fontWeight: '800', color: '#FFFFFF', marginBottom: 4 },
  summarySubtitle: { fontSize: 13, color: SKY, opacity: 0.9 },

  progressContainer: { marginTop: 12 },
  progressHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8, gap: 10 },
  progressText: { color: '#E5E7EB', fontSize: 14, fontWeight: '600', flex: 1, minWidth: 0 },
  progressPercentage: { color: SKY, fontSize: 16, fontWeight: '800' },
  progressBar: { height: 8, backgroundColor: 'rgba(255,255,255,0.1)', borderRadius: 4, overflow: 'hidden' },
  progressFill: { height: '100%', backgroundColor: '#10B981', borderRadius: 4 },

  section: { marginBottom: 24 },
  sectionTitle: { fontSize: isSmallScreen ? 18 : 20, fontWeight: '800', color: '#FFFFFF', marginBottom: 16 },

  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    backgroundColor: '#0A1929',
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(135,206,235,0.15)',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  headerContent: { flex: 1, paddingHorizontal: isSmallScreen ? 16 : 20, paddingBottom: 12, justifyContent: 'flex-start' },
  headerTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 8 },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  headerTitle: { fontSize: isSmallScreen ? 20 : 22, fontWeight: '800', color: '#FFFFFF', flex: 1, textAlign: 'center' },
  placeholder: { width: 40 },

  content: { flex: 1, paddingHorizontal: isSmallScreen ? 12 : 20 },

  documentCard: {
    marginBottom: 12,
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
  },
  documentGradient: { padding: 14 },

  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 },
  rowLeft: { flexDirection: 'row', alignItems: 'center', flex: 1, minWidth: 0 },
  rowText: { flex: 1, minWidth: 0 },
  supportingHint: {
      color: SKY,
      fontSize: 13,
      marginBottom: 12,
      opacity: 0.9,
      lineHeight: 18,
    },

  documentIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },

  documentName: { fontSize: 15, fontWeight: '800', color: '#FFFFFF', marginBottom: 2 },
  documentDescription: { fontSize: 12, color: SKY, opacity: 0.9 },

  rowRight: { flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end' },

  statusPill: {
    maxWidth: 130,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    borderWidth: 1,
  },
  statusPillText: { fontSize: 12, fontWeight: '800' },

  expandWrap: { marginTop: 12 },
  divider: { height: 1, backgroundColor: 'rgba(255,255,255,0.1)', marginBottom: 12 },
  expandContent: { gap: 12 },

  documentPreview: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  previewImage: { width: 64, height: 64, borderRadius: 10 },
  documentIcon: {
    width: 64,
    height: 64,
    borderRadius: 10,
    backgroundColor: 'rgba(135,206,235,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  previewMeta: { flex: 1, minWidth: 0 },

  fileName: { fontSize: 14, fontWeight: '700', color: '#FFFFFF' },
  uploadDate: { fontSize: 12, color: SKY, opacity: 0.85, marginTop: 2 },

  rejectionText: { fontSize: 12, color: '#EF4444', marginTop: 6, fontWeight: '700' },
  pendingHint: { fontSize: 12, color: '#F59E0B', marginTop: 6, fontWeight: '600', opacity: 0.95 },
  approvedHint: { fontSize: 12, color: '#10B981', marginTop: 6, fontWeight: '600', opacity: 0.95 },

  actionsRow: { flexDirection: 'row', justifyContent: 'flex-end', gap: 10, flexWrap: 'wrap' },

  primaryAction: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: SKY,
    paddingHorizontal: 12,
    paddingVertical: 9,
    borderRadius: 10,
    minWidth: 110,
  },
  primaryActionText: { color: '#0A1929', fontSize: 12, fontWeight: '800' },

  deleteButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(239,68,68,0.15)',
    paddingHorizontal: 12,
    paddingVertical: 9,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.3)',
    minWidth: 92,
    justifyContent: 'center',
  },
  deleteButtonDisabled: { backgroundColor: 'rgba(156,163,175,0.12)', borderColor: 'rgba(156,163,175,0.25)' },
  deleteButtonText: { color: '#EF4444', fontSize: 12, fontWeight: '800' },

  uploadButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: SKY,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 12,
  },
  uploadButtonDisabled: { opacity: 0.7 },
  uploadButtonText: { color: '#0A1929', fontSize: 14, fontWeight: '800' },

  helpSection: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 16,
    padding: 20,
    marginTop: 24,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  helpHeader: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 },
  helpTitle: { fontSize: 18, fontWeight: '800', color: '#FFFFFF' },
  helpText: { fontSize: 14, color: SKY, marginBottom: 16, lineHeight: 20, opacity: 0.9 },
  helpButton: { borderRadius: 12, overflow: 'hidden', elevation: 4, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.2, shadowRadius: 4 },
  helpButtonGradient: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 14, paddingHorizontal: 20 },
  helpButtonText: { color: '#0A1929', fontSize: 14, fontWeight: '800' },

  modalOverlay: { flex: 1, backgroundColor: 'rgba(0, 0, 0, 0.7)', justifyContent: 'flex-end' },
  modalContent: { borderTopLeftRadius: 24, borderTopRightRadius: 24, overflow: 'hidden', paddingBottom: 40 },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(135,206,235,0.2)',
  },
  modalTitle: { fontSize: 20, fontWeight: '800', color: '#F9FAFB' },
  modalBody: { padding: 20, gap: 16 },
  sourceOption: { borderRadius: 16, overflow: 'hidden', borderWidth: 1.5, borderColor: 'rgba(135,206,235,0.3)' },
  sourceOptionGradient: { padding: 20, alignItems: 'center' },
  sourceOptionIcon: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  sourceOptionTitle: { fontSize: 18, fontWeight: '800', color: '#F9FAFB', marginBottom: 4 },
  sourceOptionSubtitle: { fontSize: 14, color: '#87CEEB', textAlign: 'center', opacity: 0.8 },
});
