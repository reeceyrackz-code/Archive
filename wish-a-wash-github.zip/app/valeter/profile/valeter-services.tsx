
/**
 * Valeter services & pricing — wash tiers, detailing, and repairs (Supabase valeter_service_settings).
 */
import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Alert,
  Animated,
  TextInput,
  Modal,
  KeyboardAvoidingView,
  Platform,
  Pressable,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import type { IconGlyphName } from '../../../src/components/shared/iconGlyphTypes';
import { useLocalSearchParams } from 'expo-router';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import LoadingScreen from '../../../src/components/LoadingScreen';
import { colors } from '../../../src/constants/colors';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import ValeterScreenHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/valeter/ValeterScreenHeader';
import { LocationStyleIconBox } from '../../../src/components/shared/GradientIconBox';
import { accentToGradient } from '../../../src/utils/accentGradient';
import ContinueCTAButton from '../../../src/components/ui/ContinueCTAButton';

const BG = colors.BG ?? '#0F2847';
const SKY = colors.SKY ?? '#87CEEB';
const BUSINESS_PRIMARY = '#7DD3FC';

// -------- Tier & detailing defs (aligned with valeter_profile) --------
type TierKey = 'bronze' | 'silver' | 'gold' | 'platinum' | 'emerald';
type VehicleSizeKey = 'small' | 'medium' | 'large' | 'xl' | 'xxl';
const TIER_DEFS: Array<{
  key: TierKey;
  name: string;
  icon: IconGlyphName;
  color: string;
  tier: string;
}> = [
  { key: 'bronze', name: 'Bronze Wash', icon: 'water-outline', color: '#CD7F32', tier: 'BRONZE' },
  { key: 'silver', name: 'Silver Wash', icon: 'sparkles-outline', color: '#C0C0C0', tier: 'SILVER' },
  { key: 'gold', name: 'Gold Wash', icon: 'trophy-outline', color: '#FFD700', tier: 'GOLD' },
  { key: 'platinum', name: 'Platinum Wash', icon: 'diamond-outline', color: '#E5E4E2', tier: 'PLATINUM' },
  { key: 'emerald', name: 'Diamond Wash', icon: 'sparkles', color: '#22D3EE', tier: 'DIAMOND' },
];

const STANDARD_TIER_DESCRIPTIONS: Record<string, { description: string; includes: string[]; bestFor: string }> = {
  bronze: {
    description: 'A quick refresh for your vehicle. Choose either an exterior hand wash or a light interior clean including vacuuming and surface wipe-downs.',
    includes: ['Your choice: exterior hand wash OR light interior clean', 'Exterior option: safe wash, wheels, rinse, dry, exterior glass', 'Interior option: vacuum, surface wipe-downs, light cabin tidy', 'Fast and affordable'],
    bestFor: 'Maintenance between deeper valets.',
  },
  silver: {
    description: 'A balanced clean inside and out. Includes an exterior hand wash plus a light interior refresh with vacuuming, surface cleaning, and a tidy finish.',
    includes: ['Exterior hand wash, wheels and dry', 'Interior vacuum (seats, carpets, boot)', 'Dashboard, console and trims wiped', 'Interior and exterior glass cleaned', 'Tyre dressing and light spray wax where included'],
    bestFor: 'Regular maintenance and everyday cleanliness.',
  },
  gold: {
    description: 'A full interior deep clean designed to restore your vehicle from the inside out. Includes deep vacuuming, stain removal, upholstery and carpet treatment.',
    includes: ['Deep vacuum throughout cabin and boot', 'Stain treatment and upholstery / carpet care', 'Seats, carpets and mats shampooed or refreshed', 'All interior surfaces, trims and touchpoints detailed', 'Leather cleaned and dressed where applicable', 'Headliner and hard-to-reach areas addressed', 'Interior glass and finishes refreshed', 'Air freshener to finish'],
    bestFor: 'Vehicles needing a deep interior restoration.',
  },
  platinum: {
    description: 'A complete interior and exterior valet with enhanced attention to detail. Includes a thorough wash, detailed interior cleaning, and finishing touches.',
    includes: ['Thorough exterior wash, wheels and arches', 'Interior deep clean aligned with Gold cabin standard', 'Trims, glass and surfaces finished to a high standard', 'Enhanced attention to detail inside and out', 'Finishing touches for a clean, fresh presentation'],
    bestFor: 'Full vehicle refresh in one visit.',
  },
  emerald: {
    description: 'Our highest level service delivering a full vehicle transformation. Deep interior clean, detailed exterior wash, and premium finishing.',
    includes: ['Deep interior clean plus detailed exterior wash', 'Paint decontamination and enhancement where appropriate', 'Upholstery / leather care and interior sanitisation', 'Machine or hand finishing for gloss and clarity', 'Long-lasting protection or sealant where included', 'Fine detailing on edges, trims and glass', 'Premium finish aimed at near showroom presentation'],
    bestFor: 'Premium care and a near showroom finish.',
  },
};

type ServiceDescBlock = { description: string; includes: string[]; bestFor: string };
const ADDON_SERVICE_DESCRIPTIONS: Record<DetailingKey | RepairKey, ServiceDescBlock> = {
  'ceramic-coating': {
    description: 'A durable protective layer applied over clear coat to help repel water, dirt, and UV, and to keep gloss for longer between washes.',
    includes: ['Surface prep and decontamination where needed', 'Application of ceramic or SIO2-based coating per product instructions', 'Curing guidance for the customer', 'Typically quoted by vehicle size due to paint area'],
    bestFor: 'Owners who want easier washing and longer-lasting shine.',
  },
  'machine-polishing': {
    description: 'Machine correction to reduce swirl marks, light scratches, and oxidation, restoring clarity and gloss before protection or hand finishing.',
    includes: ['Paint assessment and safe wash', 'Single- or multi-stage machine work as agreed', 'Panel wipe and inspection', 'Optional sealant or wax if you include it in the package'],
    bestFor: 'Paint that looks dull or swirled but is otherwise sound.',
  },
  'soft-top-restoration': {
    description: 'Cleaning, conditioning, and protection for convertible fabric hoods to improve appearance and help resist water ingress and fading.',
    includes: ['Gentle clean of fabric and seams', 'Mould/mildew treatment if required (see also Mould Removal)', 'Waterproofer / UV protectant where appropriate', 'Trim and glass edges checked for drips'],
    bestFor: 'Convertibles with stained, faded, or poorly beading hoods.',
  },
  'mould-removal': {
    description: 'Targeted interior treatment to address mould and musty odours from moisture, spills, or poor ventilation—often combined with deep cleaning.',
    includes: ['Inspection of affected areas (seats, carpets, boot, HVAC paths)', 'HEPA vacuum and antimicrobial treatment as appropriate', 'Drying aids and odour neutraliser', 'Advice on preventing recurrence'],
    bestFor: 'Vehicles with visible mould, mildew smell, or water damage history.',
  },
  'headlight-restoration': {
    description: 'Restores clarity to yellowed or hazed polycarbonate lenses to improve night visibility and appearance, usually via wet sanding and UV seal.',
    includes: ['Masking adjacent paint and trim', 'Progressive refinement of lens surface', 'UV protective clear coat or seal', 'Final polish and beam check where possible'],
    bestFor: 'Cloudy headlights that fail MOT beam pattern or look aged.',
  },
  'scratch-removal': {
    description: 'Localised paint correction to reduce or remove clear-coat level marks; deeper scratches may need touch-up or bodyshop work.',
    includes: ['Depth check (clear coat vs base)', 'Compound and refine within safe limits', 'Panel wipe and gloss match', 'Honest call-out when touch-up or respray is safer'],
    bestFor: 'Parking scrapes, brush wash marks, and light clear-coat scratches.',
  },
  'paint-chip-repair': {
    description: 'Small touch-up of stone chips and chips to primer to limit rust and improve looks—colour matched where you stock or mix paint.',
    includes: ['Clean and feather edges', 'Primer / base / clear as needed per chip depth', 'Level and cure per product', 'Blend into surrounding panels where practical'],
    bestFor: 'Bonnet and front bumper stone chips and minor road rash.',
  },
  'trim-restoration': {
    description: 'Revives faded exterior plastic trim (bumpers, mirrors, cladding) with clean, dye, or dressings depending on condition.',
    includes: ['Deep clean of porous plastic', 'Grey/faded trim restored with dye or coating', 'Satin or gloss finish to customer preference', 'Avoid overspray on paint and glass'],
    bestFor: 'Sun-faded black plastic that looks grey or chalky.',
  },
  'leather-repair': {
    description: 'Repairs minor tears, scuffs, and wear on leather or leatherette—colour matching and flexible fillers for seats and bolsters.',
    includes: ['Clean and degrease the area', 'Sub-patch or filler for small holes', 'Grain texture and colour match', 'Conditioner to finish'],
    bestFor: 'Worn driver bolsters, scuffs, and small punctures not needing full retrim.',
  },
  'maintenance-check': {
    description: 'An all-in-one maintenance inspection covering coolant, oil level, tyre tread, lights, and washer fluid so customers get a clear health check for the vehicle.',
    includes: [
      'Coolant level inspection',
      'Oil level check',
      'Tyre tread and visible condition check',
      'Light bulbs / exterior lights inspection',
      'Screen wash / washer fluid check and top-up advice',
    ],
    bestFor: 'Customers wanting a quick vehicle health check while the car is in for service.',
  },
};

const VEHICLE_SIZE_DEFS: Array<{ key: VehicleSizeKey; label: string; subtitle: string; icon: IconGlyphName }> = [
  { key: 'small', label: 'Small car', subtitle: 'Fiat 500, Corsa', icon: 'car-outline' },
  { key: 'medium', label: 'Medium SUV', subtitle: 'Qashqai, Sportage', icon: 'car-sport-outline' },
  { key: 'large', label: 'Large car', subtitle: 'Passat, 3 Series', icon: 'bus-outline' },
  { key: 'xl', label: 'Van', subtitle: 'Transit, Vivaro', icon: 'subway-outline' },
  { key: 'xxl', label: 'XL van', subtitle: 'LWB Transit, Sprinter', icon: 'train-outline' },
];

type DetailingKey = 'ceramic-coating' | 'machine-polishing' | 'soft-top-restoration' | 'mould-removal';
type RepairKey = 'headlight-restoration' | 'scratch-removal' | 'paint-chip-repair' | 'trim-restoration' | 'leather-repair' | 'maintenance-check';
type DetailingItem = {
  key: DetailingKey | RepairKey;
  name: string;
  enabled: boolean;
  price: number | null;
  prices?: Record<VehicleSizeKey, number | null>;
};

const DETAILING_DEFS: Array<{ key: DetailingKey; name: string; icon: IconGlyphName }> = [
  { key: 'ceramic-coating', name: 'Ceramic Coating', icon: 'shield-checkmark-outline' },
  { key: 'machine-polishing', name: 'Machine Polishing', icon: 'color-filter-outline' },
  { key: 'soft-top-restoration', name: 'Soft Top Restoration', icon: 'brush-outline' },
  { key: 'mould-removal', name: 'Mould Removal', icon: 'water-outline' },
];

const REPAIR_DEFS: Array<{ key: RepairKey; name: string; icon: IconGlyphName }> = [
  { key: 'headlight-restoration', name: 'Headlight Restoration', icon: 'bulb-outline' },
  { key: 'scratch-removal', name: 'Scratch Removal', icon: 'color-filter-outline' },
  { key: 'paint-chip-repair', name: 'Paint Chip Repair', icon: 'medkit-outline' },
  { key: 'trim-restoration', name: 'Trim Restoration', icon: 'albums-outline' },
  { key: 'leather-repair', name: 'Leather Repair', icon: 'shirt-outline' },
  { key: 'maintenance-check', name: 'Maintenance Check', icon: 'construct-outline' },
];

const money = (n: any) => (Number.isFinite(Number(n)) ? Number(n).toFixed(2) : '0.00');

function formatPriceRange(prices: Record<VehicleSizeKey, number | null> | undefined): string {
  const vals = Object.values(prices ?? {}).filter((v): v is number => v != null && Number.isFinite(v));
  if (vals.length === 0) return 'Set pricing';
  const min = Math.min(...vals);
  const max = Math.max(...vals);
  if (min === max) return `£${money(min)}`;
  return `£${money(min)}–£${money(max)}`;
}

function minPriceFromRecord(prices: Record<VehicleSizeKey, number | null> | undefined): number | null {
  const vals = Object.values(prices ?? {}).filter((v): v is number => v != null && Number.isFinite(v));
  return vals.length > 0 ? Math.min(...vals) : null;
}

const parseMaybeNumber = (raw: string, kind: 'price' | 'minutes'): number | null => {
  const t = (raw || '').trim();
  if (!t) return null;
  const v = Number(t);
  if (!Number.isFinite(v) || v < 0) return null;
  return kind === 'minutes' ? Math.round(v) : v;
};

const buildDefaultDetailingItems = (): DetailingItem[] =>
  DETAILING_DEFS.map((d) => ({ key: d.key, name: d.name, enabled: false, price: null, prices: defaultTierSizePricing() }));

const buildDefaultRepairItems = (): DetailingItem[] =>
  REPAIR_DEFS.map((d) => ({ key: d.key, name: d.name, enabled: false, price: null, prices: defaultTierSizePricing() }));

const getDetailingPrices = (item: DetailingItem): Record<VehicleSizeKey, number | null> => {
  if (item.prices && Object.keys(item.prices).length > 0) return item.prices;
  const p = item.price != null && Number.isFinite(item.price) ? item.price : null;
  return { small: p, medium: p, large: p, xl: p, xxl: p };
};

const coerceDetailingMenu = (raw: any): DetailingItem[] => {
  const defaults = buildDefaultDetailingItems();
  const map = new Map<string, DetailingItem>();
  defaults.forEach((d) => map.set(d.key, { ...d }));
  const items = raw?.items;
  if (Array.isArray(items)) {
    for (const it of items) {
      const keyRaw = String(it?.key || '');
      const key = (keyRaw === 'ceramic' ? 'ceramic-coating' : keyRaw);
      if (!map.has(key)) continue;
      const legacy = it?.price != null && Number.isFinite(Number(it?.price)) ? Number(it?.price) : null;
      const nextPrices = defaultTierSizePricing();
      VEHICLE_SIZE_DEFS.forEach(({ key: sizeKey }) => {
        const v = it?.prices?.[sizeKey];
        nextPrices[sizeKey] = v != null && Number.isFinite(Number(v)) ? Number(v) : legacy;
      });
      map.set(key, {
        key: key as DetailingKey,
        name: String(it?.name || map.get(key)!.name),
        enabled: !!it?.enabled,
        price: legacy,
        prices: nextPrices,
      });
    }
  }
  return Array.from(map.values());
};

const coerceRepairMenu = (raw: any): DetailingItem[] => {
  const defaults = buildDefaultRepairItems();
  const map = new Map<string, DetailingItem>();
  defaults.forEach((d) => map.set(d.key, { ...d }));
  const items = raw?.items;
  if (Array.isArray(items)) {
    for (const it of items) {
      const key = String(it?.key || '');
      if (!map.has(key)) continue;
      const legacy = it?.price != null && Number.isFinite(Number(it?.price)) ? Number(it?.price) : null;
      const nextPrices = defaultTierSizePricing();
      VEHICLE_SIZE_DEFS.forEach(({ key: sizeKey }) => {
        const v = it?.prices?.[sizeKey];
        nextPrices[sizeKey] = v != null && Number.isFinite(Number(v)) ? Number(v) : legacy;
      });
      map.set(key, {
        key: key as RepairKey,
        name: String(it?.name || map.get(key)!.name),
        enabled: !!it?.enabled,
        price: legacy,
        prices: nextPrices,
      });
    }
  }
  return Array.from(map.values());
};

type TierPricing = Record<TierKey, { prices: Record<VehicleSizeKey, number | null>; minutes: number | null; enabled?: boolean }>;
const defaultTierSizePricing = (): Record<VehicleSizeKey, number | null> =>
  ({ small: null, medium: null, large: null, xl: null, xxl: null });
const ALL_TIER_KEYS: TierKey[] = ['bronze', 'silver', 'gold', 'platinum', 'emerald'];
const defaultTierPricing = (): TierPricing =>
  ALL_TIER_KEYS.reduce(
    (acc, k) => ({ ...acc, [k]: { prices: defaultTierSizePricing(), minutes: null, enabled: true } }),
    {} as TierPricing
  );

const coerceTierPricing = (raw: any): TierPricing => {
  const base = defaultTierPricing();
  const obj = raw && typeof raw === 'object' ? raw : {};
  ALL_TIER_KEYS.forEach((k) => {
    const row = obj?.[k] || {};
    const legacy = row?.price != null && Number.isFinite(Number(row.price)) ? Number(row.price) : null;
    const nextPrices = defaultTierSizePricing();
    VEHICLE_SIZE_DEFS.forEach(({ key }) => {
      const v = row?.prices?.[key];
      nextPrices[key] = v != null && Number.isFinite(Number(v)) ? Number(v) : legacy;
    });
    base[k] = {
      prices: nextPrices,
      minutes: row?.minutes != null && Number.isFinite(Number(row.minutes)) ? Math.round(Number(row.minutes)) : null,
      enabled: row?.enabled !== false,
    };
  });
  return base;
};

const isMissingTableErr = (err: any) => {
  const msg = String(err?.message || '').toLowerCase();
  return msg.includes('does not exist') || msg.includes('relation') || msg.includes('schema cache');
};

const isFilledNumber = (value: number | null | undefined) =>
  value != null && Number.isFinite(value) && Number(value) >= 0;

const getMissingTierFields = (key: TierKey, row: TierPricing[TierKey]) => {
  const label = TIER_DEFS.find((t) => t.key === key)?.name ?? key;
  const missing: string[] = [];
  VEHICLE_SIZE_DEFS.forEach(({ key: sizeKey, label: sizeLabel }) => {
    if (!isFilledNumber(row.prices[sizeKey])) missing.push(`${label} - ${sizeLabel} price`);
  });
  if (!isFilledNumber(row.minutes)) missing.push(`${label} - duration`);
  return missing;
};

const getMissingAddonFields = (item: DetailingItem, label: string) => {
  const missing: string[] = [];
  const prices = getDetailingPrices(item);
  VEHICLE_SIZE_DEFS.forEach(({ key: sizeKey, label: sizeLabel }) => {
    if (!isFilledNumber(prices[sizeKey])) missing.push(`${label} - ${sizeLabel} price`);
  });
  return missing;
};

function computeServicesDashboardStats(
  tierPricing: TierPricing,
  detailingItems: DetailingItem[],
  repairItems: DetailingItem[]
) {
  const activeWash = TIER_DEFS.filter((t) => tierPricing[t.key]?.enabled !== false);
  const activeDetail = detailingItems.filter((i) => i.enabled);
  const activeRepair = repairItems.filter((i) => i.enabled);
  const activeCount = activeWash.length + activeDetail.length + activeRepair.length;

  const bookingMins: number[] = [];
  activeWash.forEach((t) => {
    const p = minPriceFromRecord(tierPricing[t.key]?.prices);
    if (p != null) bookingMins.push(p);
  });
  activeDetail.forEach((i) => {
    const p = minPriceFromRecord(getDetailingPrices(i));
    if (p != null) bookingMins.push(p);
  });
  activeRepair.forEach((i) => {
    const p = minPriceFromRecord(getDetailingPrices(i));
    if (p != null) bookingMins.push(p);
  });

  const avgBooking =
    bookingMins.length > 0 ? bookingMins.reduce((a, b) => a + b, 0) / bookingMins.length : 0;
  const monthlyPotential = avgBooking * Math.max(activeCount, 1) * 12;

  return {
    activeWashCount: activeWash.length,
    activeDetailCount: activeDetail.length,
    activeRepairCount: activeRepair.length,
    activeCount,
    avgBooking,
    monthlyPotential,
  };
}

type ServicePricingTab = 'standard' | 'detailing' | 'repairs';

function tabFromParam(raw: string | string[] | undefined): ServicePricingTab | null {
  const v = Array.isArray(raw) ? raw[0] : raw;
  if (v === 'standard' || v === 'detailing' || v === 'repairs') return v;
  return null;
}

type ServiceDescTarget =
  | { kind: 'tier'; key: TierKey }
  | { kind: 'addon'; key: DetailingKey | RepairKey };

function serviceDescTitle(target: ServiceDescTarget): string {
  if (target.kind === 'tier') {
    return TIER_DEFS.find((t) => t.key === target.key)?.name ?? 'Service';
  }
  return (
    DETAILING_DEFS.find((d) => d.key === target.key)?.name ??
    REPAIR_DEFS.find((r) => r.key === target.key)?.name ??
    'Service'
  );
}

function serviceDescBlock(target: ServiceDescTarget): ServiceDescBlock | null {
  if (target.kind === 'tier') {
    return STANDARD_TIER_DESCRIPTIONS[target.key] ?? null;
  }
  return ADDON_SERVICE_DESCRIPTIONS[target.key] ?? null;
}

const DETAILING_INFO_ACCENT = '#F59E0B';
const REPAIR_INFO_ACCENT = '#38BDF8';

type ServiceListRowProps = Readonly<{
  name: string;
  priceLabel: string;
  enabled: boolean;
  accent: string;
  icon: IconGlyphName;
  iconPreset?: 'sky' | 'amber' | 'cyan' | 'green' | 'gray';
  iconColors?: readonly [string, string];
  switchValue: boolean;
  switchDisabled?: boolean;
  onPress: () => void;
  onToggle: (next: boolean) => void;
  onInfo?: () => void;
}>;

function ServiceListRow({
  name,
  priceLabel,
  enabled,
  accent,
  icon,
  iconPreset,
  iconColors,
  switchValue,
  switchDisabled,
  onPress,
  onToggle,
  onInfo,
}: ServiceListRowProps) {
  const muted = 'rgba(249,250,251,0.55)';
  return (
    <TouchableOpacity
      activeOpacity={0.88}
      onPress={onPress}
      style={[serviceListStyles.row, { borderColor: enabled ? `${accent}35` : 'rgba(255,255,255,0.08)' }]}
    >
      {iconColors ? (
        <LocationStyleIconBox variant="inline" icon={icon} colors={[iconColors[0], iconColors[1]]} />
      ) : (
        <LocationStyleIconBox variant="inline" icon={icon} preset={iconPreset ?? 'sky'} />
      )}
      <View style={serviceListStyles.copy}>
        <Text style={serviceListStyles.name} numberOfLines={1}>{name}</Text>
        <Text style={[serviceListStyles.price, { color: enabled ? accent : muted }]}>{priceLabel}</Text>
      </View>
      <Text style={[serviceListStyles.status, { color: enabled ? '#4ADE80' : '#F87171' }]}>
        {enabled ? '✓' : '✕'}
      </Text>
      <Switch
        value={switchValue}
        disabled={switchDisabled}
        onValueChange={onToggle}
        trackColor={{ false: 'rgba(255,255,255,0.15)', true: accent }}
        thumbColor={switchValue ? '#fff' : '#9CA3AF'}
      />
      {onInfo ? (
        <TouchableOpacity onPress={onInfo} hitSlop={8}>
          <Ionicons name="information-circle-outline" size={18} color={muted} />
        </TouchableOpacity>
      ) : (
        <Ionicons name="chevron-forward" size={16} color={muted} />
      )}
    </TouchableOpacity>
  );
}

const serviceListStyles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 14,
    paddingHorizontal: 14,
    borderRadius: 14,
    borderWidth: 1,
    backgroundColor: 'rgba(15,23,42,0.45)',
  },
  copy: { flex: 1, minWidth: 0 },
  name: { color: '#F9FAFB', fontSize: 15, fontWeight: '800' },
  price: { fontSize: 13, fontWeight: '700', marginTop: 3 },
  status: { fontSize: 16, fontWeight: '900', width: 18, textAlign: 'center' },
});

export default function ValeterServices() {
  const { user } = useAuth();
  const { tab: tabParam } = useLocalSearchParams<{ tab?: string | string[] }>();
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const headerBg = theme.headerBackground ?? theme.background;
  const toOpaque = (s: string, alpha: number) => {
    if (s.includes('rgba')) return s.replace(/,\s*[\d.]+\)$/, `, ${alpha})`);
    const hexSuffix = alpha === 1 ? 'FF' : 'EE';
    return `${s}${hexSuffix}`;
  };
  const headerGradient: [string, string] = [
    toOpaque(headerBg[0], 1),
    toOpaque(headerBg[1] || headerBg[0], 0.93),
  ];
  const pageGradient: [string, string] = [theme.background[0], theme.background[1]];
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [detailingOffered, setDetailingOffered] = useState(false);
  const [repairsOffered, setRepairsOffered] = useState(false);
  const [detailingItems, setDetailingItems] = useState<DetailingItem[]>(buildDefaultDetailingItems());
  const [repairItems, setRepairItems] = useState<DetailingItem[]>(buildDefaultRepairItems());
  const [tierPricing, setTierPricing] = useState<TierPricing>(defaultTierPricing());
  const [expandedWash, setExpandedWash] = useState(true);
  const [expandedDetailing, setExpandedDetailing] = useState(true);
  const [expandedRepairs, setExpandedRepairs] = useState(true);
  const [selectedTierForPricing, setSelectedTierForPricing] = useState<TierKey | null>(null);
  const [serviceDescTarget, setServiceDescTarget] = useState<ServiceDescTarget | null>(null);
  const [selectedDetailingForPricing, setSelectedDetailingForPricing] = useState<DetailingKey | RepairKey | null>(null);

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 400, useNativeDriver: true }).start();
  }, []);

  useEffect(() => {
    if (user?.id) loadSettings();
  }, [user?.id]);

  useEffect(() => {
    const next = tabFromParam(tabParam);
    if (next === 'detailing') setExpandedDetailing(true);
    if (next === 'repairs') setExpandedRepairs(true);
    if (next === 'standard') setExpandedWash(true);
  }, [tabParam]);

  const dashboardStats = useMemo(
    () => computeServicesDashboardStats(tierPricing, detailingItems, repairItems),
    [tierPricing, detailingItems, repairItems]
  );

  const loadSettings = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('valeter_service_settings')
        .select('*')
        .eq('valeter_id', user.id)
        .maybeSingle();
      if (error) {
        if (isMissingTableErr(error)) {
          Alert.alert('DB setup needed', "The table 'valeter_service_settings' doesn't exist yet.");
        }
        return;
      }
      if (data) {
        setDetailingOffered(data.detailing_offered === true);
        setRepairsOffered(data.repairs_offered === true);
        setDetailingItems(coerceDetailingMenu(data.detailing_menu));
        setRepairItems(coerceRepairMenu(data.repair_menu));
        setTierPricing(coerceTierPricing(data.tier_pricing));
      }
    } catch (e) {
      console.warn('[ValeterServices] load error', e);
    } finally {
      setLoading(false);
    }
  };

  const saveSettings = async () => {
    if (!user?.id) return;
    try {
      setSaving(true);
      const { error } = await supabase.from('valeter_service_settings').upsert(
        {
          valeter_id: user.id,
          detailing_offered: detailingOffered,
          repairs_offered: repairsOffered,
          detailing_menu: { items: detailingItems },
          repair_menu: { items: repairItems },
          tier_pricing: tierPricing,
        },
        { onConflict: 'valeter_id' }
      );
      if (error) {
        if (isMissingTableErr(error)) {
          Alert.alert('DB setup needed', "Create 'valeter_service_settings' first.");
          return;
        }
        throw error;
      }
      Alert.alert('Saved', 'Your services & pricing have been updated.');
    } catch (e: any) {
      Alert.alert('Error', e?.message || 'Failed to save');
    } finally {
      setSaving(false);
    }
  };

  const saveTierSheet = () => {
    if (!selectedTierForPricing) return;
    const row = tierPricing[selectedTierForPricing];
    const label = TIER_DEFS.find((t) => t.key === selectedTierForPricing)?.name ?? selectedTierForPricing;
    const missing = getMissingTierFields(selectedTierForPricing, row);
    if (missing.length > 0) {
      Alert.alert('Complete this block', `${label} needs every size price and the duration filled in before saving.`);
      return;
    }
    setSelectedTierForPricing(null);
  };

  const saveAddonSheet = () => {
    if (!selectedDetailingForPricing) return;
    const item =
      detailingItems.find((x) => x.key === selectedDetailingForPricing) ??
      repairItems.find((x) => x.key === selectedDetailingForPricing) ??
      null;
    if (!item) return;
    const label =
      DETAILING_DEFS.find((d) => d.key === selectedDetailingForPricing)?.name ??
      REPAIR_DEFS.find((r) => r.key === selectedDetailingForPricing)?.name ??
      'Service';
    const missing = getMissingAddonFields(item, label);
    if (missing.length > 0) {
      Alert.alert('Complete this block', `${label} needs every size price filled in before saving.`);
      return;
    }
    setSelectedDetailingForPricing(null);
  };

  const setTierPriceField = (key: TierKey, size: VehicleSizeKey, raw: string) => {
    const v = parseMaybeNumber(raw, 'price');
    setTierPricing((prev) => ({
      ...prev,
      [key]: { ...prev[key], prices: { ...prev[key].prices, [size]: v } },
    }));
  };
  const setTierMinutesField = (key: TierKey, raw: string) => {
    const v = parseMaybeNumber(raw, 'minutes');
    setTierPricing((prev) => ({ ...prev, [key]: { ...prev[key], minutes: v } }));
  };
  const setTierEnabled = (key: TierKey, enabled: boolean) => {
    setTierPricing((prev) => ({ ...prev, [key]: { ...prev[key], enabled } }));
  };
  const toggleDetailingItem = (key: DetailingKey, enabled: boolean) => {
    setDetailingItems((prev) => prev.map((it) => (it.key === key ? { ...it, enabled } : it)));
  };
  const toggleRepairItem = (key: RepairKey, enabled: boolean) => {
    setRepairItems((prev) => prev.map((it) => (it.key === key ? { ...it, enabled } : it)));
  };
  const setDetailingPriceField = (key: DetailingKey | RepairKey, size: VehicleSizeKey, raw: string) => {
    const v = parseMaybeNumber(raw, 'price');
    const isRepair = REPAIR_DEFS.some((d) => d.key === key);
    const setter = isRepair ? setRepairItems : setDetailingItems;
    setter((prev) =>
      prev.map((it) =>
        it.key === key ? { ...it, prices: { ...getDetailingPrices(it), [size]: v } } : it
      )
    );
  };
  const primary = theme.primary || BUSINESS_PRIMARY;
  const glassBorder = theme.glassBorder;
  const muted = theme.textSecondary ?? 'rgba(249,250,251,0.65)';
  const textMain = theme.textPrimary ?? '#F9FAFB';

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={pageGradient} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="valeter" />
        <ValeterScreenHeader title="Services dashboard" />
        <LoadingScreen message="Loading…" />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={pageGradient} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <ValeterScreenHeader title="Services dashboard" />

      <View style={styles.screen}>
        <Animated.ScrollView
          style={styles.scrollView}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={[
            styles.scrollContent,
            { paddingTop: HEADER_CONTENT_OFFSET, paddingBottom: insets.bottom + 24 },
          ]}
        >
          <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
          <Text style={[styles.heroKicker, { color: muted }]}>Business dashboard</Text>
          <Text style={[styles.heroTitle, { color: textMain }]}>Your services</Text>
          <Text style={[styles.heroSubtitle, { color: muted }]}>
            Manage wash packages, detailing, and repairs. Tap any service to edit pricing by vehicle size.
          </Text>

          <View style={[styles.revenueCard, { borderColor: `${primary}40` }]}>
            <BlurView
              intensity={Platform.OS === 'ios' ? 48 : 64}
              tint="dark"
              style={StyleSheet.absoluteFill}
              {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
            />
            <LinearGradient
              colors={[`${primary}22`, 'rgba(15,23,42,0.55)']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={StyleSheet.absoluteFill}
            />
            <View style={styles.revenueHero}>
              <Text style={[styles.revenueHeroLabel, { color: muted }]}>Est. monthly revenue potential</Text>
              <Text style={[styles.revenueHeroValue, { color: primary }]}>
                £{money(dashboardStats.monthlyPotential)}
              </Text>
              <Text style={[styles.revenueHeroHint, { color: muted }]}>Based on your active services & pricing</Text>
            </View>
            <View style={[styles.revenueDivider, { backgroundColor: `${primary}25` }]} />
            <View style={styles.revenueRow}>
              <View style={styles.revenueStat}>
                <Text style={[styles.revenueStatValue, { color: textMain }]}>{dashboardStats.activeCount}</Text>
                <Text style={[styles.revenueStatLabel, { color: muted }]}>Active services</Text>
              </View>
              <View style={[styles.revenueStatDivider, { backgroundColor: `${primary}20` }]} />
              <View style={styles.revenueStat}>
                <Text style={[styles.revenueStatValue, { color: textMain }]}>
                  £{dashboardStats.avgBooking > 0 ? money(dashboardStats.avgBooking) : '0.00'}
                </Text>
                <Text style={[styles.revenueStatLabel, { color: muted }]}>Avg. booking value</Text>
              </View>
            </View>
          </View>

          {/* Wash packages */}
          <Pressable
            onPress={() => { hapticFeedback('light'); setExpandedWash((v) => !v); }}
            style={[styles.categoryHeader, { borderColor: glassBorder }]}
          >
            <View style={styles.categoryHeaderLeft}>
              <Text style={styles.categoryEmoji}>📦</Text>
              <View>
                <Text style={[styles.categoryTitle, { color: textMain }]}>Wash packages</Text>
                <Text style={[styles.categoryMeta, { color: muted }]}>
                  {dashboardStats.activeWashCount} active · {TIER_DEFS.length} total
                </Text>
              </View>
            </View>
            <Ionicons name={expandedWash ? 'chevron-up' : 'chevron-down'} size={20} color={muted} />
          </Pressable>
          {expandedWash && (
            <View style={styles.serviceList}>
              {TIER_DEFS.map((t) => {
                const row = tierPricing[t.key];
                const enabled = row?.enabled !== false;
                const range = formatPriceRange(row?.prices);
                return (
                  <ServiceListRow
                    key={t.key}
                    name={t.name}
                    priceLabel={range}
                    enabled={enabled}
                    accent={primary}
                    icon={t.icon}
                    iconColors={accentToGradient(t.color)}
                    switchValue={enabled}
                    onPress={() => {
                      hapticFeedback('light');
                      setSelectedTierForPricing(t.key);
                    }}
                    onToggle={() => {
                      hapticFeedback('light');
                      setTierEnabled(t.key, !enabled);
                    }}
                    onInfo={() => {
                      hapticFeedback('light');
                      setServiceDescTarget({ kind: 'tier', key: t.key });
                    }}
                  />
                );
              })}
            </View>
          )}

          {/* Detailing */}
          <Pressable
            onPress={() => { hapticFeedback('light'); setExpandedDetailing((v) => !v); }}
            style={[styles.categoryHeader, { borderColor: glassBorder }]}
          >
            <View style={styles.categoryHeaderLeft}>
              <Text style={styles.categoryEmoji}>✨</Text>
              <View style={{ flex: 1 }}>
                <Text style={[styles.categoryTitle, { color: textMain }]}>Detailing services</Text>
                <Text style={[styles.categoryMeta, { color: muted }]}>
                  {dashboardStats.activeDetailCount} active · {DETAILING_DEFS.length} available
                </Text>
              </View>
            </View>
            <View style={styles.categoryHeaderRight}>
              <Switch
                value={detailingOffered}
                onValueChange={() => {
                  hapticFeedback('light');
                  setDetailingOffered((v) => !v);
                }}
                trackColor={{ false: 'rgba(255,255,255,0.12)', true: `${primary}88` }}
                thumbColor={detailingOffered ? '#fff' : '#E5E7EB'}
              />
              <Ionicons name={expandedDetailing ? 'chevron-up' : 'chevron-down'} size={20} color={muted} />
            </View>
          </Pressable>
          {expandedDetailing && (
            <View style={styles.serviceList}>
              {DETAILING_DEFS.map((def) => {
                const item =
                  detailingItems.find((x) => x.key === def.key) ??
                  ({ key: def.key, name: def.name, enabled: false, price: null, prices: defaultTierSizePricing() });
                const enabled = item.enabled && detailingOffered;
                const range = formatPriceRange(getDetailingPrices(item));
                return (
                  <ServiceListRow
                    key={def.key}
                    name={def.name}
                    priceLabel={range}
                    enabled={enabled}
                    accent={DETAILING_INFO_ACCENT}
                    icon={def.icon}
                    iconPreset="amber"
                    switchValue={item.enabled}
                    switchDisabled={!detailingOffered}
                    onPress={() => {
                      if (!detailingOffered) {
                        Alert.alert('Enable detailing', 'Turn on detailing services above to edit pricing.');
                        return;
                      }
                      hapticFeedback('light');
                      setSelectedDetailingForPricing(def.key);
                    }}
                    onToggle={() => {
                      hapticFeedback('light');
                      toggleDetailingItem(def.key, !item.enabled);
                    }}
                    onInfo={() => {
                      hapticFeedback('light');
                      setServiceDescTarget({ kind: 'addon', key: def.key });
                    }}
                  />
                );
              })}
            </View>
          )}

          {/* Repairs */}
          <Pressable
            onPress={() => { hapticFeedback('light'); setExpandedRepairs((v) => !v); }}
            style={[styles.categoryHeader, { borderColor: glassBorder }]}
          >
            <View style={styles.categoryHeaderLeft}>
              <Text style={styles.categoryEmoji}>🔧</Text>
              <View style={{ flex: 1 }}>
                <Text style={[styles.categoryTitle, { color: textMain }]}>Repair services</Text>
                <Text style={[styles.categoryMeta, { color: muted }]}>
                  {dashboardStats.activeRepairCount} active · {REPAIR_DEFS.length} available
                </Text>
              </View>
            </View>
            <View style={styles.categoryHeaderRight}>
              <Switch
                value={repairsOffered}
                onValueChange={() => {
                  hapticFeedback('light');
                  setRepairsOffered((v) => !v);
                }}
                trackColor={{ false: 'rgba(255,255,255,0.12)', true: `${primary}88` }}
                thumbColor={repairsOffered ? '#fff' : '#E5E7EB'}
              />
              <Ionicons name={expandedRepairs ? 'chevron-up' : 'chevron-down'} size={20} color={muted} />
            </View>
          </Pressable>
          {expandedRepairs && (
            <View style={styles.serviceList}>
              {REPAIR_DEFS.map((def) => {
                const item =
                  repairItems.find((x) => x.key === def.key) ??
                  ({ key: def.key, name: def.name, enabled: false, price: null, prices: defaultTierSizePricing() });
                const enabled = item.enabled && repairsOffered;
                const range = formatPriceRange(getDetailingPrices(item));
                return (
                  <ServiceListRow
                    key={def.key}
                    name={def.name}
                    priceLabel={range}
                    enabled={enabled}
                    accent={REPAIR_INFO_ACCENT}
                    icon={def.icon}
                    iconPreset="sky"
                    switchValue={item.enabled}
                    switchDisabled={!repairsOffered}
                    onPress={() => {
                      if (!repairsOffered) {
                        Alert.alert('Enable repairs', 'Turn on repair services above to edit pricing.');
                        return;
                      }
                      hapticFeedback('light');
                      setSelectedDetailingForPricing(def.key);
                    }}
                    onToggle={() => {
                      hapticFeedback('light');
                      toggleRepairItem(def.key, !item.enabled);
                    }}
                    onInfo={() => {
                      hapticFeedback('light');
                      setServiceDescTarget({ kind: 'addon', key: def.key });
                    }}
                  />
                );
              })}
            </View>
          )}

          <ContinueCTAButton
            title="Save Changes"
            onPress={saveSettings}
            accentColor={primary}
            disabled={saving}
            loading={saving}
            style={styles.continueCta}
            leading={<LocationStyleIconBox variant="inline" icon="checkmark-circle" preset="green" />}
          />
          </Animated.View>
        </Animated.ScrollView>
      </View>

      {/* Tier pricing bottom sheet (header-matching) */}
      <Modal visible={!!selectedTierForPricing} transparent animationType="slide" statusBarTranslucent onRequestClose={() => setSelectedTierForPricing(null)}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.sheetContainer}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setSelectedTierForPricing(null)}>
            <View style={[StyleSheet.absoluteFill, styles.sheetBackdrop]} />
          </Pressable>
          <View style={[styles.bottomSheet, styles.bottomSheetHeaderStyle, { paddingBottom: Math.max(insets.bottom, 24), borderColor: theme.glassBorder }]} pointerEvents="box-none">
            <LinearGradient colors={headerGradient} style={StyleSheet.absoluteFill} pointerEvents="none" />
            <View style={styles.sheetHandle} />
            <View style={styles.sheetHeaderRow}>
              <Text style={styles.sheetTitleHeader} numberOfLines={1}>
                {selectedTierForPricing ? TIER_DEFS.find((t) => t.key === selectedTierForPricing)?.name : ''}
              </Text>
              <Pressable
                onPress={() => setSelectedTierForPricing(null)}
                style={({ pressed }) => [styles.sheetCloseBtnHeader, pressed && styles.sheetCloseBtnPressedHeader]}
                hitSlop={12}
              >
                <LocationStyleIconBox variant="card" icon="close" preset="gray" />
              </Pressable>
            </View>
            <ScrollView
              key={selectedTierForPricing ?? 'x'}
              style={styles.sheetScroll}
              contentContainerStyle={styles.sheetScrollContent}
              showsVerticalScrollIndicator={false}
              keyboardShouldPersistTaps="handled"
            >
              <View style={styles.sheetBlock}>
                <Text style={styles.sheetBlockTitle}>Vehicle pricing</Text>
                <Text style={styles.sheetBlockSubtitle}>Set your price for each vehicle type — use real examples so customers know what to pick</Text>
                <View style={styles.sheetList}>
                  {VEHICLE_SIZE_DEFS.map((sizeDef, index) => {
                    const row = selectedTierForPricing ? tierPricing[selectedTierForPricing] : null;
                    const val = row?.prices?.[sizeDef.key];
                    const current = val != null && Number.isFinite(val) ? String(val) : '';
                    const isLast = index === VEHICLE_SIZE_DEFS.length - 1;
                    return (
                      <View key={sizeDef.key} style={[styles.sheetListItem, !isLast && styles.sheetListItemBorder]}>
                        <View style={styles.sheetListItemLeft}>
                          <LocationStyleIconBox
                            variant="inline"
                            icon={sizeDef.icon}
                            colors={accentToGradient(
                              selectedTierForPricing
                                ? TIER_DEFS.find((x) => x.key === selectedTierForPricing)?.color ?? primary
                                : primary
                            )}
                          />
                          <View style={styles.sheetListItemLabelBlock}>
                            <Text style={styles.sheetListItemLabel}>{sizeDef.label}</Text>
                            <Text style={styles.sheetListItemSubtitle}>{sizeDef.subtitle}</Text>
                          </View>
                        </View>
                        <View style={styles.sheetInputWrap}>
                          <Text style={styles.sheetInputPrefix}>£</Text>
                          <TextInput
                            key={`${selectedTierForPricing}-${sizeDef.key}`}
                            style={styles.sheetInput}
                            defaultValue={current}
                            onEndEditing={(e) => selectedTierForPricing && setTierPriceField(selectedTierForPricing, sizeDef.key, e.nativeEvent.text || '')}
                            keyboardType="decimal-pad"
                            placeholder="0.00"
                            placeholderTextColor="rgba(255,255,255,0.4)"
                          />
                        </View>
                      </View>
                    );
                  })}
                </View>
              </View>
              <View style={styles.sheetBlock}>
                <Text style={styles.sheetBlockTitle}>Duration</Text>
                <Text style={styles.sheetBlockSubtitle}>Estimated time per wash in minutes</Text>
                <View style={styles.sheetList}>
                  <View style={styles.sheetListItem}>
                    <View style={styles.sheetListItemLeft}>
                      <LocationStyleIconBox variant="inline" icon="time-outline" preset="cyan" />
                      <Text style={styles.sheetListItemLabel}>Minutes</Text>
                    </View>
                    <View style={styles.sheetInputWrap}>
                      <TextInput
                        key={`${selectedTierForPricing}-min`}
                        style={styles.sheetInput}
                        defaultValue={
                          selectedTierForPricing && tierPricing[selectedTierForPricing]?.minutes != null
                            ? String(tierPricing[selectedTierForPricing].minutes)
                            : ''
                        }
                        onEndEditing={(e) => selectedTierForPricing && setTierMinutesField(selectedTierForPricing, e.nativeEvent.text || '')}
                        keyboardType="number-pad"
                        placeholder="0"
                        placeholderTextColor="rgba(255,255,255,0.4)"
                      />
                      <Text style={styles.sheetInputSuffix}>min</Text>
                    </View>
                  </View>
                </View>
              </View>
            </ScrollView>
            <ContinueCTAButton
              title="Save"
              onPress={saveTierSheet}
              accentColor={primary}
              style={styles.sheetContinueCta}
            />
          </View>
        </KeyboardAvoidingView>
      </Modal>

      {/* Detailing pricing bottom sheet (same design as tier sheet) */}
      <Modal visible={!!selectedDetailingForPricing} transparent animationType="slide" statusBarTranslucent onRequestClose={() => setSelectedDetailingForPricing(null)}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.sheetContainer}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setSelectedDetailingForPricing(null)}>
            <View style={[StyleSheet.absoluteFill, styles.sheetBackdrop]} />
          </Pressable>
          <View style={[styles.bottomSheet, styles.bottomSheetHeaderStyle, { paddingBottom: Math.max(insets.bottom, 24), borderColor: theme.glassBorder }]} pointerEvents="box-none">
            <LinearGradient colors={headerGradient} style={StyleSheet.absoluteFill} pointerEvents="none" />
            <View style={styles.sheetHandle} />
            <View style={styles.sheetHeaderRow}>
              <Text style={styles.sheetTitleHeader} numberOfLines={1}>
                {selectedDetailingForPricing ? (DETAILING_DEFS.find((d) => d.key === selectedDetailingForPricing)?.name ?? REPAIR_DEFS.find((d) => d.key === selectedDetailingForPricing)?.name ?? '') : ''}
              </Text>
              <Pressable
                onPress={() => setSelectedDetailingForPricing(null)}
                style={({ pressed }) => [styles.sheetCloseBtnHeader, pressed && styles.sheetCloseBtnPressedHeader]}
                hitSlop={12}
              >
                <LocationStyleIconBox variant="card" icon="close" preset="gray" />
              </Pressable>
            </View>
            <ScrollView
              key={selectedDetailingForPricing ?? 'x'}
              style={styles.sheetScroll}
              contentContainerStyle={styles.sheetScrollContent}
              showsVerticalScrollIndicator={false}
              keyboardShouldPersistTaps="handled"
            >
              <View style={styles.sheetBlock}>
                <Text style={styles.sheetBlockTitle}>Vehicle pricing</Text>
                <Text style={styles.sheetBlockSubtitle}>Set your price for each vehicle type</Text>
                <View style={styles.sheetList}>
                  {VEHICLE_SIZE_DEFS.map((sizeDef, index) => {
                    const item = selectedDetailingForPricing ? (detailingItems.find((x) => x.key === selectedDetailingForPricing) ?? repairItems.find((x) => x.key === selectedDetailingForPricing)) : null;
                    const prices = item ? getDetailingPrices(item) : defaultTierSizePricing();
                    const val = prices[sizeDef.key];
                    const current = val != null && Number.isFinite(val) ? String(val) : '';
                    const isLast = index === VEHICLE_SIZE_DEFS.length - 1;
                    return (
                      <View key={sizeDef.key} style={[styles.sheetListItem, !isLast && styles.sheetListItemBorder]}>
                        <View style={styles.sheetListItemLeft}>
                          <LocationStyleIconBox
                            variant="inline"
                            icon={sizeDef.icon}
                            preset={
                              selectedDetailingForPricing &&
                              REPAIR_DEFS.some((d) => d.key === selectedDetailingForPricing)
                                ? 'sky'
                                : 'amber'
                            }
                          />
                          <View style={styles.sheetListItemLabelBlock}>
                            <Text style={styles.sheetListItemLabel}>{sizeDef.label}</Text>
                            <Text style={styles.sheetListItemSubtitle}>{sizeDef.subtitle}</Text>
                          </View>
                        </View>
                        <View style={styles.sheetInputWrap}>
                          <Text style={styles.sheetInputPrefix}>£</Text>
                          <TextInput
                            key={`detailing-${selectedDetailingForPricing}-${sizeDef.key}`}
                            style={styles.sheetInput}
                            defaultValue={current}
                            onEndEditing={(e) => selectedDetailingForPricing && setDetailingPriceField(selectedDetailingForPricing, sizeDef.key, e.nativeEvent.text || '')}
                            keyboardType="decimal-pad"
                            placeholder="0.00"
                            placeholderTextColor="rgba(255,255,255,0.4)"
                          />
                        </View>
                      </View>
                    );
                  })}
                </View>
              </View>
            </ScrollView>
            <ContinueCTAButton
              title="Save"
              onPress={saveAddonSheet}
              accentColor={primary}
              style={styles.sheetContinueCta}
            />
          </View>
        </KeyboardAvoidingView>
      </Modal>

      {/* Wash / detailing / repair info bottom sheet */}
      <Modal visible={!!serviceDescTarget} transparent animationType="slide" statusBarTranslucent onRequestClose={() => setServiceDescTarget(null)}>
        <View style={styles.sheetContainer}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setServiceDescTarget(null)}>
            <View style={[StyleSheet.absoluteFill, styles.sheetBackdrop]} />
          </Pressable>
          <View style={[styles.bottomSheet, styles.bottomSheetHeaderStyle, { paddingBottom: Math.max(insets.bottom, 24), borderColor: theme.glassBorder }]} pointerEvents="box-none">
            <LinearGradient colors={headerGradient} style={StyleSheet.absoluteFill} pointerEvents="none" />
            <View style={styles.sheetHandle} />
            <View style={styles.sheetHeaderRow}>
              <Text style={styles.sheetTitleHeader} numberOfLines={2}>
                {serviceDescTarget ? serviceDescTitle(serviceDescTarget) : ''}
              </Text>
              <Pressable
                onPress={() => setServiceDescTarget(null)}
                style={({ pressed }) => [styles.sheetCloseBtnHeader, pressed && styles.sheetCloseBtnPressedHeader]}
                hitSlop={12}
              >
                <LocationStyleIconBox variant="card" icon="close" preset="gray" />
              </Pressable>
            </View>
            <ScrollView
              key={serviceDescTarget ? `${serviceDescTarget.kind}-${serviceDescTarget.key}` : 'desc'}
              style={styles.sheetScroll}
              contentContainerStyle={styles.sheetScrollContent}
              showsVerticalScrollIndicator={false}
            >
              {serviceDescTarget &&
                (() => {
                  const desc = serviceDescBlock(serviceDescTarget);
                  if (!desc) return null;
                  return (
                    <>
                      <View style={styles.sheetBlock}>
                        <Text style={styles.sheetBlockTitle}>Description</Text>
                        <Text style={styles.sheetBlockSubtitle}>{desc.description}</Text>
                      </View>
                      <View style={styles.sheetBlock}>
                        <Text style={styles.sheetBlockTitle}>Includes</Text>
                        {desc.includes.map((item) => (
                          <Text key={item} style={styles.sheetDescBullet}>
                            • {item}
                          </Text>
                        ))}
                      </View>
                      <View style={styles.sheetBlock}>
                        <Text style={styles.sheetBlockTitle}>Best for</Text>
                        <Text style={styles.sheetBlockSubtitle}>{desc.bestFor}</Text>
                      </View>
                    </>
                  );
                })()}
            </ScrollView>
            <ContinueCTAButton
              title="Close"
              onPress={() => setServiceDescTarget(null)}
              accentColor={primary}
              style={styles.sheetContinueCta}
            />
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  screen: { flex: 1, paddingHorizontal: 20 },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 8,
    paddingBottom: 12,
  },
  backButton: {
    width: 44,
    height: 44,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    flex: 1,
    textAlign: 'center',
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '800',
    letterSpacing: -0.3,
  },
  headerSpacer: { width: 44, height: 44 },
  scrollView: { flex: 1 },
  scrollContent: { paddingHorizontal: 0 },
  content: { gap: 0 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12 },
  loadingText: { color: SKY, fontSize: 14 },
  heroKicker: { marginBottom: 6 },
  heroTitle: { fontSize: 26, fontWeight: '800', letterSpacing: -0.4, marginBottom: 8 },
  heroSubtitle: { fontSize: 14, lineHeight: 21, marginBottom: 18 },
  revenueCard: {
    borderRadius: 20,
    borderWidth: 1,
    overflow: 'hidden',
    marginBottom: 22,
    backgroundColor: 'rgba(15,23,42,0.45)',
  },
  revenueHero: {
    paddingHorizontal: 18,
    paddingTop: 18,
    paddingBottom: 14,
  },
  revenueHeroLabel: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
  },
  revenueHeroValue: {
    fontSize: 32,
    fontWeight: '900',
    letterSpacing: -0.5,
    marginTop: 6,
  },
  revenueHeroHint: {
    fontSize: 12,
    marginTop: 4,
    fontWeight: '600',
  },
  revenueDivider: {
    height: 1,
    marginHorizontal: 18,
  },
  revenueRow: {
    flexDirection: 'row',
    paddingVertical: 14,
    paddingHorizontal: 18,
  },
  revenueStat: {
    flex: 1,
    alignItems: 'center',
  },
  revenueStatValue: {
    fontSize: 20,
    fontWeight: '800',
  },
  revenueStatLabel: {
    fontSize: 11,
    fontWeight: '700',
    marginTop: 4,
    textTransform: 'uppercase',
    letterSpacing: 0.3,
  },
  revenueStatDivider: {
    width: 1,
    marginVertical: 4,
  },
  categoryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 14,
    paddingHorizontal: 14,
    borderRadius: 16,
    borderWidth: 1,
    backgroundColor: 'rgba(255,255,255,0.04)',
    marginBottom: 12,
    marginTop: 4,
  },
  categoryHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
    minWidth: 0,
  },
  categoryHeaderRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  categoryEmoji: {
    fontSize: 22,
  },
  categoryTitle: {
    fontSize: 16,
    fontWeight: '800',
  },
  categoryMeta: {
    fontSize: 12,
    fontWeight: '600',
    marginTop: 2,
  },
  serviceList: {
    gap: 8,
    marginBottom: 18,
  },
  headerSection: { marginBottom: 8 },
  sectionTitle: { color: '#F9FAFB', fontSize: 24, fontWeight: '700', marginBottom: 6 },
  sectionSubtitle: { color: 'rgba(249,250,251,0.7)', fontSize: 15, lineHeight: 22 },
  sectionTitleSmall: { color: '#F9FAFB', fontSize: 18, fontWeight: '700', marginBottom: 4 },
  hint: { color: 'rgba(249,250,251,0.6)', fontSize: 13 },
  section: { marginTop: 8 },
  card: { borderRadius: 20, padding: 18, marginBottom: 12 },
  toggleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 12, paddingHorizontal: 4 },
  toggleLabel: { color: '#F9FAFB', fontSize: 15, fontWeight: '600' },
  tabsScroll: { marginTop: 12, marginBottom: 12 },
  tabsScrollContent: { flexDirection: 'row', paddingHorizontal: 4, gap: 8 },
  tab: { paddingVertical: 10, paddingHorizontal: 16, borderRadius: 10, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(255,255,255,0.04)' },
  tabActive: { backgroundColor: 'rgba(135,206,235,0.25)' },
  tabText: { color: 'rgba(249,250,251,0.7)', fontSize: 14, fontWeight: '600' },
  tabTextActive: { color: '#F9FAFB' },
  detailingTabContent: { marginTop: 4 },
  tierList: { gap: 12, marginTop: 8 },
  tierCard: { borderRadius: 20, padding: 0, overflow: 'hidden' },
  tierContent: { padding: 18 },
  tierInfo: { marginBottom: 12 },
  tierTitleRow: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 8 },
  tierName: { color: '#F9FAFB', fontSize: 18, fontWeight: '800', flex: 1 },
  badgeRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  tierBadge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8, borderWidth: 1 },
  tierBadgeText: { color: '#F9FAFB', fontSize: 9, fontWeight: '800', letterSpacing: 0.5 },
  priceSummary: { color: 'rgba(249,250,251,0.85)', fontSize: 16, fontWeight: '700', marginTop: 4 },
  tierCardInfoRow: { flexDirection: 'row', justifyContent: 'flex-end', paddingTop: 10, borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,0.08)', marginTop: 4 },
  tierCardInfoBtn: { padding: 4 },
  switchContainer: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingTop: 12, borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,0.1)' },
  switchLabel: { color: '#F9FAFB', fontSize: 14, fontWeight: '700' },
  switchLabelDisabled: { color: 'rgba(249,250,251,0.5)' },
  detailingList: { gap: 10 },
  detailingCard: { borderRadius: 16, padding: 14 },
  detailingRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  detailingLeft: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  detailingIcon: { width: 40, height: 40, borderRadius: 12, backgroundColor: 'rgba(135,206,235,0.15)', alignItems: 'center', justifyContent: 'center' },
  detailingIconOff: { backgroundColor: 'rgba(255,255,255,0.06)' },
  detailingName: { color: '#F9FAFB', fontSize: 16, fontWeight: '700' },
  detailingNameOff: { color: 'rgba(249,250,251,0.6)' },
  detailingPriceRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 12, paddingTop: 12, borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,0.08)' },
  detailingPriceLabel: { color: 'rgba(249,250,251,0.7)', fontSize: 14 },
  priceInputWrap: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(255,255,255,0.06)', borderRadius: 10, paddingHorizontal: 12, paddingVertical: 8, width: 100 },
  currency: { color: 'rgba(249,250,251,0.6)', fontSize: 14, marginRight: 4 },
  priceInput: { color: '#F9FAFB', fontSize: 14, fontWeight: '700', flex: 1, padding: 0 },
  continueCta: { marginTop: 28, marginBottom: 8 },
  sheetContinueCta: { marginTop: 8 },
  sheetContainer: { flex: 1, justifyContent: 'flex-end' },
  sheetBackdrop: { backgroundColor: 'rgba(0,0,0,0.82)' },
  sheetDescBullet: { color: 'rgba(249,250,251,0.9)', fontSize: 13, lineHeight: 20, marginBottom: 4 },
  bottomSheet: {
    overflow: 'hidden',
    maxHeight: '88%',
    width: '100%',
  },
  bottomSheetHeaderStyle: {
    borderTopLeftRadius: 22,
    borderTopRightRadius: 22,
    paddingHorizontal: 20,
    paddingTop: 8,
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderColor: 'rgba(135,206,235,0.35)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 16,
  },
  sheetOverlay: { backgroundColor: 'rgba(0,0,0,0.06)' },
  sheetHandle: {
    width: 36,
    height: 4,
    backgroundColor: 'rgba(255,255,255,0.35)',
    borderRadius: 2,
    alignSelf: 'center',
    marginBottom: 16,
  },
  sheetHeaderRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20, paddingBottom: 16, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.12)' },
  sheetTitleHeader: { color: '#F9FAFB', fontSize: 20, fontWeight: '600', flex: 1, marginRight: 12 },
  sheetCloseBtnHeader: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent',
  },
  sheetCloseBtnPressedHeader: { backgroundColor: 'rgba(255,255,255,0.15)' },
  sheetScroll: { maxHeight: 400, marginBottom: 16 },
  sheetScrollContent: { paddingBottom: 16 },
  sheetBlock: { marginBottom: 24 },
  sheetBlockTitle: { color: '#F9FAFB', fontSize: 16, fontWeight: '600', marginBottom: 4 },
  sheetBlockSubtitle: { color: 'rgba(249,250,251,0.7)', fontSize: 13, marginBottom: 12, lineHeight: 18 },
  sheetList: { backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: 8, borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)', overflow: 'hidden' },
  sheetListItem: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 14, paddingHorizontal: 16, backgroundColor: 'transparent' },
  sheetListItemBorder: { borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.08)' },
  sheetListItemLeft: { flexDirection: 'row', alignItems: 'center', gap: 12, flex: 1, minWidth: 0 },
  sheetListItemLabelBlock: { flex: 1, minWidth: 0 },
  sheetListItemLabel: { color: '#F9FAFB', fontSize: 15, fontWeight: '600' },
  sheetListItemSubtitle: { color: 'rgba(249,250,251,0.55)', fontSize: 12, fontWeight: '500', marginTop: 2 },
  sheetInputWrap: { flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', backgroundColor: 'rgba(255,255,255,0.08)', borderRadius: 6, paddingHorizontal: 12, paddingVertical: 10, width: 120, minHeight: 44, borderWidth: 1, borderColor: 'rgba(255,255,255,0.15)' },
  sheetInputPrefix: { color: 'rgba(249,250,251,0.7)', fontSize: 14, fontWeight: '500', marginRight: 4 },
  sheetInput: { color: '#F9FAFB', fontSize: 15, fontWeight: '600', flex: 1, minWidth: 36, padding: 0 },
  sheetInputSuffix: { color: 'rgba(249,250,251,0.7)', fontSize: 13, fontWeight: '500', marginLeft: 4 },
});
