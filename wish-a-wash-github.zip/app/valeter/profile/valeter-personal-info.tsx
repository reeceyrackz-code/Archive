import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Dimensions,
  Alert,
  Switch,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { useFocusEffect } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { supabase } from '../../../src/lib/supabase';
import { themeBackgroundGradient } from '../../../src/utils/themeGradient';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import LoadingScreen from '../../../src/components/LoadingScreen';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import ValeterScreenHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/valeter/ValeterScreenHeader';
import GlassCard from '../../../src/components/booking/GlassCard';
import GradientIconBox from '../../../src/components/shared/GradientIconBox';
import { getServicesOfferedFromSettings, type ValeterServiceSettingsRow } from '../../../src/utils/valeterServicesOffered';
import { colors } from '../../../src/constants/colors';
import ContinueCTAButton from '../../../src/components/ui/ContinueCTAButton';

const { width } = Dimensions.get('window');
const SKY = colors.SKY;
const LIGHT_TEXT = '#F9FAFB';
const MUTED_TEXT = 'rgba(249,250,251,0.7)';
const VALETER_BG_FALLBACK: [string, string] = ['#0A1929', '#152238'];

interface ValeterProfileData {
  user_id: string;
  full_name: string;
  business_name?: string;
  bio?: string;
  experience?: string;
  profile_photo_url?: string;
  is_self_sufficient?: boolean;
}

export default function ValeterPersonalInfo() {
  const router = useRouter();
  const { user } = useAuth();
  const { theme } = useAccountTheme();
  const gradientBg = themeBackgroundGradient(theme?.background, VALETER_BG_FALLBACK);
  const primaryAccent = theme.primary || SKY;
  const insets = useSafeAreaInsets();
  const [profile, setProfile] = useState<ValeterProfileData | null>(null);
  const [serviceSettings, setServiceSettings] = useState<ValeterServiceSettingsRow | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (user?.id) {
      loadProfile();
      loadServiceSettings();
    }
  }, [user?.id]);

  useFocusEffect(
    React.useCallback(() => {
      if (user?.id) loadServiceSettings();
    }, [user?.id])
  );

  const loadProfile = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('valeter_profiles')
        .select('*')
        .eq('user_id', user!.id)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      if (data) {
        setProfile(data);
      } else {
        const newProfile: Partial<ValeterProfileData> = {
          user_id: user!.id,
          full_name: user!.name || 'Car Care Pro',
          bio: 'Professional mobile car care pro',
          experience: '0 years',
        };

        const { data: created, error: createError } = await supabase
          .from('valeter_profiles')
          .insert(newProfile)
          .select()
          .single();

        if (createError) throw createError;
        setProfile(created);
      }
    } catch (error: any) {
      console.error('Error loading profile:', error);
      Alert.alert('Error', 'Failed to load profile information');
    } finally {
      setIsLoading(false);
    }
  };

  const loadServiceSettings = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('valeter_service_settings')
        .select('tier_pricing, detailing_offered, detailing_menu')
        .eq('valeter_id', user.id)
        .maybeSingle();
      if (!error && data) setServiceSettings(data);
    } catch {
      // table may not exist
    }
  };

  const handleSaveProfile = async () => {
    if (!user?.id || !profile) return;

    try {
      setIsSaving(true);
      const { error } = await supabase
        .from('valeter_profiles')
        .update({
          full_name: profile.full_name,
          business_name: profile.business_name ?? null,
          bio: profile.bio,
          experience: profile.experience,
          is_self_sufficient: profile.is_self_sufficient,
        })
        .eq('user_id', user.id);

      if (error) throw error;

      Alert.alert('Success', 'Profile updated successfully');
      setIsEditing(false);
    } catch (error: any) {
      console.error('Error saving profile:', error);
      Alert.alert('Error', error.message || 'Failed to save profile');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <LoadingScreen message="Loading…" />
      </SafeAreaView>
    );
  }

  if (!profile) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Failed to load profile</Text>
        </View>
      </SafeAreaView>
    );
  }

  const handleCancelEdit = () => {
    loadProfile();
    setIsEditing(false);
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <ValeterScreenHeader
        title="Personal information"
        rightAction={
          isEditing ? null : (
            <TouchableOpacity
              onPress={async () => { await hapticFeedback('light'); setIsEditing(true); }}
              style={styles.editButton}
              hitSlop={12}
            >
              <Ionicons name="pencil" size={20} color={SKY} />
            </TouchableOpacity>
          )
        }
      />

      <View style={styles.screen}>
        <KeyboardAvoidingView
          style={styles.keyboardView}
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
          keyboardVerticalOffset={0}
        >
          <ScrollView
            style={styles.scrollView}
            contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET, paddingBottom: insets.bottom + 24 }]}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
          >
            <GlassCard style={styles.sectionCard} accountType="valeter">
              <View style={styles.sectionHeaderRow}>
                <GradientIconBox icon="person-outline" preset="sky" boxSize={32} size={16} style={{ marginRight: 10 }} />
                <Text style={styles.sectionCardSubtitle}>Personal details</Text>
              </View>
              <Text style={styles.sectionCardDescription}>Shown to customers and used for your profile</Text>

            <View style={styles.fieldRow}>
              <Text style={styles.fieldLabel}>Name</Text>
              {isEditing ? (
                <TextInput
                  style={styles.fieldInput}
                  value={profile.full_name}
                  onChangeText={(text) => setProfile({ ...profile, full_name: text })}
                  placeholder="Your name"
                  placeholderTextColor={MUTED_TEXT}
                />
              ) : (
                <Text style={styles.fieldValue}>{profile.full_name}</Text>
              )}
            </View>

            <View style={styles.fieldRow}>
              <Text style={styles.fieldLabel}>Business name</Text>
              {isEditing ? (
                <TextInput
                  style={styles.fieldInput}
                  value={profile.business_name ?? ''}
                  onChangeText={(text) => setProfile({ ...profile, business_name: text || undefined })}
                  placeholder="e.g. Joe's Mobile Valeting"
                  placeholderTextColor={MUTED_TEXT}
                />
              ) : (
                <Text style={styles.fieldValue}>{profile.business_name?.trim() ? profile.business_name : 'Not set'}</Text>
              )}
            </View>

            <View style={styles.fieldRow}>
              <Text style={styles.fieldLabel}>Email</Text>
              <Text style={styles.fieldValue}>{user?.email || '—'}</Text>
            </View>

            <View style={styles.fieldRow}>
              <Text style={styles.fieldLabel}>Bio</Text>
              {isEditing ? (
                <TextInput
                  style={[styles.fieldInput, styles.bioInput]}
                  value={profile.bio || ''}
                  onChangeText={(text) => setProfile({ ...profile, bio: text })}
                  placeholder="Tell customers about yourself"
                  placeholderTextColor={MUTED_TEXT}
                  multiline
                  numberOfLines={3}
                />
              ) : (
                <Text style={styles.fieldValue}>{profile.bio || 'No bio added'}</Text>
              )}
            </View>

            <View style={styles.fieldRow}>
              <Text style={styles.fieldLabel}>Experience</Text>
              {isEditing ? (
                <TextInput
                  style={styles.fieldInput}
                  value={profile.experience || ''}
                  onChangeText={(text) => setProfile({ ...profile, experience: text })}
                  placeholder="e.g. 3+ years"
                  placeholderTextColor={MUTED_TEXT}
                />
              ) : (
                <Text style={styles.fieldValue}>{profile.experience || 'Not specified'}</Text>
              )}
            </View>

              <View style={[styles.fieldRow, styles.switchRow]}>
                <View style={styles.switchLabelWrap}>
                  <Text style={styles.fieldLabel}>Self-sufficient</Text>
                  <Text style={styles.fieldHint}>I have my own water and power</Text>
                </View>
                {isEditing ? (
                  <Switch
                    value={profile.is_self_sufficient ?? false}
                    onValueChange={async (value) => {
                      await hapticFeedback('light');
                      setProfile({ ...profile, is_self_sufficient: value });
                      if (user?.id) {
                        try {
                          await supabase
                            .from('valeter_profiles')
                            .update({ is_self_sufficient: value })
                            .eq('user_id', user.id);
                        } catch (e) {
                          console.error('Error saving self-sufficiency:', e);
                        }
                      }
                    }}
                    trackColor={{ false: 'rgba(135,206,235,0.3)', true: SKY }}
                    thumbColor="#FFFFFF"
                  />
                ) : (
                  <Text style={styles.selfSufficientValue}>
                    {profile.is_self_sufficient ? 'Yes' : 'No'}
                  </Text>
                )}
              </View>
            </GlassCard>

          <GlassCard style={styles.sectionCard} accountType="valeter">
            <View style={styles.sectionHeaderRow}>
              <GradientIconBox icon="car-sport-outline" preset="sky" boxSize={32} size={16} style={{ marginRight: 10 }} />
              <Text style={styles.sectionCardSubtitle}>Services you offer</Text>
            </View>
            <Text style={styles.sectionCardDescription}>
              Wash tiers and detailing set in Services & Pricing. Shown on your profile.
            </Text>
            {(() => {
              const offered = getServicesOfferedFromSettings(serviceSettings);
              return offered.length > 0 ? (
                <View style={styles.servicesTagWrap}>
                  {offered.map((name) => (
                    <View key={name} style={styles.servicesTag}>
                      <Text style={styles.servicesTagText}>{name}</Text>
                    </View>
                  ))}
                </View>
              ) : (
                <Text style={styles.servicesEmpty}>No services set yet. Add wash tiers and detailing in Services & Pricing.</Text>
              );
            })()}
            <TouchableOpacity
              style={styles.manageServicesButton}
              onPress={async () => { await hapticFeedback('light'); router.push('/valeter/profile/valeter-services'); }}
              activeOpacity={0.85}
            >
              <Ionicons name="wallet-outline" size={18} color={SKY} />
              <Text style={styles.manageServicesButtonText}>Manage in Services & Pricing</Text>
              <Ionicons name="chevron-forward" size={18} color={SKY} />
            </TouchableOpacity>
          </GlassCard>

          {isEditing && (
            <View style={styles.actionsRow}>
              <ContinueCTAButton
                title="Save changes"
                onPress={handleSaveProfile}
                accentColor={primaryAccent}
                disabled={isSaving}
                loading={isSaving}
              />
              <ContinueCTAButton
                title="Cancel"
                onPress={handleCancelEdit}
                accentColor={primaryAccent}
                disabled={isSaving}
                variant="secondary"
                showTrailingChevron={false}
              />
            </View>
          )}
          </ScrollView>
        </KeyboardAvoidingView>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  screen: { flex: 1, paddingHorizontal: 20 },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 8,
    paddingBottom: 12,
  },
  backButton: {
    width: 44,
    height: 44,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    flex: 1,
    textAlign: 'center',
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '800',
    letterSpacing: -0.3,
  },
  headerSpacer: { width: 44, height: 44 },
  keyboardView: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingTop: 8,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: LIGHT_TEXT,
    marginTop: 16,
    fontSize: 15,
  },
  editButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  sectionCard: {
    padding: 20,
    marginBottom: 20,
    borderRadius: 20,
  },
  sectionHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  sectionCardSubtitle: {
    color: LIGHT_TEXT,
    fontSize: 16,
    fontWeight: '800',
  },
  sectionCardDescription: {
    color: MUTED_TEXT,
    fontSize: 13,
    marginBottom: 16,
  },
  fieldRow: {
    marginBottom: 16,
  },
  fieldLabel: {
    color: MUTED_TEXT,
    fontSize: 12,
    fontWeight: '700',
    marginBottom: 6,
    textTransform: 'uppercase',
    letterSpacing: 0.4,
  },
  fieldValue: {
    color: LIGHT_TEXT,
    fontSize: 16,
    fontWeight: '600',
  },
  fieldHint: {
    color: MUTED_TEXT,
    fontSize: 12,
    marginTop: 2,
  },
  fieldInput: {
    color: LIGHT_TEXT,
    fontSize: 16,
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.2)',
  },
  bioInput: {
    minHeight: 80,
    textAlignVertical: 'top',
  },
  switchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },
  switchLabelWrap: {
    flex: 1,
  },
  selfSufficientValue: {
    color: LIGHT_TEXT,
    fontSize: 16,
    fontWeight: '700',
  },
  actionsRow: {
    gap: 12,
    marginTop: 8,
  },
  servicesTagWrap: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 14,
  },
  servicesTag: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 10,
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  servicesTagText: {
    color: LIGHT_TEXT,
    fontSize: 13,
    fontWeight: '700',
  },
  servicesEmpty: {
    color: MUTED_TEXT,
    fontSize: 14,
    marginBottom: 14,
    fontStyle: 'italic',
  },
  manageServicesButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  manageServicesButtonText: {
    flex: 1,
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
  },
});
