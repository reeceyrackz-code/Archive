import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  Animated,
  RefreshControl,
  Alert,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import {
  fetchBusinessNotificationFeed,
  type BusinessNotificationItem,
  type NotificationPriority,
} from '../../src/services/businessNotificationsFeed';
import {
  loadDismissedBusinessNotificationIds,
  dismissBusinessNotificationIds,
} from '../../src/services/businessNotificationDismissals';
import AppHeader, { HEADER_HEIGHT } from '../../src/components/shared/AppHeader';
import GradientIconBox, { LocationStyleIconBox } from '../../src/components/shared/GradientIconBox';
import {
  NotificationInboxRow,
  businessNotificationIconAccent,
} from '../../src/components/shared/NotificationInboxRow';
import DefaultLoadingSkeleton from '../../src/components/shared/DefaultLoadingSkeleton';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import { SCREEN_PADDING_H } from '../../src/constants/premiumTokens';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import { accentToGradient } from '../../src/utils/accentGradient';

type NotificationItem = BusinessNotificationItem;

export default function BusinessNotificationsFull() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme: businessTheme } = useAccountTheme();
  
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [dismissedIds, setDismissedIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const organizationId = user?.organizationId ?? null;

  const visibleNotifications = useMemo(
    () => notifications.filter((n) => !dismissedIds.has(n.id)),
    [notifications, dismissedIds]
  );

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start();

    if (organizationId) {
      void (async () => {
        const dismissed = await loadDismissedBusinessNotificationIds(organizationId);
        setDismissedIds(dismissed);
        await fetchNotifications();
      })();
    } else {
      setLoading(false);
    }
  }, [organizationId]);

  const fetchNotifications = async (isRefresh = false) => {
    if (!organizationId) return;

    try {
      if (isRefresh) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }

      const notificationItems = await fetchBusinessNotificationFeed(organizationId);
      setNotifications(notificationItems);
    } catch (error) {
      console.error('Error fetching notifications:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const handleDismissOne = useCallback(
    async (id: string) => {
      if (!organizationId) return;
      await hapticFeedback('light');
      const next = await dismissBusinessNotificationIds(organizationId, [id]);
      setDismissedIds(next);
    },
    [organizationId]
  );

  const handleClearAllVisible = useCallback(() => {
    if (!organizationId || visibleNotifications.length === 0) return;
    Alert.alert(
      'Clear all notifications?',
      'This hides every item in the list from your inbox. Underlying bookings and team activity are not deleted.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Clear all',
          style: 'destructive',
          onPress: async () => {
            await hapticFeedback('medium');
            const ids = visibleNotifications.map((n) => n.id);
            const next = await dismissBusinessNotificationIds(organizationId, ids);
            setDismissedIds(next);
          },
        },
      ]
    );
  }, [organizationId, visibleNotifications]);

  const handleNotificationPress = async (item: NotificationItem) => {
    await hapticFeedback('light');

    if (item.type === 'booking_update' && item.bookingId) {
      const isActive =
        item.title === 'Booking In Progress' ||
        item.message.toLowerCase().includes('in progress');
      if (isActive) {
        router.push('/business/dashboard');
        return;
      }
    }

    if (item.route) {
      router.push(item.route as any);
    }
  };

  const getPriorityColor = (priority: NotificationPriority) => {
    switch (priority) {
      case 'high':
        return '#EF4444';
      case 'medium':
        return '#FBBF24';
      case 'low':
        return '#10B981';
      default:
        return businessTheme.primary;
    }
  };

  const renderNotification = ({ item }: { item: NotificationItem }) => {
    const meta = businessNotificationIconAccent(item.type, businessTheme.primary);
    const priorityColor = getPriorityColor(item.priority);

    return (
      <NotificationInboxRow
        title={item.title}
        message={item.message}
        timeLine={item.time}
        icon={meta.icon}
        accentColor={meta.accent}
        onPress={() => void handleNotificationPress(item)}
        onDismiss={() => void handleDismissOne(item.id)}
        dismissMode="swipe"
        showChevron
        chevronAccentColor={businessTheme.primary}
        priorityUrgent={item.priority === 'high'}
        priorityColor={priorityColor}
      />
    );
  };

  const listHeader = useMemo(
    () =>
      visibleNotifications.length > 0 ? (
        <View style={styles.feedHeader}>
          <Text style={styles.feedSubtitle}>
            {visibleNotifications.length} update{visibleNotifications.length !== 1 ? 's' : ''}
          </Text>
          <Text style={styles.feedHint}>Bookings, team requests, and alerts.</Text>
        </View>
      ) : null,
    [visibleNotifications.length]
  );

  return (
    <View style={styles.container}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />
      <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
        
        <AppHeader
          title="Notifications"
          accountType="business"
          rightAction={
            <View style={styles.headerActions}>
              {visibleNotifications.length > 0 ? (
                <TouchableOpacity
                  onPress={handleClearAllVisible}
                  style={styles.clearAllHeaderBtn}
                  accessibilityLabel="Clear all notifications"
                >
                  <Text style={[styles.clearAllHeaderText, { color: businessTheme.primary }]}>Clear all</Text>
                </TouchableOpacity>
              ) : null}
              <TouchableOpacity
                onPress={() => router.push('/business/notification-settings' as any)}
                style={styles.settingsButton}
                accessibilityLabel="Notification settings"
              >
                <LocationStyleIconBox
                  variant="inline"
                  icon="settings-outline"
                  colors={accentToGradient(businessTheme.primary)}
                />
              </TouchableOpacity>
            </View>
          }
        />

        <View
          style={[
            styles.scrollClipWrapper,
            {
              marginTop: HEADER_HEIGHT,
            },
          ]}
        >
          {loading && !refreshing ? (
            <DefaultLoadingSkeleton message="Loading notifications…" variant="rich" />
          ) : (
            <FlatList
              data={visibleNotifications}
              renderItem={renderNotification}
              keyExtractor={(item) => item.id}
              contentContainerStyle={[styles.listContent, { paddingBottom: insets.bottom + 40 }]}
              showsVerticalScrollIndicator={false}
              ListHeaderComponent={listHeader}
              ItemSeparatorComponent={() => <View style={styles.rowSeparator} />}
              ListEmptyComponent={
                <View style={styles.emptyContainer}>
                  <GradientIconBox
                    icon="notifications-off-outline"
                    preset="sky"
                    boxSize={88}
                    size={44}
                  />
                  {notifications.length > 0 ? (
                    <>
                      <Text style={styles.emptyText}>All cleared</Text>
                      <Text style={styles.emptySubtext}>
                        You dismissed every item in your inbox. Pull down to refresh — new activity will show up again.
                      </Text>
                    </>
                  ) : (
                    <>
                      <Text style={styles.emptyText}>No notifications yet</Text>
                      <Text style={styles.emptySubtext}>
                        When you get new bookings or team requests, they&apos;ll appear here.
                      </Text>
                    </>
                  )}
                </View>
              }
              refreshControl={
                <RefreshControl
                  refreshing={refreshing}
                  onRefresh={() => fetchNotifications(true)}
                  tintColor={businessTheme.primary}
                  colors={[businessTheme.primary]}
                />
              }
            />
          )}
        </View>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { 
    flex: 1,
  },
  scrollClipWrapper: {
    flex: 1,
    overflow: 'hidden',
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  clearAllHeaderBtn: {
    paddingVertical: 8,
    paddingHorizontal: 10,
    justifyContent: 'center',
  },
  clearAllHeaderText: {
    fontSize: 15,
    fontWeight: '600',
  },
  settingsButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  rowSeparator: {
    height: 10,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 15,
    fontWeight: '500',
  },
  feedHeader: {
    paddingHorizontal: SCREEN_PADDING_H,
    paddingBottom: 16,
    marginBottom: 4,
  },
  feedSubtitle: {
    color: 'rgba(249,250,251,0.65)',
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 20,
  },
  feedHint: {
    color: 'rgba(249,250,251,0.45)',
    fontSize: 12,
    fontWeight: '500',
    marginTop: 4,
  },
  listContent: {
    paddingHorizontal: SCREEN_PADDING_H,
    gap: 12,
  },
  emptyContainer: {
    padding: 40,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 60,
    gap: 16,
  },
  emptyIconWrap: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(125,211,252,0.08)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  emptyText: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
  },
  emptySubtext: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 22,
    paddingHorizontal: 20,
  },
});
