/**
 * Business Inbox – Chat with customers. Redesigned messages list with
 * grouped threads, initials avatars, and glass-style cards.
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  RefreshControl,
  Alert,
} from 'react-native';
import { router } from 'expo-router';
import { ChromeGlyph as Ionicons } from '../../src/components/shared/ChromeGlyph';
import Animated, { FadeInDown, FadeIn } from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import ScreenLayout from '../../src/components/layout/ScreenLayout';
import EmptyState from '../../src/components/shared/EmptyState';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { colors } from '../../src/constants/colors';
import { getServiceDisplayName } from '../../src/utils/serviceNameMapper';
import { formatDisplayName } from '../../src/utils/formatDisplayName';
import LoadingScreen from '../../src/components/LoadingScreen';
import { loadActiveBookingsForOrganization, type BusinessActiveBooking } from '../../src/services/BusinessBookingsService';
import { getDeletedChatBookingIds, addMultipleDeletedChatBookingIds } from '../../src/services/DeletedChatsService';

const SKY = colors.SKY;
const CARD_RADIUS = 20;
const AVATAR_SIZE = 52;
const MUTED = 'rgba(241,245,249,0.55)';
const SURFACE = 'rgba(255,255,255,0.06)';
const BORDER = 'rgba(148,163,184,0.15)';

function getInitials(name: string): string {
  const parts = String(name || '').trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return '?';
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + (parts.at(-1)?.[0] || '')).toUpperCase();
}

function formatRelativeDate(iso: string): string {
  const d = new Date(iso);
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffDays = Math.floor(diffMs / (24 * 60 * 60 * 1000));
  if (diffDays === 0) return d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
  if (diffDays === 1) return 'Yesterday';
  if (diffDays < 7) return d.toLocaleDateString('en-GB', { weekday: 'short' });
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
}

function getCustomerThreadKey(thread: BusinessActiveBooking): string {
  return thread.customer_id ?? String(thread.customer_email || thread.customer_phone || thread.customer_name || thread.id).toLowerCase();
}

export default function BusinessInboxScreen() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [threads, setThreads] = useState<BusinessActiveBooking[]>([]);

  const organizationId = user?.organizationId ?? null;

  const loadThreads = useCallback(async () => {
    if (!organizationId) {
      setThreads([]);
      setLoading(false);
      setRefreshing(false);
      return;
    }
    try {
      const [list, deletedIds] = await Promise.all([
        loadActiveBookingsForOrganization(organizationId),
        getDeletedChatBookingIds(),
      ]);
      const hiddenIds = new Set<string>(deletedIds);
      const visible = list.filter((t) => !hiddenIds.has(t.id));
      const uniqueByCustomer = new Map<string, BusinessActiveBooking>();
      visible.forEach((thread) => {
        const key = getCustomerThreadKey(thread);
        if (!uniqueByCustomer.has(key)) {
          uniqueByCustomer.set(key, thread);
        }
      });
      setThreads(Array.from(uniqueByCustomer.values()));
    } catch (e) {
      console.error('[BusinessInbox] load error', e);
      setThreads([]);
      Alert.alert('Couldn’t load messages', 'Pull down to try again.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [organizationId]);

  useEffect(() => {
    loadThreads();
  }, [loadThreads]);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    loadThreads();
  }, [loadThreads]);

  const openChat = useCallback((bookingId: string) => {
    hapticFeedback('light');
    router.push({ pathname: '/business/bookings/chat', params: { id: bookingId } } as any);
  }, []);

  const handleClearAll = () => {
    if (threads.length === 0) return;
    hapticFeedback('medium');
    Alert.alert(
      'Clear all chats',
      'Remove all conversations from this list? You can still see bookings in Activity.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Clear all',
          style: 'destructive',
          onPress: () => {
            const ids = threads.map((t) => t.id);
            void addMultipleDeletedChatBookingIds(ids).then(() => setThreads([]));
          },
        },
      ]
    );
  };

  const pluralSuffix = threads.length === 1 ? '' : 's';
  const threadCountLabel =
    threads.length > 0 ? `${threads.length} active conversation${pluralSuffix}` : 'Only active jobs appear here';

  const background = (
    <LinearGradient
      colors={['#0f172a', '#1e293b', '#0f172a']}
      locations={[0, 0.4, 1]}
      style={StyleSheet.absoluteFill}
    />
  );

  if (loading) {
    return <LoadingScreen message="Loading messages…" />;
  }

  return (
    <ScreenLayout
      header={null}
      background={background}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />}
    >
      {threads.length === 0 ? (
        <Animated.View entering={FadeIn.delay(80)} style={styles.emptyContainer}>
          <EmptyState
            icon="chatbubbles-outline"
            title="No active chats"
            subtitle="Only customers with active jobs appear in inbox. Completed or deleted chats are hidden."
            actionLabel="Go to dashboard"
            onAction={() => router.push('/business/dashboard')}
            iconColor={SKY}
            style={styles.emptyState}
          />
        </Animated.View>
      ) : (
        <View style={styles.list}>
          <View style={styles.section}>
            <View style={styles.sectionLabelRow}>
              <Text style={styles.sectionLabel}>Active jobs</Text>
              <View style={styles.sectionPill}>
                <Text style={styles.sectionPillText}>{threads.length}</Text>
              </View>
            </View>
            {threads.map((thread, index) => (
              <Animated.View
                key={thread.id}
                entering={FadeInDown.delay(60 + index * 40)}
                style={styles.threadWrap}
              >
                <TouchableOpacity
                  activeOpacity={0.7}
                  onPress={() => openChat(thread.id)}
                  style={styles.threadTouch}
                  accessibilityRole="button"
                  accessibilityLabel={`Chat with ${formatDisplayName(thread.customer_name)}, ${getServiceDisplayName(thread.service_type, thread.service_name)}`}
                >
                  <View style={styles.card}>
                    <View style={styles.avatarContainer}>
                      <LinearGradient
                        colors={[SKY + 'DD', SKY + '99']}
                        style={styles.avatarGradient}
                      >
                        <Text style={styles.avatarText}>{getInitials(thread.customer_name)}</Text>
                      </LinearGradient>
                    </View>
                    <View style={styles.cardContent}>
                      <View style={styles.topRow}>
                        <Text style={styles.customerName} numberOfLines={1}>
                          {formatDisplayName(thread.customer_name)}
                        </Text>
                        <Text style={styles.date}>{formatRelativeDate(thread.created_at)}</Text>
                      </View>
                      <View style={styles.serviceRow}>
                        <View style={styles.servicePill}>
                          <Text style={styles.servicePillText} numberOfLines={1}>
                            {getServiceDisplayName(thread.service_type, thread.service_name)}
                          </Text>
                        </View>
                        <View style={styles.statusPill}>
                          <Text style={styles.statusPillText}>{String(thread.status || 'active').replaceAll('_', ' ')}</Text>
                        </View>
                      </View>
                      {thread.location_address ? (
                        <View style={styles.addressRow}>
                          <Ionicons name="location-outline" size={12} color={MUTED} />
                          <Text style={styles.addressText} numberOfLines={1}>
                            {thread.location_address}
                          </Text>
                        </View>
                      ) : null}
                    </View>
                    <View style={styles.chevronWrap}>
                      <Ionicons name="chevron-forward" size={20} color={MUTED} />
                    </View>
                  </View>
                </TouchableOpacity>
              </Animated.View>
            ))}
          </View>
        </View>
      )}
    </ScreenLayout>
  );
}

const styles = StyleSheet.create({
  headerAction: { padding: 6 },
  emptyContainer: { flex: 1, minHeight: 280, justifyContent: 'center', paddingHorizontal: 16 },
  emptyState: { marginHorizontal: 0 },
  list: { paddingBottom: 24 },
  section: { marginBottom: 24 },
  sectionLabelRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    paddingHorizontal: 4,
    gap: 8,
  },
  sectionLabel: {
    fontSize: 13,
    fontWeight: '700',
    color: MUTED,
    letterSpacing: 0.5,
  },
  sectionPill: {
    backgroundColor: SURFACE,
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 10,
  },
  sectionPillText: { fontSize: 11, fontWeight: '800', color: '#94A3B8' },
  threadWrap: { marginBottom: 10 },
  threadTouch: { width: '100%' },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: CARD_RADIUS,
    overflow: 'hidden',
    padding: 14,
    backgroundColor: SURFACE,
    borderWidth: 1,
    borderColor: BORDER,
  },
  avatarContainer: { marginRight: 14 },
  avatarGradient: {
    width: AVATAR_SIZE,
    height: AVATAR_SIZE,
    borderRadius: AVATAR_SIZE / 2,
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: { fontSize: 18, fontWeight: '800', color: '#fff', letterSpacing: 0.5 },
  cardContent: { flex: 1, minWidth: 0 },
  topRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 4,
    gap: 8,
  },
  customerName: { fontSize: 16, fontWeight: '700', color: '#F1F5F9', flex: 1 },
  date: { fontSize: 12, fontWeight: '600', color: MUTED },
  serviceRow: { marginBottom: 2 },
  statusPill: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(16,185,129,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.45)',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 999,
    marginTop: 4,
  },
  statusPillText: {
    fontSize: 10,
    color: '#34D399',
    fontWeight: '700',
    textTransform: 'capitalize',
  },
  servicePill: {
    alignSelf: 'flex-start',
    backgroundColor: SKY + '28',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
    maxWidth: '100%',
  },
  servicePillText: { fontSize: 12, fontWeight: '700', color: SKY },
  addressRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 4 },
  addressText: { fontSize: 11, color: MUTED, flex: 1 },
  chevronWrap: { marginLeft: 8 },
});
