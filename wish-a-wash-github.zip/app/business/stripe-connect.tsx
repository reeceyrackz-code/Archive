import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  TouchableOpacity,
  Linking,
  ActivityIndicator,
  Modal,
  Pressable,
  Animated,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useLocalSearchParams } from 'expo-router';
import { ChromeGlyph as Ionicons } from '../../src/components/shared/ChromeGlyph';

import { useAuth } from '../../src/providers/enhanced-auth-context';
import {
  businessOnboardingService,
  BusinessOnboardingStatus,
  type StripeConnectStatus,
} from '../../src/services/businessOnboardingService';
import { stripeConnectService } from '../../src/services/stripeConnectService';
import GlassCard from '../../src/components/booking/GlassCard';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';
import LoadingScreen from '../../src/components/LoadingScreen';

const LIGHT_TEXT = '#F9FAFB';
const MUTED = 'rgba(249,250,251,0.72)';

function formatStripeStatus(status: StripeConnectStatus | undefined): string {
  switch (status) {
    case 'not_started':
      return 'Not started';
    case 'in_progress':
      return 'In progress';
    case 'completed':
      return 'Connected';
    case 'restricted':
      return 'Restricted';
    case 'rejected':
      return 'Rejected';
    default:
      return 'Unknown';
  }
}

function shortenAccountId(id: string | null | undefined): string {
  if (!id || id.length < 12) return id || 'Not linked yet';
  return `${id.slice(0, 10)}…${id.slice(-4)}`;
}

function formatTimestamp(value: string | null | undefined): string {
  if (!value) return 'Not available';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString('en-GB', {
    dateStyle: 'medium',
    timeStyle: 'short',
  });
}

function formatRelativeTimestamp(value: string | null | undefined): string {
  if (!value) return 'not synced yet';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;

  const diffMs = Date.now() - date.getTime();
  const diffMinutes = Math.max(1, Math.round(diffMs / 60000));
  if (diffMinutes < 60) return `${diffMinutes}m ago`;
  const diffHours = Math.round(diffMinutes / 60);
  if (diffHours < 24) return `${diffHours}h ago`;
  const diffDays = Math.round(diffHours / 24);
  return `${diffDays}d ago`;
}

export default function BusinessStripeConnectScreen() {
  const { user, logout } = useAuth();
  const params = useLocalSearchParams();
  const insets = useSafeAreaInsets();
  const { theme: businessTheme } = useAccountTheme();
  const primary = businessTheme.primary;
  const scrollY = useRef(new Animated.Value(0)).current;
  const isOnboardingMode = params?.mode === 'onboarding';

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [status, setStatus] = useState<BusinessOnboardingStatus | null>(null);
  const [dialogVisible, setDialogVisible] = useState(false);
  const [dialogTitle, setDialogTitle] = useState('');
  const [dialogMessage, setDialogMessage] = useState('');
  const [dialogType, setDialogType] = useState<'error' | 'warning' | 'info'>('info');
  const [dialogActions, setDialogActions] = useState<Array<{ label: string; kind?: 'primary' | 'secondary' | 'danger'; onPress?: () => void }>>([]);

  const openDialog = (
    title: string,
    message: string,
    type: 'error' | 'warning' | 'info' = 'info',
    actions: Array<{ label: string; kind?: 'primary' | 'secondary' | 'danger'; onPress?: () => void }> = [{ label: 'Close', kind: 'primary' }]
  ) => {
    setDialogTitle(title);
    setDialogMessage(message);
    setDialogType(type);
    setDialogActions(actions);
    setDialogVisible(true);
  };

  const load = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      const next = await businessOnboardingService.getStatus(user.id);
      setStatus(next);
    } catch (error: any) {
      openDialog('Unable to load Stripe setup', error?.message || 'Failed to load Stripe Connect status.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, [user?.id]);

  useEffect(() => {
    if (!params?.stripe_return && !params?.stripe_refresh) return;
    void handleCheckStatus(true);
  }, [params?.stripe_return, params?.stripe_refresh]);

  const startConnect = async () => {
    if (saving) return;
    try {
      await hapticFeedback('light');
      setSaving(true);
      if (user?.id) {
        await businessOnboardingService.setStripeSkipForNow(user.id, false);
      }
      const { url } = await stripeConnectService.createOnboardingLink();
      await Linking.openURL(url);
    } catch (error: any) {
      openDialog('Unable to start Stripe Connect', error?.message || 'Failed to start Stripe Connect.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleCheckStatus = async (silent = false) => {
    if (saving) return;
    try {
      await hapticFeedback('light');
      setSaving(true);
      const result = await stripeConnectService.syncStatusFromStripe();
      await load();
      if (result.stripeConnectStatus === 'completed') {
        router.replace('/business/dashboard');
        return;
      }
      if (!silent) {
        openDialog(
          'Stripe setup still incomplete',
          'Finish all required steps in Stripe, then return here and tap “Refresh status”.',
          'warning'
        );
      }
    } catch (error: any) {
      openDialog('Unable to check Stripe status', error?.message || 'Failed to check Stripe status.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleBackOrLogout = async () => {
    if (saving) return;

    if (isOnboardingMode) {
      try {
        await hapticFeedback('medium');
        setSaving(true);
        await logout();
        router.replace('/auth/login');
      } catch (error: any) {
        openDialog('Unable to log out', error?.message || 'Failed to log out.', 'error');
      } finally {
        setSaving(false);
      }
      return;
    }

    router.back();
  };

  if (loading) {
    return <LoadingScreen message="Loading payout setup…" />;
  }

  const stripeState = status?.stripeConnectStatus ?? 'not_started';
  const isComplete = stripeState === 'completed';
  const canContinueToApp = stripeState === 'completed' || stripeState === 'in_progress';
  const stripeDetails = status?.stripeDetails ?? {};
  const stripePayoutsEnabled = status?.stripeDetails?.payoutsEnabled;
  const stripeChargesEnabled = status?.stripeDetails?.chargesEnabled;
  const stripeDetailsSubmitted = status?.stripeDetails?.detailsSubmitted;
  const stripeSyncedAt =
    (stripeDetails as Record<string, any>).updated_from_stripe_at ??
    (stripeDetails as Record<string, any>).updated_from_stripe_webhook_at ??
    status?.stripeOnboardingCompletedAt ??
    status?.stripeOnboardingStartedAt ??
    null;

  const statusTitle =
    stripeState === 'completed'
      ? 'Stripe connected'
      : stripeState === 'restricted'
        ? 'Stripe needs attention'
        : stripeState === 'rejected'
          ? 'Stripe was rejected'
          : stripeState === 'in_progress'
            ? 'Stripe setup in progress'
            : 'Stripe not connected yet';
  const statusBody =
    stripeState === 'completed'
      ? 'Your business can receive platform payouts. Stripe decides the final transfer timing and verification state.'
      : stripeState === 'restricted'
        ? 'Stripe has paused this account until the remaining verification steps are completed.'
        : stripeState === 'rejected'
          ? 'Stripe could not approve the account yet. Check the verification details and update the business information.'
          : stripeState === 'in_progress'
            ? 'You’ve started onboarding. Finish the remaining steps in Stripe and tap Refresh status here.'
            : 'Connect Stripe to activate payouts and account verification for this business.';

  const handleContinueToApp = () => {
    router.replace('/business/dashboard');
  };

  return (
    <View style={styles.flex}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />

      <SafeAreaView style={styles.flex} edges={['top', 'left', 'right']}>
        <Animated.ScrollView
          style={styles.scroll}
          showsVerticalScrollIndicator={false}
          onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
          scrollEventThrottle={16}
          contentContainerStyle={[
            styles.scrollInner,
            {
              paddingTop: 18 + insets.top,
              paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 48,
            },
          ]}
        >
          <View style={styles.topActionRow}>
            <TouchableOpacity style={[styles.topActionButton, { borderColor: `${primary}30` }]} onPress={handleBackOrLogout} activeOpacity={0.85}>
              <Ionicons name={isOnboardingMode ? 'log-out-outline' : 'chevron-back'} size={18} color={LIGHT_TEXT} />
              <Text style={styles.topActionText}>{isOnboardingMode ? 'Log out' : 'Back'}</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.centerHero}>
            <View style={styles.stripeLogoWrap}>
              <View style={styles.stripeLogoGlow} />
              <Image source={require('../../assets/stripe/img.png')} style={styles.stripeLogoImage} resizeMode="contain" />
            </View>
            <Text style={styles.heroStatusText}>{statusTitle}</Text>
            <Text style={styles.heroStatusBody}>{statusBody}</Text>
          </View>

          <GlassCard style={styles.sectionCard} accountType="business">
            <Text style={styles.sectionHeading}>Current status</Text>
            <View style={styles.statusBlock}>
              <View style={styles.statusRowCompact}>
                <Text style={styles.metaLabel}>{isComplete ? 'Connection' : 'Connection status'}</Text>
                <View style={[styles.statusPill, isComplete && { borderColor: `${primary}55`, backgroundColor: `${primary}18` }]}>
                  <View style={[styles.statusDot, { backgroundColor: isComplete ? '#34D399' : '#FBBF24' }]} />
                  <Text style={[styles.statusPillText, { color: LIGHT_TEXT }]}>{formatStripeStatus(stripeState)}</Text>
                </View>
              </View>
              <View style={styles.accountBlock}>
                <Text style={styles.accountLabel}>Stripe account</Text>
                <Text style={styles.accountValue} numberOfLines={1}>
                  {shortenAccountId(status?.stripeAccountId)}
                </Text>
              </View>
            </View>
            {isComplete && (
              <View style={styles.connectionSummaryGrid}>
                <View style={styles.connectionSummaryItem}>
                  <Text style={styles.connectionSummaryLabel}>Details submitted</Text>
                  <Text style={styles.connectionSummaryValue}>
                    {stripeDetailsSubmitted === undefined ? 'Unknown' : stripeDetailsSubmitted ? 'Yes' : 'No'}
                  </Text>
                </View>
                <View style={styles.connectionSummaryItem}>
                  <Text style={styles.connectionSummaryLabel}>Charges enabled</Text>
                  <Text style={styles.connectionSummaryValue}>
                    {stripeChargesEnabled === undefined ? 'Unknown' : stripeChargesEnabled ? 'Yes' : 'No'}
                  </Text>
                </View>
                <View style={styles.connectionSummaryItem}>
                  <Text style={styles.connectionSummaryLabel}>Payouts enabled</Text>
                  <Text style={styles.connectionSummaryValue}>
                    {stripePayoutsEnabled === undefined ? 'Unknown' : stripePayoutsEnabled ? 'Yes' : 'No'}
                  </Text>
                </View>
                <View style={styles.connectionSummaryItem}>
                  <Text style={styles.connectionSummaryLabel}>Completed</Text>
                  <Text style={styles.connectionSummaryValue}>{formatTimestamp(status?.stripeOnboardingCompletedAt)}</Text>
                </View>
                <View style={styles.connectionSummaryItem}>
                  <Text style={styles.connectionSummaryLabel}>Last synced</Text>
                  <Text style={styles.connectionSummaryValue}>{formatRelativeTimestamp(stripeSyncedAt)}</Text>
                </View>
              </View>
            )}
          </GlassCard>

          <GlassCard style={styles.sectionCard} accountType="business">
            <Text style={styles.sectionHeading}>{isComplete ? 'What’s next' : 'Before you start'}</Text>
            {isComplete ? (
              <>
                {[
                  'Use Refresh status if you update anything in Stripe.',
                  'Use Update Stripe details if your bank or business info changes.',
                  'You can keep managing the account from Stripe without repeating onboarding here.',
                ].map((line, i) => (
                  <View key={i} style={styles.stepRow}>
                    <View style={[styles.stepNum, { borderColor: `${primary}44`, backgroundColor: `${primary}14` }]}>
                      <Text style={[styles.stepNumText, { color: primary }]}>{i + 1}</Text>
                    </View>
                    <Text style={styles.stepBody}>{line}</Text>
                  </View>
                ))}
              </>
            ) : (
              <>
                {[
                  'Open Stripe’s secure form and add business, identity, and bank details.',
                  'When Stripe sends you back to the app, return to this page.',
                  'Tap Refresh status to confirm the account has finished verification.',
                ].map((line, i) => (
                  <View key={i} style={styles.stepRow}>
                    <View style={[styles.stepNum, { borderColor: `${primary}44`, backgroundColor: `${primary}14` }]}>
                      <Text style={[styles.stepNumText, { color: primary }]}>{i + 1}</Text>
                    </View>
                    <Text style={styles.stepBody}>{line}</Text>
                  </View>
                ))}
              </>
            )}
          </GlassCard>

          <View style={styles.actionStack}>
            <TouchableOpacity
              style={[styles.primaryBtn, { backgroundColor: primary }]}
              onPress={canContinueToApp ? handleContinueToApp : startConnect}
              disabled={saving}
              activeOpacity={0.9}
            >
              {saving ? (
                <ActivityIndicator color="#0A1929" />
              ) : (
                <Text style={styles.primaryBtnText}>{canContinueToApp ? 'Continue to app' : 'Continue with Stripe'}</Text>
              )}
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.secondaryBtn, { borderColor: `${primary}40` }]}
              onPress={() => handleCheckStatus(false)}
              disabled={saving}
              activeOpacity={0.9}
            >
              <Ionicons name="refresh-outline" size={18} color={LIGHT_TEXT} style={{ marginRight: 8 }} />
              <Text style={styles.secondaryBtnText}>Refresh status</Text>
            </TouchableOpacity>

            {canContinueToApp && (
              <TouchableOpacity style={styles.tertiaryBtn} onPress={startConnect} disabled={saving} activeOpacity={0.85}>
                <Text style={styles.tertiaryBtnText}>{isComplete ? 'Update Stripe details' : 'Finish setup in Stripe'}</Text>
              </TouchableOpacity>
            )}

            <Text style={styles.footerHint}>
              {isComplete
                ? 'Connected. Refresh status after any Stripe changes.'
                : 'After onboarding in the browser, return here and refresh status.'}
            </Text>
          </View>
        </Animated.ScrollView>

        <Modal visible={dialogVisible} transparent animationType="fade" onRequestClose={() => setDialogVisible(false)}>
          <Pressable style={styles.modalOverlay} onPress={() => setDialogVisible(false)}>
            <View style={styles.modalCard}>
              <View
                style={[
                  styles.modalIconWrap,
                  dialogType === 'error'
                    ? styles.modalIconError
                    : dialogType === 'warning'
                      ? styles.modalIconWarning
                      : styles.modalIconInfo,
                ]}
              >
                <Ionicons
                  name={dialogType === 'error' ? 'close-circle-outline' : dialogType === 'warning' ? 'alert-circle-outline' : 'information-circle-outline'}
                  size={24}
                  color="#FFFFFF"
                />
              </View>
              <Text style={styles.modalTitle}>{dialogTitle}</Text>
              <Text style={styles.modalMessage}>{dialogMessage}</Text>

              <View style={styles.modalActions}>
                {dialogActions.map((action, index) => (
                  <TouchableOpacity
                    key={`${action.label}-${index}`}
                    style={[
                      styles.modalButton,
                      action.kind === 'secondary' && styles.modalButtonSecondary,
                      action.kind === 'danger' && styles.modalButtonDanger,
                      (!action.kind || action.kind === 'primary') && [styles.modalButtonPrimary, { backgroundColor: primary }],
                    ]}
                    onPress={() => {
                      setDialogVisible(false);
                      action.onPress?.();
                    }}
                    activeOpacity={0.85}
                  >
                    <Text
                      style={[
                        styles.modalButtonText,
                        action.kind === 'secondary' && styles.modalButtonTextSecondary,
                        action.kind === 'danger' && styles.modalButtonTextDanger,
                        (!action.kind || action.kind === 'primary') && styles.modalButtonTextPrimary,
                      ]}
                    >
                      {action.label}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          </Pressable>
        </Modal>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  scroll: { flex: 1 },
  scrollInner: {
    paddingHorizontal: 20,
  },
  topActionRow: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    marginBottom: 8,
  },
  topActionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    borderWidth: 1,
    borderRadius: 999,
    paddingHorizontal: 14,
    paddingVertical: 10,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  topActionText: {
    color: LIGHT_TEXT,
    fontSize: 13,
    fontWeight: '800',
  },
  centerHero: {
    alignItems: 'center',
    gap: 12,
    paddingVertical: 8,
  },
  stripeLogoWrap: {
    width: 200,
    height: 132,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stripeLogoGlow: {
    position: 'absolute',
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(99,102,241,0.12)',
    shadowColor: '#60A5FA',
    shadowOpacity: 0.18,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 10 },
  },
  stripeLogoImage: {
    width: 190,
    height: 96,
  },
  loadingWrap: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 14,
    paddingHorizontal: 32,
  },
  loadingText: {
    fontSize: 15,
    textAlign: 'center',
  },
  heroCard: {
    padding: 22,
    marginBottom: 14,
    borderRadius: 28,
  },
  heroTop: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  heroBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  heroBadgeText: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.6,
    textTransform: 'uppercase',
  },
  heroTitle: {
    color: LIGHT_TEXT,
    fontSize: 24,
    fontWeight: '800',
    lineHeight: 30,
    marginBottom: 8,
  },
  heroSubtitle: {
    color: MUTED,
    fontSize: 15,
    lineHeight: 22,
  },
  heroChipRow: { flexDirection: 'row', gap: 8, flexWrap: 'wrap' },
  heroChip: {
    flexGrow: 1,
    minWidth: '31%',
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingVertical: 10,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
    gap: 4,
  },
  heroChipLabel: {
    color: 'rgba(249,250,251,0.62)',
    fontSize: 10,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  heroChipValue: { color: LIGHT_TEXT, fontSize: 13, fontWeight: '800' },
  heroStatusText: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: '800',
  },
  heroStatusBody: {
    color: 'rgba(255,255,255,0.68)',
    fontSize: 13,
    lineHeight: 19,
    marginTop: 10,
  },
  sectionCard: {
    padding: 20,
    marginBottom: 14,
    borderRadius: 26,
  },
  sectionHeading: {
    color: LIGHT_TEXT,
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 14,
  },
  statusBlock: {
    gap: 8,
    paddingVertical: 2,
  },
  statusRowCompact: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },
  metaLabel: {
    color: 'rgba(249,250,251,0.55)',
    fontSize: 12,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.6,
  },
  statusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  statusPillText: {
    fontSize: 13,
    fontWeight: '800',
  },
  accountBlock: {
    gap: 4,
    paddingTop: 8,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(255,255,255,0.08)',
  },
  accountLabel: {
    color: MUTED,
    fontSize: 11,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  accountValue: {
    color: LIGHT_TEXT,
    fontSize: 14,
    fontWeight: '800',
  },
  connectionSummaryGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginTop: 14,
  },
  connectionSummaryItem: {
    flexBasis: '48%',
    minWidth: '48%',
    padding: 12,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  connectionSummaryLabel: {
    color: 'rgba(249,250,251,0.68)',
    fontSize: 11,
    fontWeight: '700',
    marginBottom: 6,
    textTransform: 'uppercase',
    letterSpacing: 0.4,
  },
  connectionSummaryValue: {
    color: LIGHT_TEXT,
    fontSize: 14,
    fontWeight: '800',
  },
  stepRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 12,
  },
  stepNum: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    marginTop: 1,
  },
  stepNumText: {
    fontSize: 13,
    fontWeight: '800',
  },
  stepBody: {
    flex: 1,
    color: 'rgba(255,255,255,0.92)',
    fontSize: 14,
    lineHeight: 21,
  },
  actionStack: {
    gap: 10,
    marginTop: 4,
  },
  primaryBtn: {
    borderRadius: 16,
    minHeight: 54,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
  },
  primaryBtnText: {
    color: '#0A1929',
    fontSize: 15,
    fontWeight: '800',
  },
  secondaryBtn: {
    borderRadius: 14,
    minHeight: 50,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    borderWidth: 1,
    backgroundColor: 'rgba(255,255,255,0.06)',
    marginBottom: 8,
  },
  secondaryBtnText: {
    color: LIGHT_TEXT,
    fontWeight: '700',
    fontSize: 15,
  },
  tertiaryBtn: {
    borderRadius: 14,
    minHeight: 46,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 4,
  },
  tertiaryBtnText: {
    color: 'rgba(249,250,251,0.65)',
    fontWeight: '600',
    fontSize: 14,
  },
  footerHint: {
    color: 'rgba(249,250,251,0.45)',
    fontSize: 12,
    marginTop: 2,
    lineHeight: 17,
    textAlign: 'center',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(3,10,18,0.75)',
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  modalCard: {
    borderRadius: 22,
    padding: 22,
    backgroundColor: '#0D1D2E',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  modalIconWrap: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 14,
  },
  modalIconError: {
    backgroundColor: 'rgba(239,68,68,0.75)',
  },
  modalIconWarning: {
    backgroundColor: 'rgba(245,158,11,0.75)',
  },
  modalIconInfo: {
    backgroundColor: 'rgba(59,130,246,0.75)',
  },
  modalTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 8,
  },
  modalMessage: {
    color: '#C7DCEA',
    fontSize: 15,
    lineHeight: 22,
  },
  modalActions: {
    marginTop: 20,
    gap: 10,
  },
  modalButton: {
    minHeight: 50,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 16,
  },
  modalButtonPrimary: {},
  modalButtonSecondary: {
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  modalButtonDanger: {
    backgroundColor: 'rgba(239,68,68,0.16)',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.28)',
  },
  modalButtonText: {
    fontSize: 14,
    fontWeight: '800',
  },
  modalButtonTextPrimary: {
    color: '#0A1929',
  },
  modalButtonTextSecondary: {
    color: '#FFFFFF',
  },
  modalButtonTextDanger: {
    color: '#FFFFFF',
  },
});
