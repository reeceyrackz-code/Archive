import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert,
  ActivityIndicator,
  Image,
  Platform,
  Modal,
  RefreshControl,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import MapView, { Marker, PROVIDER_DEFAULT } from 'react-native-maps';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import BusinessSheetBackground from '../../../src/components/shared/BusinessSheetBackground';
import StatusBadge from '../../../src/components/booking/StatusBadge';
import { colors } from '../../../src/constants/colors';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import {
  loadActiveBookingsForOrganization,
  loadHistoryBookingsForOrganization,
  type BusinessActiveBooking,
  type BusinessHistoryBooking,
} from '../../../src/services/BusinessBookingsService';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import { SCREEN_PADDING_H, SECTION_GAP, CARD_GAP } from '../../../src/constants/premiumTokens';
import DefaultLoadingSkeleton from '../../../src/components/shared/DefaultLoadingSkeleton';
import EmptyState from '../../../src/components/shared/EmptyState';
import { canOpenLiveTracking } from '../../../src/utils/businessBookingAccess';

const SKY = colors.SKY;
const CARD_MAP_HEIGHT = 108;

type UpcomingBooking = BusinessActiveBooking;
type PastBooking = BusinessHistoryBooking;
type BookingRow = UpcomingBooking | PastBooking;

function getStatusTone(status: string): 'green' | 'sky' | 'amber' | 'gray' | 'red' {
  const s = String(status).toLowerCase();
  if (s === 'completed') return 'green';
  if (s === 'cancelled') return 'red';
  if (s === 'in_progress' || s === 'arrived' || s === 'en_route') return 'sky';
  if (s === 'pending' || s === 'confirmed' || s === 'scheduled') return 'amber';
  return 'gray';
}

export default function ActivityPage() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme: businessTheme } = useAccountTheme();
  const [upcomingBookings, setUpcomingBookings] = useState<UpcomingBooking[]>([]);
  const [pastBookings, setPastBookings] = useState<PastBooking[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [activeFilter, setActiveFilter] = useState<'upcoming' | 'completed'>('upcoming');
  const [showAllUpcoming, setShowAllUpcoming] = useState(false);
  const [showAllPast, setShowAllPast] = useState(false);
  const [failedAvatarIds, setFailedAvatarIds] = useState<Record<string, boolean>>({});
  const [selectedBooking, setSelectedBooking] = useState<BookingRow | null>(null);

  const organizationId = user?.organizationId ?? null;
  const isOrgUser = ['organization', 'business'].includes((user?.userType ?? '').toLowerCase());

  const loadActivity = useCallback(async (isRefresh = false) => {
    if (!organizationId) {
      setLoading(false);
      setRefreshing(false);
      return;
    }
    try {
      if (!isRefresh) setLoading(true);
      else setRefreshing(true);

      const LOAD_TIMEOUT_MS = 15000;
      const [upcoming, past] = await Promise.race([
        Promise.all([
          loadActiveBookingsForOrganization(organizationId),
          loadHistoryBookingsForOrganization(organizationId),
        ]),
        new Promise<[UpcomingBooking[], PastBooking[]]>((_, reject) =>
          setTimeout(() => reject(new Error('Load timed out')), LOAD_TIMEOUT_MS)
        ),
      ]);

      setUpcomingBookings(upcoming);
      setPastBookings(past);
    } catch (e: any) {
      console.error('[Activity] load error', e);
      setUpcomingBookings([]);
      setPastBookings([]);
      if (!isRefresh) {
        Alert.alert(
          'Couldn’t load bookings',
          e?.message === 'Load timed out' ? 'Request took too long. Pull down to try again.' : 'Pull down to try again.'
        );
      }
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [organizationId]);

  useEffect(() => {
    if (isOrgUser && organizationId) {
      loadActivity(false);
    } else {
      setLoading(false);
    }
  }, [organizationId, isOrgUser, loadActivity]);

  const formatDate = (booking: BookingRow) => {
    const at = booking.scheduled_at;
    return at
      ? new Date(at).toLocaleString('en-GB', {
          weekday: 'short',
          day: 'numeric',
          month: 'short',
          hour: '2-digit',
          minute: '2-digit',
        })
      : new Date(booking.created_at).toLocaleDateString('en-GB', {
          weekday: 'short',
          day: 'numeric',
          month: 'short',
        });
  };

  const hasCoords = (b: BookingRow) =>
    b.location_lat != null &&
    b.location_lng != null &&
    Number.isFinite(b.location_lat) &&
    Number.isFinite(b.location_lng);

  const renderCard = (booking: BookingRow, variant: 'upcoming' | 'past') => {
    const coords = hasCoords(booking);
    const region = coords
      ? {
          latitude: booking.location_lat!,
          longitude: booking.location_lng!,
          latitudeDelta: 0.003,
          longitudeDelta: 0.003,
        }
      : {
          latitude: 51.5074,
          longitude: -0.1278,
          latitudeDelta: 0.05,
          longitudeDelta: 0.05,
        };
    const isCompleted = booking.status === 'completed';
    const photoUri = booking.customer_profile_picture;
    const showAvatarImage = !!photoUri && !failedAvatarIds[booking.id];
    const customerName = booking.customer_name?.trim() || 'Customer';
    const customerInitial = customerName.charAt(0).toUpperCase() || '?';
    const valeterInitial = (booking.assigned_valeter_name || '?').trim().charAt(0).toUpperCase() || '?';
    const statusTone = getStatusTone(booking.status);
    const priceLabel = variant === 'upcoming' ? 'Booked' : 'Earned';
    const avatarColors =
      statusTone === 'green'
        ? ['rgba(16,185,129,0.34)', 'rgba(16,185,129,0.12)']
        : statusTone === 'red'
          ? ['rgba(248,113,113,0.34)', 'rgba(248,113,113,0.12)']
          : statusTone === 'amber'
            ? ['rgba(245,158,11,0.34)', 'rgba(245,158,11,0.12)']
            : ['rgba(135,206,235,0.34)', 'rgba(135,206,235,0.12)'];
    const accentStyle =
      statusTone === 'green'
        ? styles.cardAccentCompleted
        : statusTone === 'red'
          ? styles.cardAccentCancelled
          : styles.cardAccentPending;

    return (
      <TouchableOpacity
        key={booking.id}
        activeOpacity={0.88}
        onPress={async () => {
          await hapticFeedback('light');
          setSelectedBooking(booking);
        }}
        style={styles.card}
        >
        <View style={styles.cardInner}>
          <View style={[styles.cardAccent, accentStyle]} />
          <View style={styles.cardHeader}>
            <View style={styles.cardHeaderLeft}>
              <View style={styles.avatarWrap}>
                {showAvatarImage && photoUri ? (
                  <Image
                    source={{ uri: photoUri }}
                    style={styles.avatarImage}
                    resizeMode="cover"
                    onError={() =>
                      setFailedAvatarIds((prev) => (prev[booking.id] ? prev : { ...prev, [booking.id]: true }))
                    }
                  />
                ) : (
                  <LinearGradient
                    colors={avatarColors as [string, string]}
                    style={styles.avatarGrad}
                  >
                    <Text style={styles.avatarLetter}>{customerInitial}</Text>
                  </LinearGradient>
                )}
              </View>
              <View style={styles.cardHeaderText}>
                <Text style={styles.customerName} numberOfLines={1}>
                  {customerName}
                </Text>
                <Text style={styles.serviceName} numberOfLines={1}>
                  {getServiceDisplayName(booking.service_type, booking.service_name)}
                </Text>
                <View style={styles.statusRow}>
                  <StatusBadge status={booking.status as any} size="small" />
                </View>
              </View>
            </View>

            <View style={styles.priceStack}>
              <Text style={styles.pricePillText}>£{Number(booking.price || 0).toFixed(2)}</Text>
              <Text style={[styles.priceLabel, statusTone === 'red' && styles.priceLabelAlert]}>{priceLabel}</Text>
            </View>
          </View>

          <View style={styles.infoBlock}>
            <View style={styles.infoRow}>
              <Ionicons name="calendar-outline" size={16} color="rgba(249,250,251,0.7)" />
              <Text style={styles.infoText}>{formatDate(booking)}</Text>
            </View>
            {booking.location_address ? (
              <View style={styles.infoRow}>
                <Ionicons name="location-outline" size={16} color="rgba(249,250,251,0.7)" />
                <Text style={styles.infoText} numberOfLines={1}>
                  {booking.location_address.split(',')[0]}
                </Text>
              </View>
            ) : (
              <View style={styles.infoRow}>
                <Ionicons name="location-outline" size={16} color="rgba(148,163,184,0.5)" />
                <Text style={styles.infoTextMuted}>Location not recorded</Text>
              </View>
            )}
          </View>

          <View style={styles.mapWrap}>
            {coords ? (
              <MapView
                style={styles.map}
                region={region}
                scrollEnabled={false}
                zoomEnabled={false}
                pitchEnabled={false}
                rotateEnabled={false}
                provider={Platform.OS === 'ios' ? PROVIDER_DEFAULT : undefined}
                mapType="standard"
              >
                <Marker
                  coordinate={{
                    latitude: booking.location_lat!,
                    longitude: booking.location_lng!,
                  }}
                  anchor={{ x: 0.5, y: 0.5 }}
                >
                  <View style={styles.mapPin}>
                    <Ionicons name="location" size={16} color={SKY} />
                  </View>
                </Marker>
              </MapView>
            ) : (
              <View style={styles.mapPlaceholder}>
                <Ionicons name="map-outline" size={32} color="rgba(148,163,184,0.4)" />
                <Text style={styles.mapPlaceholderText}>No map data</Text>
              </View>
            )}
            <View style={styles.mapChevronBubble}>
              <Ionicons name="chevron-forward" size={20} color="#F9FAFB" />
            </View>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  const upcoming = [...upcomingBookings].sort((a, b) => {
    const aTime = new Date(a.scheduled_at ?? a.created_at).getTime();
    const bTime = new Date(b.scheduled_at ?? b.created_at).getTime();
    return aTime - bTime;
  });

  const past = [...pastBookings].sort((a, b) => {
    const aTime = new Date(a.created_at).getTime();
    const bTime = new Date(b.created_at).getTime();
    return bTime - aTime;
  });

  const upcomingVisible = showAllUpcoming ? upcoming : upcoming.slice(0, 4);
  const pastVisible = showAllPast ? past : past.slice(0, 5);
  const hasUpcomingMore = upcoming.length > upcomingVisible.length;
  const hasPastMore = past.length > pastVisible.length;
  const hasAnyBookings = upcoming.length > 0 || past.length > 0;
  const activeCount = activeFilter === 'upcoming' ? upcoming.length : past.length;
  const activeBookings = activeFilter === 'upcoming' ? upcoming : past;
  const activeVisible = activeFilter === 'upcoming' ? upcomingVisible : pastVisible;
  const activeHasMore = activeFilter === 'upcoming' ? hasUpcomingMore : hasPastMore;
  const activeShowAll = activeFilter === 'upcoming' ? showAllUpcoming : showAllPast;
  const selectedName = selectedBooking?.customer_name?.trim() || 'Customer';
  const selectedService = selectedBooking
    ? getServiceDisplayName(selectedBooking.service_type, selectedBooking.service_name)
    : '';
  const selectedStatusTone = selectedBooking ? getStatusTone(selectedBooking.status) : 'gray';
  const selectedStatusLabel =
    selectedBooking?.status
      ? selectedBooking.status.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())
      : '';
  const selectedCanTrack = selectedBooking
    ? canOpenLiveTracking(selectedBooking.scheduled_at, selectedBooking.status)
    : false;
  const selectedCustomerId =
    selectedBooking && 'customer_id' in selectedBooking ? selectedBooking.customer_id : null;

  return (
    <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />

      <View
        style={[
          styles.contentWrap,
          {
            paddingTop: insets.top + 2,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + SECTION_GAP,
          },
        ]}
      >
        {loading ? (
          <View style={styles.loadingArea}>
            <DefaultLoadingSkeleton message="Loading bookings…" variant="rich" />
          </View>
        ) : !hasAnyBookings ? (
          <ScrollView
            contentContainerStyle={styles.centeredScroll}
            refreshControl={
              <RefreshControl refreshing={refreshing} onRefresh={() => loadActivity(true)} tintColor={SKY} />
            }
          >
            <View style={styles.filterBar}>
              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  setActiveFilter('upcoming');
                }}
                style={[
                  styles.filterChip,
                  activeFilter === 'upcoming' && styles.filterChipActive,
                ]}
                activeOpacity={0.85}
              >
                <Text style={[styles.filterChipText, activeFilter === 'upcoming' && styles.filterChipTextActive]}>
                  Upcoming
                </Text>
                <View style={[styles.filterChipCount, activeFilter === 'upcoming' && styles.filterChipCountActive]}>
                  <Text style={[styles.filterChipCountText, activeFilter === 'upcoming' && styles.filterChipCountTextActive]}>
                    {upcoming.length}
                  </Text>
                </View>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  setActiveFilter('completed');
                }}
                style={[
                  styles.filterChip,
                  activeFilter === 'completed' && styles.filterChipActive,
                ]}
                activeOpacity={0.85}
              >
                <Text style={[styles.filterChipText, activeFilter === 'completed' && styles.filterChipTextActive]}>
                  Completed
                </Text>
                <View style={[styles.filterChipCount, activeFilter === 'completed' && styles.filterChipCountActive]}>
                  <Text style={[styles.filterChipCountText, activeFilter === 'completed' && styles.filterChipCountTextActive]}>
                    {past.length}
                  </Text>
                </View>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  loadActivity(true);
                }}
                style={styles.headerBtnCircle}
              >
                <Ionicons name="refresh-outline" size={20} color={SKY} />
              </TouchableOpacity>
            </View>
            <EmptyState
              icon="calendar-outline"
              title="No bookings yet"
              subtitle="Upcoming and past washes will appear here"
              iconColor={SKY}
            />
          </ScrollView>
        ) : (
          <ScrollView
            contentContainerStyle={styles.listContent}
            showsVerticalScrollIndicator={false}
            refreshControl={
              <RefreshControl refreshing={refreshing} onRefresh={() => loadActivity(true)} tintColor={SKY} />
            }
          >
            <View style={styles.filterBar}>
              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  setActiveFilter('upcoming');
                }}
                style={[
                  styles.filterChip,
                  activeFilter === 'upcoming' && styles.filterChipActive,
                ]}
                activeOpacity={0.85}
              >
                <Text style={[styles.filterChipText, activeFilter === 'upcoming' && styles.filterChipTextActive]}>
                  Upcoming
                </Text>
                <View style={[styles.filterChipCount, activeFilter === 'upcoming' && styles.filterChipCountActive]}>
                  <Text style={[styles.filterChipCountText, activeFilter === 'upcoming' && styles.filterChipCountTextActive]}>
                    {upcoming.length}
                  </Text>
                </View>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  setActiveFilter('completed');
                }}
                style={[
                  styles.filterChip,
                  activeFilter === 'completed' && styles.filterChipActive,
                ]}
                activeOpacity={0.85}
              >
                <Text style={[styles.filterChipText, activeFilter === 'completed' && styles.filterChipTextActive]}>
                  Completed
                </Text>
                <View style={[styles.filterChipCount, activeFilter === 'completed' && styles.filterChipCountActive]}>
                  <Text style={[styles.filterChipCountText, activeFilter === 'completed' && styles.filterChipCountTextActive]}>
                    {past.length}
                  </Text>
                </View>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  loadActivity(true);
                }}
                style={styles.headerBtnCircle}
              >
                <Ionicons name="refresh-outline" size={20} color={SKY} />
              </TouchableOpacity>
            </View>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>{activeFilter === 'upcoming' ? 'Upcoming' : 'Completed'}</Text>
              <Text style={styles.sectionCount}>{activeCount}</Text>
            </View>
            {activeBookings.length === 0 ? (
              <EmptyState
                icon={activeFilter === 'upcoming' ? 'time-outline' : 'checkmark-circle-outline'}
                title={activeFilter === 'upcoming' ? 'No upcoming jobs' : 'No completed jobs'}
                subtitle={activeFilter === 'upcoming' ? 'Scheduled and active bookings will show here' : 'Completed jobs will appear here'}
                iconColor={SKY}
              />
            ) : (
              <>
                {activeVisible.map((b) =>
                  activeFilter === 'upcoming' ? renderCard(b, 'upcoming') : renderCard(b, 'past')
                )}
                {activeHasMore && (
                  <TouchableOpacity
                    onPress={async () => {
                      await hapticFeedback('light');
                      activeFilter === 'upcoming' ? setShowAllUpcoming(true) : setShowAllPast(true);
                    }}
                    style={styles.viewAllWrap}
                    activeOpacity={0.8}
                  >
                    <Text style={styles.viewAllText}>
                      View all {activeFilter === 'upcoming' ? 'upcoming' : 'completed'}
                    </Text>
                    <Ionicons name="list" size={20} color={SKY} />
                  </TouchableOpacity>
                )}
                {activeShowAll && activeHasMore && (
                  <TouchableOpacity
                    onPress={async () => {
                      await hapticFeedback('light');
                      activeFilter === 'upcoming' ? setShowAllUpcoming(false) : setShowAllPast(false);
                    }}
                    style={styles.viewAllWrap}
                    activeOpacity={0.8}
                  >
                    <Text style={styles.viewAllText}>Show less</Text>
                    <Ionicons name="chevron-up" size={20} color={SKY} />
                  </TouchableOpacity>
                )}
              </>
            )}
          </ScrollView>
        )}
      </View>

      <Modal
        visible={!!selectedBooking}
        transparent
        animationType="slide"
        statusBarTranslucent
        onRequestClose={() => setSelectedBooking(null)}
      >
        <View style={styles.detailModalRoot}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setSelectedBooking(null)}>
            <View style={styles.detailBackdrop} />
          </Pressable>
          <Pressable
            style={[styles.detailSheet, { paddingBottom: Math.max(24, insets.bottom + 12) }]}
            onPress={(e) => e.stopPropagation()}
          >
            <BusinessSheetBackground />
            <View style={styles.detailHandle} />
            {selectedBooking ? (
              <>
                <View style={styles.detailHeaderRow}>
                  <View style={styles.detailHeaderCopy}>
                    <Text style={styles.detailTitle}>{selectedName}</Text>
                    <Text style={styles.detailSubtitle}>{selectedService}</Text>
                  </View>
                  <TouchableOpacity onPress={() => setSelectedBooking(null)} style={styles.detailCloseBtn} hitSlop={12}>
                    <Ionicons name="close" size={24} color="rgba(249,250,251,0.9)" />
                  </TouchableOpacity>
                </View>

                <View style={styles.detailHeroRow}>
                  <View style={styles.detailAvatarWrap}>
                    {selectedBooking.customer_profile_picture ? (
                      <Image source={{ uri: selectedBooking.customer_profile_picture }} style={styles.detailAvatar} resizeMode="cover" />
                    ) : (
                      <LinearGradient
                        colors={selectedStatusTone === 'red'
                          ? ['rgba(248,113,113,0.36)', 'rgba(248,113,113,0.15)']
                          : selectedStatusTone === 'green'
                            ? ['rgba(16,185,129,0.32)', 'rgba(16,185,129,0.14)']
                            : ['rgba(246,211,101,0.32)', 'rgba(246,211,101,0.14)']}
                        style={styles.detailAvatarFallback}
                      >
                        <Text style={styles.detailAvatarLetter}>{selectedName.charAt(0).toUpperCase()}</Text>
                      </LinearGradient>
                    )}
                  </View>
                  <View style={styles.detailHeroStats}>
                    <View style={[styles.detailPricePill, selectedStatusTone === 'red' && styles.detailPricePillRed, selectedStatusTone === 'green' && styles.detailPricePillGreen]}>
                      <Text style={styles.detailPriceValue}>£{Number(selectedBooking.price || 0).toFixed(2)}</Text>
                      <Text style={styles.detailPriceLabel}>Earned</Text>
                    </View>
                    <View style={styles.detailStatusWrap}>
                      <StatusBadge status={selectedBooking.status as any} size="medium" />
                    </View>
                  </View>
                </View>

                <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.detailScrollContent}>
                  <View style={styles.detailInfoCard}>
                    <View style={styles.detailRow}>
                      <Ionicons name="calendar-outline" size={18} color={SKY} />
                      <Text style={styles.detailRowText}>
                        {selectedBooking.scheduled_at
                          ? new Date(selectedBooking.scheduled_at).toLocaleString('en-GB', {
                              weekday: 'short',
                              day: 'numeric',
                              month: 'short',
                              hour: '2-digit',
                              minute: '2-digit',
                            })
                          : new Date(selectedBooking.created_at).toLocaleDateString('en-GB', {
                              weekday: 'short',
                              day: 'numeric',
                              month: 'short',
                            })}
                      </Text>
                    </View>
                    {selectedBooking.location_address ? (
                      <View style={styles.detailRow}>
                        <Ionicons name="location-outline" size={18} color={SKY} />
                        <Text style={styles.detailRowText}>{selectedBooking.location_address}</Text>
                      </View>
                    ) : null}
                    {selectedBooking.assigned_valeter_name ? (
                      <View style={styles.detailRow}>
                        {selectedBooking.assigned_valeter_photo ? (
                          <Image
                            source={{ uri: selectedBooking.assigned_valeter_photo }}
                            style={styles.detailValeterAvatar}
                            resizeMode="cover"
                          />
                        ) : (
                          <View style={styles.detailValeterAvatarFallback}>
                            <Text style={styles.detailValeterAvatarLetter}>
                              {(selectedBooking.assigned_valeter_name || '?').trim().charAt(0).toUpperCase()}
                            </Text>
                          </View>
                        )}
                        <Text style={styles.detailRowText}>Car Care Pro: {selectedBooking.assigned_valeter_name}</Text>
                      </View>
                    ) : null}
                    {selectedStatusLabel ? (
                      <View style={styles.detailRow}>
                        <Ionicons name="radio-button-on-outline" size={18} color={SKY} />
                        <Text style={styles.detailRowText}>{selectedStatusLabel}</Text>
                      </View>
                    ) : null}
                    {selectedCustomerId ? (
                      <View style={styles.detailRow}>
                        <Ionicons name="chatbubble-outline" size={18} color={SKY} />
                        <Text style={styles.detailRowText}>Customer chat available from this booking</Text>
                      </View>
                    ) : null}
                  </View>

                  <View style={styles.detailMapWrap}>
                    {selectedBooking.location_lat != null && selectedBooking.location_lng != null ? (
                      <MapView
                        style={StyleSheet.absoluteFill}
                        region={{
                          latitude: selectedBooking.location_lat,
                          longitude: selectedBooking.location_lng,
                          latitudeDelta: 0.008,
                          longitudeDelta: 0.008,
                        }}
                        provider={Platform.OS === 'ios' ? PROVIDER_DEFAULT : undefined}
                      >
                        <Marker coordinate={{ latitude: selectedBooking.location_lat, longitude: selectedBooking.location_lng }}>
                          <View style={styles.detailMapPin}>
                            <Ionicons name="location" size={18} color={SKY} />
                          </View>
                        </Marker>
                      </MapView>
                    ) : (
                      <View style={styles.detailMapPlaceholder}>
                        <Ionicons name="map-outline" size={30} color="rgba(148,163,184,0.42)" />
                        <Text style={styles.detailMapPlaceholderText}>No map data</Text>
                      </View>
                    )}
                  </View>
                </ScrollView>

                <View style={styles.detailActions}>
                  <TouchableOpacity style={styles.detailActionGhost} onPress={() => setSelectedBooking(null)}>
                    <Text style={styles.detailActionGhostText}>Close</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[styles.detailActionPrimary, !selectedCanTrack && styles.detailActionPrimaryDisabled]}
                    onPress={async () => {
                      if (!selectedCanTrack) return;
                      await hapticFeedback('light');
                      setSelectedBooking(null);
                      router.push({
                        pathname: '/business/bookings/tracking',
                        params: { bookingId: selectedBooking.id },
                      } as any);
                    }}
                    disabled={!selectedCanTrack}
                  >
                    <Text style={styles.detailActionPrimaryText}>
                      {selectedCanTrack ? 'Track booking' : 'Tracking locked'}
                    </Text>
                  </TouchableOpacity>
                </View>
              </>
            ) : null}
          </Pressable>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  contentWrap: { flex: 1 },
  loadingArea: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: SCREEN_PADDING_H,
  },
  centeredScroll: {
    flexGrow: 1,
    justifyContent: 'center',
    paddingHorizontal: SCREEN_PADDING_H,
    gap: SECTION_GAP,
  },
  listContent: {
    paddingHorizontal: SCREEN_PADDING_H,
    paddingTop: 4,
    paddingBottom: SECTION_GAP,
    gap: CARD_GAP,
  },
  flatHeaderRow: {
    display: 'none',
  },
  filterBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
    gap: 8,
  },
  headerBtnCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.18)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.35)',
  },
  filterChip: {
    flex: 1,
    minWidth: 0,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.15)',
  },
  filterChipActive: {
    backgroundColor: 'rgba(135,206,235,0.16)',
    borderColor: 'rgba(135,206,235,0.32)',
  },
  filterChipText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    fontWeight: '800',
  },
  filterChipTextActive: {
    color: '#F9FAFB',
  },
  filterChipCount: {
    minWidth: 24,
    height: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
    paddingHorizontal: 7,
  },
  filterChipCountActive: {
    backgroundColor: 'rgba(255,255,255,0.16)',
  },
  filterChipCountText: {
    color: 'rgba(249,250,251,0.65)',
    fontSize: 12,
    fontWeight: '800',
  },
  filterChipCountTextActive: {
    color: '#F9FAFB',
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 8,
    marginBottom: 2,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: -0.25,
  },
  sectionCount: {
    color: 'rgba(248,250,252,0.7)',
    fontSize: 13,
    fontWeight: '700',
  },
  card: {
    borderRadius: 22,
    overflow: 'hidden',
    backgroundColor: 'rgba(10,18,30,0.78)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.18)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.14,
    shadowRadius: 18,
    elevation: 5,
  },
  cardInner: {
    padding: 16,
    gap: 12,
    position: 'relative',
  },
  cardAccent: {
    position: 'absolute',
    right: 0,
    top: 0,
    bottom: 0,
    width: 4,
    borderTopLeftRadius: 0,
    borderBottomLeftRadius: 0,
    borderTopRightRadius: 22,
    borderBottomRightRadius: 22,
  },
  cardAccentPending: {
    backgroundColor: 'rgba(245,158,11,0.95)',
  },
  cardAccentCompleted: {
    backgroundColor: 'rgba(16,185,129,0.95)',
  },
  cardAccentCancelled: {
    backgroundColor: 'rgba(248,113,113,0.95)',
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    gap: 12,
  },
  cardHeaderLeft: {
    flex: 1,
    minWidth: 0,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  avatarWrap: {
    width: 60,
    height: 60,
    borderRadius: 18,
    overflow: 'hidden',
  },
  avatarGrad: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarImage: {
    width: '100%',
    height: '100%',
  },
  avatarLetter: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: '800',
  },
  cardHeaderText: {
    flex: 1,
    minWidth: 0,
    gap: 6,
  },
  customerName: {
    fontSize: 19,
    fontWeight: '800',
    color: '#F9FAFB',
    lineHeight: 21,
  },
  serviceName: {
    color: 'rgba(226,232,240,0.78)',
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 18,
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flexWrap: 'wrap',
  },
  variantPill: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 999,
    borderWidth: 1,
  },
  variantPillUpcoming: {
    backgroundColor: 'rgba(96,165,250,0.12)',
    borderColor: 'rgba(96,165,250,0.3)',
  },
  variantPillPast: {
    backgroundColor: 'rgba(16,185,129,0.12)',
    borderColor: 'rgba(16,185,129,0.28)',
  },
  variantPillText: {
    color: '#F9FAFB',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.35,
  },
  pricePill: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 16,
    backgroundColor: 'rgba(135,206,235,0.14)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.28)',
  },
  priceStack: {
    alignItems: 'flex-end',
    minWidth: 96,
    gap: 1,
  },
  pricePillText: {
    color: '#F9FAFB',
    fontSize: 19,
    fontWeight: '900',
    letterSpacing: -0.2,
  },
  priceLabel: {
    color: 'rgba(248,250,252,0.68)',
    fontSize: 12,
    fontWeight: '600',
  },
  priceLabelAlert: {
    color: 'rgba(248,250,252,0.72)',
  },
  infoBlock: {
    gap: 8,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
  },
  infoText: {
    fontSize: 14,
    color: 'rgba(249,250,251,0.9)',
    fontWeight: '500',
    flex: 1,
  },
  infoTextMuted: {
    fontSize: 14,
    color: 'rgba(148,163,184,0.7)',
    fontWeight: '500',
    fontStyle: 'italic',
  },
  valeterAvatar: {
    width: 18,
    height: 18,
    borderRadius: 9,
  },
  valeterAvatarFallback: {
    width: 18,
    height: 18,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(135,206,235,0.24)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.38)',
  },
  valeterAvatarLetter: {
    color: '#F9FAFB',
    fontSize: 9,
    fontWeight: '800',
  },
  mapWrap: {
    height: CARD_MAP_HEIGHT,
    width: '100%',
    borderRadius: 18,
    overflow: 'hidden',
    backgroundColor: 'rgba(15,23,42,0.72)',
    marginTop: 2,
  },
  map: {
    width: '100%',
    height: '100%',
    borderRadius: 18,
  },
  mapPin: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(15,23,42,0.92)',
    borderWidth: 2,
    borderColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
  },
  mapPlaceholder: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
  },
  mapPlaceholderText: {
    fontSize: 12,
    color: 'rgba(148,163,184,0.6)',
    fontWeight: '500',
  },
  mapChevronBubble: {
    position: 'absolute',
    right: 14,
    bottom: 14,
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(17,24,39,0.62)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  viewAllWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    paddingHorizontal: 20,
    marginTop: 4,
    borderRadius: 16,
    backgroundColor: 'rgba(135,206,235,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  viewAllText: {
    fontSize: 16,
    fontWeight: '700',
    color: SKY,
  },
  detailModalRoot: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  detailBackdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(3,10,21,0.62)',
  },
  detailSheet: {
    maxHeight: '88%',
    borderTopLeftRadius: 26,
    borderTopRightRadius: 26,
    overflow: 'hidden',
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    backgroundColor: '#0B1D34',
    paddingHorizontal: 20,
    paddingTop: 12,
  },
  detailHandle: {
    width: 40,
    height: 5,
    borderRadius: 999,
    backgroundColor: 'rgba(255,255,255,0.22)',
    alignSelf: 'center',
    marginBottom: 18,
  },
  detailHeaderRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    gap: 12,
    marginBottom: 14,
  },
  detailHeaderCopy: {
    flex: 1,
    minWidth: 0,
  },
  detailTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  detailSubtitle: {
    color: 'rgba(226,232,240,0.72)',
    fontSize: 14,
    fontWeight: '600',
    marginTop: 4,
  },
  detailCloseBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
  },
  detailHeroRow: {
    flexDirection: 'row',
    alignItems: 'stretch',
    justifyContent: 'space-between',
    gap: 12,
    marginBottom: 16,
  },
  detailAvatarWrap: {
    width: 78,
    height: 78,
    borderRadius: 22,
    overflow: 'hidden',
  },
  detailAvatar: {
    width: '100%',
    height: '100%',
  },
  detailAvatarFallback: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  detailAvatarLetter: {
    color: '#F9FAFB',
    fontSize: 28,
    fontWeight: '900',
  },
  detailValeterAvatar: {
    width: 20,
    height: 20,
    borderRadius: 10,
  },
  detailValeterAvatarFallback: {
    width: 20,
    height: 20,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(135,206,235,0.24)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.38)',
  },
  detailValeterAvatarLetter: {
    color: '#F9FAFB',
    fontSize: 9,
    fontWeight: '800',
  },
  detailHeroStats: {
    flex: 1,
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    gap: 10,
  },
  detailPricePill: {
    minWidth: 126,
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 18,
    backgroundColor: 'rgba(135,206,235,0.14)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.28)',
    alignItems: 'flex-end',
  },
  detailPricePillGreen: {
    backgroundColor: 'rgba(16,185,129,0.14)',
    borderColor: 'rgba(16,185,129,0.28)',
  },
  detailPricePillRed: {
    backgroundColor: 'rgba(248,113,113,0.14)',
    borderColor: 'rgba(248,113,113,0.28)',
  },
  detailPriceValue: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '900',
    letterSpacing: -0.25,
  },
  detailPriceLabel: {
    color: 'rgba(248,250,252,0.7)',
    fontSize: 12,
    fontWeight: '600',
    marginTop: 2,
  },
  detailStatusWrap: {
    alignSelf: 'flex-end',
  },
  detailScrollContent: {
    gap: 14,
    paddingBottom: 18,
  },
  detailInfoCard: {
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.16)',
    padding: 16,
    gap: 12,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
  },
  detailRowText: {
    flex: 1,
    color: 'rgba(249,250,251,0.92)',
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 20,
  },
  detailMapWrap: {
    height: 220,
    borderRadius: 22,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.16)',
    backgroundColor: 'rgba(8,15,26,0.72)',
  },
  detailMapPin: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: 'rgba(15,23,42,0.94)',
    borderWidth: 2,
    borderColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
  },
  detailMapPlaceholder: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
  },
  detailMapPlaceholderText: {
    color: 'rgba(148,163,184,0.68)',
    fontSize: 12,
    fontWeight: '600',
  },
  detailActions: {
    flexDirection: 'row',
    gap: 12,
    paddingTop: 12,
  },
  detailActionGhost: {
    flex: 1,
    minWidth: 0,
    paddingVertical: 14,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
    backgroundColor: 'rgba(255,255,255,0.04)',
  },
  detailActionGhostText: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '800',
  },
  detailActionPrimary: {
    flex: 1,
    minWidth: 0,
    paddingVertical: 14,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: SKY,
  },
  detailActionPrimaryDisabled: {
    opacity: 0.45,
  },
  detailActionPrimaryText: {
    color: '#0B1D34',
    fontSize: 15,
    fontWeight: '900',
  },
});
