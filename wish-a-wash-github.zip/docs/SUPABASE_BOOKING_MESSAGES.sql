create table if not exists public.booking_messages (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings(id) on delete cascade,
  sender_id uuid not null,
  sender_role text not null,
  message_type text not null default 'text',
  content text null,
  media_url text null,
  voice_duration_seconds integer null,
  created_at timestamptz not null default now()
);

create index if not exists idx_booking_messages_booking_created_at
  on public.booking_messages (booking_id, created_at);

create index if not exists idx_booking_messages_booking_sender
  on public.booking_messages (booking_id, sender_id);

grant select, insert, update, delete on public.booking_messages to authenticated;

alter publication supabase_realtime add table public.booking_messages;
