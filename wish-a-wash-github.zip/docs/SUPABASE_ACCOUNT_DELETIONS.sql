alter table public.account_deletions
  add column if not exists reason text;

alter table public.account_deletions
  add column if not exists notes text;
