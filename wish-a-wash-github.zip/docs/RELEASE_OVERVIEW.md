# Wish a Washer Release Overview

## What this app is
Wish a Washer is the service provider app. It is the side valeters and business accounts use to go online, manage jobs, accept bookings, chat with customers, and connect Stripe for payouts.

Think of it as the driver/provider app in an Uber-style split.

## Main user journeys
- Sign up and log in
- Complete valeter or business onboarding
- Connect a Stripe account
- Go online or offline
- Accept and manage incoming jobs
- Chat with customers about bookings
- Track active jobs
- View earnings, performance, and job history
- Manage business locations, services, and profile data

## App areas to know
- `app/auth/*` handles login, signup, and auth-related routes
- `app/valeter/*` handles the valeter-facing experience
- `app/business/*` handles the business-facing experience
- `src/components/dashboard/*` contains dashboard UI
- `src/services/*` contains the business logic and Supabase/Stripe integration

## Supabase connection points

### Auth
- Uses Supabase Auth for login and session handling
- The app distinguishes between business and valeter style access in its routing and onboarding

### Database tables this app is expected to touch
- `profiles`
- `bookings`
- `booking_messages`
- `valeter_profiles`
- `valeter_documents`
- `valeter_presence`
- `valeter_service_settings`
- `location_services`
- `location_opening_hours`
- `car_wash_locations`
- `organizations`
- `organization_members`
- `reviews`
- `job_completions`
- `waw_platform_fees`

### Edge Functions this app uses
- `stripe-connect`
- `stripe-connect-webhook`
- `booking-extra-charge`

## Payment and Stripe Connect flow
- Valeter or business accounts connect their Stripe account through `stripe-connect`
- The onboarding/status sync is handled from the app through the Stripe Connect Edge Function
- `stripe-connect-webhook` receives Stripe webhook events and updates Supabase-side state
- `booking-extra-charge` is used for booking-related charges and payment requests

## Things to keep aligned
- The Stripe Connect account status in Supabase should match what the app shows
- Any booking payment request payloads should match between this app and the customer app
- Webhook handling should remain the source of truth for payout-related updates
- Route names and role names should stay consistent between the app and the backend payloads

## Important file pointers
- [Business Stripe Connect service](/Volumes/externalSSD/Projects/Latest Wish Group/Wish-a-Washer/wishawasherwithconnect-source-no-assets%202/src/services/stripeConnectService.ts)
- [Valeter Stripe Connect service](/Volumes/externalSSD/Projects/Latest Wish Group/Wish-a-Washer/wishawasherwithconnect-source-no-assets%202/src/services/valeterStripeConnectService.ts)
- [Booking payment request service](/Volumes/externalSSD/Projects/Latest Wish Group/Wish-a-Washer/wishawasherwithconnect-source-no-assets%202/src/services/bookingPaymentRequestService.ts)
- [Stripe Connect Edge Function](/Volumes/externalSSD/Projects/Latest Wish Group/Wish-a-Washer/wishawasherwithconnect-source-no-assets%202/supabase/functions/stripe-connect/index.ts)
- [Stripe Connect webhook](/Volumes/externalSSD/Projects/Latest Wish Group/Wish-a-Washer/wishawasherwithconnect-source-no-assets%202/supabase/functions/stripe-connect-webhook/index.ts)
- [Shared booking charge function](/Volumes/externalSSD/Projects/Latest Wish Group/Wish-a-Washer/wishawasherwithconnect-source-no-assets%202/supabase/functions/booking-extra-charge/index.ts)

## Release note
This document is meant as a release and handover summary for the service provider app. It is intentionally focused on the live wiring between app, Stripe, and Supabase.
