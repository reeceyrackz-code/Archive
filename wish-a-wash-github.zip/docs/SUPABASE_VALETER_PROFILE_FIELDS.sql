-- Run in Supabase SQL editor (once) to support valeter personal info fields.
-- This adds the missing business_name column used by the valeter personal info screen.

ALTER TABLE public.valeter_profiles
  ADD COLUMN IF NOT EXISTS business_name text NULL;

COMMENT ON COLUMN public.valeter_profiles.business_name IS 'Optional trading / business name shown on the valeter personal info page.';

ALTER TABLE public.valeter_profiles
  ADD COLUMN IF NOT EXISTS is_self_sufficient boolean NOT NULL DEFAULT false;

COMMENT ON COLUMN public.valeter_profiles.is_self_sufficient IS 'Whether the valeter has their own water and power setup.';

ALTER TABLE public.valeter_profiles
  ADD COLUMN IF NOT EXISTS notification_preferences jsonb NOT NULL DEFAULT '{"jobAlerts":true,"sound":true,"vibration":true,"email":false}'::jsonb;

COMMENT ON COLUMN public.valeter_profiles.notification_preferences IS 'Valeter notification settings stored as JSON.';

ALTER TABLE public.valeter_profiles
  ADD COLUMN IF NOT EXISTS terms_status text NOT NULL DEFAULT 'pending';

ALTER TABLE public.valeter_profiles
  ADD COLUMN IF NOT EXISTS terms_version text NULL;

ALTER TABLE public.valeter_profiles
  ADD COLUMN IF NOT EXISTS terms_accepted_at timestamptz NULL;

ALTER TABLE public.valeter_profiles
  ADD COLUMN IF NOT EXISTS terms_declined_at timestamptz NULL;

ALTER TABLE public.valeter_profiles
  ADD COLUMN IF NOT EXISTS terms_details jsonb NOT NULL DEFAULT '{}'::jsonb;

ALTER TABLE public.valeter_profiles
  ADD COLUMN IF NOT EXISTS stripe_connect_status text NOT NULL DEFAULT 'not_started';

ALTER TABLE public.valeter_profiles
  ADD COLUMN IF NOT EXISTS stripe_account_id text NULL;

ALTER TABLE public.valeter_profiles
  ADD COLUMN IF NOT EXISTS stripe_onboarding_started_at timestamptz NULL;

ALTER TABLE public.valeter_profiles
  ADD COLUMN IF NOT EXISTS stripe_onboarding_completed_at timestamptz NULL;

ALTER TABLE public.valeter_profiles
  ADD COLUMN IF NOT EXISTS stripe_details jsonb NOT NULL DEFAULT '{}'::jsonb;

COMMENT ON COLUMN public.valeter_profiles.terms_status IS 'Valeter terms acceptance status.';
COMMENT ON COLUMN public.valeter_profiles.terms_version IS 'Version of the terms accepted or declined.';
COMMENT ON COLUMN public.valeter_profiles.terms_accepted_at IS 'When the valeter accepted the terms.';
COMMENT ON COLUMN public.valeter_profiles.terms_declined_at IS 'When the valeter declined the terms.';
COMMENT ON COLUMN public.valeter_profiles.terms_details IS 'Additional terms context such as account mode.';
COMMENT ON COLUMN public.valeter_profiles.stripe_connect_status IS 'Stripe onboarding state for the valeter.';
COMMENT ON COLUMN public.valeter_profiles.stripe_account_id IS 'Linked Stripe account id for the valeter.';
COMMENT ON COLUMN public.valeter_profiles.stripe_onboarding_started_at IS 'When Stripe Connect onboarding started.';
COMMENT ON COLUMN public.valeter_profiles.stripe_onboarding_completed_at IS 'When Stripe Connect onboarding completed.';
COMMENT ON COLUMN public.valeter_profiles.stripe_details IS 'Extra Stripe state cached from onboarding.';
