import type { StyleProp, ViewStyle } from 'react-native';
import { useVideoPlayer, VideoView, type VideoSource } from 'expo-video';

type BackgroundVideoProps = {
  source: VideoSource;
  style?: StyleProp<ViewStyle>;
  onFirstFrameRender?: () => void;
};

/** Muted, looping, auto-playing video with no controls, used as a screen background. */
export function BackgroundVideo({ source, style, onFirstFrameRender }: BackgroundVideoProps) {
  const player = useVideoPlayer(source, (p) => {
    p.loop = true;
    p.muted = true;
    p.play();
  });

  return (
    <VideoView
      player={player}
      style={style}
      contentFit="cover"
      nativeControls={false}
      allowsPictureInPicture={false}
      pointerEvents="none"
      {...(onFirstFrameRender ? { onFirstFrameRender } : {})}
    />
  );
}
