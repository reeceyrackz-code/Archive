import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  RefreshControl,
  ScrollView,
  Image,
  TextInput,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import LoadingScreen from '../../src/components/LoadingScreen';
import EmptyState from '../../src/components/shared/EmptyState';
import AppHeader from '../../src/components/shared/AppHeader';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { useOwnerScrollContentPadding } from '../../src/hooks/useOwnerScrollContentPadding';
import { CONTENT_PADDING_H } from '../../src/constants/pageStyles';
import { colors } from '../../src/constants/colors';
import { fetchProfileById } from '../../src/utils/customerProfiles';
import { getServiceDisplayName } from '../../src/utils/serviceNameMapper';
import { ValeterStatsService } from '../../src/services/Valeterstatsservice';
import { formatDisplayName } from '../../src/utils/formatDisplayName';
import { ValeterPhotoPlaceholder, WashHubPlaceholder } from '../../src/components/shared/washValeterPlaceholders';
import { CCP, ccpFallbackName, ccpSingularLower } from '../../src/constants/carCareProLabels';

const SKY = colors.SKY;
const TEXT_PRIMARY = '#F1F5F9';
const TEXT_TERTIARY = 'rgba(241,245,249,0.48)';
const SEARCH_BG = 'rgba(255,255,255,0.09)';
const LIST_SURFACE = 'rgba(15,23,42,0.35)';
const AVATAR_SIZE = 56;
const HUB_AVATAR_RADIUS = 14;

/** Bookings that can have support chat (aligned with pro-app lifecycle + hub/pool). */
const INBOX_BOOKING_STATUSES: string[] = [
  'pending',
  'pending_valeter_acceptance',
  'pending_payment',
  'confirmed',
  'scheduled',
  'valeter_assigned',
  'en_route',
  'arrived',
  'in_progress',
  'completed',
];

/** Statuses safe for `.in('status', …)` — omit values missing from some `booking_status` enums. */
const INBOX_BOOKING_STATUSES_QUERY: string[] = INBOX_BOOKING_STATUSES.filter(
  (s) => s !== 'pending_business_acceptance'
);

/** Narrower fallback if the DB rejects another status in the filter (Postgres `22P02`). */
const INBOX_BOOKING_STATUSES_FALLBACK: string[] = [
  'pending_valeter_acceptance',
  'pending_payment',
  'confirmed',
  'scheduled',
  'valeter_assigned',
  'en_route',
  'arrived',
  'in_progress',
  'completed',
];

type InboxThread = {
  id: string;
  bookingId: string;
  /** Stable identity for the contact (valeter / hub) so repeat bookings collapse into one chat. */
  personKey: string;
  proName: string;
  serviceDisplayName: string;
  status: string;
  address?: string | null;
  updatedAt: string;
  valeterId?: string | null;
  locationId?: string | null;
  profilePhoto?: string | null;
  rating?: number;
  totalJobs?: number;
  isHub?: boolean;
  /** How many bookings are folded into this conversation. */
  bookingCount: number;
};

/** Group identity for a row so the same contact never opens a second chat. */
function getPersonKey(valeterId?: string | null, locationId?: string | null, proName?: string): string {
  if (valeterId) return `v:${valeterId}`;
  if (locationId) return `h:${locationId}`;
  return `n:${(proName || '').trim().toLowerCase()}`;
}

/**
 * Collapse multiple bookings with the same person into a single conversation.
 * Rows arrive newest-first, so the first one seen for a contact is the live thread
 * we keep (and route to); older bookings only bump the count.
 */
function dedupeThreadsByPerson(rows: InboxThread[]): InboxThread[] {
  const byPerson = new Map<string, InboxThread>();
  const ordered: InboxThread[] = [];
  for (const row of rows) {
    const existing = byPerson.get(row.personKey);
    if (!existing) {
      const rep: InboxThread = { ...row, bookingCount: 1 };
      byPerson.set(row.personKey, rep);
      ordered.push(rep);
    } else {
      existing.bookingCount += 1;
    }
  }
  return ordered;
}

function formatListTime(iso: string): string {
  const d = new Date(iso);
  const now = new Date();
  const startOfToday = new Date(now);
  startOfToday.setHours(0, 0, 0, 0);
  const startOfMsg = new Date(d);
  startOfMsg.setHours(0, 0, 0, 0);
  const diffDays = Math.round((startOfToday.getTime() - startOfMsg.getTime()) / (24 * 60 * 60 * 1000));
  if (diffDays === 0) return d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
  if (diffDays === 1) return 'Yesterday';
  if (diffDays > 1 && diffDays < 7) return d.toLocaleDateString('en-GB', { weekday: 'short' });
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
}

function bookingStatusLabel(status: string): string {
  const s = (status || '').toLowerCase();
  if (s === 'pending_valeter_acceptance') return `Finding ${ccpSingularLower()}`;
  if (s === 'valeter_assigned') return `${CCP.singularShort} assigned`;
  const map: Record<string, string> = {
    pending: 'Pending',
    pending_business_acceptance: 'Pending',
    pending_payment: 'Payment pending',
    confirmed: 'Confirmed',
    scheduled: 'Scheduled',
    en_route: 'On the way',
    arrived: 'Arrived',
    in_progress: 'In progress',
    completed: 'Completed',
  };
  return map[s] || status.replace(/_/g, ' ');
}

export default function InboxScreen() {
  const { user } = useAuth();
  const scrollPad = useOwnerScrollContentPadding(true);

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [threads, setThreads] = useState<InboxThread[]>([]);
  const [searchQuery, setSearchQuery] = useState('');

  const loadThreads = useCallback(async () => {
    if (!user?.id) {
      setThreads([]);
      setLoading(false);
      return;
    }
    try {
      const inboxBookingsQuery = (statuses: string[]) =>
        supabase
          .from('bookings')
          .select(
            'id, service_type, service_name, valeter_id, location_id, valeter_name, status, location_address, updated_at, created_at'
          )
          .eq('user_id', user.id)
          .is('cancelled_at', null)
          .in('status', statuses)
          .or('valeter_id.not.is.null,location_id.not.is.null')
          .order('updated_at', { ascending: false })
          .limit(50);

      let { data: rows, error } = await inboxBookingsQuery(INBOX_BOOKING_STATUSES_QUERY);
      if (error?.code === '22P02') {
        const retry = await inboxBookingsQuery(INBOX_BOOKING_STATUSES_FALLBACK);
        rows = retry.data;
        error = retry.error;
      }
      if (error) throw error;
      const raw = rows || [];

      const valeterIds = [...new Set(raw.map((r: any) => r.valeter_id).filter(Boolean))] as string[];
      const locationIds = [...new Set(raw.map((r: any) => r.location_id).filter(Boolean))] as string[];

      const [statsBatch, vProfilesRes, hubsRes] = await Promise.all([
        ValeterStatsService.getValeterStatsBatch(valeterIds),
        valeterIds.length
          ? supabase.from('valeter_profiles').select('user_id, profile_photo_url').in('user_id', valeterIds)
          : Promise.resolve({ data: [] as { user_id: string; profile_photo_url: string | null }[] }),
        locationIds.length
          ? supabase.from('car_wash_locations').select('id,name').in('id', locationIds)
          : Promise.resolve({ data: [] as { id: string; name: string | null }[] }),
      ]);

      const vpMap = new Map<string, string | null>();
      for (const vp of vProfilesRes.data || []) {
        vpMap.set(vp.user_id, vp.profile_photo_url ?? null);
      }
      const hubMap = new Map<string, string>();
      for (const h of hubsRes.data || []) {
        hubMap.set(h.id, h.name || 'Car Wash');
      }

      const list: InboxThread[] = [];
      for (const row of raw) {
        const r = row as any;
        let proName = r.valeter_name || ccpFallbackName();
        let profilePhoto: string | null = null;
        let rating: number | undefined;
        let totalJobs: number | undefined;
        const isHub = !r.valeter_id && !!r.location_id;

        if (r.valeter_id) {
          if (!r.valeter_name) {
            const profile = await fetchProfileById(r.valeter_id);
            proName = profile?.full_name || ccpFallbackName();
          }
          profilePhoto = vpMap.get(r.valeter_id) ?? null;
          if (!profilePhoto) {
            const { data: prof } = await supabase.from('profiles').select('profile_picture').eq('id', r.valeter_id).maybeSingle();
            profilePhoto = (prof as any)?.profile_picture ?? null;
          }
          const stats = statsBatch.get(r.valeter_id);
          if (stats) {
            rating = stats.averageRating;
            totalJobs = stats.totalJobs;
          }
        } else if (r.location_id) {
          proName = hubMap.get(r.location_id) || 'Car Wash';
        }

        list.push({
          id: r.id,
          bookingId: r.id,
          personKey: getPersonKey(r.valeter_id, r.location_id, proName),
          proName,
          serviceDisplayName: getServiceDisplayName(r.service_type, r.service_name),
          status: r.status || 'scheduled',
          address: r.location_address ?? null,
          updatedAt: r.updated_at || r.created_at || new Date().toISOString(),
          valeterId: r.valeter_id ?? null,
          locationId: r.location_id ?? null,
          profilePhoto: profilePhoto ?? null,
          ...(rating !== undefined ? { rating } : {}),
          ...(totalJobs !== undefined ? { totalJobs } : {}),
          isHub,
          bookingCount: 1,
        });
      }
      setThreads(dedupeThreadsByPerson(list));
    } catch (e) {
      console.error('[inbox] load error', e);
      setThreads([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [user?.id]);

  useEffect(() => {
    loadThreads();
  }, [loadThreads]);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    loadThreads();
  }, [loadThreads]);

  const filteredThreads = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return threads;
    return threads.filter(
      (t) =>
        t.proName.toLowerCase().includes(q) ||
        t.serviceDisplayName.toLowerCase().includes(q) ||
        (t.address || '').toLowerCase().includes(q) ||
        bookingStatusLabel(t.status).toLowerCase().includes(q)
    );
  }, [threads, searchQuery]);

  const openChat = useCallback((bookingId: string) => {
    hapticFeedback('light');
    router.push({ pathname: '/owner/booking/chat', params: { bookingId } } as any);
  }, []);

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LoadingScreen />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <AppHeader
        title="Messages"
        subtitle={threads.length > 0 ? `${threads.length} conversation${threads.length === 1 ? '' : 's'}` : undefined}
        variant="dashboard"
        accountType="customer"
        fullWidth
      />
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          { ...scrollPad, paddingTop: (scrollPad.paddingTop ?? 0) + 12 },
        ]}
        showsVerticalScrollIndicator={false}
        scrollEventThrottle={16}
        keyboardShouldPersistTaps="handled"
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />}
      >
        {threads.length === 0 ? (
          <Animated.View entering={FadeInDown.delay(100)} style={styles.emptyContainer}>
            <EmptyState
              icon="chatbubbles-outline"
              title="No chats yet"
              subtitle={`After you book, conversations with your ${ccpSingularLower()} or car wash appear here. Pull down to refresh.`}
              actionLabel="View bookings"
              onAction={() => router.push('/owner/track')}
              iconColor={SKY}
              style={[styles.emptyState, { paddingHorizontal: CONTENT_PADDING_H }]}
            />
          </Animated.View>
        ) : (
          <>
            <View style={[styles.searchWrap, { marginHorizontal: CONTENT_PADDING_H }]}>
              <Ionicons name="search" size={18} color={TEXT_TERTIARY} style={styles.searchIcon} />
              <TextInput
                style={styles.searchInput}
                placeholder="Search"
                placeholderTextColor={TEXT_TERTIARY}
                value={searchQuery}
                onChangeText={setSearchQuery}
                returnKeyType="search"
                autoCorrect={false}
                autoCapitalize="none"
              />
              {searchQuery.length > 0 ? (
                <TouchableOpacity onPress={() => setSearchQuery('')} hitSlop={12} accessibilityLabel="Clear search">
                  <Ionicons name="close-circle" size={20} color={TEXT_TERTIARY} />
                </TouchableOpacity>
              ) : null}
            </View>

            <View style={[styles.chatList, { marginHorizontal: CONTENT_PADDING_H }]}>
              {filteredThreads.map((thread, index) => {
                const isActive = thread.status !== 'completed';
                const statusText = bookingStatusLabel(thread.status);
                const metaBits: string[] = [];
                if (!thread.isHub && thread.rating != null && thread.rating > 0) metaBits.push(`${thread.rating.toFixed(1)} ★`);
                if (!thread.isHub && thread.totalJobs != null) metaBits.push(`${thread.totalJobs} jobs`);
                const metaLine = metaBits.length ? metaBits.join(' · ') : null;

                return (
                  <Animated.View key={`${thread.personKey}:${thread.bookingId}`} entering={FadeInDown.delay(Math.min(40 + index * 35, 400))}>
                    <TouchableOpacity
                      style={[styles.chatCard, isActive && styles.chatCardActive]}
                      activeOpacity={0.7}
                      onPress={() => openChat(thread.bookingId)}
                      accessibilityRole="button"
                      accessibilityLabel={`Open chat with ${thread.proName}`}
                    >
                      <View style={styles.chatRowInner}>
                        {thread.isHub ? (
                          <View
                            style={[
                              styles.avatarHub,
                              { borderColor: SKY + '44' },
                              isActive && styles.avatarHubActiveBooking,
                            ]}
                          >
                            <WashHubPlaceholder width={38} height={38} borderRadius={10} iconSize={20} iconName="camera-outline" />
                            <View style={styles.avatarHubBadge}>
                              <Ionicons name="camera-outline" size={10} color="#fff" />
                            </View>
                          </View>
                        ) : (
                          <View style={styles.avatarValeterWrap}>
                            {thread.profilePhoto ? (
                              <Image source={{ uri: thread.profilePhoto }} style={styles.avatarValeter} resizeMode="cover" />
                            ) : (
                              <ValeterPhotoPlaceholder size={AVATAR_SIZE} borderRadius={AVATAR_SIZE / 2} />
                            )}
                            <View style={[styles.presenceDot, isActive ? styles.presenceActiveBooking : undefined]} />
                          </View>
                        )}

                        <View style={styles.chatRowBody}>
                          <View style={styles.chatRowTop}>
                            <View style={styles.nameRow}>
                              {isActive ? <View style={styles.unreadDot} /> : null}
                              <Text
                                style={[styles.chatName, isActive && styles.chatNameActive]}
                                numberOfLines={1}
                              >
                                {thread.isHub ? thread.proName : formatDisplayName(thread.proName)}
                              </Text>
                              {thread.bookingCount > 1 ? (
                                <View style={styles.bookingCountBadge}>
                                  <Text style={styles.bookingCountText}>{thread.bookingCount}</Text>
                                </View>
                              ) : null}
                            </View>
                            <Text style={[styles.chatTime, isActive && styles.chatTimeActive]}>{formatListTime(thread.updatedAt)}</Text>
                          </View>
                          <View style={styles.previewRow}>
                            {!isActive ? (
                              <Ionicons name="checkmark-done" size={15} color={SKY} style={styles.previewLeadIcon} />
                            ) : null}
                            <Text style={styles.previewText} numberOfLines={1}>
                              {isActive ? (
                                <>
                                  <Text style={styles.previewStatus}>{statusText}</Text>
                                  <Text style={styles.previewMuted}>
                                    {' · '}
                                    {thread.serviceDisplayName}
                                    {thread.address ? ` · ${thread.address}` : ''}
                                  </Text>
                                </>
                              ) : (
                                <Text style={styles.previewMuted}>
                                  {thread.serviceDisplayName}
                                  {thread.address ? ` · ${thread.address}` : ''}
                                </Text>
                              )}
                            </Text>
                          </View>
                          {metaLine ? (
                            <Text style={styles.chatMetaHint} numberOfLines={1}>
                              {metaLine}
                            </Text>
                          ) : null}
                        </View>
                        <Ionicons name="chevron-forward" size={18} color={TEXT_TERTIARY} style={styles.chatChevron} />
                      </View>
                    </TouchableOpacity>
                  </Animated.View>
                );
              })}
            </View>

            {filteredThreads.length === 0 && searchQuery.trim() ? (
              <Text style={[styles.noResults, { paddingHorizontal: CONTENT_PADDING_H }]}>No chats match “{searchQuery.trim()}”</Text>
            ) : null}
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 28,
  },
  emptyContainer: {
    flex: 1,
    minHeight: 280,
    justifyContent: 'center',
  },
  emptyState: {
    marginHorizontal: 0,
  },
  searchWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: SEARCH_BG,
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 9,
    marginBottom: 12,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(148,163,184,0.12)',
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: TEXT_PRIMARY,
    paddingVertical: 0,
    fontWeight: '500',
  },
  chatList: {
    marginTop: 2,
    gap: 10,
  },
  chatCard: {
    backgroundColor: LIST_SURFACE,
    borderRadius: 18,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(148,163,184,0.16)',
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.18,
    shadowRadius: 10,
    elevation: 3,
  },
  chatCardActive: {
    borderColor: SKY + '3D',
    backgroundColor: 'rgba(20,33,57,0.55)',
  },
  chatRowInner: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 14,
    minHeight: 76,
  },
  chatChevron: {
    marginLeft: 6,
    flexShrink: 0,
    opacity: 0.7,
  },
  bookingCountBadge: {
    minWidth: 20,
    height: 20,
    paddingHorizontal: 6,
    borderRadius: 10,
    backgroundColor: SKY + '33',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: SKY + '55',
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
  },
  bookingCountText: {
    color: SKY,
    fontSize: 11,
    fontWeight: '700',
  },
  avatarValeterWrap: {
    width: AVATAR_SIZE,
    height: AVATAR_SIZE,
    marginRight: 14,
    position: 'relative',
  },
  avatarValeter: {
    width: AVATAR_SIZE,
    height: AVATAR_SIZE,
    borderRadius: AVATAR_SIZE / 2,
  },
  avatarValeterPlaceholder: {
    width: AVATAR_SIZE,
    height: AVATAR_SIZE,
    borderRadius: AVATAR_SIZE / 2,
    overflow: 'hidden',
    backgroundColor: SKY + '22',
  },
  presenceDot: {
    position: 'absolute',
    bottom: 2,
    right: 2,
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: 'rgba(148,163,184,0.5)',
    borderWidth: 2,
    borderColor: 'rgba(15,23,42,0.95)',
  },
  /** Active booking thread (not completed) — readable “open conversation” cue, not live presence */
  presenceActiveBooking: {
    backgroundColor: '#34D399',
  },
  avatarHub: {
    width: AVATAR_SIZE,
    height: AVATAR_SIZE,
    borderRadius: HUB_AVATAR_RADIUS,
    marginRight: 14,
    backgroundColor: SKY + '18',
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  avatarHubImage: {
    width: 36,
    height: 36,
    opacity: 0.95,
  },
  avatarHubActiveBooking: {
    borderColor: 'rgba(52,211,153,0.75)',
    borderWidth: 2,
  },
  avatarHubBadge: {
    position: 'absolute',
    bottom: 3,
    right: 3,
    width: 18,
    height: 18,
    borderRadius: 5,
    backgroundColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: 'rgba(15,23,42,0.95)',
  },
  chatRowBody: {
    flex: 1,
    minWidth: 0,
    justifyContent: 'center',
  },
  chatRowTop: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10,
    marginBottom: 3,
  },
  nameRow: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    minWidth: 0,
    gap: 8,
  },
  unreadDot: {
    width: 9,
    height: 9,
    borderRadius: 5,
    backgroundColor: '#25D366',
    flexShrink: 0,
  },
  chatName: {
    flex: 1,
    fontSize: 17,
    fontWeight: '600',
    color: TEXT_PRIMARY,
    letterSpacing: -0.2,
  },
  chatNameActive: {
    fontWeight: '700',
  },
  chatTime: {
    fontSize: 12,
    fontWeight: '500',
    color: TEXT_TERTIARY,
    flexShrink: 0,
  },
  chatTimeActive: {
    color: SKY,
    fontWeight: '600',
  },
  previewRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    minWidth: 0,
  },
  previewLeadIcon: {
    marginTop: 1,
    flexShrink: 0,
  },
  previewText: {
    flex: 1,
    fontSize: 14,
    fontWeight: '400',
    lineHeight: 19,
    minWidth: 0,
  },
  previewStatus: {
    color: SKY,
    fontWeight: '600',
  },
  previewMuted: {
    color: TEXT_TERTIARY,
    fontWeight: '400',
  },
  chatMetaHint: {
    marginTop: 3,
    fontSize: 11,
    fontWeight: '500',
    color: 'rgba(241,245,249,0.38)',
  },
  noResults: {
    textAlign: 'center',
    marginTop: 24,
    fontSize: 14,
    color: TEXT_TERTIARY,
    fontWeight: '600',
  },
});
