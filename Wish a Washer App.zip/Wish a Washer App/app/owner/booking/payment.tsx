import React, { useCallback, useEffect, useRef, useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import MapView, { Marker, Region } from 'react-native-maps';
import { router, useLocalSearchParams } from 'expo-router';
import BookingPaymentSheet from '../../../src/components/booking/BookingPaymentSheet';
import { MapMarkerCustomerVehicle } from '../../../src/components/maps/MapMarkerViews';
import useLiveLocation from '../../../src/hooks/useLiveLocation';
import { supabase } from '../../../src/lib/supabase';
import {
  BOOKING_MAP_STYLE,
  DEFAULT_MAP_REGION,
  MAP_LOCKED_DARK,
  MAP_ZOOM_DELTA,
} from '../../../src/constants/mapConstants';

function coordsFromBooking(row: Record<string, unknown> | null): { latitude: number; longitude: number } | null {
  if (!row) return null;
  const lat = Number(row.location_lat);
  const lng = Number(row.location_lng);
  if (Number.isFinite(lat) && Number.isFinite(lng)) {
    return { latitude: lat, longitude: lng };
  }
  const loc = row.location;
  if (loc && typeof loc === 'object') {
    const o = loc as Record<string, unknown>;
    const la = Number(o.latitude ?? o.lat);
    const lo = Number(o.longitude ?? o.lng);
    if (Number.isFinite(la) && Number.isFinite(lo)) {
      return { latitude: la, longitude: lo };
    }
  }
  return null;
}

/**
 * Full-route payment: same Stripe flow as the tracking inline sheet, for hub flows that `replace` here after creating a pending-payment booking.
 */
export default function BookingPaymentScreen() {
  const { bookingId: bookingIdParam } = useLocalSearchParams<{ bookingId?: string }>();
  const bookingId = bookingIdParam ?? null;
  const insets = useSafeAreaInsets();
  const mapRef = useRef<MapView>(null);
  const { coords: liveCoords } = useLiveLocation();
  const [mapCenter, setMapCenter] = useState<{ latitude: number; longitude: number } | null>(null);

  useEffect(() => {
    if (!bookingId) {
      router.back();
    }
  }, [bookingId]);

  useEffect(() => {
    if (!bookingId) return;
    let cancelled = false;
    void (async () => {
      try {
        const { data, error } = await supabase
          .from('bookings')
          .select('location_lat, location_lng, location')
          .eq('id', bookingId)
          .maybeSingle();
        if (cancelled) return;
        if (error) throw error;
        const coords = coordsFromBooking(data as Record<string, unknown> | null);
        if (coords) {
          setMapCenter(coords);
          mapRef.current?.animateToRegion(
            { ...coords, latitudeDelta: MAP_ZOOM_DELTA, longitudeDelta: MAP_ZOOM_DELTA },
            350,
          );
        }
      } catch {
        /* fall back to live location */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [bookingId]);

  useEffect(() => {
    if (mapCenter || !liveCoords) return;
    setMapCenter({ latitude: liveCoords.latitude, longitude: liveCoords.longitude });
  }, [liveCoords, mapCenter]);

  const onClose = useCallback(() => {
    router.back();
  }, []);

  const onPaid = useCallback(() => {
    if (!bookingId) return;
    router.replace({ pathname: '/owner/booking/tracking', params: { bookingId } } as any);
  }, [bookingId]);

  const region: Region = {
    ...(mapCenter ?? {
      latitude: liveCoords?.latitude ?? DEFAULT_MAP_REGION.latitude,
      longitude: liveCoords?.longitude ?? DEFAULT_MAP_REGION.longitude,
    }),
    latitudeDelta: MAP_ZOOM_DELTA,
    longitudeDelta: MAP_ZOOM_DELTA,
  };

  const sheetMapBottom = 280 + Math.max(insets.bottom, 14);

  if (!bookingId) {
    return <View style={styles.shell} />;
  }

  return (
    <View style={styles.shell}>
      <MapView
        ref={mapRef}
        style={StyleSheet.absoluteFill}
        region={region}
        scrollEnabled={false}
        zoomEnabled={false}
        rotateEnabled={false}
        pitchEnabled={false}
        showsUserLocation
        showsMyLocationButton={false}
        toolbarEnabled={false}
        customMapStyle={BOOKING_MAP_STYLE}
        userInterfaceStyle={MAP_LOCKED_DARK}
        mapPadding={{ top: 12, right: 12, bottom: sheetMapBottom, left: 12 }}
        legalLabelInsets={{ top: 0, right: 10, bottom: sheetMapBottom - 40, left: 10 }}
      >
        {mapCenter ? (
          <Marker coordinate={mapCenter} anchor={{ x: 0.5, y: 1 }}>
            <MapMarkerCustomerVehicle size={42} variant="pin" />
          </Marker>
        ) : null}
      </MapView>
      <BookingPaymentSheet
        visible
        presentation="route"
        bookingId={bookingId}
        onClose={onClose}
        onPaid={onPaid}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  shell: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
});
