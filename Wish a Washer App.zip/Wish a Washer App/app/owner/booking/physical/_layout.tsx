import { useEffect } from 'react';
import { Stack, router } from 'expo-router';
import { MOBILE_SERVICE_ONLY_LAUNCH } from '../../../../src/constants/launchCustomerScope';

/** Redirect hub / come-to-us booking routes while mobile-only launch is active. */
export default function PhysicalBookingLayout() {
  useEffect(() => {
    if (MOBILE_SERVICE_ONLY_LAUNCH) {
      router.replace('/owner/booking/create');
    }
  }, []);

  if (MOBILE_SERVICE_ONLY_LAUNCH) return null;

  return <Stack screenOptions={{ headerShown: false }} />;
}
