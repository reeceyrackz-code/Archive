import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Dimensions,
  Switch,
  TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import AppHeader from '../../../src/components/shared/AppHeader';
import GradientIconBox from '../../../src/components/shared/GradientIconBox';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { useOwnerScrollContentPadding } from '../../../src/hooks/useOwnerScrollContentPadding';
import { useTheme } from '../../../src/contexts/ThemeContext';
import { customerTheme } from '../../../src/constants/customerTheme';
import { colors } from '../../../src/constants/colors';
import { BORDER_RADIUS, CARD_SHADOW } from '../../../src/constants/designTokens';
import { AUTO_SELECT_DEFAULT_VEHICLE_KEY } from '../../../src/constants/userPreferences';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;

export default function AppearanceSettings() {
  const scrollPad = useOwnerScrollContentPadding(true);
  const { isDark, setColorScheme, theme } = useTheme();
  const activeTheme = theme ?? customerTheme;

  const [autoSelectVehicle, setAutoSelectVehicle] = useState(false);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const stored = await AsyncStorage.getItem(AUTO_SELECT_DEFAULT_VEHICLE_KEY);
        if (active && stored === 'true') setAutoSelectVehicle(true);
      } catch {}
    })();
    return () => {
      active = false;
    };
  }, []);

  const handleToggleAutoSelectVehicle = (value: boolean) => {
    hapticFeedback('light');
    setAutoSelectVehicle(value);
    void AsyncStorage.setItem(AUTO_SELECT_DEFAULT_VEHICLE_KEY, value ? 'true' : 'false');
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: activeTheme.backgroundColor }]} edges={[]}>
      <LinearGradient colors={activeTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Appearance"
        accountType="customer"
        showBack
        fullWidth
        onBack={() => {
          hapticFeedback('light');
          router.back();
        }}
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, scrollPad]}
        showsVerticalScrollIndicator={false}
      >
        <Text style={styles.sectionLabel}>Theme</Text>
        <View style={styles.settingCard}>
          <View style={styles.settingIconWrapper}>
            <GradientIconBox icon="moon" preset="sky" boxSize={48} size={22} borderRadius={14} elevated />
          </View>
          <View style={styles.settingContent}>
            <Text style={styles.settingTitle}>Dark mode</Text>
            <Text style={styles.settingSubtitle}>{isDark ? 'On' : 'Off'} — saved on this device</Text>
          </View>
          <Switch
            value={isDark}
            onValueChange={(value) => {
              hapticFeedback('light');
              setColorScheme(value ? 'dark' : 'light');
            }}
            trackColor={{ false: '#374151', true: SKY }}
            thumbColor={isDark ? '#FFFFFF' : '#9CA3AF'}
            accessibilityLabel="Dark mode"
          />
        </View>

        <Text style={[styles.sectionLabel, { marginTop: 22 }]}>Booking</Text>
        <View style={styles.settingCard}>
          <View style={styles.settingIconWrapper}>
            <GradientIconBox icon="car-sport" preset="blue" boxSize={48} size={22} borderRadius={14} elevated />
          </View>
          <View style={styles.settingContent}>
            <Text style={styles.settingTitle}>Auto-select default vehicle</Text>
            <Text style={styles.settingSubtitle}>
              {autoSelectVehicle ? 'On — skips the vehicle step' : 'Off — choose a vehicle each time'}
            </Text>
          </View>
          <Switch
            value={autoSelectVehicle}
            onValueChange={handleToggleAutoSelectVehicle}
            trackColor={{ false: '#374151', true: SKY }}
            thumbColor={autoSelectVehicle ? '#FFFFFF' : '#9CA3AF'}
            accessibilityLabel="Auto-select default vehicle"
          />
        </View>

        <Text style={[styles.sectionLabel, { marginTop: 22 }]}>Legal</Text>
        <TouchableOpacity
          style={styles.linkCard}
          onPress={() => {
            hapticFeedback('light');
            router.push('/privacy-policy' as any);
          }}
          activeOpacity={0.85}
          accessibilityRole="button"
          accessibilityLabel="Privacy policy"
        >
          <Ionicons name="document-text-outline" size={22} color={SKY} />
          <Text style={styles.linkCardText}>Privacy policy</Text>
          <Ionicons name="chevron-forward" size={20} color="rgba(148,163,184,0.75)" />
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.linkCard}
          onPress={() => {
            hapticFeedback('light');
            router.push('/cookie-policy' as any);
          }}
          activeOpacity={0.85}
          accessibilityRole="button"
          accessibilityLabel="Cookie policy"
        >
          <Ionicons name="shield-checkmark-outline" size={22} color={SKY} />
          <Text style={styles.linkCardText}>Cookie policy</Text>
          <Ionicons name="chevron-forward" size={20} color="rgba(148,163,184,0.75)" />
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.linkCard}
          onPress={() => {
            hapticFeedback('light');
            router.push('/terms-of-service' as any);
          }}
          activeOpacity={0.85}
          accessibilityRole="button"
          accessibilityLabel="Terms of service"
        >
          <Ionicons name="reader-outline" size={22} color={SKY} />
          <Text style={styles.linkCardText}>Terms of service</Text>
          <Ionicons name="chevron-forward" size={20} color="rgba(148,163,184,0.75)" />
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 120, paddingHorizontal: isSmallScreen ? 12 : 20 },
  sectionLabel: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
    marginBottom: 10,
  },
  settingCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surfaceOverlay,
    borderRadius: BORDER_RADIUS.md,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: colors.borderLight,
    ...CARD_SHADOW,
  },
  settingIconWrapper: { marginRight: 12 },
  settingContent: { flex: 1 },
  settingTitle: {
    color: colors.textOnDarkPrimary,
    fontSize: isSmallScreen ? 16 : 17,
    fontWeight: '700',
    marginBottom: 4,
  },
  settingSubtitle: {
    color: SKY,
    fontSize: 13,
    fontWeight: '600',
  },
  linkCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: colors.surfaceOverlay,
    borderRadius: BORDER_RADIUS.md,
    padding: 16,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: colors.borderLight,
    ...CARD_SHADOW,
  },
  linkCardText: {
    flex: 1,
    color: colors.textOnDarkPrimary,
    fontSize: 16,
    fontWeight: '700',
  },
});
