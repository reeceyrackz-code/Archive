import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Platform,
  Alert,
  ActivityIndicator,
  TextInput,
  KeyboardAvoidingView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from '../../../src/components/shared/AppHeader';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { useOwnerScrollContentPadding } from '../../../src/hooks/useOwnerScrollContentPadding';
import { CONTENT_PADDING_H } from '../../../src/constants/pageStyles';
import { colors } from '../../../src/constants/colors';
import GradientIconBox from '../../../src/components/shared/GradientIconBox';
import { BORDER_RADIUS } from '../../../src/constants/designTokens';

const SKY = colors.SKY;
const isSmallScreen = Dimensions.get('window').width < 375;

// Stripe CardField + createToken only on native
let CardField: React.ComponentType<any> = () => null;
let useStripe: () => { createToken?: (params: { type: 'Card' }) => Promise<{ token?: { id: string; card: { brand: string; last4: string; expMonth: number; expYear: number } }; error?: { message?: string } }> } = () => ({});

if (Platform.OS !== 'web') {
  try {
    const stripe = require('@stripe/stripe-react-native');
    CardField = stripe.CardField;
    useStripe = stripe.useStripe;
  } catch (e) {
    if (__DEV__) console.warn('Stripe CardField not available:', e);
  }
}

const CARD_FIELD_STYLE = {
  borderWidth: 1.5,
  borderRadius: BORDER_RADIUS.md,
  borderColor: 'rgba(148,163,184,0.35)',
  backgroundColor: colors.surfaceOverlay,
  textColor: '#F1F5F9',
  fontSize: 16,
  placeholderColor: 'rgba(255,255,255,0.4)',
  cursorColor: SKY,
};

export default function AddPaymentMethod() {
  const scrollPad = useOwnerScrollContentPadding(true);
  const stripe = useStripe();
  const [cardComplete, setCardComplete] = useState(false);
  const [cardholderName, setCardholderName] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleCardChange = useCallback((details: { complete: boolean }) => {
    setCardComplete(details.complete);
  }, []);

  const buildAddedCardFromToken = (token: { id: string; card: { brand: string; last4: string; expMonth: number; expYear: number } }) => {
    const card = token.card;
    const brand = (card.brand ?? 'Unknown').toLowerCase();
    let brandKey: 'visa' | 'mastercard' | 'amex' | 'other' = 'other';
    if (brand.includes('visa')) brandKey = 'visa';
    else if (brand.includes('master')) brandKey = 'mastercard';
    else if (brand.includes('amex')) brandKey = 'amex';
    let brandName = 'Card';
    if (brandKey === 'amex') brandName = 'Amex';
    else if (brandKey === 'visa') brandName = 'Visa';
    else if (brandKey === 'mastercard') brandName = 'Mastercard';
    return {
      id: token.id,
      type: 'card' as const,
      brand: brandKey,
      name: `${brandName} ending in ${card.last4}`,
      last4: card.last4,
      expiry: `${String(card.expMonth).padStart(2, '0')}/${String(card.expYear).slice(-2)}`,
      isDefault: false,
    };
  };

  const handleAddCard = async () => {
    if (!cardComplete) return;
    if (Platform.OS === 'web') {
      Alert.alert('Add card', 'Card entry is available in the mobile app. On web, add a card at checkout when you book a wash.');
      return;
    }
    if (!stripe?.createToken) {
      Alert.alert('Not available', 'Stripe is not initialised. Add a card when you book a wash.');
      return;
    }
    hapticFeedback('medium');
    setSubmitting(true);
    try {
      const { token, error } = await stripe.createToken({ type: 'Card' });
      if (error) {
        Alert.alert('Card error', error.message ?? 'Could not add card.');
        return;
      }
      if (!token?.id || !token?.card) {
        Alert.alert('Error', 'Could not read card details.');
        return;
      }
      const addedCard = buildAddedCardFromToken(token);
      const params = new URLSearchParams();
      params.set('addedCard', JSON.stringify(addedCard));
      router.replace(`/owner/settings/payment-methods?${params.toString()}`);
    } catch (e) {
      if (__DEV__) console.error('[AddPaymentMethod]', e);
      Alert.alert('Error', 'Something went wrong. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      <AppHeader
        title="Add card"
        subtitle="Enter your card details"
        variant="dashboard"
        accountType="customer"
        showBack
        fullWidth
        onBack={() => { hapticFeedback('light'); router.back(); }}
      />

      <KeyboardAvoidingView
        style={styles.keyboardView}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
      >
        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={[
            styles.scrollContent,
            scrollPad,
            { paddingHorizontal: CONTENT_PADDING_H },
          ]}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.cardSection}>
            <Text style={styles.sectionTitle}>Card details</Text>
            <Text style={styles.sectionSubtitle}>Your card number is never stored. Payments are secured by Stripe.</Text>

            {Platform.OS !== 'web' && CardField ? (
              <View style={styles.cardFieldWrap}>
                <CardField
                  style={styles.cardField}
                  cardStyle={CARD_FIELD_STYLE}
                  placeholders={{ number: '4242 4242 4242 4242', expiration: 'MM/YY', cvc: 'CVC' }}
                  postalCodeEnabled={false}
                  onCardChange={handleCardChange}
                />
              </View>
            ) : (
              <View style={styles.webPlaceholder}>
                <View style={{ opacity: 0.88 }}>
                  <GradientIconBox icon="card-outline" preset="sky" boxSize={56} size={28} borderRadius={16} elevated />
                </View>
                <Text style={styles.webPlaceholderText}>Card entry is available in the iOS and Android app.</Text>
                <Text style={styles.webPlaceholderSubtext}>You can add a card when you book a wash at checkout.</Text>
              </View>
            )}

            <View style={styles.inputRow}>
              <Text style={styles.label}>Cardholder name (optional)</Text>
              <TextInput
                style={styles.textInput}
                value={cardholderName}
                onChangeText={setCardholderName}
                placeholder="Name on card"
                placeholderTextColor="rgba(255,255,255,0.4)"
                autoCapitalize="words"
                autoCorrect={false}
              />
            </View>
          </View>

          <TouchableOpacity
            style={[
              styles.addButton,
              (!cardComplete || submitting) && styles.addButtonDisabled,
            ]}
            onPress={handleAddCard}
            disabled={!cardComplete || submitting}
            activeOpacity={0.85}
          >
            {submitting ? (
              <ActivityIndicator size="small" color="#0A1929" />
            ) : (
              <>
                <Ionicons name="add-circle" size={22} color={Platform.OS === 'web' ? '#94A3B8' : '#0A1929'} />
                <Text style={[styles.addButtonText, Platform.OS === 'web' && styles.addButtonTextDisabled]}>
                  Add card
                </Text>
              </>
            )}
          </TouchableOpacity>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  keyboardView: { flex: 1 },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 120 },
  cardSection: { marginBottom: 24 },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 17 : 18,
    fontWeight: '800',
    marginBottom: 6,
  },
  sectionSubtitle: {
    color: '#94A3B8',
    fontSize: 13,
    marginBottom: 16,
    lineHeight: 18,
  },
  cardFieldWrap: {
    marginBottom: 16,
    minHeight: 50,
  },
  cardField: {
    width: '100%',
    height: 50,
  },
  webPlaceholder: {
    padding: 24,
    borderRadius: BORDER_RADIUS.md,
    backgroundColor: colors.surfaceOverlay,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.25)',
    alignItems: 'center',
    gap: 10,
    marginBottom: 16,
  },
  webPlaceholderText: {
    color: '#F1F5F9',
    fontSize: 15,
    fontWeight: '600',
    textAlign: 'center',
  },
  webPlaceholderSubtext: {
    color: '#94A3B8',
    fontSize: 13,
    textAlign: 'center',
  },
  inputRow: { marginBottom: 8 },
  label: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 6,
  },
  textInput: {
    backgroundColor: colors.surfaceOverlay,
    borderRadius: BORDER_RADIUS.md,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.35)',
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 16,
    color: '#F1F5F9',
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    backgroundColor: SKY,
    paddingVertical: 16,
    borderRadius: BORDER_RADIUS.md,
    marginTop: 8,
  },
  addButtonDisabled: {
    backgroundColor: 'rgba(148,163,184,0.3)',
    opacity: 0.9,
  },
  addButtonText: {
    color: '#0A1929',
    fontSize: 17,
    fontWeight: '800',
  },
  addButtonTextDisabled: {
    color: '#64748B',
  },
});
