import React, { useEffect, useMemo, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  RefreshControl,
  Alert,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import AppHeader from '../../../src/components/shared/AppHeader';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { useOwnerScrollContentPadding } from '../../../src/hooks/useOwnerScrollContentPadding';
import { colors } from '../../../src/constants/colors';
import GradientIconBox from '../../../src/components/shared/GradientIconBox';
import QuickActionPageHero from '../../../src/components/shared/QuickActionPageHero';
import { accentToGradient } from '../../../src/utils/accentGradient';
import { BORDER_RADIUS, FONT_SIZES, SPACING } from '../../../src/constants/designTokens';
import {
  getLoyaltyBalance,
  redeemRewardPoints,
} from '../../../src/services/LoyaltyService';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;

type RewardType = 'discount' | 'boost' | 'unlock' | 'badge' | 'service' | 'perk';
type RewardTier = 'common' | 'rare' | 'epic' | 'legendary';

interface Reward {
  id: string;
  title: string;
  description: string;
  points: number;
  icon: string;
  type: RewardType;
  tier: RewardTier;
  available: boolean;
  unlocked?: boolean;
}

export default function Rewards() {
  const scrollPad = useOwnerScrollContentPadding(true);
  const { user, updateUser } = useAuth();

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [redeemingId, setRedeemingId] = useState<string | null>(null);

  const [completedCount, setCompletedCount] = useState(0);
  const [points, setPoints] = useState(0);
  const [progressToNext, setProgressToNext] = useState(0);

  const REWARD_TIERS = [1000, 2500, 5000] as const;

  const getNextMilestone = useCallback((pts: number) => {
    if (pts >= 5000) return null;
    const next = REWARD_TIERS.find(t => t > pts);
    return next ?? null;
  }, []);

  const getProgressToNext = useCallback((pts: number) => {
    const next = getNextMilestone(pts);
    if (!next) return 100;
    const prev = REWARD_TIERS[REWARD_TIERS.indexOf(next) - 1] ?? 0;
    const progress = Math.min(100, ((pts - prev) / (next - prev)) * 100);
    return Math.max(0, progress);
  }, [getNextMilestone]);

  const getNextMilestoneLabel = useCallback((pts: number) => {
    const next = getNextMilestone(pts);
    if (!next) return 'All rewards unlocked';
    if (next === 1000) return 'Next: 25% off washes (1,000 pts)';
    if (next === 2500) return 'Next: Free Basic Wash (2,500 pts)';
    return 'Next: Free Gold Wash (5,000 pts)';
  }, [getNextMilestone]);

  const rewards: Reward[] = useMemo(() => {
    const allRewards: Reward[] = [
      { id: 'reward-25', title: '25% off washes', description: 'Redeem for 25% off washes only', points: 1000, icon: 'pricetag', type: 'service', tier: 'rare', available: points >= 1000 },
      { id: 'reward-basic', title: 'Free Basic Wash', description: 'Complimentary basic wash', points: 2500, icon: 'car', type: 'service', tier: 'epic', available: points >= 2500 },
      { id: 'reward-gold', title: 'Free Gold Wash', description: 'Complimentary Gold wash', points: 5000, icon: 'diamond', type: 'service', tier: 'legendary', available: points >= 5000 },
    ];
    return allRewards.map(r => ({ ...r, available: points >= r.points }));
  }, [points]);

  const loadPoints = useCallback(async () => {
    if (!user?.id) {
      setCompletedCount(0);
      setPoints(0);
      setProgressToNext(0);
      setLoading(false);
      setRefreshing(false);
      return;
    }

    try {
      if (!refreshing) setLoading(true);
      const balance = await getLoyaltyBalance(user.id);
      setCompletedCount(balance.completedBookings);
      setPoints(balance.effectivePoints);
      setProgressToNext(getProgressToNext(balance.effectivePoints));
    } catch (e: any) {
      console.warn('[Rewards] Could not count completed bookings.', e);
      setCompletedCount(0);
      setPoints(0);
      setProgressToNext(0);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [user?.id, refreshing, getProgressToNext]);

  useEffect(() => {
    loadPoints();
  }, [loadPoints]);

  const onRefresh = () => {
    setRefreshing(true);
    loadPoints();
  };

  const getTierColor = (tier: RewardTier) => {
    switch (tier) {
      case 'legendary': return '#FFD700';
      case 'epic': return '#9D4EDD';
      case 'rare': return '#4A90E2';
      default: return SKY;
    }
  };

  const handleRedeem = (reward: Reward) => {
    if (!reward.available || !user?.id || redeemingId) return;
    Alert.alert(
      'Redeem Reward',
      `Unlock "${reward.title}" for ${reward.points} points?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Redeem',
          onPress: () => {
            void (async () => {
              try {
                setRedeemingId(reward.id);
                const nextBalance = await redeemRewardPoints(user.id, {
                  id: reward.id,
                  title: reward.title,
                  points: reward.points,
                });
                await updateUser({ tierPoints: nextBalance });
                setPoints(nextBalance);
                Alert.alert('Success!', `You've unlocked: ${reward.title}`);
              } catch (err: any) {
                Alert.alert('Redeem failed', err?.message ?? 'Unable to redeem this reward right now.');
              } finally {
                setRedeemingId(null);
              }
            })();
          },
        },
      ]
    );
  };

  const groupedRewards = useMemo(() => [['Wash rewards', rewards] as const], [rewards]);

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      <AppHeader
        title="Rewards"
        subtitle="Premium loyalty perks"
        showBack
        fullWidth
        onBack={() => { hapticFeedback('light'); router.back(); }}
        accountType="customer"
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, scrollPad]}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />}
      >
        <QuickActionPageHero
          icon="trophy"
          title="Loyalty rewards"
          subtitle="Earn points on completed washes and unlock premium perks at each milestone."
          accentColor="#10B981"
          iconColor={SKY}
        />
        {/* Points Card */}
        <View style={styles.pointsCard}>
          <BlurView intensity={35} tint="dark" style={styles.pointsBlur}>
            <LinearGradient
              colors={['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.03)']}
              style={StyleSheet.absoluteFill}
            />
            <View style={styles.pointsBorder} />
            <View style={styles.pointsContent}>
              <View style={styles.pointsHeader}>
                <View style={styles.pointsLeft}>
                  {loading ? (
                    <ActivityIndicator color={SKY} size="small" style={{ marginTop: 8 }} />
                  ) : (
                    <>
                      <Text style={styles.pointsValue}>{points.toLocaleString()}</Text>
                      <Text style={styles.pointsLabel}>Points</Text>
                    </>
                  )}
                </View>
                <View style={styles.pointsRight}>
                  <Ionicons name="gift" size={28} color={SKY} />
                </View>
              </View>
              {!loading && (
                <Text style={styles.earnRate}>50 points per booking ({completedCount} completed)</Text>
              )}
              {!loading && (
                <View style={styles.progressContainer}>
                  <View style={styles.progressBarBg}>
                    <LinearGradient
                      colors={[SKY, '#4A90E2']}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 1, y: 0 }}
                      style={[styles.progressBarFill, { width: `${progressToNext}%` }]}
                    />
                  </View>
                  <Text style={styles.progressText}>{getNextMilestoneLabel(points)}</Text>
                </View>
              )}
            </View>
          </BlurView>
        </View>

        {/* Disclaimer */}
        <View style={styles.disclaimer}>
          <Ionicons name="information-circle-outline" size={18} color="#9CA3AF" />
          <Text style={styles.disclaimerText}>Rewards do not apply to detailing services.</Text>
        </View>

        {/* Wash rewards */}
        {groupedRewards.map(([category, categoryRewards]) => (
          <View key={category} style={styles.rewardsSection}>
            <View style={styles.categoryHeader}>
              <Text style={styles.categoryTitle}>{category}</Text>
              <Text style={styles.categoryCount}>{categoryRewards.filter(r => r.available).length}/{categoryRewards.length}</Text>
            </View>
            
            <View style={styles.rewardsGrid}>
              {categoryRewards.map((reward) => {
                const tierColor = getTierColor(reward.tier);
                const isUnlocked = reward.available;
                
                return (
            <TouchableOpacity
              key={reward.id}
                    style={[
                      styles.rewardCard,
                      !isUnlocked && styles.rewardCardDisabled,
                      { borderColor: isUnlocked ? `${tierColor}40` : 'rgba(107,114,128,0.2)' },
                    ]}
                    disabled={!isUnlocked || redeemingId === reward.id}
              activeOpacity={0.8}
                    onPress={() => handleRedeem(reward)}
            >
              <BlurView intensity={30} tint="dark" style={styles.rewardBlur}>
                <LinearGradient
                        colors={isUnlocked 
                          ? ['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.03)']
                          : ['rgba(107,114,128,0.05)', 'rgba(107,114,128,0.02)']
                        }
                  style={StyleSheet.absoluteFill}
                />
                      
                      {/* Tier Indicator */}
                      {reward.tier !== 'common' && (
                        <View style={[styles.tierBadge, { backgroundColor: `${tierColor}20` }]}>
                          <Text style={[styles.tierText, { color: tierColor }]}>
                            {reward.tier.toUpperCase()}
                          </Text>
                        </View>
                      )}
                      
                      <View style={styles.rewardContent}>
                  <View style={styles.rewardIconWrapper}>
                    {isUnlocked ? (
                      <GradientIconBox
                        icon={reward.icon as keyof typeof Ionicons.glyphMap}
                        colors={accentToGradient(tierColor)}
                        boxSize={52}
                        size={28}
                        elevated
                      />
                    ) : (
                      <GradientIconBox
                        icon={reward.icon as keyof typeof Ionicons.glyphMap}
                        preset="gray"
                        boxSize={52}
                        size={28}
                        elevated
                      />
                    )}
                  </View>

                        <Text 
                          style={[
                            styles.rewardTitle, 
                            !isUnlocked && styles.rewardTitleDisabled,
                            { color: isUnlocked ? '#F9FAFB' : '#6B7280' }
                          ]}
                          numberOfLines={2}
                        >
                      {reward.title}
                    </Text>
                        
                        <Text style={[styles.rewardDescription, !isUnlocked && styles.rewardDescriptionDisabled]}>
                          {reward.description}
                        </Text>

                        <View style={styles.rewardFooter}>
                          <View style={styles.pointsBadge}>
                            <Ionicons name="star" size={12} color={isUnlocked ? tierColor : '#6B7280'} />
                            <Text style={[styles.rewardPoints, { color: isUnlocked ? tierColor : '#6B7280' }]}>
                              {reward.points}
                            </Text>
                  </View>

                          {isUnlocked ? (
                            <Ionicons name="checkmark-circle" size={18} color="#10B981" />
                  ) : (
                            <Ionicons name="lock-closed" size={18} color="#6B7280" />
                  )}
                        </View>
                </View>
              </BlurView>
            </TouchableOpacity>
                );
              })}
            </View>
          </View>
          ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 120, paddingHorizontal: isSmallScreen ? SPACING.md : SPACING.xl },
  
  // Compact Points Card
  pointsCard: {
    borderRadius: BORDER_RADIUS.md,
    overflow: 'hidden',
    marginBottom: SPACING.xl,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 4,
  },
  pointsBlur: {
    borderRadius: BORDER_RADIUS.md,
    overflow: 'hidden',
  },
  pointsBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  pointsContent: {
    padding: SPACING.lg,
  },
  pointsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  pointsLeft: {
    flex: 1,
  },
  pointsRight: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  levelBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    marginBottom: 8,
  },
  levelText: {
    fontSize: 11,
    fontWeight: '700',
    marginLeft: 4,
    textTransform: 'uppercase',
  },
  pointsValue: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? FONT_SIZES.xxxl : 34,
    fontWeight: '800',
    marginBottom: 2,
  },
  pointsLabel: {
    color: SKY,
    fontSize: 12,
    fontWeight: '600',
    opacity: 0.8,
  },
  earnRate: {
    color: '#9CA3AF',
    fontSize: 12,
    marginTop: 4,
  },
  disclaimer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
    paddingHorizontal: 4,
  },
  disclaimerText: {
    color: '#9CA3AF',
    fontSize: 13,
    flex: 1,
  },
  progressContainer: {
    marginTop: 4,
  },
  progressBarBg: {
    height: 6,
    backgroundColor: 'rgba(107,114,128,0.2)',
    borderRadius: 3,
    overflow: 'hidden',
    marginBottom: 6,
  },
  progressBarFill: {
    height: '100%',
    borderRadius: 3,
  },
  progressText: {
    color: '#87CEEB',
    fontSize: 11,
    fontWeight: '600',
    opacity: 0.8,
  },
  
  // Rewards Section
  rewardsSection: {
    marginBottom: 28,
  },
  categoryHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  categoryTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
  },
  categoryCount: {
    color: '#87CEEB',
    fontSize: 13,
    fontWeight: '600',
    backgroundColor: 'rgba(135,206,235,0.15)',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  rewardsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginHorizontal: -6,
  },
  rewardCard: {
    width: (width - (isSmallScreen ? 24 : 40) - 24) / 2,
    borderRadius: BORDER_RADIUS.sm + 2,
    overflow: 'hidden',
    margin: SPACING.sm - 2,
    borderWidth: 1.5,
    minHeight: 180,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.18,
    shadowRadius: 8,
    elevation: 3,
  },
  rewardCardDisabled: {
    opacity: 0.6,
  },
  rewardBlur: {
    borderRadius: 14,
    overflow: 'hidden',
    flex: 1,
  },
  tierBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 8,
    zIndex: 1,
  },
  tierText: {
    fontSize: 8,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  rewardContent: {
    padding: 12,
    flex: 1,
    justifyContent: 'space-between',
  },
  rewardIconWrapper: {
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
    alignSelf: 'center',
  },
  rewardTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 14 : 15,
    fontWeight: '700',
    marginBottom: 4,
    textAlign: 'center',
    minHeight: 36,
  },
  rewardTitleDisabled: {
    color: '#6B7280',
  },
  rewardDescription: {
    color: '#94A3B8',
    fontSize: 11,
    textAlign: 'center',
    marginBottom: 10,
    lineHeight: 14,
    minHeight: 28,
  },
  rewardDescriptionDisabled: {
    color: '#6B7280',
    opacity: 0.6,
  },
  rewardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 'auto',
  },
  pointsBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(135,206,235,0.1)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  rewardPoints: {
    fontSize: 12,
    fontWeight: '700',
    marginLeft: 4,
  },
});
