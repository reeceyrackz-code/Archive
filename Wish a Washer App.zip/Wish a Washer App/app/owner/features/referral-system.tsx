import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Share,
  Alert,
  ActivityIndicator,
  RefreshControl,
  TextInput,
  Clipboard,
  Platform,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import AppHeader from '../../../src/components/shared/AppHeader';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { useOwnerScrollContentPadding } from '../../../src/hooks/useOwnerScrollContentPadding';
import { colors } from '../../../src/constants/colors';
import QuickActionPageHero from '../../../src/components/shared/QuickActionPageHero';
import { BORDER_RADIUS, FONT_SIZES, SPACING } from '../../../src/constants/designTokens';
import {
  getReferralSummary,
  generateReferralCode,
  applyReferralCodeToUser,
} from '../../../src/services/LoyaltyService';
import {
  buildReferralJoinLink,
  buildReferralShareMessage,
} from '../../../src/utils/referralLinks';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const REWARD_PER_REFERRAL = 5;

// Referral tiers: Rookie → Rising Star → Champion → Ambassador → Legend
const REFERRAL_TIERS = [
  { name: 'Rookie', min: 0, icon: 'leaf', color: '#94A3B8' },
  { name: 'Rising Star', min: 1, icon: 'star', color: '#FCD34D' },
  { name: 'Champion', min: 3, icon: 'trophy', color: '#F59E0B' },
  { name: 'Ambassador', min: 7, icon: 'ribbon', color: '#8B5CF6' },
  { name: 'Legend', min: 10, icon: 'diamond', color: '#06B6D4' },
];

// Achievement milestones
const MILESTONES = [
  { id: 'first', count: 1, label: 'First Friend', icon: 'heart' },
  { id: 'squad', count: 3, label: 'Squad Builder', icon: 'people' },
  { id: 'influencer', count: 5, label: 'Influencer', icon: 'megaphone' },
  { id: 'ambassador', count: 7, label: 'Ambassador', icon: 'ribbon' },
  { id: 'legend', count: 10, label: 'Legend', icon: 'diamond' },
];

export default function ReferralSystem() {
  const params = useLocalSearchParams<{ enterCode?: string }>();
  const scrollPad = useOwnerScrollContentPadding(true);
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [referralCode, setReferralCode] = useState(user?.id ? generateReferralCode(user.id) : 'WAW-00000000');
  const [hasAppliedReferral, setHasAppliedReferral] = useState(false);
  const [entryCode, setEntryCode] = useState('');
  const [applyingEntryCode, setApplyingEntryCode] = useState(false);
  const [referrals, setReferrals] = useState<Array<{
    id: string;
    refereeName: string;
    createdAt: string;
    status: 'pending' | 'completed' | 'rewarded';
    rewardAmount: number;
  }>>([]);

  const rewardedReferralCount = useMemo(
    () => referrals.filter((referral) => referral.status === 'rewarded').length,
    [referrals],
  );
  const referralCount = referrals.length;
  const creditsEarned = rewardedReferralCount * REWARD_PER_REFERRAL;

  const { currentTier, nextTier, progressToNext, isMaxTier } = useMemo(() => {
    const tiers = [...REFERRAL_TIERS].reverse();
    const current = tiers.find((t) => rewardedReferralCount >= t.min) ?? REFERRAL_TIERS[0];
    const next = REFERRAL_TIERS[REFERRAL_TIERS.indexOf(current) + 1];
    const isMax = !next;
    let progress: number;
    if (isMax) progress = 100;
    else if (next) progress = Math.min(100, ((rewardedReferralCount - current.min) / (next.min - current.min)) * 100);
    else progress = 0;
    return {
      currentTier: current,
      nextTier: next ?? null,
      progressToNext: progress,
      isMaxTier: isMax,
    };
  }, [rewardedReferralCount]);

  const nextMilestone = useMemo(
    () => MILESTONES.find((m) => rewardedReferralCount < m.count),
    [rewardedReferralCount]
  );
  const referralsToNext = nextMilestone ? nextMilestone.count - rewardedReferralCount : 0;

  const loadReferrals = useCallback(async () => {
    if (!user?.id) {
      setReferrals([]);
      setLoading(false);
      setRefreshing(false);
      setReferralCode('WAW-00000000');
      setHasAppliedReferral(false);
      return;
    }

    try {
      if (!refreshing) setLoading(true);
      const summary = await getReferralSummary(user.id);
      setReferralCode(summary.referralCode);
      setHasAppliedReferral(summary.referredBy);
      setReferrals(
        summary.referrals.map((row) => ({
          id: row.id,
          refereeName: row.refereeName,
          createdAt: row.createdAt,
          status: row.status,
          rewardAmount: row.rewardAmount,
        })),
      );
    } catch (err) {
      console.warn('[Referral] load failed:', err);
      setReferrals([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [refreshing, user?.id]);

  useEffect(() => {
    void loadReferrals();
  }, [loadReferrals]);

  useEffect(() => {
    const incoming = typeof params.enterCode === 'string' ? params.enterCode.trim().toUpperCase() : '';
    if (incoming) setEntryCode(incoming);
  }, [params.enterCode]);

  const onRefresh = () => {
    setRefreshing(true);
    void loadReferrals();
  };

  const handleShare = async () => {
    try {
      const message = buildReferralShareMessage(referralCode);
      const link = buildReferralJoinLink(referralCode);
      await Share.share(
        Platform.OS === 'ios'
          ? { message, url: link }
          : { message, title: 'Join Wish a Wash' },
      );
    } catch (err) {
      console.warn('[Referral] Share failed:', err);
      Alert.alert('Error', 'Unable to share referral code');
    }
  };

  const handleCopy = () => {
    const link = buildReferralJoinLink(referralCode);
    Clipboard.setString(`${referralCode}\n${link}`);
    hapticFeedback('light');
    Alert.alert('Copied', 'Your referral code and invite link are on the clipboard.');
  };

  const handleApplyEntryCode = async () => {
    if (!user?.id) {
      router.push({ pathname: '/auth/signup', params: { referralCode: entryCode.trim() } });
      return;
    }
    const normalized = entryCode.trim().toUpperCase();
    if (!normalized) {
      Alert.alert('Enter a code', 'Paste or type your friend\'s referral code.');
      return;
    }
    if (normalized === referralCode.trim().toUpperCase()) {
      Alert.alert('That\'s your code', 'Enter a friend\'s referral code, not your own.');
      return;
    }
    if (hasAppliedReferral) {
      Alert.alert('Already applied', 'You\'ve already used a referral code on this account.');
      return;
    }

    try {
      setApplyingEntryCode(true);
      await hapticFeedback('light');
      const applied = await applyReferralCodeToUser(user.id, normalized);
      if (applied) {
        setHasAppliedReferral(true);
        setEntryCode('');
        Alert.alert('Code applied', 'Your referral code is saved. Complete your first booking to unlock rewards.');
        void loadReferrals();
      } else {
        Alert.alert('Invalid code', 'We couldn\'t find that referral code. Check it and try again.');
      }
    } catch (err) {
      console.warn('[Referral] apply entry failed:', err);
      Alert.alert('Error', 'Unable to apply referral code right now.');
    } finally {
      setApplyingEntryCode(false);
    }
  };

  const referralLink = buildReferralJoinLink(referralCode);

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      <AppHeader
        title="Referrals"
        subtitle="Invite friends, unlock premium perks"
        showBack
        fullWidth
        onBack={() => { hapticFeedback('light'); router.back(); }}
        accountType="customer"
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, scrollPad]}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />}
      >
        <QuickActionPageHero
          icon="people-circle"
          title="Share Wish a Wash"
          subtitle="Invite friends with your code. They save on a first booking — you unlock tiers and credits as referrals complete."
          accentColor="#F59E0B"
          iconColor={SKY}
        />
        {/* Level & Stats Card */}
        <View style={styles.levelCard}>
          <BlurView intensity={35} tint="dark" style={styles.levelBlur}>
            <LinearGradient
              colors={['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.03)']}
              style={StyleSheet.absoluteFill}
            />
            <View style={styles.levelBorder} />
            <View style={styles.levelContent}>
              <View style={styles.levelHeader}>
                <View style={[styles.tierBadge, { backgroundColor: `${currentTier.color}25` }]}>
                  <Ionicons name={currentTier.icon as any} size={20} color={currentTier.color} />
                  <Text style={[styles.tierText, { color: currentTier.color }]}>{currentTier.name}</Text>
                </View>
                <View style={styles.statsRow}>
                  <View style={styles.statPill}>
                    <Ionicons name="people" size={16} color={SKY} />
                    <Text style={styles.statValue}>{referralCount}</Text>
                    <Text style={styles.statLabel}>Friends</Text>
                  </View>
                  <View style={styles.statPill}>
                    <Ionicons name="wallet" size={16} color="#10B981" />
                    <Text style={[styles.statValue, { color: '#10B981' }]}>£{creditsEarned}</Text>
                    <Text style={styles.statLabel}>Earned</Text>
                  </View>
                </View>
              </View>
              {!isMaxTier && nextTier && (
                <View style={styles.progressContainer}>
                  <View style={styles.progressBarBg}>
                    <LinearGradient
                      colors={[currentTier.color, nextTier.color]}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 1, y: 0 }}
                      style={[styles.progressBarFill, { width: `${progressToNext}%` }]}
                    />
                  </View>
                  <Text style={styles.progressLabel}>
                    {rewardedReferralCount} / {nextTier.min} → {nextTier.name}
                  </Text>
                </View>
              )}
              {isMaxTier && (
                <View style={styles.maxTierBadge}>
                  <Ionicons name="ribbon" size={14} color={currentTier.color} />
                  <Text style={[styles.maxTierText, { color: currentTier.color }]}>Max tier unlocked!</Text>
                </View>
              )}
            </View>
          </BlurView>
        </View>

        {/* Referral Code Card */}
        <View style={styles.codeCard}>
          <BlurView intensity={35} tint="dark" style={styles.codeBlur}>
            <LinearGradient
              colors={['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.03)']}
              style={StyleSheet.absoluteFill}
            />
            <View style={styles.codeBorder} />
            <View style={styles.codeGradient}>
              <View style={[styles.codeIconWrapper, { backgroundColor: `${currentTier.color}25` }]}>
                <Ionicons name="gift" size={32} color={currentTier.color} />
              </View>
              <Text style={styles.codeLabel}>Your Referral Code</Text>
              <View style={styles.codeContainer}>
                <Text style={styles.codeText}>{referralCode}</Text>
              </View>
              <View style={styles.codeActions}>
                <TouchableOpacity style={styles.codeButton} onPress={handleCopy}>
                  <Ionicons name="copy" size={18} color={SKY} />
                  <Text style={styles.codeButtonText}>Copy link</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.codeButton, styles.shareButton]} onPress={handleShare}>
                  <Ionicons name="share-social" size={18} color="#fff" />
                  <Text style={[styles.codeButtonText, { color: '#fff' }]}>Share & Earn</Text>
                </TouchableOpacity>
              </View>
              <Text style={styles.inviteLinkText} numberOfLines={2}>
                {referralLink}
              </Text>
            </View>
          </BlurView>
        </View>

        {/* Enter a friend's referral code */}
        <View style={styles.entryCard}>
          <BlurView intensity={35} tint="dark" style={styles.entryBlur}>
            <LinearGradient
              colors={['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.03)']}
              style={StyleSheet.absoluteFill}
            />
            <View style={styles.entryBorder} />
            <View style={styles.entryContent}>
              <Text style={styles.entryTitle}>Have a friend&apos;s code?</Text>
              <Text style={styles.entrySubtitle}>
                Enter their referral code to get £5 off your first booking.
              </Text>
              {hasAppliedReferral ? (
                <View style={styles.entryAppliedPill}>
                  <Ionicons name="checkmark-circle" size={18} color="#10B981" />
                  <Text style={styles.entryAppliedText}>Referral code already applied</Text>
                </View>
              ) : (
                <View style={styles.entryRow}>
                  <TextInput
                    style={styles.entryInput}
                    placeholder="WAW-XXXXXXXX"
                    placeholderTextColor="rgba(255,255,255,0.45)"
                    value={entryCode}
                    onChangeText={(v) => setEntryCode(v.toUpperCase())}
                    autoCapitalize="characters"
                    autoCorrect={false}
                    editable={!applyingEntryCode}
                    accessibilityLabel="Friend referral code"
                  />
                  <TouchableOpacity
                    style={[styles.entryApplyButton, applyingEntryCode && styles.entryApplyButtonDisabled]}
                    onPress={() => void handleApplyEntryCode()}
                    disabled={applyingEntryCode}
                    activeOpacity={0.85}
                  >
                    {applyingEntryCode ? (
                      <ActivityIndicator size="small" color="#fff" />
                    ) : (
                      <Text style={styles.entryApplyText}>Apply</Text>
                    )}
                  </TouchableOpacity>
                </View>
              )}
            </View>
          </BlurView>
        </View>

        {/* Next Milestone Callout */}
        {nextMilestone && (
          <View style={styles.milestoneCard}>
            <BlurView intensity={25} tint="dark" style={styles.milestoneBlur}>
              <LinearGradient
                colors={['rgba(139,92,246,0.15)', 'rgba(6,182,212,0.08)']}
                style={StyleSheet.absoluteFill}
              />
              <View style={styles.milestoneContent}>
                <View style={styles.milestoneIconWrapper}>
                  <Ionicons name={nextMilestone.icon as any} size={24} color="#8B5CF6" />
                </View>
                <View style={styles.milestoneTextWrapper}>
                  <Text style={styles.milestoneTitle}>Next unlock: {nextMilestone.label}</Text>
                  <Text style={styles.milestoneSubtext}>
                    {referralsToNext} more referral{referralsToNext === 1 ? '' : 's'} to unlock this badge!
                  </Text>
                </View>
              </View>
            </BlurView>
          </View>
        )}

        {/* Achievement Badges */}
        <View style={styles.achievementsSection}>
          <Text style={styles.sectionTitle}>Achievements</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.achievementsRow}>
            {MILESTONES.map((m) => {
              const unlocked = referralCount >= m.count;
              return (
                <View
                  key={m.id}
                  style={[
                    styles.achievementBadge,
                    unlocked ? styles.achievementUnlocked : styles.achievementLocked,
                  ]}
                >
                  <View
                    style={[
                      styles.achievementIcon,
                      unlocked ? { backgroundColor: `${SKY}25`, borderColor: `${SKY}50` } : { backgroundColor: 'rgba(107,114,128,0.08)', borderColor: 'rgba(107,114,128,0.25)' },
                    ]}
                  >
                    <Ionicons
                      name={unlocked ? (m.icon as any) : 'lock-closed'}
                      size={22}
                      color={unlocked ? SKY : '#6B7280'}
                    />
                  </View>
                  <Text style={[styles.achievementLabel, !unlocked && styles.achievementLabelLocked]}>
                    {m.label}
                  </Text>
                  <Text style={styles.achievementCount}>{m.count}</Text>
                </View>
              );
            })}
          </ScrollView>
        </View>

        {/* How it Works */}
        <View style={styles.infoCard}>
          <BlurView intensity={30} tint="dark" style={styles.infoBlur}>
            <LinearGradient
              colors={['rgba(255,255,255,0.06)', 'rgba(255,255,255,0.02)']}
              style={StyleSheet.absoluteFill}
            />
            <View style={styles.infoBorder} />
            <View style={styles.infoContentWrapper}>
              <View style={styles.infoIconWrapper}>
                <Ionicons name="sparkles" size={24} color={SKY} />
              </View>
              <View style={styles.infoContent}>
                <Text style={styles.infoTitle}>How it Works</Text>
                <Text style={styles.infoText}>
                  Share your invite link with friends. When they sign up and complete their first booking, you both get £5 credit! Friends can tap the link to open the app and apply your code automatically.
                </Text>
              </View>
            </View>
          </BlurView>
        </View>

        {/* Referrals List */}
        <View style={styles.referralsSection}>
          <Text style={styles.sectionTitle}>Your Squad ({referrals.length})</Text>
          {loading ? (
            <View style={styles.emptyContainer}>
              <ActivityIndicator size="small" color={SKY} />
              <Text style={styles.emptyText}>Loading referrals...</Text>
            </View>
          ) : referrals.length === 0 ? (
            <View style={styles.emptyContainer}>
              <View style={styles.emptyIconRing}>
                <Ionicons name="rocket" size={40} color={SKY} />
              </View>
              <Text style={styles.emptyText}>Your first referral = £5!</Text>
              <Text style={styles.emptySubtext}>
                Share your code to level up from Rookie and unlock the First Friend badge
              </Text>
              <TouchableOpacity style={styles.emptyCta} onPress={handleShare}>
                <Ionicons name="share-social" size={18} color="#fff" />
                <Text style={styles.emptyCtaText}>Share Now</Text>
              </TouchableOpacity>
            </View>
          ) : (
            referrals.map((referral) => (
              <View key={referral.id} style={styles.referralCard}>
                <BlurView intensity={30} tint="dark" style={styles.referralBlur}>
                  <LinearGradient
                    colors={['rgba(255,255,255,0.06)', 'rgba(255,255,255,0.02)']}
                    style={StyleSheet.absoluteFill}
                  />
                  <View style={styles.referralBorder} />
                  <View style={styles.referralContentWrapper}>
                    <View style={styles.referralIconWrapper}>
                      <Ionicons name="person" size={20} color={SKY} />
                    </View>
                    <View style={styles.referralContent}>
                      <Text style={styles.referralName}>{referral.refereeName}</Text>
                      <Text style={styles.referralDate}>{new Date(referral.createdAt).toLocaleDateString()}</Text>
                    </View>
                    <View
                      style={[
                        styles.rewardBadge,
                        referral.status === 'rewarded'
                          ? styles.rewardBadgeRewarded
                          : styles.rewardBadgePending,
                      ]}
                    >
                      <Text style={styles.rewardText}>
                        {referral.status === 'rewarded'
                          ? `+£${referral.rewardAmount}`
                          : referral.status === 'completed'
                            ? 'Pending payout'
                            : 'Pending'}
                      </Text>
                    </View>
                  </View>
                </BlurView>
              </View>
            ))
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 120, paddingHorizontal: isSmallScreen ? SPACING.md : SPACING.xl },
  // Level & tier card
  levelCard: {
    borderRadius: BORDER_RADIUS.lg,
    overflow: 'hidden',
    marginBottom: SPACING.lg,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 4,
  },
  levelBlur: { borderRadius: 20, overflow: 'hidden' },
  levelBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  levelContent: { padding: SPACING.xl },
  levelHeader: { marginBottom: SPACING.md },
  tierBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 14,
    marginBottom: 14,
  },
  tierText: { fontSize: FONT_SIZES.md, fontWeight: '800', marginLeft: 6, textTransform: 'uppercase', letterSpacing: 0.5 },
  statsRow: { flexDirection: 'row', gap: 16 },
  statPill: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 12,
    gap: 8,
  },
  statValue: { color: '#F9FAFB', fontSize: 18, fontWeight: '800' },
  statLabel: { color: '#94A3B8', fontSize: 11, fontWeight: '600' },
  progressContainer: { marginTop: 4 },
  progressBarBg: {
    height: 8,
    backgroundColor: 'rgba(107,114,128,0.2)',
    borderRadius: 4,
    overflow: 'hidden',
    marginBottom: 6,
  },
  progressBarFill: { height: '100%', borderRadius: 4 },
  progressLabel: { color: '#87CEEB', fontSize: 11, fontWeight: '600', opacity: 0.9 },
  maxTierBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    marginTop: 8,
    gap: 6,
  },
  maxTierText: { fontSize: 12, fontWeight: '700' },
  // Milestone callout
  milestoneCard: {
    borderRadius: 14,
    overflow: 'hidden',
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.3)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.18,
    shadowRadius: 9,
    elevation: 3,
  },
  milestoneBlur: { borderRadius: 14, overflow: 'hidden' },
  milestoneContent: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  milestoneIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 14,
    backgroundColor: 'rgba(139,92,246,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 14,
  },
  milestoneTextWrapper: { flex: 1 },
  milestoneTitle: { color: '#F9FAFB', fontSize: 15, fontWeight: '700', marginBottom: 4 },
  milestoneSubtext: { color: '#A78BFA', fontSize: 12, fontWeight: '500' },
  // Achievements
  achievementsSection: { marginBottom: 20 },
  achievementsRow: {
    flexDirection: 'row',
    gap: 12,
    paddingVertical: 4,
  },
  achievementBadge: {
    alignItems: 'center',
    minWidth: 80,
  },
  achievementUnlocked: {},
  achievementLocked: { opacity: 0.5 },
  achievementIcon: {
    width: 48,
    height: 48,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
    borderWidth: 2,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  achievementLabel: {
    color: '#F9FAFB',
    fontSize: 11,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 2,
  },
  achievementLabelLocked: { color: '#6B7280' },
  achievementCount: {
    color: '#87CEEB',
    fontSize: 10,
    fontWeight: '700',
  },
  codeCard: {
    borderRadius: 20,
    overflow: 'hidden',
    marginBottom: 24,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 4,
  },
  codeBlur: {
    borderRadius: 20,
    overflow: 'hidden',
  },
  codeBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  codeGradient: {
    padding: 24,
    alignItems: 'center',
  },
  codeIconWrapper: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  codeLabel: {
    color: '#87CEEB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 12,
  },
  codeContainer: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  codeText: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 24,
    fontWeight: '800',
    letterSpacing: 2,
  },
  codeActions: {
    flexDirection: 'row',
    gap: 12,
  },
  codeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(135,206,235,0.25)',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 12,
    gap: 6,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  codeButtonText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
  },
  shareButton: {
    backgroundColor: SKY,
    borderColor: SKY,
  },
  inviteLinkText: {
    marginTop: 14,
    color: 'rgba(135,206,235,0.85)',
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
    lineHeight: 18,
    paddingHorizontal: 8,
  },
  entryCard: {
    borderRadius: 20,
    overflow: 'hidden',
    marginBottom: 24,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  entryBlur: { borderRadius: 20, overflow: 'hidden' },
  entryBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  entryContent: { padding: 20 },
  entryTitle: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 6,
  },
  entrySubtitle: {
    color: '#94A3B8',
    fontSize: 13,
    lineHeight: 18,
    marginBottom: 14,
  },
  entryRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  entryInput: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.35)',
    paddingHorizontal: 14,
    paddingVertical: Platform.OS === 'ios' ? 14 : 10,
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 1,
  },
  entryApplyButton: {
    backgroundColor: SKY,
    borderRadius: 12,
    paddingHorizontal: 18,
    paddingVertical: 14,
    minWidth: 88,
    alignItems: 'center',
    justifyContent: 'center',
  },
  entryApplyButtonDisabled: { opacity: 0.7 },
  entryApplyText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '800',
  },
  entryAppliedPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(16,185,129,0.12)',
    borderColor: 'rgba(16,185,129,0.35)',
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
  },
  entryAppliedText: {
    color: '#10B981',
    fontSize: 13,
    fontWeight: '700',
  },
  infoCard: {
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 24,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  infoBlur: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  infoBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  infoContentWrapper: {
    flexDirection: 'row',
    padding: 16,
  },
  infoIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  infoContent: {
    flex: 1,
  },
  infoTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 17,
    fontWeight: '700',
    marginBottom: 6,
  },
  infoText: {
    color: '#87CEEB',
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '500',
  },
  referralsSection: {
    marginBottom: 24,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: 36,
  },
  emptyIconRing: {
    width: 88,
    height: 88,
    borderRadius: 44,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    borderWidth: 2,
    borderColor: 'rgba(135,206,235,0.35)',
  },
  emptyText: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 8,
    textAlign: 'center',
  },
  emptySubtext: {
    color: '#87CEEB',
    fontSize: 14,
    textAlign: 'center',
    paddingHorizontal: 24,
    lineHeight: 20,
    marginBottom: 20,
  },
  emptyCta: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: SKY,
    paddingVertical: 14,
    paddingHorizontal: 28,
    borderRadius: 14,
    gap: 10,
  },
  emptyCtaText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
  referralCard: {
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  referralBlur: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  referralBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  referralContentWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  referralIconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 10,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  referralContent: {
    flex: 1,
  },
  referralName: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 15 : 16,
    fontWeight: '700',
    marginBottom: 4,
  },
  referralDate: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '600',
  },
  rewardBadge: {
    backgroundColor: 'rgba(135,206,235,0.15)',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  rewardBadgeRewarded: {
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderColor: 'rgba(16,185,129,0.35)',
  },
  rewardBadgePending: {
    backgroundColor: 'rgba(245,158,11,0.14)',
    borderColor: 'rgba(245,158,11,0.3)',
  },
  rewardText: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '700',
  },
});
