import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Animated,
  KeyboardAvoidingView,
  Platform,
  Alert,
  ScrollView,
  StatusBar,
  Image,
  Modal,
  Pressable,
  Linking,
} from 'react-native';
import { Video, ResizeMode, AVPlaybackStatus } from 'expo-av';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { colors } from '../../src/constants/colors';
import { WWPrimaryButton, WWSheetCloseButton } from '../../src/components/ui';
import * as AppleAuthentication from 'expo-apple-authentication';
import { AUTH_PAGES_VIDEO, NEW_AUTH_LOGO } from '../../assets/assetExports';
import {
  sharedAuthStyleDefs,
  AUTH_GRADIENT_COLORS,
  AUTH_CONTENT_OVERLAY_COLORS,
} from '../../src/constants/authStyles';

const TERMS_URL = 'https://wishawash.com/terms';
const PRIVACY_URL = 'https://wishawash.com/privacy';

export default function SignupScreen() {
  const params = useLocalSearchParams<{ referralCode?: string; code?: string }>();
  const { register, registerWithApple } = useAuth();

  const USER_TYPE = 'customer' as const;

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    referralCode: '',
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isAppleAvailable, setIsAppleAvailable] = useState(false);
  const [emailModalVisible, setEmailModalVisible] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const videoOpacity = useRef(new Animated.Value(0)).current;
  const logoGlow = useRef(new Animated.Value(0.94)).current;
  const buttonScale = useRef(new Animated.Value(1)).current;
  const videoRef = useRef<Video>(null);

  useEffect(() => {
    const incoming =
      (typeof params.referralCode === 'string' && params.referralCode.trim()) ||
      (typeof params.code === 'string' && params.code.trim()) ||
      '';
    if (!incoming) return;
    setFormData((prev) => ({
      ...prev,
      referralCode: incoming.trim().toUpperCase(),
    }));
  }, [params.referralCode, params.code]);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const available =
          Platform.OS === 'ios' && (await AppleAuthentication.isAvailableAsync());
        setIsAppleAvailable(Boolean(available));
      } catch {
        setIsAppleAvailable(false);
      }
    })();
  }, []);

  useEffect(() => {
    const pulse = Animated.loop(
      Animated.sequence([
        Animated.timing(logoGlow, {
          toValue: 1,
          duration: 2800,
          useNativeDriver: true,
        }),
        Animated.timing(logoGlow, {
          toValue: 0.88,
          duration: 2800,
          useNativeDriver: true,
        }),
      ])
    );
    pulse.start();
    return () => pulse.stop();
  }, [logoGlow]);

  const handlePlaybackStatusUpdate = (status: AVPlaybackStatus) => {
    if (!status.isLoaded || !videoRef.current) return;
    if (status.didJustFinish) {
      videoRef.current.setPositionAsync(0).then(() => videoRef.current?.playAsync()).catch(() => {});
      return;
    }
    if (status.durationMillis != null && status.positionMillis != null) {
      const remaining = status.durationMillis - status.positionMillis;
      if (remaining < 500 && remaining > 0) {
        videoRef.current.setPositionAsync(0).then(() => videoRef.current?.playAsync()).catch(() => {});
      }
    }
  };

  const handleVideoLoad = () => {
    Animated.timing(videoOpacity, {
      toValue: 1,
      duration: 700,
      useNativeDriver: true,
    }).start();
  };

  const handlePressIn = () => {
    Animated.spring(buttonScale, {
      toValue: 0.98,
      useNativeDriver: true,
      speed: 50,
    }).start();
  };
  const handlePressOut = () => {
    Animated.spring(buttonScale, {
      toValue: 1,
      useNativeDriver: true,
      speed: 50,
    }).start();
  };

  const updateFormData = (field: keyof typeof formData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    setError(null);
  };

  const validateForm = () => {
    if (!formData.name || !formData.email || !formData.password) {
      setError('Please fill in all required fields');
      return false;
    }
    if (!formData.email.includes('@')) {
      setError('Please enter a valid email address');
      return false;
    }
    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters');
      return false;
    }
    return true;
  };

  const handleSignup = async () => {
    if (!validateForm()) return;

    await hapticFeedback('medium');
    setIsLoading(true);
    setError(null);

    try {
      const referralCode = formData.referralCode.trim();
      const signupPayload: Parameters<typeof register>[0] = {
        email: formData.email,
        name: formData.name,
        isVerified: false,
        verificationType: 'none',
        totalWashes: 0,
        tier: 'bronze',
        tierPoints: 0,
        password: formData.password,
        userType: USER_TYPE,
      };
      if (referralCode) signupPayload.referralCode = referralCode;

      const success = await register(signupPayload);

      if (success) {
        setEmailModalVisible(false);
        Alert.alert('Success!', 'Account created! Please verify your email.', [
          { text: 'OK', onPress: () => router.replace('/auth/login') },
        ]);
      } else {
        setError('Failed to create account. Please try again.');
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to create account. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAppleSignup = async () => {
    try {
      await hapticFeedback('light');

      const cred = await AppleAuthentication.signInAsync({
        requestedScopes: [
          AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
          AppleAuthentication.AppleAuthenticationScope.EMAIL,
        ],
      });

      const referralCode = formData.referralCode.trim();
      type AppleSeed = NonNullable<Parameters<typeof registerWithApple>[1]>;
      const appleSeed: AppleSeed = {
        userType: USER_TYPE,
      };
      if (referralCode) appleSeed.referralCode = referralCode;

      const ok = await registerWithApple(cred, appleSeed);
      if (!ok) return;

      router.replace('/auth/login');
    } catch (error: any) {
      if (error?.code !== 'ERR_CANCELED') {
        Alert.alert('Apple Sign Up Failed', 'Please try again.');
      }
    }
  };

  const handleGoogleSignup = () => {
    hapticFeedback('light');
    Alert.alert('Coming soon', 'Sign in with Google coming soon.');
  };

  const openEmailModal = () => {
    hapticFeedback('light');
    setEmailModalVisible(true);
  };

  const openLink = (url: string) => {
    Linking.openURL(url).catch(() => {});
  };

  return (
    <View style={styles.root}>
      <StatusBar translucent backgroundColor="transparent" barStyle="light-content" />

      <TouchableOpacity
        style={styles.topRightLink}
        onPress={() => router.replace('/auth/login')}
        activeOpacity={0.8}
      >
        <Text style={styles.topRightLinkText}>Sign in</Text>
      </TouchableOpacity>

      <Animated.View style={[StyleSheet.absoluteFill, { opacity: videoOpacity }]}>
        <Video
          ref={videoRef}
          source={AUTH_PAGES_VIDEO}
          style={styles.videoBackground}
          resizeMode={ResizeMode.COVER}
          shouldPlay
          isLooping={true}
          isMuted
          progressUpdateIntervalMillis={30}
          onPlaybackStatusUpdate={handlePlaybackStatusUpdate}
          onLoad={handleVideoLoad}
        />
      </Animated.View>
      <View style={StyleSheet.absoluteFill} pointerEvents="none">
        <LinearGradient
          colors={[...AUTH_GRADIENT_COLORS]}
          style={StyleSheet.absoluteFill}
        />
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <Animated.View
            style={[
              styles.contentContainer,
              { opacity: fadeAnim, transform: [{ translateY: slideAnim }] },
            ]}
          >
            <View style={styles.logoContainer}>
              <Animated.View style={{ opacity: logoGlow }}>
                <Image
                  source={NEW_AUTH_LOGO}
                  style={styles.signupHeroLogo}
                  resizeMode="contain"
                />
              </Animated.View>
              <Text style={styles.headline}>Create your account</Text>
              <Text style={styles.subtext}>Join Wish-a-Wash for premium car care in minutes.</Text>
            </View>

            <View style={styles.contentOverlayWrapper}>
              <View style={StyleSheet.absoluteFill} pointerEvents="none">
                <LinearGradient
                  colors={[...AUTH_CONTENT_OVERLAY_COLORS]}
                  style={StyleSheet.absoluteFill}
                />
              </View>
              <BlurView intensity={Platform.OS === 'ios' ? 40 : 24} tint="dark" style={styles.glassCard}>
                <TouchableOpacity
                  style={styles.emailCtaButton}
                  onPress={openEmailModal}
                  onPressIn={handlePressIn}
                  onPressOut={handlePressOut}
                  activeOpacity={1}
                >
                  <Animated.View style={{ transform: [{ scale: buttonScale }] }}>
                    <Ionicons name="mail-outline" size={22} color="rgba(255,255,255,0.95)" />
                  </Animated.View>
                  <Text style={styles.emailCtaButtonText}>Continue with Email</Text>
                </TouchableOpacity>

                <View style={styles.dividerContainer}>
                  <View style={styles.dividerLine} />
                  <Text style={styles.dividerText}>or continue with</Text>
                  <View style={styles.dividerLine} />
                </View>

                <View style={styles.socialIconRow}>
                  {isAppleAvailable && (
                    <TouchableOpacity
                      style={[styles.socialIconButton, styles.socialIconApple]}
                      onPress={handleAppleSignup}
                      onPressIn={handlePressIn}
                      onPressOut={handlePressOut}
                      activeOpacity={0.9}
                      accessibilityLabel="Continue with Apple"
                    >
                      <Ionicons name="logo-apple" size={24} color="#000000" />
                    </TouchableOpacity>
                  )}
                  <TouchableOpacity
                    style={[
                      styles.socialIconButton,
                      styles.socialIconGoogle,
                      { backgroundColor: 'rgba(255,255,255,0.18)', borderColor: 'rgba(255,255,255,0.18)', opacity: 0.72 },
                    ]}
                    onPress={handleGoogleSignup}
                    onPressIn={handlePressIn}
                    onPressOut={handlePressOut}
                    activeOpacity={0.9}
                    accessibilityLabel="Continue with Google"
                  >
                    <Ionicons name="logo-google" size={22} color="rgba(255,255,255,0.55)" />
                  </TouchableOpacity>
                </View>
              </BlurView>
            </View>

            <View style={styles.trustCopy}>
              <Text style={styles.trustCopyText}>
                By continuing, you agree to{' '}
                <Text style={styles.trustCopyLink} onPress={() => openLink(TERMS_URL)}>
                  Terms
                </Text>
                {' & '}
                <Text style={styles.trustCopyLink} onPress={() => openLink(PRIVACY_URL)}>
                  Privacy Policy
                </Text>
              </Text>
            </View>

            <View style={styles.signupCtaRow}>
              <Text style={styles.signupCtaText}>Already have an account? </Text>
              <TouchableOpacity onPress={() => router.replace('/auth/login')} activeOpacity={0.8}>
                <Text style={[styles.signupCtaText, styles.signupCtaLink]}>Sign in</Text>
              </TouchableOpacity>
            </View>
          </Animated.View>
        </ScrollView>
      </KeyboardAvoidingView>

      <Modal
        visible={emailModalVisible}
        animationType="slide"
        transparent
        onRequestClose={() => setEmailModalVisible(false)}
      >
        <Pressable
          style={styles.modalOverlay}
          onPress={() => setEmailModalVisible(false)}
        >
          <KeyboardAvoidingView
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
            style={styles.modalKeyboardAvoid}
          >
            <Pressable style={styles.modalContent} onPress={(e) => e.stopPropagation()}>
              <BlurView intensity={60} tint="dark" style={styles.modalBlur}>
                <ScrollView
                  style={styles.modalScroll}
                  contentContainerStyle={styles.modalScrollContent}
                  keyboardShouldPersistTaps="handled"
                  showsVerticalScrollIndicator={false}
                >
                  <View style={styles.modalInner}>
                    <View style={styles.modalHeader}>
                      <Text style={styles.modalTitle}>Create account with email</Text>
                      <WWSheetCloseButton
                        size={40}
                        iconSize={28}
                        iconColor="rgba(255,255,255,0.9)"
                        hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
                        onPress={() => setEmailModalVisible(false)}
                        accessibilityLabel="Close"
                      />
                    </View>

                        <View style={styles.inputWrapper}>
                      <View style={styles.inputIconContainer}>
                        <Ionicons name="person-outline" size={20} color="rgba(255,255,255,0.7)" />
                      </View>
                      <TextInput
                        style={styles.input}
                        placeholder="Full name"
                        placeholderTextColor={colors.inputPlaceholder}
                        value={formData.name}
                        onChangeText={(v) => updateFormData('name', v)}
                        autoComplete="name"
                        accessibilityLabel="Full name"
                      />
                    </View>

                    <View style={styles.inputWrapper}>
                      <View style={styles.inputIconContainer}>
                        <Ionicons name="mail-outline" size={20} color="rgba(255,255,255,0.7)" />
                      </View>
                      <TextInput
                        style={styles.input}
                        placeholder="Email address"
                        placeholderTextColor={colors.inputPlaceholder}
                        value={formData.email}
                        onChangeText={(v) => updateFormData('email', v)}
                        autoCapitalize="none"
                        keyboardType="email-address"
                        autoComplete="email"
                        accessibilityLabel="Email address"
                      />
                    </View>

                    <View style={styles.inputWrapper}>
                      <View style={styles.inputIconContainer}>
                        <Ionicons name="lock-closed-outline" size={20} color="rgba(255,255,255,0.7)" />
                      </View>
                      <TextInput
                        style={styles.input}
                        placeholder="Password (min. 6 characters)"
                        placeholderTextColor={colors.inputPlaceholder}
                        value={formData.password}
                        onChangeText={(v) => updateFormData('password', v)}
                        secureTextEntry={!showPassword}
                        autoComplete="password-new"
                        accessibilityLabel="Password"
                      />
                      <TouchableOpacity
                        style={styles.inputIconContainer}
                        onPress={() => setShowPassword((v) => !v)}
                        accessibilityLabel={showPassword ? 'Hide password' : 'Show password'}
                        hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                      >
                        <Ionicons
                          name={showPassword ? 'eye-off-outline' : 'eye-outline'}
                          size={20}
                          color="rgba(255,255,255,0.7)"
                        />
                      </TouchableOpacity>
                    </View>

                    <View style={styles.inputWrapper}>
                      <View style={styles.inputIconContainer}>
                        <Ionicons name="gift-outline" size={20} color="rgba(255,255,255,0.7)" />
                      </View>
                      <TextInput
                        style={styles.input}
                        placeholder="Referral code (optional)"
                        placeholderTextColor={colors.inputPlaceholder}
                        value={formData.referralCode}
                        onChangeText={(v) => updateFormData('referralCode', v)}
                        autoCapitalize="characters"
                        accessibilityLabel="Referral code"
                      />
                    </View>

                    {error && (
                      <View style={styles.errorContainer}>
                        <Ionicons name="warning" size={18} color={colors.inputError} />
                        <Text style={styles.errorText}>{error}</Text>
                      </View>
                    )}

                    <WWPrimaryButton
                      title={isLoading ? 'Creating account…' : 'Create account'}
                      onPress={handleSignup}
                      disabled={isLoading}
                      loading={isLoading}
                      style={styles.signupButton}
                    />
                  </View>
                </ScrollView>
              </BlurView>
            </Pressable>
          </KeyboardAvoidingView>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  ...sharedAuthStyleDefs,
  contentOverlayWrapper: {
    position: 'relative',
    width: '100%',
    borderRadius: 20,
    overflow: 'hidden',
    marginBottom: 4,
  },
  signupHeroLogo: {
    width: 380,
    height: 238,
  },
  glassCard: {
    borderRadius: 20,
    overflow: 'hidden',
    paddingHorizontal: 20,
    paddingTop: 24,
    paddingBottom: 24,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.22,
    shadowRadius: 16,
    elevation: 8,
  },
  errorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  errorText: {
    color: colors.inputError,
    fontSize: 14,
  },
  signupButton: { marginTop: 4 },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  modalKeyboardAvoid: {
    width: '100%',
    maxHeight: '92%',
  },
  modalContent: {
    maxHeight: '92%',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    overflow: 'hidden',
  },
  modalBlur: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    overflow: 'hidden',
    maxHeight: '100%',
  },
  modalScroll: {
    maxHeight: '100%',
  },
  modalScrollContent: {
    padding: 24,
    paddingBottom: 40,
  },
  modalInner: {
    padding: 0,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: 'rgba(255,255,255,0.95)',
  },
  signupCtaRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 12,
    marginBottom: 8,
  },
  signupCtaText: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 13,
    fontWeight: '600',
  },
  signupCtaLink: {
    color: '#87CEEB',
    fontWeight: '800',
  },
});
