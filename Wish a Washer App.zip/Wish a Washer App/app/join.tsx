import { useEffect } from 'react';
import { ActivityIndicator, View, StyleSheet } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../src/providers/enhanced-auth-context';
import { colors } from '../src/constants/colors';

export default function JoinReferralScreen() {
  const params = useLocalSearchParams<{ code?: string; referralCode?: string }>();
  const { user, isLoading } = useAuth();

  useEffect(() => {
    if (isLoading) return;

    const rawCode = params.code ?? params.referralCode;
    const code =
      typeof rawCode === 'string' && rawCode.trim()
        ? rawCode.trim().toUpperCase()
        : null;

    if (user?.id) {
      if (code) {
        router.replace({
          pathname: '/owner/features/referral-system',
          params: { enterCode: code },
        });
      } else {
        router.replace('/owner/features/referral-system');
      }
      return;
    }

    if (code) {
      router.replace({
        pathname: '/auth/signup',
        params: { referralCode: code },
      });
      return;
    }

    router.replace('/auth/signup');
  }, [isLoading, params.code, params.referralCode, user?.id]);

  return (
    <View style={styles.container}>
      <ActivityIndicator size="large" color={colors.SKY} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.bgPrimary,
  },
});
