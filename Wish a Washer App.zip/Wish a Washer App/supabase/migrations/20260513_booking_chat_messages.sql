create table if not exists public.booking_messages (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings (id) on delete cascade,
  sender_id uuid not null references auth.users (id),
  sender_role text not null check (sender_role = any (array['customer'::text, 'valeter'::text])),
  message_type text not null default 'text' check (message_type = any (array['text'::text, 'image'::text, 'voice'::text])),
  content text,
  media_url text,
  voice_duration_seconds integer,
  read_at timestamp with time zone,
  created_at timestamp with time zone not null default now()
);

create index if not exists idx_booking_chat_messages_booking_created_at
  on public.booking_messages (booking_id, created_at);

create index if not exists idx_booking_chat_messages_sender_created_at
  on public.booking_messages (sender_id, created_at);
