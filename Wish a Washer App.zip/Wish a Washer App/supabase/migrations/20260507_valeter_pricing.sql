alter table if exists public.valeter_profiles
  add column if not exists services_offered text[] not null default '{}'::text[],
  add column if not exists service_pricing jsonb not null default '{}'::jsonb;

alter table if exists public.bookings
  add column if not exists platform_fee_percent numeric,
  add column if not exists platform_fee_amount numeric;

create table if not exists public.waw_platform_fees (
  context text not null,
  percent numeric(6, 3) not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint waw_platform_fees_pkey primary key (context),
  constraint waw_platform_fees_context_check check (
    context = any (array['valeter'::text, 'physical'::text])
  ),
  constraint waw_platform_fees_percent_check check (
    percent >= (0)::numeric
    and percent <= (100)::numeric
  )
);
