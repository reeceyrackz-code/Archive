# Wish a Wash Release Overview

## What this app is
Wish a Wash is the customer-facing app. It is the side customers use to sign in, manage their profile, book a wash, pay, track the job, and review the service after completion.

Think of it as the rider/customer app in an Uber-style split.

## Main user journeys
- Sign up and log in
- Complete customer onboarding
- Add or manage vehicles
- Browse services and select a booking flow
- Choose a valeter or a physical location, depending on the booking type
- Pay for the booking
- Track the job while it is active
- Leave a rating or review after completion

## App areas to know
- `app/auth/*` handles login and signup
- `app/owner/*` contains the main customer experience, including booking, tracking, history, settings, and support
- `src/components/booking/*` contains the booking UI and payment sheet pieces
- `src/services/*` contains the local business logic used by the app

## Supabase connection points

### Auth
- Uses Supabase Auth for login and session handling
- Session state is stored locally in the app and reused for API calls

### Database tables this app is expected to touch
- `profiles`
- `bookings`
- `customer_vehicles`
- `car_wash_locations`
- `valeter_profiles`
- `valeter_pricing`
- `reviews`
- `booking_messages`
- `location_services`
- `waw_platform_fees`

### Edge Functions this app uses
- `booking-extra-charge`

That function is used from the booking payment flow and also from booking-related customer actions inside the app.

## Payment flow
- The booking flow creates or prepares a booking in Supabase
- The app then calls the `booking-extra-charge` Edge Function for payment collection
- After successful payment, the booking is updated in the app flow and should stay in sync with the backend state

## Things to keep aligned
- Booking status names should match the business app and the Supabase function payloads
- Any payment-related field names in the booking row should stay consistent across both apps
- If a booking can be paid in more than one place, the payment source of truth should stay in Supabase and the webhook/function layer, not just the client

## Important file pointers
- [Customer booking payment sheet](/Volumes/externalSSD/Projects/Latest Wish Group/Wish-a-Wash/wish-a-wash/src/components/booking/BookingPaymentSheet.tsx)
- [Customer booking payment function](/Volumes/externalSSD/Projects/Latest Wish Group/Wish-a-Wash/wish-a-wash/supabase/functions/booking-extra-charge/index.ts)
- [Customer auth client](/Volumes/externalSSD/Projects/Latest Wish Group/Wish-a-Wash/wish-a-wash/src/lib/supabase.ts)

## Release note
This document is meant as a release and handover summary for the customer app. It is intentionally focused on how the app is wired rather than on old legacy code that may still be present in the repository.
