/** AsyncStorage key for the "auto-select my default vehicle in bookings" preference. */
export const AUTO_SELECT_DEFAULT_VEHICLE_KEY = 'pref_auto_select_default_vehicle_v1';
