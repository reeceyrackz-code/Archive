import { colors } from './colors';
import { ADAPTIVE_STATIC } from './adaptiveLayout';

/** Single curved radius for all booking cards – matches detailing vehicle selection exactly */
const CARD_BORDER_RADIUS = 18;

/** Vertical position for card strip on map views – tracking & payment (cards higher) */
export const CARD_STRIP_TOP = 156;

/**
 * Bottom offset for customer booking flow glass sheets on `/owner/booking/*`.
 * The tab bar is hidden on these routes, so sheets sit flush with the screen bottom;
 * safe area is handled via each sheet's `paddingBottom` (e.g. `Math.max(insets.bottom, 10)`).
 */
export function getCustomerBookingSheetScreenBottom(): number {
  return 0;
}

/** Panel height for step sheets (tracking-adjacent feel). */
export const BOOKING_MAP_SHEET_HEIGHT_RATIO = 0.4;
export const BOOKING_MAP_SHEET_HEIGHT_MAX = 400;

export function getCustomerBookingMapSheetHeight(screenHeight: number): number {
  return Math.min(screenHeight * BOOKING_MAP_SHEET_HEIGHT_RATIO, BOOKING_MAP_SHEET_HEIGHT_MAX);
}

/** Quick book: needs room for header + tiers + vehicle + CTA without clipping. */
export const QUICK_BOOKING_SHEET_RATIO = 0.5;
export const QUICK_BOOKING_SHEET_MAX = 460;

export function getQuickBookingMapSheetHeight(screenHeight: number): number {
  return Math.min(screenHeight * QUICK_BOOKING_SHEET_RATIO, QUICK_BOOKING_SHEET_MAX);
}

/** Payment summary + swipe bar — taller than generic map sheet. */
export const PAYMENT_BOOKING_SHEET_RATIO = 0.56;
export const PAYMENT_BOOKING_SHEET_MAX = 520;

export function getPaymentBookingMapSheetHeight(screenHeight: number): number {
  return Math.min(screenHeight * PAYMENT_BOOKING_SHEET_RATIO, PAYMENT_BOOKING_SHEET_MAX);
}

/** Taller panel for live tracking (nested card + progress + footer actions). */
export const BOOKING_TRACKING_SHEET_HEIGHT_RATIO = 0.5;
export const BOOKING_TRACKING_SHEET_HEIGHT_MAX = 480;

export function getCustomerBookingTrackingSheetHeight(screenHeight: number): number {
  return Math.min(screenHeight * BOOKING_TRACKING_SHEET_HEIGHT_RATIO, BOOKING_TRACKING_SHEET_HEIGHT_MAX);
}

/** Bottom sheet top corner radius (map flows) — matches compact header mockups */
export const CUSTOMER_BOOKING_SHEET_TOP_RADIUS = 28;

/**
 * Bottom sheet edge — legacy single top rail (some flows still compose with premium rim).
 */
export const CUSTOMER_BOOKING_SHEET_INDEX_LIKE_BORDER = {
  borderTopWidth: 1,
  borderLeftWidth: 0,
  borderRightWidth: 0,
  borderBottomWidth: 0,
  borderColor: 'rgba(148,163,184,0.3)',
} as const;

/**
 * Premium glass map / booking sheet rim — matches `IndexTrackingCardShell` luxury frame.
 * Use on bottom sheets (with `overflow: 'hidden'`) instead of only `CUSTOMER_BOOKING_SHEET_INDEX_LIKE_BORDER`.
 */
export const PREMIUM_BOOKING_MAP_SHEET = {
  borderTopLeftRadius: CUSTOMER_BOOKING_SHEET_TOP_RADIUS,
  borderTopRightRadius: CUSTOMER_BOOKING_SHEET_TOP_RADIUS,
  overflow: 'hidden' as const,
  borderTopWidth: 1,
  borderLeftWidth: 1,
  borderRightWidth: 1,
  borderBottomWidth: 0,
  borderColor: HEADER_STYLE_CARD_BORDER,
  backgroundColor: colors.BG ?? '#0A1929',
  shadowColor: 'rgba(8,20,38,0.9)',
  shadowOffset: { width: 0, height: -10 },
  shadowOpacity: 0.42,
  shadowRadius: 28,
  elevation: 20,
} as const;

/** Same rim/shadow as `PREMIUM_BOOKING_MAP_SHEET` but leaves room for BlurView + layered gradients underneath. */
export const PREMIUM_BOOKING_MAP_SHEET_GLASS = {
  ...PREMIUM_BOOKING_MAP_SHEET,
  backgroundColor: colors.BG ?? '#0A1929',
} as const;

/**
 * Nested “tracking card” on glass sheets — opaque inset panel + crisp rim
 * (reference: inner card on booking request / tracking mockups).
 */
export const BOOKING_INNER_CARD_BACKGROUND = 'rgba(11, 18, 34, 0.94)';
export const BOOKING_INNER_CARD_BORDER = 'rgba(255, 255, 255, 0.14)';

/** Align horizontal step cards with tracking’s main card (`minHeight: 220`). */
export const BOOKING_STEP_CARD_MIN_HEIGHT = 220;

/**
 * Wash / detailing tier carousels — baseline height so bronze/silver match gold+ (badge + taglines).
 */
export const BOOKING_SERVICE_CARD_MIN_HEIGHT = 252;

/** Gap between horizontal snap cards (booking pickers on map sheets). */
export const BOOKING_H_CARD_GAP = 12;

/**
 * Booking index + map bottom-sheet option tiles — same width as tracking-style cards
 * (`min(screenWidth - 52, 300)`).
 */
export const INDEX_TRACKING_CARD_BORDER_RADIUS = 22;

export function getIndexTrackingCardWidth(screenWidth: number): number {
  return Math.min(screenWidth - 36, 328);
}

/**
 * Book a Service (`booking/index`) — card width inside the glass sheet (sheet padding + right peek).
 * Keeps one full card visible with a sliver of the next; avoids overflow on narrow phones.
 */
export function getBookingIndexOptionCardWidth(screenWidth: number): number {
  const sheetHorizontalPadding = 14 * 2;
  const horizontalBreathing = 20; // peek + scroll end padding
  const cap = 312;
  const inner = screenWidth - sheetHorizontalPadding - horizontalBreathing;
  return Math.max(160, Math.min(inner, cap));
}

export function getIndexTrackingCardSnapInterval(screenWidth: number): number {
  return getIndexTrackingCardWidth(screenWidth) + BOOKING_H_CARD_GAP;
}

export function getBookingIndexOptionSnapInterval(screenWidth: number): number {
  return getBookingIndexOptionCardWidth(screenWidth) + BOOKING_H_CARD_GAP;
}

/** Compact horizontal card width — narrower than full bleed rows. */
export function getBookingHorizontalCardWidth(screenWidth: number): number {
  return Math.round(Math.min(screenWidth * 0.72, 260));
}

export function getBookingHorizontalSnapInterval(screenWidth: number): number {
  return getBookingHorizontalCardWidth(screenWidth) + BOOKING_H_CARD_GAP;
}

/** Narrow tier chips for quick-book row (~3 per screen with peek). */
export function getQuickBookingTierChipWidth(screenWidth: number): number {
  const shellPad = 16;
  const inner = screenWidth - shellPad * 2;
  return Math.round(Math.min(102, Math.max(76, (inner - 8 * 3) / 3.15)));
}

export function getQuickBookingTierSnapInterval(screenWidth: number): number {
  return getQuickBookingTierChipWidth(screenWidth) + 8;
}

/** Centered footer CTA width under compact horizontal strips. */
export function getBookingSheetFooterWidth(screenWidth: number): number {
  return Math.min(screenWidth - 40, 320);
}

/** Gradient matching customer UI (glossy teal/navy glass) */
export const HEADER_STYLE_CARD_GRADIENT = [
  'rgba(108,168,204,0.64)',
  'rgba(42,88,124,0.52)',
  'rgba(15,28,48,0.46)',
] as [string, string, string];

/** Border color — brighter rim for glossy dark-blue chrome */
export const HEADER_STYLE_CARD_BORDER = 'rgba(148,196,220,0.62)';

/** Specular highlights layered on blur + navy gradients */
export const BOOKING_GLASS_TOP_SHEEN = [
  'rgba(255,255,255,0.24)',
  'rgba(255,255,255,0.07)',
  'transparent',
] as const;

export const BOOKING_GLASS_TOP_SHEEN_LOCATIONS = [0, 0.3, 0.65] as const;

export const BOOKING_GLASS_DIAGONAL_SHEEN = [
  'rgba(255,255,255,0.26)',
  'rgba(255,255,255,0.04)',
] as const;

/** Dark scrim over blur/gradient inside map tracking-style sheets (wishawasherwithconnect business tracking). */
export const BOOKING_SHEET_DARK_OVERLAY = 'rgba(0,0,0,0.28)';

/** Same as wishawasherwithconnect valeter `tracking.tsx` TRACKING_SHEET_MAX_HEIGHT_RATIO + ACTIONS_BAR_HEIGHT. */
export const MAP_TRACKING_SHEET_MAX_HEIGHT_RATIO = 0.4;
export const MAP_TRACKING_ACTIONS_BAR_HEIGHT = 52;
/** Extra map bottom padding above sheet (reference uses +80 on sheet body ratio). */
export const MAP_TRACKING_MAP_PADDING_BOTTOM_EXTRA = 80;

/** Panel blur — wishawasherwithconnect `bookingCardTheme` / valeter tracking sheet. */
export const BOOKING_SHEET_BLUR_INTENSITY = 40;

/** Yellow chrome for map UI in dark mode; light blue in light mode — use `getMapChromeColors` / `useMapChromeColors`. */
export type MapChromeColors = {
  accent: string;
  icon: string;
  border: string;
  gradient: readonly [string, string, string];
  shadow: string;
};

const MAP_CHROME_DARK: MapChromeColors = {
  accent: colors.DETAILING_YELLOW ?? '#EAB308',
  icon: '#FDE047',
  border: 'rgba(250,204,21,0.5)',
  gradient: ['rgba(234,179,8,0.32)', 'rgba(8,20,38,0.62)', 'rgba(250,204,21,0.1)'],
  shadow: colors.DETAILING_YELLOW ?? '#EAB308',
};

const MAP_CHROME_LIGHT: MapChromeColors = {
  accent: colors.SKY ?? '#38BDF8',
  icon: '#E0F2FE',
  border: 'rgba(125,211,252,0.55)',
  gradient: ['rgba(56,189,248,0.28)', 'rgba(8,20,38,0.55)', 'rgba(125,211,252,0.14)'],
  shadow: colors.SKY ?? '#38BDF8',
};

/** Map header / tab chrome — yellow in dark mode, sky blue in light mode. */
export function getMapChromeColors(isLight: boolean): MapChromeColors {
  return isLight ? MAP_CHROME_LIGHT : MAP_CHROME_DARK;
}

/** @deprecated Use `getMapChromeColors` — dark-mode defaults for static fallbacks. */
export const MAP_CHROME_YELLOW = MAP_CHROME_DARK.accent;
export const MAP_CHROME_YELLOW_ICON = MAP_CHROME_DARK.icon;
export const MAP_CHROME_YELLOW_BORDER = MAP_CHROME_DARK.border;
export const MAP_CHROME_YELLOW_GRADIENT = MAP_CHROME_DARK.gradient;

export function getMapTrackingTotalSheetHeight(screenHeight: number): number {
  return screenHeight * MAP_TRACKING_SHEET_MAX_HEIGHT_RATIO + MAP_TRACKING_ACTIONS_BAR_HEIGHT;
}

/** Curved container — no outer stroke; matches flat IndexTrackingCardShell tiles on map sheets */
export const CURVED_BOOKING_CARD = {
  borderRadius: CARD_BORDER_RADIUS,
  overflow: 'hidden' as const,
  backgroundColor: 'transparent',
  borderWidth: 0,
  borderColor: 'transparent',
  shadowColor: 'transparent',
  shadowOffset: { width: 0, height: 0 },
  shadowOpacity: 0,
  shadowRadius: 0,
  elevation: 0,
};

/** Slightly narrower than screen so each card fits with visible margins; on iPad capped and centered via adaptiveLayout */
export const BOOKING_CARD = {
  CARD_WIDTH: ADAPTIVE_STATIC.cardWidth,
  SNAP_INTERVAL: ADAPTIVE_STATIC.cardSnapInterval,
  PADDING_H: 20,
  PADDING_TOP: 14,
  BORDER_RADIUS: CARD_BORDER_RADIUS,
  INTENSITY: 35,
  SKY: colors.SKY,
  GRADIENT: [colors.SKY, '#60A5FA', '#3B82F6'] as const,
  GRADIENT_CTA: [colors.SKY, '#60A5FA'] as const,
  ICON_SIZE: 58,
  ICON_RADIUS: 18,
  CURVED: CURVED_BOOKING_CARD,
};
