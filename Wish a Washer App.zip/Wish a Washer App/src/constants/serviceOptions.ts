/** Badge shown on service cards (e.g. "Popular", "Recommended", "Best value"). */
export type ServiceBadge = 'Quick & affordable' | 'Recommended' | 'Popular' | 'Best value' | 'Premium' | 'Most popular';

export interface ServiceOption {
  id: string;
  name: string;
  desc: string;
  dur: string;
  icon: string;
  colors: [string, string];
  price: number;
  minPrice?: number;
  maxPrice?: number;
  bulletPoints?: string[];
  /** Reassurance lines shown on confirmation (e.g. "✔ Complete interior & exterior clean"). */
  confirmationSummary?: string[];
  /** Optional badge for service card (e.g. "Popular", "Recommended"). */
  badge?: ServiceBadge;
  /** Add-on IDs already included in this service; these are hidden from the add-on picker when this service is selected. */
  includedAddOnIds?: string[];
  /** Title shown above the description in the info popup (e.g. "Essential Clean", "Showroom Finish"). */
  descriptionTitle?: string;
}

/* =======================
   STANDARD VALET SERVICES
======================= */

export const serviceOptions: ServiceOption[] = [
  {
    id: 'bronze-wash',
    name: 'Bronze Wash',
    descriptionTitle: 'Interior OR exterior',
    desc: 'A quick refresh for your vehicle. Choose either an exterior hand wash or a light interior clean including vacuuming and surface wipe-downs.',
    dur: '20–35 min',
    icon: 'water-outline',
    colors: ['#CD7F32', '#A0522D'],
    price: 15,
    bulletPoints: [
      'Your choice: exterior hand wash OR light interior clean',
      'Exterior option: safe wash, wheels, rinse, dry, exterior glass',
      'Interior option: vacuum, surface wipe-downs, light cabin tidy',
      'Ideal for maintenance between deeper valets',
      'Fast and affordable',
    ],
    confirmationSummary: [
      'Bronze – exterior OR interior refresh (your choice)',
      'Approx time: 20–35 mins',
    ],
  },
  {
    id: 'silver-wash',
    name: 'Silver Wash',
    descriptionTitle: 'Interior + Exterior',
    desc: 'A balanced clean inside and out. Includes an exterior hand wash plus a light interior refresh with vacuuming, surface cleaning, and a tidy finish.',
    dur: '60–90 min',
    icon: 'sparkles-outline',
    colors: ['#C0C0C0', '#A8A8A8'],
    price: 25,
    bulletPoints: [
      'Exterior hand wash, wheels and dry',
      'Interior vacuum (seats, carpets, boot)',
      'Dashboard, console and trims wiped',
      'Interior and exterior glass cleaned',
      'Tyre dressing and light spray wax where included',
      'Balanced inside-and-out refresh',
    ],
    confirmationSummary: [
      'Silver – exterior wash plus light interior refresh',
      'Approx time: 60–90 mins',
    ],
  },
  {
    id: 'gold-wash',
    name: 'Gold Wash',
    descriptionTitle: 'Interior Deep Clean',
    desc: 'A full interior deep clean designed to restore your vehicle from the inside out. Includes deep vacuuming, stain removal, upholstery and carpet treatment, and detailed cleaning of all interior surfaces.',
    dur: '90–120 min',
    icon: 'trophy-outline',
    colors: ['#FFD700', '#FFA500'],
    price: 55,
    badge: 'Popular',
    bulletPoints: [
      'Deep vacuum throughout cabin and boot',
      'Stain treatment and upholstery / carpet care',
      'Seats, carpets and mats shampooed or refreshed where suitable',
      'All interior surfaces, trims and touchpoints detailed',
      'Leather cleaned and dressed where applicable',
      'Headliner and hard-to-reach areas addressed',
      'Interior glass and finishes refreshed',
      'Air freshener to finish',
    ],
    confirmationSummary: [
      'Gold – interior deep clean (focus on cabin restoration)',
      'Approx time: 90–120 mins',
    ],
    includedAddOnIds: ['seat-shampoo'],
  },
  {
    id: 'platinum-wash',
    name: 'Platinum Wash',
    descriptionTitle: 'Full Valet',
    desc: 'A complete interior and exterior valet with enhanced attention to detail. Includes a thorough wash, detailed interior cleaning, and finishing touches to leave your vehicle clean, fresh, and well presented.',
    dur: '2–3 hours',
    icon: 'diamond-outline',
    colors: ['#E5E4E2', '#BCC6CC'],
    price: 70,
    badge: 'Recommended',
    bulletPoints: [
      'Thorough exterior wash, wheels and arches',
      'Interior deep clean aligned with our Gold cabin standard',
      'Trims, glass and surfaces finished to a high standard',
      'Enhanced attention to detail inside and out',
      'Finishing touches for a clean, fresh presentation',
      'Ideal when you want the full vehicle refreshed in one visit',
    ],
    confirmationSummary: [
      'Platinum – full valet (interior + exterior)',
      'Approx time: 2–3 hours',
    ],
  },
  {
    id: 'emerald-wash',
    name: 'Diamond Wash',
    descriptionTitle: 'Premium Full Detail',
    desc: 'Our highest level service delivering a full vehicle transformation. Includes a deep interior clean, detailed exterior wash, and premium finishing to restore shine, enhance protection, and achieve a near showroom finish.',
    dur: '2–4 hours',
    icon: 'sparkles',
    colors: ['#22D3EE', '#0EA5E9'],
    price: 85,
    badge: 'Premium',
    bulletPoints: [
      'Deep interior clean plus detailed exterior wash',
      'Paint decontamination and enhancement where appropriate',
      'Upholstery / leather care and interior sanitisation',
      'Machine or hand finishing for gloss and clarity',
      'Long-lasting protection or sealant where included',
      'Fine detailing on edges, trims and glass',
      'Premium finish aimed at near showroom presentation',
    ],
    confirmationSummary: [
      'Diamond – premium full detail (highest tier)',
      'Approx time: 2–4 hours',
    ],
  },
];

/* =======================
   DETAILING SERVICES
======================= */

export const detailingServiceOptions: ServiceOption[] = [
  {
    id: 'ceramic-coating',
    name: 'Ceramic Coating',
    desc: 'Long-lasting paint protection with a premium ceramic layer that bonds to your paint. Delivers a deep gloss and makes washing easier for years.',
    dur: '6–8 hours',
    icon: 'shield-checkmark-outline',
    colors: ['#EAB308', '#CA8A04'],
    price: 350,
    badge: 'Popular',
    bulletPoints: [
      'Full exterior wash and paint decontamination',
      'Paint preparation and light correction if needed',
      'Professional-grade ceramic coating application',
      'Hydrophobic finish – water beads and runs off',
      'Strong UV, chemical, and oxidation protection',
      'Enhanced gloss and colour depth',
      'Typically 1–3+ years protection (depends on product and care)',
      'Best for: New or freshly corrected paint, low-maintenance shine',
    ],
  },
  {
    id: 'machine-polishing',
    name: 'Machine Polishing',
    desc: 'Professional paint correction using dual-action or rotary polishers. Removes swirls, light scratches, and defects to restore clarity and gloss.',
    dur: '4–6 hours',
    icon: 'color-filter-outline',
    colors: ['#EAB308', '#CA8A04'],
    price: 300,
    badge: 'Recommended',
    bulletPoints: [
      'Full wash and decontamination first',
      'Paint inspected under proper lighting',
      'Multi-stage machine polish (cut and refine)',
      'Removal of swirl marks, light scratches, and oxidation',
      'Noticeable improvement in gloss and depth',
      'Sealant or wax applied to protect the finish',
      'Level of correction depends on paint condition',
      'Best for: Dull or scratched paint, pre-ceramic prep, enthusiasts',
    ],
  },
  {
    id: 'soft-top-restoration',
    name: 'Soft Top Restoration',
    desc: 'Specialist care for fabric and vinyl convertible hoods. Cleans, reconditions, and protects to restore appearance and weather resistance.',
    dur: '2–3 hours',
    icon: 'brush-outline',
    colors: ['#EAB308', '#CA8A04'],
    price: 150,
    badge: 'Premium',
    bulletPoints: [
      'Gentle wash to remove dirt and stains',
      'Mould and mildew treatment if present',
      'Fabric or vinyl cleaner suited to your roof type',
      'Conditioning to restore colour and suppleness',
      'Water-repellent / UV protection product applied',
      'Seals and stitching checked',
      'Best for: Convertibles, cabriolets, fabric or vinyl soft tops',
    ],
  },
  {
    id: 'mould-removal',
    name: 'Mould Removal',
    desc: 'Professional removal of mould, mildew and musty odours from interior surfaces, air-con systems and cabin filters. Restores a fresh, clean interior.',
    dur: '1–2 hours',
    icon: 'water-outline',
    colors: ['#EAB308', '#CA8A04'],
    price: 95,
    badge: 'Premium',
    bulletPoints: [
      'Inspection of cabin filter, vents and ducting',
      'Air-con system sanitisation and treatment',
      'Dashboard, trim and upholstery mould treatment',
      'Odour neutralisation for a fresh cabin',
      'Prevention tips to reduce recurrence',
      'Best for: Musty smell, visible mould, after flooding or damp storage',
    ],
  },
];

/* =======================
   REPAIR SERVICES (mobile package sheet — separate from detailing)
======================= */

export const repairServiceOptions: ServiceOption[] = [
  {
    id: 'maintenance-pack',
    name: 'Maintenance Pack',
    descriptionTitle: 'Fluids & quick checks',
    desc: 'Essential under-bonnet checks and top-ups: oil level, coolant, screen wash and a visual health pass — ideal between services.',
    dur: '30–45 min',
    icon: 'build-outline',
    colors: ['#FB923C', '#EA580C'],
    price: 45,
    badge: 'Value',
    bulletPoints: [
      'Visual oil level check (dipstick — no oil change)',
      'Coolant level check and top-up where low',
      'Screen wash reservoir top-up',
      'Quick visual under-bonnet health check',
      'Tyre pressures checked and adjusted where needed',
      'Best for: Between services, pre-MOT peace of mind, winter readiness',
    ],
  },
  {
    id: 'headlight-restoration',
    name: 'Headlight Restoration',
    descriptionTitle: 'Lens clarity',
    desc: 'Restore cloudy or yellowed headlights for clearer vision and a like-new look. Professional treatment to remove oxidation and restore clarity.',
    dur: '1–2 hours',
    icon: 'bulb-outline',
    colors: ['#FB923C', '#EA580C'],
    price: 35,
    badge: 'Popular',
    bulletPoints: [
      'Inspection of headlight condition',
      'Surface cleaned and prepared',
      'Oxidation and yellowing removed',
      'Polish and refinement for clarity',
      'UV sealant applied to slow future hazing',
      'Improved night-time visibility and appearance',
      'Best for: Cloudy, yellowed, or hazy headlights',
    ],
  },
  {
    id: 'scratch-removal',
    name: 'Scratch Removal',
    descriptionTitle: 'Paint rescue',
    desc: 'Targeted reduction or removal of light scratches and swirl marks in clear coat. Depth and result depend on scratch severity.',
    dur: '1–3 hours',
    icon: 'color-filter-outline',
    colors: ['#FB923C', '#C2410C'],
    price: 55,
    bulletPoints: [
      'Paint inspected under good light',
      'Safe wash and decontamination of the area',
      'Machine or hand correction where appropriate',
      'Refinement and gloss restoration',
      'Protection layer applied where suitable',
      'Best for: Light clear-coat scratches, wash swirls, minor scuffs',
    ],
  },
  {
    id: 'paint-chip-repair',
    name: 'Paint Chip Repair',
    descriptionTitle: 'Touch-in & seal',
    desc: 'Clean, fill and touch in small stone chips and minor paint damage to protect metal and improve appearance.',
    dur: '45–90 min',
    icon: 'medkit-outline',
    colors: ['#FB923C', '#EA580C'],
    price: 40,
    bulletPoints: [
      'Chip areas cleaned and degreased',
      'Rust or contamination addressed if present',
      'Colour-matched touch-in (where match available)',
      'Levelled and sealed to protect from spreading',
      'Best for: Small chips, motorway stone strikes, parking nicks',
    ],
  },
  {
    id: 'trim-restoration',
    name: 'Trim Restoration',
    descriptionTitle: 'Faded plastic revived',
    desc: 'Restore faded or greying exterior plastic trim, bumpers and mouldings with deep clean and UV dressing.',
    dur: '1–2 hours',
    icon: 'albums-outline',
    colors: ['#F97316', '#EA580C'],
    price: 35,
    bulletPoints: [
      'Trim cleaned and stripped of old dressings',
      'Oxidation and fading treated',
      'Satin or gloss finish to OEM-style look',
      'UV protection to slow future fading',
      'Best for: Door strips, mirror caps, bumper inserts, side mouldings',
    ],
  },
  {
    id: 'leather-repair',
    name: 'Leather Repair',
    descriptionTitle: 'Seat & trim repair',
    desc: 'Minor leather repairs: scuffs, small tears, colour wear and bolster creasing improved for a neater cabin.',
    dur: '1–2 hours',
    icon: 'shirt-outline',
    colors: ['#EA580C', '#C2410C'],
    price: 45,
    bulletPoints: [
      'Leather cleaned and assessed',
      'Fill or bind small tears where suitable',
      'Colour touch-up and blend',
      'Conditioner applied for suppleness',
      'Best for: Worn bolsters, cat scratches, scuffs, small splits',
    ],
  },
];

/** Ids for mobile “Repair” category packages (add-ons + strip colour helpers). */
export const REPAIR_PACKAGE_IDS: readonly string[] = repairServiceOptions.map((o) => o.id);

/** Add-ons offered only with repair bookings (fluids & quick fit). */
export const REPAIR_ADD_ON_IDS: readonly string[] = [
  'wiper-blade-install',
  'coolant-top-up',
  'oil-level-check',
  'screen-wash-refill',
];

const REPAIR_ADD_ON_SET = new Set(REPAIR_ADD_ON_IDS);

/* =======================
   ADD-ON OPTIONS (wash & detail)
   "Enhance Your Clean" (Optional)
======================= */

export const ADD_ON_SECTION_TITLE = 'Enhance your clean';
export const ADD_ON_SECTION_SUBTITLE = 'Add extra treatments to your booking:';

export interface AddOnOption {
  id: string;
  name: string;
  desc: string;
  price: number;
  icon: string;
}

export const addOnOptions: AddOnOption[] = [
  {
    id: 'pet-hair',
    name: 'Pet hair removal',
    desc: 'Removes stubborn embedded pet hair from seats and carpets.',
    price: 12,
    icon: 'paw-outline',
  },
  {
    id: 'stain-removal',
    name: 'Stain removal treatment',
    desc: 'Targeted treatment for stubborn stains on seats and carpets.',
    price: 15,
    icon: 'water-outline',
  },
  {
    id: 'vomit-removal',
    name: 'Vomit removal',
    desc: 'Deep clean and sanitisation for spill, stain, and odour removal.',
    price: 35,
    icon: 'warning-outline',
  },
  {
    id: 'biohazard-removal',
    name: 'Biohazard removal',
    desc: 'Specialist clean-up for hazardous contamination and sanitisation.',
    price: 55,
    icon: 'shield-checkmark-outline',
  },
  {
    id: 'engine-bay',
    name: 'Engine bay clean',
    desc: 'Safe exterior engine bay clean and dress.',
    price: 25,
    icon: 'construct-outline',
  },
  {
    id: 'headlight-restoration',
    name: 'Headlight restoration',
    desc: 'Restore cloudy or yellowed headlights for clearer vision and a like-new look.',
    price: 35,
    icon: 'bulb-outline',
  },
  {
    id: 'seat-shampoo',
    name: 'Interior shampoo',
    desc: 'Deep fabric and upholstery cleaning to remove dirt and refresh seats and carpets.',
    price: 15,
    icon: 'water-outline',
  },
  {
    id: 'ceramic-spray',
    name: 'Ceramic spray protection upgrade',
    desc: 'Longer-lasting hydrophobic protection and enhanced gloss for your paintwork.',
    price: 25,
    icon: 'sparkles-outline',
  },
  {
    id: 'floor-mats-carpet-shampoo',
    name: 'Floor mats & carpet shampoo',
    desc: 'Deep clean and shampoo of footwells, floor mats and carpets.',
    price: 18,
    icon: 'water-outline',
  },
  {
    id: 'clay-bar-treatment',
    name: 'Clay bar treatment',
    desc: 'Paint decontamination to remove bonded contaminants and restore smoothness.',
    price: 35,
    icon: 'color-filter-outline',
  },
  {
    id: 'iron-tar-decontamination',
    name: 'Iron and tar decontamination',
    desc: 'Removes industrial fallout, tar spots and embedded particles from paintwork.',
    price: 40,
    icon: 'construct-outline',
  },
  {
    id: 'wiper-blade-install',
    name: 'Wiper blade installation (Customer Provided)',
    desc: 'Professional fit of wiper blades you supply — correct pairing and safe installation.',
    price: 10,
    icon: 'rainy-outline',
  },
  {
    id: 'coolant-top-up',
    name: 'Coolant level top-up',
    desc: 'Check coolant level and top up with correct spec where low (customer-approved).',
    price: 12,
    icon: 'thermometer-outline',
  },
  {
    id: 'oil-level-check',
    name: 'Oil level check (Visual Only)',
    desc: 'Visual check of dipstick level only — no top-up or oil change.',
    price: 8,
    icon: 'speedometer-outline',
  },
  {
    id: 'screen-wash-refill',
    name: 'Screen wash top-up',
    desc: 'Top up washer reservoir with quality screen wash.',
    price: 8,
    icon: 'cloud-outline',
  },
];

/** Add-on ids shown only for interior (Bronze/Diamond interior). */
const ADD_ON_IDS_INTERIOR = [
  'pet-hair',
  'stain-removal',
  'vomit-removal',
  'biohazard-removal',
  'seat-shampoo',
  'floor-mats-carpet-shampoo',
];

/** Add-on ids shown only for exterior (Bronze exterior). */
const ADD_ON_IDS_EXTERIOR = ['clay-bar-treatment', 'iron-tar-decontamination'];

/** Detailing service that may show exterior add-ons (clay bar, iron/tar). */
const SOFT_TOP_RESTORATION_ID = 'soft-top-restoration';

const REPAIR_ID_SET = new Set(REPAIR_PACKAGE_IDS);

/** Legacy eco wash ids on older bookings → standard wash tier id. */
export const LEGACY_ECO_SERVICE_ID_MAP: Record<string, string> = {
  'eco-bronze-wash': 'bronze-wash',
  'eco-silver-wash': 'silver-wash',
  'eco-gold-wash': 'gold-wash',
  'eco-platinum-wash': 'platinum-wash',
  'eco-emerald-wash': 'emerald-wash',
};

/**
 * Returns add-on ids that are available for the given service and (for wash) wash type.
 * - Bronze + interior: pet hair, stain removal, seats shampoo, floor mats & carpet shampoo
 * - Bronze + exterior: clay bar, iron and tar decontamination only
 * - Silver / Gold / Platinum / Diamond: all wash add-ons except repair add-ons
 * - Bronze exterior: exterior-only add-ons
 * - Detailing: no add-ons except soft-top-restoration gets clay bar + iron/tar
 * - Repair packages: wiper install, coolant, oil check, screen wash refill
 */
export function getAvailableAddOnIdsForService(
  serviceId: string,
  washType: 'interior' | 'exterior' | 'both' | '' | null,
  isDetailing: boolean
): string[] {
  const allIds = addOnOptions.map((a) => a.id);
  if (isDetailing) {
    if (REPAIR_ID_SET.has(serviceId)) {
      if (serviceId === 'maintenance-pack') return [];
      return [...REPAIR_ADD_ON_IDS];
    }
    if (serviceId === SOFT_TOP_RESTORATION_ID) return ADD_ON_IDS_EXTERIOR;
    return [];
  }
  const sid = LEGACY_ECO_SERVICE_ID_MAP[serviceId] ?? serviceId;
  switch (sid) {
    case 'bronze-wash':
      if (washType === 'interior') return ADD_ON_IDS_INTERIOR;
      if (washType === 'exterior') return ADD_ON_IDS_EXTERIOR;
      return [];
    case 'silver-wash':
      return allIds.filter((id) => !REPAIR_ADD_ON_SET.has(id));
    case 'gold-wash':
      return ['pet-hair', 'vomit-removal', 'biohazard-removal'];
    case 'emerald-wash':
    case 'platinum-wash':
      return ['vomit-removal', 'biohazard-removal'];
    default:
      if (REPAIR_ID_SET.has(sid)) return [];
      return allIds.filter((id) => !REPAIR_ADD_ON_SET.has(id));
  }
}

const ALL_BOOKING_PACKAGE_OPTIONS: ServiceOption[] = [
  ...serviceOptions,
  ...detailingServiceOptions,
  ...repairServiceOptions,
];

/** Resolve a package id from any catalogue (wash, detail, repair). Legacy eco-* maps to standard wash. */
export function findServiceOptionById(id: string): ServiceOption | undefined {
  const resolved = ALL_BOOKING_PACKAGE_OPTIONS.find((o) => o.id === id);
  if (resolved) return resolved;
  const mapped = LEGACY_ECO_SERVICE_ID_MAP[id];
  return mapped ? ALL_BOOKING_PACKAGE_OPTIONS.find((o) => o.id === mapped) : undefined;
}
