// Shared customer theme – toned down for reduced brightness and better contrast

export const customerTheme = {
  // Background gradient: muted blue to navy (softer intensity)
  backgroundGradient: ['#4A7A8E', '#152238'] as [string, string],

  // Fallback solid background
  backgroundColor: '#0A1929',

  // Header – more subtle
  headerBg: 'rgba(26,47,74,0.2)',

  // Primary colors – slightly desaturated for less glare
  skyBlue: '#6B9AAA',
  navyBlue: '#1A2F4A',
  darkNavy: '#0A1929',

  // Primary for header/nav – sky blue, not pure bright
  primary: '#7EB8D4',
};

/** Dark mode — rich navy blue (not near-black OLED dark). */
export const customerDarkTheme = {
  ...customerTheme,
  backgroundGradient: ['#243B55', '#152238'] as [string, string],
  backgroundColor: '#152238',
  headerBg: 'rgba(26,47,74,0.72)',
  navyBlue: '#1A2F4A',
  darkNavy: '#152238',
};

export { BOOKING_CARD } from './bookingCardTheme';

