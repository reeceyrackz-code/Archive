import { customerTheme } from './customerTheme';

/** Interior accent for mobile booking info / pricing pop-ups (matches Choose your package sheet). */
export const BOOKING_INFO_SHEET_ACCENT = customerTheme.primary;
