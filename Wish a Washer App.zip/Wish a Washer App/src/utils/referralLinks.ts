const APP_SCHEME = 'waw';
const WEB_JOIN_BASE = 'https://wishawash.com/join';

export function buildReferralJoinLink(referralCode: string): string {
  const code = referralCode.trim().toUpperCase();
  return `${WEB_JOIN_BASE}?code=${encodeURIComponent(code)}`;
}

export function buildReferralAppLink(referralCode: string): string {
  const code = referralCode.trim().toUpperCase();
  return `${APP_SCHEME}://join?code=${encodeURIComponent(code)}`;
}

export function buildReferralShareMessage(referralCode: string): string {
  const link = buildReferralJoinLink(referralCode);
  return (
    `Join me on Wish a Wash! Get £5 off your first booking with my referral code ${referralCode.trim().toUpperCase()}.\n\n` +
    `Tap to join: ${link}`
  );
}

export function parseReferralCodeFromUrl(url: string): string | null {
  if (!url) return null;
  try {
    const parsed = new URL(url.replace(/^waw:\/\//, 'https://waw.app/'));
    const fromQuery =
      parsed.searchParams.get('code') ??
      parsed.searchParams.get('referralCode') ??
      parsed.searchParams.get('referral');
    if (fromQuery?.trim()) {
      return fromQuery.trim().toUpperCase();
    }
  } catch {
    // fall through to regex
  }

  const match = url.match(/(?:code|referralCode|referral)=([A-Za-z0-9-]+)/i);
  return match?.[1]?.trim().toUpperCase() ?? null;
}
