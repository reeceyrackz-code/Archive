export type VehicleSizeKey = 'small' | 'medium' | 'large' | 'xl' | 'xxl';

export type PhysicalWashServiceRow = {
  id: string;
  location_id: string;
  service_name: string;
  is_enabled: boolean | null;
  price: number | string | null;
  duration_minutes: number | string | null;
  price_by_size: Record<string, unknown> | null;
};

const VEHICLE_SIZE_KEYS: VehicleSizeKey[] = ['small', 'medium', 'large', 'xl', 'xxl'];

export function normalizeVehicleSizeKey(value: unknown): VehicleSizeKey | null {
  if (typeof value !== 'string') return null;
  const key = value.trim().toLowerCase();
  if (VEHICLE_SIZE_KEYS.includes(key as VehicleSizeKey)) return key as VehicleSizeKey;
  return null;
}

export function resolveVehicleSizeKey(rawSize: unknown): VehicleSizeKey {
  return normalizeVehicleSizeKey(rawSize) ?? 'medium';
}

export function getPhysicalWashPriceBySize(
  service: Pick<PhysicalWashServiceRow, 'price_by_size' | 'price'>,
  size: VehicleSizeKey
): number | null {
  const bySize = service.price_by_size;
  if (bySize && typeof bySize === 'object') {
    const direct = bySize[size];
    const nested = typeof bySize.prices === 'object' && bySize.prices ? (bySize.prices as Record<string, unknown>)[size] : undefined;
    const raw = direct ?? nested;
    const value = typeof raw === 'number' ? raw : typeof raw === 'string' ? Number(raw) : NaN;
    if (Number.isFinite(value) && value > 0) return value;
  }

  const flat = typeof service.price === 'number' ? service.price : typeof service.price === 'string' ? Number(service.price) : NaN;
  if (Number.isFinite(flat) && flat > 0) return flat;

  return null;
}

export function getPhysicalWashAvailableSizes(service: Pick<PhysicalWashServiceRow, 'price_by_size' | 'price'>): Array<{
  key: VehicleSizeKey;
  price: number | null;
}> {
  return VEHICLE_SIZE_KEYS.map((key) => ({
    key,
    price: getPhysicalWashPriceBySize(service, key),
  }));
}

export function isBronzePhysicalWash(serviceName: string | null | undefined): boolean {
  const normalized = String(serviceName || '').trim().toLowerCase();
  return normalized.includes('bronze');
}
