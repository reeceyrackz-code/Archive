import { findServiceOptionById } from '../constants/serviceOptions';
import { supabase } from '../lib/supabase';
import { getVehicleSize } from '../pricing/pricingEngine';
import {
  getActivePlatformFeePercent,
  resolveValeterBookingPrice,
  type ValeterServiceSettingsRow,
} from '../services/ValeterPricingService';
import { syncBookingToDeviceCalendar } from '../services/BookingCalendarSync';
import { getActiveBookingForCustomer } from './activeBookingGuard';
import { ActiveBookingBlockedError } from './hubPendingPaymentBooking';

export type CreateMobileValeterBookingInput = {
  userId: string;
  valeterId: string;
  vehicleId: string;
  serviceId: string;
  location: { latitude: number; longitude: number; address: string };
  washType?: string;
  addOnIds?: string;
  addOnsTotal?: number;
  discountAmount?: number;
  serviceBasePriceGBP?: number;
  customerOffersWater?: boolean;
  customerOffersElectricity?: boolean;
  scheduledAt?: string;
};

export async function createMobileValeterBookingPendingPayment(
  input: CreateMobileValeterBookingInput
): Promise<string> {
  const active = await getActiveBookingForCustomer(input.userId);
  if (active) {
    throw new ActiveBookingBlockedError(active.id);
  }

  const serviceOption = findServiceOptionById(input.serviceId);
  const serviceName = serviceOption?.name || input.serviceId;

  const [{ data: vehicleRow }, { data: settingsRow }, platformFeePercent] = await Promise.all([
    supabase.from('customer_vehicles').select('id, type, make, model, size').eq('id', input.vehicleId).maybeSingle(),
    supabase
      .from('valeter_service_settings')
      .select('valeter_id, eco_washing, detailing_offered, detailing_menu, tier_pricing, repairs_offered, repair_menu')
      .eq('valeter_id', input.valeterId)
      .maybeSingle(),
    getActivePlatformFeePercent(),
  ]);

  const vehicleSize = vehicleRow ? getVehicleSize(vehicleRow) : null;
  const fallbackBase =
    Number.isFinite(input.serviceBasePriceGBP) && (input.serviceBasePriceGBP ?? 0) > 0
      ? (input.serviceBasePriceGBP as number)
      : (serviceOption?.price ?? 0);

  const settings = settingsRow as ValeterServiceSettingsRow | null;
  const resolvedPricing = resolveValeterBookingPrice({
    serviceId: input.serviceId,
    vehicleSize,
    fallbackBasePrice: fallbackBase,
    settings: settings
      ? {
          eco_washing: settings.eco_washing,
          detailing_offered: settings.detailing_offered,
          detailing_menu: settings.detailing_menu,
          tier_pricing: settings.tier_pricing,
          repairs_offered: settings.repairs_offered,
          repair_menu: settings.repair_menu,
        }
      : null,
    platformFeePercent,
  });

  if (!resolvedPricing.available) {
    throw new Error('This valeter does not currently offer the selected service.');
  }

  const discountAmount = input.discountAmount ?? 0;
  const addOnsTotal = input.addOnsTotal ?? 0;
  const serviceTotal = resolvedPricing.basePrice + resolvedPricing.platformFeeAmount - discountAmount;
  const finalPrice = serviceTotal + addOnsTotal;
  const scheduledAt = input.scheduledAt ?? new Date().toISOString();

  const insertRow: Record<string, unknown> = {
    user_id: input.userId,
    valeter_id: input.valeterId,
    vehicle_id: input.vehicleId,
    service_type: input.serviceId,
    service_name: serviceName,
    status: 'pending_payment',
    price: finalPrice,
    location_address: input.location.address,
    location_lat: input.location.latitude,
    location_lng: input.location.longitude,
    customer_offers_water: input.customerOffersWater ?? false,
    customer_offers_electricity: input.customerOffersElectricity ?? false,
    discount_amount: discountAmount,
    wash_type: input.washType ?? null,
    platform_fee_percent: resolvedPricing.platformFeePercent * 100,
    platform_fee_amount: resolvedPricing.platformFeeAmount,
    scheduled_at: scheduledAt,
  };

  if (input.addOnIds) insertRow.add_on_ids = input.addOnIds;
  if (addOnsTotal > 0) insertRow.add_ons_total = addOnsTotal;

  let result = await supabase.from('bookings').insert(insertRow).select('id').single();
  if (result.error && (result.error.message?.includes('add_on') || result.error.message?.includes('add_ons'))) {
    delete insertRow.add_on_ids;
    delete insertRow.add_ons_total;
    result = await supabase.from('bookings').insert(insertRow).select('id').single();
  }
  if (result.error) {
    throw new Error(result.error.message || 'Failed to create booking');
  }

  const bookingId = (result.data as { id: string }).id;

  void syncBookingToDeviceCalendar({
    id: bookingId,
    serviceName,
    serviceType: input.serviceId,
    address: input.location.address,
    scheduledAt,
  });

  return bookingId;
}
