import { supabase } from '../lib/supabase';

export type BookingChatSenderRole = 'customer' | 'valeter';
export type BookingChatMessageType = 'text' | 'image' | 'voice' | 'payment_request';

export type BookingPaymentRequestStatus = 'pending' | 'paid' | 'failed';

export type BookingPaymentRequestPayload = {
  kind?: 'booking_payment_request';
  amount?: number;
  currency?: string;
  reason?: string;
  note?: string | null;
  platformFee?: number;
  valeterShare?: number;
  status?: BookingPaymentRequestStatus;
  paymentIntentId?: string | null;
  paymentIntentClientSecret?: string | null;
  requestedAt?: string | null;
  paidAt?: string | null;
  requestedBy?: string | null;
  requestedByRole?: BookingChatSenderRole | string | null;
};

export type BookingChatMessageRow = {
  id: string;
  booking_id: string;
  sender_id: string;
  sender_role: BookingChatSenderRole;
  message_type: BookingChatMessageType;
  content?: string | null;
  media_url?: string | null;
  voice_duration_seconds?: number | null;
  read_at?: string | null;
  created_at: string;
};

export function parseBookingChatPaymentRequest(content?: string | null): BookingPaymentRequestPayload | null {
  if (!content) return null;
  try {
    const parsed = JSON.parse(content) as BookingPaymentRequestPayload;
    if (!parsed || typeof parsed !== 'object') return null;
    return parsed.kind === 'booking_payment_request' ? parsed : null;
  } catch {
    return null;
  }
}

type SendBookingChatMessageInput = {
  bookingId: string;
  senderId: string;
  senderRole: BookingChatSenderRole;
  content: string;
  mediaUrl?: string | null;
  voiceDurationSeconds?: number | null;
  messageType?: BookingChatMessageType;
};

export async function loadBookingChatMessages(bookingId: string): Promise<BookingChatMessageRow[]> {
  const { data, error } = await supabase
    .from('booking_messages')
    .select('*')
    .eq('booking_id', bookingId)
    .order('created_at', { ascending: true });

  if (error) throw error;
  return (data ?? []) as BookingChatMessageRow[];
}

export async function sendBookingChatMessage(input: SendBookingChatMessageInput): Promise<BookingChatMessageRow> {
  const row = {
    booking_id: input.bookingId,
    sender_id: input.senderId,
    sender_role: input.senderRole,
    message_type: input.messageType ?? (input.mediaUrl ? 'image' : 'text'),
    content: input.content.trim() || null,
    media_url: input.mediaUrl ?? null,
    voice_duration_seconds: input.voiceDurationSeconds ?? null,
  };

  const { data, error } = await supabase
    .from('booking_messages')
    .insert(row)
    .select('*')
    .single();

  if (error) throw error;

  const now = new Date().toISOString();
  await supabase.from('bookings').update({ updated_at: now }).eq('id', input.bookingId);

  return data as BookingChatMessageRow;
}

export function subscribeToBookingChatMessages(
  bookingId: string,
  onInsert: (message: BookingChatMessageRow) => void,
) {
  const handler = (payload: { new?: BookingChatMessageRow | null; old?: BookingChatMessageRow | null }) => {
    const row = (payload.new ?? payload.old) as BookingChatMessageRow | undefined;
    if (row) onInsert(row);
  };

  return supabase
    .channel(`booking-chat-${bookingId}`)
    .on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'booking_messages',
        filter: `booking_id=eq.${bookingId}`,
      },
      handler,
    )
    .on(
      'postgres_changes',
      {
        event: 'UPDATE',
        schema: 'public',
        table: 'booking_messages',
        filter: `booking_id=eq.${bookingId}`,
      },
      handler,
    )
    .subscribe();
}
