import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { customerTheme, customerDarkTheme } from '../constants/customerTheme';

const THEME_STORAGE_KEY = 'app_theme_dark';

export type ColorScheme = 'light' | 'dark';

/** Light mode = current UI (muted blue–navy gradient). Cards keep same colours. */
export const lightTheme = customerTheme;

/** Dark mode — navy blue wash (aligned with accountThemes dark backgrounds). */
export const darkTheme = customerDarkTheme;

export type AppTheme = typeof lightTheme;

type ThemeContextValue = {
  colorScheme: ColorScheme;
  isDark: boolean;
  theme: AppTheme;
  setColorScheme: (scheme: ColorScheme) => void;
  toggleDarkMode: () => void;
};

const ThemeContext = createContext<ThemeContextValue | null>(null);

export function ThemeProvider({ children }: Readonly<{ children: React.ReactNode }>) {
  const [colorScheme, setColorScheme] = useState<ColorScheme>('light');

  useEffect(() => {
    AsyncStorage.getItem(THEME_STORAGE_KEY).then((stored) => {
      if (stored === 'dark') setColorScheme('dark');
      else if (stored === 'light') setColorScheme('light');
    });
  }, []);

  const persistAndSetColorScheme = useCallback((scheme: ColorScheme) => {
    setColorScheme(scheme);
    AsyncStorage.setItem(THEME_STORAGE_KEY, scheme);
  }, []);

  const toggleDarkMode = useCallback(() => {
    setColorScheme((prev) => {
      const next = prev === 'dark' ? 'light' : 'dark';
      AsyncStorage.setItem(THEME_STORAGE_KEY, next);
      return next;
    });
  }, []);

  const value = useMemo(
    () => ({
      colorScheme,
      isDark: colorScheme === 'dark',
      theme: colorScheme === 'dark' ? darkTheme : lightTheme,
      setColorScheme: persistAndSetColorScheme,
      toggleDarkMode,
    }),
    [colorScheme, persistAndSetColorScheme, toggleDarkMode]
  );

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme(): ThemeContextValue {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useTheme must be used within ThemeProvider');
  return ctx;
}

export function useThemeOptional(): ThemeContextValue | null {
  return useContext(ThemeContext);
}
