import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ViewStyle } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';
import * as Haptics from 'expo-haptics';

const SKY = colors.SKY;

export type WashTier = 'Bronze' | 'Silver' | 'Gold';

interface WashTierCardProps {
  tier: WashTier;
  /** Card title; defaults to tier name (e.g. matches catalogue `name`). */
  heading?: string;
  duration: string;
  perks: string[];
  selected?: boolean;
  onPress?: () => void;
  onInfoPress?: () => void;
  style?: ViewStyle;
}

const TIER_COLORS: Record<WashTier, { primary: string; secondary: string; icon: string }> = {
  Bronze: {
    primary: '#CD7F32',
    secondary: 'rgba(205, 127, 50, 0.22)',
    icon: 'medal',
  },
  Silver: {
    primary: '#C0C0C0',
    secondary: 'rgba(192, 192, 192, 0.22)',
    icon: 'star',
  },
  Gold: {
    primary: '#FFD700',
    secondary: 'rgba(255, 215, 0, 0.22)',
    icon: 'diamond',
  },
};

export default function WashTierCard({
  tier,
  heading,
  duration,
  perks,
  selected = false,
  onPress,
  onInfoPress,
  style,
}: WashTierCardProps) {
  const tierColors = TIER_COLORS[tier];
  const preview =
    perks.length > 0 ? perks.slice(0, 2).join(' · ') : 'Tap for full details';

  const handlePress = () => {
    if (onPress) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      onPress();
    }
  };

  return (
    <TouchableOpacity
      onPress={handlePress}
      activeOpacity={0.82}
      style={[
        styles.row,
        selected && styles.rowSelected,
        { borderLeftColor: tierColors.primary },
        style,
      ]}
    >
      <LinearGradient
        colors={
          selected
            ? ['rgba(255,255,255,0.1)', 'rgba(255,255,255,0.03)']
            : ['rgba(255,255,255,0.06)', 'rgba(255,255,255,0.02)']
        }
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={StyleSheet.absoluteFill}
      />
      <View style={[styles.leadingRing, { borderColor: tierColors.primary }]}>
        <View style={[styles.leadingInner, { backgroundColor: tierColors.secondary }]}>
          <Ionicons name={tierColors.icon as any} size={22} color={tierColors.primary} />
        </View>
      </View>

      <View style={styles.body}>
        <View style={styles.titleRow}>
          <Text style={styles.tierName} numberOfLines={2}>
            {heading ?? tier}
          </Text>
          {onInfoPress ? (
            <TouchableOpacity
              onPress={(e) => {
                e?.stopPropagation?.();
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                onInfoPress();
              }}
              hitSlop={10}
              style={[styles.infoHit, { borderColor: tierColors.primary + '40', backgroundColor: tierColors.primary + '15' }]}
            >
              <Ionicons name="information-circle-outline" size={22} color={tierColors.primary} />
            </TouchableOpacity>
          ) : null}
        </View>
        <Text style={styles.duration} numberOfLines={1}>
          {duration}
        </Text>
        <Text style={styles.preview} numberOfLines={2}>
          {preview}
        </Text>
      </View>

      <View style={styles.trailing}>
        <Text style={[styles.priceDisclaimer, { color: tierColors.primary }]}>Prices vary</Text>
        {selected ? (
          <Ionicons name="checkmark-circle" size={26} color={tierColors.primary} style={styles.check} />
        ) : (
          <Ionicons name="chevron-forward" size={20} color="rgba(148,163,184,0.7)" style={styles.check} />
        )}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.18)',
    borderLeftWidth: 4,
    paddingVertical: 14,
    paddingHorizontal: 14,
    paddingLeft: 12,
    position: 'relative',
  },
  rowSelected: {
    borderColor: 'rgba(135,206,235,0.35)',
  },
  leadingRing: {
    width: 52,
    height: 52,
    borderRadius: 26,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  leadingInner: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  body: {
    flex: 1,
    minWidth: 0,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 8,
    marginBottom: 2,
  },
  tierName: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
    letterSpacing: -0.2,
    flex: 1,
  },
  infoHit: {
    marginLeft: 4,
    padding: 6,
    borderRadius: 10,
    borderWidth: 1,
  },
  duration: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 4,
  },
  preview: {
    color: 'rgba(226,232,240,0.82)',
    fontSize: 12,
    fontWeight: '500',
    lineHeight: 16,
  },
  trailing: {
    alignItems: 'flex-end',
    marginLeft: 10,
    minWidth: 88,
    justifyContent: 'center',
  },
  priceDisclaimer: {
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 0.2,
    textAlign: 'right',
    marginBottom: 6,
    maxWidth: 92,
  },
  check: {
    marginTop: 2,
  },
});
