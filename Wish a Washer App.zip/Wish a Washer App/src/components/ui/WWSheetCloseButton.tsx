import React, { useRef } from 'react';
import {
  TouchableOpacity,
  StyleSheet,
  Animated,
  ActivityIndicator,
  type ViewStyle,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { bookingContinueChromeBorder } from '../../utils/bookingContinueStyle';

const PRESS_SCALE = 0.96;
const SKY = colors.SKY ?? '#38BDF8';

export interface WWSheetCloseButtonProps {
  onPress: () => void;
  accessibilityLabel?: string;
  style?: ViewStyle;
  /** Touch target width and height (default 48). */
  size?: number;
  iconSize?: number;
  iconColor?: string;
  loading?: boolean;
  disabled?: boolean;
  hitSlop?: { top?: number; bottom?: number; left?: number; right?: number } | number;
  /** `bordered` = glass ring on booking / tracking bottom sheets; `plain` = borderless icon */
  variant?: 'plain' | 'bordered';
  /** Override ring color when `variant` is `bordered` */
  borderColor?: string;
}

function borderedRingColor(iconColor: string, borderColor?: string): string {
  if (borderColor) return borderColor;
  const normalized = iconColor.trim().toUpperCase();
  if (normalized === '#EF4444' || normalized === '#F87171' || normalized === '#FCA5A5') {
    return 'rgba(239,68,68,0.55)';
  }
  const lightIcons = new Set(['#F1F5F9', '#F8FAFC', '#FFFFFF', '#E2E8F0', colors.textOnDarkPrimary.toUpperCase()]);
  if (lightIcons.has(normalized)) {
    return bookingContinueChromeBorder(SKY);
  }
  if (normalized.startsWith('#') && normalized.length === 7) {
    return bookingContinueChromeBorder(iconColor);
  }
  return 'rgba(148,163,184,0.35)';
}

/**
 * Dismiss / exit control for sheets, modals, and headers.
 */
export default function WWSheetCloseButton({
  onPress,
  accessibilityLabel = 'Close',
  style,
  size = 48,
  iconSize = 22,
  iconColor = colors.textOnDarkPrimary,
  loading = false,
  disabled = false,
  hitSlop = { top: 8, bottom: 8, left: 8, right: 8 },
  variant = 'plain',
  borderColor,
}: WWSheetCloseButtonProps) {
  const scaleAnim = useRef(new Animated.Value(1)).current;
  const borderRadius = size / 2;
  const isDisabled = disabled || loading;
  const isBordered = variant === 'bordered';

  const handlePress = () => {
    if (isDisabled) return;
    hapticFeedback('medium');
    onPress();
  };

  return (
    <Animated.View style={[{ transform: [{ scale: scaleAnim }] }, style]}>
      <TouchableOpacity
        onPress={handlePress}
        onPressIn={() => {
          if (isDisabled) return;
          Animated.spring(scaleAnim, { toValue: PRESS_SCALE, useNativeDriver: true, speed: 50 }).start();
        }}
        onPressOut={() => {
          Animated.spring(scaleAnim, { toValue: 1, useNativeDriver: true, speed: 50 }).start();
        }}
        hitSlop={hitSlop}
        disabled={isDisabled}
        activeOpacity={0.72}
        accessibilityRole="button"
        accessibilityLabel={accessibilityLabel}
        style={[
          styles.container,
          { width: size, height: size, borderRadius },
          isBordered && [
            styles.bordered,
            { borderColor: borderedRingColor(iconColor, borderColor) },
          ],
          isDisabled && styles.disabled,
        ]}
      >
        {loading ? (
          <ActivityIndicator size="small" color={iconColor} />
        ) : (
          <Ionicons name="close" size={iconSize} color={iconColor} />
        )}
      </TouchableOpacity>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  bordered: {
    borderWidth: 1,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  disabled: {
    opacity: 0.55,
  },
});
