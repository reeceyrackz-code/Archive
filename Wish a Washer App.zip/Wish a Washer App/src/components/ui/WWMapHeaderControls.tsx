import React from 'react';
import { View, TouchableOpacity, StyleSheet, Platform } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import {
  BOOKING_CONTINUE_RADIUS,
  appHeaderChromeIconButtonStyle,
  bookingContinueGradient,
  bookingContinueHeaderBarShadow,
} from '../../utils/bookingContinueStyle';
import WWSheetCloseButton from './WWSheetCloseButton';

interface WWMapHeaderControlsProps {
  onBack?: () => void;
  onLocate?: () => void;
  onClose?: () => void;
  showBack?: boolean;
  showLocate?: boolean;
  showClose?: boolean;
}

const R = BOOKING_CONTINUE_RADIUS;

export default function WWMapHeaderControls({
  onBack,
  onLocate,
  onClose,
  showBack = true,
  showLocate = true,
  showClose = false,
}: WWMapHeaderControlsProps) {
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const accent = theme.primary;
  const [g0, g1] = bookingContinueGradient(accent);

  return (
    <View pointerEvents="box-none" style={styles.wrap}>
      <View
        style={[
          styles.chromeBar,
          bookingContinueHeaderBarShadow(accent),
          {
            width: '100%',
            borderBottomLeftRadius: R,
            borderBottomRightRadius: R,
            paddingTop: insets.top,
          },
        ]}
      >
        <BlurView
          intensity={Platform.OS === 'ios' ? 78 : 96}
          tint="dark"
          style={[styles.blurLayer, { borderBottomLeftRadius: R, borderBottomRightRadius: R }]}
          {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
        />
        <LinearGradient
          colors={[g0, g1]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={[styles.tintLayer, { borderBottomLeftRadius: R, borderBottomRightRadius: R }]}
        />
        <View
          pointerEvents="none"
          style={[
            styles.glassStroke,
            {
              borderBottomLeftRadius: R,
              borderBottomRightRadius: R,
            },
          ]}
        />
        <View style={styles.row}>
          {showBack && onBack ? (
            <TouchableOpacity
              onPress={onBack}
              activeOpacity={0.82}
              accessibilityRole="button"
              accessibilityLabel="Go back"
              style={appHeaderChromeIconButtonStyle()}
            >
              <Ionicons name="chevron-back" size={22} color="#FFFFFF" />
            </TouchableOpacity>
          ) : (
            <View style={{ width: 40 }} />
          )}
          <View style={styles.spacer} />
          <View style={styles.right}>
            {showLocate && onLocate && (
              <TouchableOpacity
                onPress={onLocate}
                activeOpacity={0.82}
                accessibilityRole="button"
                accessibilityLabel="Center map on my location"
                style={appHeaderChromeIconButtonStyle()}
              >
                <Ionicons name="locate" size={20} color="#FFFFFF" />
              </TouchableOpacity>
            )}
            {showClose && onClose && (
              <WWSheetCloseButton
                size={40}
                iconSize={22}
                iconColor="#FFFFFF"
                onPress={onClose}
                accessibilityLabel="Close"
              />
            )}
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    width: '100%',
  },
  chromeBar: {
    overflow: 'hidden',
    backgroundColor: 'rgba(15,23,42,0.35)',
    position: 'relative',
  },
  blurLayer: {
    ...StyleSheet.absoluteFillObject,
  },
  tintLayer: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.82,
  },
  glassStroke: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: 1,
    borderTopWidth: 0,
    borderColor: 'rgba(255,255,255,0.22)',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 8,
    minHeight: 52,
    zIndex: 10,
    position: 'relative',
  },
  spacer: { flex: 1 },
  right: { flexDirection: 'row', alignItems: 'center', gap: 8 },
});
