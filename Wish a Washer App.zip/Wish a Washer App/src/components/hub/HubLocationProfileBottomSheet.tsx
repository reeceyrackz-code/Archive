/**
 * Wash location profile — bottom sheet matching ValeterProfileBottomSheet chrome.
 * Loads address, hours, services tags, stats, and bio from Supabase when possible.
 */
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  Pressable,
  ScrollView,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  useWindowDimensions,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../../lib/supabase';
import { colors } from '../../constants/colors';
import {
  CUSTOMER_BOOKING_SHEET_TOP_RADIUS,
  HEADER_STYLE_CARD_BORDER,
  HEADER_STYLE_CARD_GRADIENT,
  BOOKING_SHEET_DARK_OVERLAY,
  getIndexTrackingCardWidth,
} from '../../constants/bookingCardTheme';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { ccpCountLabel } from '../../constants/carCareProLabels';
import { MOBILE_SERVICE_ONLY_LAUNCH } from '../../constants/launchCustomerScope';
import { WWPrimaryButton, WWSheetCloseButton } from '../ui';
import OpeningHoursSheet, { type OpeningHourRow } from '../shared/OpeningHoursSheet';
import { pickCarWashLocationProfileImageUrl } from '../../utils/carWashLocationMedia';
import { WashHubPlaceholder } from '../shared/washValeterPlaceholders';
import SheetQuickIcon, { type SheetQuickIconPreset } from '../shared/SheetQuickIcon';
import ProfileSheetReviewsSection, { type ProfileSheetReviewItem } from '../profile/ProfileSheetReviewsSection';
import BusinessSheetBackground from '../shared/BusinessSheetBackground';

const SKY = colors.SKY;
const SHEET_MAX_RATIO = 0.92;

const DAY_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

function formatHHMM(t: string | null | undefined): string {
  if (!t) return '—';
  return t.slice(0, 5);
}

function formatTodayHoursLine(hours: OpeningHourRow[]): string {
  if (!hours.length) return 'Hours not listed';
  const dow = new Date().getDay();
  const row = hours.find((h) => h.day_of_week === dow);
  const dayLabel = DAY_NAMES[dow] ?? 'Today';
  if (!row) return `${dayLabel} · Hours not set`;
  if (!row.is_open) return `${dayLabel} · Closed`;
  return `${dayLabel} · ${formatHHMM(row.open_time)} – ${formatHHMM(row.close_time)}`;
}

function readBio(raw: Record<string, unknown>): string | null {
  for (const k of ['description', 'bio', 'about', 'notes']) {
    const v = raw[k];
    if (typeof v === 'string' && v.trim().length > 0) return v.trim();
  }
  const svc = raw.services_offered;
  if (typeof svc === 'string' && svc.trim().length > 0) return svc.trim();
  return null;
}

function offersRepairs(raw: Record<string, unknown>): boolean {
  const s = raw.services_offered;
  const t = typeof s === 'string' ? s.toLowerCase() : '';
  return t.includes('repair') || t.includes('body') || t.includes('mechanic');
}

export type HubLocationSheetSeed = {
  id: string;
  name?: string;
  rating?: number;
  jobsCompleted?: number;
};

type LoadedHub = {
  name: string;
  address: string | null;
  rating: number;
  totalReviews: number;
  completedJobs: number;
  valeterCount: number;
  profileImageUrl: string | null;
  detailingOffered: boolean;
  ecoWashing: boolean;
  offersMobile: boolean;
  repairsOffered: boolean;
  bio: string | null;
  openingHours: OpeningHourRow[];
};

const DEFAULT_BIO =
  "This wash location hasn't added a full description yet. Book a slot to visit on-site washing, valeting, and more.";

export default function HubLocationProfileBottomSheet({
  visible,
  onClose,
  locationId,
  seed,
  onRequestBook,
}: {
  visible: boolean;
  onClose: () => void;
  locationId: string | null;
  seed?: HubLocationSheetSeed | null;
  onRequestBook: (hubId: string) => void | Promise<void>;
}) {
  const insets = useSafeAreaInsets();
  const { height: windowH, width: windowW } = useWindowDimensions();
  const sheetMaxHeight = Math.round(windowH * SHEET_MAX_RATIO);

  const [loading, setLoading] = useState(false);
  const [extra, setExtra] = useState<LoadedHub | null>(null);
  const [imageFailed, setImageFailed] = useState(false);
  const [hoursSheetOpen, setHoursSheetOpen] = useState(false);
  const [reviews, setReviews] = useState<ProfileSheetReviewItem[]>([]);
  const [reviewsLoading, setReviewsLoading] = useState(false);
  const [photoExpanded, setPhotoExpanded] = useState(false);

  const load = useCallback(async () => {
    if (!locationId || locationId.trim() === '') return;
    setLoading(true);
    setImageFailed(false);
    try {
      const { data: hubRow, error: hubErr } = await supabase.from('car_wash_locations').select('*').eq('id', locationId).maybeSingle();
      if (hubErr || !hubRow) {
        setExtra(null);
        return;
      }
      const raw = hubRow as Record<string, unknown>;

      const { data: hoursData } = await supabase
        .from('location_opening_hours')
        .select('day_of_week,is_open,open_time,close_time')
        .eq('location_id', locationId)
        .order('day_of_week');
      const openingHours = ((hoursData || []) as OpeningHourRow[]).sort((a, b) => a.day_of_week - b.day_of_week);

      const { count: completedCount } = await supabase
        .from('bookings')
        .select('id', { count: 'exact', head: true })
        .eq('location_id', locationId)
        .eq('status', 'completed');
      const jobsFallback = seed?.jobsCompleted ?? 0;

      const { data: valeterRows } = await supabase
        .from('bookings')
        .select('valeter_id')
        .eq('location_id', locationId)
        .not('valeter_id', 'is', null)
        .limit(400);
      const vSet = new Set<string>();
      (valeterRows || []).forEach((r: { valeter_id?: string | null }) => {
        if (r.valeter_id) vSet.add(r.valeter_id);
      });

      const bio = readBio(raw);
      setExtra({
        name: String(raw.name ?? seed?.name ?? 'Wash location'),
        address: raw.address != null ? String(raw.address) : null,
        rating: raw.rating != null ? Number(raw.rating) : seed?.rating ?? 0,
        totalReviews: raw.total_reviews != null ? Number(raw.total_reviews) : 0,
        completedJobs: typeof completedCount === 'number' ? completedCount : jobsFallback,
        valeterCount: Math.max(vSet.size, 0),
        profileImageUrl: pickCarWashLocationProfileImageUrl(raw),
        detailingOffered: raw.detailing_offered === true,
        ecoWashing: raw.eco_washing === true,
        offersMobile: raw.offers_mobile === true,
        repairsOffered: offersRepairs(raw),
        bio,
        openingHours,
      });
    } catch {
      setExtra(null);
    } finally {
      setLoading(false);
    }
  }, [locationId, seed]);

  useEffect(() => {
    if (!visible || !locationId) {
      setExtra(null);
      return;
    }
    void load();
  }, [visible, locationId, load]);

  useEffect(() => {
    if (!visible || !locationId) {
      setReviews([]);
      return;
    }
    let cancelled = false;
    (async () => {
      setReviewsLoading(true);
      try {
        const { data, error } = await supabase
          .from('bookings')
          .select('id,rating,review,completed_at,user_id')
          .eq('location_id', locationId)
          .eq('status', 'completed')
          .not('rating', 'is', null)
          .order('completed_at', { ascending: false })
          .limit(8);
        if (cancelled || error || !data?.length) {
          if (!cancelled) setReviews([]);
          return;
        }
        const userIds = [...new Set(data.map((r: { user_id?: string }) => r.user_id).filter(Boolean))] as string[];
        const nameBy = new Map<string, string>();
        if (userIds.length) {
          const { data: profs } = await supabase.from('profiles').select('id,full_name').in('id', userIds);
          (profs || []).forEach((p: { id: string; full_name?: string | null }) => {
            nameBy.set(p.id, p.full_name?.trim() || 'Customer');
          });
        }
        if (!cancelled) {
          setReviews(
            data.map((r: { id: string; rating?: number | null; review?: string | null; user_id?: string; completed_at?: string | null }) => ({
              id: String(r.id),
              rating: Number(r.rating) || 0,
              body: r.review?.trim() || null,
              author: (r.user_id && nameBy.get(r.user_id)) || 'Customer',
              completedAt: r.completed_at ?? null,
            }))
          );
        }
      } catch {
        if (!cancelled) setReviews([]);
      } finally {
        if (!cancelled) setReviewsLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [visible, locationId]);

  useEffect(() => {
    if (!visible) setPhotoExpanded(false);
  }, [visible]);

  const merged = useMemo(() => {
    const name = extra?.name || seed?.name || 'Wash location';
    const rating = extra?.rating ?? seed?.rating ?? 0;
    const jobs = extra?.completedJobs ?? seed?.jobsCompleted ?? 0;
    return {
      name,
      rating,
      jobs,
      address: extra?.address ?? null,
      totalReviews: extra?.totalReviews ?? 0,
      valeterCount: extra?.valeterCount ?? 0,
      photo: extra?.profileImageUrl ?? null,
      detailingOffered: extra?.detailingOffered ?? false,
      ecoWashing: extra?.ecoWashing ?? false,
      offersMobile: extra?.offersMobile ?? false,
      repairsOffered: extra?.repairsOffered ?? false,
      bioText: extra?.bio?.trim() || null,
      openingHours: extra?.openingHours ?? [],
    };
  }, [extra, seed]);

  const bioParagraph = merged.bioText || DEFAULT_BIO;
  const todayLine = formatTodayHoursLine(merged.openingHours);

  const tags = useMemo(() => {
    const list: { key: string; label: string; icon: keyof typeof Ionicons.glyphMap }[] = [
      { key: 'wash', label: 'Washing', icon: 'water' },
    ];
    if (merged.detailingOffered) list.push({ key: 'detail', label: 'Detailing', icon: 'diamond-outline' });
    if (merged.repairsOffered) list.push({ key: 'repair', label: 'Repairs', icon: 'construct-outline' });
    if (merged.ecoWashing) list.push({ key: 'eco', label: 'Eco wash', icon: 'leaf-outline' });
    if (merged.offersMobile) list.push({ key: 'mobile', label: 'Mobile', icon: 'car-outline' });
    return list;
  }, [merged.detailingOffered, merged.ecoWashing, merged.offersMobile, merged.repairsOffered]);

  if (!locationId) return null;

  return (
    <>
      <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
        <View style={styles.root}>
          <Pressable style={StyleSheet.absoluteFill} onPress={onClose} accessibilityLabel="Dismiss hub profile" />
          <View
            style={[
              styles.panel,
              { borderColor: HEADER_STYLE_CARD_BORDER, maxHeight: sheetMaxHeight, paddingBottom: Math.max(14, insets.bottom) },
            ]}
          >
            <BusinessSheetBackground />
            <View style={[styles.rail, { backgroundColor: SKY + '99', shadowColor: SKY }]} pointerEvents="none" />
            <View style={styles.handle} />

            <ScrollView
              showsVerticalScrollIndicator={false}
              keyboardShouldPersistTaps="handled"
              contentContainerStyle={styles.scrollContent}
            >
              <View style={styles.heroRow}>
                <TouchableOpacity
                  activeOpacity={merged.photo && !imageFailed ? 0.88 : 1}
                  disabled={!merged.photo || imageFailed}
                  onPress={() => {
                    void hapticFeedback('light');
                    setPhotoExpanded(true);
                  }}
                  accessibilityRole="button"
                  accessibilityLabel="View location photo"
                >
                  <View style={styles.avatarRing}>
                    {merged.photo && !imageFailed ? (
                      <Image source={{ uri: merged.photo }} style={styles.avatarImg} onError={() => setImageFailed(true)} />
                    ) : (
                      <WashHubPlaceholder width={72} height={72} borderRadius={19} style={styles.avatarImgFill} iconName="business-outline" />
                    )}
                    {merged.photo && !imageFailed ? (
                      <View style={styles.avatarExpandHint} pointerEvents="none">
                        <Ionicons name="expand-outline" size={12} color="#F8FAFC" />
                      </View>
                    ) : null}
                  </View>
                </TouchableOpacity>
                <View style={styles.heroTextCol}>
                  <Text style={styles.name} numberOfLines={2}>
                    {merged.name}
                  </Text>
                  <Text style={styles.kicker}>Wash location</Text>
                  <View style={styles.metaPills}>
                    <View style={styles.pill}>
                      <Ionicons name="star" size={14} color="#FBBF24" />
                      <Text style={styles.pillText}>{merged.rating > 0 ? merged.rating.toFixed(1) : 'New'}</Text>
                    </View>
                    <View style={styles.pill}>
                      <Ionicons name="checkmark-done-outline" size={14} color={SKY} />
                      <Text style={styles.pillText}>{merged.jobs} completed</Text>
                    </View>
                    {merged.totalReviews > 0 ? (
                      <View style={styles.pill}>
                        <Ionicons name="chatbubbles-outline" size={14} color={SKY} />
                        <Text style={styles.pillText}>{merged.totalReviews} reviews</Text>
                      </View>
                    ) : null}
                    {merged.valeterCount > 0 ? (
                      <View style={styles.pill}>
                        <Ionicons name="people-outline" size={14} color={SKY} />
                        <Text style={styles.pillText}>
                          {ccpCountLabel(merged.valeterCount)}
                        </Text>
                      </View>
                    ) : null}
                  </View>
                </View>
                <WWSheetCloseButton onPress={onClose} hitSlop={14} accessibilityLabel="Close" />
              </View>

              {merged.address ? (
                <View style={styles.section}>
                  <Text style={styles.sectionLabel}>Address</Text>
                  <View style={styles.aboutCard}>
                    <View style={styles.addressRow}>
                      <SheetQuickIcon icon="map" preset="purple" />
                      <Text style={styles.addressText}>{merged.address}</Text>
                    </View>
                  </View>
                </View>
              ) : null}

              <View style={styles.section}>
                <Text style={styles.sectionLabel}>Today&apos;s hours</Text>
                <Pressable
                  onPress={() => {
                    void hapticFeedback('light');
                    setHoursSheetOpen(true);
                  }}
                  style={styles.hoursTapCard}
                >
                  <SheetQuickIcon icon="time-outline" preset="cyan" />
                  <View style={styles.hoursTapTextCol}>
                    <Text style={styles.hoursTapPrimary}>{todayLine}</Text>
                    <Text style={styles.hoursTapHint}>Tap for full week</Text>
                  </View>
                  <Ionicons name="chevron-forward" size={18} color="rgba(148,163,184,0.9)" />
                </Pressable>
              </View>

              <View style={styles.section}>
                <Text style={styles.sectionLabel}>Services</Text>
                <View style={styles.tagsWrap}>
                  {tags.map((t) => (
                    <View key={t.key} style={styles.tagChip}>
                      <SheetQuickIcon icon={t.icon} preset={t.preset} size="chip" />
                      <Text style={styles.tagChipText}>{t.label}</Text>
                    </View>
                  ))}
                </View>
              </View>

              <View style={styles.section}>
                <Text style={styles.sectionLabel}>About</Text>
                <View style={styles.aboutCard}>
                  {loading && !extra ? (
                    <ActivityIndicator color={SKY} style={{ marginVertical: 8 }} />
                  ) : (
                    <Text style={styles.aboutBody}>{bioParagraph}</Text>
                  )}
                </View>
              </View>

              <ProfileSheetReviewsSection
                reviews={reviews}
                loading={reviewsLoading}
                reviewCount={merged.totalReviews}
              />
            </ScrollView>

            {!MOBILE_SERVICE_ONLY_LAUNCH ? (
            <WWPrimaryButton
              title="Book this location"
              onPress={() => {
                void hapticFeedback('medium');
                void Promise.resolve(onRequestBook(locationId));
              }}
              leftIconName="calendar-outline"
              leftIconSize={22}
              style={{
                alignSelf: 'center',
                width: getIndexTrackingCardWidth(windowW),
                marginTop: 4,
                marginBottom: 4,
              }}
            />
            ) : null}
          </View>
        </View>
      </Modal>

      <Modal
        visible={photoExpanded && Boolean(merged.photo) && !imageFailed}
        transparent
        animationType="fade"
        onRequestClose={() => setPhotoExpanded(false)}
      >
        <View style={styles.photoViewerRoot}>
          <Pressable
            style={StyleSheet.absoluteFill}
            onPress={() => setPhotoExpanded(false)}
            accessibilityLabel="Close location photo"
          />
          <View style={[styles.photoViewerTopBar, { paddingTop: insets.top + 8 }]}>
            <WWSheetCloseButton
              size={44}
              iconSize={26}
              iconColor="#FFFFFF"
              onPress={() => setPhotoExpanded(false)}
              accessibilityLabel="Close location photo"
            />
          </View>
          {merged.photo ? (
            <Image source={{ uri: merged.photo }} style={styles.photoViewerImage} resizeMode="contain" />
          ) : null}
        </View>
      </Modal>

      <OpeningHoursSheet
        visible={hoursSheetOpen}
        onClose={() => setHoursSheetOpen(false)}
        hours={merged.openingHours}
        accentColor={SKY}
        title="Opening hours"
      />
    </>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(2,6,23,0.55)',
  },
  panel: {
    borderTopLeftRadius: CUSTOMER_BOOKING_SHEET_TOP_RADIUS,
    borderTopRightRadius: CUSTOMER_BOOKING_SHEET_TOP_RADIUS,
    borderWidth: 1,
    borderBottomWidth: 0,
    overflow: 'hidden',
  },
  sheetDarkScrim: {
    backgroundColor: BOOKING_SHEET_DARK_OVERLAY,
  },
  rail: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 2,
    opacity: 0.85,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.45,
    shadowRadius: 8,
  },
  handle: {
    alignSelf: 'center',
    width: 44,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(148,163,184,0.45)',
    marginTop: 10,
    marginBottom: 6,
  },
  scrollContent: {
    paddingHorizontal: 18,
    paddingBottom: 12,
  },
  heroRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 14,
    gap: 12,
  },
  avatarRing: {
    width: 76,
    height: 76,
    borderRadius: 22,
    padding: 2,
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.22)',
    backgroundColor: 'rgba(15,23,42,0.35)',
    overflow: 'hidden',
  },
  avatarImg: {
    width: '100%',
    height: '100%',
    borderRadius: 19,
  },
  avatarImgFill: {
    width: '100%',
    height: '100%',
  },
  avatarExpandHint: {
    position: 'absolute',
    left: 4,
    bottom: 4,
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: 'rgba(15,23,42,0.72)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
  },
  heroTextCol: {
    flex: 1,
    minWidth: 0,
    paddingTop: 2,
  },
  name: {
    color: '#F8FAFC',
    fontSize: 22,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  kicker: {
    marginTop: 4,
    color: 'rgba(226,232,240,0.72)',
    fontSize: 13,
    fontWeight: '600',
  },
  metaPills: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 10,
  },
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 14,
    backgroundColor: 'rgba(15,23,42,0.55)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.22)',
  },
  pillText: {
    color: 'rgba(248,250,252,0.92)',
    fontSize: 12,
    fontWeight: '700',
  },
  section: {
    marginBottom: 16,
  },
  sectionLabel: {
    color: 'rgba(226,232,240,0.88)',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.1,
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  aboutCard: {
    borderRadius: 18,
    padding: 14,
    backgroundColor: 'rgba(15,23,42,0.52)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.2)',
  },
  aboutBody: {
    color: 'rgba(248,250,252,0.92)',
    fontSize: 15,
    lineHeight: 22,
    fontWeight: '500',
  },
  addressRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
  },
  addressText: {
    flex: 1,
    color: 'rgba(248,250,252,0.92)',
    fontSize: 15,
    lineHeight: 22,
    fontWeight: '600',
  },
  hoursTapCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderRadius: 18,
    padding: 14,
    backgroundColor: 'rgba(15,23,42,0.52)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.2)',
  },
  hoursTapTextCol: {
    flex: 1,
    minWidth: 0,
  },
  hoursTapPrimary: {
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '700',
  },
  hoursTapHint: {
    marginTop: 4,
    color: 'rgba(148,163,184,0.9)',
    fontSize: 12,
    fontWeight: '600',
  },
  tagsWrap: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  tagChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 14,
    backgroundColor: 'rgba(15,23,42,0.55)',
    borderWidth: 1,
    borderColor: 'rgba(56,189,248,0.28)',
  },
  tagChipText: {
    color: 'rgba(248,250,252,0.92)',
    fontSize: 12,
    fontWeight: '700',
  },
  photoViewerRoot: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.94)',
    justifyContent: 'center',
  },
  photoViewerTopBar: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 2,
    paddingHorizontal: 16,
    alignItems: 'flex-end',
  },
  photoViewerImage: {
    width: '100%',
    height: '78%',
    alignSelf: 'center',
  },
});
