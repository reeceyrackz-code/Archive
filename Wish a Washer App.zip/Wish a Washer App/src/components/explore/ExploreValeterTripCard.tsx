import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';
import {
  BOOKING_CARD,
  BOOKING_GLASS_TOP_SHEEN,
  BOOKING_GLASS_TOP_SHEEN_LOCATIONS,
} from '../../constants/bookingCardTheme';
import { formatDisplayName } from '../../utils/formatDisplayName';
import GradientIconBox from '../shared/GradientIconBox';
import { accentToGradient } from '../../utils/accentGradient';
import { CCP } from '../../constants/carCareProLabels';

const SKY = colors.SKY;

export type ExploreValeterCardData = {
  id: string;
  name: string;
  rating: number;
  totalJobs: number;
  distance: number | null;
  isOnline: boolean;
  profilePicture?: string | null;
  isFavourite?: boolean;
};

type Props = {
  valeter: ExploreValeterCardData;
  width: number;
  accent: string;
  borderColor: string;
  onPress: () => void;
  onBook: () => void;
  onToggleFavourite?: () => void;
};

export default function ExploreValeterTripCard({
  valeter: v,
  width,
  accent,
  borderColor,
  onPress,
  onBook,
  onToggleFavourite,
}: Props) {
  return (
    <View style={[styles.wrap, { width }]}>
      <View style={[styles.card, { borderColor }]}>
        <BlurView intensity={50} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
        <LinearGradient
          colors={[accent + '18', 'transparent']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
        />
        <LinearGradient
          colors={[...BOOKING_GLASS_TOP_SHEEN]}
          locations={[...BOOKING_GLASS_TOP_SHEEN_LOCATIONS]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0.85 }}
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
        />
        <View style={styles.pad}>
          <View style={[styles.accentRail, { backgroundColor: accent }]} />
          <TouchableOpacity onPress={onPress} activeOpacity={0.9} style={styles.top}>
            <View style={[styles.iconWrap, { backgroundColor: accent + '25' }]}>
              {v.profilePicture ? (
                <Image source={{ uri: v.profilePicture }} style={styles.avatar} />
              ) : (
                <GradientIconBox
                  icon="car-sport-outline"
                  colors={accentToGradient(accent)}
                  boxSize={40}
                  borderRadius={11}
                  elevated
                  size={22}
                />
              )}
            </View>
            <View style={styles.main}>
              {onToggleFavourite ? (
                <View style={styles.metaRow}>
                  <TouchableOpacity onPress={onToggleFavourite} hitSlop={10} style={styles.heartBtn}>
                    <Ionicons
                      name={v.isFavourite ? 'heart' : 'heart-outline'}
                      size={20}
                      color={v.isFavourite ? '#EF4444' : 'rgba(248,250,252,0.88)'}
                    />
                  </TouchableOpacity>
                </View>
              ) : null}
              <Text style={styles.title} numberOfLines={1}>
                {formatDisplayName(v.name) || v.name}
              </Text>
              <View
                style={[styles.statusPill, { backgroundColor: (v.isOnline ? '#10B981' : '#64748B') + '30' }]}
              >
                <View style={[styles.statusDot, { backgroundColor: v.isOnline ? '#10B981' : '#94A3B8' }]} />
                <Text style={[styles.statusText, { color: v.isOnline ? '#10B981' : '#94A3B8' }]}>
                  {v.isOnline ? 'Available' : 'Offline'}
                </Text>
              </View>
            </View>
          </TouchableOpacity>
          <View style={styles.bottom}>
            <View style={styles.metaPills}>
              <View style={styles.pill}>
                <Ionicons name="star" size={14} color="#FBBF24" />
                <Text style={styles.pillText}>{v.rating > 0 ? v.rating.toFixed(1) : 'New'}</Text>
              </View>
              <View style={styles.pill}>
                <Ionicons name="checkmark-done-outline" size={14} color={SKY} />
                <Text style={styles.pillText}>{v.totalJobs} jobs</Text>
              </View>
              {v.distance != null ? (
                <View style={styles.pill}>
                  <Ionicons name="location-outline" size={14} color={SKY} />
                  <Text style={styles.pillText}>~{v.distance.toFixed(1)} mi</Text>
                </View>
              ) : null}
            </View>
            <TouchableOpacity onPress={onBook} style={[styles.bookBtn, { borderColor: borderColor }]} activeOpacity={0.88}>
              <Ionicons name="flash-outline" size={16} color={accent} />
              <Text style={[styles.bookBtnText, { color: accent }]}>{CCP.requestButton}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    marginRight: 12,
  },
  card: {
    minHeight: 168,
    overflow: 'hidden',
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(8,20,38,0.22)',
    borderWidth: 1,
    shadowColor: 'rgba(56,189,248,0.2)',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.28,
    shadowRadius: 10,
    elevation: 5,
  },
  pad: {
    padding: 14,
    position: 'relative',
    gap: 10,
  },
  accentRail: {
    position: 'absolute',
    left: 0,
    top: 12,
    bottom: 12,
    width: 3,
    borderTopRightRadius: 4,
    borderBottomRightRadius: 4,
    opacity: 0.95,
  },
  top: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingLeft: 4,
  },
  iconWrap: {
    width: 46,
    height: 46,
    borderRadius: 13,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.36)',
  },
  avatar: {
    width: 46,
    height: 46,
    borderRadius: 13,
  },
  main: {
    flex: 1,
    minWidth: 0,
    gap: 4,
  },
  metaRow: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  heartBtn: {
    padding: 2,
  },
  title: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '900',
    letterSpacing: 0.1,
  },
  statusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
    alignSelf: 'flex-start',
  },
  statusDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '800',
  },
  bottom: {
    gap: 10,
    paddingLeft: 4,
    borderTopWidth: 1,
    borderTopColor: 'rgba(148,163,184,0.15)',
    paddingTop: 10,
  },
  metaPills: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 6,
  },
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.3)',
    backgroundColor: 'rgba(8,20,38,0.56)',
    borderRadius: 999,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  pillText: {
    color: SKY,
    fontSize: 11,
    fontWeight: '800',
  },
  bookBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    borderRadius: 12,
    borderWidth: 1,
    backgroundColor: 'rgba(8,20,38,0.55)',
    paddingVertical: 10,
  },
  bookBtnText: {
    fontSize: 13,
    fontWeight: '800',
  },
});
