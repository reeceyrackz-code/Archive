import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, ViewStyle, StyleProp, Image, Animated, Easing } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';
import { CAR_IMAGE, CARWASH_IMAGE, DETAILING_IMAGE, MOBILE_VAN_MARKER_IMAGE, VALETER_IMAGE } from '../../../assets/assetExports';

const PURPLE = '#A78BFA';

/** Soft expanding "live" ring behind a marker. */
function PulseRing({ color = colors.SKY, size }: { color?: string; size: number }) {
  const anim = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(
      Animated.timing(anim, {
        toValue: 1,
        duration: 1800,
        easing: Easing.out(Easing.ease),
        useNativeDriver: true,
      })
    );
    loop.start();
    return () => loop.stop();
  }, [anim]);
  const scale = anim.interpolate({ inputRange: [0, 1], outputRange: [0.6, 1.9] });
  const opacity = anim.interpolate({ inputRange: [0, 0.6, 1], outputRange: [0.45, 0.18, 0] });
  return (
    <Animated.View
      pointerEvents="none"
      style={{
        position: 'absolute',
        width: size,
        height: size,
        borderRadius: size / 2,
        backgroundColor: color,
        opacity,
        transform: [{ scale }],
      }}
    />
  );
}

const SKY = colors.SKY;
const EMERALD = '#10B981';
const AMBER = '#F59E0B';

type IconName = keyof typeof Ionicons.glyphMap;

const basePin: ViewStyle = {
  alignItems: 'center',
  justifyContent: 'center',
  borderWidth: 2,
  shadowColor: '#000',
  shadowOffset: { width: 0, height: 2 },
  shadowOpacity: 0.35,
  shadowRadius: 4,
  elevation: 6,
};

function MapIconPin({
  icon,
  size,
  diameter,
  backgroundColor,
  borderColor,
  iconColor,
  style,
}: {
  icon: IconName;
  size: number;
  diameter: number;
  backgroundColor: string;
  borderColor: string;
  iconColor: string;
  style?: StyleProp<ViewStyle>;
}) {
  return (
    <View
      style={[
        basePin,
        {
          width: diameter,
          height: diameter,
          borderRadius: diameter / 2,
          backgroundColor,
          borderColor,
        },
        style,
      ]}
    >
      <Ionicons name={icon} size={size} color={iconColor} />
    </View>
  );
}

/**
 * Customer / pickup location on maps.
 * - `car` — brand car art (`car.png`): dashboard, history, completed snapshots.
 * - `pin` — compact location chip: **active booking flow** maps (no car asset).
 */
export function MapMarkerCustomerVehicle({
  size = 44,
  variant = 'car',
}: {
  size?: number;
  variant?: 'car' | 'pin';
}) {
  if (variant === 'pin') {
    const d = Math.max(34, Math.round(size * 0.92));
    return (
      <MapIconPin
        icon="location"
        size={Math.round(d * 0.4)}
        diameter={d}
        backgroundColor="rgba(15,23,42,0.94)"
        borderColor={SKY + 'B3'}
        iconColor={SKY}
        style={{
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.28,
          shadowRadius: 4,
          elevation: 6,
        }}
      />
    );
  }
  const h = Math.round(size * 1.12);
  return (
    <View
      style={[
        styles.customerCarMarker,
        {
          width: size,
          height: h,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.38,
          shadowRadius: 5,
          elevation: 8,
        },
      ]}
    >
      <Image source={CAR_IMAGE} style={{ width: size, height: h }} resizeMode="contain" accessibilityIgnoresInvertColors />
    </View>
  );
}

/** Drop pin for “choose on map” / saved location editing */
export function MapMarkerDroppedPin({ size = 46 }: { size?: number }) {
  return (
    <View style={styles.pinColumn}>
      <MapIconPin
        icon="location"
        size={Math.round(size * 0.44)}
        diameter={size}
        backgroundColor="rgba(239,68,68,0.95)"
        borderColor="rgba(254,202,202,0.9)"
        iconColor="#fff"
      />
      <View style={styles.pinDot} />
    </View>
  );
}

/**
 * Car wash / fixed hub — same visual language as Explore map hubs (`explore.tsx`):
 * sky glow ring + dark core + location pin.
 */
export function MapMarkerWashHub({ size = 44, isSelected }: { size?: number; isSelected?: boolean }) {
  const outer = size;
  const core = Math.max(28, Math.round((size * 38) / 50));
  const iconPx = Math.max(12, Math.round((20 * core) / 38));
  const rOuter = outer / 2;
  const rCore = core / 2;
  return (
    <View
      style={{
        width: outer,
        height: outer,
        borderRadius: rOuter,
        justifyContent: 'center',
        alignItems: 'center',
      }}
    >
      <View
        style={{
          position: 'absolute',
          width: outer,
          height: outer,
          borderRadius: rOuter,
          backgroundColor: isSelected ? 'rgba(125,211,252,0.45)' : 'rgba(125,211,252,0.22)',
          borderWidth: isSelected ? 3 : 2,
          borderColor: isSelected ? SKY : 'rgba(125,211,252,0.45)',
        }}
      />
      <View
        style={{
          width: core,
          height: core,
          borderRadius: rCore,
          backgroundColor: isSelected ? SKY : 'rgba(15,23,42,0.92)',
          borderWidth: 2,
          borderColor: isSelected ? '#fff' : SKY,
          justifyContent: 'center',
          alignItems: 'center',
        }}
      >
        <Ionicons name="camera-outline" size={iconPx} color={isSelected ? '#0f172a' : SKY} />
      </View>
    </View>
  );
}

/** Detailing studio — Explore-style ring + core, purple glow + sparkles */
export function MapMarkerDetailingHub({ size = 44, isSelected }: { size?: number; isSelected?: boolean }) {
  const outer = size;
  const core = Math.max(28, Math.round((size * 38) / 50));
  const iconPx = Math.max(12, Math.round((20 * core) / 38));
  const rOuter = outer / 2;
  const rCore = core / 2;
  const lilac = 'rgba(216,180,254,0.55)';
  const glowFill = isSelected ? 'rgba(167,139,250,0.42)' : 'rgba(167,139,250,0.2)';
  const glowBorder = isSelected ? '#C4B5FD' : 'rgba(167,139,250,0.45)';
  return (
    <View
      style={{
        width: outer,
        height: outer,
        borderRadius: rOuter,
        justifyContent: 'center',
        alignItems: 'center',
      }}
    >
      <View
        style={{
          position: 'absolute',
          width: outer,
          height: outer,
          borderRadius: rOuter,
          backgroundColor: glowFill,
          borderWidth: isSelected ? 3 : 2,
          borderColor: glowBorder,
        }}
      />
      <View
        style={{
          width: core,
          height: core,
          borderRadius: rCore,
          backgroundColor: isSelected ? 'rgba(88,28,135,0.95)' : 'rgba(15,23,42,0.92)',
          borderWidth: 2,
          borderColor: isSelected ? '#fff' : lilac,
          justifyContent: 'center',
          alignItems: 'center',
        }}
      >
        <Ionicons name="sparkles" size={iconPx} color={isSelected ? '#FFFFFF' : '#F5D0FE'} />
      </View>
    </View>
  );
}

/**
 * Branded top-down van (`Mobile.png`) — mobile valeters & mobile detailing pros on maps.
 * Optional `waitLabel` renders above the icon (e.g. dashboard preview).
 */
export function MapMarkerMobileServiceVan({
  size = 48,
  isSelected,
  isOnline,
  waitLabel,
  heading,
  variant,
  pulse,
}: {
  size?: number;
  isSelected?: boolean;
  isOnline?: boolean;
  /** Short wait hint, e.g. "~15 min avg" */
  waitLabel?: string | null;
  /** Compass bearing (deg) to rotate the van toward its direction of travel. */
  heading?: number | null;
  /** Service kind — adds a small corner badge (water drop / sparkles). */
  variant?: 'wash' | 'detail';
  /** Show an animated "live" pulse ring (e.g. en-route tracking). */
  pulse?: boolean;
}) {
  const h = Math.round(size * 1.08);
  const rotation = typeof heading === 'number' && Number.isFinite(heading) ? `${heading}deg` : '0deg';
  const badgeColor = variant === 'detail' ? PURPLE : SKY;
  return (
    <View style={styles.mobileVanMarkerRoot}>
      {waitLabel ? (
        <View style={styles.mobileVanWaitPill}>
          <Text style={styles.mobileVanWaitText} numberOfLines={1}>
            {waitLabel}
          </Text>
        </View>
      ) : null}
      <View style={[styles.mobileVanImageWrap, { width: size, height: h }, isSelected ? styles.mobileVanImageWrapSelected : undefined]}>
        {pulse ? <PulseRing color={SKY} size={size} /> : null}
        <Image
          source={MOBILE_VAN_MARKER_IMAGE}
          style={{ width: size, height: h, transform: [{ rotate: rotation }] }}
          resizeMode="contain"
          accessibilityIgnoresInvertColors
        />
        {isOnline ? (
          <View style={styles.mobileVanOnlineBadge}>
            <View style={styles.onlineDot} />
          </View>
        ) : null}
        {variant ? (
          <View style={[styles.mobileVanServiceBadge, { borderColor: badgeColor + '88' }]}>
            <Ionicons name={variant === 'detail' ? 'sparkles' : 'water'} size={9} color={badgeColor} />
          </View>
        ) : null}
      </View>
    </View>
  );
}

/**
 * Avatar-style valeter pin (photo + rating + online dot) — for choosing a pro.
 * Falls back to the branded valeter image when no photo is available.
 */
export function MapMarkerValeterAvatar({
  size = 50,
  photoUri,
  rating,
  isSelected,
  isOnline,
}: {
  size?: number;
  photoUri?: string | null;
  rating?: number | null;
  isSelected?: boolean;
  isOnline?: boolean;
}) {
  const ringColor = isSelected ? SKY : 'rgba(255,255,255,0.92)';
  const showRating = typeof rating === 'number' && rating > 0;
  return (
    <View style={[styles.avatarPinBox, { width: size, height: size }]}>
      <View
        style={[
          styles.avatarPin,
          { width: size, height: size, borderRadius: size / 2, borderColor: ringColor },
          isSelected ? styles.avatarPinSelected : undefined,
        ]}
      >
        <Image
          source={photoUri ? { uri: photoUri } : VALETER_IMAGE}
          style={{ width: '100%', height: '100%' }}
          resizeMode="cover"
          accessibilityIgnoresInvertColors
        />
      </View>
      {isOnline ? <View style={styles.avatarOnlineDot} /> : null}
      {showRating ? (
        <View style={styles.avatarRatingChip}>
          <Ionicons name="star" size={8} color="#FBBF24" />
          <Text style={styles.avatarRatingText}>{(rating as number).toFixed(1)}</Text>
        </View>
      ) : null}
    </View>
  );
}

/** Location pin — circular venue picture with a rating chip + open dot, styled like the valeter avatar. */
export function MapMarkerLocationAvatar({
  size = 46,
  photoUri,
  rating,
  isSelected,
  isOpen,
  detailing,
}: {
  size?: number;
  photoUri?: string | null;
  rating?: number | null;
  isSelected?: boolean;
  isOpen?: boolean;
  detailing?: boolean;
}) {
  const ringColor = isSelected ? SKY : 'rgba(255,255,255,0.92)';
  const showRating = typeof rating === 'number' && rating > 0;
  const fallback = detailing ? DETAILING_IMAGE : CARWASH_IMAGE;
  return (
    <View style={[styles.avatarPinBox, { width: size, height: size }]}>
      <View
        style={[
          styles.avatarPin,
          { width: size, height: size, borderRadius: size / 2, borderColor: ringColor },
          isSelected ? styles.avatarPinSelected : undefined,
        ]}
      >
        <Image
          source={photoUri ? { uri: photoUri } : fallback}
          style={{ width: '100%', height: '100%' }}
          resizeMode="cover"
          accessibilityIgnoresInvertColors
        />
      </View>
      {isOpen ? <View style={styles.avatarOnlineDot} /> : null}
      {showRating ? (
        <View style={styles.avatarRatingChip}>
          <Ionicons name="star" size={8} color="#FBBF24" />
          <Text style={styles.avatarRatingText}>{(rating as number).toFixed(1)}</Text>
        </View>
      ) : null}
    </View>
  );
}

/** Live valeter / pro en route — branded van with a live pulse and optional heading. */
export function MapMarkerValeterLive({ size = 44, heading }: { size?: number; heading?: number | null }) {
  return <MapMarkerMobileServiceVan size={size} isOnline pulse heading={heading} />;
}

/**
 * Valeter on a selection map. Defaults to an avatar pin (photo + rating) so customers can
 * tell pros apart; pass `useVan` to keep the branded van for discovery/density maps.
 */
export function MapMarkerValeterCandidate({
  size = 50,
  isSelected,
  isOnline,
  photoUri,
  rating,
  useVan,
}: {
  size?: number;
  isSelected?: boolean;
  isOnline?: boolean;
  photoUri?: string | null;
  rating?: number | null;
  useVan?: boolean;
}) {
  const scale = isSelected ? 1.08 : 1;
  return (
    <View style={[styles.valeterWrap, { transform: [{ scale }] }]}>
      {useVan ? (
        <MapMarkerMobileServiceVan size={size} isSelected={isSelected} isOnline={isOnline} />
      ) : (
        <MapMarkerValeterAvatar size={size} isSelected={isSelected} isOnline={isOnline} photoUri={photoUri} rating={rating} />
      )}
    </View>
  );
}

/** Turn-by-turn destination (business / address) */
export function MapMarkerNavigationDestination({ size = 44 }: { size?: number }) {
  return (
    <MapIconPin
      icon="flag"
      size={Math.round(size * 0.4)}
      diameter={size}
      backgroundColor="rgba(127,29,29,0.94)"
      borderColor="rgba(254,202,202,0.75)"
      iconColor="#FECACA"
    />
  );
}

/** Generic service coordinates on payment / summary maps */
export function MapMarkerServiceSpot({ size = 40 }: { size?: number }) {
  return (
    <MapIconPin
      icon="location-sharp"
      size={Math.round(size * 0.38)}
      diameter={size}
      backgroundColor="rgba(15,23,42,0.96)"
      borderColor="rgba(245,158,11,0.6)"
      iconColor={AMBER}
    />
  );
}

/** Scheduled appointment location (hub) — confirm / schedule flows */
export function MapMarkerScheduledHub({
  variant = 'wash',
  size = 44,
}: {
  variant?: 'wash' | 'detail';
  size?: number;
}) {
  if (variant === 'detail') {
    return <MapMarkerDetailingHub size={size} />;
  }
  return <MapMarkerWashHub size={size} />;
}

const styles = StyleSheet.create({
  customerCarMarker: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  pinColumn: { alignItems: 'center' },
  pinDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginTop: -2,
    backgroundColor: 'rgba(0,0,0,0.35)',
  },
  mobileVanMarkerRoot: {
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  mobileVanWaitPill: {
    marginBottom: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
    backgroundColor: 'rgba(2,6,23,0.88)',
    borderWidth: 1,
    borderColor: 'rgba(56,189,248,0.42)',
    maxWidth: 128,
  },
  mobileVanWaitText: {
    color: '#E2E8F0',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 0.15,
  },
  mobileVanImageWrap: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  mobileVanImageWrapSelected: {
    shadowColor: SKY,
    shadowOpacity: 0.55,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 2 },
    elevation: 10,
  },
  mobileVanOnlineBadge: {
    position: 'absolute',
    top: 0,
    right: -2,
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: 'rgba(15,23,42,0.95)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.5)',
  },
  mobileVanServiceBadge: {
    position: 'absolute',
    bottom: 0,
    left: -2,
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: 'rgba(15,23,42,0.95)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  },
  avatarPinBox: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarPin: {
    overflow: 'hidden',
    borderWidth: 2.5,
    backgroundColor: 'rgba(15,23,42,0.6)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 5,
    elevation: 8,
  },
  avatarPinSelected: {
    shadowColor: SKY,
    shadowOpacity: 0.6,
    shadowRadius: 10,
  },
  avatarOnlineDot: {
    position: 'absolute',
    top: -1,
    right: -1,
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: EMERALD,
    borderWidth: 2,
    borderColor: 'rgba(15,23,42,0.95)',
  },
  avatarRatingChip: {
    position: 'absolute',
    bottom: -7,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
    paddingHorizontal: 5,
    paddingVertical: 1,
    borderRadius: 999,
    backgroundColor: 'rgba(15,23,42,0.96)',
    borderWidth: 1,
    borderColor: SKY + '66',
  },
  avatarRatingText: {
    color: '#F8FAFC',
    fontSize: 9,
    fontWeight: '800',
  },
  valeterWrap: { position: 'relative', alignItems: 'center', justifyContent: 'center' },
  valeterSelectedRing: {
    shadowColor: SKY,
    shadowOpacity: 0.55,
    shadowRadius: 8,
  },
  onlineBadge: {
    position: 'absolute',
    top: -2,
    right: -2,
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: 'rgba(15,23,42,0.95)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.5)',
  },
  onlineDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: EMERALD,
  },
});
