import React from 'react';
import { Image, ImageSourcePropType, StyleSheet } from 'react-native';
import Animated, { type SharedValue, useAnimatedStyle } from 'react-native-reanimated';
import { SPLASH_LOGO_WIDTH } from '../../constants/splash';

type SplashLogoProps = {
  source: ImageSourcePropType;
  scale: SharedValue<number>;
  opacity: SharedValue<number>;
};

export default function SplashLogo({ source, scale, opacity }: Readonly<SplashLogoProps>) {
  const animatedStyle = useAnimatedStyle(() => ({
    opacity: opacity.value,
    transform: [{ scale: scale.value }],
  }));

  return (
    <Animated.View style={[styles.wrap, animatedStyle]}>
      <Image source={source} style={styles.image} resizeMode="contain" />
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  image: {
    width: SPLASH_LOGO_WIDTH,
    height: SPLASH_LOGO_WIDTH,
  },
});
