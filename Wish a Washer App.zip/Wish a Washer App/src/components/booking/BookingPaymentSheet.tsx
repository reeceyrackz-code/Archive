import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '../../providers/enhanced-auth-context';
import { supabase } from '../../lib/supabase';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { syncBookingToDeviceCalendar } from '../../services/BookingCalendarSync';
import { HEADER_STYLE_CARD_GRADIENT } from '../../constants/bookingCardTheme';
import { colors } from '../../constants/colors';
import { getServiceDisplayName } from '../../utils/serviceNameMapper';
import GradientIconBox from '../shared/GradientIconBox';
import { WWPrimaryButton, WWSheetCloseButton } from '../ui';

const SKY = colors.SKY ?? '#38BDF8';

type PrepState = 'idle' | 'preparing' | 'ready' | 'error';

type BookingRecord = {
  id?: string;
  price?: number;
  add_ons_total?: number;
  discount_amount?: number;
  platform_fee_amount?: number;
  platform_fee_percent?: number;
  service_type?: string | null;
  service_name?: string | null;
  location_address?: string | null;
  scheduled_at?: string | null;
  status?: string;
  payment_completed_at?: string | null;
};

function useStripeNoop(): null {
  return null;
}
let useStripeImpl: () => ReturnType<typeof useStripeNoop> | { initPaymentSheet: unknown; presentPaymentSheet: unknown } =
  useStripeNoop;
if (Platform.OS !== 'web') {
  try {
    const stripe = require('@stripe/stripe-react-native');
    useStripeImpl = stripe.useStripe;
  } catch {
    /* no-op */
  }
}

function moneyGBP(value: unknown) {
  const n = Number(value);
  if (!Number.isFinite(n)) return '0.00';
  return n.toFixed(2);
}

function extractClientSecret(data: any): string | null {
  return (
    data?.clientSecret ??
    data?.client_secret ??
    data?.paymentIntentClientSecret ??
    data?.payment_intent_client_secret ??
    data?.paymentIntent?.clientSecret ??
    data?.paymentIntent?.client_secret ??
    data?.payment_intent?.client_secret ??
    null
  );
}

export type BookingPaymentSheetProps = {
  visible: boolean;
  bookingId: string | null | undefined;
  onClose: () => void;
  /** After successful Stripe completion and DB update */
  onPaid: () => void;
  /** `route` = full-screen payment page with map behind; `modal` = overlay on tracking */
  presentation?: 'modal' | 'route';
};

export default function BookingPaymentSheet({
  visible,
  bookingId,
  onClose,
  onPaid,
  presentation = 'modal',
}: BookingPaymentSheetProps) {
  const { user } = useAuth();
  const stripeHook = useStripeImpl();
  const hookObj = stripeHook && typeof stripeHook === 'object' ? (stripeHook as Record<string, unknown>) : null;
  const initPaymentSheet = typeof hookObj?.initPaymentSheet === 'function' ? hookObj.initPaymentSheet : undefined;
  const presentPaymentSheet = typeof hookObj?.presentPaymentSheet === 'function' ? hookObj.presentPaymentSheet : undefined;

  const [booking, setBooking] = useState<BookingRecord | null>(null);
  const [loadingBooking, setLoadingBooking] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [prepState, setPrepState] = useState<PrepState>('idle');
  const [lastError, setLastError] = useState<string | null>(null);
  const [clientSecret, setClientSecret] = useState<string | null>(null);

  const sheetReady = prepState === 'ready';

  const reset = useCallback(() => {
    setBooking(null);
    setLoadingBooking(false);
    setProcessing(false);
    setPrepState('idle');
    setLastError(null);
    setClientSecret(null);
  }, []);

  useEffect(() => {
    if (!visible) {
      reset();
    }
  }, [visible, reset]);

  const loadBooking = useCallback(async () => {
    if (!bookingId || !visible) return;
    setLoadingBooking(true);
    setLastError(null);
    try {
      const { data, error } = await supabase.from('bookings').select('*').eq('id', bookingId).single();
      if (error) throw error;
      setBooking(data as BookingRecord);
    } catch (e: any) {
      setBooking(null);
      setLastError(e?.message || 'Could not load booking');
      setPrepState('error');
    } finally {
      setLoadingBooking(false);
    }
  }, [bookingId, visible]);

  useEffect(() => {
    if (visible && bookingId) void loadBooking();
  }, [visible, bookingId, loadBooking]);

  const markBookingPaid = useCallback(async () => {
    if (!bookingId) return;
    const { error } = await supabase
      .from('bookings')
      .update({
        status: 'confirmed',
        payment_completed_at: new Date().toISOString(),
      })
      .eq('id', bookingId);
    if (error) throw error;
    await syncBookingToDeviceCalendar({
      id: bookingId,
      serviceName: booking?.service_name ?? null,
      serviceType: booking?.service_type ?? null,
      address: booking?.location_address ?? null,
      scheduledAt: booking?.scheduled_at ?? null,
    });
  }, [bookingId, booking?.service_name, booking?.service_type, booking?.location_address, booking?.scheduled_at]);

  const presentSheetAndHandleResult = useCallback(async () => {
    if (!presentPaymentSheet) return;
    setProcessing(true);
    await hapticFeedback('medium');
    try {
      const { error } = await presentPaymentSheet();
      if (error) {
        if (error.code === 'Canceled') {
          setProcessing(false);
          return;
        }
        throw error;
      }
      await markBookingPaid();
      onPaid();
    } catch (e: any) {
      console.error('[BookingPaymentSheet]', e);
      Alert.alert('Payment failed', e?.message || 'Please try again.');
    } finally {
      setProcessing(false);
    }
  }, [presentPaymentSheet, markBookingPaid, onPaid, onClose]);

  const preparePaymentSheet = useCallback(async (): Promise<boolean> => {
    if (Platform.OS === 'web') {
      setLastError('Payment is native-only.');
      setPrepState('error');
      return false;
    }
    if (!booking || !user?.id || !bookingId) return false;
    if (!initPaymentSheet || !presentPaymentSheet) {
      setLastError('Stripe is not initialised.');
      setPrepState('error');
      return false;
    }

    setPrepState('preparing');
    setLastError(null);
    setClientSecret(null);

    const priceNumber = Number(booking.price);
    const amountPence = Math.round((Number.isFinite(priceNumber) ? priceNumber : 0) * 100);

    if (!amountPence || Number.isNaN(amountPence) || amountPence < 50) {
      setLastError('Invalid amount for this booking.');
      setPrepState('error');
      return false;
    }

    try {
      const { data, error } = await supabase.functions.invoke('booking-extra-charge', {
        body: {
          action: 'create_payment_intent',
          bookingId,
          currency: 'gbp',
          customerId: user.id,
          description: `Wish a Wash booking ${bookingId}`,
          amount: amountPence,
        },
      });

      if (error) {
        setLastError(error.message || 'Payment setup failed');
        setPrepState('error');
        return false;
      }

      const cs = extractClientSecret(data);
      if (!cs) {
        setLastError('No payment client secret returned.');
        setPrepState('error');
        return false;
      }

      setClientSecret(cs);

      const { error: sheetError } = await initPaymentSheet({
        paymentIntentClientSecret: cs,
        merchantDisplayName: 'Wish a Wash',
        returnURL: 'waw://stripe-redirect',
        style: 'automatic',
      });

      if (sheetError) {
        setLastError(sheetError.message || 'Could not start payment.');
        setPrepState('error');
        return false;
      }

      setPrepState('ready');
      return true;
    } catch (e: any) {
      setLastError(e?.message || 'Unexpected error preparing payment.');
      setPrepState('error');
      return false;
    }
  }, [booking, user?.id, bookingId, initPaymentSheet, presentPaymentSheet]);

  useEffect(() => {
    if (!visible || !booking?.id || !user?.id || Platform.OS === 'web') return;
    void preparePaymentSheet();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visible, booking?.id, user?.id]);

  const handlePayPress = useCallback(async () => {
    if (!bookingId || processing) return;
    if (Platform.OS === 'web') {
      Alert.alert('Not supported', 'Payment is native-only.');
      return;
    }
    if (!presentPaymentSheet) {
      Alert.alert('Stripe not ready', 'Payment is not available.');
      return;
    }

    setProcessing(true);
    let ready = sheetReady && !!clientSecret;
    if (!ready) {
      if (prepState === 'preparing') {
        setProcessing(false);
        Alert.alert('Hold on', 'Payment is still preparing…');
        return;
      }
      ready = await preparePaymentSheet();
      if (!ready) {
        setProcessing(false);
        Alert.alert('Hold on', lastError || 'Payment is not ready. Try Retry below.');
        return;
      }
    }
    await presentSheetAndHandleResult();
  }, [bookingId, processing, sheetReady, clientSecret, prepState, preparePaymentSheet, presentSheetAndHandleResult, presentPaymentSheet, lastError]);

  const serviceLabel = useMemo(
    () => getServiceDisplayName(booking?.service_type, booking?.service_name),
    [booking?.service_type, booking?.service_name],
  );
  const totalDisplay = moneyGBP(booking?.price);
  const addOns = Number(booking?.add_ons_total) || 0;
  const platformFee = Number(booking?.platform_fee_amount) || 0;
  const discountAmount = Number(booking?.discount_amount) || 0;
  const serviceSubtotal = Math.max(0, Number(booking?.price) - addOns - platformFee + discountAmount);

  if (!visible) return null;

  const isRoute = presentation === 'route';

  const sheet = (
    <Pressable
      style={isRoute ? styles.routeBackdrop : styles.backdrop}
      onPress={isRoute ? undefined : onClose}
    >
      <Pressable style={styles.wrap} onPress={(e) => e.stopPropagation()}>
          <BlurView intensity={24} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
          <LinearGradient colors={HEADER_STYLE_CARD_GRADIENT} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1 }} style={StyleSheet.absoluteFill} pointerEvents="none" />
          <LinearGradient
            colors={['rgba(255,255,255,0.14)', 'rgba(255,255,255,0.02)', 'transparent']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.sheen}
            pointerEvents="none"
          />
          <View style={styles.handle} />
          <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
            <View style={styles.headerRow}>
              <View style={styles.titleRow}>
                <GradientIconBox icon="wallet-outline" preset="teal" boxSize={44} borderRadius={15} elevated />
                <Text style={styles.title}>Complete payment</Text>
              </View>
              <WWSheetCloseButton variant="bordered" onPress={onClose} accessibilityLabel="Close payment sheet" />
            </View>
            <Text style={styles.subtitle}>Pay securely to confirm your booking.</Text>

            {loadingBooking && !booking ? (
              <View style={styles.centerBlock}>
                <ActivityIndicator color={SKY} />
                <Text style={styles.muted}>Loading booking…</Text>
              </View>
            ) : !booking ? (
              <Text style={styles.errorText}>{lastError || 'Booking not found.'}</Text>
            ) : (
              <>
                <View style={styles.summaryCard}>
                  <Text style={styles.summaryLabel}>Service</Text>
                  <Text style={styles.summaryService}>{serviceLabel}</Text>
                  <View style={styles.divider} />
                  <View style={styles.rowBetween}>
                    <Text style={styles.mutedSmall}>Service</Text>
                    <Text style={styles.amount}>£{moneyGBP(serviceSubtotal)}</Text>
                  </View>
                  {platformFee > 0 ? (
                    <View style={styles.rowBetween}>
                      <Text style={styles.mutedSmall}>Platform fee</Text>
                      <Text style={styles.amount}>£{moneyGBP(platformFee)}</Text>
                    </View>
                  ) : null}
                  {addOns > 0 ? (
                    <View style={styles.rowBetween}>
                      <Text style={styles.mutedSmall}>Add-ons</Text>
                      <Text style={styles.amount}>£{moneyGBP(addOns)}</Text>
                    </View>
                  ) : null}
                  {discountAmount > 0 ? (
                    <View style={styles.rowBetween}>
                      <Text style={styles.mutedSmall}>Discount</Text>
                      <Text style={[styles.amount, { color: '#34D399' }]}>-£{moneyGBP(discountAmount)}</Text>
                    </View>
                  ) : null}
                  <View style={[styles.rowBetween, styles.totalRow]}>
                    <Text style={styles.totalLabel}>Total due</Text>
                    <Text style={styles.totalValue}>£{totalDisplay}</Text>
                  </View>
                </View>
                <Text style={styles.prepHint}>
                  {prepState === 'ready' && 'Ready — tap Pay to open the secure sheet'}
                  {prepState === 'preparing' && 'Preparing payment…'}
                  {prepState === 'error' && (lastError || 'Something went wrong')}
                  {prepState === 'idle' && ' '}
                </Text>
              </>
            )}

            <WWPrimaryButton
              title={booking ? `Pay £${totalDisplay}` : 'Pay'}
              onPress={() => void handlePayPress()}
              disabled={!booking || processing || prepState === 'preparing'}
              loading={processing || prepState === 'preparing'}
              leftIconName="card-outline"
              leftIconSize={20}
            />

            {prepState === 'error' ? (
              <TouchableOpacity
                style={styles.retryBtn}
                onPress={() => {
                  setPrepState('idle');
                  void preparePaymentSheet();
                }}
                activeOpacity={0.85}
              >
                <Text style={styles.retryText}>Retry setup</Text>
              </TouchableOpacity>
            ) : null}

            <TouchableOpacity style={styles.cancelLink} onPress={onClose} activeOpacity={0.8}>
              <Text style={styles.cancelLinkText}>Not now</Text>
            </TouchableOpacity>
          </ScrollView>
        </Pressable>
      </Pressable>
  );

  if (isRoute) {
    return (
      <View style={styles.routeRoot} pointerEvents="box-none">
        {sheet}
      </View>
    );
  }

  return (
    <Modal visible transparent animationType="fade" onRequestClose={onClose}>
      {sheet}
    </Modal>
  );
}

const styles = StyleSheet.create({
  routeRoot: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'flex-end',
    zIndex: 2,
  },
  routeBackdrop: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'transparent',
  },
  backdrop: {
    flex: 1,
    backgroundColor: 'rgba(2,6,23,0.45)',
    justifyContent: 'flex-end',
  },
  wrap: {
    width: '100%',
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.3)',
    overflow: 'hidden',
    maxHeight: '78%',
  },
  sheen: { ...StyleSheet.absoluteFillObject, opacity: 0.92 },
  handle: {
    width: 44,
    height: 5,
    borderRadius: 999,
    backgroundColor: 'rgba(226,232,240,0.35)',
    alignSelf: 'center',
    marginTop: 10,
    marginBottom: 8,
  },
  content: { paddingHorizontal: 18, paddingBottom: 28 },
  headerRow: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 8 },
  titleRow: { flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 },
  title: { color: '#F8FAFC', fontSize: 20, fontWeight: '800', flex: 1 },
  subtitle: { color: 'rgba(148,163,184,0.95)', fontSize: 14, fontWeight: '600', marginBottom: 16, lineHeight: 20 },
  centerBlock: { alignItems: 'center', paddingVertical: 24, gap: 10 },
  muted: { color: 'rgba(226,232,240,0.8)', fontSize: 14, fontWeight: '600' },
  errorText: { color: '#FCA5A5', fontSize: 14, fontWeight: '600', marginBottom: 12 },
  summaryCard: {
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.28)',
    backgroundColor: 'rgba(255,255,255,0.05)',
    padding: 16,
    marginBottom: 10,
  },
  summaryLabel: { color: SKY, fontSize: 11, fontWeight: '800', letterSpacing: 0.4, marginBottom: 4, textTransform: 'uppercase' },
  summaryService: { color: '#F8FAFC', fontSize: 17, fontWeight: '800', marginBottom: 12 },
  divider: { height: 1, backgroundColor: 'rgba(148,163,184,0.2)', marginBottom: 10 },
  rowBetween: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  mutedSmall: { color: 'rgba(148,163,184,0.9)', fontSize: 13, fontWeight: '600' },
  amount: { color: '#E2E8F0', fontSize: 14, fontWeight: '700' },
  totalRow: { marginTop: 8, paddingTop: 10, borderTopWidth: 1, borderTopColor: 'rgba(148,163,184,0.2)' },
  totalLabel: { color: '#F8FAFC', fontSize: 15, fontWeight: '800' },
  totalValue: { color: SKY, fontSize: 18, fontWeight: '800' },
  prepHint: { color: 'rgba(148,163,184,0.9)', fontSize: 12, fontWeight: '600', textAlign: 'center', marginBottom: 14, minHeight: 16 },
  retryBtn: {
    alignSelf: 'center',
    paddingVertical: 10,
    paddingHorizontal: 16,
    marginBottom: 8,
  },
  retryText: { color: SKY, fontSize: 15, fontWeight: '700' },
  cancelLink: { alignSelf: 'center', paddingVertical: 8 },
  cancelLinkText: { color: 'rgba(148,163,184,0.95)', fontSize: 14, fontWeight: '600' },
});
