import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Animated, TouchableOpacity, Pressable } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';
import { CCP, ccpSingularLower } from '../../constants/carCareProLabels';
import GradientIconBox from '../shared/GradientIconBox';

const SKY = colors.SKY ?? '#87CEEB';

interface ValeterDeclinedOverlayProps {
  visible: boolean;
  onFindNewValeter: () => void;
  onBackToDashboard: () => void;
}

export default function ValeterDeclinedOverlay({
  visible,
  onFindNewValeter,
  onBackToDashboard,
}: ValeterDeclinedOverlayProps) {
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.85)).current;
  const bounceAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (visible) {
      Animated.parallel([
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 280,
          useNativeDriver: true,
        }),
        Animated.spring(scaleAnim, {
          toValue: 1,
          tension: 65,
          friction: 8,
          useNativeDriver: true,
        }),
      ]).start();

      // Gentle bounce for the sad icon
      Animated.sequence([
        Animated.timing(bounceAnim, { toValue: 1, duration: 400, useNativeDriver: true }),
        Animated.timing(bounceAnim, { toValue: 0, duration: 300, useNativeDriver: true }),
      ]).start();
    } else {
      fadeAnim.setValue(0);
      scaleAnim.setValue(0.85);
      bounceAnim.setValue(0);
    }
  }, [visible]);

  if (!visible) return null;

  const iconBounce = bounceAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [0, -8],
  });

  return (
    <Animated.View
      style={[styles.overlay, { opacity: fadeAnim }]}
      pointerEvents="box-none"
    >
      <BlurView intensity={70} tint="dark" style={StyleSheet.absoluteFill} />
      <View style={styles.backdrop} />

      <Animated.View
        style={[
          styles.card,
          {
            transform: [{ scale: scaleAnim }],
          },
        ]}
      >
        <LinearGradient
          colors={['rgba(30,58,138,0.95)', 'rgba(10,25,41,0.98)']}
          style={styles.cardGradient}
        >
          <View style={styles.iconRow}>
            <Animated.View
              style={[
                styles.iconWrap,
                { transform: [{ translateY: iconBounce }] },
              ]}
            >
              <GradientIconBox
                icon="sad-outline"
                preset="sky"
                boxSize={88}
                size={44}
                borderRadius={28}
                elevated
              />
            </Animated.View>
          </View>

          <Text style={styles.title}>Oh no</Text>
          <Text style={styles.subtitle}>{`Let's find you a new ${ccpSingularLower()}`}</Text>

          <TouchableOpacity
            style={styles.primaryButton}
            onPress={onFindNewValeter}
            activeOpacity={0.85}
          >
            <LinearGradient
              colors={[SKY, '#0EA5E9']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.primaryButtonGradient}
            >
              <Ionicons name="search" size={20} color="#0A1929" />
              <Text style={styles.primaryButtonText}>{`Find new ${ccpSingularLower()}`}</Text>
            </LinearGradient>
          </TouchableOpacity>

          <Pressable
            style={({ pressed }) => [styles.secondaryButton, pressed && styles.secondaryButtonPressed]}
            onPress={onBackToDashboard}
          >
            <Text style={styles.secondaryButtonText}>Back to dashboard</Text>
          </Pressable>
        </LinearGradient>
      </Animated.View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  overlay: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 9999,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  backdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(10,25,41,0.75)',
  },
  card: {
    width: '100%',
    maxWidth: 340,
    borderRadius: 24,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 24,
    elevation: 12,
  },
  cardGradient: {
    paddingVertical: 32,
    paddingHorizontal: 28,
    alignItems: 'center',
  },
  iconRow: {
    marginBottom: 20,
  },
  iconWrap: {
    alignSelf: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: '800',
    color: '#F1F5F9',
    marginBottom: 8,
    letterSpacing: 0.5,
  },
  subtitle: {
    fontSize: 16,
    color: 'rgba(241,245,249,0.88)',
    marginBottom: 28,
    textAlign: 'center',
    lineHeight: 22,
  },
  primaryButton: {
    width: '100%',
    marginBottom: 12,
    borderRadius: 14,
    overflow: 'hidden',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
    elevation: 6,
  },
  primaryButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 24,
    gap: 10,
  },
  primaryButtonText: {
    fontSize: 17,
    fontWeight: '700',
    color: '#0A1929',
  },
  secondaryButton: {
    paddingVertical: 12,
    paddingHorizontal: 20,
  },
  secondaryButtonPressed: {
    opacity: 0.7,
  },
  secondaryButtonText: {
    fontSize: 15,
    color: 'rgba(241,245,249,0.8)',
    fontWeight: '600',
  },
});
