import React from 'react';
import { colors } from '../../constants/colors';
import { BookingHeaderMapControlButton } from '../shared/BookingHeaderMapControlButton';
import BookingMapChromeHeader from './BookingMapChromeHeader';

type BookingMapLocationFullHeaderProps = {
  topInset: number;
  title?: string;
  accentColor?: string;
  onBack: () => void;
  onRecenter: () => void;
  recenterLoading?: boolean;
};

export default function BookingMapLocationFullHeader({
  topInset,
  title = "Where's the ride?",
  accentColor = colors.SKY,
  onBack,
  onRecenter,
  recenterLoading = false,
}: BookingMapLocationFullHeaderProps) {
  return (
    <BookingMapChromeHeader
      topInset={topInset}
      title={title}
      titleIcon="car-sport-outline"
      onBack={onBack}
      rightAction={
        <BookingHeaderMapControlButton
          onPress={onRecenter}
          accentColor={accentColor}
          loading={recenterLoading}
          accessibilityLabel="Recenter map on your location"
        />
      }
    />
  );
}
