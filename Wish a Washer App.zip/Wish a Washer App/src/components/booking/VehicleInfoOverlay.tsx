import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import BookingBottomSheetOverlay from './BookingBottomSheetOverlay';
import { BOOKING_INFO_SHEET_ACCENT } from '../../constants/bookingInfoSheetTheme';
import GradientIconBox from '../shared/GradientIconBox';
import SheetQuickIcon from '../shared/SheetQuickIcon';

export type VehicleInfoOverlayVehicle = {
  id: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  image_url?: string | null;
  photo?: string | null;
  type?: string | null;
  size?: string | null;
  mot_expiry?: string | null;
  mot_expiry_date?: string | null;
  tax_status?: string | null;
  tax_due_date?: string | null;
  tax_expiry?: string | null;
  mileage?: string | number | null;
};

export type VehicleStats = {
  washCount: number;
  lastCleanedAt: string | null;
  cleanRating: number | null;
};

type VehicleInfoOverlayProps = {
  visible: boolean;
  vehicle: VehicleInfoOverlayVehicle | null;
  stats: VehicleStats;
  accentColor: string;
  onClose: () => void;
};

function formatSize(size: string | null | undefined): string {
  if (!size) return '';
  const s = String(size).toLowerCase();
  if (s === 'small') return 'S';
  if (s === 'medium') return 'M';
  if (s === 'large') return 'L';
  if (s === 'xl') return 'XL';
  if (s === 'xxl') return 'XXL';
  return s.charAt(0).toUpperCase() + s.slice(1);
}

function formatDate(iso: string | null | undefined): string {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
  } catch {
    return '—';
  }
}

function getMotStatus(expiry: string | null | undefined): string {
  if (!expiry) return '—';
  try {
    const d = new Date(expiry);
    const dateStr = d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
    return d >= new Date() ? `Valid until ${dateStr}` : `Expired ${dateStr}`;
  } catch {
    return String(expiry);
  }
}

function getTaxStatus(
  status: string | null | undefined,
  dueDate: string | null | undefined,
  expiry: string | null | undefined
): string {
  const dateStr = dueDate || expiry;
  if (dateStr) {
    try {
      const d = new Date(dateStr);
      const formatted = d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
      if (d >= new Date()) return `Valid until ${formatted}`;
      return `Expired ${formatted}`;
    } catch {
      // fall through
    }
  }
  if (status && String(status).trim()) return String(status).trim();
  return '—';
}

export function VehicleInfoOverlay({
  visible,
  vehicle,
  stats,
  accentColor = BOOKING_INFO_SHEET_ACCENT,
  onClose,
}: VehicleInfoOverlayProps) {
  const imageUri = vehicle?.image_url ?? vehicle?.photo ?? null;
  const motDate = vehicle?.mot_expiry_date ?? vehicle?.mot_expiry ?? null;
  const taxDue = vehicle?.tax_due_date ?? vehicle?.tax_expiry ?? null;
  const mileage =
    vehicle?.mileage != null && vehicle.mileage !== ''
      ? typeof vehicle.mileage === 'number'
        ? vehicle.mileage.toLocaleString()
        : String(vehicle.mileage)
      : null;

  return (
    <BookingBottomSheetOverlay visible={visible} onClose={onClose} maxHeightRatio={0.9}>
      {!vehicle ? (
        <View style={styles.loadingState}>
          <Text style={styles.loadingText}>Loading…</Text>
          <TouchableOpacity onPress={onClose} style={styles.doneWrap} activeOpacity={0.9}>
            <LinearGradient colors={[accentColor, `${accentColor}E6`]} style={styles.doneBtn}>
              <Text style={styles.doneText}>Close</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      ) : (
        <>
          <ScrollView
            style={styles.scroll}
            contentContainerStyle={styles.scrollContent}
            showsVerticalScrollIndicator
            nestedScrollEnabled
          >
            <View style={[styles.photoWrap, { borderColor: accentColor + '35' }]}>
              {imageUri ? (
                <Image source={{ uri: imageUri }} style={styles.photo} resizeMode="cover" />
              ) : (
                <View style={[styles.photoPlaceholder, { backgroundColor: accentColor + '12' }]}>
                  <GradientIconBox
                    icon="car-sport-outline"
                    colors={[accentColor, accentColor]}
                    boxSize={56}
                    borderRadius={16}
                    elevated
                  />
                </View>
              )}
            </View>

            <Text style={styles.makeModel} numberOfLines={2}>
              {vehicle.make} {vehicle.model}
            </Text>
            <Text style={styles.regLine}>
              {vehicle.color} · {vehicle.registration}
            </Text>

            <View style={styles.sectionCompact}>
              <Text style={styles.sectionLabel}>Service history</Text>
              <View style={styles.statsGrid}>
                <View style={[styles.statChip, { borderColor: '#10B981' + '40', backgroundColor: '#10B981' + '12' }]}>
                  <Ionicons name="water" size={14} color="#10B981" />
                  <Text style={styles.statChipText}>
                    {stats.washCount} wash{stats.washCount !== 1 ? 'es' : ''}
                  </Text>
                </View>
                <View style={[styles.statChip, { borderColor: accentColor + '40', backgroundColor: accentColor + '12' }]}>
                  <Ionicons name="calendar" size={14} color={accentColor} />
                  <Text style={styles.statChipText}>{formatDate(stats.lastCleanedAt)}</Text>
                </View>
                <View style={[styles.statChip, { borderColor: '#EAB308' + '40', backgroundColor: '#EAB308' + '12' }]}>
                  <Ionicons name="star" size={14} color="#EAB308" />
                  <Text style={styles.statChipText}>{stats.cleanRating != null ? `${stats.cleanRating}/5` : '—'}</Text>
                </View>
              </View>
            </View>

            <View style={styles.sectionCompact}>
              <Text style={styles.sectionLabel}>MOT & tax</Text>
              <View style={styles.rows}>
                {[
                  { icon: 'shield-checkmark' as const, preset: 'teal' as const, label: 'MOT status', value: getMotStatus(motDate) },
                  { icon: 'receipt-outline' as const, preset: 'sky' as const, label: 'Tax status', value: getTaxStatus(vehicle.tax_status, vehicle.tax_due_date, taxDue) },
                  mileage != null
                    ? { icon: 'speedometer' as const, preset: 'gray' as const, label: 'Mileage', value: `${mileage} miles` }
                    : null,
                  vehicle.size ? { icon: 'resize' as const, preset: 'purple' as const, label: 'Size', value: formatSize(vehicle.size) } : null,
                  vehicle.type ? { icon: 'shapes' as const, preset: 'pink' as const, label: 'Type', value: vehicle.type } : null,
                ]
                  .filter(Boolean)
                  .map((item, index, arr) => (
                    <View key={item!.label} style={[styles.row, index === arr.length - 1 && styles.rowLast]}>
                      <SheetQuickIcon icon={item!.icon} preset={item!.preset} size="chip" />
                      <Text style={styles.rowLabel}>{item!.label}</Text>
                      <Text style={styles.rowValue}>{item!.value}</Text>
                    </View>
                  ))}
              </View>
            </View>
          </ScrollView>

          <TouchableOpacity onPress={onClose} style={styles.doneWrap} activeOpacity={0.9}>
            <LinearGradient colors={[accentColor, `${accentColor}E6`]} style={styles.doneBtn}>
              <Text style={styles.doneText}>Done</Text>
            </LinearGradient>
          </TouchableOpacity>
        </>
      )}
    </BookingBottomSheetOverlay>
  );
}

const styles = StyleSheet.create({
  loadingState: {
    paddingVertical: 24,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 120,
  },
  loadingText: {
    color: '#94A3B8',
    fontSize: 16,
    marginBottom: 16,
  },
  scroll: {
    maxHeight: 480,
  },
  scrollContent: {
    paddingBottom: 12,
    flexGrow: 1,
  },
  photoWrap: {
    height: 100,
    borderRadius: 14,
    overflow: 'hidden',
    marginBottom: 12,
    borderWidth: 1,
  },
  photo: {
    width: '100%',
    height: '100%',
  },
  photoPlaceholder: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  makeModel: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: '800',
    textAlign: 'center',
    marginBottom: 4,
    letterSpacing: 0.2,
  },
  regLine: {
    color: '#B8C5D6',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 14,
  },
  sectionCompact: {
    marginBottom: 14,
  },
  sectionLabel: {
    color: '#B8C5D6',
    fontSize: 12,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.8,
    marginBottom: 10,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  statChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 8,
    borderWidth: 1,
  },
  statChipText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '600',
  },
  rows: {
    backgroundColor: 'rgba(30,41,59,0.95)',
    borderRadius: 10,
    padding: 10,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.35)',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 8,
    paddingHorizontal: 4,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'rgba(148,163,184,0.25)',
  },
  rowLast: {
    borderBottomWidth: 0,
  },
  rowLabel: {
    color: '#B8C5D6',
    fontSize: 14,
    flex: 0,
    minWidth: 80,
  },
  rowValue: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
    flex: 1,
    textAlign: 'right',
  },
  doneWrap: {
    marginTop: 8,
    borderRadius: 14,
    overflow: 'hidden',
  },
  doneBtn: {
    paddingVertical: 16,
    alignItems: 'center',
  },
  doneText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '800',
  },
});
