import React from 'react';

/**
 * @deprecated Glass stack lives in `BookingMapGlassBackground` / `BusinessSheetBackground`.
 * Kept as a no-op so existing sheet layouts do not double-layer sheens.
 */
export default function BookingSheetPremiumLayers() {
  return null;
}
