import { useCallback, useEffect, useMemo, useState } from 'react';
import * as Location from 'expo-location';
import { supabase } from '../lib/supabase';
import { ValeterStatsService } from '../services/Valeterstatsservice';
import { distanceKm, etaMinutes } from '../utils/mapUtils';
import { ccpFallbackName } from '../constants/carCareProLabels';
import type { ExploreValeterCardData } from '../components/explore/ExploreValeterTripCard';

export type NearbyValeterRow = ExploreValeterCardData & {
  etaMins: number | null;
  lastLat?: number | null;
  lastLng?: number | null;
};

type Coords = { latitude: number; longitude: number };

export function useNearbyValeters(radiusMiles: number | null, userId?: string | null) {
  const [userCoords, setUserCoords] = useState<Coords | null>(null);
  const [valeters, setValeters] = useState<NearbyValeterRow[]>([]);
  const [favouriteIds, setFavouriteIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const { status } = await Location.getForegroundPermissionsAsync();
        if (status !== 'granted') {
          const { status: req } = await Location.requestForegroundPermissionsAsync();
          if (req !== 'granted' || cancelled) return;
        }
        const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
        if (!cancelled) {
          setUserCoords({ latitude: loc.coords.latitude, longitude: loc.coords.longitude });
        }
      } catch {
        /* location optional */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const loadFavourites = useCallback(async () => {
    if (!userId) return new Set<string>();
    const { data } = await supabase.from('favourites').select('valeter_id').eq('user_id', userId);
    const ids = new Set((data || []).map((r: { valeter_id: string }) => r.valeter_id));
    setFavouriteIds(ids);
    return ids;
  }, [userId]);

  const loadValeters = useCallback(
    async (favSet?: Set<string>) => {
      try {
        const { data: presenceData, error } = await supabase
          .from('valeter_presence')
          .select('user_id, is_online, last_lat, last_lng');
        if (error) throw error;
        const withLocation = (presenceData || []).filter(
          (p: { last_lat?: unknown; last_lng?: unknown }) => p.last_lat != null && p.last_lng != null
        );
        if (!withLocation.length) {
          setValeters([]);
          return;
        }
        const userIds = withLocation.map((p: { user_id: string }) => p.user_id);
        const { data: profilesMin } = await supabase
          .from('valeter_profiles')
          .select('user_id, full_name, profile_photo_url')
          .in('user_id', userIds);
        const profilesData = (profilesMin || []) as {
          user_id: string;
          full_name?: string;
          profile_photo_url?: string;
        }[];
        const statsBatch = await ValeterStatsService.getValeterStatsBatch(userIds);
        const fav = favSet ?? favouriteIds;
        const list: NearbyValeterRow[] = withLocation.map((p: Record<string, unknown>) => {
          const uid = p.user_id as string;
          const profile = profilesData.find((pr) => pr.user_id === uid);
          const stats = statsBatch.get(uid);
          return {
            id: uid,
            name: profile?.full_name || ccpFallbackName(),
            rating: stats?.averageRating ?? 0,
            totalJobs: stats?.totalJobs ?? 0,
            distance: null,
            etaMins: null,
            isOnline: Boolean(p.is_online),
            profilePicture: profile?.profile_photo_url ?? null,
            isFavourite: fav.has(uid),
            lastLat: p.last_lat != null ? Number(p.last_lat) : null,
            lastLng: p.last_lng != null ? Number(p.last_lng) : null,
          };
        });
        setValeters(list);
      } catch {
        setValeters([]);
      }
    },
    [favouriteIds]
  );

  const refresh = useCallback(async () => {
    setLoading(true);
    const fav = await loadFavourites();
    await loadValeters(fav);
    setLoading(false);
  }, [loadFavourites, loadValeters]);

  useEffect(() => {
    void refresh();
  }, [userId]);

  const valetersWithDistance = useMemo(() => {
    if (!userCoords) return valeters;
    return valeters.map((v) => {
      if (v.lastLat == null || v.lastLng == null) return v;
      const km = distanceKm(userCoords, { latitude: v.lastLat, longitude: v.lastLng });
      const miles = km * 0.621371;
      return { ...v, distance: miles, etaMins: etaMinutes(km) };
    });
  }, [valeters, userCoords]);

  const valetersInRadius = useMemo(() => {
    let list = [...valetersWithDistance];
    if (radiusMiles != null) {
      list = list.filter((v) => (v.distance ?? 999) <= radiusMiles);
    }
    list.sort((a, b) => {
      const online = Number(b.isOnline) - Number(a.isOnline);
      if (online !== 0) return online;
      return (a.distance ?? 999) - (b.distance ?? 999);
    });
    return list;
  }, [valetersWithDistance, radiusMiles]);

  const toggleFavourite = useCallback(
    async (valeterId: string) => {
      if (!userId) return;
      const isFav = favouriteIds.has(valeterId);
      if (isFav) {
        await supabase.from('favourites').delete().eq('user_id', userId).eq('valeter_id', valeterId);
        setFavouriteIds((prev) => {
          const next = new Set(prev);
          next.delete(valeterId);
          return next;
        });
        setValeters((prev) => prev.map((v) => (v.id === valeterId ? { ...v, isFavourite: false } : v)));
      } else {
        await supabase.from('favourites').insert({ user_id: userId, valeter_id: valeterId });
        setFavouriteIds((prev) => new Set([...prev, valeterId]));
        setValeters((prev) => prev.map((v) => (v.id === valeterId ? { ...v, isFavourite: true } : v)));
      }
    },
    [userId, favouriteIds]
  );

  return {
    userCoords,
    valetersInRadius,
    loading,
    refresh,
    toggleFavourite,
  };
}
