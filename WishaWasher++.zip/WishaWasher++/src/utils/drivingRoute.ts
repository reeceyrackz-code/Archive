import { GOOGLE_MAPS_API_KEY } from '../config/google-maps';

const polyline = require('@mapbox/polyline');

export type LatLng = { latitude: number; longitude: number };

export type DrivingRoute = {
  coordinates: LatLng[];
  distanceMi: number;
  durationMinutes: number;
};

function metersToMiles(meters: number): number {
  return Math.round((meters / 1609.344) * 10) / 10;
}

function secondsToMinutes(seconds: number): number {
  return Math.max(1, Math.round(seconds / 60));
}

type DirectionsStep = { polyline?: { points?: string } };
type DirectionsLeg = { steps?: DirectionsStep[] };

/**
 * Full-resolution path from each step's polyline, so the line hugs every road at sat-nav zoom.
 * Falls back to the simplified overview path when steps are missing.
 */
function detailedPath(route: { legs?: DirectionsLeg[]; overview_polyline?: { points?: string } } | undefined): [number, number][] | null {
  const pts: [number, number][] = [];
  for (const leg of route?.legs ?? []) {
    for (const step of leg.steps ?? []) {
      const enc = step.polyline?.points;
      if (typeof enc !== 'string') continue;
      const seg: [number, number][] = polyline.decode(enc);
      pts.push(...(pts.length ? seg.slice(1) : seg));
    }
  }
  if (pts.length > 1) return pts;
  const overview = route?.overview_polyline?.points;
  return typeof overview === 'string' ? polyline.decode(overview) : null;
}

const ROUTE_TIMEOUT_MS = 8000;

async function fetchJson(url: string): Promise<any> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ROUTE_TIMEOUT_MS);
  try {
    const res = await fetch(url, { signal: controller.signal });
    if (!res.ok) return null;
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

async function googleRoute(originLat: number, originLng: number, destLat: number, destLng: number): Promise<DrivingRoute | null> {
  if (!GOOGLE_MAPS_API_KEY) return null;
  const url =
    `https://maps.googleapis.com/maps/api/directions/json` +
    `?origin=${originLat},${originLng}` +
    `&destination=${destLat},${destLng}` +
    `&mode=driving` +
    `&key=${GOOGLE_MAPS_API_KEY}`;

  const json = await fetchJson(url);
  const route = json?.routes?.[0];
  const decoded = detailedPath(route);

  if (!Array.isArray(decoded) || decoded.length < 2) {
    return null;
  }

  const leg = route?.legs?.[0];
  const distanceMi =
    leg?.distance?.value != null
      ? metersToMiles(Number(leg.distance.value))
      : metersToMiles(Number(route?.legs?.reduce((sum: number, l: { distance?: { value?: number } }) => sum + (l.distance?.value ?? 0), 0) ?? 0));
  const durationMinutes =
    leg?.duration?.value != null
      ? secondsToMinutes(Number(leg.duration.value))
      : secondsToMinutes(Number(route?.legs?.reduce((sum: number, l: { duration?: { value?: number } }) => sum + (l.duration?.value ?? 0), 0) ?? 0));

  return {
    coordinates: decoded.map(([latitude, longitude]: [number, number]) => ({ latitude, longitude })),
    distanceMi,
    durationMinutes,
  };
}

/** Public OSRM demo server: no key, but rate-limited and not for production traffic. */
async function osrmRoute(originLat: number, originLng: number, destLat: number, destLng: number): Promise<DrivingRoute | null> {
  const url =
    `https://router.project-osrm.org/route/v1/driving/${originLng},${originLat};${destLng},${destLat}` +
    `?overview=full&geometries=polyline`;
  const json = await fetchJson(url);
  const route = json?.routes?.[0];
  const enc = route?.geometry;
  if (typeof enc !== 'string') return null;
  const decoded: [number, number][] = polyline.decode(enc);
  if (decoded.length < 2) return null;
  return {
    coordinates: decoded.map(([latitude, longitude]) => ({ latitude, longitude })),
    distanceMi: metersToMiles(Number(route.distance ?? 0)),
    durationMinutes: secondsToMinutes(Number(route.duration ?? 0)),
  };
}

/**
 * Driving route along real roads: Google Directions first, OSRM if Google is unavailable.
 * Returns null if neither can route (no straight-line fallback). Never throws.
 */
export async function fetchDrivingRoute(
  originLat: number,
  originLng: number,
  destLat: number,
  destLng: number
): Promise<DrivingRoute | null> {
  if (
    !Number.isFinite(originLat) ||
    !Number.isFinite(originLng) ||
    !Number.isFinite(destLat) ||
    !Number.isFinite(destLng)
  ) {
    return null;
  }

  try {
    const google = await googleRoute(originLat, originLng, destLat, destLng);
    if (google) return google;
  } catch {}
  try {
    return await osrmRoute(originLat, originLng, destLat, destLng);
  } catch {
    return null;
  }
}
