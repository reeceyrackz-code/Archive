import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Alert } from 'react-native';
import { router } from 'expo-router';
import { supabase } from '../lib/supabase';
import { hapticFeedback } from '../services/HapticFeedbackService';
import { ValeterStatsService } from '../services/Valeterstatsservice';
import { getCustomerDisplayName, fetchProfileById, resolveCustomerAvatarFromProfileRowAsync, resolveCustomerMediaUrlAsync } from '../utils/customerProfiles';
import { releaseBookingValeterPayout } from '../services/bookingPaymentRequestService';
import { promptAndSendBookingPhotoMessage } from '../services/bookingChatMediaService';
import {
  getStages,
  getStageProgressPercent,
  getValeterJobStatusMessage,
  isChatLockedUntilPaid,
} from '../utils/trackingStatusHelpers';
import {
  getServiceTrackingCategory,
  getStartServiceActionLabel,
} from '../utils/serviceNameMapper';
import { fetchDrivingRoute } from '../utils/drivingRoute';
import { toast } from '../components/shared/ToastHost';

function haversineMi(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const toRad = (d: number) => (d * Math.PI) / 180;
  const R = 3958.8;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export type ValeterTrackingStatus =
  | 'pending_valeter_acceptance'
  | 'pending_payment'
  | 'confirmed'
  | 'scheduled'
  | 'en_route'
  | 'arrived'
  | 'in_progress'
  | 'completed'
  | 'cancelled';

export type ValeterTrackingJob = {
  id: string;
  status: ValeterTrackingStatus;
  user_id?: string | null;
  service_type?: string | null;
  service_name?: string | null;
  wash_type?: string | null;
  add_on_ids?: string | string[] | null;
  location_lat?: number | string | null;
  location_lng?: number | string | null;
  location_address?: string | null;
  price?: number | string | null;
  scheduled_at?: string | null;
  vehicle_id?: string | null;
  vehicle_info?: string | null;
  vehicle_registration?: string | null;
  vehicle_make?: string | null;
  vehicle_model?: string | null;
  vehicle_photo?: string | null;
  valeter_response_at?: string | null;
  updated_at?: string | null;
  created_at?: string | null;
};

/** Trip id for the on-device preview: a pretend job that never touches the database. */
export const PREVIEW_JOB_ID = '__trip_preview__';

/** London fallback when the Pro's position isn't known yet. */
const PREVIEW_FALLBACK = { lat: 51.5074, lng: -0.1278 };

function previewJob(origin: { lat?: number | null; lng?: number | null }): ValeterTrackingJob {
  const lat = origin.lat ?? PREVIEW_FALLBACK.lat;
  const lng = origin.lng ?? PREVIEW_FALLBACK.lng;
  const now = new Date().toISOString();
  return {
    id: PREVIEW_JOB_ID,
    status: 'pending_payment',
    service_type: 'wash',
    service_name: 'Full Valet',
    location_lat: lat + 0.012,
    location_lng: lng + 0.009,
    location_address: 'Preview customer',
    price: 45,
    vehicle_registration: 'WA54 SHR',
    vehicle_make: 'Tesla',
    vehicle_model: 'Model 3',
    valeter_response_at: now,
    updated_at: now,
    created_at: now,
  };
}

/** Customer must pay within this window after the valeter accepts. */
export const PAYMENT_WAIT_SECONDS = 300;

export function paymentWaitSecondsRemaining(
  status: string | null | undefined,
  acceptedAtIso?: string | null,
  nowMs = Date.now()
): number | null {
  if (status !== 'pending_payment') return null;
  if (!acceptedAtIso) return PAYMENT_WAIT_SECONDS;
  const start = new Date(acceptedAtIso).getTime();
  if (!Number.isFinite(start)) return PAYMENT_WAIT_SECONDS;
  return Math.max(0, PAYMENT_WAIT_SECONDS - Math.floor((nowMs - start) / 1000));
}

export function formatPaymentWaitClock(totalSeconds: number): string {
  const s = Math.max(0, Math.floor(totalSeconds));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${m}:${r.toString().padStart(2, '0')}`;
}

export type BookingVehicleItem = {
  id: string;
  make?: string;
  model?: string;
  registration?: string;
  colour?: string;
  photo?: string | null;
};

type VehicleDetails = {
  registration?: string;
  make?: string;
  model?: string;
  colour?: string;
  photo?: string;
  /** Full booking vehicle line (supports multiple cars). */
  summaryLine?: string;
} | null;

async function resolveValeterOrigin(
  valeterId: string,
  liveOrigin?: { lat?: number | null; lng?: number | null }
): Promise<{ lat: number; lng: number } | null> {
  const liveLat = liveOrigin?.lat;
  const liveLng = liveOrigin?.lng;
  if (liveLat != null && liveLng != null && Number.isFinite(liveLat) && Number.isFinite(liveLng)) {
    return { lat: liveLat, lng: liveLng };
  }
  const { data } = await supabase
    .from('valeter_presence')
    .select('last_lat, last_lng')
    .eq('user_id', valeterId)
    .maybeSingle();
  if (data?.last_lat == null || data?.last_lng == null) return null;
  return { lat: Number(data.last_lat), lng: Number(data.last_lng) };
}

export function getValeterJobProgress(status: ValeterTrackingStatus): number {
  switch (status) {
    case 'pending_valeter_acceptance':
    case 'pending_payment':
      return 10;
    case 'confirmed':
    case 'scheduled':
      return 25;
    case 'en_route':
      return 50;
    case 'arrived':
      return 70;
    case 'in_progress':
      return 90;
    case 'completed':
      return 100;
    default:
      return 20;
  }
}

function vehicleLabel(row: {
  make?: string | null;
  model?: string | null;
  registration?: string | null;
}): string {
  const name = [row.make, row.model].filter(Boolean).join(' ').trim();
  const reg = row.registration ? ` (${row.registration})` : '';
  return `${name}${reg}`.trim();
}

function matchVehiclesToBookingInfo(
  rows: Array<{
    id: string;
    make?: string | null;
    model?: string | null;
    registration?: string | null;
    colour?: string | null;
    color?: string | null;
    photo?: string | null;
  }>,
  vehicleInfo?: string | null,
  primaryVehicleId?: string | null
): typeof rows {
  if (!rows.length) return [];
  const info = typeof vehicleInfo === 'string' ? vehicleInfo.trim() : '';
  if (!info) {
    const primary = primaryVehicleId ? rows.find((r) => r.id === primaryVehicleId) : null;
    return primary ? [primary] : rows.slice(0, 1);
  }

  const segments = info.split('·').map((s) => s.trim().toLowerCase()).filter(Boolean);
  const matched: typeof rows = [];
  const used = new Set<string>();

  for (const segment of segments) {
    const byReg = rows.find((r) => {
      if (!r.registration || used.has(r.id)) return false;
      return segment.includes(String(r.registration).trim().toLowerCase());
    });
    if (byReg) {
      matched.push(byReg);
      used.add(byReg.id);
      continue;
    }
    const byName = rows.find((r) => {
      if (used.has(r.id)) return false;
      const label = vehicleLabel(r).toLowerCase();
      return Boolean(label && (segment.includes(label) || label.includes(segment)));
    });
    if (byName) {
      matched.push(byName);
      used.add(byName.id);
    }
  }

  if (matched.length > 0) return matched;
  const primary = primaryVehicleId ? rows.find((r) => r.id === primaryVehicleId) : null;
  return primary ? [primary] : rows.slice(0, 1);
}

type CustomerVehicleRow = {
  id: string;
  make?: string | null;
  model?: string | null;
  registration?: string | null;
  colour?: string | null;
  color?: string | null;
  photo?: string | null;
};

const VEHICLE_COLS = 'id, registration, make, model, colour, color, photo';

/** The customer's saved vehicles, tolerating older schemas without a colour column. */
async function fetchCustomerVehicleRows(
  userId: string | null,
  vehicleId: string | null | undefined
): Promise<CustomerVehicleRow[]> {
  if (userId) {
    const res = await supabase.from('customer_vehicles').select(VEHICLE_COLS).eq('user_id', userId);
    if (!res.error || !/colour|color|schema cache|does not exist/i.test(res.error.message || '')) {
      return (res.data as CustomerVehicleRow[] | null) || [];
    }
    const fallback = await supabase.from('customer_vehicles').select('id, registration, make, model, photo').eq('user_id', userId);
    return ((fallback.data as CustomerVehicleRow[] | null) || []).map((r) => ({ ...r, colour: null, color: null }));
  }
  if (!vehicleId) return [];
  const { data } = await supabase.from('customer_vehicles').select(VEHICLE_COLS).eq('id', vehicleId).maybeSingle();
  return data ? [data as CustomerVehicleRow] : [];
}

/** "Ford Fiesta (AB12 CDE)" → name and registration, using string ops rather than a backtracking regex. */
function splitTrailingReg(label: string): { name: string; registration?: string } {
  const text = label.trimEnd();
  const open = text.lastIndexOf('(');
  if (!text.endsWith(')') || open < 0) return { name: text.trim() };
  const registration = text.slice(open + 1, -1).trim() || undefined;
  return { name: text.slice(0, open).trim(), registration };
}

function summaryParts(summaryLine: string) {
  return summaryLine.split('·').map((s) => s.trim()).filter(Boolean);
}

/** Vehicles described only by the booking's summary line, e.g. "Ford Fiesta (AB12 CDE) · VW Golf". */
function vehiclesFromSummary(summaryLine: string): BookingVehicleItem[] {
  return summaryParts(summaryLine).map((label, i) => {
    const { name, registration } = splitTrailingReg(label);
    const [make, ...rest] = name.split(/\s+/);
    return {
      id: `info-${i}`,
      make: make || name || 'Vehicle',
      model: rest.join(' ') || undefined,
      registration,
      photo: null,
    };
  });
}

async function withResolvedPhoto(row: CustomerVehicleRow): Promise<BookingVehicleItem> {
  return {
    id: row.id,
    make: row.make ?? undefined,
    model: row.model ?? undefined,
    registration: row.registration ?? undefined,
    colour: row.colour || row.color || undefined,
    photo: row.photo ? (await resolveCustomerMediaUrlAsync(row.photo)) || null : null,
  };
}

async function loadVehicleDetails(
  userId: string | null,
  booking: { vehicle_id?: string | null; vehicle_info?: string | null } | null,
  setVehicleDetails: (v: VehicleDetails) => void,
  setBookingVehicles: (v: BookingVehicleItem[]) => void
) {
  const summaryLine =
    typeof booking?.vehicle_info === 'string' && booking.vehicle_info.trim()
      ? booking.vehicle_info.trim()
      : undefined;

  if (!userId && !summaryLine) {
    setBookingVehicles([]);
    return;
  }

  try {
    const rows = await fetchCustomerVehicleRows(userId, booking?.vehicle_id);
    const matched = matchVehiclesToBookingInfo(rows, booking?.vehicle_info, booking?.vehicle_id);
    const withPhotos = await Promise.all(matched.map(withResolvedPhoto));
    const useSummary = withPhotos.length === 0 && summaryLine;
    setBookingVehicles(useSummary ? vehiclesFromSummary(summaryLine) : withPhotos);

    const primary = withPhotos[0];
    setVehicleDetails({
      registration: primary?.registration,
      make: primary?.make,
      model: primary?.model,
      colour: primary?.colour,
      photo: primary?.photo || undefined,
      summaryLine,
    });
  } catch {
    if (!summaryLine) {
      setBookingVehicles([]);
      return;
    }
    setVehicleDetails({ summaryLine });
    setBookingVehicles(summaryParts(summaryLine).map((label, i) => ({ id: `info-${i}`, make: label, photo: null })));
  }
}

export function useValeterJobTracking(
  jobId: string | null,
  valeterId: string | null,
  options?: {
    onClose?: () => void;
    onJobUpdated?: () => void;
    originLat?: number | null;
    originLng?: number | null;
  }
) {
  const onCloseRef = useRef(options?.onClose);
  const onJobUpdatedRef = useRef(options?.onJobUpdated);
  onCloseRef.current = options?.onClose;
  onJobUpdatedRef.current = options?.onJobUpdated;
  const [job, setJob] = useState<ValeterTrackingJob | null>(null);
  const [status, setStatus] = useState<ValeterTrackingStatus>('pending_payment');
  const [customerName, setCustomerName] = useState('Customer');
  const [customerPhotoUrl, setCustomerPhotoUrl] = useState<string | null>(null);
  const [vehicleDetails, setVehicleDetails] = useState<VehicleDetails>(null);
  const [bookingVehicles, setBookingVehicles] = useState<BookingVehicleItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [cancelling, setCancelling] = useState(false);
  const [infoSheetVisible, setInfoSheetVisible] = useState(false);
  const [etaMinutes, setEtaMinutes] = useState<number | null>(null);
  const [distanceMi, setDistanceMi] = useState<number | null>(null);
  const [routeCoordinates, setRouteCoordinates] = useState<{ latitude: number; longitude: number }[] | null>(null);
  const [paymentSecondsLeft, setPaymentSecondsLeft] = useState<number | null>(null);
  const paymentTimeoutFiredRef = useRef(false);
  const isPreview = jobId === PREVIEW_JOB_ID;
  const originRef = useRef({ lat: options?.originLat, lng: options?.originLng });
  originRef.current = { lat: options?.originLat, lng: options?.originLng };

  const loadJob = useCallback(async (id: string) => {
    if (id === PREVIEW_JOB_ID) {
      const row = previewJob(originRef.current);
      setJob(row);
      setStatus(row.status);
      setCustomerName('Jimmy');
      setCustomerPhotoUrl(null);
      setVehicleDetails({ registration: 'WA54 SHR', make: 'Tesla', model: 'Model 3', colour: 'White' });
      setBookingVehicles([]);
      return;
    }
    setLoading(true);
    try {
      const { data, error } = await supabase.from('bookings').select('*').eq('id', id).single();
      if (error || !data) {
        toast.error('Job not found');
        onCloseRef.current?.();
        return;
      }
      const row = data as ValeterTrackingJob;
      setJob({
        ...row,
        vehicle_photo: (await resolveCustomerMediaUrlAsync(row.vehicle_photo)) || row.vehicle_photo,
      });
      setStatus(row.status);
      if (row.user_id) {
        setCustomerName(await getCustomerDisplayName(row.user_id));
        const profile = await fetchProfileById(row.user_id);
        setCustomerPhotoUrl(await resolveCustomerAvatarFromProfileRowAsync(profile));
      } else {
        setCustomerName('Customer');
        setCustomerPhotoUrl(null);
      }
      await loadVehicleDetails(row.user_id ?? null, row, setVehicleDetails, setBookingVehicles);
    } catch (e: any) {
      toast.error(e?.message ?? 'Failed to load job');
      onCloseRef.current?.();
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!jobId) {
      setJob(null);
      setRouteCoordinates(null);
      setCustomerPhotoUrl(null);
      setVehicleDetails(null);
      setBookingVehicles([]);
      setPaymentSecondsLeft(null);
      paymentTimeoutFiredRef.current = false;
      return;
    }
    paymentTimeoutFiredRef.current = false;
    void loadJob(jobId);
  }, [jobId, loadJob]);

  useEffect(() => {
    if (status !== 'pending_payment' || !job) {
      setPaymentSecondsLeft(null);
      return;
    }
    const acceptedAt = job.valeter_response_at || job.updated_at || job.created_at || null;
    const tick = () => {
      const left = paymentWaitSecondsRemaining(status, acceptedAt);
      setPaymentSecondsLeft(left);
      return left;
    };
    tick();
    const id = setInterval(() => {
      const left = tick();
      if (left === 0 && !paymentTimeoutFiredRef.current && jobId && jobId !== PREVIEW_JOB_ID) {
        paymentTimeoutFiredRef.current = true;
        void (async () => {
          const { error } = await supabase
            .from('bookings')
            .update({ status: 'cancelled' })
            .eq('id', jobId)
            .eq('status', 'pending_payment');
          if (error) {
            paymentTimeoutFiredRef.current = false;
            return;
          }
          setStatus('cancelled');
          Alert.alert(
            'Payment timed out',
            'The customer didn’t complete payment within 5 minutes. This job was cancelled.',
            [{ text: 'OK', onPress: () => onCloseRef.current?.() }]
          );
          onJobUpdatedRef.current?.();
        })();
      }
    }, 1000);
    return () => clearInterval(id);
  }, [status, job, jobId]);

  useEffect(() => {
    if (!jobId || jobId === PREVIEW_JOB_ID) return;
    const ch = supabase
      .channel(`valeter-dash-tracking-${jobId}`)
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'bookings', filter: `id=eq.${jobId}` },
        (payload) => {
          const nextRow = payload.new as Partial<ValeterTrackingJob> | undefined;
          const next = nextRow?.status as string | undefined;
          if (next) {
            setStatus(next as ValeterTrackingStatus);
            setJob((prev) =>
              prev
                ? {
                    ...prev,
                    ...nextRow,
                    status: next as ValeterTrackingStatus,
                  }
                : prev
            );
          }
          if (next === 'completed') {
            router.push({ pathname: '/valeter/jobs/complete', params: { jobId } } as any);
          }
          if (next === 'cancelled' || next === 'valeter_timeout') {
            onCloseRef.current?.();
          }
          onJobUpdatedRef.current?.();
        }
      )
      .subscribe();
    return () => {
      void supabase.removeChannel(ch);
    };
  }, [jobId]);

  useEffect(() => {
    if (!valeterId || !job?.location_lat || !job?.location_lng) {
      setEtaMinutes(null);
      setDistanceMi(null);
      setRouteCoordinates(null);
      return;
    }

    // Keep an ETA on the header for any pre-arrival live status.
    const shouldRoute =
      status === 'en_route' ||
      status === 'confirmed' ||
      status === 'scheduled' ||
      status === 'pending_payment' ||
      status === 'arrived';

    if (!shouldRoute) {
      setEtaMinutes(null);
      setDistanceMi(null);
      setRouteCoordinates(null);
      return;
    }

    let cancelled = false;
    void (async () => {
      const origin = await resolveValeterOrigin(valeterId, {
        lat: options?.originLat,
        lng: options?.originLng,
      });
      if (cancelled || !origin) {
        setRouteCoordinates(null);
        setEtaMinutes(null);
        setDistanceMi(null);
        return;
      }

      const destLat = Number(job.location_lat);
      const destLng = Number(job.location_lng);

      if (status === 'arrived') {
        const mi = haversineMi(origin.lat, origin.lng, destLat, destLng);
        if (!cancelled) {
          setRouteCoordinates(null);
          setDistanceMi(Math.round(mi * 10) / 10);
          setEtaMinutes(0);
        }
        return;
      }

      const route = await fetchDrivingRoute(origin.lat, origin.lng, destLat, destLng);
      if (cancelled) return;

      if (route && route.coordinates.length > 1) {
        setRouteCoordinates(route.coordinates);
        setDistanceMi(route.distanceMi);
        setEtaMinutes(route.durationMinutes);
        return;
      }

      // Fallback when routing API is unavailable.
      const mi = haversineMi(origin.lat, origin.lng, destLat, destLng);
      const mins = Math.max(1, Math.round((mi / 18) * 60));
      setRouteCoordinates(null);
      setDistanceMi(Math.round(mi * 10) / 10);
      setEtaMinutes(mins);
    })();

    return () => {
      cancelled = true;
    };
  }, [valeterId, job?.id, job?.location_lat, job?.location_lng, status, options?.originLat, options?.originLng]);

  const updateStatus = useCallback(
    async (newStatus: ValeterTrackingStatus) => {
      if (!jobId || !valeterId) return;
      await hapticFeedback('medium');
      if (jobId === PREVIEW_JOB_ID) {
        setStatus(newStatus);
        setJob((prev) => (prev ? { ...prev, status: newStatus, updated_at: new Date().toISOString() } : prev));
        if (newStatus === 'completed') {
          toast.info('That was the whole trip.', 'Preview finished');
          onCloseRef.current?.();
        }
        return;
      }
      try {
        const payload: { status: string; completed_at?: string } = { status: newStatus };
        if (newStatus === 'completed') payload.completed_at = new Date().toISOString();

        const { error } = await supabase.from('bookings').update(payload).eq('id', jobId);
        if (error) throw error;

        setStatus(newStatus);
        if (newStatus === 'completed') {
          await ValeterStatsService.recordJobCompletion(valeterId, jobId);
          try {
            await releaseBookingValeterPayout({ bookingId: jobId });
          } catch (releaseError: any) {
            toast.info(releaseError?.message || 'Job marked complete; payout release pending.', 'Job completed');
          }
          router.push({ pathname: '/valeter/jobs/complete', params: { jobId } } as any);
        }
        onJobUpdatedRef.current?.();
      } catch (e: any) {
        toast.error(e?.message ?? 'Failed to update');
      }
    },
    [jobId, valeterId]
  );

  const startWashWithPhoto = useCallback(async () => {
    if (!jobId || !valeterId) return;
    if (jobId === PREVIEW_JOB_ID) {
      await updateStatus('in_progress');
      return;
    }
    try {
      const sent = await promptAndSendBookingPhotoMessage({
        bookingId: jobId,
        senderId: valeterId,
        senderRole: 'valeter',
        content: 'BEFORE IMAGE',
        promptTitle: 'Photo required',
        promptMessage: 'You need to take a picture before starting.',
      });
      if (!sent) return;
      await updateStatus('in_progress');
    } catch (e: any) {
      toast.error(e?.message ?? 'Could not take or send the photo.', 'Photo required');
    }
  }, [jobId, valeterId, updateStatus]);

  const completeWashWithPhoto = useCallback(async () => {
    if (!jobId || !valeterId) return;
    if (jobId === PREVIEW_JOB_ID) {
      await updateStatus('completed');
      return;
    }
    try {
      const sent = await promptAndSendBookingPhotoMessage({
        bookingId: jobId,
        senderId: valeterId,
        senderRole: 'valeter',
        content: 'Finished IMAGE',
        promptTitle: 'Photo required',
        promptMessage: 'You need to take a picture before finishing.',
      });
      if (!sent) return;
      await updateStatus('completed');
    } catch (e: any) {
      toast.error(e?.message ?? 'Could not take or send the photo.', 'Photo required');
    }
  }, [jobId, valeterId, updateStatus]);

  const serviceCategory = getServiceTrackingCategory(job?.service_type, job?.service_name);

  const nextAction = useMemo(() => {
    const startLabel = getStartServiceActionLabel(serviceCategory);
    switch (status) {
      case 'pending_valeter_acceptance':
        return { label: 'Accept', action: () => updateStatus('pending_payment') };
      case 'pending_payment':
        return isPreview ? { label: 'Customer paid', action: () => updateStatus('confirmed') } : null;
      case 'confirmed':
      case 'scheduled':
        return { label: 'Set off', action: () => updateStatus('en_route') };
      case 'en_route':
        return { label: 'Arrived', action: () => updateStatus('arrived') };
      case 'arrived':
        return { label: startLabel, action: () => startWashWithPhoto() };
      case 'in_progress':
        return { label: 'Done', action: () => completeWashWithPhoto() };
      default:
        return null;
    }
  }, [status, updateStatus, startWashWithPhoto, completeWashWithPhoto, serviceCategory, isPreview]);

  /** Cancelling is only allowed before the valeter sets off — locked from en route onwards. */
  const canCancel =
    status === 'pending_valeter_acceptance' ||
    status === 'pending_payment' ||
    status === 'confirmed' ||
    status === 'scheduled';

  const handleCancel = useCallback(() => {
    if (!canCancel || !jobId) return;
    void hapticFeedback('light');
    if (jobId === PREVIEW_JOB_ID) {
      onCloseRef.current?.();
      return;
    }
    Alert.alert('Cancel job', 'Cancel this job? The customer will be notified.', [
      { text: 'No', style: 'cancel' },
      {
        text: 'Yes, cancel',
        style: 'destructive',
        onPress: () => {
          void (async () => {
            setCancelling(true);
            const { error } = await supabase.from('bookings').update({ status: 'cancelled' }).eq('id', jobId);
            if (error) toast.error(error.message);
            else {
              setStatus('cancelled');
              Alert.alert('Cancelled', 'Job cancelled.', [{ text: 'OK', onPress: () => onCloseRef.current?.() }]);
            }
            setCancelling(false);
            onJobUpdatedRef.current?.();
          })();
        },
      },
    ]);
  }, [canCancel, jobId]);

  /** Cancels with a Pro-selected reason. Resolves true on success. */
  const cancelWithReason = useCallback(
    async (reason: string): Promise<boolean> => {
      if (!canCancel || !jobId) return false;
      if (jobId === PREVIEW_JOB_ID) {
        setStatus('cancelled');
        return true;
      }
      setCancelling(true);
      try {
        let { error } = await supabase
          .from('bookings')
          .update({ status: 'cancelled', cancelled_by: 'valeter', cancellation_reason: reason })
          .eq('id', jobId);
        if (error && /cancelled_by|cancellation_reason/i.test(error.message)) {
          ({ error } = await supabase.from('bookings').update({ status: 'cancelled' }).eq('id', jobId));
        }
        if (error) {
          toast.error(error.message, 'Could not cancel');
          return false;
        }
        setStatus('cancelled');
        onJobUpdatedRef.current?.();
        return true;
      } finally {
        setCancelling(false);
      }
    },
    [canCancel, jobId]
  );

  const handleChat = useCallback(() => {
    if (!jobId || isChatLockedUntilPaid(status)) return;
    if (jobId === PREVIEW_JOB_ID) {
      toast.info('Chat is off in the preview.');
      return;
    }
    void hapticFeedback('light');
    router.push({ pathname: '/valeter/jobs/chat', params: { bookingId: jobId } } as any);
  }, [jobId, status]);

  const customerCoords = useMemo(() => {
    if (!job?.location_lat || !job?.location_lng) return null;
    return { latitude: Number(job.location_lat), longitude: Number(job.location_lng) };
  }, [job?.location_lat, job?.location_lng]);

  const stages = getStages(status, serviceCategory, true);
  const stageProgressPercent = getStageProgressPercent(status, serviceCategory, true);
  const statusMessage = useMemo(() => getValeterJobStatusMessage(status), [status]);

  return {
    job,
    status,
    customerName,
    customerPhotoUrl,
    vehicleDetails,
    bookingVehicles,
    loading,
    cancelling,
    infoSheetVisible,
    setInfoSheetVisible,
    etaMinutes,
    distanceMi,
    routeCoordinates,
    customerCoords,
    nextAction,
    canCancel,
    handleCancel,
    cancelWithReason,
    handleChat,
    paymentSecondsLeft,
    stages,
    stageProgressPercent,
    statusMessage,
    reload: () => jobId && loadJob(jobId),
  };
}
