import React, { useEffect, useRef } from 'react';
import { Animated, Easing, Image, StyleSheet, View } from 'react-native';
import { CAR_IMAGE } from '../../constants/washerAssets';

const PULSE_MS = 1600;

function OfferPulse({ size, color }: Readonly<{ size: number; color: string }>) {
  const t = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const anim = Animated.loop(
      Animated.sequence([
        Animated.timing(t, { toValue: 1, duration: PULSE_MS, easing: Easing.out(Easing.quad), useNativeDriver: true }),
        Animated.timing(t, { toValue: 0, duration: 0, useNativeDriver: true }),
      ])
    );
    anim.start();
    return () => anim.stop();
  }, [t]);
  return (
    <Animated.View
      style={[
        styles.pulse,
        {
          width: size,
          height: size,
          borderRadius: size / 2,
          borderColor: color,
          backgroundColor: `${color}33`,
          opacity: t.interpolate({ inputRange: [0, 1], outputRange: [0.8, 0] }),
          transform: [{ scale: t.interpolate({ inputRange: [0, 1], outputRange: [0.8, 2] }) }],
        },
      ]}
    />
  );
}

/** Customer pin for a live job offer: the car, pulsing in the route colour; the offer in focus is larger. */
export default function ValeterMapOfferMarker({
  focused = false,
  accent,
}: Readonly<{ focused?: boolean; accent: string }>) {
  const car = focused ? 40 : 30;

  return (
    <View style={styles.wrap} collapsable={false}>
      <View style={[styles.pinBox, { width: car * 2.4, height: car * 2.4 }]}>
        <OfferPulse size={car * 1.2} color={accent} />
        <Image source={CAR_IMAGE} style={[styles.car, { width: car, height: car }]} resizeMode="contain" />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { alignItems: 'center' },
  pinBox: { alignItems: 'center', justifyContent: 'center' },
  pulse: { position: 'absolute', borderWidth: 2.5 },
  car: {
    shadowColor: '#000',
    shadowOpacity: 0.45,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
  },
});
