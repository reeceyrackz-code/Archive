// Google Maps API Configuration
// Set EXPO_PUBLIC_GOOGLE_MAPS_API_KEY in `.env` (local) and in EAS environment variables (builds).
// Restrict the key in Google Cloud Console to this app's bundle IDs and to the Directions API.

export const GOOGLE_MAPS_API_KEY = process.env.EXPO_PUBLIC_GOOGLE_MAPS_API_KEY ?? '';

export const MAPS_CONFIG = {
  apiKey: GOOGLE_MAPS_API_KEY,
  defaultCenter: {
    lat: 51.5074, // London coordinates
    lng: -0.1278
  },
  defaultZoom: 15,
  mapStyles: [
    {
      featureType: 'poi',
      elementType: 'labels',
      stylers: [{ visibility: 'off' }]
    }
  ]
};
