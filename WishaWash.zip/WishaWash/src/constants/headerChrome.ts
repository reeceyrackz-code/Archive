/** Shared look for every top header bar: dark glass strip, hairline border, bordered square tiles. */
export const HEADER_TILE = 44;
export const HEADER_TILE_RADIUS = 14;
export const HEADER_TILE_BORDER = 'rgba(148,196,220,0.26)';
export const HEADER_TILE_BG = 'rgba(255,255,255,0.05)';
export const HEADER_BAR_PAD_TOP = 6;
export const HEADER_BAR_PAD_BOTTOM = 10;
export const HEADER_BAR_PAD_H = 16;
/** Bar height below the safe-area inset (top pad + tile row + bottom pad). */
export const HEADER_BAR_BODY = HEADER_BAR_PAD_TOP + HEADER_TILE + HEADER_BAR_PAD_BOTTOM;
