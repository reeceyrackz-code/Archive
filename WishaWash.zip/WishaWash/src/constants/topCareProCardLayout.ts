import { Dimensions } from 'react-native';
import { BREAKPOINTS, SMALL_PHONE } from './adaptiveLayout';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

/** Proportional scale for full Top Care Pro card tiles (avatar, type, stats). */
export const TOP_CARE_PRO_CARD_ZOOM = 0.78;

/** Global dashboard density — slightly pulled back so tiles feel less zoomed in. */
const DASHBOARD_ZOOM = 0.62;
/** Book A Wish + Your Hub icons stay slightly larger as well. */
const DASHBOARD_HERO_ZOOM = 0.7;
/** Dashboard-only card scale (Explore / booking keep TOP_CARE_PRO_CARD_ZOOM). */
const DASHBOARD_CARD_ZOOM = 0.78;

/** iPhone 14-class width used as the dashboard scale baseline. */
const BASE_WIDTH = 390;

export const dz = (n: number) => Math.round(n * DASHBOARD_ZOOM);
/** Unchanged scale for Book A Wish CTA and Your Hub quick actions. */
export const dzHero = (n: number) => Math.round(n * DASHBOARD_HERO_ZOOM);
export const cpz = (n: number) => Math.round(n * DASHBOARD_CARD_ZOOM);

export type DashboardLayout = {
  scale: number;
  isSmallPhone: boolean;
  isTablet: boolean;
  mapHeight: number;
  mapRadius: number;
  mapZoomDelta: number;
  pillFontSize: number;
  pillPadH: number;
  pillPadV: number;
  pillBottom: number;
  kickerFontSize: number;
  hubScale: number;
  profilePicSize: number;
};

/** Live dashboard metrics so map, pills, and hub tiles track phone vs tablet size. */
export function getDashboardLayout(width: number, height: number): DashboardLayout {
  const isSmallPhone = width < SMALL_PHONE;
  const isTablet = width >= BREAKPOINTS.tablet;
  const scale = Math.min(1.18, Math.max(0.88, width / BASE_WIDTH));

  const mapHeight = isTablet
    ? Math.round(Math.min(320, Math.max(240, height * 0.26)))
    : isSmallPhone
      ? Math.round(Math.min(180, Math.max(150, height * 0.2)))
      : Math.round(Math.min(240, Math.max(180, height * 0.23)));

  return {
    scale,
    isSmallPhone,
    isTablet,
    mapHeight,
    mapRadius: Math.round(22 * scale),
    mapZoomDelta: isTablet ? 0.006 : isSmallPhone ? 0.0035 : 0.004,
    pillFontSize: isTablet ? 17 : isSmallPhone ? 13 : 15,
    pillPadH: isTablet ? 34 : isSmallPhone ? 22 : 28,
    pillPadV: isTablet ? 15 : isSmallPhone ? 10 : 13,
    pillBottom: isTablet ? 28 : isSmallPhone ? 16 : 22,
    kickerFontSize: isTablet ? 12 : isSmallPhone ? 10 : 10.5,
    hubScale: isTablet ? 0.94 : isSmallPhone ? 0.76 : 0.82,
    profilePicSize: isTablet ? 42 : isSmallPhone ? 34 : 38,
  };
}

/** Phone-width carousel tile — nearly full dashboard width with a next-card peek. */
export function getTopCareProCardWidth(screenWidth: number = SCREEN_WIDTH): number {
  const isSmallScreen = screenWidth < SMALL_PHONE;
  const isTablet = screenWidth >= BREAKPOINTS.tablet;
  const inset = isTablet ? 28 : isSmallScreen ? 12 : 16;
  const peek = isSmallScreen ? 28 : isTablet ? 48 : 36;
  return Math.max(260, screenWidth - inset * 2 - peek);
}
