import { customerTheme } from './customerTheme';
import { ICON_AUTH } from '../../assets/_assetExports';

/** Matches `splash.backgroundColor` in app.config.ts */
export const SPLASH_BACKGROUND_COLOR = customerTheme.backgroundGradient[0];

/** Matches `splash.image` in app.config.ts */
export const SPLASH_LOGO_SOURCE = ICON_AUTH;

/** Matches `expo-splash-screen` plugin `imageWidth` in app.config.ts */
export const SPLASH_LOGO_WIDTH = 200;
