import { useEffect, useState, type ReactNode } from 'react';
import {
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
  type LayoutChangeEvent,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, {
  css,
  useAnimatedStyle,
  useReducedMotion,
  useSharedValue,
  withDelay,
  withSpring,
} from 'react-native-reanimated';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import type { HubGlassPalette } from '../shared/HubGlassIcon';

type KeyframesRule = ReturnType<typeof css.keyframes>;
export type Seconds = `${number}s`;

export const LOCKED_PALETTE: HubGlassPalette = {
  gradient: ['rgba(100,116,139,0.32)', 'rgba(51,65,85,0.28)', 'rgba(15,23,42,0.4)'],
  icon: 'rgba(203,213,225,0.55)',
  rim: 'rgba(148,163,184,0.3)',
  glow: '#64748B',
};

const drift = css.keyframes({
  '0%': { transform: [{ translateX: 0 }, { translateY: 0 }, { scale: 1 }] },
  '33%': { transform: [{ translateX: 26 }, { translateY: -14 }, { scale: 1.12 }] },
  '66%': { transform: [{ translateX: -18 }, { translateY: 12 }, { scale: 0.94 }] },
  '100%': { transform: [{ translateX: 0 }, { translateY: 0 }, { scale: 1 }] },
});

const sweep = css.keyframes({
  '0%': { transform: [{ translateX: -260 }, { rotate: '18deg' }], opacity: 0 },
  '10%': { opacity: 1 },
  '45%': { transform: [{ translateX: 520 }, { rotate: '18deg' }], opacity: 0 },
  '100%': { transform: [{ translateX: 520 }, { rotate: '18deg' }], opacity: 0 },
});

export const pulseRing = css.keyframes({
  from: { transform: [{ scale: 1 }], opacity: 0.65 },
  to: { transform: [{ scale: 1.55 }], opacity: 0 },
});

export const softBob = css.keyframes({
  '0%': { transform: [{ translateY: 0 }] },
  '50%': { transform: [{ translateY: -4 }] },
  '100%': { transform: [{ translateY: 0 }] },
});

export function loopAnim(
  name: KeyframesRule,
  duration: Seconds,
  delay: Seconds = '0s',
  timing: 'linear' | 'ease-out' | 'ease-in-out' = 'ease-in-out',
) {
  return {
    animationName: name,
    animationDuration: duration,
    animationDelay: delay,
    animationIterationCount: 'infinite',
    animationTimingFunction: timing,
  } as const;
}

export function withAlpha(hex: string, alpha: number): string {
  const a = Math.round(Math.max(0, Math.min(1, alpha)) * 255)
    .toString(16)
    .padStart(2, '0');
  return `${hex.slice(0, 7)}${a}`;
}

export function useCountUp(target: number, durationMs = 900) {
  const reduced = useReducedMotion();
  const [value, setValue] = useState(reduced ? target : 0);
  useEffect(() => {
    if (reduced) {
      setValue(target);
      return;
    }
    let raf = 0;
    const start = Date.now();
    const tick = () => {
      const t = Math.min(1, (Date.now() - start) / durationMs);
      setValue(target * (1 - Math.pow(1 - t, 3)));
      if (t < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, durationMs, reduced]);
  return value;
}

export function PressScale({
  children,
  onPress,
  style,
  containerStyle,
  disabled,
  haptic = true,
  accessibilityLabel,
  to = 0.96,
}: Readonly<{
  children: ReactNode;
  onPress?: (() => void) | undefined;
  style?: StyleProp<ViewStyle>;
  containerStyle?: StyleProp<ViewStyle>;
  disabled?: boolean;
  haptic?: boolean;
  accessibilityLabel?: string;
  to?: number;
}>) {
  const scale = useSharedValue(1);
  const animatedStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  return (
    <Pressable
      style={containerStyle}
      disabled={disabled || !onPress}
      onPress={() => {
        if (haptic) void hapticFeedback('light');
        onPress?.();
      }}
      onPressIn={() => {
        scale.value = withSpring(to, { damping: 18, stiffness: 340 });
      }}
      onPressOut={() => {
        scale.value = withSpring(1, { damping: 13, stiffness: 260 });
      }}
      accessibilityRole="button"
      {...(accessibilityLabel ? { accessibilityLabel } : {})}
    >
      <Animated.View style={[style, animatedStyle]}>{children}</Animated.View>
    </Pressable>
  );
}

/** Frosted card tinted from any 6-digit hex accent. */
export function GlassCard({
  accent,
  children,
  style,
  contentStyle,
  aurora,
  shimmer,
  strong,
}: Readonly<{
  accent: string;
  children: ReactNode;
  style?: StyleProp<ViewStyle>;
  contentStyle?: StyleProp<ViewStyle>;
  /** Second colour for the drifting aurora glow. */
  aurora?: string;
  shimmer?: boolean;
  strong?: boolean;
}>) {
  const reduced = useReducedMotion();
  return (
    <View style={[kit.card, { borderColor: withAlpha(accent, strong ? 0.42 : 0.24) }, style]}>
      <View style={[StyleSheet.absoluteFill, kit.clip]} pointerEvents="none">
        <View style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(8,15,30,0.42)' }]} />
        <BlurView
          intensity={Platform.OS === 'ios' ? 30 : 42}
          tint="dark"
          style={StyleSheet.absoluteFill}
          {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
        />
        {aurora && !reduced ? (
          <>
            <Animated.View
              style={[
                kit.orb,
                { backgroundColor: withAlpha(accent, 0.34), top: -90, left: -60 },
                loopAnim(drift, '9s'),
              ]}
            />
            <Animated.View
              style={[
                kit.orb,
                { backgroundColor: withAlpha(aurora, 0.26), bottom: -110, right: -70 },
                loopAnim(drift, '11s', '1.5s'),
              ]}
            />
          </>
        ) : null}
        <LinearGradient
          colors={[withAlpha(accent, strong ? 0.3 : 0.16), withAlpha(accent, 0.05), 'rgba(2,6,23,0.18)']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={StyleSheet.absoluteFill}
        />
        <LinearGradient
          colors={['rgba(255,255,255,0.12)', 'rgba(255,255,255,0.02)', 'transparent']}
          start={{ x: 0.1, y: 0 }}
          end={{ x: 0.6, y: 0.7 }}
          style={StyleSheet.absoluteFill}
        />
        {shimmer && !reduced ? (
          <Animated.View style={[kit.sweep, loopAnim(sweep, '5.5s', '1.2s', 'linear')]}>
            <LinearGradient
              colors={['transparent', 'rgba(255,255,255,0.12)', 'transparent']}
              start={{ x: 0, y: 0.5 }}
              end={{ x: 1, y: 0.5 }}
              style={StyleSheet.absoluteFill}
            />
          </Animated.View>
        ) : null}
      </View>
      <View style={[kit.cardBody, contentStyle]}>{children}</View>
    </View>
  );
}

/** Track with a spring-filled gradient bar and a glowing head. */
export function SpringBar({
  progress,
  colors,
  height = 8,
  delay = 200,
  style,
}: Readonly<{
  progress: number;
  colors: readonly [string, string];
  height?: number;
  delay?: number;
  style?: StyleProp<ViewStyle>;
}>) {
  const [width, setWidth] = useState(0);
  const fill = useSharedValue(0);
  const clamped = Math.max(0, Math.min(100, progress));

  useEffect(() => {
    if (width <= 0) return;
    fill.value = withDelay(delay, withSpring((clamped / 100) * width, { damping: 20, stiffness: 90 }));
  }, [clamped, width, delay, fill]);

  const fillStyle = useAnimatedStyle(() => ({ width: Math.max(0, fill.value) }));

  return (
    <View
      style={[kit.track, { height, borderRadius: height / 2 }, style]}
      onLayout={(e: LayoutChangeEvent) => setWidth(e.nativeEvent.layout.width)}
    >
      <Animated.View style={[kit.fill, { borderRadius: height / 2, shadowColor: colors[1] }, fillStyle]}>
        <LinearGradient
          colors={[...colors]}
          start={{ x: 0, y: 0.5 }}
          end={{ x: 1, y: 0.5 }}
          style={[StyleSheet.absoluteFill, { borderRadius: height / 2 }]}
        />
        {clamped > 0 ? (
          <View
            style={[
              kit.head,
              {
                width: height + 4,
                height: height + 4,
                borderRadius: (height + 4) / 2,
                right: -2,
                top: -2,
                shadowColor: colors[1],
              },
            ]}
          />
        ) : null}
      </Animated.View>
    </View>
  );
}

export function SectionHeader({
  title,
  meta,
  actionLabel,
  onAction,
}: Readonly<{ title: string; meta?: string; actionLabel?: string; onAction?: () => void }>) {
  return (
    <View style={kit.sectionHead}>
      <Text style={kit.sectionTitle}>{title}</Text>
      {actionLabel && onAction ? (
        <Pressable onPress={onAction} hitSlop={10} accessibilityRole="button">
          <Text style={kit.sectionAction}>{actionLabel}</Text>
        </Pressable>
      ) : meta ? (
        <Text style={kit.sectionMeta}>{meta}</Text>
      ) : null}
    </View>
  );
}

const kit = StyleSheet.create({
  card: {
    borderRadius: 24,
    borderWidth: 1,
    overflow: 'hidden',
  },
  clip: {
    overflow: 'hidden',
    borderRadius: 24,
  },
  cardBody: {
    padding: 18,
  },
  orb: {
    position: 'absolute',
    width: 220,
    height: 220,
    borderRadius: 110,
  },
  sweep: {
    position: 'absolute',
    top: -60,
    bottom: -60,
    width: 90,
  },
  track: {
    backgroundColor: 'rgba(148,163,184,0.16)',
    overflow: 'visible',
  },
  fill: {
    height: '100%',
    shadowOpacity: 0.6,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 0 },
  },
  head: {
    position: 'absolute',
    backgroundColor: '#FFFFFF',
    shadowOpacity: 0.9,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 0 },
  },
  sectionHead: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
    paddingHorizontal: 2,
  },
  sectionTitle: {
    color: '#F1F5F9',
    fontSize: 17,
    fontWeight: '800',
    letterSpacing: -0.2,
  },
  sectionMeta: {
    color: 'rgba(148,163,184,0.85)',
    fontSize: 12,
    fontWeight: '700',
  },
  sectionAction: {
    color: '#7DD3FC',
    fontSize: 13,
    fontWeight: '800',
  },
});
