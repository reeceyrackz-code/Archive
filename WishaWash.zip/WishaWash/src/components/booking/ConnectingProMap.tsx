import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Image, Pressable, StyleSheet, Text, View, useWindowDimensions, type GestureResponderEvent } from 'react-native';
import Animated, {
  Easing,
  cancelAnimation,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withRepeat,
  withSequence,
  withTiming,
  type SharedValue,
} from 'react-native-reanimated';
import type MapView from 'react-native-maps';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import SafeMapView from '../maps/SafeMapView';
import { LOCATION_PICKER_MAP_STYLE, MAP_LOCKED_DARK } from '../../constants/mapConstants';
import { supabase } from '../../lib/supabase';
import { distanceMiles } from '../../utils/mapUtils';
import { hapticFeedback } from '../../services/HapticFeedbackService';

type Coord = { latitude: number; longitude: number };
type Pt = { x: number; y: number };
type Van = { id: string; coord: Coord; miles: number; heading: number };
type PlacedVan = Van & Pt & { angle: number; heat: string };

const CAR_PIN = require('../../../assets/tracking-car.png');
const VAN_PIN = require('../../../assets/tracking-van-pin.png');
const VAN_LEN = 76;
const VAN_W = VAN_LEN * (145 / 288);
const SEARCH_MILES = 10;
const MAX_VANS = 7;
const MIN_GAP = 100;
const MIN_FROM_CAR = 92;
const AVG_MPH = 18;
const HEAT = ['#EF4444', '#F97316', '#FB923C', '#FBBF24'];
const TRAIL_STEPS = 16;

function headingFor(id: string): number {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) % 360;
  return h;
}

function offsetCoord(c: Coord, miles: number, deg: number): Coord {
  const rad = (deg * Math.PI) / 180;
  return {
    latitude: c.latitude - (Math.sin(rad) * miles) / 69,
    longitude: c.longitude + (Math.cos(rad) * miles) / (69 * Math.cos((c.latitude * Math.PI) / 180)),
  };
}

function previewVans(customer: Coord): Van[] {
  return [
    [0.5, 300],
    [0.8, 30],
    [1.1, 150],
    [1.4, 215],
    [1.7, 95],
    [2.0, 255],
    [2.3, 350],
  ].map(([miles, deg], i) => ({ id: `preview-${i}`, coord: offsetCoord(customer, miles!, deg!), miles: miles!, heading: (deg! * 7 + i * 40) % 360 }));
}

async function loadOnlineVans(customer: Coord): Promise<Van[]> {
  const { data, error } = await supabase.from('valeter_presence').select('user_id, last_lat, last_lng').eq('is_online', true);
  if (error || !data) return [];
  return (data as { user_id: string; last_lat: unknown; last_lng: unknown }[])
    .filter((p) => p.last_lat != null && p.last_lng != null)
    .map((p) => {
      const coord = { latitude: Number(p.last_lat), longitude: Number(p.last_lng) };
      return { id: p.user_id, coord, miles: distanceMiles(customer, coord), heading: headingFor(p.user_id) };
    })
    .filter((v) => Number.isFinite(v.miles) && v.miles <= SEARCH_MILES)
    .sort((a, b) => a.miles - b.miles)
    .slice(0, MAX_VANS);
}

/** Push overlapping vans apart (and away from the car) while keeping their bearing roughly true. */
function declutter(car: Pt, pts: Pt[], R: number): Pt[] {
  const out = pts.map((p) => ({ ...p }));
  for (let iter = 0; iter < 40; iter++) {
    for (let i = 0; i < out.length; i++) {
      for (let j = i + 1; j < out.length; j++) {
        const a = out[i]!;
        const b = out[j]!;
        let dx = b.x - a.x;
        let dy = b.y - a.y;
        let d = Math.hypot(dx, dy);
        if (d >= MIN_GAP) continue;
        if (d < 0.01) {
          dx = 1;
          dy = 0;
          d = 1;
        }
        const push = (MIN_GAP - d) / 2;
        a.x -= (dx / d) * push;
        a.y -= (dy / d) * push;
        b.x += (dx / d) * push;
        b.y += (dy / d) * push;
      }
    }
    for (const p of out) {
      const dx = p.x - car.x;
      const dy = p.y - car.y;
      const d = Math.hypot(dx, dy) || 1;
      const clamped = Math.min(R * 0.92, Math.max(MIN_FROM_CAR, d));
      p.x = car.x + (dx / d) * clamped;
      p.y = car.y + (dy / d) * clamped;
    }
  }
  return out;
}

function hitAmount(sweep: number, angle: number): number {
  'worklet';
  const since = (((sweep * 360 - angle) % 360) + 360) % 360;
  return Math.exp(-since / 55);
}

function RadarRing({ size, color, delay, period }: Readonly<{ size: number; color: string; delay: number; period: number }>) {
  const t = useSharedValue(0);
  useEffect(() => {
    t.value = 0;
    t.value = withDelay(delay, withRepeat(withTiming(1, { duration: period, easing: Easing.out(Easing.quad) }), -1, false));
    return () => cancelAnimation(t);
  }, [delay, period, t]);
  const style = useAnimatedStyle(() => ({ opacity: 0.4 * (1 - t.value), transform: [{ scale: 0.06 + 0.94 * t.value }] }));
  return <Animated.View style={[styles.ring, { width: size, height: size, borderRadius: size / 2, borderColor: color }, style]} />;
}

function SweepCone({ R, color, sweep }: Readonly<{ R: number; color: string; sweep: SharedValue<number> }>) {
  const style = useAnimatedStyle(() => ({ transform: [{ rotate: `${sweep.value * 360}deg` }] }));
  return (
    <Animated.View pointerEvents="none" style={[styles.sweepBox, { width: R * 2, height: R * 2 }, style]}>
      {Array.from({ length: TRAIL_STEPS }, (_, i) => (
        <View
          key={i}
          style={[
            styles.sweepArm,
            { left: 0, top: R - 1, width: R * 2, transform: [{ rotate: `${-i * 2.2}deg` }] },
          ]}
        >
          <LinearGradient
            colors={[`${color}00`, i === 0 ? `${color}F0` : `${color}${Math.round(60 * (1 - i / TRAIL_STEPS)).toString(16).padStart(2, '0')}`]}
            start={{ x: 0, y: 0.5 }}
            end={{ x: 1, y: 0.5 }}
            style={[styles.sweepArmFill, { left: R, width: R, height: i === 0 ? 2 : 3 }]}
          />
        </View>
      ))}
    </Animated.View>
  );
}

function HitBeam({ car, van, sweep, color }: Readonly<{ car: Pt; van: PlacedVan; sweep: SharedValue<number>; color: string }>) {
  const len = Math.hypot(van.x - car.x, van.y - car.y);
  const style = useAnimatedStyle(() => ({ opacity: hitAmount(sweep.value, van.angle) * 0.7 }));
  return (
    <Animated.View
      pointerEvents="none"
      style={[
        styles.beam,
        { left: car.x, top: car.y - 1, width: len, transform: [{ translateX: -len / 2 }, { rotate: `${van.angle}deg` }, { translateX: len / 2 }] },
        style,
      ]}
    >
      <LinearGradient colors={[`${color}00`, van.heat]} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={StyleSheet.absoluteFill} />
    </Animated.View>
  );
}

function HeatVan({
  van,
  sweep,
  flare,
  index,
}: Readonly<{ van: PlacedVan; sweep: SharedValue<number>; flare: SharedValue<number>; index: number }>) {
  const bob = useSharedValue(0);
  useEffect(() => {
    bob.value = withDelay(index * 230, withRepeat(withTiming(1, { duration: 1400 + index * 90, easing: Easing.inOut(Easing.sin) }), -1, true));
    return () => cancelAnimation(bob);
  }, [bob, index]);
  const glow = useAnimatedStyle(() => {
    const v = Math.max(hitAmount(sweep.value, van.angle), flare.value);
    return { opacity: 0.22 + v * 0.78, transform: [{ scale: 0.7 + v * 0.45 }] };
  });
  const ping = useAnimatedStyle(() => {
    const h = hitAmount(sweep.value, van.angle);
    return { opacity: h * 0.8, transform: [{ scale: 0.5 + (1 - h) * 1.6 }] };
  });
  const tag = useAnimatedStyle(() => {
    const v = Math.max(hitAmount(sweep.value, van.angle), flare.value);
    return { opacity: Math.min(1, v * 1.6), transform: [{ translateY: (1 - v) * 6 }] };
  });
  const vanStyle = useAnimatedStyle(() => {
    const v = Math.max(hitAmount(sweep.value, van.angle), flare.value);
    return { transform: [{ translateY: (bob.value - 0.5) * 3 }, { rotate: `${van.heading}deg` }, { scale: 1 + v * 0.12 }] };
  });
  const eta = Math.max(1, Math.round((van.miles / AVG_MPH) * 60));
  return (
    <View pointerEvents="none" style={[styles.vanAnchor, { left: van.x, top: van.y }]}>
      <Animated.View style={[styles.heatWrap, glow]}>
        <View style={[styles.heat, { width: 96, height: 96, borderRadius: 48, backgroundColor: van.heat, opacity: 0.14 }]} />
        <View style={[styles.heat, { width: 66, height: 66, borderRadius: 33, backgroundColor: van.heat, opacity: 0.24 }]} />
        <View style={[styles.heat, { width: 38, height: 38, borderRadius: 19, backgroundColor: van.heat, opacity: 0.4 }]} />
      </Animated.View>
      <Animated.View style={[styles.vanPing, { borderColor: van.heat }, ping]} />
      <Animated.Image source={VAN_PIN} resizeMode="contain" style={[styles.van, vanStyle]} />
      <Animated.View style={[styles.vanTag, tag]}>
        <View style={[styles.vanTagDot, { backgroundColor: van.heat }]} />
        <Text style={styles.vanTagText}>{`${van.miles.toFixed(1)} mi · ${eta} min`}</Text>
      </Animated.View>
    </View>
  );
}

function TapPing({ x, y, color }: Readonly<{ x: number; y: number; color: string }>) {
  const t = useSharedValue(0);
  useEffect(() => {
    t.value = withTiming(1, { duration: 900, easing: Easing.out(Easing.cubic) });
  }, [t]);
  const style = useAnimatedStyle(() => ({ opacity: 0.85 * (1 - t.value), transform: [{ scale: 0.1 + 1.1 * t.value }] }));
  return <Animated.View pointerEvents="none" style={[styles.ping, { left: x - 80, top: y - 80, borderColor: color }, style]} />;
}

function CarCore({ car, accent }: Readonly<{ car: Pt; accent: string }>) {
  const t = useSharedValue(0);
  useEffect(() => {
    t.value = withRepeat(withTiming(1, { duration: 1600, easing: Easing.out(Easing.quad) }), -1, false);
    return () => cancelAnimation(t);
  }, [t]);
  const halo = useAnimatedStyle(() => ({ opacity: 0.45 * (1 - t.value), transform: [{ scale: 0.6 + t.value * 1.1 }] }));
  return (
    <View pointerEvents="none" style={[styles.carAnchor, { left: car.x, top: car.y }]}>
      <Animated.View style={[styles.carHalo, { backgroundColor: accent }, halo]} />
      <View style={[styles.carDisc, { borderColor: `${accent}AA` }]} />
      <Image source={CAR_PIN} style={styles.carPin} resizeMode="contain" />
    </View>
  );
}

/**
 * Connecting stage on the real map: your car in the middle, online Pros' vans around it,
 * and a radar sweep that makes each van's heat glow flare as it passes.
 */
export default function ConnectingProMap({
  customer,
  accent,
  urgent,
  preview,
  acceptedProId,
  onLockPoint,
}: Readonly<{
  customer: Coord;
  accent: string;
  urgent: boolean;
  preview: boolean;
  acceptedProId: string | null;
  onLockPoint?: (p: Pt | null) => void;
}>) {
  const { width: W, height: H } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const mapRef = useRef<MapView>(null);
  const [vans, setVans] = useState<Van[]>([]);
  const [car, setCar] = useState<Pt | null>(null);
  const [pxPerMile, setPxPerMile] = useState<number | null>(null);
  const [placed, setPlaced] = useState<PlacedVan[]>([]);
  const [pings, setPings] = useState<{ id: number; x: number; y: number }[]>([]);
  const sweepPeriod = urgent ? 2000 : 3600;
  const ringPeriod = urgent ? 1500 : 2600;
  const sweep = useSharedValue(0);
  const f0 = useSharedValue(0);
  const f1 = useSharedValue(0);
  const f2 = useSharedValue(0);
  const f3 = useSharedValue(0);
  const f4 = useSharedValue(0);
  const f5 = useSharedValue(0);
  const f6 = useSharedValue(0);
  const flares = useMemo(() => [f0, f1, f2, f3, f4, f5, f6], [f0, f1, f2, f3, f4, f5, f6]);

  const R = Math.min(W * 0.46, (H * 0.58 - insets.top - 60) / 2);

  useEffect(() => {
    if (preview) {
      setVans(previewVans(customer));
      return;
    }
    let cancelled = false;
    const load = () =>
      loadOnlineVans(customer)
        .then((v) => {
          if (!cancelled) setVans(v);
        })
        .catch(() => undefined);
    void load();
    const id = setInterval(load, 20000);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, [customer.latitude, customer.longitude, preview]);

  useEffect(() => {
    sweep.value = 0;
    sweep.value = withRepeat(withTiming(1, { duration: sweepPeriod, easing: Easing.linear }), -1, false);
    return () => cancelAnimation(sweep);
  }, [sweepPeriod, sweep]);

  const mapPadding = useMemo(() => ({ top: insets.top + 60, right: 0, bottom: Math.round(H * 0.42), left: 0 }), [insets.top, H]);
  const region = useMemo(() => {
    const ranked = vans.map((v) => v.miles).sort((a, b) => a - b);
    const fitMiles = Math.min(SEARCH_MILES, Math.max(0.5, ranked[Math.min(ranked.length - 1, 4)] ?? 1));
    const cos = Math.cos((customer.latitude * Math.PI) / 180);
    const milesAcross = (fitMiles * W) / (R * 0.82);
    const longitudeDelta = milesAcross / (69 * cos);
    return {
      latitude: customer.latitude,
      longitude: customer.longitude,
      latitudeDelta: (milesAcross / 69) * 0.5,
      longitudeDelta,
    };
  }, [customer.latitude, customer.longitude, vans, W, R]);

  const project = useCallback(async () => {
    const map = mapRef.current;
    if (!map) return;
    try {
      const c = await map.pointForCoordinate(customer);
      const east = await map.pointForCoordinate(offsetCoord(customer, 1, 0));
      const raw = await Promise.all(vans.map((v) => map.pointForCoordinate(v.coord)));
      const ppm = Math.abs(east.x - c.x);
      const spread = declutter(c, raw, R);
      const list: PlacedVan[] = vans.map((v, i) => {
        const p = spread[i]!;
        const angle = (((Math.atan2(p.y - c.y, p.x - c.x) * 180) / Math.PI) + 360) % 360;
        return {
          ...v,
          x: p.x,
          y: p.y,
          angle,
          heat: HEAT[Math.min(HEAT.length - 1, Math.floor((i / Math.max(1, vans.length)) * HEAT.length))]!,
        };
      });
      setCar({ x: c.x, y: c.y });
      setPxPerMile(ppm > 0 ? ppm : null);
      setPlaced(list);
    } catch {
      /* projection unavailable until the map is laid out */
    }
  }, [customer, vans, R]);

  useEffect(() => {
    const t = setTimeout(() => void project(), 450);
    return () => clearTimeout(t);
  }, [project, region]);

  const onLockPointRef = useRef(onLockPoint);
  onLockPointRef.current = onLockPoint;
  useEffect(() => {
    const target = placed.find((v) => v.id === acceptedProId) ?? placed[0] ?? null;
    onLockPointRef.current?.(target ? { x: target.x, y: target.y } : null);
  }, [placed, acceptedProId]);

  const rings = useMemo(() => {
    if (!pxPerMile) return [] as { r: number; label: string }[];
    const steps = [0.25, 0.5, 1, 2, 5];
    const step = steps.find((s) => s * pxPerMile >= R * 0.3) ?? 5;
    const out: { r: number; label: string }[] = [];
    for (let k = 1; k * step * pxPerMile <= R * 1.01 && k <= 4; k++) {
      const miles = k * step;
      out.push({ r: miles * pxPerMile, label: `${miles} mi` });
    }
    return out;
  }, [pxPerMile, R]);

  const onTap = useCallback(
    (e: GestureResponderEvent) => {
      const { pageX, pageY } = e.nativeEvent;
      const idx = placed.findIndex((v) => Math.hypot(v.x - pageX, v.y - pageY) < 44);
      if (idx >= 0) {
        const f = flares[idx];
        if (f) f.value = withSequence(withTiming(1, { duration: 120 }), withDelay(900, withTiming(0, { duration: 700, easing: Easing.out(Easing.quad) })));
        void hapticFeedback('medium');
        return;
      }
      void hapticFeedback('light');
      const id = Date.now();
      setPings((p) => [...p.slice(-4), { id, x: pageX, y: pageY }]);
      setTimeout(() => setPings((p) => p.filter((q) => q.id !== id)), 950);
    },
    [placed, flares]
  );

  const count = placed.length;
  const closestEta = placed.length ? Math.max(1, Math.round((Math.min(...placed.map((v) => v.miles)) / AVG_MPH) * 60)) : null;

  return (
    <View style={StyleSheet.absoluteFill}>
      <SafeMapView
        ref={mapRef}
        style={StyleSheet.absoluteFill}
        region={region}
        initialRegion={region}
        scrollEnabled={false}
        zoomEnabled={false}
        rotateEnabled={false}
        pitchEnabled={false}
        showsUserLocation={false}
        showsMyLocationButton={false}
        toolbarEnabled={false}
        customMapStyle={LOCATION_PICKER_MAP_STYLE}
        userInterfaceStyle={MAP_LOCKED_DARK}
        mapPadding={mapPadding}
        pointerEvents="none"
        onMapReady={() => void project()}
        onRegionChangeComplete={() => void project()}
      />
      <View pointerEvents="none" style={styles.tint} />
      <LinearGradient
        pointerEvents="none"
        colors={['rgba(2,6,23,0.05)', 'rgba(2,6,23,0.3)', 'rgba(2,6,23,0.6)']}
        locations={[0, 0.55, 1]}
        style={StyleSheet.absoluteFill}
      />

      <Pressable style={StyleSheet.absoluteFill} onPress={onTap} accessibilityLabel="Ping for a Pro">
        {car ? (
          <View pointerEvents="none" style={[styles.radarBox, { left: car.x - R, top: car.y - R, width: R * 2, height: R * 2 }]}>
            <View style={[styles.radarFill, { width: R * 2, height: R * 2, borderRadius: R, backgroundColor: `${accent}0D` }]} />
            {[0, 1, 2].map((i) => (
              <RadarRing key={i} size={R * 2} color={accent} delay={(i * ringPeriod) / 3} period={ringPeriod} />
            ))}
            {rings.map((rg) => (
              <View key={rg.label} style={[styles.staticRing, { width: rg.r * 2, height: rg.r * 2, borderRadius: rg.r, borderColor: `${accent}30` }]} />
            ))}
            <View style={[styles.staticRing, { width: R * 2, height: R * 2, borderRadius: R, borderColor: `${accent}40` }]} />
            <View style={[styles.crossH, { width: R * 2, backgroundColor: `${accent}14` }]} />
            <View style={[styles.crossV, { height: R * 2, backgroundColor: `${accent}14` }]} />
            <SweepCone R={R} color={accent} sweep={sweep} />
          </View>
        ) : null}

        {car
          ? rings.map((rg) => (
              <Text
                key={`l-${rg.label}`}
                pointerEvents="none"
                style={[styles.ringLabel, { left: car.x + rg.r * 0.707 + 3, top: car.y - rg.r * 0.707 - 14 }]}
              >
                {rg.label}
              </Text>
            ))
          : null}

        {car ? placed.map((v) => <HitBeam key={`b-${v.id}`} car={car} van={v} sweep={sweep} color={accent} />) : null}
        {placed.map((v, i) => (
          <HeatVan key={v.id} van={v} index={i} sweep={sweep} flare={flares[i] ?? f0} />
        ))}
        {car ? <CarCore car={car} accent={accent} /> : null}

        {pings.map((p) => (
          <TapPing key={p.id} x={p.x} y={p.y} color={accent} />
        ))}
      </Pressable>

      <View pointerEvents="none" style={[styles.topRow, { top: insets.top + 70 }]}>
        <View style={styles.countPill}>
          <View style={[styles.liveDot, { backgroundColor: count ? '#34D399' : accent }]} />
          <Text style={styles.countText}>
            {count ? `${count} Pro${count === 1 ? '' : 's'} nearby` : 'Scanning your area'}
            {closestEta != null ? <Text style={styles.countSub}>{`  ·  closest ${closestEta} min`}</Text> : null}
          </Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  tint: { ...StyleSheet.absoluteFill, backgroundColor: 'rgba(15,23,42,0.22)' },
  radarBox: { position: 'absolute', alignItems: 'center', justifyContent: 'center' },
  radarFill: { position: 'absolute' },
  ring: { position: 'absolute', borderWidth: 1.5 },
  staticRing: { position: 'absolute', borderWidth: 1 },
  crossH: { position: 'absolute', height: 1 },
  crossV: { position: 'absolute', width: 1 },
  sweepBox: { position: 'absolute', left: 0, top: 0 },
  sweepArm: { position: 'absolute', height: 3 },
  sweepArmFill: { position: 'absolute', top: 0, borderRadius: 2 },
  ringLabel: { position: 'absolute', color: 'rgba(226,232,240,0.6)', fontSize: 10, fontWeight: '700', fontVariant: ['tabular-nums'] },
  beam: { position: 'absolute', height: 2, borderRadius: 1, overflow: 'hidden' },
  vanAnchor: { position: 'absolute', width: 0, height: 0, alignItems: 'center', justifyContent: 'center' },
  heatWrap: { position: 'absolute', width: 96, height: 96, alignItems: 'center', justifyContent: 'center' },
  heat: { position: 'absolute' },
  vanPing: { position: 'absolute', width: 84, height: 84, borderRadius: 42, borderWidth: 1.5 },
  van: { position: 'absolute', width: VAN_LEN, height: VAN_W },
  vanTag: {
    position: 'absolute',
    top: 30,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 999,
    backgroundColor: 'rgba(2,6,23,0.72)',
  },
  vanTagDot: { width: 6, height: 6, borderRadius: 3 },
  vanTagText: { color: '#F8FAFC', fontSize: 10.5, fontWeight: '700', fontVariant: ['tabular-nums'] },
  ping: { position: 'absolute', width: 160, height: 160, borderRadius: 80, borderWidth: 2 },
  carAnchor: { position: 'absolute', width: 0, height: 0, alignItems: 'center', justifyContent: 'center' },
  carHalo: { position: 'absolute', width: 96, height: 96, borderRadius: 48 },
  carDisc: { position: 'absolute', width: 78, height: 78, borderRadius: 39, borderWidth: 1.5, backgroundColor: 'rgba(2,6,23,0.55)' },
  carPin: { position: 'absolute', width: 36, height: 67 },
  topRow: { position: 'absolute', left: 0, right: 0, alignItems: 'center' },
  countPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: 'rgba(2,6,23,0.5)',
  },
  liveDot: { width: 7, height: 7, borderRadius: 4 },
  countText: { color: '#F1F5F9', fontSize: 12, fontWeight: '700' },
  countSub: { color: 'rgba(226,232,240,0.7)', fontWeight: '600' },
});
