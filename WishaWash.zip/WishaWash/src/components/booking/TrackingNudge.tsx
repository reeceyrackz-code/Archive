import { useEffect, type ComponentProps } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import Animated, { FadeOutUp, SlideInUp } from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { hapticFeedback } from '../../services/HapticFeedbackService';

export type TrackingNudgeMessage = Readonly<{
  id: string;
  icon: ComponentProps<typeof Ionicons>['name'];
  title: string;
  body: string;
}>;

const VISIBLE_MS = 7000;

/** Heads-up banner under the header for moments that need the customer (Pro nearly here, Pro arrived). */
export default function TrackingNudge({
  nudge,
  accent,
  top,
  onDismiss,
}: Readonly<{ nudge: TrackingNudgeMessage | null; accent: string; top: number; onDismiss: () => void }>) {
  useEffect(() => {
    if (!nudge) return;
    void hapticFeedback('medium');
    const id = setTimeout(onDismiss, VISIBLE_MS);
    return () => clearTimeout(id);
  }, [nudge, onDismiss]);

  if (!nudge) return null;
  return (
    <Animated.View key={nudge.id} entering={SlideInUp.springify().damping(18)} exiting={FadeOutUp.duration(220)} style={[styles.wrap, { top }]} pointerEvents="box-none">
      <Pressable onPress={onDismiss} style={styles.card} accessibilityRole="button" accessibilityLabel={`${nudge.title}. ${nudge.body}. Tap to dismiss`}>
        <View style={[styles.icon, { backgroundColor: accent }]}>
          <Ionicons name={nudge.icon} size={18} color="#04121F" />
        </View>
        <View style={styles.copy}>
          <Text style={styles.title} numberOfLines={1}>
            {nudge.title}
          </Text>
          <Text style={styles.body} numberOfLines={2}>
            {nudge.body}
          </Text>
        </View>
        <Ionicons name="close" size={16} color="rgba(226,232,240,0.6)" />
      </Pressable>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  wrap: { position: 'absolute', left: 14, right: 14, zIndex: 20 },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderRadius: 20,
    backgroundColor: 'rgba(10,18,32,0.94)',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(255,255,255,0.16)',
    shadowColor: '#000',
    shadowOpacity: 0.4,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 8 },
    elevation: 12,
  },
  icon: { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  copy: { flex: 1, minWidth: 0 },
  title: { color: '#FFFFFF', fontSize: 15, fontWeight: '800' },
  body: { marginTop: 2, color: 'rgba(226,232,240,0.75)', fontSize: 12.5, fontWeight: '600', lineHeight: 17 },
});
