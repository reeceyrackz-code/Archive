import React from 'react';
import { colors } from '../../constants/colors';
import { BookingHeaderMapControlButton } from '../shared/BookingHeaderMapControlButton';
import BookingMapChromeHeader from './BookingMapChromeHeader';

type BookingMapLocationFullHeaderProps = {
  topInset: number;
  title?: string;
  accentColor?: string;
  onBack: () => void;
  onRecenter: () => void;
  recenterLoading?: boolean;
  /** Replaces the title pill (e.g. an address search field). */
  centerContent?: React.ReactNode;
  /** Glass controls floating over the map instead of a solid header bar. */
  floating?: boolean;
};

/** Row height of the header below the safe-area inset (padding + 40pt controls). */
export const BOOKING_MAP_LOCATION_HEADER_BODY_HEIGHT = 56;

export default function BookingMapLocationFullHeader({
  topInset,
  title = "Where's the ride?",
  accentColor = colors.SKY,
  onBack,
  onRecenter,
  recenterLoading = false,
  centerContent,
  floating = false,
}: BookingMapLocationFullHeaderProps) {
  return (
    <BookingMapChromeHeader
      topInset={topInset}
      title={title}
      titleIcon="car-sport-outline"
      onBack={onBack}
      floating={floating}
      {...(centerContent != null ? { centerContent } : {})}
      rightAction={
        <BookingHeaderMapControlButton
          onPress={onRecenter}
          accentColor={accentColor}
          loading={recenterLoading}
          accessibilityLabel="Recenter map on your location"
        />
      }
    />
  );
}
