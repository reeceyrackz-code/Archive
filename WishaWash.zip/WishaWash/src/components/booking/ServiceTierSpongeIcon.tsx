import React from 'react';
import { View, StyleSheet, Platform, type ImageSourcePropType } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import {
  BOOKING_CONTINUE_RADIUS,
  bookingContinueVerticalTint,
  bookingContinueChromeBorder,
} from '../../utils/bookingContinueStyle';
import { LEGACY_ECO_SERVICE_ID_MAP } from '../../constants/serviceOptions';
import type { GlyphName } from '../shared/GlyphIcon';
import {
  CERAMIC_DETAIL_IMAGE,
  SOFTOP_DETAIL_IMAGE,
  MOULD_DETAIL_IMAGE,
  HEADLIGHT_DETAIL_IMAGE,
} from '../../../assets/assetExports';

/**
 * Branded picture used as the lead icon for specialist detail services
 * (ceramic coating, soft top restoration, mould removal, headlight restoration).
 * Matches on service id or name; returns null for services without a dedicated picture.
 */
export function getServiceTierLeadImage(serviceIdOrName: string): ImageSourcePropType | null {
  const t = serviceIdOrName.toLowerCase();
  if (t.includes('ceramic')) return CERAMIC_DETAIL_IMAGE;
  if (t.includes('soft top') || t.includes('soft-top') || t.includes('softop')) return SOFTOP_DETAIL_IMAGE;
  if (t.includes('mould') || t.includes('mold')) return MOULD_DETAIL_IMAGE;
  if (t.includes('headlight')) return HEADLIGHT_DETAIL_IMAGE;
  return null;
}

export function getServiceTierLeadIconName(serviceId: string): GlyphName {
  const raw = serviceId.toLowerCase();
  const id = LEGACY_ECO_SERVICE_ID_MAP[raw] ?? raw;
  const map: Record<string, GlyphName> = {
    'bronze-wash': 'mci:car-wash',
    'silver-wash': 'mci:spray',
    'gold-wash': 'mci:shimmer',
    'platinum-wash': 'mci:crown',
    'emerald-wash': 'mci:diamond-stone',
    'ceramic-coating': 'mci:shield-car',
    'machine-polishing': 'mci:auto-fix',
    'soft-top-restoration': 'mci:car-convertible',
    'mould-removal': 'mci:bacteria-outline',
    'headlight-restoration': 'mci:car-light-high',
    'scratch-removal': 'mci:brush',
    'paint-chip-repair': 'mci:format-paint',
    'trim-restoration': 'mci:car-door',
    'leather-repair': 'mci:car-seat',
    'maintenance-pack': 'mci:wrench-cog',
  };
  return map[id] ?? 'mci:car-wash';
}

const ADD_ON_GLYPHS: Record<string, GlyphName> = {
  'pet-hair': 'mci:paw',
  'stain-removal': 'mci:water-off',
  'vomit-removal': 'mci:emoticon-sick',
  'biohazard-removal': 'mci:biohazard',
  'engine-bay': 'mci:engine',
  'headlight-restoration': 'mci:car-light-high',
  'seat-shampoo': 'mci:vacuum',
  'ceramic-spray': 'mci:spray-bottle',
  'floor-mats-carpet-shampoo': 'mci:rug',
  'clay-bar-treatment': 'mci:texture-box',
  'iron-tar-decontamination': 'mci:blur',
  'wiper-blade-install': 'mci:wiper',
  'coolant-top-up': 'mci:car-coolant-level',
  'oil-level-check': 'mci:oil-level',
  'screen-wash-refill': 'mci:wiper-wash',
};

/** Car-care glyph for an add-on, falling back to its stored Ionicons name. */
export function getAddOnIconName(addOn: Readonly<{ id: string; icon?: string | null }>): GlyphName {
  return ADD_ON_GLYPHS[addOn.id] ?? ((addOn.icon || 'add') as GlyphName);
}

/**
 * Tier lead icon — same glass + vertical tint + accent border treatment as Continue CTAs.
 */
export default function ServiceTierSpongeIcon({
  accentColor,
  iconName,
  boxSize = 44,
  iconSize = 22,
}: Readonly<{
  accentColor: string;
  iconName: React.ComponentProps<typeof Ionicons>['name'];
  boxSize?: number;
  iconSize?: number;
}>) {
  const vertical = bookingContinueVerticalTint(accentColor);
  const borderCol = bookingContinueChromeBorder(accentColor);

  return (
    <View style={{ width: boxSize, height: boxSize }}>
      <View
        style={[
          styles.chrome,
          {
            width: boxSize,
            height: boxSize,
            borderRadius: BOOKING_CONTINUE_RADIUS,
            borderColor: borderCol,
          },
        ]}
      >
        <BlurView
          intensity={22}
          tint="dark"
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
          {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
        />
        <LinearGradient
          colors={vertical}
          start={{ x: 0, y: 0 }}
          end={{ x: 0, y: 1 }}
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
        />
        <View style={styles.iconCenter} pointerEvents="none">
          <Ionicons name={iconName} size={iconSize} color={accentColor} />
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  chrome: {
    overflow: 'hidden',
    borderWidth: 1,
    position: 'relative',
  },
  iconCenter: {
    ...StyleSheet.absoluteFill,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
