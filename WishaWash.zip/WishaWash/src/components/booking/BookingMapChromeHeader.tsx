import React from 'react';
import { View, Text, StyleSheet, Pressable, Platform, type StyleProp, type ViewStyle } from 'react-native';
import Animated, { FadeIn, ZoomIn, useAnimatedStyle, useSharedValue, withSpring } from 'react-native-reanimated';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import HubGlassIcon from '../shared/HubGlassIcon';
import { useMapChromeColors } from '../../hooks/useMapChromeColors';
import {
  HEADER_BAR_PAD_BOTTOM,
  HEADER_BAR_PAD_H,
  HEADER_BAR_PAD_TOP,
  HEADER_TILE,
  HEADER_TILE_BG,
  HEADER_TILE_BORDER,
  HEADER_TILE_RADIUS,
} from '../../constants/headerChrome';

type IoniconName = React.ComponentProps<typeof Ionicons>['name'];

export function BookingMapChromeIconButton({
  onPress,
  icon,
  iconSize = 20,
  accessibilityLabel,
  style,
  disabled,
}: {
  onPress?: () => void;
  icon: IoniconName;
  iconSize?: number;
  accessibilityLabel: string;
  style?: StyleProp<ViewStyle>;
  disabled?: boolean;
}) {
  const chrome = useMapChromeColors();
  const scale = useSharedValue(1);
  const pressStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));

  return (
    <Animated.View style={pressStyle}>
      <Pressable
        onPress={onPress}
        disabled={disabled}
        onPressIn={() => {
          scale.value = withSpring(0.9, { damping: 16, stiffness: 320 });
        }}
        onPressOut={() => {
          scale.value = withSpring(1, { damping: 12, stiffness: 260 });
        }}
        hitSlop={6}
        style={[styles.iconBtn, style]}
        accessibilityRole="button"
        accessibilityLabel={accessibilityLabel}
      >
        <Ionicons name={icon} size={iconSize} color={chrome.icon} />
      </Pressable>
    </Animated.View>
  );
}

export type BookingMapChromeHeaderProps = {
  topInset: number;
  title?: string;
  subtitle?: string;
  titleIcon?: IoniconName;
  showBack?: boolean;
  onBack?: () => void;
  leftAction?: React.ReactNode;
  centerContent?: React.ReactNode;
  rightAction?: React.ReactNode;
  points?: number;
  /** Tint for the glowing title icon tile (tone name or hex); defaults to the chrome accent. */
  titleAccent?: string;
  style?: StyleProp<ViewStyle>;
  /** Glass controls floating over a map instead of a solid header bar. */
  floating?: boolean;
  /** With `floating`, pin to the top of the parent (off when the parent already positions the header). */
  overlay?: boolean;
};

/** Same glass pill as the header title — for custom centre content (search field, address). */
export function BookingMapChromePill({
  children,
  style,
  innerStyle,
}: Readonly<{ children: React.ReactNode; style?: StyleProp<ViewStyle>; innerStyle?: StyleProp<ViewStyle> }>) {
  return (
    <View style={[styles.chromePill, style]}>
      <View style={[styles.chromePillInner, innerStyle]}>{children}</View>
    </View>
  );
}

export default function BookingMapChromeHeader(props: BookingMapChromeHeaderProps) {
  return <SolidChromeHeader {...props} />;
}

function SolidChromeHeader({
  topInset,
  title,
  subtitle,
  titleIcon,
  showBack = true,
  onBack,
  leftAction,
  centerContent,
  rightAction,
  points,
  titleAccent,
  style,
  floating = false,
  overlay = true,
}: BookingMapChromeHeaderProps) {
  const chrome = useMapChromeColors();
  const hasTitle = Boolean(title && title.trim().length > 0);
  const showTitle = centerContent == null && hasTitle;

  return (
    <View
      style={[styles.bar, floating && overlay ? styles.barOverlay : null, style]}
      pointerEvents="box-none"
    >
      <BlurView
        intensity={40}
        tint="dark"
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
        {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
      />
      <LinearGradient
        colors={[...chrome.gradient]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <View style={[styles.content, { paddingTop: topInset + HEADER_BAR_PAD_TOP }]} pointerEvents="box-none">
        {leftAction != null ? (
          leftAction
        ) : showBack ? (
          <BookingMapChromeIconButton
            icon="chevron-back"
            iconSize={22}
            accessibilityLabel="Back"
            {...(onBack ? { onPress: onBack } : {})}
          />
        ) : null}

        {centerContent != null ? (
          <View style={styles.centerSlot}>{centerContent}</View>
        ) : showTitle ? (
          <Animated.View entering={FadeIn.duration(280)} style={styles.titleRow}>
            {titleIcon ? (
              <Animated.View entering={ZoomIn.delay(80).springify().damping(14)} style={styles.titleIconTile}>
                <HubGlassIcon icon={titleIcon} accent={titleAccent ?? chrome.accent} size={34} iconSize={17} glow={false} />
              </Animated.View>
            ) : null}
            <Animated.View key={`${title ?? ''}|${subtitle ?? ''}`} entering={FadeIn.duration(220)} style={styles.titleTextCol}>
              <Text style={styles.titleText} numberOfLines={1}>
                {title}
              </Text>
              {subtitle ? (
                <Text style={styles.subtitleText} numberOfLines={1}>
                  {subtitle}
                </Text>
              ) : null}
            </Animated.View>
            {points === undefined ? null : (
              <View style={styles.pointsChip}>
                <Ionicons name="trophy" size={13} color="#FBBF24" />
                <Text style={styles.pointsText}>{points.toLocaleString()}</Text>
                <Text style={styles.pointsSuffix}>pts</Text>
              </View>
            )}
          </Animated.View>
        ) : (
          <View style={styles.centerSlot} />
        )}

        {rightAction == null ? null : <View style={styles.rightSlot}>{rightAction}</View>}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  bar: {
    overflow: 'hidden',
    zIndex: 920,
  },
  barOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    minHeight: HEADER_TILE,
    paddingHorizontal: HEADER_BAR_PAD_H,
    paddingBottom: HEADER_BAR_PAD_BOTTOM,
    zIndex: 1,
  },
  iconBtn: {
    width: HEADER_TILE,
    height: HEADER_TILE,
    borderRadius: HEADER_TILE_RADIUS,
    borderWidth: 1,
    borderColor: HEADER_TILE_BORDER,
    backgroundColor: HEADER_TILE_BG,
    alignItems: 'center',
    justifyContent: 'center',
  },
  chromePill: {
    height: HEADER_TILE,
    borderRadius: HEADER_TILE_RADIUS,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: HEADER_TILE_BORDER,
    backgroundColor: HEADER_TILE_BG,
  },
  chromePillInner: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 14,
    zIndex: 1,
  },
  centerSlot: {
    flex: 1,
    minWidth: 0,
  },
  rightSlot: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flexShrink: 0,
  },
  titleRow: {
    flex: 1,
    minWidth: 0,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  titleIconTile: {
    width: HEADER_TILE,
    height: HEADER_TILE,
    borderRadius: HEADER_TILE_RADIUS,
    borderWidth: 1,
    borderColor: HEADER_TILE_BORDER,
    backgroundColor: HEADER_TILE_BG,
    alignItems: 'center',
    justifyContent: 'center',
  },
  titleTextCol: {
    flex: 1,
    minWidth: 0,
    gap: 1,
  },
  titleText: {
    color: '#F8FAFC',
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: -0.3,
  },
  subtitleText: {
    color: 'rgba(203,213,225,0.82)',
    fontSize: 12,
    fontWeight: '600',
    letterSpacing: 0.1,
  },
  pointsChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    height: 34,
    paddingHorizontal: 11,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(251,191,36,0.38)',
    backgroundColor: 'rgba(251,191,36,0.1)',
  },
  pointsText: {
    color: '#FBBF24',
    fontSize: 14,
    fontWeight: '800',
    letterSpacing: -0.2,
  },
  pointsSuffix: {
    color: 'rgba(251,191,36,0.75)',
    fontSize: 11,
    fontWeight: '700',
    marginTop: 1,
  },
});
