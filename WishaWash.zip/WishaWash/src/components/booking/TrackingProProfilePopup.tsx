import { useEffect, useState, type ReactNode } from 'react';
import { Image, Modal, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import Animated, { FadeIn, FadeInDown, FadeOut, SlideInUp, SlideOutUp } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { BlurView } from 'expo-blur';
import { GlassView, isLiquidGlassAvailable } from 'expo-glass-effect';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../../lib/supabase';
import { loadGalleryPhotos } from '../valeter/ValeterProfileBottomSheet';

const GOLD = '#FBBF24';
const GREEN = '#34D399';
const MUTED = 'rgba(226,232,240,0.6)';
const GLASS = Platform.OS === 'ios' && isLiquidGlassAvailable();

export type TrackingProProfile = Readonly<{
  name: string;
  photoUrl: string | null;
  rating: number;
  reviews: number;
  totalJobs: number;
  experienceMonths: number;
  onTimePercentage: number;
}>;

type ProExtras = {
  bio: string | null;
  specializations: string[];
  photos: string[];
  review: { rating: number; body: string; author: string } | null;
};

const EMPTY_EXTRAS: ProExtras = { bio: null, specializations: [], photos: [], review: null };

const PREVIEW_EXTRAS: ProExtras = {
  bio: 'Detailing enthusiast for 6 years. Paint-safe products, careful hand finish and always on time.',
  specializations: ['Full valet', 'Paint protection', 'Interiors', 'EVs'],
  photos: [],
  review: { rating: 5, body: 'Car looks brand new — friendly and super thorough.', author: 'Sophie' },
};

type Props = Readonly<{
  visible: boolean;
  pro: TrackingProProfile | null;
  valeterId: string | null;
  preview?: boolean;
  accent: string;
  onClose: () => void;
}>;

function Surface({ children, style }: Readonly<{ children: ReactNode; style?: object }>) {
  if (GLASS) {
    return (
      <GlassView glassEffectStyle="regular" colorScheme="dark" tintColor="rgba(8,20,38,0.55)" style={style}>
        {children}
      </GlassView>
    );
  }
  return (
    <View style={[style, styles.surfaceFallback]}>
      <BlurView intensity={50} tint="dark" style={StyleSheet.absoluteFill} />
      <View style={[StyleSheet.absoluteFill, styles.surfaceTint]} />
      {children}
    </View>
  );
}

function experienceLabel(months: number): string {
  if (months >= 12) {
    const years = Math.floor(months / 12);
    return `${years}y${months % 12 ? ` ${months % 12}m` : ''}`;
  }
  return `${Math.max(1, months)}m`;
}

function Stat({ value, label, icon, color }: Readonly<{ value: string; label: string; icon?: keyof typeof Ionicons.glyphMap; color?: string }>) {
  return (
    <View style={styles.stat}>
      <View style={styles.statValueRow}>
        {icon ? <Ionicons name={icon} size={12} color={color ?? '#F8FAFC'} /> : null}
        <Text style={styles.statValue}>{value}</Text>
      </View>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}

async function loadProExtras(valeterId: string): Promise<ProExtras> {
  const [profileRes, photos, reviewRes] = await Promise.all([
    supabase.from('valeter_profiles').select('bio, specializations').eq('user_id', valeterId).maybeSingle(),
    loadGalleryPhotos(valeterId).catch(() => [] as string[]),
    supabase
      .from('bookings')
      .select('rating, review, user_id')
      .eq('valeter_id', valeterId)
      .eq('status', 'completed')
      .not('review', 'is', null)
      .order('completed_at', { ascending: false })
      .limit(1)
      .maybeSingle(),
  ]);

  const profile = profileRes.data as { bio?: string | null; specializations?: string[] | null } | null;
  const reviewRow = reviewRes.data as { rating?: number | null; review?: string | null; user_id?: string | null } | null;

  let review: ProExtras['review'] = null;
  if (reviewRow?.review?.trim()) {
    let author = 'Customer';
    if (reviewRow.user_id) {
      const { data: prof } = await supabase.from('profiles').select('full_name').eq('id', reviewRow.user_id).maybeSingle();
      const first = (prof as { full_name?: string | null } | null)?.full_name?.trim().split(/\s+/)[0];
      if (first) author = first;
    }
    review = { rating: Number(reviewRow.rating) || 5, body: reviewRow.review.trim(), author };
  }

  return {
    bio: profile?.bio?.trim() || null,
    specializations: Array.isArray(profile?.specializations) ? profile.specializations.filter(Boolean).slice(0, 4) : [],
    photos: photos.slice(0, 4),
    review,
  };
}

/** Compact pro profile card that drops in from the top of the tracking screen. */
export default function TrackingProProfilePopup({ visible, pro, valeterId, preview, accent, onClose }: Props) {
  const insets = useSafeAreaInsets();
  const [extras, setExtras] = useState<ProExtras>(EMPTY_EXTRAS);

  useEffect(() => {
    if (!visible) return;
    if (preview) {
      setExtras(PREVIEW_EXTRAS);
      return;
    }
    if (!valeterId) {
      setExtras(EMPTY_EXTRAS);
      return;
    }
    let cancelled = false;
    void loadProExtras(valeterId)
      .then((next) => {
        if (!cancelled) setExtras(next);
      })
      .catch(() => {
        if (!cancelled) setExtras(EMPTY_EXTRAS);
      });
    return () => {
      cancelled = true;
    };
  }, [visible, valeterId, preview]);

  return (
    <Modal visible={visible} transparent animationType="none" statusBarTranslucent onRequestClose={onClose}>
      {visible && pro ? (
        <View style={styles.root}>
          <Animated.View entering={FadeIn.duration(200)} exiting={FadeOut.duration(160)} style={StyleSheet.absoluteFill}>
            <BlurView intensity={24} tint="dark" style={StyleSheet.absoluteFill} />
            <Pressable style={[StyleSheet.absoluteFill, styles.scrim]} onPress={onClose} accessibilityLabel="Close profile" />
          </Animated.View>

          <Animated.View
            entering={SlideInUp.springify().damping(18).stiffness(170)}
            exiting={SlideOutUp.duration(200)}
            style={[styles.cardWrap, { paddingTop: insets.top + 8 }]}
          >
            <Surface style={styles.card}>
              <LinearGradient colors={[`${accent}29`, `${accent}00`]} style={styles.glow} pointerEvents="none" />

              <View style={styles.headRow}>
                {pro.photoUrl ? (
                  <Image source={{ uri: pro.photoUrl }} style={[styles.avatar, { borderColor: `${accent}AA` }]} />
                ) : (
                  <View style={[styles.avatar, styles.avatarFallback, { backgroundColor: `${accent}33`, borderColor: `${accent}AA` }]}>
                    <Ionicons name="person" size={22} color="#E0F2FE" />
                  </View>
                )}
                <View style={styles.headText}>
                  <View style={styles.kickerRow}>
                    <Ionicons name="shield-checkmark" size={11} color={GREEN} />
                    <Text style={styles.kicker}>VERIFIED PRO</Text>
                  </View>
                  <Text style={styles.name} numberOfLines={1}>{pro.name}</Text>
                  <Text style={styles.meta} numberOfLines={1}>Verified · Insured</Text>
                </View>
                <Pressable onPress={onClose} hitSlop={10} style={styles.close} accessibilityLabel="Close">
                  <Ionicons name="close" size={15} color="rgba(226,232,240,0.8)" />
                </Pressable>
              </View>

              <Animated.View entering={FadeInDown.delay(80).duration(260)} style={styles.stats}>
                <Stat value={pro.rating > 0 ? pro.rating.toFixed(1) : 'New'} label={pro.reviews > 0 ? `${pro.reviews} reviews` : 'Rating'} icon="star" color={GOLD} />
                <View style={styles.divider} />
                <Stat value={String(pro.totalJobs)} label="Jobs" />
                <View style={styles.divider} />
                <Stat value={pro.onTimePercentage > 0 ? `${Math.round(pro.onTimePercentage)}%` : '—'} label="On time" />
                <View style={styles.divider} />
                <Stat value={experienceLabel(pro.experienceMonths)} label="With us" />
              </Animated.View>

              {extras.bio ? (
                <Animated.Text entering={FadeIn.delay(120).duration(240)} style={styles.bio} numberOfLines={3}>
                  {extras.bio}
                </Animated.Text>
              ) : null}

              {extras.specializations.length > 0 ? (
                <Animated.View entering={FadeIn.delay(160).duration(240)} style={styles.chips}>
                  {extras.specializations.map((s) => (
                    <View key={s} style={styles.chip}>
                      <Ionicons name="sparkles" size={10} color={accent} />
                      <Text style={styles.chipText} numberOfLines={1}>{s}</Text>
                    </View>
                  ))}
                </Animated.View>
              ) : null}

              {extras.photos.length > 0 ? (
                <Animated.View entering={FadeIn.delay(200).duration(240)} style={styles.section}>
                  <Text style={styles.sectionLabel}>RECENT WORK</Text>
                  <View style={styles.photos}>
                    {extras.photos.map((uri) => (
                      <Image key={uri} source={{ uri }} style={styles.photo} />
                    ))}
                  </View>
                </Animated.View>
              ) : null}

              {extras.review ? (
                <Animated.View entering={FadeIn.delay(240).duration(240)} style={styles.review}>
                  <View style={styles.reviewHead}>
                    <View style={styles.reviewStars}>
                      {[0, 1, 2, 3, 4].map((i) => (
                        <Ionicons
                          key={i}
                          name={i < Math.round(extras.review!.rating) ? 'star' : 'star-outline'}
                          size={10}
                          color={GOLD}
                        />
                      ))}
                    </View>
                    <Text style={styles.reviewAuthor} numberOfLines={1}>{extras.review.author}</Text>
                  </View>
                  <Text style={styles.reviewBody} numberOfLines={2}>“{extras.review.body}”</Text>
                </Animated.View>
              ) : null}
            </Surface>
          </Animated.View>
        </View>
      ) : null}
    </Modal>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, justifyContent: 'flex-start' },
  scrim: { backgroundColor: 'rgba(2,6,23,0.4)' },
  cardWrap: { paddingHorizontal: 10 },
  card: { borderRadius: 30, overflow: 'hidden', padding: 16 },
  surfaceFallback: { overflow: 'hidden' },
  surfaceTint: { backgroundColor: 'rgba(6,16,32,0.78)' },
  glow: { position: 'absolute', left: 0, right: 0, top: 0, height: 110 },
  headRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  avatar: { width: 52, height: 52, borderRadius: 16, borderWidth: 1 },
  avatarFallback: { alignItems: 'center', justifyContent: 'center' },
  headText: { flex: 1, minWidth: 0 },
  kickerRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  kicker: { color: '#6EE7B7', fontSize: 10, fontWeight: '800', letterSpacing: 1.1 },
  name: { marginTop: 1, color: '#F8FAFC', fontSize: 18, fontWeight: '800', letterSpacing: -0.3 },
  meta: { marginTop: 1, color: MUTED, fontSize: 11.5, fontWeight: '600' },
  close: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(148,163,184,0.16)',
    alignSelf: 'flex-start',
  },
  stats: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 14,
    paddingVertical: 10,
    borderRadius: 18,
    backgroundColor: 'rgba(148,163,184,0.1)',
  },
  stat: { flex: 1, alignItems: 'center', gap: 2 },
  statValueRow: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  statValue: { color: '#F8FAFC', fontSize: 15, fontWeight: '800', fontVariant: ['tabular-nums'] },
  statLabel: { color: MUTED, fontSize: 10.5, fontWeight: '600' },
  divider: { width: StyleSheet.hairlineWidth, height: 22, backgroundColor: 'rgba(148,163,184,0.25)' },
  bio: { marginTop: 12, color: 'rgba(226,232,240,0.85)', fontSize: 13, lineHeight: 18, fontWeight: '500' },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 10 },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    height: 26,
    paddingHorizontal: 10,
    borderRadius: 13,
    backgroundColor: 'rgba(148,163,184,0.12)',
  },
  chipText: { color: 'rgba(226,232,240,0.85)', fontSize: 11.5, fontWeight: '600' },
  section: { marginTop: 12 },
  sectionLabel: { color: 'rgba(186,230,253,0.85)', fontSize: 10, fontWeight: '800', letterSpacing: 1.1 },
  photos: { flexDirection: 'row', gap: 6, marginTop: 8 },
  photo: { flex: 1, aspectRatio: 1, maxWidth: 80, borderRadius: 12, backgroundColor: 'rgba(148,163,184,0.12)' },
  review: { marginTop: 12, padding: 12, borderRadius: 16, backgroundColor: 'rgba(148,163,184,0.08)', gap: 4 },
  reviewHead: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  reviewStars: { flexDirection: 'row', gap: 2 },
  reviewAuthor: { flex: 1, color: 'rgba(148,163,184,0.9)', fontSize: 11, fontWeight: '600' },
  reviewBody: { color: 'rgba(241,245,249,0.92)', fontSize: 12.5, lineHeight: 17, fontWeight: '500' },
});
