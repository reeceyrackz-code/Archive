import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Modal,
  PanResponder,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import Animated, {
  Easing,
  FadeIn,
  FadeOut,
  LinearTransition,
  interpolate,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { FunctionsHttpError } from '@supabase/supabase-js';
import { useAuth } from '../../providers/enhanced-auth-context';
import { supabase } from '../../lib/supabase';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { RequestProCta } from './ConfirmProSheetParts';
import { syncBookingToDeviceCalendar } from '../../services/BookingCalendarSync';
import { colors } from '../../constants/colors';
import { getServiceDisplayName } from '../../utils/serviceNameMapper';
import BookingMapGlassBackground from './BookingMapGlassBackground';
import BusinessSheetBackground from '../shared/BusinessSheetBackground';

const SKY = colors.SKY ?? '#38BDF8';
const MUTED = 'rgba(148,163,184,0.9)';
const SNAP_SPRING = { damping: 20, stiffness: 220, mass: 0.9 };
const LAYOUT = LinearTransition.springify().damping(20).stiffness(200);

type IconName = keyof typeof Ionicons.glyphMap;

function PressScale({
  onPress,
  disabled,
  style,
  children,
  accessibilityLabel,
}: Readonly<{
  onPress: () => void;
  disabled?: boolean;
  style?: StyleProp<ViewStyle>;
  children: React.ReactNode;
  accessibilityLabel?: string;
}>) {
  const scale = useSharedValue(1);
  const aStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      onPressIn={() => { scale.value = withSpring(0.96, { damping: 18, stiffness: 400 }); }}
      onPressOut={() => { scale.value = withSpring(1, { damping: 14, stiffness: 300 }); }}
      accessibilityRole="button"
      {...(accessibilityLabel ? { accessibilityLabel } : {})}
    >
      <Animated.View style={[style, aStyle, disabled && styles.disabled]}>{children}</Animated.View>
    </Pressable>
  );
}

/** Animates a currency amount up to its value when it first appears / changes. */
function useCountUp(target: number, durationMs = 650): number {
  const [value, setValue] = useState(0);
  useEffect(() => {
    if (!Number.isFinite(target) || target <= 0) {
      setValue(Number.isFinite(target) ? target : 0);
      return undefined;
    }
    const start = Date.now();
    let raf = 0;
    const tick = () => {
      const t = Math.min(1, (Date.now() - start) / durationMs);
      const eased = 1 - Math.pow(1 - t, 3);
      setValue(target * eased);
      if (t < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, durationMs]);
  return value;
}

type PrepState = 'idle' | 'preparing' | 'ready' | 'error';

type BookingRecord = {
  id?: string;
  price?: number;
  add_ons_total?: number;
  discount_amount?: number;
  platform_fee_amount?: number;
  platform_fee_percent?: number;
  service_type?: string | null;
  service_name?: string | null;
  vehicle_info?: string | null;
  vehicle_type?: string | null;
  location_address?: string | null;
  scheduled_at?: string | null;
  status?: string;
  payment_completed_at?: string | null;
};

function useStripeNoop(): null {
  return null;
}
let useStripeImpl: () => ReturnType<typeof useStripeNoop> | { initPaymentSheet: unknown; presentPaymentSheet: unknown } =
  useStripeNoop;
if (Platform.OS !== 'web') {
  try {
    const stripe = require('@stripe/stripe-react-native');
    useStripeImpl = stripe.useStripe;
  } catch {
    /* no-op */
  }
}

function moneyGBP(value: unknown) {
  const n = Number(value);
  if (!Number.isFinite(n)) return '0.00';
  return n.toFixed(2);
}

function extractClientSecret(data: any): string | null {
  return (
    data?.clientSecret ??
    data?.client_secret ??
    data?.paymentIntentClientSecret ??
    data?.payment_intent_client_secret ??
    data?.paymentIntent?.clientSecret ??
    data?.paymentIntent?.client_secret ??
    data?.payment_intent?.client_secret ??
    null
  );
}

async function extractFunctionErrorMessage(error: unknown, fallback: string): Promise<string> {
  if (error instanceof FunctionsHttpError) {
    const response = error.context as Response | undefined;
    if (response) {
      try {
        const cloned = response.clone();
        const contentType = cloned.headers.get('content-type') || '';
        if (contentType.includes('application/json')) {
          const body = await cloned.json();
          if (typeof body?.error === 'string' && body.error.trim()) return body.error;
          if (typeof body?.message === 'string' && body.message.trim()) return body.message;
          if (typeof body?.details === 'string' && body.details.trim()) return body.details;
          return JSON.stringify(body);
        }
        const text = await cloned.text();
        if (text.trim()) return text;
      } catch {
        // Fall through to the generic message below.
      }
    }
    return error.message || fallback;
  }

  if (error && typeof error === 'object') {
    const maybeError = error as { message?: string; details?: unknown; hint?: unknown };
    if (typeof maybeError.message === 'string' && maybeError.message.trim()) return maybeError.message;
    if (typeof maybeError.details === 'string' && maybeError.details.trim()) return maybeError.details;
    if (typeof maybeError.hint === 'string' && maybeError.hint.trim()) return maybeError.hint;
  }

  return fallback;
}

export type BookingPaymentSheetProps = {
  visible: boolean;
  bookingId: string | null | undefined;
  onClose: () => void;
  /** After successful Stripe completion and DB update */
  onPaid: () => void;
  /** `route` = full-screen payment page with map behind; `modal` = overlay on tracking */
  presentation?: 'modal' | 'route';
};

export default function BookingPaymentSheet({
  visible,
  bookingId,
  onClose,
  onPaid,
  presentation = 'modal',
}: BookingPaymentSheetProps) {
  const { user } = useAuth();
  const stripeHook = useStripeImpl();
  const hookObj = stripeHook && typeof stripeHook === 'object' ? (stripeHook as Record<string, unknown>) : null;
  const initPaymentSheet = typeof hookObj?.initPaymentSheet === 'function' ? hookObj.initPaymentSheet : undefined;
  const presentPaymentSheet = typeof hookObj?.presentPaymentSheet === 'function' ? hookObj.presentPaymentSheet : undefined;

  const [booking, setBooking] = useState<BookingRecord | null>(null);
  const [loadingBooking, setLoadingBooking] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [prepState, setPrepState] = useState<PrepState>('idle');
  const [lastError, setLastError] = useState<string | null>(null);
  const [clientSecret, setClientSecret] = useState<string | null>(null);

  const sheetReady = prepState === 'ready';

  const reset = useCallback(() => {
    setBooking(null);
    setLoadingBooking(false);
    setProcessing(false);
    setPrepState('idle');
    setLastError(null);
    setClientSecret(null);
  }, []);

  useEffect(() => {
    if (!visible) {
      reset();
    }
  }, [visible, reset]);

  const loadBooking = useCallback(async () => {
    if (!bookingId || !visible) return;
    setLoadingBooking(true);
    setLastError(null);
    try {
      const { data, error } = await supabase.from('bookings').select('*').eq('id', bookingId).single();
      if (error) throw error;
      setBooking(data as BookingRecord);
    } catch (e: any) {
      setBooking(null);
      setLastError(e?.message || 'Could not load booking');
      setPrepState('error');
    } finally {
      setLoadingBooking(false);
    }
  }, [bookingId, visible]);

  useEffect(() => {
    if (visible && bookingId) void loadBooking();
  }, [visible, bookingId, loadBooking]);

  const markBookingPaid = useCallback(async () => {
    if (!bookingId) return;
    const { error } = await supabase
      .from('bookings')
      .update({
        status: 'confirmed',
        payment_completed_at: new Date().toISOString(),
      })
      .eq('id', bookingId);
    if (error) throw error;
    await syncBookingToDeviceCalendar({
      id: bookingId,
      serviceName: booking?.service_name ?? null,
      serviceType: booking?.service_type ?? null,
      address: booking?.location_address ?? null,
      scheduledAt: booking?.scheduled_at ?? null,
    });
  }, [bookingId, booking?.service_name, booking?.service_type, booking?.location_address, booking?.scheduled_at]);

  const presentSheetAndHandleResult = useCallback(async () => {
    if (!presentPaymentSheet) return;
    setProcessing(true);
    await hapticFeedback('medium');
    try {
      const { error } = await presentPaymentSheet();
      if (error) {
        if (error.code === 'Canceled') {
          setProcessing(false);
          return;
        }
        throw error;
      }
      await markBookingPaid();
      onPaid();
    } catch (e: any) {
      console.error('[BookingPaymentSheet]', e);
      Alert.alert('Payment failed', e?.message || 'Please try again.');
    } finally {
      setProcessing(false);
    }
  }, [presentPaymentSheet, markBookingPaid, onPaid, onClose]);

  const preparePaymentSheet = useCallback(async (): Promise<boolean> => {
    if (Platform.OS === 'web') {
      setLastError('Payment is native-only.');
      setPrepState('error');
      return false;
    }
    if (!booking || !user?.id || !bookingId) return false;
    if (!initPaymentSheet || !presentPaymentSheet) {
      setLastError('Stripe is not initialised.');
      setPrepState('error');
      return false;
    }

    setPrepState('preparing');
    setLastError(null);
    setClientSecret(null);

    const priceNumber = Number(booking.price);
    const amountPence = Math.round((Number.isFinite(priceNumber) ? priceNumber : 0) * 100);

    if (!amountPence || Number.isNaN(amountPence) || amountPence < 50) {
      setLastError('Invalid amount for this booking.');
      setPrepState('error');
      return false;
    }

    try {
      const { data, error } = await supabase.functions.invoke('booking-extra-charge', {
        body: {
          action: 'create_payment_intent',
          bookingId,
          currency: 'gbp',
          customerId: user.id,
          description: `Wish a Wash booking ${bookingId}`,
          amount: amountPence,
        },
      });

      if (error) {
        const message = await extractFunctionErrorMessage(error, 'Payment setup failed');
        setLastError(message);
        setPrepState('error');
        return false;
      }

      const cs = extractClientSecret(data);
      if (!cs) {
        setLastError('No payment client secret returned.');
        setPrepState('error');
        return false;
      }

      setClientSecret(cs);

      const { error: sheetError } = await initPaymentSheet({
        paymentIntentClientSecret: cs,
        merchantDisplayName: 'Wish a Wash',
        returnURL: 'waw://stripe-redirect',
        style: 'automatic',
      });

      if (sheetError) {
        setLastError(sheetError.message || 'Could not start payment.');
        setPrepState('error');
        return false;
      }

      setPrepState('ready');
      return true;
    } catch (e: any) {
      const message = await extractFunctionErrorMessage(e, 'Unexpected error preparing payment.');
      setLastError(message);
      setPrepState('error');
      return false;
    }
  }, [booking, user?.id, bookingId, initPaymentSheet, presentPaymentSheet]);

  useEffect(() => {
    if (!visible || !booking?.id || !user?.id || Platform.OS === 'web') return;
    void preparePaymentSheet();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visible, booking?.id, user?.id]);

  /** Opening the sheet should start Stripe — don't wait for a second Pay tap. */
  const autoPresentedRef = useRef(false);
  useEffect(() => {
    if (!visible) {
      autoPresentedRef.current = false;
      return;
    }
    if (prepState !== 'ready' || autoPresentedRef.current || processing) return;
    if (!presentPaymentSheet) return;
    autoPresentedRef.current = true;
    void presentSheetAndHandleResult();
  }, [visible, prepState, processing, presentPaymentSheet, presentSheetAndHandleResult]);

  const handlePayPress = useCallback(async () => {
    if (!bookingId || processing) return;
    if (Platform.OS === 'web') {
      Alert.alert('Not supported', 'Payment is native-only.');
      return;
    }
    if (!presentPaymentSheet) {
      Alert.alert('Stripe not ready', 'Payment is not available.');
      return;
    }

    setProcessing(true);
    let ready = sheetReady && !!clientSecret;
    if (!ready) {
      if (prepState === 'preparing') {
        setProcessing(false);
        Alert.alert('Hold on', 'Payment is still preparing…');
        return;
      }
      ready = await preparePaymentSheet();
      if (!ready) {
        setProcessing(false);
        Alert.alert('Hold on', lastError || 'Payment is not ready. Try Retry below.');
        return;
      }
    }
    await presentSheetAndHandleResult();
  }, [bookingId, processing, sheetReady, clientSecret, prepState, preparePaymentSheet, presentSheetAndHandleResult, presentPaymentSheet, lastError]);

  const serviceLabel = useMemo(
    () => getServiceDisplayName(booking?.service_type, booking?.service_name),
    [booking?.service_type, booking?.service_name],
  );
  const totalNumber = Number(booking?.price) || 0;
  const totalDisplay = moneyGBP(booking?.price);
  const addOns = Number(booking?.add_ons_total) || 0;
  const platformFee = Number(booking?.platform_fee_amount) || 0;
  const discountAmount = Number(booking?.discount_amount) || 0;
  const serviceSubtotal = Math.max(0, Number(booking?.price) - addOns - platformFee + discountAmount);

  const insets = useSafeAreaInsets();
  const { height: screenH } = useWindowDimensions();
  const isRoute = presentation === 'route';
  const animatedTotal = useCountUp(booking ? totalNumber : 0);
  const [breakdownOpen, setBreakdownOpen] = useState(false);
  const sheetY = useSharedValue(screenH);
  const backdrop = useSharedValue(0);
  const closingRef = useRef(false);
  const chevron = useSharedValue(0);

  useEffect(() => {
    if (!visible) return;
    closingRef.current = false;
    setBreakdownOpen(false);
    sheetY.value = screenH;
    sheetY.value = withTiming(0, { duration: 340, easing: Easing.out(Easing.cubic) });
    backdrop.value = 0;
    backdrop.value = withTiming(1, { duration: 260 });
  }, [visible, screenH, sheetY, backdrop]);

  useEffect(() => {
    chevron.value = withSpring(breakdownOpen ? 1 : 0, SNAP_SPRING);
  }, [breakdownOpen, chevron]);

  const requestClose = useCallback(() => {
    if (closingRef.current) return;
    closingRef.current = true;
    sheetY.value = withTiming(screenH, { duration: 230, easing: Easing.in(Easing.cubic) });
    backdrop.value = withTiming(0, { duration: 230 });
    setTimeout(onClose, 220);
  }, [onClose, screenH, sheetY, backdrop]);

  const pan = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => false,
        onMoveShouldSetPanResponder: (_, g) => g.dy > 6 && Math.abs(g.dy) > Math.abs(g.dx),
        onPanResponderMove: (_, g) => {
          sheetY.value = Math.max(0, g.dy);
        },
        onPanResponderRelease: (_, g) => {
          if (g.dy > 110 || g.vy > 0.8) requestClose();
          else sheetY.value = withSpring(0, SNAP_SPRING);
        },
        onPanResponderTerminate: () => {
          sheetY.value = withSpring(0, SNAP_SPRING);
        },
      }),
    [requestClose, sheetY]
  );

  const sheetStyle = useAnimatedStyle(() => ({
    opacity: interpolate(sheetY.value, [0, screenH * 0.35], [1, 0], 'clamp'),
    transform: [
      { translateY: sheetY.value },
      { scale: interpolate(sheetY.value, [0, screenH * 0.35], [1, 0.96], 'clamp') },
    ],
  }));
  const backdropStyle = useAnimatedStyle(() => ({ opacity: backdrop.value }));
  const chevronStyle = useAnimatedStyle(() => ({ transform: [{ rotate: `${chevron.value * 180}deg` }] }));

  if (!visible) return null;

  const busy = processing || prepState === 'preparing';
  const status: { key: string; icon: IconName | null; color: string; text: string } =
    prepState === 'error'
      ? { key: 'error', icon: 'alert-circle', color: '#FCA5A5', text: lastError || 'Something went wrong' }
      : processing
        ? { key: 'processing', icon: null, color: SKY, text: 'Waiting for secure payment…' }
        : prepState === 'preparing'
          ? { key: 'preparing', icon: null, color: SKY, text: 'Preparing secure payment…' }
          : prepState === 'ready'
            ? { key: 'ready', icon: 'checkmark-circle', color: '#34D399', text: 'Ready to pay' }
            : { key: 'idle', icon: 'time-outline', color: MUTED, text: 'Getting things ready…' };

  const vehicleText = booking?.vehicle_info || booking?.vehicle_type || null;
  const breakdown = [
    { label: 'Service', value: `£${moneyGBP(serviceSubtotal)}` },
    ...(platformFee > 0 ? [{ label: 'Platform fee', value: `£${moneyGBP(platformFee)}` }] : []),
    ...(addOns > 0 ? [{ label: 'Add-ons', value: `£${moneyGBP(addOns)}` }] : []),
    ...(discountAmount > 0 ? [{ label: 'Discount', value: `−£${moneyGBP(discountAmount)}`, positive: true }] : []),
  ];
  const detailRows: { key: string; icon: IconName; text: string }[] = booking
    ? [
        { key: 'service', icon: 'sparkles-outline', text: serviceLabel },
        ...(vehicleText ? [{ key: 'vehicle', icon: 'car-sport-outline' as IconName, text: vehicleText }] : []),
        ...(booking.location_address
          ? [{ key: 'location', icon: 'location-outline' as IconName, text: booking.location_address }]
          : []),
      ]
    : [];

  const sheet = (
    <View style={styles.root} pointerEvents="box-none">
      {!isRoute ? (
        <Animated.View style={[StyleSheet.absoluteFill, styles.backdrop, backdropStyle]}>
          <Pressable style={StyleSheet.absoluteFill} onPress={requestClose} accessibilityLabel="Close payment" />
        </Animated.View>
      ) : null}

      <Animated.View
        style={[
          styles.wrap,
          {
            marginBottom: Math.max(insets.bottom, 10) + 6,
            maxHeight: Math.min(screenH * 0.9, screenH - insets.top - 24),
          },
          sheetStyle,
        ]}
      >
        <BusinessSheetBackground reportObstruction={isRoute} />
        <LinearGradient
          colors={[`${SKY}1F`, 'transparent']}
          start={{ x: 0.5, y: 0 }}
          end={{ x: 0.5, y: 1 }}
          style={styles.accentWash}
          pointerEvents="none"
        />

        <View {...pan.panHandlers}>
          <View style={styles.handleHit}>
            <View style={styles.handle} />
          </View>
          <View style={styles.headerRow}>
            <View style={styles.secureChip}>
              <Ionicons name="lock-closed" size={11} color="#34D399" />
              <Text style={styles.secureText}>Secure checkout</Text>
            </View>
            <PressScale onPress={requestClose} style={styles.closeBtn} accessibilityLabel="Close payment sheet">
              <Ionicons name="close" size={17} color="rgba(226,232,240,0.85)" />
            </PressScale>
          </View>
        </View>

        <ScrollView
          style={styles.scroll}
          contentContainerStyle={styles.content}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          bounces={false}
        >
          {loadingBooking && !booking ? (
            <Animated.View entering={FadeIn.duration(220)} style={styles.centerBlock}>
              <ActivityIndicator color={SKY} />
              <Text style={styles.muted}>Loading booking…</Text>
            </Animated.View>
          ) : !booking ? (
            <Animated.View entering={FadeIn.duration(220)} style={styles.errorCard}>
              <Ionicons name="alert-circle" size={16} color="#FCA5A5" />
              <Text style={styles.errorText}>{lastError || 'Booking not found.'}</Text>
            </Animated.View>
          ) : (
            <Animated.View entering={FadeIn.duration(280)} layout={LAYOUT}>
              <View style={styles.amountHero}>
                <Text style={styles.amountLabel}>Total due</Text>
                <Text style={styles.amountValue}>£{animatedTotal.toFixed(2)}</Text>
                <Animated.View
                  key={status.key}
                  entering={FadeIn.duration(220)}
                  exiting={FadeOut.duration(120)}
                  style={styles.statusLine}
                >
                  {status.icon ? (
                    <Ionicons name={status.icon} size={13} color={status.color} />
                  ) : (
                    <ActivityIndicator size="small" color={status.color} style={styles.statusSpinner} />
                  )}
                  <Text style={[styles.statusText, { color: status.color }]} numberOfLines={2}>
                    {status.text}
                  </Text>
                  {prepState === 'error' ? (
                    <Pressable
                      onPress={() => {
                        void hapticFeedback('light');
                        setPrepState('idle');
                        void preparePaymentSheet();
                      }}
                      hitSlop={8}
                      style={styles.retryChip}
                    >
                      <Ionicons name="refresh" size={12} color="#F8FAFC" />
                      <Text style={styles.retryChipText}>Retry</Text>
                    </Pressable>
                  ) : null}
                </Animated.View>
              </View>

              <View style={styles.summaryCard}>
                {detailRows.map((row) => (
                  <View key={row.key} style={styles.infoRow}>
                    <View style={styles.infoDot}>
                      <Ionicons name={row.icon} size={14} color="rgba(226,232,240,0.85)" />
                    </View>
                    <Text style={styles.infoValue} numberOfLines={1}>
                      {row.text}
                    </Text>
                  </View>
                ))}

                <Pressable
                  onPress={() => {
                    void hapticFeedback('light');
                    setBreakdownOpen((v) => !v);
                  }}
                  style={styles.breakdownToggle}
                  accessibilityRole="button"
                >
                  <Text style={styles.breakdownToggleText}>Price breakdown</Text>
                  <Animated.View style={chevronStyle}>
                    <Ionicons name="chevron-down" size={15} color={MUTED} />
                  </Animated.View>
                </Pressable>
                {breakdownOpen ? (
                  <Animated.View entering={FadeIn.duration(220)} exiting={FadeOut.duration(120)} style={styles.breakdown}>
                    {breakdown.map((row) => (
                      <View key={row.label} style={styles.rowBetween}>
                        <Text style={styles.mutedSmall}>{row.label}</Text>
                        <Text style={[styles.amount, row.positive && { color: '#34D399' }]}>{row.value}</Text>
                      </View>
                    ))}
                    <View style={[styles.rowBetween, styles.totalRow]}>
                      <Text style={styles.totalLabel}>Total</Text>
                      <Text style={styles.totalValue}>£{totalDisplay}</Text>
                    </View>
                  </Animated.View>
                ) : null}
              </View>
            </Animated.View>
          )}

          <RequestProCta
            accent={SKY}
            title={booking ? `Pay £${totalDisplay}` : 'Pay'}
            subtitle="Apple Pay · Card · Encrypted by Stripe"
            disabled={!booking}
            loading={busy}
            onPress={() => void handlePayPress()}
            idleIcon="lock-closed"
          />

          <Pressable style={styles.cancelLink} onPress={requestClose} hitSlop={8}>
            <Text style={styles.cancelLinkText}>Not now</Text>
          </Pressable>
        </ScrollView>
      </Animated.View>
    </View>
  );

  if (isRoute) return sheet;

  return (
    <Modal visible transparent animationType="none" onRequestClose={requestClose} statusBarTranslucent>
      {sheet}
    </Modal>
  );
}

const styles = StyleSheet.create({
  root: { ...StyleSheet.absoluteFill, justifyContent: 'flex-end', zIndex: 2 },
  backdrop: { backgroundColor: 'rgba(2,6,23,0.5)' },
  wrap: {
    marginHorizontal: 10,
    borderRadius: 30,
    overflow: 'hidden',
    backgroundColor: colors.BG ?? '#0A1929',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.35,
    shadowRadius: 28,
    elevation: 20,
  },
  accentWash: { position: 'absolute', top: 0, left: 0, right: 0, height: 180 },
  handleHit: { alignItems: 'center', paddingTop: 8, paddingBottom: 6 },
  handle: { width: 36, height: 4, borderRadius: 2, backgroundColor: 'rgba(148,163,184,0.35)' },
  headerRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16 },
  secureChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 999,
    backgroundColor: 'rgba(52,211,153,0.1)',
  },
  secureText: { color: '#6EE7B7', fontSize: 11.5, fontWeight: '700' },
  closeBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.07)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  scroll: { flexGrow: 0, flexShrink: 1 },
  content: { paddingHorizontal: 16, paddingBottom: 6 },
  centerBlock: { alignItems: 'center', paddingVertical: 28, gap: 10 },
  muted: { color: 'rgba(226,232,240,0.75)', fontSize: 13, fontWeight: '600' },
  errorCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    padding: 12,
    borderRadius: 18,
    backgroundColor: 'rgba(239,68,68,0.1)',
    marginVertical: 12,
  },
  errorText: { flex: 1, color: '#FCA5A5', fontSize: 13, fontWeight: '600' },

  amountHero: { alignItems: 'center', paddingTop: 14, paddingBottom: 16 },
  amountLabel: { color: MUTED, fontSize: 12, fontWeight: '600' },
  amountValue: {
    color: '#F8FAFC',
    fontSize: 36,
    fontWeight: '800',
    letterSpacing: -1,
    fontVariant: ['tabular-nums'],
    marginTop: 2,
  },
  statusLine: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 8, maxWidth: '92%' },
  statusSpinner: { transform: [{ scale: 0.75 }] },
  statusText: { flexShrink: 1, fontSize: 12.5, fontWeight: '600', textAlign: 'center' },
  retryChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
    backgroundColor: 'rgba(255,255,255,0.1)',
  },
  retryChipText: { color: '#F8FAFC', fontSize: 11.5, fontWeight: '700' },

  summaryCard: { borderRadius: 22, backgroundColor: 'rgba(2,6,23,0.35)', padding: 12, gap: 10, marginBottom: 16 },
  infoRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  infoDot: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  infoValue: { flex: 1, color: 'rgba(241,245,249,0.92)', fontSize: 13.5, fontWeight: '600' },
  breakdownToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingTop: 10,
    paddingHorizontal: 2,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(148,163,184,0.18)',
  },
  breakdownToggleText: { flex: 1, color: 'rgba(203,213,225,0.9)', fontSize: 12.5, fontWeight: '600' },
  breakdown: { gap: 6, paddingHorizontal: 2 },
  rowBetween: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  mutedSmall: { color: MUTED, fontSize: 12.5, fontWeight: '500' },
  amount: { color: '#E2E8F0', fontSize: 12.5, fontWeight: '600' },
  totalRow: { marginTop: 2, paddingTop: 8, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: 'rgba(148,163,184,0.18)' },
  totalLabel: { color: '#F8FAFC', fontSize: 13, fontWeight: '700' },
  totalValue: { color: '#F8FAFC', fontSize: 14, fontWeight: '800' },

  cancelLink: { alignSelf: 'center', paddingVertical: 10, marginTop: 4 },
  cancelLinkText: { color: 'rgba(148,163,184,0.9)', fontSize: 13, fontWeight: '600' },
});
