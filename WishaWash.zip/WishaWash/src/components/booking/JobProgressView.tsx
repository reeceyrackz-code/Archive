import { useEffect, useRef, useState } from 'react';
import { Image, StyleSheet, Text, View } from 'react-native';
import Animated, { FadeIn, FadeInDown, FadeOut, ZoomIn, useAnimatedStyle, useSharedValue, withRepeat, withTiming, Easing } from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { type JobKind, type WashStation } from '../../utils/washJourney';

const MASCOT = require('../../../assets/map-mascot.png');
const GREEN = '#34D399';
const MUTED = 'rgba(203,213,225,0.55)';
const DONE_MS = 4200;
const KIND_WORD: Record<JobKind, string> = { wash: 'wash', detail: 'detail', repair: 'repair' };
const DONE_TITLE: Record<JobKind, string> = { wash: 'Your car is gleaming', detail: 'Detailed to a shine', repair: 'Repaired and good as new' };

/** Rotating while the job is on-site — honest encouragement, never a made-up step, percentage or time. */
const LIVE_LINES: Record<JobKind, readonly string[]> = {
  wash: [
    'Bringing the magic to reality',
    'Foam on, grime off',
    'Every panel getting the love',
    'Working on that shine',
    'The little details matter',
  ],
  detail: [
    'Bringing the magic to reality',
    'Deep clean in motion',
    'Every corner, every crease',
    'Restoring that showroom feel',
    'Precision in every pass',
  ],
  repair: [
    'Bringing the fix to reality',
    'Careful hands at work',
    'Taking care of every detail',
    'Quality over rush',
    'Restoring your car at its best',
  ],
};
const LINE_MS = 4000;

function useRotatingLine(lines: readonly string[], active: boolean): string {
  const [i, setI] = useState(0);
  useEffect(() => {
    if (!active) return;
    const id = setInterval(() => setI((n) => (n + 1) % lines.length), LINE_MS);
    return () => clearInterval(id);
  }, [active, lines.length]);
  return lines[i % lines.length] ?? lines[0] ?? '';
}

/** The Pro app mascot in a soft breathing glow. */
function GlowBadge({ color }: Readonly<{ color: string }>) {
  const t = useSharedValue(0);
  useEffect(() => {
    t.value = withRepeat(withTiming(1, { duration: 2200, easing: Easing.inOut(Easing.sin) }), -1, true);
  }, [t]);
  const ring = useAnimatedStyle(() => ({ opacity: 0.25 + t.value * 0.35, transform: [{ scale: 1 + t.value * 0.18 }] }));
  return (
    <View style={styles.glowWrap}>
      <Animated.View style={[styles.glowRing, { backgroundColor: `${color}33`, borderColor: `${color}88` }, ring]} />
      <View style={[styles.glowCore, { backgroundColor: color }]}>
        <Image source={MASCOT} style={styles.mascot} resizeMode="cover" accessibilityIgnoresInvertColors />
      </View>
    </View>
  );
}

/** Looping shimmer: shows work is happening without claiming how far along it is. */
function ShimmerBar({ color }: Readonly<{ color: string }>) {
  const [w, setW] = useState(0);
  const t = useSharedValue(0);
  useEffect(() => {
    t.value = withRepeat(withTiming(1, { duration: 1800, easing: Easing.inOut(Easing.quad) }), -1, false);
  }, [t]);
  const seg = useAnimatedStyle(() => ({ transform: [{ translateX: -w * 0.4 + t.value * w * 1.4 }] }));
  return (
    <View style={styles.track} onLayout={(e) => setW(e.nativeEvent.layout.width)}>
      <Animated.View style={[styles.trackSeg, { width: w * 0.4, backgroundColor: color }, seg]} />
    </View>
  );
}

type Props = Readonly<{
  status: 'in_progress' | 'completed';
  accent: string;
  kind: JobKind;
  proName: string | null;
  stations: WashStation[];
  startedAt: number | null;
  estimateMs: number | null;
  top: number;
  bottom: number;
  onDone?: () => void;
}>;

/** On-site view: rotating messages while the Pro works, then a finished summary. */
export default function JobProgressView({ status, accent, kind, proName, top, bottom, onDone }: Props) {
  const done = status === 'completed';
  const line = useRotatingLine(LIVE_LINES[kind], !done);

  const doneRef = useRef(onDone);
  doneRef.current = onDone;
  useEffect(() => {
    if (!done) return;
    void hapticFeedback('medium');
    const id = setTimeout(() => doneRef.current?.(), DONE_MS);
    return () => clearTimeout(id);
  }, [done]);

  const first = proName?.trim().split(/\s+/)[0] || 'Your Pro';

  return (
    <View pointerEvents="none" style={[styles.wrap, { top }]}>
      <View style={[styles.band, { height: bottom - top }]}>
        {done ? (
          <Animated.View key="done" entering={FadeInDown.duration(450)} style={styles.center}>
            <Animated.View entering={ZoomIn.springify().damping(12)} style={[styles.doneBadge, { backgroundColor: GREEN }]}>
              <Ionicons name="checkmark" size={30} color="#04121F" />
            </Animated.View>
            <Text style={[styles.kicker, styles.centerText]}>ALL DONE</Text>
            <Text style={[styles.heroTitle, styles.centerText]} numberOfLines={2}>
              {DONE_TITLE[kind]}
            </Text>
          </Animated.View>
        ) : (
          <Animated.View key="live" entering={FadeIn.duration(450)} style={styles.center}>
            <GlowBadge color={accent} />
            <Text style={[styles.kicker, styles.centerText]}>
              {first.toUpperCase()} IS ON YOUR {KIND_WORD[kind].toUpperCase()}
            </Text>
            <View style={styles.lineSlot}>
              <Animated.Text
                key={line}
                entering={FadeInDown.duration(500).easing(Easing.out(Easing.cubic))}
                exiting={FadeOut.duration(300)}
                style={[styles.heroTitle, styles.centerText]}
                numberOfLines={2}
              >
                {line}
              </Animated.Text>
            </View>
            <ShimmerBar color={accent} />
            <Text style={[styles.note, styles.centerText]}>We’ll let you know the moment it’s done.</Text>
          </Animated.View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { position: 'absolute', left: 0, right: 0 },
  band: { paddingHorizontal: 28, justifyContent: 'center' },
  center: { alignItems: 'center' },
  centerText: { textAlign: 'center' },
  kicker: { marginTop: 18, color: MUTED, fontSize: 11, fontWeight: '800', letterSpacing: 1.1 },
  lineSlot: { minHeight: 70, justifyContent: 'center', alignSelf: 'stretch' },
  heroTitle: { marginTop: 6, color: '#FFFFFF', fontSize: 26, fontWeight: '800', letterSpacing: -0.6 },
  note: { marginTop: 14, color: MUTED, fontSize: 12.5, fontWeight: '600' },
  glowWrap: { width: 104, height: 104, alignItems: 'center', justifyContent: 'center' },
  glowRing: { position: 'absolute', width: 104, height: 104, borderRadius: 52, borderWidth: 1.5 },
  glowCore: {
    width: 76,
    height: 76,
    borderRadius: 38,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2.5,
    borderColor: '#FFFFFF',
  },
  mascot: { width: 96, height: 96 },
  doneBadge: {
    width: 52,
    height: 52,
    borderRadius: 26,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: GREEN,
    shadowOpacity: 0.7,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 0 },
  },
  track: { marginTop: 14, alignSelf: 'stretch', height: 4, borderRadius: 2, backgroundColor: 'rgba(255,255,255,0.1)', overflow: 'hidden' },
  trackSeg: { height: '100%', borderRadius: 2 },
});
