import { useEffect } from 'react';
import { StyleSheet, View } from 'react-native';
import Animated, { Easing, FadeIn, FadeOut, useAnimatedStyle, useSharedValue, withDelay, withRepeat, withTiming } from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { type JobKind, type WashStation } from '../../utils/washJourney';
import JobProgressView from './JobProgressView';
import BackgroundVideo from '../shared/BackgroundVideo';
import { WASHING_STAGE_VIDEO } from '../../../assets/_assetExports';

/** `matching` = still finding a Pro; every other pre-arrival stage shows the live map untouched. */
export type TrackingBackdropStage = 'matching' | 'in_progress' | 'completed';

export type WashJourneyInput = Readonly<{ startedAt: number; estimateMs: number; kind: JobKind; stations: WashStation[] }>;

type Props = Readonly<{
  stage: TrackingBackdropStage | null;
  accent: string;
  journey?: WashJourneyInput | null;
  stations: WashStation[];
  kind: JobKind;
  proName?: string | null;
  onFinaleDone?: () => void;
  /** Height of the map box this layer fills (between the header and the sheet). */
  boxHeight: number;
  /** Top strip of the box hidden behind the header. */
  topClearance?: number;
  /** Bottom strip of the box tucked under the sheet's rounded top. */
  bottomTuck?: number;
}>;

/** Layer inside the tracking map box, above the map. */
export default function TrackingStageBackdrop({ stage, accent, journey, stations, kind, proName, onFinaleDone, boxHeight, topClearance = 0, bottomTuck = 0 }: Props) {
  if (!stage) return null;
  const top = topClearance + 14;
  const bottom = Math.max(top + 160, boxHeight - bottomTuck - 14);

  return (
    <Animated.View key={stage === 'matching' ? 'matching' : 'onsite'} entering={FadeIn.duration(600)} exiting={FadeOut.duration(400)} style={StyleSheet.absoluteFill} pointerEvents="none">
      {stage === 'matching' ? (
        <SearchPulse accent={accent} topClearance={topClearance} bottomTuck={bottomTuck} />
      ) : (
        <>
          <LinearGradient colors={['#0B1424', '#081020', '#050A14']} style={StyleSheet.absoluteFill} />
        {stage === 'in_progress' || stage === 'completed' ? (
          <>
              <BackgroundVideo source={WASHING_STAGE_VIDEO} style={StyleSheet.absoluteFill} />
      <LinearGradient
                colors={['rgba(5,10,20,0.82)', 'rgba(5,10,20,0.55)', 'rgba(5,10,20,0.7)', 'rgba(5,10,20,0.92)']}
                locations={[0, 0.35, 0.65, 1]}
        style={StyleSheet.absoluteFill}
      />
        </>
      ) : null}
          <JobProgressView
            status={stage}
            accent={accent}
            kind={journey?.kind ?? kind}
            proName={proName ?? null}
            stations={journey?.stations ?? stations}
            startedAt={journey?.startedAt ?? null}
            estimateMs={journey?.estimateMs ?? null}
        top={top}
            bottom={bottom}
            {...(onFinaleDone ? { onDone: onFinaleDone } : {})}
          />
        </>
      )}
    </Animated.View>
  );
}

function PulseRing({ delay, color }: Readonly<{ delay: number; color: string }>) {
  const t = useSharedValue(0);
  useEffect(() => {
    t.value = withDelay(delay, withRepeat(withTiming(1, { duration: 2700, easing: Easing.out(Easing.quad) }), -1, false));
  }, [t, delay]);
  const style = useAnimatedStyle(() => ({ opacity: 0.55 * (1 - t.value), transform: [{ scale: 0.25 + t.value * 1.2 }] }));
  return <Animated.View style={[styles.ring, { borderColor: color, backgroundColor: `${color}14` }, style]} />;
}

/** Radar pulse around your car pin while a Pro is being found. */
function SearchPulse({ accent, topClearance, bottomTuck }: Readonly<{ accent: string; topClearance: number; bottomTuck: number }>) {
  return (
    <View style={[styles.center, { top: topClearance, bottom: bottomTuck }]}>
      {[0, 900, 1800].map((d) => (
        <PulseRing key={d} delay={d} color={accent} />
      ))}
    </View>
  );
}

const RING = 220;

const styles = StyleSheet.create({
  center: { ...StyleSheet.absoluteFill, alignItems: 'center', justifyContent: 'center' },
  ring: { position: 'absolute', width: RING, height: RING, borderRadius: RING / 2, borderWidth: 1.5 },
});
