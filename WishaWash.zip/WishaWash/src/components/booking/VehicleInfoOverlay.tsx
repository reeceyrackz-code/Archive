import { View, Text, StyleSheet, ScrollView } from 'react-native';
import BookingBottomSheetOverlay from './BookingBottomSheetOverlay';
import { BOOKING_INFO_SHEET_ACCENT } from '../../constants/bookingInfoSheetTheme';
import {
  InfoSheetButton,
  InfoSheetHero,
  InfoSheetRow,
  InfoSheetSection,
  InfoSheetStat,
} from '../shared/InfoSheetKit';

export type VehicleInfoOverlayVehicle = {
  id: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  image_url?: string | null;
  photo?: string | null;
  type?: string | null;
  size?: string | null;
  mot_expiry?: string | null;
  mot_expiry_date?: string | null;
  tax_status?: string | null;
  tax_due_date?: string | null;
  tax_expiry?: string | null;
  mileage?: string | number | null;
};

export type VehicleStats = {
  washCount: number;
  lastCleanedAt: string | null;
  cleanRating: number | null;
};

type VehicleInfoOverlayProps = {
  visible: boolean;
  vehicle: VehicleInfoOverlayVehicle | null;
  stats: VehicleStats;
  accentColor: string;
  onClose: () => void;
};

function formatSize(size: string | null | undefined): string {
  if (!size) return '';
  const s = String(size).toLowerCase();
  if (s === 'small') return 'S';
  if (s === 'medium') return 'M';
  if (s === 'large') return 'L';
  if (s === 'xl') return 'XL';
  if (s === 'xxl') return 'XXL (HGV)';
  return s.charAt(0).toUpperCase() + s.slice(1);
}

function formatDate(iso: string | null | undefined): string {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
  } catch {
    return '—';
  }
}

function getMotStatus(expiry: string | null | undefined): string {
  if (!expiry) return '—';
  try {
    const d = new Date(expiry);
    const dateStr = d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
    return d >= new Date() ? `Valid until ${dateStr}` : `Expired ${dateStr}`;
  } catch {
    return String(expiry);
  }
}

function getTaxStatus(
  status: string | null | undefined,
  dueDate: string | null | undefined,
  expiry: string | null | undefined
): string {
  const dateStr = dueDate || expiry;
  if (dateStr) {
    try {
      const d = new Date(dateStr);
      const formatted = d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
      if (d >= new Date()) return `Valid until ${formatted}`;
      return `Expired ${formatted}`;
    } catch {
      // fall through
    }
  }
  if (status && String(status).trim()) return String(status).trim();
  return '—';
}

export function VehicleInfoOverlay({
  visible,
  vehicle,
  stats,
  accentColor = BOOKING_INFO_SHEET_ACCENT,
  onClose,
}: VehicleInfoOverlayProps) {
  const imageUri = vehicle?.image_url ?? vehicle?.photo ?? null;
  const motDate = vehicle?.mot_expiry_date ?? vehicle?.mot_expiry ?? null;
  const taxDue = vehicle?.tax_due_date ?? vehicle?.tax_expiry ?? null;
  const mileage =
    vehicle?.mileage != null && vehicle.mileage !== ''
      ? typeof vehicle.mileage === 'number'
        ? vehicle.mileage.toLocaleString()
        : String(vehicle.mileage)
      : null;

  const motStatus = getMotStatus(motDate);
  const taxStatus = getTaxStatus(vehicle?.tax_status, vehicle?.tax_due_date, taxDue);
  const statusColor = (value: string) =>
    value.startsWith('Expired') ? '#F87171' : value.startsWith('Valid') ? '#34D399' : undefined;

  const detailRows = vehicle
    ? [
        { icon: 'shield-checkmark' as const, tint: '#34D399', label: 'MOT', value: motStatus },
        { icon: 'receipt' as const, tint: '#38BDF8', label: 'Tax', value: taxStatus },
        mileage != null ? { icon: 'speedometer' as const, tint: '#CBD5E1', label: 'Mileage', value: `${mileage} miles` } : null,
        vehicle.size ? { icon: 'resize' as const, tint: '#A78BFA', label: 'Size', value: formatSize(vehicle.size) } : null,
        vehicle.type ? { icon: 'shapes' as const, tint: '#F472B6', label: 'Type', value: vehicle.type } : null,
      ].filter((r): r is NonNullable<typeof r> => r != null)
    : [];

  return (
    <BookingBottomSheetOverlay visible={visible} onClose={onClose} maxHeightRatio={0.9}>
      {!vehicle ? (
        <View style={styles.loadingState}>
          <Text style={styles.loadingText}>Loading…</Text>
          <InfoSheetButton accent={accentColor} label="Close" icon="close" onPress={onClose} />
        </View>
      ) : (
        <>
          <ScrollView
            style={styles.scroll}
            contentContainerStyle={styles.scrollContent}
            showsVerticalScrollIndicator={false}
            nestedScrollEnabled
          >
            <InfoSheetHero
              accent={accentColor}
              icon="car-sport"
              imageUri={imageUri}
              eyebrow={vehicle.registration}
              title={`${vehicle.make} ${vehicle.model}`}
              {...(vehicle.color ? { subtitle: vehicle.color } : {})}
            />

            <InfoSheetSection title="Service history" icon="water" accent={accentColor} index={0}>
              <View style={styles.statsRow}>
                <InfoSheetStat
                  icon="water"
                  accent="#34D399"
                  value={String(stats.washCount)}
                  label={stats.washCount === 1 ? 'Wash' : 'Washes'}
                />
                <InfoSheetStat icon="calendar" accent={accentColor} value={formatDate(stats.lastCleanedAt)} label="Last clean" />
                <InfoSheetStat
                  icon="star"
                  accent="#FBBF24"
                  value={stats.cleanRating != null ? `${stats.cleanRating}/5` : '—'}
                  label="Rating"
                />
              </View>
            </InfoSheetSection>

            <InfoSheetSection title="MOT, tax & specs" icon="document-text" accent={accentColor} index={1}>
              {detailRows.map((item, index) => (
                <InfoSheetRow
                  key={item.label}
                  icon={item.icon}
                  accent={item.tint}
                  label={item.label}
                  value={item.value}
                  {...(statusColor(item.value) ? { valueColor: statusColor(item.value) as string } : {})}
                  last={index === detailRows.length - 1}
                />
              ))}
            </InfoSheetSection>
          </ScrollView>

          <InfoSheetButton accent={accentColor} label="Done" onPress={onClose} />
        </>
      )}
    </BookingBottomSheetOverlay>
  );
}

const styles = StyleSheet.create({
  loadingState: {
    paddingVertical: 24,
    justifyContent: 'center',
    minHeight: 120,
  },
  loadingText: {
    color: '#94A3B8',
    fontSize: 16,
    marginBottom: 16,
    textAlign: 'center',
  },
  scroll: {
    maxHeight: 520,
  },
  scrollContent: {
    paddingBottom: 12,
    flexGrow: 1,
  },
  statsRow: {
    flexDirection: 'row',
    gap: 8,
  },
});
