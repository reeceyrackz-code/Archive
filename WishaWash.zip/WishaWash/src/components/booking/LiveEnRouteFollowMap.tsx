import { useCallback, useEffect, useRef, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Marker, Polyline, type Region } from 'react-native-maps';
import type MapView from 'react-native-maps';
import SafeMapView from '../maps/SafeMapView';
import { LinearGradient } from 'expo-linear-gradient';
import { MapMarkerTopDownCar } from '../maps/MapMarkerViews';
import MapMarkerMascotDroplet from '../maps/MapMarkerMascotDroplet';
import {
  LOCATION_PICKER_MAP_STYLE,
  MAP_CAMERA_ANIMATION_DURATION,
  MAP_LOCKED_DARK,
  MAP_ZOOM_DELTA,
} from '../../constants/mapConstants';
import { regionForCoordinates } from '../../utils/mapUtils';
import { ROUTE_LINE_COLOR, useRoadRoute } from '../../utils/roadRoute';

type Coord = { latitude: number; longitude: number };


type Props = {
  customer: Coord;
  valeter: Coord;
  /** When true, camera follows the Care Pro; otherwise stays locked on the customer. */
  followValeter: boolean;
  /** Draw the driving route Pro → you with a distance tag, and frame the whole route. */
  showRoute?: boolean;
  accent?: string;
  /** Screen space covered by the header (top) and tracking sheet (bottom), kept clear when framing the route. */
  edgePadding?: { top: number; bottom: number };
  /** Dark overlay over the map; off for stages that want the plain map. */
  tinted?: boolean;
};

const ROUTE_EDGE_SIDE = 56;
/** Car and van pins share one nose-to-tail length so they read as the same scale. */
const PIN_LENGTH = 64;
const MASCOT_SIZE = 36;
/** Extra breathing room above/below the route so the pins clear the header and sheet edges. */
const ROUTE_EDGE_V = 36;

const GLIDE_MS = 1200;

/** Eases a coordinate towards each new target so the Pro's marker glides rather than jumps. */
function useGlidingCoord(target: Coord): Coord {
  const [shown, setShown] = useState(target);
  const shownRef = useRef(target);
  useEffect(() => {
    const from = shownRef.current;
    if (from.latitude === target.latitude && from.longitude === target.longitude) return;
    const start = Date.now();
    let frame = 0;
    const step = () => {
      const t = Math.min(1, (Date.now() - start) / GLIDE_MS);
      const e = 1 - (1 - t) * (1 - t);
      const next = {
        latitude: from.latitude + (target.latitude - from.latitude) * e,
        longitude: from.longitude + (target.longitude - from.longitude) * e,
      };
      shownRef.current = next;
      setShown(next);
      if (t < 1) frame = requestAnimationFrame(step);
    };
    frame = requestAnimationFrame(step);
    return () => cancelAnimationFrame(frame);
  }, [target.latitude, target.longitude]);
  return shown;
}

/**
 * Live en-route map: tinted, non-interactive. Follows the Pro when within range.
 */
export default function LiveEnRouteFollowMap({ customer, valeter, followValeter, showRoute = false, accent = '#38BDF8', edgePadding, tinted = true }: Props) {
  const mapRef = useRef<MapView>(null);
  const proCoord = useGlidingCoord(valeter);
  const route = useRoadRoute(showRoute ? valeter : null, showRoute ? customer : null);
  const padTop = edgePadding?.top ?? 140;
  const padBottom = edgePadding?.bottom ?? 320;
  const [mapReady, setMapReady] = useState(false);

  const fitRoute = useCallback(
    (animated: boolean) => {
      if (!route) return;
      mapRef.current?.fitToCoordinates([customer, valeter, ...route.coords], {
        edgePadding: { top: padTop + ROUTE_EDGE_V, bottom: padBottom + ROUTE_EDGE_V, left: ROUTE_EDGE_SIDE, right: ROUTE_EDGE_SIDE },
        animated,
      });
    },
    [route, customer, valeter, padTop, padBottom]
  );

  useEffect(() => {
    if (mapReady) fitRoute(true);
  }, [mapReady, fitRoute]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || showRoute) return;
    if (followValeter) {
      const region = regionForCoordinates([customer, valeter], 0.55);
      map.animateToRegion(region, MAP_CAMERA_ANIMATION_DURATION);
    } else {
      const region: Region = {
        latitude: customer.latitude,
        longitude: customer.longitude,
        latitudeDelta: MAP_ZOOM_DELTA * 2.2,
        longitudeDelta: MAP_ZOOM_DELTA * 2.2,
      };
      map.animateToRegion(region, MAP_CAMERA_ANIMATION_DURATION);
    }
  }, [customer.latitude, customer.longitude, valeter.latitude, valeter.longitude, followValeter, showRoute]);

  const initialRegion: Region = followValeter || showRoute
    ? regionForCoordinates([customer, valeter], 0.55)
    : {
        latitude: customer.latitude,
        longitude: customer.longitude,
        latitudeDelta: MAP_ZOOM_DELTA * 2.2,
        longitudeDelta: MAP_ZOOM_DELTA * 2.2,
      };

  return (
    <View style={StyleSheet.absoluteFill} onLayout={() => mapReady && fitRoute(true)}>
      <SafeMapView
        ref={mapRef}
        style={StyleSheet.absoluteFill}
        initialRegion={initialRegion}
        scrollEnabled={false}
        zoomEnabled={false}
        rotateEnabled={false}
        pitchEnabled={false}
        showsUserLocation={false}
        showsMyLocationButton={false}
        toolbarEnabled={false}
        customMapStyle={LOCATION_PICKER_MAP_STYLE}
        userInterfaceStyle={MAP_LOCKED_DARK}
        pointerEvents="none"
        onMapReady={() => setMapReady(true)}
      >
        {route ? (
          <>
            <Polyline coordinates={route.coords} strokeColor={`${ROUTE_LINE_COLOR}55`} strokeWidth={11} lineCap="round" lineJoin="round" zIndex={1} />
            <Polyline
              coordinates={route.coords}
              strokeColor={ROUTE_LINE_COLOR}
              strokeWidth={4.5}
              lineCap="round"
              lineJoin="round"
              zIndex={2}
              {...(route.onRoads ? {} : { lineDashPattern: [8, 8] })}
            />
          </>
        ) : null}
        <Marker coordinate={customer} anchor={{ x: 0.5, y: 0.5 }} tracksViewChanges={false}>
          <MapMarkerTopDownCar length={PIN_LENGTH} />
        </Marker>
        <Marker coordinate={proCoord} anchor={{ x: 0.5, y: 0.5 }} tracksViewChanges>
          <MapMarkerMascotDroplet size={MASCOT_SIZE} />
        </Marker>
      </SafeMapView>
      {tinted ? (
        <>
          <View pointerEvents="none" style={styles.tint} />
          <LinearGradient
            pointerEvents="none"
            colors={['rgba(2,6,23,0.1)', 'rgba(2,6,23,0.38)', 'rgba(2,6,23,0.55)']}
            locations={[0, 0.55, 1]}
            style={StyleSheet.absoluteFill}
          />
        </>
      ) : null}
      {route ? (
        <View pointerEvents="none" style={[styles.routeTagLayer, { top: padTop, bottom: padBottom }]}>
          <View style={[styles.routeTag, { borderColor: `${accent}88` }]}>
            <Text style={styles.routeTagMain}>{`${route.minutes} min`}</Text>
            <Text style={styles.routeTagSub}>{`${route.miles < 0.1 ? '<0.1' : route.miles.toFixed(1)} mi away`}</Text>
          </View>
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  routeTagLayer: { position: 'absolute', left: 0, right: 0, alignItems: 'center', justifyContent: 'center' },
  routeTag: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: 5,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 999,
    borderWidth: 1,
    backgroundColor: 'rgba(2,6,23,0.88)',
  },
  routeTagMain: { color: '#F8FAFC', fontSize: 16, fontWeight: '800', fontVariant: ['tabular-nums'] },
  routeTagSub: { color: 'rgba(226,232,240,0.75)', fontSize: 13, fontWeight: '700', fontVariant: ['tabular-nums'] },
  tint: {
    ...StyleSheet.absoluteFill,
    backgroundColor: 'rgba(15,23,42,0.26)',
  },
});
