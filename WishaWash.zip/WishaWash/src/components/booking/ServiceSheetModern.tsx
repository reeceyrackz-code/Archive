import { useEffect, useState } from 'react';
import { Image, Pressable, StyleSheet, Text, View, type ImageSourcePropType, type LayoutChangeEvent } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import GlyphIcon, { type GlyphName } from '../shared/GlyphIcon';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, {
  FadeIn,
  FadeInRight,
  ZoomIn,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from 'react-native-reanimated';
import HubGlassIcon from '../shared/HubGlassIcon';
import { hapticFeedback } from '../../services/HapticFeedbackService';


export type ServiceModeTab<T extends string> = {
  id: T;
  label: string;
  icon: GlyphName;
  accent: string;
};

const SEG_PAD = 4;

export function ServiceModeSegmented<T extends string>({
  tabs,
  value,
  onChange,
}: Readonly<{ tabs: readonly ServiceModeTab<T>[]; value: T; onChange: (id: T) => void }>) {
  const [trackW, setTrackW] = useState(0);
  const index = Math.max(0, tabs.findIndex((t) => t.id === value));
  const active = tabs[index] ?? tabs[0];
  const segW = trackW > 0 ? (trackW - SEG_PAD * 2) / tabs.length : 0;
  const x = useSharedValue(0);

  useEffect(() => {
    x.value = withSpring(index * segW, { damping: 18, stiffness: 220, mass: 0.8 });
  }, [index, segW, x]);

  const indicatorStyle = useAnimatedStyle(() => ({ transform: [{ translateX: x.value }] }));

  return (
    <View
      style={seg.track}
      onLayout={(e: LayoutChangeEvent) => setTrackW(e.nativeEvent.layout.width)}
      accessibilityRole="tablist"
    >
      {segW > 0 && active ? (
        <Animated.View style={[seg.indicator, { width: segW, shadowColor: active.accent }, indicatorStyle]}>
          <LinearGradient
            colors={['rgba(255,255,255,0.16)', 'rgba(255,255,255,0.06)']}
            start={{ x: 0, y: 0 }}
            end={{ x: 0, y: 1 }}
            style={StyleSheet.absoluteFill}
          />
          <View style={[seg.indicatorTint, { backgroundColor: active.accent }]} />
        </Animated.View>
      ) : null}
      {tabs.map((tab) => {
        const isActive = tab.id === value;
        return (
          <Pressable
            key={tab.id}
            style={seg.tab}
            onPress={() => {
              if (isActive) return;
              void hapticFeedback('light');
              onChange(tab.id);
            }}
            accessibilityRole="tab"
            accessibilityState={{ selected: isActive }}
            accessibilityLabel={tab.label}
          >
            <View style={[seg.iconDot, isActive && { backgroundColor: tab.accent }]}>
              <GlyphIcon
                name={isActive && !tab.icon.startsWith('mci:') ? (tab.icon.replace('-outline', '') as GlyphName) : tab.icon}
                size={13}
                color={isActive ? '#0B1220' : 'rgba(148,163,184,0.8)'}
              />
            </View>
            <Text style={[seg.label, isActive && seg.labelActive]} numberOfLines={1}>
              {tab.label}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}

export type ServiceCardData = {
  id: string;
  name: string;
  dur: string;
  colors: [string, string];
  badge?: string;
};

export function ServiceOptionCard({
  service,
  index,
  width,
  height,
  subtitle,
  icon,
  image,
  selected,
  addOnsCount,
  onPress,
  onInfo,
  onAddOns,
}: Readonly<{
  service: ServiceCardData;
  index: number;
  width: number;
  height: number;
  subtitle: string;
  icon: GlyphName;
  image?: ImageSourcePropType | null;
  selected: boolean;
  addOnsCount: number;
  onPress: () => void;
  onInfo: () => void;
  onAddOns: () => void;
}>) {
  const accent = service.colors[0];
  const scale = useSharedValue(1);
  const lift = useSharedValue(selected ? 1 : 0);

  useEffect(() => {
    lift.value = withSpring(selected ? 1 : 0, { damping: 16, stiffness: 200 });
  }, [selected, lift]);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }, { translateY: -3 * lift.value }],
    shadowOpacity: 0.18 + 0.32 * lift.value,
  }));

  return (
    <Animated.View entering={FadeInRight.delay(Math.min(index, 5) * 60).springify().damping(17)}>
      <Pressable
        onPress={onPress}
        onPressIn={() => {
          scale.value = withSpring(0.96, { damping: 18, stiffness: 320 });
        }}
        onPressOut={() => {
          scale.value = withSpring(1, { damping: 14, stiffness: 260 });
        }}
        accessibilityRole="button"
        accessibilityState={{ selected }}
        accessibilityLabel={`${service.name}, ${service.dur}`}
      >
        <Animated.View style={[card.shell, { width, height, shadowColor: selected ? accent : '#000' }, animatedStyle]}>
          <LinearGradient
            colors={selected ? [`${accent}3D`, 'rgba(15,23,42,0.92)'] : ['rgba(30,41,59,0.78)', 'rgba(15,23,42,0.9)']}
            start={{ x: 0, y: 0 }}
            end={{ x: 0.9, y: 1 }}
            style={StyleSheet.absoluteFill}
          />
          <View style={[card.glow, { backgroundColor: accent, opacity: selected ? 0.32 : 0.14 }]} />
          <LinearGradient
            colors={['rgba(255,255,255,0.10)', 'rgba(255,255,255,0)']}
            start={{ x: 0, y: 0 }}
            end={{ x: 0, y: 0.5 }}
            style={card.sheen}
            pointerEvents="none"
          />

          <View style={card.topRow}>
            {image ? (
              <Image source={image} style={card.leadImage} resizeMode="cover" />
            ) : (
              <HubGlassIcon icon={icon} accent={accent} size={44} iconSize={20} glow={selected} />
            )}
            <View style={card.titleCol}>
              <View style={card.nameRow}>
                <Text style={card.name} numberOfLines={1}>
                  {service.name}
                </Text>
                {service.badge ? (
                  <View style={[card.badge, { backgroundColor: `${accent}26` }]}>
                    <Text style={[card.badgeText, { color: accent }]} numberOfLines={1}>
                      {service.badge}
                    </Text>
                  </View>
                ) : null}
              </View>
              {subtitle ? (
                <Text style={card.subtitle} numberOfLines={2}>
                  {subtitle}
                </Text>
              ) : null}
            </View>
          </View>

          <View style={card.footer}>
            <View style={[card.chip, { backgroundColor: `${accent}1F` }]}>
              <Ionicons name="time" size={12} color={accent} />
              <Text style={[card.chipText, { color: accent }]} numberOfLines={1}>
                {service.dur}
              </Text>
            </View>
            <View style={card.chip}>
              <Ionicons name="pricetag" size={11} color="rgba(203,213,225,0.8)" />
              <Text style={card.chipText} numberOfLines={1}>
                Prices vary
              </Text>
            </View>
            {selected && addOnsCount > 0 ? (
              <Animated.View entering={ZoomIn.springify().damping(14)}>
                <Pressable
                  onPress={onAddOns}
                  hitSlop={8}
                  style={[card.chip, { backgroundColor: `${accent}2E` }]}
                  accessibilityRole="button"
                  accessibilityLabel={`${addOnsCount} add-on${addOnsCount === 1 ? '' : 's'} selected`}
                >
                  <Ionicons name="add-circle" size={12} color={accent} />
                  <Text style={[card.chipText, { color: accent }]}>{addOnsCount}</Text>
                </Pressable>
              </Animated.View>
            ) : null}
            <View style={card.flex} />
            <Pressable
              onPress={onInfo}
              hitSlop={10}
              style={card.infoBtn}
              accessibilityRole="button"
              accessibilityLabel={`${service.name} details`}
            >
              <Ionicons name="information" size={15} color="rgba(226,232,240,0.9)" />
            </Pressable>
          </View>

          {selected ? (
            <Animated.View entering={ZoomIn.springify().damping(12)} style={[card.check, { backgroundColor: accent }]}>
              <Ionicons name="checkmark" size={13} color="#0B1220" />
            </Animated.View>
          ) : null}
        </Animated.View>
      </Pressable>
    </Animated.View>
  );
}

export function ServicePagerDots({
  count,
  activeIndex,
  accent,
}: Readonly<{ count: number; activeIndex: number; accent: string }>) {
  if (count < 2) return null;
  return (
    <View style={dots.row} pointerEvents="none">
      {Array.from({ length: count }, (_, i) => (
        <View
          key={i}
          style={[dots.dot, i === activeIndex ? { width: 16, backgroundColor: accent } : null]}
        />
      ))}
    </View>
  );
}

export function ServiceSheetCta({
  accent,
  ready,
  title,
  subtitle,
  vehicleCount,
  onPress,
  onVehiclesPress,
}: Readonly<{
  accent: string;
  ready: boolean;
  title: string;
  subtitle: string;
  vehicleCount: number;
  onPress: () => void;
  onVehiclesPress: () => void;
}>) {
  const scale = useSharedValue(1);
  const pressStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));

  return (
    <View style={cta.row}>
      <Pressable
        onPress={() => {
          void hapticFeedback('light');
          onVehiclesPress();
        }}
        style={({ pressed }) => [cta.vehicle, pressed && cta.vehiclePressed]}
        accessibilityRole="button"
        accessibilityLabel={`${vehicleCount} vehicle${vehicleCount === 1 ? '' : 's'} selected. Tap to change.`}
      >
        <View style={[cta.vehicleIcon, { backgroundColor: `${accent}26` }]}>
          <Ionicons name="car-sport" size={15} color={accent} />
        </View>
        <Text style={cta.vehicleCountText}>{vehicleCount}</Text>
      </Pressable>
      <Pressable
        style={cta.flex}
        disabled={!ready}
        onPress={() => {
          void hapticFeedback('medium');
          onPress();
        }}
        onPressIn={() => {
          scale.value = withSpring(0.97, { damping: 18, stiffness: 320 });
        }}
        onPressOut={() => {
          scale.value = withSpring(1, { damping: 14, stiffness: 260 });
        }}
        accessibilityRole="button"
        accessibilityState={{ disabled: !ready }}
        accessibilityLabel={title}
      >
        <Animated.View style={[cta.main, ready ? { shadowColor: accent } : cta.mainIdle, pressStyle]}>
          {ready ? (
            <Animated.View entering={FadeIn.duration(240)} style={StyleSheet.absoluteFill}>
              <LinearGradient
                colors={[accent, `${accent}D9`]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={StyleSheet.absoluteFill}
              />
              <LinearGradient
                colors={['rgba(255,255,255,0.3)', 'rgba(255,255,255,0)']}
                start={{ x: 0, y: 0 }}
                end={{ x: 0, y: 0.75 }}
                style={cta.sheen}
                pointerEvents="none"
              />
            </Animated.View>
          ) : null}
          <View style={cta.textCol}>
            <Text style={[cta.title, !ready && cta.titleIdle]} numberOfLines={1}>
              {title}
            </Text>
            <Animated.Text
              key={subtitle}
              entering={FadeIn.duration(220)}
              style={[cta.subtitle, !ready && cta.subtitleIdle]}
              numberOfLines={1}
            >
              {subtitle}
            </Animated.Text>
          </View>
          <View style={[cta.arrow, !ready && cta.arrowIdle]}>
            <Ionicons
              name={ready ? 'arrow-forward' : 'hand-left-outline'}
              size={ready ? 17 : 15}
              color={ready ? '#F8FAFC' : 'rgba(148,163,184,0.9)'}
            />
          </View>
        </Animated.View>
      </Pressable>
    </View>
  );
}

const seg = StyleSheet.create({
  track: {
    flexDirection: 'row',
    padding: SEG_PAD,
    borderRadius: 999,
    backgroundColor: 'rgba(2,6,23,0.35)',
    marginHorizontal: 16,
    marginTop: 4,
  },
  indicator: {
    position: 'absolute',
    top: SEG_PAD,
    bottom: SEG_PAD,
    left: SEG_PAD,
    borderRadius: 999,
    overflow: 'hidden',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.35,
    shadowRadius: 10,
  },
  indicatorTint: {
    ...StyleSheet.absoluteFill,
    opacity: 0.1,
  },
  tab: {
    flex: 1,
    height: 36,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 7,
  },
  iconDot: {
    width: 22,
    height: 22,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  label: {
    color: 'rgba(148,163,184,0.85)',
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 0.1,
  },
  labelActive: {
    color: '#F8FAFC',
  },
});

const card = StyleSheet.create({
  leadImage: {
    width: 44,
    height: 44,
    borderRadius: 14,
  },
  shell: {
    borderRadius: 22,
    overflow: 'hidden',
    padding: 14,
    justifyContent: 'space-between',
    shadowOffset: { width: 0, height: 8 },
    shadowRadius: 16,
    elevation: 6,
  },
  glow: {
    position: 'absolute',
    top: -50,
    left: -40,
    width: 150,
    height: 150,
    borderRadius: 75,
  },
  sheen: {
    ...StyleSheet.absoluteFill,
  },
  topRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingRight: 18,
  },
  titleCol: {
    flex: 1,
    minWidth: 0,
    gap: 3,
  },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  name: {
    flexShrink: 1,
    color: '#F8FAFC',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.1,
  },
  badge: {
    paddingHorizontal: 7,
    paddingVertical: 2,
    borderRadius: 8,
    flexShrink: 0,
  },
  badgeText: {
    fontSize: 9.5,
    fontWeight: '800',
    letterSpacing: 0.4,
    textTransform: 'uppercase',
  },
  subtitle: {
    color: 'rgba(203,213,225,0.78)',
    fontSize: 12.5,
    lineHeight: 16,
  },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    height: 24,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.07)',
  },
  chipText: {
    color: 'rgba(226,232,240,0.85)',
    fontSize: 11.5,
    fontWeight: '700',
  },
  flex: { flex: 1 },
  infoBtn: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.09)',
  },
  check: {
    position: 'absolute',
    top: 12,
    right: 12,
    width: 22,
    height: 22,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center',
  },
});

const dots = StyleSheet.create({
  row: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 5,
    marginTop: 2,
    marginBottom: 2,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: 'rgba(148,163,184,0.35)',
  },
});

const cta = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 16,
    paddingTop: 8,
  },
  flex: { flex: 1 },
  main: {
    height: 54,
    borderRadius: 27,
    overflow: 'hidden',
    flexDirection: 'row',
    alignItems: 'center',
    paddingLeft: 20,
    paddingRight: 7,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.38,
    shadowRadius: 14,
    elevation: 6,
  },
  mainIdle: {
    backgroundColor: 'rgba(2,6,23,0.35)',
    shadowOpacity: 0,
    elevation: 0,
  },
  sheen: {
    ...StyleSheet.absoluteFill,
  },
  textCol: {
    flex: 1,
    minWidth: 0,
  },
  title: {
    color: '#0B1220',
    fontSize: 15,
    fontWeight: '800',
    letterSpacing: -0.1,
  },
  titleIdle: { color: 'rgba(226,232,240,0.88)' },
  subtitle: {
    color: 'rgba(11,18,32,0.68)',
    fontSize: 11.5,
    fontWeight: '600',
    marginTop: 1,
  },
  subtitleIdle: { color: 'rgba(148,163,184,0.85)' },
  arrow: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(11,18,32,0.88)',
  },
  arrowIdle: { backgroundColor: 'rgba(255,255,255,0.06)' },
  vehicle: {
    height: 54,
    borderRadius: 27,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    paddingLeft: 7,
    paddingRight: 14,
    backgroundColor: 'rgba(2,6,23,0.35)',
  },
  vehiclePressed: { opacity: 0.75 },
  vehicleIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  vehicleCountText: {
    color: '#F8FAFC',
    fontSize: 14,
    fontWeight: '800',
  },
});
