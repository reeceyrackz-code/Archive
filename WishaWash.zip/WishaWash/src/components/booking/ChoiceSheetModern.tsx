import { useEffect } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, {
  FadeIn,
  FadeInDown,
  LinearTransition,
  ZoomIn,
  ZoomOut,
  interpolateColor,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import GlyphIcon, { type GlyphName } from '../shared/GlyphIcon';
import { hapticFeedback } from '../../services/HapticFeedbackService';

type IconName = keyof typeof Ionicons.glyphMap;

const GLASS = 'rgba(2,6,23,0.35)';
const IDLE_ICON_BG = 'rgba(255,255,255,0.06)';
const IDLE_ICON = 'rgba(148,163,184,0.85)';
const INK = '#0B1220';

function usePressSpring(pressed = 0.96) {
  const scale = useSharedValue(1);
  const style = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  return {
    style,
    onPressIn: () => {
      scale.value = withSpring(pressed, { damping: 18, stiffness: 320 });
    },
    onPressOut: () => {
      scale.value = withSpring(1, { damping: 13, stiffness: 260 });
    },
  };
}

/** Round icon dot — filled with the accent when active, muted glass when idle (matches the service mode tabs). */
function IconDot({ icon, accent, active, size }: Readonly<{ icon: GlyphName; accent: string; active: boolean; size: number }>) {
  return (
    <View
      style={[
        dot.base,
        { width: size, height: size, borderRadius: size / 2, backgroundColor: active ? accent : IDLE_ICON_BG },
      ]}
    >
      <GlyphIcon name={icon} size={Math.round(size * 0.46)} color={active ? INK : IDLE_ICON} />
    </View>
  );
}

/** Frosted selected fill with a faint accent tint — same as the active service mode tab. */
function SelectedFill({ accent }: Readonly<{ accent: string }>) {
  return (
    <>
      <LinearGradient
        colors={['rgba(255,255,255,0.14)', 'rgba(255,255,255,0.05)']}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <View style={[StyleSheet.absoluteFill, { backgroundColor: accent, opacity: 0.1 }]} pointerEvents="none" />
    </>
  );
}

/** Compact sheet header: accent icon dot, eyebrow, title, subtitle. */
export function ChoiceSheetHeader({
  accent,
  icon,
  eyebrow,
  title,
  subtitle,
}: Readonly<{ accent: string; icon: IconName; eyebrow?: string; title: string; subtitle?: string }>) {
  return (
    <Animated.View entering={FadeInDown.springify().damping(18)} style={head.row}>
      <IconDot icon={icon} accent={accent} active size={40} />
      <View style={head.textCol}>
        {eyebrow ? (
          <Text style={[head.eyebrow, { color: accent }]} numberOfLines={1}>
            {eyebrow}
          </Text>
        ) : null}
        <Text style={head.title} numberOfLines={1}>
          {title}
        </Text>
        {subtitle ? (
          <Text style={head.subtitle} numberOfLines={2}>
            {subtitle}
          </Text>
        ) : null}
      </View>
    </Animated.View>
  );
}

export type WashTypeOption<T extends string> = Readonly<{
  id: T;
  icon: GlyphName;
  title: string;
  meta: string;
  perks: readonly string[];
  price?: string;
}>;

function WashTypeCard<T extends string>({
  option,
  accent,
  selected,
  index,
  onSelect,
}: Readonly<{ option: WashTypeOption<T>; accent: string; selected: boolean; index: number; onSelect: (id: T) => void }>) {
  const press = usePressSpring(0.97);

  return (
    <Animated.View entering={FadeInDown.delay(80 + index * 70).springify().damping(17)} style={press.style}>
      <Pressable
        onPress={() => {
          void hapticFeedback('medium');
          onSelect(option.id);
        }}
        onPressIn={press.onPressIn}
        onPressOut={press.onPressOut}
        accessibilityRole="button"
        accessibilityState={{ selected }}
        accessibilityLabel={`${option.title}. ${option.meta}`}
      >
        <View style={[choice.card, selected && { shadowColor: accent, shadowOpacity: 0.35 }]}>
          {selected ? <SelectedFill accent={accent} /> : null}
          <View style={choice.body}>
            <IconDot icon={option.icon} accent={accent} active={selected} size={44} />
            <View style={choice.textCol}>
              <View style={choice.titleRow}>
                <Text style={[choice.title, !selected && choice.titleIdle]}>{option.title}</Text>
                {option.price ? (
                  <View style={[choice.pricePill, { backgroundColor: `${accent}24` }]}>
                    <Text style={[choice.priceText, { color: accent }]}>{option.price}</Text>
                  </View>
                ) : null}
              </View>
              <Text style={choice.meta} numberOfLines={1}>
                {option.meta}
              </Text>
              <View style={choice.perks}>
                {option.perks.map((perk) => (
                  <View key={perk} style={choice.perkRow}>
                    <View style={[choice.perkDot, { backgroundColor: selected ? accent : 'rgba(148,163,184,0.6)' }]} />
                    <Text style={choice.perkText} numberOfLines={1}>
                      {perk}
                    </Text>
                  </View>
                ))}
              </View>
            </View>
            {selected ? (
              <Animated.View entering={ZoomIn.springify().damping(12)} exiting={ZoomOut.duration(120)}>
                <View style={[choice.check, { backgroundColor: accent }]}>
                  <Ionicons name="checkmark" size={13} color={INK} />
                </View>
              </Animated.View>
            ) : (
              <View style={choice.radio} />
            )}
          </View>
        </View>
      </Pressable>
    </Animated.View>
  );
}

/** Stacked full-width choice cards (e.g. Exterior / Interior). */
export function WashTypeChoiceCards<T extends string>({
  accent,
  options,
  value,
  onSelect,
}: Readonly<{ accent: string; options: readonly WashTypeOption<T>[]; value: T | null | undefined; onSelect: (id: T) => void }>) {
  return (
    <View style={choice.row}>
      {options.map((option, i) => (
        <WashTypeCard
          key={option.id}
          option={option}
          accent={accent}
          selected={value === option.id}
          index={i}
          onSelect={onSelect}
        />
      ))}
    </View>
  );
}

/** Add-on row that toggles on tap; the price pill morphs into a tick when added. */
export function AddOnToggleRow({
  accent,
  icon,
  title,
  desc,
  price,
  selected,
  index,
  onPress,
}: Readonly<{
  accent: string;
  icon: GlyphName;
  title: string;
  desc?: string;
  price: string;
  selected: boolean;
  index: number;
  onPress: () => void;
}>) {
  const press = usePressSpring(0.97);
  const on = useSharedValue(selected ? 1 : 0);

  useEffect(() => {
    on.value = withTiming(selected ? 1 : 0, { duration: 220 });
  }, [selected, on]);

  const bgStyle = useAnimatedStyle(() => ({
    backgroundColor: interpolateColor(on.value, [0, 1], [GLASS, `${accent}1F`]),
  }));
  const pillStyle = useAnimatedStyle(() => ({
    backgroundColor: interpolateColor(on.value, [0, 1], ['rgba(255,255,255,0.06)', accent]),
  }));

  return (
    <Animated.View
      entering={FadeInDown.delay(60 + Math.min(index, 8) * 45).springify().damping(18)}
      layout={LinearTransition.springify().damping(18)}
      style={press.style}
    >
      <Pressable
        onPress={() => {
          void hapticFeedback(selected ? 'light' : 'medium');
          onPress();
        }}
        onPressIn={press.onPressIn}
        onPressOut={press.onPressOut}
        accessibilityRole="checkbox"
        accessibilityState={{ checked: selected }}
        accessibilityLabel={`${title}, ${price}`}
      >
        <Animated.View style={[addOn.row, bgStyle]}>
          <IconDot icon={icon} accent={accent} active={selected} size={38} />
          <View style={addOn.textCol}>
            <Text style={[addOn.title, !selected && addOn.titleIdle]} numberOfLines={1}>
              {title}
            </Text>
            {desc ? (
              <Text style={addOn.desc} numberOfLines={2}>
                {desc}
              </Text>
            ) : null}
          </View>
          <Animated.View style={[addOn.pill, pillStyle]}>
            {selected ? (
              <Animated.View key="on" entering={ZoomIn.springify().damping(12)} style={addOn.pillInner}>
                <Ionicons name="checkmark" size={13} color={INK} />
                <Text style={[addOn.pillText, { color: INK }]}>Added</Text>
              </Animated.View>
            ) : (
              <Animated.View key="off" entering={FadeIn.duration(160)} style={addOn.pillInner}>
                <Ionicons name="add" size={13} color={accent} />
                <Text style={[addOn.pillText, { color: '#F8FAFC' }]}>{price}</Text>
              </Animated.View>
            )}
          </Animated.View>
        </Animated.View>
      </Pressable>
    </Animated.View>
  );
}

/** Footer with running total and a primary pill (dark glass when nothing is added). */
export function AddOnsSummaryBar({
  accent,
  count,
  total,
  onDone,
}: Readonly<{ accent: string; count: number; total: string; onDone: () => void }>) {
  const press = usePressSpring(0.97);
  const hasAny = count > 0;

  return (
    <View style={bar.row}>
      {hasAny ? (
        <Animated.View entering={FadeIn.duration(200)} style={bar.totalPill}>
          <Text style={bar.totalLabel}>
            {count} add-on{count === 1 ? '' : 's'}
          </Text>
          <Animated.Text key={total} entering={FadeInDown.duration(200)} style={bar.totalValue}>
            +{total}
          </Animated.Text>
        </Animated.View>
      ) : null}
      <Animated.View style={[bar.btnWrap, hasAny && { shadowColor: accent, shadowOpacity: 0.38 }, press.style]}>
        <Pressable
          onPress={() => {
            void hapticFeedback(hasAny ? 'medium' : 'light');
            onDone();
          }}
          onPressIn={press.onPressIn}
          onPressOut={press.onPressOut}
          accessibilityRole="button"
          accessibilityLabel={hasAny ? 'Done' : 'Not today thanks'}
        >
          <View style={[bar.btn, !hasAny && bar.btnGhost]}>
            {hasAny ? (
              <Animated.View entering={FadeIn.duration(220)} style={StyleSheet.absoluteFill}>
                <LinearGradient
                  colors={[accent, `${accent}D9`]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={StyleSheet.absoluteFill}
                />
                <LinearGradient
                  colors={['rgba(255,255,255,0.3)', 'rgba(255,255,255,0)']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 0, y: 0.75 }}
                  style={StyleSheet.absoluteFill}
                  pointerEvents="none"
                />
              </Animated.View>
            ) : null}
            <Text style={[bar.btnText, !hasAny && bar.btnTextIdle]} numberOfLines={1}>
              {hasAny ? 'Done' : 'Not today thanks'}
            </Text>
            <View style={[bar.btnIcon, !hasAny && bar.btnIconIdle]}>
              <Ionicons
                name={hasAny ? 'checkmark' : 'close'}
                size={hasAny ? 17 : 15}
                color={hasAny ? '#F8FAFC' : 'rgba(148,163,184,0.9)'}
              />
            </View>
          </View>
        </Pressable>
      </Animated.View>
    </View>
  );
}

const dot = StyleSheet.create({
  base: { alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
});

const head = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 14 },
  textCol: { flex: 1, minWidth: 0, gap: 1 },
  eyebrow: { fontSize: 10.5, fontWeight: '800', letterSpacing: 0.8, textTransform: 'uppercase' },
  title: { color: '#F8FAFC', fontSize: 17, fontWeight: '800', letterSpacing: -0.2 },
  subtitle: { color: 'rgba(203,213,225,0.8)', fontSize: 12.5, fontWeight: '500', lineHeight: 17 },
});

const choice = StyleSheet.create({
  row: { gap: 10, paddingTop: 2, paddingBottom: 8 },
  card: {
    borderRadius: 24,
    overflow: 'hidden',
    padding: 14,
    backgroundColor: GLASS,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0,
    shadowRadius: 12,
  },
  body: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  textCol: { flex: 1, minWidth: 0 },
  titleRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  check: { width: 22, height: 22, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  radio: { width: 22, height: 22, borderRadius: 11, backgroundColor: 'rgba(255,255,255,0.06)' },
  title: { color: '#F8FAFC', fontSize: 15, fontWeight: '800', letterSpacing: -0.1 },
  titleIdle: { color: 'rgba(226,232,240,0.9)' },
  meta: { color: 'rgba(148,163,184,0.9)', fontSize: 12, fontWeight: '600', marginTop: 1 },
  perks: { gap: 4, marginTop: 8 },
  perkRow: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  perkDot: { width: 5, height: 5, borderRadius: 3 },
  perkText: { flex: 1, color: 'rgba(226,232,240,0.88)', fontSize: 12, fontWeight: '600' },
  pricePill: { height: 22, paddingHorizontal: 9, borderRadius: 11, justifyContent: 'center' },
  priceText: { fontSize: 12, fontWeight: '800' },
});

const addOn = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 10,
    paddingLeft: 10,
    paddingRight: 10,
    borderRadius: 22,
    marginBottom: 8,
  },
  textCol: { flex: 1, minWidth: 0, gap: 2 },
  title: { color: '#F8FAFC', fontSize: 14, fontWeight: '700', letterSpacing: -0.1 },
  titleIdle: { color: 'rgba(226,232,240,0.92)' },
  desc: { color: 'rgba(148,163,184,0.9)', fontSize: 11.5, lineHeight: 15 },
  pill: { height: 30, borderRadius: 15, paddingHorizontal: 11, justifyContent: 'center', minWidth: 72 },
  pillInner: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 3 },
  pillText: { fontSize: 12.5, fontWeight: '800' },
});

const bar = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingTop: 8 },
  totalPill: {
    height: 54,
    borderRadius: 27,
    paddingHorizontal: 16,
    justifyContent: 'center',
    backgroundColor: GLASS,
  },
  totalLabel: { color: 'rgba(148,163,184,0.9)', fontSize: 11, fontWeight: '700' },
  totalValue: { color: '#F8FAFC', fontSize: 16, fontWeight: '800', letterSpacing: -0.2 },
  btnWrap: {
    flex: 1,
    borderRadius: 27,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0,
    shadowRadius: 14,
    elevation: 6,
  },
  btn: {
    height: 54,
    borderRadius: 27,
    overflow: 'hidden',
    flexDirection: 'row',
    alignItems: 'center',
    paddingLeft: 20,
    paddingRight: 7,
  },
  btnGhost: { backgroundColor: GLASS },
  btnText: { flex: 1, color: INK, fontSize: 15, fontWeight: '800', letterSpacing: -0.1 },
  btnTextIdle: { color: 'rgba(226,232,240,0.88)', fontWeight: '700' },
  btnIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(11,18,32,0.88)',
  },
  btnIconIdle: { backgroundColor: 'rgba(255,255,255,0.06)' },
});
