import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import Animated, { FadeIn, ZoomIn } from 'react-native-reanimated';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useMapChromeColors } from '../../hooks/useMapChromeColors';

const VERIFIED_GREEN = '#34D399';

/** Pro photo tile for the floating tracking header (same footprint as the dashboard profile tile). */
export function TrackingProAvatar({
  photoUrl,
  accent,
  onPress,
}: Readonly<{ photoUrl: string | null; accent: string; onPress?: () => void }>) {
  return (
    <Pressable
      disabled={!onPress}
      {...(onPress ? { onPress } : {})}
      hitSlop={6}
      accessibilityRole="button"
      accessibilityLabel="View Pro profile"
      style={({ pressed }) => pressed && styles.pressed}
    >
      <Animated.View entering={ZoomIn.springify().damping(16)} style={[styles.avatar, { borderColor: accent }]}>
        {photoUrl ? (
          <Image source={{ uri: photoUrl }} style={styles.avatarImage} resizeMode="cover" />
        ) : (
          <View style={[styles.avatarFallback, { backgroundColor: `${accent}33` }]}>
            <Ionicons name="person" size={20} color="#E0F2FE" />
          </View>
        )}
      </Animated.View>
    </Pressable>
  );
}

/** Glass name pill — mirrors the dashboard greeting pill (small meta line above the name). */
export function TrackingProNamePill({
  name,
  rating,
  jobs,
}: Readonly<{ name: string; rating: number; jobs: number }>) {
  const chrome = useMapChromeColors();
  return (
    <Animated.View
      entering={FadeIn.duration(320)}
      style={[styles.pill, { borderColor: chrome.border, shadowColor: chrome.shadow }]}
    >
      <BlurView intensity={28} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
      <LinearGradient
        colors={[...chrome.gradient]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <LinearGradient
        colors={['rgba(255,255,255,0.14)', 'transparent']}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={styles.sheen}
        pointerEvents="none"
      />
      <View style={styles.pillInner}>
        <View style={styles.metaRow}>
          {rating > 0 ? (
            <>
              <Ionicons name="star" size={10} color="#FBBF24" />
              <Text style={styles.meta}>{rating.toFixed(1)}</Text>
              <Text style={styles.metaDot}>·</Text>
            </>
          ) : null}
          <Text style={styles.meta} numberOfLines={1}>
            {jobs > 0 ? `${jobs} jobs` : 'Your Pro'}
          </Text>
        </View>
        <Text style={styles.name} numberOfLines={1}>
          {name}
        </Text>
      </View>
    </Animated.View>
  );
}

/** Floating glass tile with the green verified shield. */
export function TrackingProVerifiedBadge() {
  const chrome = useMapChromeColors();
  return (
    <Animated.View
      entering={ZoomIn.delay(120).springify().damping(14)}
      style={[styles.badge, { borderColor: chrome.border, shadowColor: chrome.shadow }]}
      accessibilityLabel="Verified Pro"
    >
      <BlurView intensity={28} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
      <LinearGradient
        colors={['rgba(52,211,153,0.28)', 'rgba(16,185,129,0.08)']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <Ionicons name="shield-checkmark" size={19} color={VERIFIED_GREEN} />
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 13,
    overflow: 'hidden',
    borderWidth: 1,
    flexShrink: 0,
  },
  pressed: { opacity: 0.8, transform: [{ scale: 0.96 }] },
  avatarImage: { width: '100%', height: '100%' },
  avatarFallback: { flex: 1, alignItems: 'center', justifyContent: 'center' },

  pill: {
    flex: 1,
    minHeight: 48,
    borderRadius: 22,
    overflow: 'hidden',
    borderWidth: 1,
    backgroundColor: 'rgba(8,20,38,0.55)',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.35,
    shadowRadius: 10,
    elevation: 8,
  },
  sheen: { ...StyleSheet.absoluteFill, opacity: 0.85 },
  pillInner: { flex: 1, justifyContent: 'center', gap: 1, paddingHorizontal: 14, paddingVertical: 6 },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  meta: { color: 'rgba(226,232,240,0.8)', fontSize: 11, fontWeight: '700' },
  metaDot: { color: 'rgba(226,232,240,0.6)', fontSize: 11 },
  name: { color: '#F9FAFB', fontSize: 16, fontWeight: '800', letterSpacing: -0.2 },

  badge: {
    width: 44,
    height: 44,
    borderRadius: 22,
    overflow: 'hidden',
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(8,20,38,0.55)',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.35,
    shadowRadius: 10,
    elevation: 8,
  },
});
