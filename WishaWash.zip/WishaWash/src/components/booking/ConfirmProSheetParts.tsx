import { useState, type ReactNode } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { FadeIn, FadeInDown, css, useAnimatedStyle, useSharedValue, withSpring } from 'react-native-reanimated';
import HubGlassIcon from '../shared/HubGlassIcon';
import { hapticFeedback } from '../../services/HapticFeedbackService';

const livePulse = css.keyframes({
  '0%': { transform: [{ scale: 1 }], opacity: 0.7 },
  '100%': { transform: [{ scale: 2.4 }], opacity: 0 },
});

/** "Pick your pro" row above the cards with a pulsing live count. */
export function ConfirmProSheetHeader({
  accent,
  title,
  liveLabel,
}: Readonly<{ accent: string; title: string; liveLabel: string }>) {
  return (
    <Animated.View entering={FadeInDown.springify().damping(18)} style={head.row}>
      <HubGlassIcon icon="people" accent={accent} size={36} iconSize={17} />
      <Text style={head.title} numberOfLines={1}>
        {title}
      </Text>
      <View style={[head.live, { backgroundColor: `${accent}1F` }]}>
        <View style={head.dotWrap}>
          <Animated.View
            style={[
              head.dotPulse,
              { backgroundColor: '#34D399' },
              {
                animationName: livePulse,
                animationDuration: '1600ms',
                animationIterationCount: 'infinite',
                animationTimingFunction: 'ease-out',
              },
            ]}
          />
          <View style={[head.dot, { backgroundColor: '#34D399' }]} />
        </View>
        <Text style={[head.liveText, { color: accent }]} numberOfLines={1}>
          {liveLabel}
        </Text>
      </View>
    </Animated.View>
  );
}

/** Minimal note field: a one-line pill until tapped, then it opens into a multi-line input; actions show while editing. */
export function ProNoteCard({
  accent,
  value,
  maxLength,
  typing,
  placeholder,
  onChangeText,
  onFocus,
  onBlur,
  onDone,
  footer,
}: Readonly<{
  accent: string;
  value: string;
  maxLength: number;
  typing: boolean;
  placeholder: string;
  onChangeText: (text: string) => void;
  onFocus: () => void;
  onBlur: () => void;
  onDone: () => void;
  footer?: ReactNode;
}>) {
  const hasValue = value.trim().length > 0;
  const [editing, setEditing] = useState(false);
  const open = editing || typing;

  const startEditing = () => {
    void hapticFeedback('light');
    setEditing(true);
  };

  if (!open) {
    return (
      <Pressable
        onPress={startEditing}
        hitSlop={10}
        style={({ pressed }) => [note.trigger, pressed && { opacity: 0.7 }]}
        accessibilityRole="button"
        accessibilityLabel={hasValue ? `Note for your pro: ${value}. Tap to edit` : 'Add a note for your pro (optional)'}
      >
        <Ionicons name={hasValue ? 'create' : 'create-outline'} size={14} color={hasValue ? accent : 'rgba(148,163,184,0.9)'} />
        <Text style={[note.triggerText, hasValue && { color: accent }]}>{hasValue ? 'Note added' : 'Add note'}</Text>
        {hasValue ? <Text style={note.triggerHint}>· Edit</Text> : null}
      </Pressable>
    );
  }

  return (
    <Animated.View entering={FadeIn.duration(160)}>
      <View style={[note.pill, note.pillTyping]}>
        <Ionicons name="create" size={16} color={accent} style={note.iconTyping} />
        <TextInput
          value={value}
          onChangeText={onChangeText}
          onFocus={onFocus}
          onBlur={() => {
            setEditing(false);
            onBlur();
          }}
          autoFocus
          placeholder={placeholder}
          placeholderTextColor="rgba(148,163,184,0.75)"
          multiline
          maxLength={maxLength}
          textAlignVertical="top"
          style={[note.input, note.inputTyping]}
          returnKeyType="default"
          accessibilityLabel="Note for your pro (optional)"
        />
        <Pressable onPress={onDone} hitSlop={10} style={[note.doneBtn, { backgroundColor: accent }]}>
          <Text style={note.doneText}>Done</Text>
        </Pressable>
      </View>
      <View style={note.footer}>
        {footer}
        <Text style={note.counter}>
          {value.length}/{maxLength}
        </Text>
      </View>
    </Animated.View>
  );
}

/** Text-style action used under the note field (save / use saved / remove). */
export function NoteChip({
  icon,
  label,
  color,
  onPress,
  disabled,
}: Readonly<{ icon: keyof typeof Ionicons.glyphMap; label: string; color: string; onPress?: () => void; disabled?: boolean }>) {
  const content = (
    <>
      <Ionicons name={icon} size={12} color={color} />
      <Text style={[note.chipText, { color }]} numberOfLines={1}>
        {label}
      </Text>
    </>
  );
  if (!onPress) return <View style={note.chip}>{content}</View>;
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      hitSlop={8}
      style={({ pressed }) => [note.chip, (pressed || disabled) && { opacity: 0.6 }]}
    >
      {content}
    </Pressable>
  );
}

/** Request pill showing the selected pro + price/ETA — same style as the service sheet continue button. */
export function RequestProCta({
  accent,
  title,
  subtitle,
  disabled,
  loading,
  onPress,
  idleIcon = 'hand-left-outline',
}: Readonly<{
  accent: string;
  title: string;
  subtitle?: string;
  disabled: boolean;
  loading: boolean;
  onPress: () => void;
  idleIcon?: keyof typeof Ionicons.glyphMap;
}>) {
  const scale = useSharedValue(1);
  const pressStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  const inactive = disabled && !loading;

  return (
    <Animated.View style={[cta.wrap, inactive ? cta.wrapIdle : { shadowColor: accent }, pressStyle]}>
      <Pressable
        onPress={() => {
          void hapticFeedback('medium');
          onPress();
        }}
        disabled={disabled || loading}
        onPressIn={() => {
          scale.value = withSpring(0.97, { damping: 18, stiffness: 320 });
        }}
        onPressOut={() => {
          scale.value = withSpring(1, { damping: 13, stiffness: 260 });
        }}
        accessibilityRole="button"
        accessibilityState={{ disabled: disabled || loading, busy: loading }}
        accessibilityLabel={title}
      >
        <View style={[cta.fill, inactive && cta.fillIdle]}>
          {inactive ? null : (
            <Animated.View entering={FadeIn.duration(240)} style={StyleSheet.absoluteFill}>
              <LinearGradient
                colors={[accent, `${accent}D9`]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={StyleSheet.absoluteFill}
              />
              <LinearGradient
                colors={['rgba(255,255,255,0.3)', 'rgba(255,255,255,0)']}
                start={{ x: 0, y: 0 }}
                end={{ x: 0, y: 0.75 }}
                style={StyleSheet.absoluteFill}
                pointerEvents="none"
              />
            </Animated.View>
          )}
          <View style={cta.textCol}>
            <Text style={[cta.title, inactive && cta.titleInactive]} numberOfLines={1}>
              {title}
            </Text>
            {subtitle ? (
              <Animated.Text
                key={subtitle}
                entering={FadeIn.duration(200)}
                style={[cta.subtitle, inactive && cta.subtitleInactive]}
                numberOfLines={1}
              >
                {subtitle}
              </Animated.Text>
            ) : null}
          </View>
          <View style={[cta.arrow, inactive && cta.arrowInactive]}>
            {loading ? (
              <ActivityIndicator size="small" color="#F8FAFC" />
            ) : (
              <Ionicons
                name={inactive ? idleIcon : 'arrow-forward'}
                size={inactive ? 15 : 17}
                color={inactive ? 'rgba(148,163,184,0.9)' : '#F8FAFC'}
              />
            )}
          </View>
        </View>
      </Pressable>
    </Animated.View>
  );
}

const head = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 10 },
  title: { flex: 1, color: '#F8FAFC', fontSize: 17, fontWeight: '800', letterSpacing: -0.3 },
  live: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    height: 26,
    paddingHorizontal: 10,
    borderRadius: 13,
  },
  dotWrap: { width: 8, height: 8, alignItems: 'center', justifyContent: 'center' },
  dot: { width: 7, height: 7, borderRadius: 4 },
  dotPulse: { position: 'absolute', width: 7, height: 7, borderRadius: 4 },
  liveText: { fontSize: 12, fontWeight: '800' },
});

const note = StyleSheet.create({
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    minHeight: 48,
    borderRadius: 24,
    paddingLeft: 16,
    paddingRight: 8,
    paddingVertical: 6,
    backgroundColor: 'rgba(2,6,23,0.35)',
  },
  pillTyping: { alignItems: 'flex-start', borderRadius: 20, paddingVertical: 10 },
  iconTyping: { marginTop: 5 },
  trigger: { flexDirection: 'row', alignItems: 'center', alignSelf: 'center', gap: 6, paddingVertical: 4 },
  triggerText: { color: 'rgba(148,163,184,0.95)', fontSize: 13, fontWeight: '600' },
  triggerHint: { color: 'rgba(148,163,184,0.7)', fontSize: 13, fontWeight: '500' },
  input: {
    flex: 1,
    maxHeight: 110,
    paddingVertical: 4,
    color: '#F8FAFC',
    fontSize: 14,
    lineHeight: 19,
  },
  inputTyping: { minHeight: 60 },
  doneBtn: { height: 28, paddingHorizontal: 12, borderRadius: 14, justifyContent: 'center' },
  doneText: { color: '#0B1220', fontSize: 12, fontWeight: '800' },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    marginTop: 6,
    paddingHorizontal: 16,
  },
  counter: { marginLeft: 'auto', color: 'rgba(148,163,184,0.65)', fontSize: 11, fontWeight: '700' },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    height: 22,
    flexShrink: 1,
  },
  chipText: { fontSize: 11.5, fontWeight: '700', flexShrink: 1 },
});

const cta = StyleSheet.create({
  wrap: {
    borderRadius: 27,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.38,
    shadowRadius: 14,
    elevation: 6,
  },
  wrapIdle: { shadowOpacity: 0, elevation: 0 },
  fill: {
    height: 54,
    borderRadius: 27,
    overflow: 'hidden',
    flexDirection: 'row',
    alignItems: 'center',
    paddingLeft: 20,
    paddingRight: 7,
    gap: 10,
  },
  fillIdle: { backgroundColor: 'rgba(2,6,23,0.35)' },
  textCol: { flex: 1, minWidth: 0 },
  title: { color: '#0B1220', fontSize: 15, fontWeight: '800', letterSpacing: -0.1 },
  titleInactive: { color: 'rgba(226,232,240,0.88)' },
  subtitle: { color: 'rgba(11,18,32,0.68)', fontSize: 11.5, fontWeight: '600', marginTop: 1 },
  subtitleInactive: { color: 'rgba(148,163,184,0.85)' },
  arrow: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(11,18,32,0.88)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  arrowInactive: { backgroundColor: 'rgba(255,255,255,0.06)' },
});
