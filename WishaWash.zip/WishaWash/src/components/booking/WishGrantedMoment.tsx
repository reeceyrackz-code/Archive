import { useEffect, useMemo } from 'react';
import { Image, StyleSheet, View, useWindowDimensions } from 'react-native';
import Animated, {
  Easing,
  Extrapolation,
  interpolate,
  useAnimatedStyle,
  useSharedValue,
  withTiming,
  type SharedValue,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { hapticFeedback } from '../../services/HapticFeedbackService';

const TOTAL_MS = 3400;
const GOLD = '#FBBF24';

/** ms → 0..1 progress inside [from, to], clamped. */
function seg(ms: number, from: number, to: number) {
  'worklet';
  return interpolate(ms, [from, to], [0, 1], Extrapolation.CLAMP);
}

function easeInOut(t: number) {
  'worklet';
  return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
}

type Pt = { x: number; y: number };

function Reticle({ clock, at, color }: Readonly<{ clock: SharedValue<number>; at: Pt; color: string }>) {
  const style = useAnimatedStyle(() => {
    const ms = clock.value;
    const inP = seg(ms, 0, 450);
    const outP = seg(ms, 850, 1050);
    return {
      opacity: inP * (1 - outP),
      transform: [{ scale: 2.4 - 1.4 * easeInOut(inP) }, { rotate: `${inP * 90}deg` }],
    };
  });
  return (
    <Animated.View pointerEvents="none" style={[styles.reticle, { left: at.x - 22, top: at.y - 22, borderColor: color }, style]}>
      {[0, 90, 180, 270].map((deg) => (
        <View key={deg} style={[styles.tick, { backgroundColor: color, transform: [{ rotate: `${deg}deg` }, { translateY: -26 }] }]} />
      ))}
    </Animated.View>
  );
}

function FlyingAvatar({
  clock,
  from,
  to,
  photoUrl,
  color,
}: Readonly<{ clock: SharedValue<number>; from: Pt; to: Pt; photoUrl: string | null; color: string }>) {
  const style = useAnimatedStyle(() => {
    const ms = clock.value;
    const pop = seg(ms, 450, 760);
    const fly = easeInOut(seg(ms, 950, 1550));
    const fade = seg(ms, 1500, 1650);
    const arc = Math.sin(fly * Math.PI) * -60;
    const popScale = pop < 1 ? pop * 1.15 : 1;
    return {
      opacity: Math.min(1, pop * 2) * (1 - fade),
      transform: [
        { translateX: from.x + (to.x - from.x) * fly - 28 },
        { translateY: from.y + (to.y - from.y) * fly + arc - 28 },
        { scale: popScale * (1 - 0.22 * fly) },
      ],
    };
  });
  return (
    <Animated.View pointerEvents="none" style={[styles.avatar, { borderColor: color, shadowColor: color }, style]}>
      {photoUrl ? (
        <Image source={{ uri: photoUrl }} style={styles.avatarImg} />
      ) : (
        <View style={[styles.avatarImg, styles.avatarFallback, { backgroundColor: `${color}55` }]}>
          <Ionicons name="person" size={24} color="#E0F2FE" />
        </View>
      )}
    </Animated.View>
  );
}

function LandingPulse({ clock, at, color }: Readonly<{ clock: SharedValue<number>; at: Pt; color: string }>) {
  const style = useAnimatedStyle(() => {
    const p = seg(clock.value, 1520, 1950);
    return { opacity: p > 0 ? 0.9 * (1 - p) : 0, transform: [{ scale: 0.8 + 1.2 * p }] };
  });
  return <Animated.View pointerEvents="none" style={[styles.pulse, { left: at.x - 26, top: at.y - 26, borderColor: color }, style]} />;
}

const WAND_FROM = 1350;
const WAND_TO = 2300;

const GENIE = require('../../../assets/wish-genie.png');
const GENIE_SIZE = 112;
/** Wand tip inside wish-genie.png, as fractions of the image. */
const WAND_TIP = { x: 0.83, y: 0.36 };

function wandPoint(t: number, W: number, H: number, from: Pt): Pt {
  'worklet';
  const endX = W * 0.66;
  const endY = H * 0.3;
  return {
    x: from.x + t * (endX - from.x),
    y: from.y + t * (endY - from.y) - Math.sin(t * Math.PI) * 70 + Math.sin(t * Math.PI * 3) * 16 * t,
  };
}

function Genie({ clock, at }: Readonly<{ clock: SharedValue<number>; at: Pt }>) {
  const style = useAnimatedStyle(() => {
    const ms = clock.value;
    const pop = seg(ms, 1050, 1350);
    const flick = seg(ms, 1250, 1450);
    const wave = seg(ms, 2050, 2850);
    const out = seg(ms, 2900, 3300);
    const overshoot = pop < 1 ? Math.sin(pop * Math.PI * 0.5) * 1.12 : 1;
    const tilt = Math.sin(flick * Math.PI) * -14 + Math.sin(wave * Math.PI * 4) * 6 * (1 - wave);
    return {
      opacity: Math.min(1, pop * 3) * (1 - out),
      transform: [
        { translateY: (1 - pop) * 60 + out * 40 },
        { scale: (pop < 1 ? overshoot : 1) * (1 - out * 0.4) },
        { rotate: `${tilt}deg` },
      ],
    };
  });
  return (
    <Animated.View pointerEvents="none" style={[styles.genie, { left: at.x, top: at.y }, style]}>
      <Image source={GENIE} style={styles.genieImg} resizeMode="contain" />
    </Animated.View>
  );
}

function WandHead({ clock, W, H, from }: Readonly<{ clock: SharedValue<number>; W: number; H: number; from: Pt }>) {
  const style = useAnimatedStyle(() => {
    const t = seg(clock.value, WAND_FROM, WAND_TO);
    const p = wandPoint(t, W, H, from);
    return {
      opacity: t > 0 && t < 1 ? 1 : 0,
      transform: [{ translateX: p.x - 14 }, { translateY: p.y - 14 }, { rotate: `${t * 540}deg` }],
    };
  });
  return (
    <Animated.View pointerEvents="none" style={[styles.wandHead, style]}>
      <Ionicons name="star" size={28} color="#FFFFFF" />
    </Animated.View>
  );
}

function TrailStar({ clock, t, W, H, from, color, size }: Readonly<{ clock: SharedValue<number>; t: number; W: number; H: number; from: Pt; color: string; size: number }>) {
  const p = wandPoint(t, W, H, from);
  const start = WAND_FROM + t * (WAND_TO - WAND_FROM);
  const style = useAnimatedStyle(() => {
    const q = seg(clock.value, start, start + 750);
    return {
      opacity: q > 0 ? 1 - q : 0,
      transform: [{ translateY: q * 16 }, { scale: q > 0 ? 1 - 0.6 * q : 0 }, { rotate: `${q * 120}deg` }],
    };
  });
  return (
    <Animated.View pointerEvents="none" style={[styles.trail, { left: p.x - size / 2, top: p.y - size / 2 }, style]}>
      <Ionicons name="sparkles" size={size} color={color} />
    </Animated.View>
  );
}

const BURST_AT_MS = WAND_TO;

function BurstFlash({ clock, at }: Readonly<{ clock: SharedValue<number>; at: Pt }>) {
  const style = useAnimatedStyle(() => {
    const q = seg(clock.value, BURST_AT_MS - 40, BURST_AT_MS + 380);
    return { opacity: q > 0 ? 0.9 * (1 - q) : 0, transform: [{ scale: 0.3 + 2.4 * q }] };
  });
  return <Animated.View pointerEvents="none" style={[styles.flash, { left: at.x - 30, top: at.y - 30 }, style]} />;
}

type BurstSpec = { angle: number; dist: number; size: number; icon: 'star' | 'sparkles'; color: string; spin: number };

function BurstStar({ clock, at, spec }: Readonly<{ clock: SharedValue<number>; at: Pt; spec: BurstSpec }>) {
  const style = useAnimatedStyle(() => {
    const q = seg(clock.value, BURST_AT_MS, BURST_AT_MS + 750);
    const d = easeInOut(Math.min(1, q * 1.4)) * spec.dist;
    return {
      opacity: q > 0 ? 1 - q * q : 0,
      transform: [
        { translateX: Math.cos(spec.angle) * d },
        { translateY: Math.sin(spec.angle) * d + q * q * 30 },
        { scale: q > 0 ? (q < 0.15 ? q / 0.15 : 1 - 0.5 * q) : 0 },
        { rotate: `${q * spec.spin}deg` },
      ],
    };
  });
  return (
    <Animated.View pointerEvents="none" style={[styles.trail, { left: at.x - spec.size / 2, top: at.y - spec.size / 2 }, style]}>
      <Ionicons name={spec.icon} size={spec.size} color={spec.color} />
    </Animated.View>
  );
}

type GlitterSpec = { vx: number; vy: number; size: number; color: string; delay: number; twinkle: number };

function Glitter({ clock, at, spec, H }: Readonly<{ clock: SharedValue<number>; at: Pt; spec: GlitterSpec; H: number }>) {
  const style = useAnimatedStyle(() => {
    const q = seg(clock.value, BURST_AT_MS + spec.delay, TOTAL_MS);
    const gravity = H * 0.55;
    return {
      opacity: q > 0 ? (1 - q) * (0.55 + 0.45 * Math.abs(Math.sin(q * spec.twinkle))) : 0,
      transform: [
        { translateX: spec.vx * q + Math.sin(q * 9) * 6 },
        { translateY: spec.vy * q + gravity * q * q },
        { rotate: `${45 + q * 360}deg` },
      ],
    };
  });
  return (
    <Animated.View
      pointerEvents="none"
      style={[styles.glitter, { left: at.x - spec.size / 2, top: at.y - spec.size / 2, width: spec.size, height: spec.size, backgroundColor: spec.color, shadowColor: spec.color }, style]}
    />
  );
}

/**
 * Pro-accepted moment: radar locks onto a Pro, their photo flies into the header,
 * then the genie casts a wand trail that bursts into magic sparkles and glitter. Change `momentKey` to replay.
 */
export default function WishGrantedMoment({
  momentKey,
  accent,
  photoUrl,
  lockPoint,
  onDone,
}: Readonly<{ momentKey: number; accent: string; photoUrl: string | null; lockPoint?: Pt | null; onDone?: () => void }>) {
  const { width: W, height: H } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const clock = useSharedValue(0);

  const R = W * 0.48;
  const lockAt = useMemo<Pt>(() => {
    if (lockPoint) return lockPoint;
    const rad = (300 * Math.PI) / 180;
    return { x: W / 2 + Math.cos(rad) * R * 0.86, y: H / 2 + Math.sin(rad) * R * 0.86 };
  }, [W, H, R, lockPoint?.x, lockPoint?.y]);
  const headerAt = useMemo<Pt>(() => ({ x: 16 + 22, y: insets.top + 10 + 22 }), [insets.top]);
  const genieAt = useMemo<Pt>(() => ({ x: 18, y: H * 0.46 }), [H]);
  const wandFrom = useMemo<Pt>(
    () => ({ x: genieAt.x + GENIE_SIZE * WAND_TIP.x, y: genieAt.y + GENIE_SIZE * WAND_TIP.y }),
    [genieAt]
  );
  const burstAt = useMemo<Pt>(() => ({ x: W * 0.66, y: H * 0.3 }), [W, H]);
  const burst = useMemo<BurstSpec[]>(
    () =>
      Array.from({ length: 18 }, (_, i) => ({
        angle: (i / 18) * Math.PI * 2 + ((i * 37) % 10) / 20,
        dist: 70 + ((i * 53) % 90),
        size: 12 + ((i * 7) % 4) * 4,
        icon: i % 3 === 0 ? 'sparkles' : 'star',
        color: i % 3 === 0 ? GOLD : i % 3 === 1 ? '#FFFFFF' : accent,
        spin: ((i * 61) % 2 ? 1 : -1) * (120 + ((i * 29) % 160)),
      })),
    [accent]
  );
  const glitter = useMemo<GlitterSpec[]>(
    () =>
      Array.from({ length: 34 }, (_, i) => ({
        vx: (((i * 97) % 100) / 100 - 0.5) * W * 1.1,
        vy: -60 - ((i * 43) % 120),
        size: 5 + ((i * 13) % 5),
        color: [GOLD, '#FFFFFF', accent, '#FDE68A', '#BAE6FD'][i % 5]!,
        delay: (i % 6) * 35,
        twinkle: 6 + (i % 5) * 3,
      })),
    [W, accent]
  );
  const trail = useMemo(
    () => Array.from({ length: 18 }, (_, i) => ({ t: i / 17, size: 12 + ((i * 7) % 4) * 3, color: i % 3 === 0 ? GOLD : i % 3 === 1 ? '#FFFFFF' : accent })),
    [accent]
  );

  useEffect(() => {
    clock.value = 0;
    clock.value = withTiming(TOTAL_MS, { duration: TOTAL_MS, easing: Easing.linear });
    const timers = [
      setTimeout(() => void hapticFeedback('rigid'), 420),
      setTimeout(() => void hapticFeedback('medium'), 1530),
      setTimeout(() => void hapticFeedback('heavy'), BURST_AT_MS),
      ...(onDone ? [setTimeout(onDone, TOTAL_MS + 100)] : []),
    ];
    return () => timers.forEach(clearTimeout);
  }, [momentKey, clock, onDone]);

  return (
    <View pointerEvents="none" style={styles.overlay}>
      <Reticle clock={clock} at={lockAt} color={accent} />
      <FlyingAvatar clock={clock} from={lockAt} to={headerAt} photoUrl={photoUrl} color={accent} />
      <LandingPulse clock={clock} at={headerAt} color={accent} />
      <Genie clock={clock} at={genieAt} />
      {trail.map((s) => (
        <TrailStar key={s.t} clock={clock} t={s.t} W={W} H={H} from={wandFrom} color={s.color} size={s.size} />
      ))}
      <WandHead clock={clock} W={W} H={H} from={wandFrom} />
      <BurstFlash clock={clock} at={burstAt} />
      {glitter.map((g, i) => (
        <Glitter key={`g${i}`} clock={clock} at={burstAt} spec={g} H={H} />
      ))}
      {burst.map((b, i) => (
        <BurstStar key={`b${i}`} clock={clock} at={burstAt} spec={b} />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  overlay: { ...StyleSheet.absoluteFill, zIndex: 5000, elevation: 50 },
  reticle: {
    position: 'absolute',
    width: 44,
    height: 44,
    borderRadius: 22,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tick: { position: 'absolute', width: 2, height: 8, borderRadius: 1 },
  avatar: {
    position: 'absolute',
    left: 0,
    top: 0,
    width: 56,
    height: 56,
    borderRadius: 18,
    borderWidth: 2,
    overflow: 'hidden',
    shadowOpacity: 0.8,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 0 },
  },
  avatarImg: { width: '100%', height: '100%' },
  avatarFallback: { alignItems: 'center', justifyContent: 'center' },
  pulse: { position: 'absolute', width: 52, height: 52, borderRadius: 16, borderWidth: 2 },
  wandHead: {
    position: 'absolute',
    left: 0,
    top: 0,
    shadowColor: '#FFFFFF',
    shadowOpacity: 1,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 0 },
  },
  trail: { position: 'absolute' },
  genie: {
    position: 'absolute',
    width: GENIE_SIZE,
    height: GENIE_SIZE,
    shadowColor: '#38BDF8',
    shadowOpacity: 0.7,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 0 },
  },
  genieImg: { width: '100%', height: '100%' },
  flash: {
    position: 'absolute',
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: 'rgba(255,255,255,0.85)',
    shadowColor: '#FDE68A',
    shadowOpacity: 1,
    shadowRadius: 24,
    shadowOffset: { width: 0, height: 0 },
  },
  glitter: {
    position: 'absolute',
    borderRadius: 1.5,
    shadowOpacity: 0.9,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 0 },
  },
});
