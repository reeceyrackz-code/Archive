import React from 'react';
import { Animated, Image, StyleSheet, View } from 'react-native';
import SafeMapView from '../maps/SafeMapView';
import { LinearGradient } from 'expo-linear-gradient';
import { LOCATION_PICKER_MAP_STYLE, MAP_LOCKED_DARK } from '../../constants/mapConstants';
import type { FrozenBookingMapView } from '../../utils/frozenBookingMapView';

const CAR_PIN = require('../../../assets/tracking-car-pin.png');

type Props = {
  mapView: FrozenBookingMapView;
  children?: React.ReactNode;
  showCenterCar?: boolean;
  markerPulse?: Animated.Value;
  /** Allow map marker presses (valeter selection). Default false — fully frozen. */
  allowMarkerPresses?: boolean;
  /** Dark overlay over the map; off for stages that want the plain map. */
  tinted?: boolean;
};

export default function FrozenBookingMapStage({
  mapView,
  children,
  showCenterCar = true,
  markerPulse,
  allowMarkerPresses = false,
  tinted = true,
}: Props) {
  return (
    <View style={StyleSheet.absoluteFill}>
      <SafeMapView
        style={StyleSheet.absoluteFill}
        region={mapView.region}
        initialRegion={mapView.region}
        scrollEnabled={false}
        zoomEnabled={false}
        rotateEnabled={false}
        pitchEnabled={false}
        showsUserLocation={false}
        showsMyLocationButton={false}
        toolbarEnabled={false}
        customMapStyle={LOCATION_PICKER_MAP_STYLE}
        userInterfaceStyle={MAP_LOCKED_DARK}
        mapPadding={mapView.mapPadding}
        legalLabelInsets={mapView.legalLabelInsets}
        pointerEvents={allowMarkerPresses ? 'box-none' : 'none'}
      >
        {children}
      </SafeMapView>
      {tinted ? (
        <>
          <View pointerEvents="none" style={styles.tint} />
          <LinearGradient
            pointerEvents="none"
            colors={['rgba(2,6,23,0.12)', 'rgba(2,6,23,0.42)', 'rgba(2,6,23,0.58)']}
            locations={[0, 0.55, 1]}
            style={styles.tintGradient}
          />
        </>
      ) : null}
      {showCenterCar ? (
        <View pointerEvents="none" style={styles.centerPickerWrap}>
          <View style={styles.centerPickerPin}>
            {markerPulse ? (
              <Animated.View style={{ transform: [{ scale: markerPulse }] }}>
                <Image source={CAR_PIN} style={styles.carPin} resizeMode="contain" />
              </Animated.View>
            ) : (
              <Image source={CAR_PIN} style={styles.carPin} resizeMode="contain" />
            )}
          </View>
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  tint: {
    ...StyleSheet.absoluteFill,
    backgroundColor: 'rgba(15,23,42,0.28)',
  },
  tintGradient: {
    ...StyleSheet.absoluteFill,
  },
  centerPickerWrap: {
    ...StyleSheet.absoluteFill,
    alignItems: 'center',
    justifyContent: 'center',
  },
  centerPickerPin: {
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#38BDF8',
    shadowOpacity: 0.6,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 0 },
  },
  carPin: { width: 34, height: 64 },
});
