import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Image,
  PanResponder,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
  type StyleProp,
  type TextStyle,
  type ViewStyle,
} from 'react-native';
import Animated, {
  Easing,
  FadeIn,
  FadeInDown,
  FadeOut,
  FadeOutUp,
  LinearTransition,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withRepeat,
  withSequence,
  withSpring,
  withTiming,
  type SharedValue,
} from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors } from '../../constants/colors';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import HubGlassIcon from '../shared/HubGlassIcon';
import BusinessSheetBackground from '../shared/BusinessSheetBackground';
import type { StageItem } from '../../utils/trackingStatusHelpers';

const SKY = colors.SKY ?? '#38BDF8';
const GREEN = colors.ECO_GREEN ?? '#10B981';
const DANGER = '#EF4444';
const MUTED = 'rgba(148,163,184,0.9)';
const LOCK_AMBER = '#FBBF24';

const SNAP_SPRING = { damping: 20, stiffness: 220, mass: 0.9 };
const SHEET_LAYOUT = LinearTransition.springify().damping(24).stiffness(190);
const SWIPE_HINT_KEY = 'wishawash:tracking:swipeHintShown';
const SWIPE_HINT_MAX_SHOWS = 3;
const SWIPE_HINT_VISIBLE_MS = 4500;

/** Space kept above the sheet for the header so it never runs off the top. */
const SHEET_TOP_CLEARANCE = 80;

export type LiveTrackingSheetProps = {
  accent: string;
  mode: 'connecting' | 'payment' | 'live';
  /** Changes whenever the booking status changes; drives the hero cross-fade. */
  statusKey: string;
  statusTitle: string;
  statusMessage?: string | null;
  serviceName: string;
  stages: StageItem[];
  progressPercent: number;
  /** Matching / payment countdown. */
  countdown?: { label: string; progress: number; hint: string; urgent: boolean } | null;
  /** Pro distance while on the way / arrived. */
  eta?: { value: string; unit: string; caption: string } | null;
  pro: { name: string | null; photoUrl: string | null; rating: number; jobs: number };
  details: {
    price: string;
    washType?: string | null;
    vehicle?: string | null;
    address?: string | null;
    includes: string[];
    extras: { label: string; value: string; positive?: boolean }[];
  };
  chatLocked: boolean;
  openingChat: boolean;
  cancelling: boolean;
  onChat: () => void;
  onPay?: () => void;
  onCancel: () => void;
  onDismiss: () => void;
  /** Height of the sheet while collapsed, so the scene behind can fill exactly the space above it. */
  onCollapsedHeight?: (height: number) => void;
  /** The screen header carries the status update; the sheet shows the road and Pro only when expanded. */
  headerUpdate?: boolean;
};

function PressScale({
  onPress,
  disabled,
  style,
  children,
  accessibilityLabel,
}: Readonly<{
  onPress: () => void;
  disabled?: boolean;
  style?: StyleProp<ViewStyle>;
  children: React.ReactNode;
  accessibilityLabel?: string;
}>) {
  const scale = useSharedValue(1);
  const aStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      onPressIn={() => {
        void hapticFeedback('light');
        scale.value = withSpring(0.95, { damping: 18, stiffness: 400 });
      }}
      onPressOut={() => { scale.value = withSpring(1, { damping: 14, stiffness: 300 }); }}
      accessibilityRole="button"
      {...(accessibilityLabel ? { accessibilityLabel } : {})}
    >
      <Animated.View style={[style, aStyle, disabled && styles.disabled]}>{children}</Animated.View>
    </Pressable>
  );
}

const ROAD_CAR = require('../../../assets/tracking-car-pin.png');
const ROAD_PAD = 30;
const ROAD_H = 40;
const CAR_W = 22;
const CAR_H = 41;
const DRIVE_MS = 1200;

function RoadStop({ stage, color, x }: Readonly<{ stage: StageItem; color: string; x: number }>) {
  if (stage.done && !stage.current) {
    return (
      <View style={[styles.roadStop, styles.roadStopDone, { left: x - 7, backgroundColor: color }]}>
        <Ionicons name="checkmark" size={9} color="#04121F" />
      </View>
    );
  }
  if (stage.current) {
    return <View style={[styles.roadStop, styles.roadStopCurrent, { left: x - 8, borderColor: color }]} />;
  }
  return <View style={[styles.roadStop, styles.roadStopTodo, { left: x - 3 }]} />;
}

function Timeline({ stages, color }: Readonly<{ stages: StageItem[]; color: string }>) {
  const [width, setWidth] = useState(0);
  const n = stages.length;
  const foundIdx = stages.findIndex((s) => s.current);
  const currentIdx = Math.max(0, foundIdx >= 0 ? foundIdx : stages.filter((s) => s.done).length - 1);
  const next = stages[currentIdx + 1];
  const stopX = (i: number) => (n > 1 ? ROAD_PAD + (i * (width - ROAD_PAD * 2)) / (n - 1) : width / 2);

  const carX = useSharedValue(0);
  const moving = useSharedValue(0);
  const bob = useSharedValue(0);
  const placedRef = useRef(false);

  useEffect(() => {
    bob.value = withRepeat(withTiming(1, { duration: 420, easing: Easing.inOut(Easing.sin) }), -1, true);
  }, [bob]);

  useEffect(() => {
    if (!width) return;
    const target = stopX(currentIdx);
    if (!placedRef.current) {
      placedRef.current = true;
      carX.value = target;
      return;
    }
    if (Math.abs(carX.value - target) < 1) return;
    void hapticFeedback('soft');
    moving.value = withSequence(withTiming(1, { duration: 120 }), withDelay(DRIVE_MS - 200, withTiming(0, { duration: 260 })));
    carX.value = withTiming(target, { duration: DRIVE_MS, easing: Easing.inOut(Easing.cubic) });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [width, currentIdx]);

  const carStyle = useAnimatedStyle(() => ({
    transform: [
      { translateX: carX.value - CAR_W / 2 },
      { translateY: (bob.value - 0.5) * (0.6 + moving.value * 2.2) },
      { rotate: '90deg' },
    ],
  }));
  const fillStyle = useAnimatedStyle(() => ({ width: Math.max(0, carX.value) }));
  const puffA = useAnimatedStyle(() => ({
    opacity: moving.value * (0.35 + bob.value * 0.35),
    transform: [{ translateX: carX.value - CAR_H / 2 - 10 - bob.value * 6 }, { scale: 0.7 + bob.value * 0.6 }],
  }));
  const puffB = useAnimatedStyle(() => ({
    opacity: moving.value * (0.7 - bob.value * 0.4),
    transform: [{ translateX: carX.value - CAR_H / 2 - 20 - (1 - bob.value) * 6 }, { scale: 1.1 - bob.value * 0.5 }],
  }));

  return (
    <View style={styles.timelineWrap}>
      <View style={styles.road} onLayout={(e) => setWidth(e.nativeEvent.layout.width)}>
        <View style={styles.roadStrip}>
          <Animated.View style={[styles.roadFill, { backgroundColor: `${color}40` }, fillStyle]} />
          <View style={styles.roadDashes} pointerEvents="none">
            {Array.from({ length: 18 }, (_, i) => (
              <View key={i} style={styles.roadDash} />
            ))}
          </View>
        </View>
        {width > 0
          ? stages.map((stage, i) => <RoadStop key={stage.label} stage={stage} color={color} x={stopX(i)} />)
          : null}
        {width > 0 ? (
          <>
            <Animated.View pointerEvents="none" style={[styles.puff, puffB]} />
            <Animated.View pointerEvents="none" style={[styles.puff, puffA]} />
            <Animated.Image source={ROAD_CAR} resizeMode="contain" style={[styles.roadCar, carStyle]} />
          </>
        ) : null}
      </View>
      {width > 0 ? (
        <View style={styles.roadLabels}>
          {stages.map((stage, i) => (
            <Text
              key={stage.label}
              numberOfLines={1}
              style={[
                styles.roadLabel,
                { left: stopX(i) - 36 },
                (stage.done || stage.current) && { color: 'rgba(226,232,240,0.8)' },
                stage.current && styles.roadLabelCurrent,
                stage.current && { color },
              ]}
            >
              {stage.label}
            </Text>
          ))}
        </View>
      ) : null}
      <Text style={styles.timelineCaption} numberOfLines={1}>
        Step {currentIdx + 1} of {n}
        {next ? <Text style={styles.timelineCaptionNext}>{`  ·  Next: ${next.label}`}</Text> : null}
      </Text>
    </View>
  );
}

function SearchingAvatar({ color }: Readonly<{ color: string }>) {
  const spin = useSharedValue(0);
  useEffect(() => {
    spin.value = withRepeat(withTiming(1, { duration: 1800, easing: Easing.linear }), -1, false);
  }, [spin]);
  const aStyle = useAnimatedStyle(() => ({ transform: [{ rotate: `${spin.value * 360}deg` }] }));
  return (
    <View style={[styles.avatar, styles.avatarFallback, { backgroundColor: `${color}1F`, borderColor: `${color}55` }]}>
      <Animated.View style={aStyle}>
        <Ionicons name="sync-outline" size={20} color={color} />
      </Animated.View>
    </View>
  );
}

type Countdown = NonNullable<LiveTrackingSheetProps['countdown']>;
type Eta = NonNullable<LiveTrackingSheetProps['eta']>;
type Details = LiveTrackingSheetProps['details'];
type Mode = LiveTrackingSheetProps['mode'];

function useExpanded() {
  const [expanded, setExpanded] = useState(false);
  const expandedRef = useRef(false);
  expandedRef.current = expanded;
  const toggleExpanded = useCallback((next?: boolean) => {
    const value = next ?? !expandedRef.current;
    if (value === expandedRef.current) return;
    void hapticFeedback('light');
    setExpanded(value);
  }, []);
  return { expanded, expandedRef, toggleExpanded };
}

/** First few visits: nudge the sheet down twice and say it can be swiped away. */
function useSwipeHint(dragY: SharedValue<number>) {
  const [show, setShow] = useState(false);
  useEffect(() => {
    let cancelled = false;
    const timers: ReturnType<typeof setTimeout>[] = [];
    const dip = () =>
      withSequence(withTiming(16, { duration: 260, easing: Easing.out(Easing.quad) }), withSpring(0, { damping: 11, stiffness: 220 }));
    const nudge = () => {
      if (cancelled) return;
      setShow(true);
      dragY.value = withSequence(dip(), withTiming(0, { duration: 180 }), dip());
      timers.push(setTimeout(() => !cancelled && setShow(false), SWIPE_HINT_VISIBLE_MS));
    };
    const run = async () => {
      const shown = Number(await AsyncStorage.getItem(SWIPE_HINT_KEY)) || 0;
      if (cancelled || shown >= SWIPE_HINT_MAX_SHOWS) return;
      AsyncStorage.setItem(SWIPE_HINT_KEY, String(shown + 1)).catch(() => {});
      timers.push(setTimeout(nudge, 1100));
    };
    run().catch(() => {});
    return () => {
      cancelled = true;
      timers.forEach(clearTimeout);
    };
  }, [dragY]);
  return show;
}

/** Drag up to expand; down to collapse, down again to hide (full map), and down once more to ask to leave. */
function useSheetPan(
  dragY: SharedValue<number>,
  expandedRef: React.RefObject<boolean>,
  toggleExpanded: (next?: boolean) => void,
  hiddenRef: React.RefObject<boolean>,
  setSheetHidden: (hidden: boolean) => void,
  onDismiss: () => void
) {
  return useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => false,
        onMoveShouldSetPanResponder: (_, g) => Math.abs(g.dy) > 6 && Math.abs(g.dy) > Math.abs(g.dx),
        onPanResponderMove: (_, g) => {
          dragY.value = g.dy > 0 ? g.dy : g.dy * 0.25;
        },
        onPanResponderRelease: (_, g) => {
          const up = g.dy < -40 || g.vy < -0.5;
          const down = g.dy > 80 || g.vy > 0.6;
          if (up) {
            if (hiddenRef.current) setSheetHidden(false);
            else if (!expandedRef.current) toggleExpanded(true);
          } else if (down) {
            if (expandedRef.current) toggleExpanded(false);
            else if (!hiddenRef.current) setSheetHidden(true);
            else onDismiss();
          }
          dragY.value = withSpring(0, SNAP_SPRING);
        },
        onPanResponderTerminate: () => {
          dragY.value = withSpring(0, SNAP_SPRING);
        },
      }),
    [dragY, expandedRef, toggleExpanded, hiddenRef, setSheetHidden, onDismiss]
  );
}

function chatLabel(locked: boolean, mode: Mode) {
  if (!locked) return 'Chat';
  return mode === 'payment' ? 'Pay to chat' : 'Locked';
}

function ChatButton({ accent, mode, locked, opening, onChat }: Readonly<{ accent: string; mode: Mode; locked: boolean; opening: boolean; onChat: () => void }>) {
  const color = locked ? LOCK_AMBER : accent;
  return (
    <PressScale
      onPress={onChat}
      disabled={opening}
      style={[styles.chatBtn, { backgroundColor: `${color}${locked ? '1A' : '22'}` }]}
      accessibilityLabel={locked ? 'Chat unlocks after payment' : 'Message your Pro'}
    >
      <LinearGradient
        colors={['rgba(255,255,255,0.14)', 'rgba(255,255,255,0)']}
        start={{ x: 0.5, y: 0 }}
        end={{ x: 0.5, y: 1 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      {opening ? (
        <ActivityIndicator size="small" color={color} />
      ) : (
        <>
          <View>
            <Ionicons name="chatbubble-ellipses" size={16} color={color} />
            {locked ? (
              <View style={styles.chatLockBadge}>
                <Ionicons name="lock-closed" size={7} color="#0B1220" />
              </View>
            ) : null}
          </View>
          <Text style={[styles.chatText, { color }]}>{chatLabel(locked, mode)}</Text>
        </>
      )}
    </PressScale>
  );
}

function CancelButton({
  label,
  cancelling,
  onCancel,
  style,
  iconSize,
  textStyle,
}: Readonly<{ label: string; cancelling: boolean; onCancel: () => void; style: StyleProp<ViewStyle>; iconSize: number; textStyle: StyleProp<TextStyle> }>) {
  return (
    <PressScale onPress={onCancel} disabled={cancelling} style={style} accessibilityLabel={label}>
      {cancelling ? (
        <ActivityIndicator size="small" color={DANGER} />
      ) : (
        <>
          <Ionicons name="close" size={iconSize} color="#FCA5A5" />
          <Text style={textStyle}>{label}</Text>
        </>
      )}
    </PressScale>
  );
}

function ServiceChips({ details }: Readonly<{ details: Details }>) {
  if (!details.washType && !details.vehicle) return null;
  return (
    <View style={styles.chipRow}>
      {details.washType ? (
        <View style={styles.chip}>
          <Ionicons name="water-outline" size={12} color={SKY} />
          <Text style={styles.chipText}>{details.washType}</Text>
        </View>
      ) : null}
      {details.vehicle ? (
        <View style={styles.chip}>
          <Ionicons name="car-sport-outline" size={12} color={SKY} />
          <Text style={styles.chipText} numberOfLines={1}>
            {details.vehicle}
          </Text>
        </View>
      ) : null}
    </View>
  );
}

function IncludesList({ items, accent, drop = false }: Readonly<{ items: string[]; accent: string; drop?: boolean }>) {
  if (items.length === 0) return null;
  return (
    <View style={styles.includes}>
      {items.map((item, idx) => (
        <Animated.View
          key={`${idx}-${item.slice(0, 16)}`}
          entering={drop ? FadeInDown.delay(60 + idx * 35).duration(260) : FadeIn.delay(idx * 30).duration(220)}
          style={styles.includeRow}
        >
          <Ionicons name="checkmark-circle" size={14} color={accent} />
          <Text style={styles.includeText} numberOfLines={1}>
            {item}
          </Text>
        </Animated.View>
      ))}
    </View>
  );
}

function PriceRows({ details, accent, totalStyle }: Readonly<{ details: Details; accent: string; totalStyle?: StyleProp<ViewStyle> }>) {
  return (
    <>
      {details.extras.map((x) => (
        <View key={x.label} style={styles.priceRow}>
          <Text style={styles.priceLabel}>{x.label}</Text>
          <Text style={[styles.priceValue, x.positive && { color: GREEN }]}>{x.value}</Text>
        </View>
      ))}
      <View style={[styles.priceRow, totalStyle]}>
        <Text style={styles.priceTotalLabel}>Total</Text>
        <Text style={[styles.priceTotalValue, { color: accent }]}>£{details.price}</Text>
      </View>
    </>
  );
}

function ProAvatar({ searching, photoUrl, accent }: Readonly<{ searching: boolean; photoUrl: string | null; accent: string }>) {
  if (searching) return <SearchingAvatar color={accent} />;
  if (photoUrl) return <Image source={{ uri: photoUrl }} style={[styles.avatar, { borderColor: `${accent}88` }]} />;
  return (
    <View style={[styles.avatar, styles.avatarFallback, { backgroundColor: `${accent}1F`, borderColor: `${accent}55` }]}>
      <Ionicons name="person" size={20} color={accent} />
    </View>
  );
}

function MetricChip({ countdown, eta, accent }: Readonly<{ countdown: Countdown | null; eta: Eta | null; accent: string }>) {
  const c = countdown?.urgent ? DANGER : accent;
  let label = 'Live';
  if (countdown) label = countdown.label;
  else if (eta) label = eta.unit ? `${eta.value} ${eta.unit}` : eta.value;
  return (
    <View style={[styles.payClock, { borderColor: `${c}66`, backgroundColor: `${c}14` }]}>
      <Ionicons name={countdown ? 'time-outline' : eta ? 'navigate' : 'radio-button-on'} size={13} color={c} />
      <Text style={[styles.payClockText, { color: c }]}>{label}</Text>
    </View>
  );
}

/** Indeterminate scan bar shown while a Pro is being connected. */
function SearchBar({ accent }: Readonly<{ accent: string }>) {
  const [w, setW] = useState(0);
  const t = useSharedValue(0);
  useEffect(() => {
    t.value = withRepeat(withTiming(1, { duration: 1500, easing: Easing.inOut(Easing.quad) }), -1, false);
  }, [t]);
  const seg = useAnimatedStyle(() => ({ transform: [{ translateX: -w * 0.35 + t.value * w * 1.35 }] }));
  return (
    <View style={styles.searchTrack} onLayout={(e) => setW(e.nativeEvent.layout.width)}>
      <Animated.View style={[styles.searchSeg, { width: w * 0.35, backgroundColor: accent }, seg]} />
    </View>
  );
}

/** Every non-payment stage, Uber-style: headline + time chip, progress strip, Pro row, links. */
function StagePanel({
  mode,
  accent,
  statusKey,
  statusTitle,
  statusMessage,
  countdown,
  eta,
  stages,
  pro,
  serviceName,
  details,
  chatButton,
  expanded,
  cancelling,
  headerUpdate,
  onToggle,
  onCancel,
}: Readonly<{
  mode: Mode;
  accent: string;
  statusKey: string;
  statusTitle: string;
  statusMessage: string | null;
  countdown: Countdown | null;
  eta: Eta | null;
  stages: StageItem[];
  pro: LiveTrackingSheetProps['pro'];
  serviceName: string;
  details: Details;
  chatButton: React.ReactNode;
  expanded: boolean;
  cancelling: boolean;
  headerUpdate: boolean;
  onToggle: () => void;
  onCancel: () => void;
}>) {
  const connecting = mode === 'connecting';
  if (headerUpdate && !expanded) {
    return (
      <Animated.View entering={FadeIn.duration(260)}>
        <Timeline stages={stages} color={accent} />
        <View style={styles.payLinks}>
          <Pressable onPress={onToggle} hitSlop={8} style={styles.payLink} accessibilityRole="button" accessibilityLabel="Show your Pro and details">
            <Text style={styles.payLinkText}>{pro.name ? `${pro.name.split(' ')[0]} & details` : 'Details'}</Text>
            <Ionicons name="chevron-up" size={13} color={MUTED} />
          </Pressable>
        </View>
      </Animated.View>
    );
  }
  return (
    <Animated.View entering={FadeIn.duration(260)}>
      {headerUpdate ? null : (
      <Animated.View key={statusKey} entering={FadeInDown.duration(380).easing(Easing.out(Easing.cubic))}>
        <View style={styles.payHeadRow}>
          <Text style={styles.payTitle} numberOfLines={2}>
            {statusTitle}
          </Text>
          <MetricChip countdown={countdown} eta={eta} accent={accent} />
        </View>
        <Text style={styles.paySub} numberOfLines={2}>
          {statusMessage || serviceName}
        </Text>
      </Animated.View>
      )}

      {connecting ? <SearchBar accent={accent} /> : <Timeline stages={stages} color={accent} />}

      <View style={styles.payProRow}>
        <ProAvatar searching={connecting && !pro.name} photoUrl={pro.photoUrl} accent={accent} />
        <View style={styles.proCopy}>
          <View style={styles.payProNameRow}>
            <Text style={styles.proName} numberOfLines={1}>
              {pro.name ?? 'Finding your Pro…'}
            </Text>
            {pro.name ? <Ionicons name="shield-checkmark" size={13} color={GREEN} /> : null}
          </View>
          <View style={styles.proMetaRow}>
            {pro.name && pro.rating > 0 ? (
              <>
                <Ionicons name="star" size={11} color="#FBBF24" />
                <Text style={styles.proMeta}>{pro.rating.toFixed(1)}</Text>
                <Text style={styles.proMetaDot}>·</Text>
              </>
            ) : null}
            <Text style={styles.proMeta} numberOfLines={1}>
              {serviceName}
            </Text>
          </View>
        </View>
        {chatButton}
      </View>

      <View style={styles.payLinks}>
        <Pressable onPress={onToggle} hitSlop={8} style={styles.payLink} accessibilityRole="button" accessibilityLabel={expanded ? 'Hide details' : 'Show details'}>
          <Text style={styles.payLinkText}>{expanded ? 'Hide details' : `Details & price · £${details.price}`}</Text>
          <Ionicons name={expanded ? 'chevron-down' : 'chevron-up'} size={13} color={MUTED} />
        </Pressable>
        {connecting && !expanded ? (
          <>
            <Text style={styles.proMetaDot}>·</Text>
            <Pressable onPress={onCancel} disabled={cancelling} hitSlop={8} style={styles.payLink} accessibilityRole="button" accessibilityLabel="Cancel request">
              {cancelling ? <ActivityIndicator size="small" color={DANGER} /> : <Text style={styles.payCancelText}>Cancel</Text>}
            </Pressable>
          </>
        ) : null}
      </View>

      {expanded ? <ExpandedDetails showJobCard={false} serviceName={serviceName} details={details} accent={accent} cancelling={cancelling} onCancel={onCancel} /> : null}
    </Animated.View>
  );
}

/** Awaiting payment, Uber-style: one clear headline, the Pro, the price and a single Pay action. */
function PaymentPanel({
  accent,
  countdown,
  eta,
  pro,
  serviceName,
  details,
  expanded,
  cancelling,
  onPay,
  onToggle,
  onCancel,
}: Readonly<{
  accent: string;
  countdown: Countdown | null;
  eta: Eta | null;
  pro: LiveTrackingSheetProps['pro'];
  serviceName: string;
  details: Details;
  expanded: boolean;
  cancelling: boolean;
  onPay?: () => void;
  onToggle: () => void;
  onCancel: () => void;
}>) {
  const urgent = Boolean(countdown?.urgent);
  const clock = urgent ? DANGER : LOCK_AMBER;
  const first = pro.name?.split(' ')[0] ?? 'Your Pro';
  const away = eta ? ` · ${eta.value} ${eta.unit} away` : '';
  return (
    <Animated.View entering={FadeIn.duration(260)}>
      <View style={styles.payHeadRow}>
        <Text style={styles.payTitle} numberOfLines={1}>
          Pay to confirm
        </Text>
        {countdown ? (
          <View style={[styles.payClock, { borderColor: `${clock}66`, backgroundColor: `${clock}14` }]}>
            <Ionicons name="time-outline" size={13} color={clock} />
            <Text style={[styles.payClockText, { color: clock }]}>{countdown.label}</Text>
          </View>
        ) : null}
      </View>
      <Text style={styles.paySub} numberOfLines={1}>
        {`${first} sets off as soon as you pay${away}`}
      </Text>

      <View style={styles.payProRow}>
        <ProAvatar searching={false} photoUrl={pro.photoUrl} accent={accent} />
        <View style={styles.proCopy}>
          <View style={styles.payProNameRow}>
            <Text style={styles.proName} numberOfLines={1}>
              {pro.name ?? 'Your Pro'}
            </Text>
            <Ionicons name="shield-checkmark" size={13} color={GREEN} />
          </View>
          <View style={styles.proMetaRow}>
            {pro.rating > 0 ? (
              <>
                <Ionicons name="star" size={11} color="#FBBF24" />
                <Text style={styles.proMeta}>{pro.rating.toFixed(1)}</Text>
                <Text style={styles.proMetaDot}>·</Text>
              </>
            ) : null}
            <Text style={styles.proMeta} numberOfLines={1}>
              {serviceName}
            </Text>
          </View>
        </View>
        <View style={styles.payPriceCol}>
          <Text style={styles.payPrice}>£{details.price}</Text>
          <Text style={styles.payPriceLabel}>Total</Text>
        </View>
      </View>

      {onPay ? (
        <PressScale onPress={onPay} style={[styles.payBtn, { shadowColor: urgent ? DANGER : GREEN }]} accessibilityLabel={`Pay £${details.price}`}>
          <View style={styles.payClip}>
            <LinearGradient colors={urgent ? ['#F87171', DANGER] : ['#34D399', GREEN]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} />
            <Text style={styles.payText}>{`Pay £${details.price}`}</Text>
            <View style={styles.payArrowDot}>
              <Ionicons name="arrow-forward" size={16} color="#F8FAFC" />
            </View>
          </View>
        </PressScale>
      ) : null}

      <View style={styles.payLinks}>
        <Pressable onPress={onToggle} hitSlop={8} style={styles.payLink} accessibilityRole="button" accessibilityLabel={expanded ? 'Hide details' : 'Show details'}>
          <Text style={styles.payLinkText}>{expanded ? 'Hide details' : 'Details & price'}</Text>
          <Ionicons name={expanded ? 'chevron-down' : 'chevron-up'} size={13} color={MUTED} />
        </Pressable>
        {expanded ? null : (
          <>
            <Text style={styles.proMetaDot}>·</Text>
            <Pressable onPress={onCancel} disabled={cancelling} hitSlop={8} style={styles.payLink} accessibilityRole="button" accessibilityLabel="Cancel booking">
              {cancelling ? <ActivityIndicator size="small" color={DANGER} /> : <Text style={styles.payCancelText}>Cancel</Text>}
            </Pressable>
          </>
        )}
      </View>

      {expanded ? <ExpandedDetails showJobCard={false} serviceName={serviceName} details={details} accent={accent} cancelling={cancelling} onCancel={onCancel} /> : null}
    </Animated.View>
  );
}

function ExpandedDetails({
  showJobCard,
  serviceName,
  details,
  accent,
  cancelling,
  onCancel,
}: Readonly<{ showJobCard: boolean; serviceName: string; details: Details; accent: string; cancelling: boolean; onCancel: () => void }>) {
  return (
    <Animated.View entering={FadeInDown.duration(320)} exiting={FadeOutUp.duration(180)}>
      {showJobCard ? null : (
        <View style={styles.detailCard}>
          <Text style={styles.detailTitle} numberOfLines={2}>
            {serviceName}
          </Text>
          <ServiceChips details={details} />
          <IncludesList items={details.includes.slice(0, 8)} accent={accent} drop />
        </View>
      )}
      {details.address && !showJobCard ? (
        <View style={styles.infoRow}>
          <HubGlassIcon icon="location" accent="green" size={30} iconSize={14} />
          <Text style={styles.infoText} numberOfLines={2}>
            {details.address}
          </Text>
        </View>
      ) : null}
      <View style={styles.priceCard}>
        <PriceRows details={details} accent={accent} totalStyle={details.extras.length > 0 ? styles.priceTotalRow : null} />
      </View>
      <CancelButton label="Cancel booking" cancelling={cancelling} onCancel={onCancel} style={styles.cancelBtn} iconSize={16} textStyle={styles.cancelText} />
    </Animated.View>
  );
}

export default function LiveTrackingSheet(props: Readonly<LiveTrackingSheetProps>) {
  const {
    accent,
    mode,
    statusKey,
    statusTitle,
    statusMessage,
    serviceName,
    stages,
    countdown,
    eta,
    pro,
    details,
    chatLocked,
    openingChat,
    cancelling,
    onChat,
    onPay,
    onCancel,
    onDismiss,
    onCollapsedHeight,
    headerUpdate = false,
  } = props;
  const insets = useSafeAreaInsets();
  const { height: screenH } = useWindowDimensions();
  const { expanded, expandedRef, toggleExpanded } = useExpanded();

  // Must rest at 0: Pressables measure their frame from the committed layout, so any
  // resting offset applied only on the UI thread makes taps get cancelled.
  const dragY = useSharedValue(0);
  const scrollRef = useRef<ScrollView>(null);
  useEffect(() => {
    if (!expanded) {
      scrollRef.current?.scrollTo({ y: 0, animated: true });
      return undefined;
    }
    const t = setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 380);
    return () => clearTimeout(t);
  }, [expanded]);

  const [hidden, setHidden] = useState(false);
  const hiddenRef = useRef(false);
  hiddenRef.current = hidden;
  const setSheetHidden = useCallback((next: boolean) => {
    if (next === hiddenRef.current) return;
    void hapticFeedback('light');
    hiddenRef.current = next;
    setHidden(next);
  }, []);

  const showSwipeHint = useSwipeHint(dragY);
  const pan = useSheetPan(dragY, expandedRef, toggleExpanded, hiddenRef, setSheetHidden, onDismiss);

  const lastStatus = useRef(statusKey);
  useEffect(() => {
    if (lastStatus.current !== statusKey) {
      lastStatus.current = statusKey;
      void hapticFeedback('medium');
      hiddenRef.current = false;
      setHidden(false);
    }
  }, [statusKey]);

  const sheetStyle = useAnimatedStyle(() => ({ transform: [{ translateY: dragY.value }] }));

  const paymentView = mode === 'payment';

  const chatButton = <ChatButton accent={accent} mode={mode} locked={chatLocked} opening={openingChat} onChat={onChat} />;


  return (
    <Animated.View
      entering={FadeInDown.springify().damping(20).stiffness(180)}
      style={styles.dock}
      onLayout={(e) => {
        if (!expandedRef.current) onCollapsedHeight?.(Math.round(e.nativeEvent.layout.height));
      }}
    >
      <Animated.View style={sheetStyle}>
        <Animated.View
          layout={SHEET_LAYOUT}
          style={[styles.sheet, { paddingBottom: Math.max(insets.bottom, 12) + 4, maxHeight: screenH - insets.top - SHEET_TOP_CLEARANCE }]}
        >
          <BusinessSheetBackground />
          <LinearGradient colors={[`${accent}26`, 'transparent']} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={styles.accentWash} pointerEvents="none" />
          <View style={[styles.topRim, { backgroundColor: `${accent}66` }]} pointerEvents="none" />

          <View style={styles.body}>
            <View {...pan.panHandlers}>
              <Pressable
                onPress={() => (hiddenRef.current ? setSheetHidden(false) : toggleExpanded())}
                hitSlop={8}
                style={styles.handleHit}
                accessibilityLabel={hidden ? 'Show trip details' : 'Expand details'}
              >
                <View style={styles.handle} />
                {showSwipeHint && !expanded && !hidden ? (
                  <Animated.View entering={FadeIn.duration(260)} exiting={FadeOut.duration(320)} style={styles.swipeHint}>
                    <Ionicons name="chevron-down" size={12} color={MUTED} />
                    <Text style={styles.swipeHintText}>Swipe down for the full map</Text>
                  </Animated.View>
                ) : null}
              </Pressable>

            </View>

            {hidden ? (
              <Pressable onPress={() => setSheetHidden(false)} style={styles.peekRow} accessibilityRole="button" accessibilityLabel="Show trip details">
                <Text style={styles.peekText} numberOfLines={1}>
                  {statusTitle}
                </Text>
                <Ionicons name="chevron-up" size={14} color={MUTED} />
              </Pressable>
            ) : (
            <ScrollView ref={scrollRef} style={styles.scroll} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false} bounces={false}>
              {paymentView ? (
                <PaymentPanel
                  accent={accent}
                  countdown={countdown ?? null}
                  eta={eta ?? null}
                  pro={pro}
                  serviceName={serviceName}
                  details={details}
                  expanded={expanded}
                  cancelling={cancelling}
                  {...(onPay ? { onPay } : {})}
                  onToggle={() => toggleExpanded()}
                  onCancel={onCancel}
                />
              ) : (
                <StagePanel
                  mode={mode}
                  accent={accent}
                  statusKey={statusKey}
                  statusTitle={statusTitle}
                  statusMessage={statusMessage ?? null}
                  countdown={countdown ?? null}
                  eta={eta ?? null}
                  stages={stages}
                  pro={pro}
                  serviceName={serviceName}
                  details={details}
                  chatButton={chatButton}
                  expanded={expanded}
                  cancelling={cancelling}
                  headerUpdate={headerUpdate}
                  onToggle={() => toggleExpanded()}
                  onCancel={onCancel}
                />
              )}
            </ScrollView>
            )}
          </View>
        </Animated.View>
      </Animated.View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  dock: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 1000,
  },
  sheet: {
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    overflow: 'hidden',
    paddingHorizontal: 18,
    backgroundColor: colors.BG ?? '#0A1929',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -8 },
    shadowOpacity: 0.35,
    shadowRadius: 24,
    elevation: 20,
  },
  accentWash: { position: 'absolute', top: 0, left: 0, right: 0, height: 140 },
  topRim: { position: 'absolute', top: 0, left: 40, right: 40, height: 1.5, borderRadius: 1 },
  disabled: { opacity: 0.5 },
  body: { flexShrink: 1 },
  scroll: { flexGrow: 0, flexShrink: 1 },
  scrollContent: { paddingBottom: 4 },
  handleHit: { alignItems: 'center', paddingTop: 10, paddingBottom: 12 },
  handle: { width: 40, height: 5, borderRadius: 3, backgroundColor: 'rgba(148,163,184,0.5)' },
  swipeHint: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 6 },
  swipeHintText: { color: MUTED, fontSize: 11, fontWeight: '600' },
  peekRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingBottom: 6 },
  peekText: { flexShrink: 1, color: 'rgba(241,245,249,0.9)', fontSize: 14, fontWeight: '700' },

  heroRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 14 },
  heroCopy: { flex: 1, minWidth: 0 },
  kickerRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 4 },
  kickerLive: { fontSize: 11, fontWeight: '900', letterSpacing: 1.2 },
  kicker: { flexShrink: 1, color: MUTED, fontSize: 11, fontWeight: '700', letterSpacing: 0.4, textTransform: 'uppercase' },
  liveDotWrap: { width: 10, height: 10, alignItems: 'center', justifyContent: 'center' },
  liveDot: { width: 8, height: 8, borderRadius: 4 },
  liveDotRing: { position: 'absolute', width: 8, height: 8, borderRadius: 4 },
  statusTitle: { color: '#F8FAFC', fontSize: 18, fontWeight: '800', letterSpacing: -0.3, lineHeight: 23 },
  statusMessage: { color: 'rgba(203,213,225,0.78)', fontSize: 12.5, fontWeight: '500', lineHeight: 17, marginTop: 2 },
  timerCol: { alignItems: 'center', gap: 5, minWidth: 74 },
  timerPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 999,
  },
  timerText: { fontSize: 13, fontWeight: '700', fontVariant: ['tabular-nums'], letterSpacing: 0.2 },
  timerTrack: { width: 56, height: 2, borderRadius: 1, backgroundColor: 'rgba(148,163,184,0.18)', overflow: 'hidden' },
  timerFill: { height: '100%', borderRadius: 1 },
  timerHint: { color: MUTED, fontSize: 10, fontWeight: '600' },
  metricCol: { alignItems: 'center', gap: 5, minWidth: 74, maxWidth: 96 },
  metricRow: { flexDirection: 'row', alignItems: 'baseline', gap: 2 },
  metricValue: { fontSize: 22, fontWeight: '800', fontVariant: ['tabular-nums'], letterSpacing: -0.6 },
  metricUnit: { fontSize: 12, fontWeight: '700', opacity: 0.85 },

  timelineWrap: { marginTop: 2, marginBottom: 14 },
  road: { height: ROAD_H, justifyContent: 'center' },
  roadStrip: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: ROAD_H / 2 - 8,
    height: 16,
    borderRadius: 8,
    overflow: 'hidden',
    backgroundColor: 'rgba(148,163,184,0.12)',
  },
  roadFill: { position: 'absolute', left: 0, top: 0, bottom: 0 },
  roadDashes: {
    ...StyleSheet.absoluteFill,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    paddingHorizontal: 6,
  },
  roadDash: { width: 8, height: 1.5, borderRadius: 1, backgroundColor: 'rgba(226,232,240,0.22)' },
  roadStop: { position: 'absolute', top: ROAD_H / 2 - 7, alignItems: 'center', justifyContent: 'center' },
  roadStopDone: { width: 14, height: 14, borderRadius: 7 },
  roadStopCurrent: { width: 16, height: 16, borderRadius: 8, top: ROAD_H / 2 - 8, borderWidth: 2, backgroundColor: 'rgba(2,6,23,0.6)' },
  roadStopTodo: { width: 6, height: 6, borderRadius: 3, top: ROAD_H / 2 - 3, backgroundColor: 'rgba(148,163,184,0.45)' },
  roadCar: { position: 'absolute', left: 0, top: ROAD_H / 2 - CAR_H / 2, width: CAR_W, height: CAR_H },
  puff: {
    position: 'absolute',
    left: 0,
    top: ROAD_H / 2 - 4,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(226,232,240,0.55)',
  },
  roadLabels: { height: 16, marginTop: 2 },
  roadLabel: {
    position: 'absolute',
    width: 72,
    textAlign: 'center',
    color: 'rgba(148,163,184,0.6)',
    fontSize: 10,
    fontWeight: '700',
  },
  roadLabelCurrent: { fontWeight: '900' },
  timelineCaption: { marginTop: 6, color: MUTED, fontSize: 11, fontWeight: '700' },
  timelineCaptionNext: { color: 'rgba(148,163,184,0.7)', fontWeight: '600' },

  proCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 12,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.05)',
    marginBottom: 10,
  },
  avatar: { width: 46, height: 46, borderRadius: 14, borderWidth: 1.5 },
  avatarFallback: { alignItems: 'center', justifyContent: 'center' },
  proCopy: { flex: 1, minWidth: 0 },
  proName: { color: '#F8FAFC', fontSize: 16, fontWeight: '800' },
  proMetaRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 3 },
  proMeta: { color: MUTED, fontSize: 12, fontWeight: '600' },
  proMetaDot: { color: MUTED, fontSize: 12 },
  verifiedChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    marginLeft: 4,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 8,
    backgroundColor: 'rgba(16,185,129,0.14)',
  },
  verifiedText: { color: GREEN, fontSize: 10, fontWeight: '800' },
  chatBtn: {
    height: 40,
    minWidth: 40,
    paddingHorizontal: 14,
    borderRadius: 20,
    overflow: 'hidden',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
  },
  chatText: { fontSize: 13, fontWeight: '700' },
  jobCard: { padding: 14, borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.05)', marginBottom: 10, gap: 10 },
  jobHead: { flexDirection: 'row', alignItems: 'flex-start', gap: 10 },
  jobHeadCopy: { flex: 1, minWidth: 0 },
  jobKicker: { color: MUTED, fontSize: 11, fontWeight: '600' },
  jobKickerRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  jobKickerPrice: { fontSize: 11, fontWeight: '700' },
  jobPrice: {
    gap: 6,
    paddingTop: 10,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(148,163,184,0.2)',
  },
  jobCancel: {
    alignSelf: 'center',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    height: 34,
    paddingHorizontal: 14,
    borderRadius: 17,
    marginTop: 6,
    backgroundColor: 'rgba(239,68,68,0.1)',
  },
  jobDetails: { gap: 10 },
  jobTitle: { color: '#F8FAFC', fontSize: 15, fontWeight: '800', letterSpacing: -0.2, marginTop: 1 },
  jobAddress: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  jobAddressText: { flex: 1, color: 'rgba(203,213,225,0.82)', fontSize: 12, fontWeight: '600' },
  chatLockBadge: {
    position: 'absolute',
    right: -5,
    bottom: -4,
    width: 12,
    height: 12,
    borderRadius: 6,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: LOCK_AMBER,
    borderWidth: 1.5,
    borderColor: '#0B1220',
  },

  payBtn: {
    marginBottom: 12,
    borderRadius: 27,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.35,
    shadowRadius: 16,
    elevation: 10,
  },
  payClip: {
    height: 54,
    borderRadius: 27,
    overflow: 'hidden',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingLeft: 20,
    paddingRight: 7,
  },
  payText: { flex: 1, color: '#04121F', fontSize: 15, fontWeight: '800', letterSpacing: -0.1 },
  payArrowDot: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(11,18,32,0.88)',
  },

  wishToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 10,
    paddingHorizontal: 4,
  },
  wishToggleText: { flex: 1, color: '#E2E8F0', fontSize: 14, fontWeight: '800' },
  wishTogglePrice: { fontSize: 15, fontWeight: '900' },
  liveMore: {
    alignSelf: 'center',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 2,
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 999,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  liveMoreText: { color: '#CBD5E1', fontSize: 12.5, fontWeight: '700' },

  detailCard: { padding: 14, borderRadius: 18, backgroundColor: 'rgba(255,255,255,0.05)', marginTop: 4 },
  detailTitle: { color: '#F8FAFC', fontSize: 16, fontWeight: '800', marginBottom: 8 },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    maxWidth: '100%',
    paddingHorizontal: 9,
    paddingVertical: 5,
    borderRadius: 10,
    backgroundColor: 'rgba(56,189,248,0.12)',
  },
  chipText: { color: '#BAE6FD', fontSize: 12, fontWeight: '700', flexShrink: 1 },
  includes: { marginTop: 10, gap: 7 },
  includeRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  includeText: { flex: 1, color: 'rgba(226,232,240,0.88)', fontSize: 13, fontWeight: '500' },

  infoRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 12, paddingHorizontal: 4 },
  infoText: { flex: 1, color: 'rgba(226,232,240,0.88)', fontSize: 13, fontWeight: '600' },

  priceCard: { padding: 14, borderRadius: 18, backgroundColor: 'rgba(255,255,255,0.05)', gap: 6 },
  priceRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  priceLabel: { color: MUTED, fontSize: 13, fontWeight: '600' },
  priceValue: { color: '#E2E8F0', fontSize: 13, fontWeight: '700' },
  priceTotalRow: {
    marginTop: 4,
    paddingTop: 8,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(148,163,184,0.25)',
  },
  priceTotalLabel: { color: '#F8FAFC', fontSize: 14, fontWeight: '800' },
  priceTotalValue: { fontSize: 17, fontWeight: '900' },

  cancelBtn: {
    marginTop: 14,
    marginBottom: 4,
    height: 46,
    borderRadius: 23,
    backgroundColor: 'rgba(239,68,68,0.12)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
  },
  cancelText: { color: '#FCA5A5', fontSize: 14, fontWeight: '700' },
  cancelLink: {
    alignSelf: 'center',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    height: 34,
    paddingHorizontal: 14,
    borderRadius: 17,
    marginTop: 4,
    backgroundColor: 'rgba(239,68,68,0.1)',
  },
  cancelLinkText: { color: '#FCA5A5', fontSize: 13, fontWeight: '700' },

  searchTrack: { height: 4, borderRadius: 2, overflow: 'hidden', backgroundColor: 'rgba(148,163,184,0.18)', marginBottom: 14 },
  searchSeg: { height: 4, borderRadius: 2 },
  payHeadRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 },
  payTitle: { flex: 1, color: '#F8FAFC', fontSize: 22, fontWeight: '800', letterSpacing: -0.4 },
  payClock: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    height: 30,
    paddingHorizontal: 10,
    borderRadius: 10,
    borderWidth: 1,
  },
  payClockText: { fontSize: 14, fontWeight: '800', fontVariant: ['tabular-nums'] },
  paySub: { color: 'rgba(203,213,225,0.8)', fontSize: 13.5, fontWeight: '600', marginTop: 4, marginBottom: 14 },
  payProRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 12,
    marginBottom: 14,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(148,163,184,0.22)',
  },
  payProNameRow: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  payPriceCol: { alignItems: 'flex-end' },
  payPrice: { color: '#F8FAFC', fontSize: 20, fontWeight: '800', letterSpacing: -0.4, fontVariant: ['tabular-nums'] },
  payPriceLabel: { color: MUTED, fontSize: 11, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.4 },
  payLinks: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, marginBottom: 6 },
  payLink: { flexDirection: 'row', alignItems: 'center', gap: 4, minHeight: 28 },
  payLinkText: { color: 'rgba(226,232,240,0.8)', fontSize: 13, fontWeight: '700' },
  payCancelText: { color: '#FCA5A5', fontSize: 13, fontWeight: '700' },
});
