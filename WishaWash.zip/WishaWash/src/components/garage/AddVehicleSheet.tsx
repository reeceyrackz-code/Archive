import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  Image,
  ActivityIndicator,
  Pressable,
  Alert,
  KeyboardAvoidingView,
  Modal,
  Platform,
  useWindowDimensions,
} from 'react-native';
import Animated, {
  FadeIn,
  FadeInDown,
  FadeOut,
  LinearTransition,
  SlideInDown,
  SlideOutDown,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from 'react-native-reanimated';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import type { SFSymbol } from 'expo-symbols';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors } from '../../constants/colors';
import { GlassSurface, GlassSymbol } from '../shared/Glass';
import { PressScale } from '../pass/PassKit';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import {
  getComplianceAccent,
  getComplianceExpiryHint,
  getDaysUntilExpiry,
  getVehicleDocComplianceState,
} from '../../utils/vehicleComplianceStatus';

const SKY = colors.SKY;

export type VehicleSize = 'small' | 'medium' | 'large' | 'xl' | 'xxl';
export type AddMode = 'reg' | 'manual';

export type VehicleFormData = {
  type: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  size: VehicleSize;
  mot_status: string;
  mot_expiry_date: string;
  tax_status: string;
  tax_due_date: string;
  image_url: string;
  image_path: string;
};

type Props = {
  visible: boolean;
  onClose: () => void;
  editingVehicleId: string | null;
  addMode: AddMode;
  setAddMode: (mode: AddMode) => void;
  formData: VehicleFormData;
  setFormData: React.Dispatch<React.SetStateAction<VehicleFormData>>;
  dvlaLoading: boolean;
  dvlaTouched: boolean;
  uploadingImage: boolean;
  onRegistrationChange: (registration: string) => void;
  onDvlaRefresh: () => Promise<void>;
  onPickImage: () => void;
  onRemoveImage: () => void;
  onSave: () => void;
  formatDatePretty: (dateOnly: string | null | undefined) => string;
  getSizeLabel: (size?: VehicleSize) => string;
  getSizeIcon: (size?: VehicleSize) => string;
};

const SIZES: readonly VehicleSize[] = ['small', 'medium', 'large', 'xl', 'xxl'];
const SIZE_SF: Record<VehicleSize, SFSymbol> = {
  small: 'car.side',
  medium: 'car.side.fill',
  large: 'suv.side.fill',
  xl: 'bus.fill',
  xxl: 'box.truck.fill',
};

function ModeSwitch({ mode, onChange }: { mode: AddMode; onChange: (m: AddMode) => void }) {
  const [w, setW] = useState(0);
  const x = useSharedValue(0);
  useEffect(() => {
    x.value = withSpring(mode === 'reg' ? 0 : w / 2, { damping: 18, stiffness: 220 });
  }, [mode, w, x]);
  const thumb = useAnimatedStyle(() => ({ transform: [{ translateX: x.value }] }));

  return (
    <View style={styles.switch} onLayout={(e) => setW(e.nativeEvent.layout.width - 8)}>
      {w > 0 ? <Animated.View style={[styles.switchThumb, { width: w / 2 }, thumb]} /> : null}
      {(
        [
          ['reg', 'Reg lookup', 'magnifyingglass', 'search'],
          ['manual', 'Manual', 'square.and.pencil', 'create-outline'],
        ] as const
      ).map(([key, label, sf, ion]) => {
        const active = mode === key;
        return (
          <Pressable
            key={key}
            style={styles.switchItem}
            onPress={() => {
              if (active) return;
              void hapticFeedback('light');
              onChange(key);
            }}
            accessibilityRole="tab"
            accessibilityState={{ selected: active }}
          >
            <GlassSymbol sf={sf} ion={ion} size={14} color={active ? '#F0F9FF' : 'rgba(186,230,253,0.7)'} />
            <Text style={[styles.switchText, active && styles.switchTextOn]}>{label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

function Field({
  label,
  value,
  onChangeText,
  placeholder,
  editable = true,
  autoCapitalize = 'words',
}: {
  label: string;
  value: string;
  onChangeText: (t: string) => void;
  placeholder: string;
  editable?: boolean;
  autoCapitalize?: 'words' | 'characters';
}) {
  return (
    <View style={styles.field}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <TextInput
        style={styles.fieldInput}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor="rgba(148,163,184,0.5)"
        editable={editable}
        autoCapitalize={autoCapitalize}
        autoCorrect={false}
      />
    </View>
  );
}

function DocTile({
  label,
  sf,
  ion,
  status,
  expiryDate,
  formatDatePretty,
}: {
  label: string;
  sf: SFSymbol;
  ion: keyof typeof Ionicons.glyphMap;
  status: string;
  expiryDate: string;
  formatDatePretty: (dateOnly: string | null | undefined) => string;
}) {
  const state = getVehicleDocComplianceState(status || null, expiryDate || null);
  const accent = getComplianceAccent(state);
  const hint = getComplianceExpiryHint(state, getDaysUntilExpiry(expiryDate || null));
  return (
    <View style={styles.docTile}>
      <View style={styles.docTop}>
        <GlassSymbol sf={sf} ion={ion} size={16} color={accent} />
        <Text style={styles.docLabel}>{label}</Text>
      </View>
      <Text style={[styles.docStatus, { color: state === 'unknown' ? '#E2E8F0' : accent }]} numberOfLines={1}>
        {hint ?? (status || 'Not checked')}
      </Text>
      <Text style={styles.docDate} numberOfLines={1}>
        {expiryDate ? formatDatePretty(expiryDate) : '—'}
      </Text>
    </View>
  );
}

export default function AddVehicleSheet({
  visible,
  onClose,
  editingVehicleId,
  addMode,
  setAddMode,
  formData,
  setFormData,
  dvlaLoading,
  dvlaTouched,
  uploadingImage,
  onRegistrationChange,
  onDvlaRefresh,
  onPickImage,
  onRemoveImage,
  onSave,
  formatDatePretty,
  getSizeLabel,
  getSizeIcon,
}: Props) {
  const insets = useSafeAreaInsets();
  const { height } = useWindowDimensions();
  const isEdit = Boolean(editingVehicleId);
  const regMode = !isEdit && addMode === 'reg';
  const autoFill = regMode ? !dvlaLoading : true;
  const found = regMode && dvlaTouched && Boolean(formData.make);

  return (
    <Modal visible={visible} transparent animationType="none" statusBarTranslucent onRequestClose={onClose}>
      {visible ? (
        <KeyboardAvoidingView style={styles.root} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
          <Animated.View entering={FadeIn.duration(220)} exiting={FadeOut.duration(180)} style={StyleSheet.absoluteFill}>
            <BlurView intensity={30} tint="dark" style={StyleSheet.absoluteFill} />
            <Pressable style={[StyleSheet.absoluteFill, styles.scrim]} onPress={onClose} />
          </Animated.View>

          <Animated.View
            entering={SlideInDown.springify().damping(18).stiffness(160)}
            exiting={SlideOutDown.duration(220)}
            style={[styles.sheetWrap, { maxHeight: height - insets.top - 24 }]}
          >
            <GlassSurface
              style={[styles.sheet, { paddingBottom: Math.max(insets.bottom, 16) + 8 }]}
              tint="rgba(6,16,32,0.8)"
            >
              <LinearGradient
                colors={['rgba(56,189,248,0.16)', 'rgba(56,189,248,0)']}
                style={styles.sheetGlow}
                pointerEvents="none"
              />
              <View style={styles.handle} />

              <View style={styles.head}>
                <GlassSurface style={styles.headIcon} tint="rgba(56,189,248,0.28)">
                  <GlassSymbol
                    sf={isEdit ? 'car.side.fill' : 'plus'}
                    ion={isEdit ? 'car-sport' : 'add'}
                    size={18}
                    color="#E0F2FE"
                  />
                </GlassSurface>
                <View style={styles.headText}>
                  <Text style={styles.title}>{isEdit ? 'Edit vehicle' : 'Add a vehicle'}</Text>
                  <Text style={styles.subtitle}>
                    {isEdit ? 'Update the photo, size or DVLA details' : 'Pop in your reg and we do the rest'}
                  </Text>
                </View>
                <PressScale onPress={onClose} accessibilityLabel="Close">
                  <GlassSurface style={styles.close} interactive>
                    <GlassSymbol sf="xmark" ion="close" size={13} color="rgba(226,232,240,0.85)" />
                  </GlassSurface>
                </PressScale>
              </View>

              {!isEdit ? <ModeSwitch mode={addMode} onChange={setAddMode} /> : null}

              <ScrollView
                style={styles.scroll}
                contentContainerStyle={styles.scrollContent}
                showsVerticalScrollIndicator={false}
                keyboardShouldPersistTaps="handled"
                keyboardDismissMode="on-drag"
              >
                <Animated.View layout={LinearTransition.springify().damping(20)} style={styles.plateBlock}>
                  <View style={styles.plate}>
                    <View style={styles.plateBand}>
                      <Text style={styles.plateBandText}>UK</Text>
                    </View>
                    <TextInput
                      style={[styles.plateInput, !regMode && styles.plateInputSmall]}
                      value={formData.registration}
                      onChangeText={onRegistrationChange}
                      placeholder="AB12 CDE"
                      placeholderTextColor="rgba(15,23,42,0.32)"
                      autoCapitalize="characters"
                      autoCorrect={false}
                      editable={!dvlaLoading}
                    />
                  </View>
                  {regMode ? (
                    dvlaLoading ? (
                      <Animated.View entering={FadeIn} style={styles.lookup}>
                        <ActivityIndicator size="small" color={SKY} />
                        <Text style={styles.lookupText}>Checking DVLA…</Text>
                      </Animated.View>
                    ) : found ? (
                      <Animated.View entering={FadeInDown.springify().damping(16)} style={styles.lookup}>
                        <GlassSymbol sf="checkmark.circle.fill" ion="checkmark-circle" size={15} color="#34D399" bounce />
                        <Text style={[styles.lookupText, { color: '#A7F3D0' }]} numberOfLines={1}>
                          Found {formData.make}
                          {formData.color ? ` · ${formData.color}` : ''}
                        </Text>
                      </Animated.View>
                    ) : (
                      <Text style={styles.lookupHint}>Make, colour, size, MOT & tax fill in automatically</Text>
                    )
                  ) : null}
                </Animated.View>

                <Pressable
                  onPress={uploadingImage ? undefined : onPickImage}
                  style={[styles.photo, formData.image_url ? styles.photoFilled : null]}
                  accessibilityLabel={formData.image_url ? 'Change photo' : 'Add a photo'}
                >
                  {formData.image_url ? (
                    <>
                      <Image source={{ uri: formData.image_url }} style={StyleSheet.absoluteFill} resizeMode="cover" />
                      <View style={styles.photoTools}>
                        <GlassSurface style={styles.photoTool} interactive>
                          <GlassSymbol sf="camera.fill" ion="camera" size={13} color="#F8FAFC" />
                        </GlassSurface>
                        <PressScale onPress={onRemoveImage} accessibilityLabel="Remove photo">
                          <GlassSurface style={styles.photoTool} interactive tint="rgba(127,29,29,0.4)">
                            <GlassSymbol sf="trash.fill" ion="trash" size={13} color="#FCA5A5" />
                          </GlassSurface>
                        </PressScale>
                      </View>
                    </>
                  ) : uploadingImage ? (
                    <ActivityIndicator size="small" color={SKY} />
                  ) : (
                    <>
                      <GlassSymbol sf="camera.fill" ion="camera-outline" size={20} color={SKY} />
                      <Text style={styles.photoText}>Add a photo</Text>
                    </>
                  )}
                  {uploadingImage && formData.image_url ? (
                    <View style={styles.photoBusy}>
                      <ActivityIndicator size="small" color="#F8FAFC" />
                    </View>
                  ) : null}
                </Pressable>

                <View style={styles.fieldsRow}>
                  <Field
                    label="Make & model"
                    value={formData.make}
                    onChangeText={(t) => setFormData((p) => ({ ...p, make: t }))}
                    placeholder={regMode ? 'From DVLA' : 'Ford Fiesta'}
                    editable={autoFill}
                  />
                </View>
                <View style={styles.fieldsRow}>
                  <Field
                    label="Colour"
                    value={formData.color}
                    onChangeText={(t) => setFormData((p) => ({ ...p, color: t }))}
                    placeholder={regMode ? 'From DVLA' : 'Blue'}
                    editable={autoFill}
                  />
                </View>

                <View style={styles.sectionHead}>
                  <Text style={styles.sectionLabel}>Size</Text>
                  {dvlaTouched ? (
                    <View style={styles.lockTag}>
                      <GlassSymbol sf="lock.fill" ion="lock-closed" size={10} color="rgba(148,163,184,0.9)" />
                      <Text style={styles.lockText}>Set from DVLA</Text>
                    </View>
                  ) : (
                    <Text style={styles.sectionHint}>Affects pricing</Text>
                  )}
                </View>
                <ScrollView
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={styles.sizeRow}
                  pointerEvents={dvlaTouched ? 'none' : 'auto'}
                >
                  {SIZES.map((size) => {
                    const active = formData.size === size;
                    return (
                      <Pressable
                        key={size}
                        onPress={() => {
                          if (dvlaTouched || active) return;
                          void hapticFeedback('light');
                          setFormData((p) => ({ ...p, size }));
                        }}
                        style={[styles.sizeChip, active && styles.sizeChipOn, dvlaTouched && !active && styles.sizeChipMuted]}
                      >
                        <GlassSymbol
                          sf={SIZE_SF[size]}
                          ion={getSizeIcon(size) as keyof typeof Ionicons.glyphMap}
                          size={15}
                          color={active ? '#F0F9FF' : 'rgba(186,230,253,0.75)'}
                        />
                        <Text style={[styles.sizeText, active && styles.sizeTextOn]}>
                          {getSizeLabel(size).replace(' (HGV)', '')}
                        </Text>
                      </Pressable>
                    );
                  })}
                </ScrollView>

                <View style={styles.sectionHead}>
                  <Text style={styles.sectionLabel}>DVLA</Text>
                  <Pressable
                    onPress={() => {
                      if (!formData.registration.trim()) {
                        Alert.alert('Missing reg', 'Enter a registration first.');
                        return;
                      }
                      void onDvlaRefresh();
                    }}
                    disabled={dvlaLoading}
                    hitSlop={8}
                    style={styles.refresh}
                    accessibilityLabel="Refresh DVLA details"
                  >
                    {dvlaLoading ? (
                      <ActivityIndicator size="small" color={SKY} />
                    ) : (
                      <>
                        <GlassSymbol sf="arrow.clockwise" ion="refresh" size={12} color={SKY} />
                        <Text style={styles.refreshText}>Refresh</Text>
                      </>
                    )}
                  </Pressable>
                </View>
                <View style={styles.docRow}>
                  <DocTile
                    label="MOT"
                    sf="checkmark.shield.fill"
                    ion="shield-checkmark"
                    status={formData.mot_status}
                    expiryDate={formData.mot_expiry_date}
                    formatDatePretty={formatDatePretty}
                  />
                  <DocTile
                    label="Tax"
                    sf="doc.text.fill"
                    ion="receipt"
                    status={formData.tax_status}
                    expiryDate={formData.tax_due_date}
                    formatDatePretty={formatDatePretty}
                  />
                </View>
              </ScrollView>

              <View style={styles.footer}>
                <PressScale onPress={uploadingImage ? undefined : onSave} accessibilityLabel={isEdit ? 'Save changes' : 'Add to garage'}>
                  <GlassSurface style={styles.save} tint="rgba(56,189,248,0.42)" interactive>
                    <GlassSymbol sf="checkmark" ion="checkmark" size={15} color="#F0F9FF" />
                    <Text style={styles.saveText}>{isEdit ? 'Save changes' : 'Add to garage'}</Text>
                  </GlassSurface>
                </PressScale>
              </View>
            </GlassSurface>
          </Animated.View>
        </KeyboardAvoidingView>
      ) : null}
    </Modal>
  );
}

const FIELD_BG = 'rgba(255,255,255,0.06)';

const styles = StyleSheet.create({
  root: { flex: 1, justifyContent: 'flex-end' },
  scrim: { backgroundColor: 'rgba(2,6,23,0.45)' },
  sheetWrap: { flexShrink: 1 },
  sheet: { flexShrink: 1, borderTopLeftRadius: 32, borderTopRightRadius: 32, paddingTop: 8 },
  sheetGlow: { position: 'absolute', left: 0, right: 0, top: 0, height: 140 },
  handle: {
    alignSelf: 'center',
    width: 38,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(226,232,240,0.28)',
    marginBottom: 12,
  },

  head: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 20, marginBottom: 14 },
  headIcon: { width: 40, height: 40, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  headText: { flex: 1, minWidth: 0 },
  title: { color: '#F8FAFC', fontSize: 18, fontWeight: '800' },
  subtitle: { color: 'rgba(148,163,184,0.95)', fontSize: 12, fontWeight: '500', marginTop: 1 },
  close: { width: 30, height: 30, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },

  switch: {
    flexDirection: 'row',
    marginHorizontal: 20,
    marginBottom: 14,
    padding: 4,
    borderRadius: 16,
    backgroundColor: FIELD_BG,
  },
  switchThumb: {
    position: 'absolute',
    top: 4,
    bottom: 4,
    left: 4,
    borderRadius: 12,
    backgroundColor: 'rgba(56,189,248,0.32)',
  },
  switchItem: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, height: 34 },
  switchText: { color: 'rgba(186,230,253,0.7)', fontSize: 13, fontWeight: '700' },
  switchTextOn: { color: '#F0F9FF' },

  scroll: { flexGrow: 0, flexShrink: 1 },
  scrollContent: { paddingHorizontal: 20, paddingBottom: 6, gap: 14 },

  plateBlock: { gap: 8 },
  plate: { flexDirection: 'row', alignItems: 'stretch', borderRadius: 12, overflow: 'hidden', backgroundColor: '#F8D70C' },
  plateBand: { width: 30, backgroundColor: '#003399', alignItems: 'center', justifyContent: 'center' },
  plateBandText: { color: '#FFF', fontSize: 9, fontWeight: '900' },
  plateInput: {
    flex: 1,
    color: '#0F172A',
    fontSize: 22,
    fontWeight: '900',
    letterSpacing: 2,
    textAlign: 'center',
    paddingVertical: 12,
    paddingRight: 30,
  },
  plateInputSmall: { fontSize: 18, paddingVertical: 9 },
  lookup: { flexDirection: 'row', alignItems: 'center', gap: 6, minHeight: 18 },
  lookupText: { color: SKY, fontSize: 12, fontWeight: '700', flexShrink: 1 },
  lookupHint: { color: 'rgba(148,163,184,0.85)', fontSize: 11, fontWeight: '600', minHeight: 18 },

  photo: {
    height: 96,
    borderRadius: 20,
    overflow: 'hidden',
    backgroundColor: FIELD_BG,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
  },
  photoFilled: { height: 150 },
  photoText: { color: 'rgba(186,230,253,0.85)', fontSize: 12, fontWeight: '700' },
  photoTools: { position: 'absolute', right: 10, bottom: 10, flexDirection: 'row', gap: 8 },
  photoTool: { width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  photoBusy: {
    ...StyleSheet.absoluteFill,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(2,6,23,0.45)',
  },

  fieldsRow: { flexDirection: 'row', gap: 10 },
  field: { flex: 1, borderRadius: 16, backgroundColor: FIELD_BG, paddingHorizontal: 14, paddingTop: 9, paddingBottom: 4 },
  fieldLabel: { color: 'rgba(148,163,184,0.9)', fontSize: 10.5, fontWeight: '700' },
  fieldInput: { color: '#F8FAFC', fontSize: 15, fontWeight: '600', paddingVertical: 6 },

  sectionHead: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: -6 },
  sectionLabel: { color: 'rgba(226,232,240,0.9)', fontSize: 12, fontWeight: '700' },
  sectionHint: { color: 'rgba(148,163,184,0.75)', fontSize: 11, fontWeight: '600' },
  lockTag: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  lockText: { color: 'rgba(148,163,184,0.9)', fontSize: 11, fontWeight: '600' },

  sizeRow: { gap: 8 },
  sizeChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    height: 36,
    paddingHorizontal: 14,
    borderRadius: 18,
    backgroundColor: FIELD_BG,
  },
  sizeChipOn: { backgroundColor: 'rgba(56,189,248,0.34)' },
  sizeChipMuted: { opacity: 0.45 },
  sizeText: { color: 'rgba(186,230,253,0.8)', fontSize: 12, fontWeight: '700' },
  sizeTextOn: { color: '#F0F9FF' },

  refresh: { flexDirection: 'row', alignItems: 'center', gap: 4, minHeight: 20 },
  refreshText: { color: SKY, fontSize: 11, fontWeight: '700' },
  docRow: { flexDirection: 'row', gap: 10 },
  docTile: { flex: 1, borderRadius: 18, backgroundColor: FIELD_BG, padding: 12, gap: 3 },
  docTop: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 2 },
  docLabel: { color: 'rgba(148,163,184,0.95)', fontSize: 11, fontWeight: '700' },
  docStatus: { fontSize: 13, fontWeight: '700' },
  docDate: { color: 'rgba(148,163,184,0.85)', fontSize: 11, fontWeight: '600' },

  footer: { paddingHorizontal: 20, paddingTop: 12 },
  save: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    height: 52,
    borderRadius: 26,
  },
  saveText: { color: '#F0F9FF', fontSize: 15, fontWeight: '800' },
});
