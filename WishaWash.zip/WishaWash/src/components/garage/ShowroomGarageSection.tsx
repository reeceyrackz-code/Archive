import { useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  ActivityIndicator,
  useWindowDimensions,
} from 'react-native';
import Animated, {
  Extrapolation,
  FadeIn,
  FadeInDown,
  interpolate,
  useAnimatedScrollHandler,
  useAnimatedStyle,
  useSharedValue,
  type SharedValue,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import type { SFSymbol } from 'expo-symbols';
import { colors } from '../../constants/colors';
import { getDashboardHeaderTopOffset } from '../../constants/layoutConstants';
import { useTabBarBottomReserve } from '../../contexts/TabBarInsetContext';
import AnimatedProgress from '../booking/AnimatedProgress';
import { GlassSurface, GlassSymbol } from '../shared/Glass';
import { PressScale } from '../pass/PassKit';
import { fetchVehicleStats, type VehicleStats } from '../../utils/vehicleStats';
import { careScoreColor, computeGarageCareScore, formatLastWashLabel } from '../../utils/garageCareScore';
import {
  getComplianceAccent,
  getDaysUntilExpiry,
  getVehicleDocComplianceState,
  getWorstVehicleComplianceState,
} from '../../utils/vehicleComplianceStatus';
import { hapticFeedback } from '../../services/HapticFeedbackService';

const SKY = colors.SKY;
const H_PAD = 16;

export type GarageVehicleSize = 'small' | 'medium' | 'large' | 'xl' | 'xxl';

export type GarageVehicle = {
  id: string;
  type: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  is_default: boolean;
  size?: GarageVehicleSize;
  mot_status?: string | null;
  mot_expiry_date?: string | null;
  tax_status?: string | null;
  tax_due_date?: string | null;
  dvla_last_checked_at?: string | null;
  image_url?: string | null;
  image_path?: string | null;
  photo?: string | null;
};

function getSizeLabel(size?: GarageVehicleSize): string {
  switch (size) {
    case 'small':
      return 'Small';
    case 'large':
      return 'Large';
    case 'xl':
      return 'XL';
    case 'xxl':
      return 'XXL';
    default:
      return 'Medium';
  }
}

function formatRegPlate(reg: string): string {
  const clean = reg.replace(/\s/g, '').toUpperCase();
  if (clean.length <= 4) return clean;
  if (clean.length <= 7) return `${clean.slice(0, 4)} ${clean.slice(4)}`;
  return `${clean.slice(0, 4)} ${clean.slice(4, 7)}`;
}

function formatShortDate(dateOnly?: string | null): string | null {
  if (!dateOnly) return null;
  const d = new Date(`${dateOnly}T00:00:00`);
  if (Number.isNaN(d.getTime())) return null;
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
}

function docLine(status?: string | null, expiry?: string | null) {
  const state = getVehicleDocComplianceState(status, expiry);
  const days = getDaysUntilExpiry(expiry);
  const date = formatShortDate(expiry);
  let text: string;
  if (state === 'expired') text = days !== null && days < 0 ? `Expired ${Math.abs(days)}d ago` : 'Expired';
  else if (state === 'warning') text = days === 0 ? 'Due today' : `Due in ${days}d`;
  else if (date) text = `Until ${date}`;
  else text = status ? String(status) : 'Not checked';
  return { state, text, color: getComplianceAccent(state) };
}

function vehicleName(v: GarageVehicle) {
  return [v.make, v.model].filter(Boolean).join(' ').trim() || 'Your vehicle';
}

function UkPlate({ registration }: { registration: string }) {
  return (
    <View style={styles.plate}>
      <View style={styles.plateBand}>
        <Text style={styles.plateBandText}>UK</Text>
      </View>
      <Text style={styles.plateText}>{formatRegPlate(registration)}</Text>
    </View>
  );
}

const IDENTITY_H = 80;
const PAGE_GAP = 10;
const MIN_STAGE_H = 96;
const MAX_STAGE_H = 230;

function ShowroomPage({
  vehicle,
  index,
  pageW,
  scrollX,
  stageH,
}: {
  vehicle: GarageVehicle;
  index: number;
  pageW: number;
  scrollX: SharedValue<number>;
  stageH: number;
}) {
  const imageUri = vehicle.image_url || vehicle.photo || null;
  const stageStyle = useAnimatedStyle(() => {
    const d = scrollX.value / pageW - index;
    return {
      opacity: interpolate(Math.abs(d), [0, 1], [1, 0.35], Extrapolation.CLAMP),
      transform: [
        { translateX: d * pageW * 0.18 },
        { scale: interpolate(Math.abs(d), [0, 1], [1, 0.86], Extrapolation.CLAMP) },
      ],
    };
  });

  return (
    <View style={[styles.page, { width: pageW }]}>
      <Animated.View style={[styles.stage, { height: stageH }, stageStyle]}>
        <LinearGradient
          colors={['rgba(56,189,248,0.22)', 'rgba(56,189,248,0)']}
          start={{ x: 0.5, y: 1 }}
          end={{ x: 0.5, y: 0 }}
          style={styles.stageGlow}
          pointerEvents="none"
        />
        {imageUri ? (
          <Image source={{ uri: imageUri }} style={styles.photo} resizeMode="cover" />
        ) : (
          <View style={styles.photoEmpty}>
            <GlassSymbol sf="car.side.fill" ion="car-sport" size={84} color="rgba(186,230,253,0.75)" />
          </View>
        )}
        <View style={styles.floorShadow} pointerEvents="none" />
        {vehicle.is_default ? (
          <GlassSurface style={styles.defaultPill} tint="rgba(16,185,129,0.22)">
            <GlassSymbol sf="star.fill" ion="star" size={11} color="#6EE7B7" />
            <Text style={styles.defaultPillText}>Default</Text>
          </GlassSurface>
        ) : null}
      </Animated.View>

      <View style={styles.identity}>
        <UkPlate registration={vehicle.registration} />
        <Text style={styles.name} numberOfLines={1}>
          {vehicleName(vehicle)}
        </Text>
        <Text style={styles.meta} numberOfLines={1}>
          {[vehicle.type, vehicle.color, vehicle.size ? `${getSizeLabel(vehicle.size)} size` : null]
            .filter(Boolean)
            .join(' · ')}
        </Text>
      </View>
    </View>
  );
}

function DocRow({
  sf,
  ion,
  label,
  status,
  expiry,
}: {
  sf: SFSymbol;
  ion: keyof typeof Ionicons.glyphMap;
  label: string;
  status?: string | null;
  expiry?: string | null;
}) {
  const line = docLine(status, expiry);
  return (
    <View style={styles.docRow}>
      <GlassSymbol sf={sf} ion={ion} size={18} color={line.color} bounce={line.state === 'expired'} />
      <Text style={styles.docLabel}>{label}</Text>
      <Text style={[styles.docValue, { color: line.state === 'good' ? '#E2E8F0' : line.color }]} numberOfLines={1}>
        {line.text}
      </Text>
    </View>
  );
}

function RoundAction({
  sf,
  ion,
  color,
  label,
  onPress,
  busy,
  disabled,
}: {
  sf: SFSymbol;
  ion: keyof typeof Ionicons.glyphMap;
  color: string;
  label: string;
  onPress: () => void;
  busy?: boolean;
  disabled?: boolean;
}) {
  return (
    <PressScale onPress={disabled ? undefined : onPress} accessibilityLabel={label} style={styles.roundCell}>
      <GlassSurface style={styles.round} interactive>
        {busy ? <ActivityIndicator size="small" color={color} /> : <GlassSymbol sf={sf} ion={ion} size={18} color={color} />}
      </GlassSurface>
      <Text style={styles.roundLabel}>{label}</Text>
    </PressScale>
  );
}

type Props = {
  loading: boolean;
  vehicles: GarageVehicle[];
  insets: { top?: number; bottom?: number };
  busyId: string | null;
  onAddVehicle: () => void;
  onEditVehicle: (v: GarageVehicle) => void;
  onSetDefault: (id: string) => Promise<void>;
  onDelete: (v: GarageVehicle) => void;
};

export default function ShowroomGarageSection({
  loading,
  vehicles,
  insets,
  busyId,
  onAddVehicle,
  onEditVehicle,
  onSetDefault,
  onDelete,
}: Props) {
  const { width: pageW } = useWindowDimensions();
  const [statsById, setStatsById] = useState<Record<string, VehicleStats>>({});
  const [page, setPage] = useState(0);
  const [carouselH, setCarouselH] = useState(0);
  const tabBarReserve = useTabBarBottomReserve();
  const scrollX = useSharedValue(0);

  useEffect(() => {
    if (!vehicles.length) {
      setStatsById({});
      return;
    }
    let cancelled = false;
    void (async () => {
      const pairs = await Promise.all(vehicles.map(async (v) => [v.id, await fetchVehicleStats(v.id)] as const));
      if (!cancelled) setStatsById(Object.fromEntries(pairs));
    })();
    return () => {
      cancelled = true;
    };
  }, [vehicles]);

  const ordered = useMemo(
    () => [...vehicles].sort((a, b) => Number(b.is_default) - Number(a.is_default)),
    [vehicles]
  );
  const selected = ordered[Math.min(page, Math.max(0, ordered.length - 1))] ?? null;

  const headerSubtitle = useMemo(() => {
    if (!vehicles.length) return 'Add your first ride to start booking';
    const countLabel = vehicles.length === 1 ? '1 vehicle' : `${vehicles.length} vehicles`;
    const worst = selected ? getWorstVehicleComplianceState(selected) : 'unknown';
    if (worst === 'expired') return `${countLabel} · MOT or tax expired`;
    if (worst === 'warning') return `${countLabel} · MOT or tax due soon`;
    if (worst === 'good') return `${countLabel} · Ready to book`;
    return `${countLabel} · Check MOT & tax`;
  }, [vehicles.length, selected]);

  const onScroll = useAnimatedScrollHandler((e) => {
    scrollX.value = e.contentOffset.x;
  });

  const bottomPad = tabBarReserve > 0 ? tabBarReserve + 12 : Math.max(insets.bottom ?? 0, 12) + 12;
  const topPad = getDashboardHeaderTopOffset(insets);

  if (loading) {
    return (
      <View style={[styles.screen, { paddingTop: topPad, paddingBottom: bottomPad, paddingHorizontal: H_PAD }]}>
        <GarageHeader subtitle="Loading your garage…" />
        <View style={styles.loadingWrap}>
          <ActivityIndicator size="small" color={SKY} />
        </View>
      </View>
    );
  }

  if (!selected) {
    return (
      <View style={[styles.screen, { paddingTop: topPad, paddingBottom: bottomPad, paddingHorizontal: H_PAD }]}>
        <GarageHeader subtitle="No vehicles parked yet" />
        <Animated.View entering={FadeInDown.springify().damping(18)} style={styles.empty}>
          <GlassSymbol sf="car.side.fill" ion="car-sport" size={72} color="rgba(186,230,253,0.6)" bounce />
          <Text style={styles.emptyTitle}>Empty bay</Text>
          <Text style={styles.emptyText}>
            Add your reg and we'll pull the MOT, tax and size for you.
          </Text>
          <PressScale onPress={onAddVehicle} accessibilityLabel="Add your first vehicle">
            <GlassSurface style={styles.primaryBtn} tint="rgba(56,189,248,0.35)" interactive>
              <GlassSymbol sf="plus" ion="add" size={15} color="#F0F9FF" />
              <Text style={styles.primaryBtnText}>Add your first vehicle</Text>
            </GlassSurface>
          </PressScale>
        </Animated.View>
      </View>
    );
  }

  const stats = statsById[selected.id];
  const careScore = computeGarageCareScore(selected, stats);
  const ringColor = careScoreColor(careScore, selected);
  const isBusy = busyId === selected.id;

  const dotsH = ordered.length > 1 ? 14 : 0;
  const stageH = carouselH
    ? Math.min(MAX_STAGE_H, Math.max(MIN_STAGE_H, carouselH - IDENTITY_H - PAGE_GAP - dotsH))
    : 160;

  return (
    <View style={[styles.screen, { paddingTop: topPad, paddingBottom: bottomPad }]}>
      <View style={styles.padded}>
        <GarageHeader subtitle={headerSubtitle} />
      </View>

      <View
        style={styles.carouselArea}
        onLayout={(e) => {
          const h = Math.round(e.nativeEvent.layout.height);
          setCarouselH((prev) => (Math.abs(prev - h) < 2 ? prev : h));
        }}
      >
        <Animated.ScrollView
          horizontal
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          scrollEventThrottle={16}
          onScroll={onScroll}
          style={styles.carousel}
          onMomentumScrollEnd={(e) => {
            const next = Math.round(e.nativeEvent.contentOffset.x / pageW);
            if (next !== page) {
              setPage(next);
              void hapticFeedback('light');
            }
          }}
        >
          {ordered.map((v, i) => (
            <ShowroomPage key={v.id} vehicle={v} index={i} pageW={pageW} scrollX={scrollX} stageH={stageH} />
          ))}
        </Animated.ScrollView>

        {ordered.length > 1 ? (
          <View style={styles.dots}>
            {ordered.map((v, i) => (
              <View key={v.id} style={[styles.dot, i === page && styles.dotOn]} />
            ))}
          </View>
        ) : null}
      </View>

      <Animated.View key={selected.id} entering={FadeIn.duration(220)} style={[styles.padded, styles.details]}>
        <GlassSurface style={styles.panel}>
          <View style={styles.scoreCol}>
            <AnimatedProgress
              progress={careScore}
              size={62}
              strokeWidth={5}
              showPercentage
              percentageFontSize={13}
              color={ringColor}
            />
            <Text style={styles.scoreLabel}>Care score</Text>
          </View>
          <View style={styles.docs}>
            <DocRow
              sf="checkmark.shield.fill"
              ion="shield-checkmark"
              label="MOT"
              status={selected.mot_status ?? null}
              expiry={selected.mot_expiry_date ?? null}
            />
            <DocRow
              sf="doc.text.fill"
              ion="receipt"
              label="Tax"
              status={selected.tax_status ?? null}
              expiry={selected.tax_due_date ?? null}
            />
            <View style={styles.docRow}>
              <GlassSymbol sf="drop.fill" ion="water" size={18} color={SKY} />
              <Text style={styles.docLabel}>Wash</Text>
              <Text style={styles.docValue} numberOfLines={1}>
                {formatLastWashLabel(stats)}
                {stats?.washCount ? ` · ${stats.washCount} total` : ''}
              </Text>
            </View>
          </View>
        </GlassSurface>

        <PressScale
          onPress={() => {
            void hapticFeedback('medium');
            router.push('/owner/booking/create');
          }}
          accessibilityLabel="Book a wash"
        >
          <GlassSurface style={styles.primaryBtn} tint="rgba(56,189,248,0.38)" interactive>
            <GlassSymbol sf="sparkles" ion="sparkles" size={16} color="#F0F9FF" />
            <Text style={styles.primaryBtnText}>Book a wash</Text>
          </GlassSurface>
        </PressScale>

        <View style={styles.roundRow}>
          <RoundAction
            sf="pencil"
            ion="create-outline"
            color={SKY}
            label="Edit"
            disabled={Boolean(busyId)}
            onPress={() => onEditVehicle(selected)}
          />
          {!selected.is_default ? (
            <RoundAction
              sf="star"
              ion="star-outline"
              color="#6EE7B7"
              label="Make default"
              busy={isBusy}
              disabled={Boolean(busyId)}
              onPress={() => void onSetDefault(selected.id)}
            />
          ) : null}
          <RoundAction
            sf="plus"
            ion="add"
            color="#E2E8F0"
            label="Add car"
            onPress={onAddVehicle}
          />
          <RoundAction
            sf="trash"
            ion="trash-outline"
            color="#F87171"
            label="Remove"
            disabled={Boolean(busyId)}
            onPress={() => onDelete(selected)}
          />
        </View>
      </Animated.View>
    </View>
  );
}

function GarageHeader({ subtitle }: { subtitle: string }) {
  return (
    <View style={styles.header}>
      <Text style={styles.kicker}>YOUR GARAGE</Text>
      <Text style={styles.subtitle} numberOfLines={1}>
        {subtitle}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  padded: { paddingHorizontal: H_PAD },
  loadingWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', minHeight: 200 },
  header: { marginBottom: 8, gap: 2 },
  kicker: { fontSize: 9, fontWeight: '800', color: 'rgba(186,230,253,0.92)', letterSpacing: 1.2 },
  subtitle: { color: 'rgba(148,163,184,0.95)', fontSize: 11, fontWeight: '600' },

  carouselArea: { flex: 1, minHeight: 0, justifyContent: 'center' },
  carousel: { flexGrow: 0 },
  page: { paddingHorizontal: H_PAD, gap: PAGE_GAP },
  stage: { borderRadius: 28, overflow: 'hidden', justifyContent: 'flex-end' },
  stageGlow: { ...StyleSheet.absoluteFill },
  photo: { ...StyleSheet.absoluteFill, borderRadius: 28 },
  photoEmpty: { ...StyleSheet.absoluteFill, alignItems: 'center', justifyContent: 'center' },
  floorShadow: {
    position: 'absolute',
    left: '18%',
    right: '18%',
    bottom: 10,
    height: 10,
    borderRadius: 999,
    backgroundColor: 'rgba(2,6,23,0.45)',
  },
  defaultPill: {
    position: 'absolute',
    top: 12,
    left: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    height: 26,
    borderRadius: 13,
  },
  defaultPillText: { color: '#A7F3D0', fontSize: 11, fontWeight: '700' },

  identity: { alignItems: 'center', gap: 6 },
  plate: {
    flexDirection: 'row',
    alignItems: 'stretch',
    borderRadius: 7,
    overflow: 'hidden',
    backgroundColor: '#F8D70C',
  },
  plateBand: { width: 22, backgroundColor: '#003399', alignItems: 'center', justifyContent: 'center' },
  plateBandText: { color: '#FFFFFF', fontSize: 8, fontWeight: '900' },
  plateText: {
    color: '#0F172A',
    fontSize: 15,
    fontWeight: '900',
    letterSpacing: 1.6,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  name: { color: '#F8FAFC', fontSize: 18, fontWeight: '800' },
  meta: { color: 'rgba(148,163,184,0.9)', fontSize: 12, fontWeight: '600' },

  dots: { flexDirection: 'row', justifyContent: 'center', gap: 6, marginTop: 8 },
  dot: { width: 6, height: 6, borderRadius: 3, backgroundColor: 'rgba(148,163,184,0.35)' },
  dotOn: { width: 18, backgroundColor: SKY },

  details: { gap: 12, marginTop: 10 },
  panel: { flexDirection: 'row', alignItems: 'center', gap: 16, paddingHorizontal: 16, paddingVertical: 12, borderRadius: 24 },
  scoreCol: { alignItems: 'center', gap: 4 },
  scoreLabel: { color: 'rgba(203,213,225,0.8)', fontSize: 10, fontWeight: '700' },
  docs: { flex: 1, gap: 10 },
  docRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  docLabel: { color: 'rgba(148,163,184,0.95)', fontSize: 12, fontWeight: '700', width: 38 },
  docValue: { flex: 1, color: '#E2E8F0', fontSize: 12, fontWeight: '700', textAlign: 'right' },

  primaryBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    height: 50,
    paddingHorizontal: 22,
    borderRadius: 25,
  },
  primaryBtnText: { color: '#F0F9FF', fontSize: 15, fontWeight: '800' },

  roundRow: { flexDirection: 'row', justifyContent: 'space-evenly' },
  roundCell: { alignItems: 'center' },
  round: { width: 46, height: 46, borderRadius: 23, alignItems: 'center', justifyContent: 'center' },
  roundLabel: { color: 'rgba(203,213,225,0.85)', fontSize: 11, fontWeight: '600', marginTop: 5, textAlign: 'center' },

  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10, paddingBottom: 40 },
  emptyTitle: { color: '#F8FAFC', fontSize: 18, fontWeight: '800', marginTop: 6 },
  emptyText: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 13,
    fontWeight: '500',
    textAlign: 'center',
    lineHeight: 18,
    maxWidth: 260,
    marginBottom: 8,
  },
});
