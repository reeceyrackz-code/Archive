import { ActivityIndicator, Pressable, StyleSheet, Text, View, type StyleProp, type ViewStyle } from 'react-native';
import Animated, { useAnimatedStyle, useSharedValue, withSpring } from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';

type Props = Readonly<{
  label: string;
  onPress: () => void;
  loading?: boolean;
  disabled?: boolean;
  icon?: keyof typeof Ionicons.glyphMap;
  style?: StyleProp<ViewStyle>;
}>;

/** Sky gradient pill CTA shared by the auth landing and sheets. */
export default function AuthSubmitButton({
  label,
  onPress,
  loading = false,
  disabled = false,
  icon = 'arrow-forward',
  style,
}: Props) {
  const scale = useSharedValue(1);
  const pressStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  const inactive = disabled || loading;

  return (
    <Animated.View style={[styles.wrap, inactive && styles.wrapInactive, pressStyle, style]}>
      <Pressable
        onPress={onPress}
        disabled={inactive}
        onPressIn={() => {
          scale.value = withSpring(0.97, { damping: 18, stiffness: 320 });
        }}
        onPressOut={() => {
          scale.value = withSpring(1, { damping: 14, stiffness: 260 });
        }}
        style={styles.btn}
        accessibilityRole="button"
        accessibilityLabel={label}
        accessibilityState={{ disabled: inactive, busy: loading }}
      >
        <LinearGradient
          colors={['#38BDF8', '#0EA5E9']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={StyleSheet.absoluteFill}
        />
        <LinearGradient
          colors={['rgba(255,255,255,0.3)', 'rgba(255,255,255,0)']}
          start={{ x: 0.5, y: 0 }}
          end={{ x: 0.5, y: 1 }}
          style={styles.sheen}
        />
        {loading ? <ActivityIndicator color="#04121F" /> : null}
        <Text style={styles.label}>{label}</Text>
        {!loading ? (
          <View style={styles.iconWell}>
            <Ionicons name={icon} size={16} color="#04121F" />
          </View>
        ) : null}
      </Pressable>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    borderRadius: 28,
    shadowColor: '#38BDF8',
    shadowOpacity: 0.45,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 6 },
    elevation: 8,
  },
  wrapInactive: { opacity: 0.5, shadowOpacity: 0 },
  btn: {
    height: 56,
    borderRadius: 28,
    overflow: 'hidden',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
  },
  sheen: { position: 'absolute', left: 0, right: 0, top: 0, height: 28 },
  label: { color: '#04121F', fontSize: 16, fontWeight: '800', letterSpacing: -0.1 },
  iconWell: {
    width: 26,
    height: 26,
    borderRadius: 13,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(4,18,31,0.12)',
  },
});
