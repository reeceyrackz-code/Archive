import React, { useCallback, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Platform,
  StatusBar,
  Image,
  Linking,
  ScrollView,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { AUTH_PAGES_VIDEO, NEW_AUTH_LOGO } from '../../../assets/assetExports';
import { AUTH_GRADIENT_COLORS } from '../../constants/authStyles';
import BackgroundVideo from '../shared/BackgroundVideo';
import { colors } from '../../constants/colors';
import { hapticFeedback } from '../../services/HapticFeedbackService';

const SKY = colors.SKY ?? '#87CEEB';
/** Brand yellow from logo / plate accent */
const BRAND_YELLOW = '#F8D70C';
const TERMS_URL = 'https://wishawash.com/terms';
const PRIVACY_URL = 'https://wishawash.com/privacy';
const { width: WINDOW_W, height: WINDOW_H } = Dimensions.get('window');
const LOGO_SIZE = Math.round(Math.min(250, WINDOW_W * 0.62, WINDOW_H * 0.28));

/** Bubble geometry in icon-auth.png, as fractions of the image size. */
const BUBBLE_CX = 0.505;
const BUBBLE_CY = 0.428;
const BUBBLE_R = 0.311;

const ARC_FONT = Math.round(LOGO_SIZE * 0.072);
const ARC_RADIUS = LOGO_SIZE * (BUBBLE_R + 0.06);
const ARC_BOX = ARC_FONT * 1.4;
const ARC_TRACKING = 0.16;
const GLYPH_WIDTH: Record<string, number> = { W: 1, I: 0.34, S: 0.66, H: 0.76, A: 0.74, a: 0.6, ' ': 0.42 };

/** "WISH a WASH" set on a circle concentric with the logo bubble. */
const BRAND_ARC = (() => {
  const text = 'WISH a WASH';
  const advances = [...text].map((ch) => ((GLYPH_WIDTH[ch] ?? 0.7) + ARC_TRACKING) * ARC_FONT);
  const total = advances.reduce((sum, w) => sum + w, 0);
  const cx = LOGO_SIZE * BUBBLE_CX;
  const cy = LOGO_SIZE * BUBBLE_CY;
  let run = -total / 2;
  return [...text].flatMap((ch, i) => {
    const mid = run + advances[i]! / 2;
    run += advances[i]!;
    if (ch === ' ') return [];
    const theta = mid / ARC_RADIUS;
    return [
      {
        key: `${ch}-${i}`,
        ch,
        accent: ch === 'a',
        left: cx + ARC_RADIUS * Math.sin(theta) - ARC_BOX / 2,
        top: cy - ARC_RADIUS * Math.cos(theta) - ARC_BOX / 2,
        rotate: (theta * 180) / Math.PI,
      },
    ];
  });
})();

export type AuthLandingShellProps = {
  mode: 'login' | 'signup';
  subcopy: string;
  switchLabel: string;
  onSwitchAuth: () => void;
  onContinueEmail: () => void;
  onApple: () => void;
  onGoogle: () => void;
  isAppleAvailable?: boolean;
  disabled?: boolean;
};

function GlassSheen() {
  return (
    <LinearGradient
      colors={['rgba(255,255,255,0.22)', 'rgba(255,255,255,0)']}
      start={{ x: 0.5, y: 0 }}
      end={{ x: 0.5, y: 1 }}
      style={styles.ctaSheen}
      pointerEvents="none"
    />
  );
}

export default function AuthLandingShell({
  mode,
  subcopy,
  switchLabel,
  onSwitchAuth,
  onContinueEmail,
  onApple,
  onGoogle,
  isAppleAvailable = false,
  disabled = false,
}: AuthLandingShellProps) {
  const insets = useSafeAreaInsets();
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(36)).current;
  const dockAnim = useRef(new Animated.Value(48)).current;
  const videoOpacity = useRef(new Animated.Value(0)).current;
  const logoGlow = useRef(new Animated.Value(0.92)).current;
  const buttonScale = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 700, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0, duration: 700, useNativeDriver: true }),
      Animated.spring(dockAnim, { toValue: 0, tension: 48, friction: 10, useNativeDriver: true }),
    ]).start();
  }, [fadeAnim, slideAnim, dockAnim]);

  useEffect(() => {
    const pulse = Animated.loop(
      Animated.sequence([
        Animated.timing(logoGlow, { toValue: 1, duration: 2600, useNativeDriver: true }),
        Animated.timing(logoGlow, { toValue: 0.88, duration: 2600, useNativeDriver: true }),
      ])
    );
    pulse.start();
    return () => pulse.stop();
  }, [logoGlow]);

  const handleVideoLoad = useCallback(() => {
    Animated.timing(videoOpacity, { toValue: 1, duration: 650, useNativeDriver: true }).start();
  }, [videoOpacity]);

  const pressIn = () => {
    Animated.spring(buttonScale, { toValue: 0.97, useNativeDriver: true, speed: 50 }).start();
  };
  const pressOut = () => {
    Animated.spring(buttonScale, { toValue: 1, useNativeDriver: true, speed: 50 }).start();
  };

  const openLink = (url: string) => {
    Linking.openURL(url).catch(() => {});
  };

  return (
    <View style={styles.root}>
      <StatusBar translucent backgroundColor="transparent" barStyle="light-content" />

      <Animated.View style={[StyleSheet.absoluteFill, { opacity: videoOpacity }]}>
        <BackgroundVideo
          source={AUTH_PAGES_VIDEO}
          style={StyleSheet.absoluteFill}
          onReady={handleVideoLoad}
        />
      </Animated.View>

      <LinearGradient
        pointerEvents="none"
        colors={[...AUTH_GRADIENT_COLORS]}
        style={StyleSheet.absoluteFill}
      />
      <LinearGradient
        pointerEvents="none"
        colors={['transparent', 'rgba(2,10,24,0.35)', 'rgba(2,10,24,0.92)']}
        locations={[0.2, 0.55, 1]}
        style={StyleSheet.absoluteFill}
      />

      <TouchableOpacity
        style={[styles.topRightLink, { top: Math.max(insets.top, 12) + 8 }]}
        onPress={() => {
          void hapticFeedback('light');
          onSwitchAuth();
        }}
        disabled={disabled}
        activeOpacity={0.7}
        hitSlop={10}
      >
        <Text style={styles.topRightLinkText}>{switchLabel}</Text>
      </TouchableOpacity>

      <ScrollView
        style={styles.stage}
        contentContainerStyle={[
          styles.stageContent,
          { paddingTop: insets.top + 36, paddingBottom: Math.max(insets.bottom, 16) + 48 },
        ]}
        bounces={false}
        showsVerticalScrollIndicator={false}
      >
        <Animated.View
          style={[
            styles.heroBlock,
            {
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }],
            },
          ]}
        >
          <View style={styles.logoCrest}>
            <Animated.View style={{ opacity: logoGlow }}>
              <Image source={NEW_AUTH_LOGO} style={styles.heroLogo} resizeMode="contain" />
            </Animated.View>
            <View style={StyleSheet.absoluteFill} pointerEvents="none">
              {BRAND_ARC.map((g) => (
                <View
                  key={g.key}
                  style={[
                    styles.arcGlyph,
                    { left: g.left, top: g.top, transform: [{ rotate: `${g.rotate}deg` }] },
                  ]}
                >
                  <Text style={[styles.arcChar, g.accent && styles.arcCharAccent]}>{g.ch}</Text>
                </View>
              ))}
            </View>
          </View>
          <Text style={styles.subcopy}>{subcopy}</Text>
        </Animated.View>

        <Animated.View
          style={[
            styles.dock,
            {
              opacity: fadeAnim,
              transform: [{ translateY: dockAnim }],
            },
          ]}
        >
          <Text style={styles.headline}>{mode === 'login' ? 'Welcome back' : 'Get started'}</Text>
          <Text style={styles.headlineSub}>
            {mode === 'login'
              ? 'Sign in to book your next wash.'
              : 'Create an account in seconds.'}
          </Text>

          <Animated.View style={{ transform: [{ scale: buttonScale }] }}>
            <TouchableOpacity
              style={styles.emailCta}
              onPress={() => {
                void hapticFeedback('light');
                onContinueEmail();
              }}
              onPressIn={pressIn}
              onPressOut={pressOut}
              disabled={disabled}
              activeOpacity={0.92}
              accessibilityLabel="Continue with Email"
            >
              <BlurView intensity={30} tint="dark" style={StyleSheet.absoluteFill} />
              <LinearGradient
                colors={['rgba(56,189,248,0.55)', 'rgba(14,165,233,0.32)']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={StyleSheet.absoluteFill}
              />
              <GlassSheen />
              <Ionicons name="mail" size={19} color="#F8FAFC" />
              <Text style={styles.emailCtaText}>Continue with Email</Text>
            </TouchableOpacity>
          </Animated.View>

          <View style={styles.socialRow}>
            {isAppleAvailable ? (
              <TouchableOpacity
                style={styles.socialBtn}
                onPress={() => {
                  void hapticFeedback('light');
                  onApple();
                }}
                disabled={disabled}
                activeOpacity={0.85}
                accessibilityLabel="Continue with Apple"
              >
                <BlurView intensity={30} tint="dark" style={StyleSheet.absoluteFill} />
                <View style={[StyleSheet.absoluteFill, styles.glassFill]} />
                <GlassSheen />
                <Ionicons name="logo-apple" size={20} color="#F8FAFC" />
                <Text style={styles.socialText}>Apple</Text>
              </TouchableOpacity>
            ) : null}

            <TouchableOpacity
              style={styles.socialBtn}
              onPress={() => {
                void hapticFeedback('light');
                onGoogle();
              }}
              disabled={disabled}
              activeOpacity={0.85}
              accessibilityLabel="Continue with Google"
            >
              <BlurView intensity={30} tint="dark" style={StyleSheet.absoluteFill} />
              <View style={[StyleSheet.absoluteFill, styles.glassFill]} />
              <GlassSheen />
              <Ionicons name="logo-google" size={18} color="#F8FAFC" />
              <Text style={styles.socialText}>Google</Text>
            </TouchableOpacity>
          </View>

          <Text style={styles.trustText}>
            By continuing, you agree to our{' '}
            <Text style={styles.trustLink} onPress={() => openLink(TERMS_URL)}>
              Terms
            </Text>
            {' and '}
            <Text style={styles.trustLink} onPress={() => openLink(PRIVACY_URL)}>
              Privacy Policy
            </Text>
          </Text>
        </Animated.View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#020A18',
  },
  topRightLink: {
    position: 'absolute',
    right: 20,
    zIndex: 20,
    paddingVertical: 8,
  },
  topRightLinkText: {
    color: '#F8FAFC',
    fontWeight: '800',
    fontSize: 15,
  },
  stage: {
    flex: 1,
  },
  stageContent: {
    flexGrow: 1,
    justifyContent: 'center',
  },
  heroBlock: {
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: Platform.OS === 'ios' ? 8 : 4,
  },
  logoCrest: {
    width: LOGO_SIZE,
    height: LOGO_SIZE,
    alignItems: 'center',
    justifyContent: 'center',
  },
  heroLogo: {
    width: LOGO_SIZE,
    height: LOGO_SIZE,
  },
  arcGlyph: {
    position: 'absolute',
    width: ARC_BOX,
    height: ARC_BOX,
    alignItems: 'center',
    justifyContent: 'center',
  },
  arcChar: {
    color: SKY,
    fontSize: ARC_FONT,
    lineHeight: ARC_FONT * 1.2,
    fontWeight: '900',
    textAlign: 'center',
    textShadowColor: 'rgba(0,0,0,0.5)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 3,
  },
  arcCharAccent: {
    color: BRAND_YELLOW,
    fontStyle: 'italic',
  },
  subcopy: {
    marginTop: 8,
    color: BRAND_YELLOW,
    fontSize: 15,
    fontWeight: '700',
    lineHeight: 22,
    textAlign: 'center',
    maxWidth: 320,
    letterSpacing: 0.2,
    textShadowColor: 'rgba(0,0,0,0.35)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 4,
  },
  dock: {
    marginTop: 22,
    paddingHorizontal: 22,
  },
  headline: {
    color: '#F8FAFC',
    fontSize: 26,
    fontWeight: '800',
    letterSpacing: -0.6,
  },
  headlineSub: {
    marginTop: 2,
    marginBottom: 16,
    color: 'rgba(226,232,240,0.65)',
    fontSize: 14,
    fontWeight: '600',
  },
  emailCta: {
    height: 56,
    borderRadius: 28,
    overflow: 'hidden',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    shadowColor: '#38BDF8',
    shadowOpacity: 0.3,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 6 },
  },
  ctaSheen: { position: 'absolute', left: 0, right: 0, top: 0, height: 28 },
  emailCtaText: {
    color: '#F8FAFC',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: -0.1,
  },
  socialRow: { flexDirection: 'row', gap: 12, marginTop: 12 },
  socialBtn: {
    flex: 1,
    height: 54,
    borderRadius: 27,
    overflow: 'hidden',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  glassFill: { backgroundColor: 'rgba(255,255,255,0.1)' },
  socialText: { color: '#F8FAFC', fontSize: 15, fontWeight: '700' },
  trustText: {
    marginTop: 14,
    textAlign: 'center',
    color: 'rgba(226,232,240,0.42)',
    fontSize: 11.5,
    fontWeight: '600',
    lineHeight: 17,
    paddingHorizontal: 12,
  },
  trustLink: {
    color: 'rgba(226,232,240,0.7)',
    fontWeight: '700',
  },
});
