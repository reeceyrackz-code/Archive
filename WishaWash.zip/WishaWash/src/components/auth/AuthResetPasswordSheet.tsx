import React, { useMemo } from 'react';
import { View, Text, StyleSheet, ScrollView, Dimensions, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import BookingBottomSheetOverlay from '../booking/BookingBottomSheetOverlay';
import HubGlassIcon from '../shared/HubGlassIcon';
import AuthField from './AuthField';
import AuthSubmitButton from './AuthSubmitButton';

const WINDOW_H = Dimensions.get('window').height;

export type AuthResetPasswordSheetProps = {
  visible: boolean;
  onClose: () => void;
  email: string;
  onChangeEmail: (value: string) => void;
  onSubmit: () => void;
  onBackToSignIn?: () => void;
  loading?: boolean;
  error?: string | null;
  sent?: boolean;
  /** Seconds until another reset email can be requested for this address. */
  resendIn?: number;
  onResend?: () => void;
};

export default function AuthResetPasswordSheet({
  visible,
  onClose,
  email,
  onChangeEmail,
  onSubmit,
  onBackToSignIn,
  loading = false,
  error = null,
  sent = false,
  resendIn = 0,
  onResend,
}: AuthResetPasswordSheetProps) {
  const sheetHeight = useMemo(
    () => Math.min(WINDOW_H * 0.42, 360),
    [sent]
  );

  return (
    <BookingBottomSheetOverlay
      visible={visible}
      onClose={onClose}
      maxHeightRatio={0.46}
      compact
      translucent
      fillBody
      closeVariant="plain"
      sheetStyle={{ height: sheetHeight, maxHeight: sheetHeight }}
    >
      <ScrollView
        style={styles.flex}
        contentContainerStyle={styles.scrollContent}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
        bounces={false}
        keyboardDismissMode="on-drag"
      >
        <View style={styles.header}>
          <HubGlassIcon icon={sent ? 'mail-open' : 'key'} accent={sent ? 'green' : 'sky'} size={46} />
          <View style={styles.headerText}>
            <Text style={styles.title}>{sent ? 'Check your email' : 'Reset password'}</Text>
            <Text style={styles.subtitle}>
              {sent
                ? `We sent a reset link to ${email.trim() || 'your email'}.`
                : 'We’ll email you a link to set a new one.'}
            </Text>
          </View>
        </View>

        {sent ? (
          <Text style={styles.sentHint}>Open the link on this phone to choose a new password.</Text>
        ) : (
          <View style={styles.fieldBlock}>
            <AuthField
              icon="mail-outline"
              placeholder="Email address"
              value={email}
              onChangeText={onChangeEmail}
              autoCapitalize="none"
              keyboardType="email-address"
              autoComplete="email"
              autoCorrect={false}
              returnKeyType="send"
              onSubmitEditing={onSubmit}
              autoFocus
              accessibilityLabel="Email address"
            />
          </View>
        )}

        {error ? (
          <View style={styles.errorRow}>
            <Ionicons name="alert-circle" size={16} color="#F87171" />
            <Text style={styles.errorText}>{error}</Text>
          </View>
        ) : null}

        {sent ? (
          <AuthSubmitButton
            label="Back to sign in"
            icon="log-in"
            onPress={() => {
              onBackToSignIn?.() ?? onClose();
            }}
          />
        ) : (
          <AuthSubmitButton
            label={loading ? 'Sending…' : resendIn > 0 ? `Send again in ${resendIn}s` : 'Send reset link'}
            icon="send"
            onPress={onSubmit}
            disabled={!email.trim().includes('@') || resendIn > 0}
            loading={loading}
          />
        )}

        {sent && onResend ? (
          <TouchableOpacity
            style={styles.resendRow}
            onPress={onResend}
            disabled={resendIn > 0 || loading}
            hitSlop={8}
            accessibilityRole="button"
          >
            <Text style={styles.resendHint}>
              Didn't get it?{' '}
              <Text style={resendIn > 0 || loading ? styles.resendMuted : styles.resendLink}>
                {loading ? 'Sending…' : resendIn > 0 ? `Resend in ${resendIn}s` : 'Resend link'}
              </Text>
            </Text>
          </TouchableOpacity>
        ) : null}
      </ScrollView>
    </BookingBottomSheetOverlay>
  );
}

const styles = StyleSheet.create({
  flex: {
    flex: 1,
    minHeight: 0,
    width: '100%',
  },
  scrollContent: {
    flexGrow: 1,
    paddingBottom: 12,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    marginBottom: 18,
    paddingRight: 40,
  },
  headerText: { flex: 1 },
  title: {
    color: '#F8FAFC',
    fontSize: 22,
    fontWeight: '800',
    letterSpacing: -0.5,
  },
  subtitle: {
    marginTop: 2,
    color: 'rgba(226,232,240,0.6)',
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 19,
  },
  sentHint: {
    color: 'rgba(226,232,240,0.7)',
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 20,
    marginBottom: 20,
  },
  fieldBlock: {
    marginBottom: 20,
  },
  errorRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  errorText: {
    flex: 1,
    color: '#FCA5A5',
    fontSize: 14,
    fontWeight: '600',
  },
  resendRow: {
    alignSelf: 'center',
    marginTop: 14,
  },
  resendHint: {
    color: 'rgba(226,232,240,0.6)',
    fontSize: 13,
    fontWeight: '600',
  },
  resendLink: {
    color: '#38BDF8',
    fontWeight: '800',
  },
  resendMuted: {
    color: 'rgba(226,232,240,0.45)',
    fontWeight: '700',
  },
});
