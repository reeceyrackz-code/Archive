import { forwardRef, useState, type ReactNode } from 'react';
import { StyleSheet, TextInput, View, type TextInputProps } from 'react-native';
import Animated, { ZoomIn, ZoomOut } from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';

const SKY = colors.SKY ?? '#38BDF8';

type Props = TextInputProps &
  Readonly<{
    icon: keyof typeof Ionicons.glyphMap;
    trailing?: ReactNode;
    /** Shows a green tick once the value is acceptable. */
    valid?: boolean;
  }>;

/** Soft filled input used across the auth sheets. */
const AuthField = forwardRef<TextInput, Props>(function AuthField(
  { icon, trailing, valid = false, onFocus, onBlur, style, ...input },
  ref
) {
  const [focused, setFocused] = useState(false);
  return (
    <View style={[styles.row, focused && styles.rowFocused]}>
      <Ionicons name={icon} size={19} color={focused ? SKY : 'rgba(148,163,184,0.85)'} />
      <TextInput
        ref={ref}
        placeholderTextColor="rgba(148,163,184,0.65)"
        {...input}
        style={[styles.input, style]}
        onFocus={(e) => {
          setFocused(true);
          onFocus?.(e);
        }}
        onBlur={(e) => {
          setFocused(false);
          onBlur?.(e);
        }}
      />
      {valid && !trailing ? (
        <Animated.View entering={ZoomIn.springify()} exiting={ZoomOut.duration(120)}>
          <Ionicons name="checkmark-circle" size={19} color="#34D399" />
        </Animated.View>
      ) : null}
      {trailing}
    </View>
  );
});

export default AuthField;

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    height: 54,
    paddingHorizontal: 16,
    borderRadius: 18,
    backgroundColor: 'rgba(148,163,184,0.11)',
  },
  rowFocused: {
    backgroundColor: 'rgba(56,189,248,0.14)',
  },
  input: {
    flex: 1,
    color: '#F8FAFC',
    fontSize: 16,
    fontWeight: '600',
    paddingVertical: 0,
  },
});
