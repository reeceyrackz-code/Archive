import { useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Dimensions,
  type TextInput,
} from 'react-native';
import Animated, { FadeIn, LinearTransition } from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import BookingBottomSheetOverlay from '../booking/BookingBottomSheetOverlay';
import HubGlassIcon from '../shared/HubGlassIcon';
import { colors } from '../../constants/colors';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import AuthField from './AuthField';
import AuthSubmitButton from './AuthSubmitButton';

const SKY = colors.SKY ?? '#38BDF8';
const WINDOW_H = Dimensions.get('window').height;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export type AuthEmailSheetMode = 'login' | 'signup';

export type AuthEmailSheetProps = {
  visible: boolean;
  onClose: () => void;
  mode: AuthEmailSheetMode;
  loading?: boolean;
  error?: string | null;
  email: string;
  password: string;
  onChangeEmail: (value: string) => void;
  onChangePassword: (value: string) => void;
  onSubmit: () => void;
  onSwitchMode?: () => void;
  onForgotPassword?: () => void;
};

export default function AuthEmailSheet({
  visible,
  onClose,
  mode,
  loading = false,
  error = null,
  email,
  password,
  onChangeEmail,
  onChangePassword,
  onSubmit,
  onSwitchMode,
  onForgotPassword,
}: AuthEmailSheetProps) {
  const [showPassword, setShowPassword] = useState(false);
  const isLogin = mode === 'login';
  const emailRef = useRef<TextInput>(null);
  const passwordRef = useRef<TextInput>(null);

  const maxHeightRatio = isLogin ? 0.56 : 0.74;
  const sheetHeight = useMemo(
    () => Math.min(WINDOW_H * (isLogin ? 0.52 : 0.7), isLogin ? 440 : 580),
    [isLogin]
  );

  const emailOk = EMAIL_RE.test(email.trim());
  const passwordOk = isLogin ? password.length > 0 : password.length >= 6;
  const canSubmit = emailOk && passwordOk;

  const submit = () => {
    if (!canSubmit || loading) return;
    onSubmit();
  };

  return (
    <BookingBottomSheetOverlay
      visible={visible}
      onClose={onClose}
      maxHeightRatio={maxHeightRatio}
      compact
      translucent
      fillBody
      closeVariant="plain"
      sheetStyle={{ height: sheetHeight, maxHeight: sheetHeight }}
    >
      <ScrollView
        style={styles.flex}
        contentContainerStyle={styles.scrollContent}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
        bounces={false}
        keyboardDismissMode="on-drag"
      >
        <View style={styles.header}>
          <HubGlassIcon icon={isLogin ? 'log-in' : 'sparkles'} accent="sky" size={46} />
          <View style={styles.headerText}>
            <Text style={styles.title}>{isLogin ? 'Welcome back' : 'Create your account'}</Text>
            <Text style={styles.subtitle}>
              {isLogin ? 'Sign in with your email' : 'It only takes a minute'}
            </Text>
          </View>
        </View>

        <View style={styles.fields}>
          <AuthField
            ref={emailRef}
            icon="mail-outline"
            placeholder="Email address"
            value={email}
            onChangeText={onChangeEmail}
            autoCapitalize="none"
            autoCorrect={false}
            keyboardType="email-address"
            autoComplete="email"
            textContentType="emailAddress"
            returnKeyType="next"
            onSubmitEditing={() => passwordRef.current?.focus()}
            submitBehavior="submit"
            valid={emailOk}
            accessibilityLabel="Email address"
          />

          <AuthField
            ref={passwordRef}
            icon="lock-closed-outline"
            placeholder={isLogin ? 'Password' : 'Create a password'}
            value={password}
            onChangeText={onChangePassword}
            secureTextEntry={!showPassword}
            autoComplete={isLogin ? 'password' : 'password-new'}
            textContentType={isLogin ? 'password' : 'newPassword'}
            returnKeyType={isLogin ? 'go' : 'next'}
            onSubmitEditing={submit}
            submitBehavior={isLogin ? 'blurAndSubmit' : 'submit'}
            accessibilityLabel="Password"
            trailing={
              <TouchableOpacity
                onPress={() => {
                  void hapticFeedback('light');
                  setShowPassword((v) => !v);
                }}
                accessibilityLabel={showPassword ? 'Hide password' : 'Show password'}
                hitSlop={10}
              >
                <Ionicons
                  name={showPassword ? 'eye-off-outline' : 'eye-outline'}
                  size={19}
                  color="rgba(148,163,184,0.9)"
                />
              </TouchableOpacity>
            }
          />

        </View>

        {isLogin && onForgotPassword ? (
          <TouchableOpacity
            style={styles.forgotRow}
            onPress={() => {
              void hapticFeedback('light');
              onForgotPassword();
            }}
            activeOpacity={0.8}
            hitSlop={8}
          >
            <Text style={styles.forgotText}>Forgot password?</Text>
          </TouchableOpacity>
        ) : (
          <View style={styles.forgotSpacer} />
        )}

        {error ? (
          <Animated.View entering={FadeIn} layout={LinearTransition} style={styles.errorRow}>
            <Ionicons name="alert-circle" size={16} color="#F87171" />
            <Text style={styles.errorText}>{error}</Text>
          </Animated.View>
        ) : null}

        <AuthSubmitButton
          label={
            loading
              ? isLogin
                ? 'Signing in…'
                : 'Creating account…'
              : isLogin
                ? 'Sign in'
                : 'Create account'
          }
          onPress={submit}
          loading={loading}
          disabled={!canSubmit}
        />

        {onSwitchMode ? (
          <TouchableOpacity
            style={styles.switchRow}
            onPress={() => {
              void hapticFeedback('light');
              onSwitchMode();
            }}
            activeOpacity={0.8}
          >
            <Text style={styles.switchHint}>
              {isLogin ? 'New here? ' : 'Already have an account? '}
              <Text style={styles.switchLink}>{isLogin ? 'Create an account' : 'Sign in'}</Text>
            </Text>
          </TouchableOpacity>
        ) : null}
      </ScrollView>
    </BookingBottomSheetOverlay>
  );
}

const styles = StyleSheet.create({
  flex: {
    flex: 1,
    minHeight: 0,
    width: '100%',
  },
  scrollContent: {
    flexGrow: 1,
    paddingBottom: 12,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    marginBottom: 18,
    paddingRight: 40,
  },
  headerText: { flex: 1 },
  title: {
    color: '#F8FAFC',
    fontSize: 22,
    fontWeight: '800',
    letterSpacing: -0.5,
  },
  subtitle: {
    marginTop: 2,
    color: 'rgba(226,232,240,0.6)',
    fontSize: 14,
    fontWeight: '600',
  },
  fields: { gap: 10 },
  forgotRow: {
    alignSelf: 'flex-end',
    marginTop: 12,
    marginBottom: 14,
  },
  forgotSpacer: {
    height: 18,
  },
  forgotText: {
    color: SKY,
    fontWeight: '700',
    fontSize: 13,
  },
  errorRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  errorText: {
    flex: 1,
    color: '#FCA5A5',
    fontSize: 13,
    fontWeight: '600',
  },
  switchRow: {
    alignSelf: 'center',
    marginTop: 16,
  },
  switchHint: {
    color: 'rgba(226,232,240,0.6)',
    fontSize: 13,
    fontWeight: '600',
  },
  switchLink: {
    color: SKY,
    fontWeight: '800',
  },
});
