/**
 * Valeter profile — bottom sheet (Explore + /owner/valeter-details).
 * Loads profile/stats/reviews when possible; polished placeholders if columns are missing.
 */
import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  Pressable,
  Image,
  useWindowDimensions,
  PanResponder,
} from 'react-native';
import Animated, {
  css,
  Easing,
  FadeIn,
  FadeInDown,
  ZoomIn,
  useAnimatedStyle,
  useSharedValue,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../../lib/supabase';
import { ValeterStatsService } from '../../services/Valeterstatsservice';
import { formatDisplayName } from '../../utils/formatDisplayName';
import { colors } from '../../constants/colors';
import { CUSTOMER_BOOKING_SHEET_TOP_RADIUS } from '../../constants/bookingCardTheme';
import { type ProfileSheetReviewItem } from '../profile/ProfileSheetReviewsSection';
import BusinessSheetBackground from '../shared/BusinessSheetBackground';
import HubGlassIcon from '../shared/HubGlassIcon';
import { RequestProCta } from '../booking/ConfirmProSheetParts';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { washCompletionService } from '../../services/WashCompletionService';
import { useAuth } from '../../providers/enhanced-auth-context';
import { CCP, ccpFallbackName } from '../../constants/carCareProLabels';
import { formatEtaMinutes } from '../../utils/mapUtils';
import { readSavedPros, toggleSavedProRow, writeSavedPros } from '../../utils/savedPros';
import { WWSheetCloseButton } from '../ui';

const CCP_ACCENT_YELLOW = colors.DETAILING_YELLOW ?? '#EAB308';
const SHEET_MAX_RATIO = 0.92;

export type ValeterProfileSheetSeed = {
  id: string;
  name?: string;
  rating?: number;
  totalJobs?: number;
  reviewCount?: number;
  profilePicture?: string | null;
  isOnline?: boolean;
  distanceMiles?: number | null;
  etaMins?: number | null;
  specializations?: string[];
  rank?: number;
  isFavourite?: boolean;
};

type PreviousWash = {
  completedAt: string | null;
  serviceName: string | null;
};

type LoadedExtra = {
  fullName: string | null;
  profilePhotoUrl: string | null;
  bio: string | null;
  isOnline: boolean;
  rating: number;
  totalJobs: number;
  reviewCount: number;
  specializations: string[];
  isVerified: boolean;
  responseHint: string | null;
};

const DEFAULT_BIO_FALLBACK =
  `This ${CCP.singularShort} hasn't added an about section yet. They offer mobile wash and care at your location — tap below to request them.`;

const SNAP_SPRING = { damping: 20, stiffness: 220 };
const AVATAR = 64;
const WORK_THUMBS = 4;

type StatItem = { key: string; icon: keyof typeof Ionicons.glyphMap; color: string; value: string; label: string };

const livePulse = css.keyframes({
  from: { transform: [{ scale: 1 }], opacity: 0.7 },
  to: { transform: [{ scale: 2.4 }], opacity: 0 },
});

function useCountUp(target: number, active: boolean, durationMs = 700) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    if (!active) {
      setValue(0);
      return;
    }
    let raf = 0;
    const start = Date.now();
    const tick = () => {
      const t = Math.min(1, (Date.now() - start) / durationMs);
      setValue(target * (1 - Math.pow(1 - t, 3)));
      if (t < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, active, durationMs]);
  return value;
}

function PressScale({
  children,
  onPress,
  style,
  disabled,
  accessibilityLabel,
  hitSlop,
}: Readonly<{
  children: ReactNode;
  onPress: () => void;
  style?: any;
  disabled?: boolean;
  accessibilityLabel?: string;
  hitSlop?: number;
}>) {
  const scale = useSharedValue(1);
  const animatedStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      onPressIn={() => {
        scale.value = withSpring(0.95, { damping: 18, stiffness: 360 });
      }}
      onPressOut={() => {
        scale.value = withSpring(1, { damping: 14, stiffness: 260 });
      }}
      accessibilityRole="button"
      {...(accessibilityLabel ? { accessibilityLabel } : {})}
      {...(hitSlop ? { hitSlop } : {})}
    >
      <Animated.View style={[style, animatedStyle]}>{children}</Animated.View>
    </Pressable>
  );
}

const RANK_COLORS: Record<number, string> = {
  1: '#FBBF24',
  2: '#CBD5E1',
  3: '#D97706',
};

function formatRelativeWashDate(dateOnly: string | null | undefined): string {
  if (!dateOnly) return 'recently';
  const d = new Date(dateOnly);
  if (Number.isNaN(d.getTime())) return 'recently';
  const days = Math.floor((Date.now() - d.getTime()) / (1000 * 60 * 60 * 24));
  if (days <= 0) return 'today';
  if (days === 1) return 'yesterday';
  if (days < 7) return `${days} days ago`;
  if (days < 30) return `${Math.floor(days / 7)} weeks ago`;
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
}

function formatResponseHint(isOnline: boolean, updatedAt: string | null | undefined): string | null {
  if (isOnline) return 'Usually replies within minutes';
  if (!updatedAt) return null;
  const mins = Math.floor((Date.now() - new Date(updatedAt).getTime()) / 60000);
  if (mins < 15) return 'Active recently · quick responses';
  if (mins < 60) return 'Usually replies in ~15 min';
  if (mins < 360) return 'Typically responds within a few hours';
  return null;
}

export async function loadGalleryPhotos(valeterId: string): Promise<string[]> {
  const photos: string[] = [];
  try {
    const { data } = await supabase
      .from('valeter_profiles')
      .select('portfolio_images, gallery_urls, work_photos, showcase_images')
      .eq('user_id', valeterId)
      .maybeSingle();
    if (data) {
      for (const key of ['portfolio_images', 'gallery_urls', 'work_photos', 'showcase_images'] as const) {
        const val = (data as Record<string, unknown>)[key];
        if (Array.isArray(val)) {
          val.forEach((url) => {
            if (typeof url === 'string' && url.trim() && !photos.includes(url.trim())) {
              photos.push(url.trim());
            }
          });
        }
      }
    }
  } catch {
    // Optional columns may not exist yet.
  }

  try {
    const completions = await washCompletionService.getValeterWashCompletions(valeterId);
    completions.forEach((completion) => {
      completion.photos?.forEach((url) => {
        if (url && !photos.includes(url)) photos.push(url);
      });
    });
  } catch {
    // In-memory service fallback only.
  }

  return photos.slice(0, 12);
}

export default function ValeterProfileBottomSheet({
  visible,
  onClose,
  valeterId,
  seed,
  onRequestBook,
  onToggleFavourite,
  requireOnlineToBook = false,
}: {
  visible: boolean;
  onClose: () => void;
  valeterId: string | null;
  seed?: ValeterProfileSheetSeed | null;
  onRequestBook: () => void | Promise<void>;
  /** When provided (e.g. Explore), parent handles favourite persistence. */
  onToggleFavourite?: () => void | Promise<void>;
  /** Lock the book CTA while the pro is offline. */
  requireOnlineToBook?: boolean;
}) {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { height: windowH } = useWindowDimensions();
  const sheetMaxHeight = Math.round(windowH * SHEET_MAX_RATIO);

  const dragY = useSharedValue(windowH);
  const backdrop = useSharedValue(0);
  const heartScale = useSharedValue(1);
  const closingRef = useRef(false);

  const [loading, setLoading] = useState(false);
  const [extra, setExtra] = useState<LoadedExtra | null>(null);
  const [imageFailed, setImageFailed] = useState(false);
  const [reviews, setReviews] = useState<ProfileSheetReviewItem[]>([]);
  const [photoExpanded, setPhotoExpanded] = useState(false);
  const [galleryPreviewUri, setGalleryPreviewUri] = useState<string | null>(null);
  const [galleryPhotos, setGalleryPhotos] = useState<string[]>([]);
  const [previousWash, setPreviousWash] = useState<PreviousWash | null>(null);
  const [isFavourite, setIsFavourite] = useState(Boolean(seed?.isFavourite));

  const load = useCallback(async () => {
    if (!valeterId || valeterId.trim() === '') return;
    setLoading(true);
    setImageFailed(false);
    try {
      let fullName: string | null = null;
      let profilePhotoUrl: string | null = null;
      let bio: string | null = null;

      type VpRow = {
        user_id?: string;
        full_name?: string | null;
        profile_photo_url?: string | null;
        specializations?: string[] | null;
        verification_status?: string | null;
      };

      const { data: vpData, error: vpError } = await supabase
        .from('valeter_profiles')
        .select('user_id, full_name, profile_photo_url, specializations, verification_status')
        .eq('user_id', valeterId)
        .maybeSingle();

      let specializations: string[] = Array.isArray(seed?.specializations) ? seed.specializations : [];
      let isVerified = false;

      if (!vpError && vpData) {
        const vp = vpData as VpRow;
        fullName = vp.full_name ?? null;
        profilePhotoUrl = vp.profile_photo_url ?? null;
        if (Array.isArray(vp.specializations) && vp.specializations.length > 0) {
          specializations = vp.specializations;
        }
        isVerified = vp.verification_status === 'verified';
      } else {
        const { data: prof } = await supabase.from('profiles').select('full_name, profile_picture').eq('id', valeterId).maybeSingle();
        const p = prof as { full_name?: string; profile_picture?: string } | null;
        fullName = p?.full_name ?? null;
        profilePhotoUrl = p?.profile_picture ?? null;
      }

      const bioRes = await supabase.from('valeter_profiles').select('bio').eq('user_id', valeterId).maybeSingle();
      if (!bioRes.error && bioRes.data) {
        const raw = (bioRes.data as { bio?: string | null }).bio;
        bio = raw?.trim() || null;
      }

      const { data: presenceData } = await supabase
        .from('valeter_presence')
        .select('is_online, updated_at')
        .eq('user_id', valeterId)
        .maybeSingle();
      const presence = presenceData as { is_online?: boolean; updated_at?: string | null } | null;
      const isOnline = presence?.is_online ?? seed?.isOnline ?? false;
      const responseHint = formatResponseHint(isOnline, presence?.updated_at ?? null);

      let rating = seed?.rating ?? 0;
      let totalJobs = seed?.totalJobs ?? 0;
      let reviewCount = 0;
      const stats = await ValeterStatsService.getValeterStats(valeterId).catch(() => null);
      if (stats) {
        rating = stats.averageRating ?? rating;
        totalJobs = stats.totalJobs ?? totalJobs;
        reviewCount = stats.customerReviews ?? 0;
      }

      setExtra({
        fullName,
        profilePhotoUrl,
        bio,
        isOnline,
        rating,
        totalJobs,
        reviewCount,
        specializations,
        isVerified,
        responseHint,
      });
    } catch {
      setExtra({
        fullName: null,
        profilePhotoUrl: null,
        bio: null,
        isOnline: seed?.isOnline ?? false,
        rating: seed?.rating ?? 0,
        totalJobs: seed?.totalJobs ?? 0,
        reviewCount: seed?.reviewCount ?? 0,
        specializations: seed?.specializations ?? [],
        isVerified: false,
        responseHint: seed?.isOnline ? 'Usually replies within minutes' : null,
      });
    } finally {
      setLoading(false);
    }
  }, [valeterId, seed?.isOnline, seed?.rating, seed?.totalJobs, seed?.reviewCount, seed?.specializations]);

  useEffect(() => {
    if (!visible || !valeterId) {
      setExtra(null);
      setGalleryPhotos([]);
      setPreviousWash(null);
      return;
    }
    setIsFavourite(Boolean(seed?.isFavourite));
    void load();
  }, [visible, valeterId, load, seed?.isFavourite]);

  useEffect(() => {
    if (!visible || !valeterId) return;
    let cancelled = false;
    void loadGalleryPhotos(valeterId).then((photos) => {
      if (!cancelled) setGalleryPhotos(photos);
    });
    return () => {
      cancelled = true;
    };
  }, [visible, valeterId]);

  useEffect(() => {
    if (!visible || !valeterId || !user?.id) {
      setPreviousWash(null);
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const { data } = await supabase
          .from('bookings')
          .select('completed_at, service_name')
          .eq('user_id', user.id)
          .eq('valeter_id', valeterId)
          .eq('status', 'completed')
          .order('completed_at', { ascending: false })
          .limit(1)
          .maybeSingle();
        if (cancelled) return;
        if (data) {
          const row = data as { completed_at?: string | null; service_name?: string | null };
          setPreviousWash({
            completedAt: row.completed_at ?? null,
            serviceName: row.service_name ?? null,
          });
        } else {
          setPreviousWash(null);
        }
      } catch {
        if (!cancelled) setPreviousWash(null);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [visible, valeterId, user?.id]);

  useEffect(() => {
    if (!visible || !valeterId || !user?.id || seed?.isFavourite != null || onToggleFavourite) return;
    let cancelled = false;
    (async () => {
      const saved = await readSavedPros(user.id);
      if (!cancelled) setIsFavourite(saved.some((f) => f.valeter_id === valeterId));
    })();
    return () => {
      cancelled = true;
    };
  }, [visible, valeterId, user?.id, seed?.isFavourite, onToggleFavourite]);

  useEffect(() => {
    if (!visible) return;
    closingRef.current = false;
    dragY.value = windowH;
    dragY.value = withTiming(0, { duration: 340, easing: Easing.out(Easing.cubic) });
    backdrop.value = withTiming(1, { duration: 260 });
  }, [visible, windowH, dragY, backdrop]);

  const requestClose = useCallback(() => {
    if (closingRef.current) return;
    closingRef.current = true;
    dragY.value = withTiming(windowH, { duration: 230, easing: Easing.in(Easing.cubic) });
    backdrop.value = withTiming(0, { duration: 230 });
    setTimeout(onClose, 220);
  }, [onClose, windowH, dragY, backdrop]);

  const pan = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => false,
        onMoveShouldSetPanResponder: (_, g) => g.dy > 6 && Math.abs(g.dy) > Math.abs(g.dx),
        onPanResponderMove: (_, g) => {
          dragY.value = Math.max(0, g.dy);
        },
        onPanResponderRelease: (_, g) => {
          if (g.dy > 120 || g.vy > 0.85) requestClose();
          else dragY.value = withSpring(0, SNAP_SPRING);
        },
        onPanResponderTerminate: () => {
          dragY.value = withSpring(0, SNAP_SPRING);
        },
      }),
    [requestClose, dragY]
  );

  const sheetStyle = useAnimatedStyle(() => ({ transform: [{ translateY: dragY.value }] }));
  const backdropStyle = useAnimatedStyle(() => ({ opacity: backdrop.value }));
  const heartStyle = useAnimatedStyle(() => ({ transform: [{ scale: heartScale.value }] }));

  useEffect(() => {
    if (!visible || !valeterId) {
      setReviews([]);
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const { data, error } = await supabase
          .from('bookings')
          .select('id,rating,review,completed_at,user_id')
          .eq('valeter_id', valeterId)
          .eq('status', 'completed')
          .not('rating', 'is', null)
          .order('completed_at', { ascending: false })
          .limit(8);
        if (cancelled || error || !data?.length) {
          if (!cancelled) setReviews([]);
          return;
        }
        const userIds = [...new Set(data.map((r: { user_id?: string }) => r.user_id).filter(Boolean))] as string[];
        const nameBy = new Map<string, string>();
        if (userIds.length) {
          const { data: profs } = await supabase.from('profiles').select('id,full_name').in('id', userIds);
          (profs || []).forEach((p: { id: string; full_name?: string | null }) => {
            nameBy.set(p.id, p.full_name?.trim() || 'Customer');
          });
        }
        if (!cancelled) {
          setReviews(
            data.map((r: { id: string; rating?: number | null; review?: string | null; user_id?: string; completed_at?: string | null }) => ({
              id: String(r.id),
              rating: Number(r.rating) || 0,
              body: r.review?.trim() || null,
              author: (r.user_id && nameBy.get(r.user_id)) || 'Customer',
              completedAt: r.completed_at ?? null,
            }))
          );
        }
      } catch {
        if (!cancelled) setReviews([]);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [visible, valeterId]);

  useEffect(() => {
    if (!visible) {
      setPhotoExpanded(false);
      setGalleryPreviewUri(null);
    }
  }, [visible]);

  const merged = useMemo(() => {
    const name = extra?.fullName || seed?.name || ccpFallbackName();
    const photo = extra?.profilePhotoUrl ?? seed?.profilePicture ?? null;
    const rating = extra?.rating ?? seed?.rating ?? 0;
    const jobs = extra?.totalJobs ?? seed?.totalJobs ?? 0;
    const reviewCount = extra?.reviewCount ?? seed?.reviewCount ?? 0;
    const online = extra?.isOnline ?? seed?.isOnline ?? false;
    const bioText = (extra?.bio && extra.bio.trim()) || null;
    const specializations = extra?.specializations ?? seed?.specializations ?? [];
    const isVerified = extra?.isVerified ?? false;
    const rank = seed?.rank ?? null;
    const isTopRated = rating >= 4.8 && jobs >= 10;
    return {
      name: formatDisplayName(name) || name,
      photo,
      rating,
      jobs,
      reviewCount,
      online,
      bioText,
      specializations,
      isVerified,
      rank,
      isTopRated,
      distanceMiles: seed?.distanceMiles ?? null,
      etaMins: seed?.etaMins ?? null,
      responseHint: extra?.responseHint ?? null,
    };
  }, [extra, seed]);

  const handleToggleFavourite = useCallback(async () => {
    if (onToggleFavourite) {
      void hapticFeedback('light');
      onToggleFavourite();
      return;
    }
    if (!user?.id || !valeterId) return;
    void hapticFeedback('light');
    const saved = await readSavedPros(user.id);
    const next = toggleSavedProRow(saved, {
      id: valeterId,
      name: merged.name,
      profilePicture: merged.photo,
      rating: merged.rating,
      totalJobs: merged.jobs,
      specializations: merged.specializations,
    });
    writeSavedPros(user.id, next);
    setIsFavourite(next.some((f) => f.valeter_id === valeterId));
  }, [onToggleFavourite, user?.id, valeterId, merged]);

  const featuredReview = useMemo(() => {
    const withBody = reviews.filter((r) => r.body && r.body.trim().length > 0);
    if (!withBody.length) return null;
    return withBody.reduce((best, r) => (r.rating > best.rating ? r : best), withBody[0]);
  }, [reviews]);

  const bioParagraph = merged.bioText || DEFAULT_BIO_FALLBACK;
  const rankColor = merged.rank != null ? RANK_COLORS[merged.rank] ?? CCP_ACCENT_YELLOW : null;
  const bookingLocked = requireOnlineToBook && !merged.online;
  const ctaTitle = bookingLocked ? 'Offline' : previousWash ? 'Book again' : CCP.requestButton;
  const ctaSubtitle = bookingLocked
    ? 'Available when they come online'
    : previousWash
    ? `Last wash ${formatRelativeWashDate(previousWash.completedAt)}${
        previousWash.serviceName ? ` · ${previousWash.serviceName}` : ''
      }`
    : merged.online
      ? [
          merged.distanceMiles != null ? `${merged.distanceMiles.toFixed(1)} mi away` : null,
          merged.etaMins != null ? `${formatEtaMinutes(merged.etaMins, { approx: true })} ETA` : null,
          merged.responseHint ?? 'Available now',
        ]
          .filter(Boolean)
          .join(' · ')
      : merged.responseHint ?? 'Request a wash — they’ll confirm availability';

  const statsActive = visible && !loading;
  const ratingCount = useCountUp(merged.rating, statsActive);
  const jobsCount = useCountUp(merged.jobs, statsActive);
  const reviewsCount = useCountUp(merged.reviewCount, statsActive);

  if (!valeterId) return null;

  const showFavourite = seed?.isFavourite ?? isFavourite;
  const firstName = merged.name.split(' ')[0] ?? merged.name;
  const hasPhoto = Boolean(merged.photo && !imageFailed);

  const onHeartPress = () => {
    heartScale.value = withSequence(
      withSpring(1.4, { damping: 8, stiffness: 420 }),
      withSpring(1, { damping: 10, stiffness: 240 }),
    );
    if (!showFavourite) void hapticFeedback('medium');
    void handleToggleFavourite();
  };

  const bookNow = () => {
    if (bookingLocked) return;
    void hapticFeedback('medium');
    void Promise.resolve(onRequestBook());
  };

  const stats: StatItem[] = [
    { key: 'rating', icon: 'star', color: '#FBBF24', value: merged.rating > 0 ? ratingCount.toFixed(1) : 'New', label: 'Rating' },
    { key: 'jobs', icon: 'checkmark-done', color: '#38BDF8', value: String(Math.round(jobsCount)), label: 'Jobs' },
    {
      key: 'reviews',
      icon: 'chatbubbles',
      color: '#A78BFA',
      value: merged.reviewCount > 0 ? String(Math.round(reviewsCount)) : '—',
      label: 'Reviews',
    },
    ...(merged.distanceMiles != null
      ? [{ key: 'distance', icon: 'navigate' as const, color: '#34D399', value: `${merged.distanceMiles.toFixed(1)} mi`, label: 'Away' }]
      : []),
    ...(merged.etaMins != null
      ? [{ key: 'eta', icon: 'time' as const, color: '#38BDF8', value: formatEtaMinutes(merged.etaMins, { approx: true }) ?? '—', label: 'ETA' }]
      : []),
  ];
  const workThumbs = galleryPhotos.slice(0, WORK_THUMBS);
  const moreWork = galleryPhotos.length - workThumbs.length;
  const specs = merged.specializations.slice(0, 4);

  return (
    <Modal visible={visible} transparent animationType="none" onRequestClose={requestClose}>
      <View style={styles.root}>
        <Animated.View style={[StyleSheet.absoluteFill, styles.backdrop, backdropStyle]}>
          <Pressable style={StyleSheet.absoluteFill} onPress={requestClose} accessibilityLabel="Dismiss profile" />
        </Animated.View>

        <Animated.View
          style={[styles.panel, { maxHeight: sheetMaxHeight, paddingBottom: Math.max(14, insets.bottom) }, sheetStyle]}
        >
          <BusinessSheetBackground reportObstruction={false} />

          <View {...pan.panHandlers}>
            <View style={styles.handle} />
            <View style={styles.header}>
              <Pressable
                disabled={!hasPhoto}
                onPress={() => {
                  void hapticFeedback('light');
                  setPhotoExpanded(true);
                }}
                accessibilityRole="button"
                accessibilityLabel={hasPhoto ? 'View profile photo' : 'Profile photo'}
                style={styles.avatarWrap}
              >
                {hasPhoto ? (
                  <Image
                    source={{ uri: merged.photo! }}
                    style={styles.avatar}
                    resizeMode="cover"
                    onError={() => setImageFailed(true)}
                  />
                ) : (
                  <HubGlassIcon icon="person" accent="gold" size={AVATAR} iconSize={28} glow={false} />
                )}
                {merged.online ? (
                  <View style={styles.avatarLive}>
                    <Animated.View
                      style={[
                        styles.avatarLiveRing,
                        {
                          animationName: livePulse,
                          animationDuration: '1.6s',
                          animationIterationCount: 'infinite',
                          animationTimingFunction: 'ease-out',
                        },
                      ]}
                    />
                    <View style={styles.avatarLiveDot} />
                  </View>
                ) : null}
              </Pressable>

              <View style={styles.headerText}>
                <View style={styles.nameRow}>
                  <Text style={styles.name} numberOfLines={1}>
                    {merged.name}
                  </Text>
                  {merged.isVerified ? <Ionicons name="checkmark-circle" size={17} color="#38BDF8" /> : null}
                </View>
                <View style={styles.metaRow}>
                  <View style={[styles.metaPill, merged.online ? styles.metaPillOnline : styles.metaPillOffline]}>
                    <Text style={[styles.metaPillText, { color: merged.online ? '#6EE7B7' : '#CBD5E1' }]}>
                      {merged.online ? 'Available now' : 'Offline'}
                    </Text>
                  </View>
                  {merged.rank != null && merged.rank <= 3 ? (
                    <View style={[styles.metaPill, { backgroundColor: `${rankColor}26` }]}>
                      <Ionicons name="trophy" size={11} color={rankColor ?? CCP_ACCENT_YELLOW} />
                      <Text style={[styles.metaPillText, { color: rankColor ?? CCP_ACCENT_YELLOW }]}>#{merged.rank}</Text>
                    </View>
                  ) : merged.isTopRated ? (
                    <View style={[styles.metaPill, styles.metaPillGold]}>
                      <Ionicons name="ribbon" size={11} color="#FBBF24" />
                      <Text style={[styles.metaPillText, { color: '#FBBF24' }]}>Top rated</Text>
                    </View>
                  ) : null}
                  <Text style={styles.kicker} numberOfLines={1}>
                    {CCP.singularShort}
                  </Text>
                </View>
              </View>

              <View style={styles.headerButtons}>
                {user?.id ? (
                  <Pressable
                    onPress={onHeartPress}
                    hitSlop={8}
                    accessibilityRole="button"
                    accessibilityLabel={
                      showFavourite ? `Remove ${merged.name} from favourites` : `Save ${merged.name} to favourites`
                    }
                  >
                    <Animated.View style={[styles.glassBtn, heartStyle]}>
                      <Ionicons
                        name={showFavourite ? 'heart' : 'heart-outline'}
                        size={17}
                        color={showFavourite ? '#F87171' : '#F8FAFC'}
                      />
                    </Animated.View>
                  </Pressable>
                ) : null}
                <PressScale onPress={requestClose} style={styles.glassBtn} accessibilityLabel="Close" hitSlop={8}>
                  <Ionicons name="close" size={18} color="#F8FAFC" />
                </PressScale>
              </View>
            </View>
          </View>

          <View style={styles.body}>
            <Animated.View entering={FadeInDown.delay(60).springify().damping(18)} style={styles.statStrip}>
              {stats.map((st, i) => (
                <View key={st.key} style={[styles.statCell, i > 0 && styles.statCellDivider]}>
                  <View style={styles.statValueRow}>
                    <Ionicons name={st.icon} size={12} color={st.color} />
                    <Text style={styles.statValue} numberOfLines={1} adjustsFontSizeToFit>
                      {st.value}
                    </Text>
                  </View>
                  <Text style={styles.statLabel} numberOfLines={1}>
                    {st.label}
                  </Text>
                </View>
              ))}
            </Animated.View>

            {previousWash ? (
              <PressScale onPress={bookNow} style={styles.againRow} accessibilityLabel={`Book ${firstName} again`}>
                <Ionicons name="refresh" size={14} color="#FDE68A" />
                <Text style={styles.againText} numberOfLines={1}>
                  You’ve washed with {firstName} · {formatRelativeWashDate(previousWash.completedAt)}
                </Text>
                <Ionicons name="chevron-forward" size={14} color="rgba(253,230,138,0.8)" />
              </PressScale>
            ) : null}

            <View style={styles.section}>
              <Text style={styles.bio} numberOfLines={3}>
                {loading && !extra ? 'Loading profile…' : bioParagraph}
              </Text>
              {merged.responseHint ? (
                <View style={styles.hintRow}>
                  <Ionicons name="chatbubble-ellipses-outline" size={12} color="#7DD3FC" />
                  <Text style={styles.hintText} numberOfLines={1}>
                    {merged.responseHint}
                  </Text>
                </View>
              ) : null}
            </View>

            {specs.length > 0 ? (
              <View style={styles.specRow}>
                {specs.map((spec) => (
                  <View key={spec} style={styles.specChip}>
                    <Text style={styles.specChipText} numberOfLines={1}>
                      {spec}
                    </Text>
                  </View>
                ))}
              </View>
            ) : null}

            {workThumbs.length > 0 ? (
              <View style={styles.section}>
                <Text style={styles.sectionLabel}>Recent work</Text>
                <View style={styles.workRow}>
                  {workThumbs.map((uri, index) => {
                    const showMore = index === workThumbs.length - 1 && moreWork > 0;
                    return (
                      <Animated.View key={`${uri}-${index}`} entering={ZoomIn.delay(index * 40).springify().damping(16)} style={styles.workCell}>
                        <PressScale
                          onPress={() => {
                            void hapticFeedback('light');
                            setGalleryPreviewUri(uri);
                          }}
                          style={styles.workThumb}
                          accessibilityLabel={`Open work photo ${index + 1}`}
                        >
                          <Image source={{ uri }} style={styles.workImage} resizeMode="cover" />
                          {showMore ? (
                            <View style={styles.workMore} pointerEvents="none">
                              <Text style={styles.workMoreText}>+{moreWork}</Text>
                            </View>
                          ) : null}
                        </PressScale>
                      </Animated.View>
                    );
                  })}
                  {Array.from({ length: WORK_THUMBS - workThumbs.length }).map((_, i) => (
                    <View key={`work-pad-${i}`} style={styles.workCell} />
                  ))}
                </View>
              </View>
            ) : null}

            {featuredReview ? (
              <Animated.View entering={FadeIn.duration(220)} style={styles.reviewCard}>
                <View style={styles.reviewHead}>
                  <View style={styles.reviewStars}>
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Ionicons
                        key={`rs-${i}`}
                        name={i < Math.round(featuredReview.rating) ? 'star' : 'star-outline'}
                        size={11}
                        color="#FBBF24"
                      />
                    ))}
                  </View>
                  <Text style={styles.reviewAuthor} numberOfLines={1}>
                    {featuredReview.author}
                  </Text>
                </View>
                <Text style={styles.reviewBody} numberOfLines={2}>
                  “{featuredReview.body}”
                </Text>
              </Animated.View>
            ) : null}
          </View>

          <View style={styles.ctaWrap}>
            <RequestProCta
              accent={CCP_ACCENT_YELLOW}
              title={ctaTitle}
              subtitle={ctaSubtitle}
              disabled={bookingLocked}
              loading={false}
              onPress={bookNow}
              idleIcon="lock-closed"
            />
          </View>
        </Animated.View>
      </View>

      <Modal
        visible={Boolean(photoExpanded && hasPhoto) || Boolean(galleryPreviewUri)}
        transparent
        animationType="fade"
        onRequestClose={() => {
          setPhotoExpanded(false);
          setGalleryPreviewUri(null);
        }}
      >
        <View style={styles.photoViewerRoot}>
          <Pressable
            style={StyleSheet.absoluteFill}
            onPress={() => {
              setPhotoExpanded(false);
              setGalleryPreviewUri(null);
            }}
            accessibilityLabel="Close photo"
          />
          <View style={[styles.photoViewerTopBar, { paddingTop: insets.top + 8 }]}>
            <WWSheetCloseButton
              size={44}
              iconSize={26}
              iconColor="#FFFFFF"
              onPress={() => {
                setPhotoExpanded(false);
                setGalleryPreviewUri(null);
              }}
              accessibilityLabel="Close photo"
            />
          </View>
          {galleryPreviewUri || merged.photo ? (
            <Animated.Image
              entering={ZoomIn.springify().damping(18)}
              source={{ uri: galleryPreviewUri ?? merged.photo! }}
              style={styles.photoViewerImage}
              resizeMode="contain"
            />
          ) : null}
        </View>
      </Modal>
    </Modal>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, justifyContent: 'flex-end' },
  backdrop: { backgroundColor: 'rgba(2,6,23,0.6)' },
  panel: {
    borderTopLeftRadius: CUSTOMER_BOOKING_SHEET_TOP_RADIUS + 6,
    borderTopRightRadius: CUSTOMER_BOOKING_SHEET_TOP_RADIUS + 6,
    overflow: 'hidden',
  },
  handle: {
    alignSelf: 'center',
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(248,250,252,0.35)',
    marginTop: 8,
    marginBottom: 12,
  },

  header: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 18 },
  avatarWrap: { width: AVATAR, height: AVATAR },
  avatar: { width: AVATAR, height: AVATAR, borderRadius: AVATAR / 2, backgroundColor: 'rgba(15,23,42,0.6)' },
  avatarLive: {
    position: 'absolute',
    right: 1,
    bottom: 1,
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: '#0B1220',
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarLiveDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: '#34D399' },
  avatarLiveRing: { position: 'absolute', width: 10, height: 10, borderRadius: 5, backgroundColor: '#34D399' },
  headerText: { flex: 1, minWidth: 0, gap: 6 },
  nameRow: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  name: { flexShrink: 1, color: '#F8FAFC', fontSize: 19, fontWeight: '800', letterSpacing: -0.4 },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  metaPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 999,
  },
  metaPillText: { fontSize: 11, fontWeight: '700' },
  metaPillOnline: { backgroundColor: 'rgba(52,211,153,0.14)' },
  metaPillOffline: { backgroundColor: 'rgba(148,163,184,0.14)' },
  metaPillGold: { backgroundColor: 'rgba(251,191,36,0.12)' },
  kicker: { flexShrink: 1, color: 'rgba(148,163,184,0.85)', fontSize: 11.5, fontWeight: '600' },
  headerButtons: { flexDirection: 'row', gap: 8, alignSelf: 'flex-start' },
  glassBtn: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
  },

  body: { paddingHorizontal: 18, paddingTop: 16, gap: 14 },
  statStrip: {
    flexDirection: 'row',
    paddingVertical: 10,
    borderRadius: 18,
    backgroundColor: 'rgba(2,6,23,0.35)',
  },
  statCell: { flex: 1, alignItems: 'center', gap: 2, paddingHorizontal: 4 },
  statCellDivider: { borderLeftWidth: StyleSheet.hairlineWidth, borderLeftColor: 'rgba(148,163,184,0.18)' },
  statValueRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  statValue: { color: '#F8FAFC', fontSize: 15, fontWeight: '800', letterSpacing: -0.2 },
  statLabel: { color: 'rgba(148,163,184,0.85)', fontSize: 10.5, fontWeight: '600' },

  againRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 9,
    borderRadius: 999,
    backgroundColor: 'rgba(234,179,8,0.1)',
  },
  againText: { flex: 1, color: '#FDE68A', fontSize: 12.5, fontWeight: '600' },

  section: { gap: 8 },
  bio: { color: 'rgba(226,232,240,0.88)', fontSize: 13.5, lineHeight: 19, fontWeight: '500' },
  hintRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  hintText: { flex: 1, color: '#7DD3FC', fontSize: 12, fontWeight: '600' },
  sectionLabel: { color: 'rgba(148,163,184,0.85)', fontSize: 11.5, fontWeight: '700' },

  specRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  specChip: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 999,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  specChipText: { color: 'rgba(226,232,240,0.9)', fontSize: 11.5, fontWeight: '600' },

  workRow: { flexDirection: 'row', gap: 8 },
  workCell: { flex: 1 },
  workThumb: { height: 58, borderRadius: 14, overflow: 'hidden', backgroundColor: 'rgba(15,23,42,0.55)' },
  workImage: { width: '100%', height: '100%' },
  workMore: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(2,6,23,0.55)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  workMoreText: { color: '#F8FAFC', fontSize: 13, fontWeight: '800' },

  reviewCard: {
    gap: 5,
    paddingHorizontal: 14,
    paddingVertical: 11,
    borderRadius: 18,
    backgroundColor: 'rgba(2,6,23,0.35)',
  },
  reviewHead: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  reviewStars: { flexDirection: 'row', gap: 2 },
  reviewAuthor: { flex: 1, color: 'rgba(148,163,184,0.9)', fontSize: 11.5, fontWeight: '600' },
  reviewBody: { color: 'rgba(241,245,249,0.92)', fontSize: 13, lineHeight: 18, fontWeight: '500' },

  ctaWrap: { paddingHorizontal: 18, paddingTop: 16 },

  photoViewerRoot: { flex: 1, backgroundColor: 'rgba(0,0,0,0.94)', justifyContent: 'center' },
  photoViewerTopBar: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 2,
    paddingHorizontal: 16,
    alignItems: 'flex-end',
  },
  photoViewerImage: { width: '100%', height: '78%', alignSelf: 'center' },
});
