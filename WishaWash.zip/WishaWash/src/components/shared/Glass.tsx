import type { ReactNode } from 'react';
import { Platform, StyleSheet, View, type StyleProp, type ViewStyle } from 'react-native';
import { BlurView } from 'expo-blur';
import { GlassView, isLiquidGlassAvailable } from 'expo-glass-effect';
import { SymbolView, type SFSymbol } from 'expo-symbols';
import { Ionicons } from '@expo/vector-icons';

const LIQUID_GLASS = Platform.OS === 'ios' && isLiquidGlassAvailable();

/** Liquid Glass on iOS 26+, blurred dark glass everywhere else. */
export function GlassSurface({
  children,
  style,
  tint = 'rgba(8,20,38,0.5)',
  interactive = false,
}: Readonly<{
  children?: ReactNode;
  style?: StyleProp<ViewStyle>;
  tint?: string;
  interactive?: boolean;
}>) {
  if (LIQUID_GLASS) {
    return (
      <GlassView
        glassEffectStyle="regular"
        colorScheme="dark"
        tintColor={tint}
        isInteractive={interactive}
        style={[styles.clip, style]}
      >
        {children}
      </GlassView>
    );
  }
  return (
    <View style={[styles.clip, style]}>
      <BlurView intensity={40} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
      <View style={[StyleSheet.absoluteFill, { backgroundColor: tint }]} pointerEvents="none" />
      {children}
    </View>
  );
}

/** SF Symbol on iOS with an Ionicons stand-in elsewhere. */
export function GlassSymbol({
  sf,
  ion,
  size,
  color,
  bounce,
}: Readonly<{
  sf: SFSymbol;
  ion: keyof typeof Ionicons.glyphMap;
  size: number;
  color: string;
  bounce?: boolean;
}>) {
  const fallback = <Ionicons name={ion} size={size} color={color} />;
  if (Platform.OS !== 'ios') return fallback;
  return (
    <SymbolView
      name={sf}
      size={size}
      tintColor={color}
      type="hierarchical"
      {...(bounce ? { animationSpec: { effect: { type: 'bounce', wholeSymbol: true } } } : {})}
      fallback={fallback}
    />
  );
}

const styles = StyleSheet.create({
  clip: { overflow: 'hidden' },
});
