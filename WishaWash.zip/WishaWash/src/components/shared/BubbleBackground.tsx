import { memo, useMemo } from 'react';
import { Dimensions, StyleSheet, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { css, useAnimatedStyle, useReducedMotion, type SharedValue } from 'react-native-reanimated';
import type { AccountType } from '../../constants/accountThemes';

const { width: SCREEN_W, height: SCREEN_H } = Dimensions.get('window');

type Seconds = `${number}s`;

interface BubbleBackgroundProps {
  accountType?: AccountType;
  bubbleCount?: number;
  /** Scroll offset of the screen; bubbles drift up with a slow parallax. */
  scrollY?: SharedValue<number>;
}

/** Bubbles parallax at this fraction of scroll, capped so the spawn line stays off-screen. */
const SCROLL_PARALLAX = 0.25;
const SCROLL_SHIFT_MAX = 140;

type Tint = { core: string; edge: string; rim: string };

const SKY_TINT: Tint = {
  core: 'rgba(135,206,235,0.34)',
  edge: 'rgba(135,206,235,0.06)',
  rim: 'rgba(186,230,253,0.35)',
};
const LIME_TINT: Tint = {
  core: 'rgba(202,224,80,0.3)',
  edge: 'rgba(202,224,80,0.05)',
  rim: 'rgba(236,252,203,0.32)',
};
const GREEN_TINT: Tint = {
  core: 'rgba(132,204,22,0.32)',
  edge: 'rgba(132,204,22,0.05)',
  rim: 'rgba(217,249,157,0.32)',
};

const rise = css.keyframes({
  '0%': { transform: [{ translateY: 0 }], opacity: 0 },
  '12%': { opacity: 1 },
  '70%': { opacity: 0.85 },
  '100%': { transform: [{ translateY: -SCREEN_H * 0.95 }], opacity: 0 },
});

const sway = css.keyframes({
  '0%': { transform: [{ translateX: 0 }] },
  '25%': { transform: [{ translateX: 14 }] },
  '50%': { transform: [{ translateX: -6 }] },
  '75%': { transform: [{ translateX: -16 }] },
  '100%': { transform: [{ translateX: 0 }] },
});

const wobble = css.keyframes({
  '0%': { transform: [{ scaleX: 1 }, { scaleY: 1 }] },
  '30%': { transform: [{ scaleX: 1.06 }, { scaleY: 0.95 }] },
  '60%': { transform: [{ scaleX: 0.96 }, { scaleY: 1.05 }] },
  '100%': { transform: [{ scaleX: 1 }, { scaleY: 1 }] },
});

/** Deterministic pseudo-random so bubbles keep their layout across renders. */
function seeded(i: number, salt: number) {
  const x = Math.sin(i * 12.9898 + salt * 78.233) * 43758.5453;
  return x - Math.floor(x);
}

type BubbleSpec = {
  key: string;
  size: number;
  left: number;
  rise: Seconds;
  sway: Seconds;
  wobble: Seconds;
  delay: Seconds;
  tint: Tint;
};

function buildBubbles(count: number, accountType: AccountType): BubbleSpec[] {
  const base = accountType === 'business' ? GREEN_TINT : SKY_TINT;
  return Array.from({ length: count }, (_, i) => {
    const size = Math.round(12 + seeded(i, 1) * 38);
    const accent = accountType === 'customer' && i % 4 === 1;
    return {
      key: `b${i}`,
      size,
      left: Math.round((i + 0.5) * (SCREEN_W / count) + (seeded(i, 2) - 0.5) * (SCREEN_W / count) - size / 2),
      rise: `${(11 + seeded(i, 3) * 9).toFixed(1)}s` as Seconds,
      sway: `${(4 + seeded(i, 4) * 3).toFixed(1)}s` as Seconds,
      wobble: `${(2.2 + seeded(i, 5) * 1.6).toFixed(1)}s` as Seconds,
      delay: `${(i * 1.3 + seeded(i, 6) * 1.2).toFixed(1)}s` as Seconds,
      tint: accent ? LIME_TINT : base,
    };
  });
}

function Orb({ size, tint }: Readonly<{ size: number; tint: Tint }>) {
  return (
    <View
      style={[
        styles.orb,
        {
          width: size,
          height: size,
          borderRadius: size / 2,
          borderColor: tint.rim,
        },
      ]}
    >
      <LinearGradient
        colors={[tint.core, tint.edge]}
        start={{ x: 0.25, y: 0.15 }}
        end={{ x: 0.85, y: 1 }}
        style={StyleSheet.absoluteFill}
      />
      <View
        style={[
          styles.glint,
          {
            width: size * 0.32,
            height: size * 0.2,
            borderRadius: size * 0.16,
            top: size * 0.16,
            left: size * 0.2,
          },
        ]}
      />
    </View>
  );
}

function BubbleBackground({ accountType = 'customer', bubbleCount = 9, scrollY }: BubbleBackgroundProps) {
  const reduced = useReducedMotion();
  const bubbles = useMemo(() => buildBubbles(bubbleCount, accountType), [bubbleCount, accountType]);
  const parallaxStyle = useAnimatedStyle(() => ({
    transform: [
      {
        translateY: -Math.min(SCROLL_SHIFT_MAX, Math.max(0, (scrollY?.value ?? 0) * SCROLL_PARALLAX)),
      },
    ],
  }));

  return (
    <View style={styles.container} pointerEvents="none">
      <Animated.View style={[styles.layer, parallaxStyle]}>
        {bubbles.map((b, i) =>
          reduced ? (
            <View
              key={b.key}
              style={[
                styles.bubble,
                {
                  left: b.left,
                  bottom: 40 + seeded(i, 7) * SCREEN_H * 0.4,
                  opacity: 0.6,
                },
              ]}
            >
              <Orb size={b.size} tint={b.tint} />
            </View>
          ) : (
            <Animated.View
              key={b.key}
              style={[
                styles.bubble,
                { left: b.left, bottom: -b.size },
                {
                  animationName: rise,
                  animationDuration: b.rise,
                  animationDelay: b.delay,
                  animationIterationCount: 'infinite',
                  animationTimingFunction: 'linear',
                  animationFillMode: 'both',
                },
              ]}
            >
              <Animated.View
                style={{
                  animationName: sway,
                  animationDuration: b.sway,
                  animationIterationCount: 'infinite',
                  animationTimingFunction: 'ease-in-out',
                }}
              >
                <Animated.View
                  style={{
                    animationName: wobble,
                    animationDuration: b.wobble,
                    animationIterationCount: 'infinite',
                    animationTimingFunction: 'ease-in-out',
                  }}
                >
                  <Orb size={b.size} tint={b.tint} />
                </Animated.View>
              </Animated.View>
            </Animated.View>
          ),
        )}
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFill,
    zIndex: 0,
    overflow: 'hidden',
  },
  layer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: -SCROLL_SHIFT_MAX,
  },
  bubble: {
    position: 'absolute',
  },
  orb: {
    overflow: 'hidden',
    borderWidth: StyleSheet.hairlineWidth * 2,
  },
  glint: {
    position: 'absolute',
    backgroundColor: 'rgba(255,255,255,0.45)',
    transform: [{ rotate: '-24deg' }],
  },
});

export default memo(BubbleBackground);
