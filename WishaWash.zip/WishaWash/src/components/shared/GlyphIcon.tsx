import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';

type MciName = keyof typeof MaterialCommunityIcons.glyphMap;

/** An Ionicons name, or a Material Community Icons name prefixed with `mci:` (e.g. `mci:car-wash`). */
export type GlyphName = keyof typeof Ionicons.glyphMap | `mci:${MciName}`;

export default function GlyphIcon({ name, size, color }: Readonly<{ name: GlyphName; size: number; color: string }>) {
  if (name.startsWith('mci:')) {
    return <MaterialCommunityIcons name={name.slice(4) as MciName} size={size} color={color} />;
  }
  return <Ionicons name={name as keyof typeof Ionicons.glyphMap} size={size} color={color} />;
}
