import { useEffect, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View, type StyleProp, type ViewStyle } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, {
  css,
  FadeIn,
  FadeInDown,
  FadeOut,
  useAnimatedStyle,
  useReducedMotion,
  useSharedValue,
  withSequence,
  withSpring,
} from 'react-native-reanimated';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import HubGlassIcon from './HubGlassIcon';

export type LivelyEmptyVariant = 'radar' | 'saved' | 'chat' | 'search' | 'bell';

export type LivelyEmptyAction = {
  key: string;
  label: string;
  icon?: keyof typeof Ionicons.glyphMap;
  primary?: boolean;
  onPress: () => void;
};

type Props = Readonly<{
  variant: LivelyEmptyVariant;
  title: string;
  subtitle?: string;
  icon?: keyof typeof Ionicons.glyphMap;
  accent?: string;
  actions?: LivelyEmptyAction[];
  /** Short hints cycled under the subtitle. */
  tips?: string[];
  compact?: boolean;
  style?: StyleProp<ViewStyle>;
}>;

const DEFAULT_ICON: Record<LivelyEmptyVariant, keyof typeof Ionicons.glyphMap> = {
  radar: 'car-sport',
  saved: 'heart',
  chat: 'chatbubbles',
  search: 'search',
  bell: 'notifications',
};

const TIP_INTERVAL_MS = 3400;
const ORBITER_SIZE = 24;

type KeyframesRule = ReturnType<typeof css.keyframes>;
type Seconds = `${number}s`;

const ringPulse = css.keyframes({
  from: { transform: [{ scale: 0.55 }], opacity: 0.6 },
  to: { transform: [{ scale: 1.9 }], opacity: 0 },
});

const ringPulseInset = css.keyframes({
  from: { transform: [{ scale: 0.45 }], opacity: 0.7 },
  to: { transform: [{ scale: 1 }], opacity: 0 },
});

const spin = css.keyframes({
  from: { transform: [{ rotate: '0deg' }] },
  to: { transform: [{ rotate: '360deg' }] },
});

const bob = css.keyframes({
  '0%': { transform: [{ translateY: 0 }] },
  '50%': { transform: [{ translateY: -6 }] },
  '100%': { transform: [{ translateY: 0 }] },
});

const heartbeat = css.keyframes({
  '0%': { transform: [{ scale: 1 }] },
  '14%': { transform: [{ scale: 1.18 }] },
  '28%': { transform: [{ scale: 1 }] },
  '42%': { transform: [{ scale: 1.12 }] },
  '70%': { transform: [{ scale: 1 }] },
  '100%': { transform: [{ scale: 1 }] },
});

const floatUp = css.keyframes({
  '0%': { opacity: 0, transform: [{ translateY: 10 }, { scale: 0.6 }] },
  '20%': { opacity: 1, transform: [{ translateY: 0 }, { scale: 0.85 }] },
  '100%': { opacity: 0, transform: [{ translateY: -48 }, { scale: 1.05 }] },
});

const typingDot = css.keyframes({
  '0%': { opacity: 0.35, transform: [{ translateY: 0 }] },
  '30%': { opacity: 1, transform: [{ translateY: -4 }] },
  '60%': { opacity: 0.35, transform: [{ translateY: 0 }] },
  '100%': { opacity: 0.35, transform: [{ translateY: 0 }] },
});

const blip = css.keyframes({
  '0%': { opacity: 0, transform: [{ scale: 0.2 }] },
  '15%': { opacity: 1, transform: [{ scale: 1 }] },
  '60%': { opacity: 0.85, transform: [{ scale: 1 }] },
  '100%': { opacity: 0, transform: [{ scale: 0.4 }] },
});

const wander = css.keyframes({
  '0%': { transform: [{ translateX: -8 }, { translateY: -4 }, { rotate: '-8deg' }] },
  '25%': { transform: [{ translateX: 8 }, { translateY: -6 }, { rotate: '6deg' }] },
  '50%': { transform: [{ translateX: 6 }, { translateY: 6 }, { rotate: '10deg' }] },
  '75%': { transform: [{ translateX: -6 }, { translateY: 5 }, { rotate: '-4deg' }] },
  '100%': { transform: [{ translateX: -8 }, { translateY: -4 }, { rotate: '-8deg' }] },
});

const burst = css.keyframes({
  from: { transform: [{ scale: 0.8 }], opacity: 0.9 },
  to: { transform: [{ scale: 2.3 }], opacity: 0 },
});

const bellSwing = css.keyframes({
  '0%': { transform: [{ rotate: '0deg' }] },
  '6%': { transform: [{ rotate: '16deg' }] },
  '12%': { transform: [{ rotate: '-14deg' }] },
  '18%': { transform: [{ rotate: '10deg' }] },
  '24%': { transform: [{ rotate: '-6deg' }] },
  '30%': { transform: [{ rotate: '0deg' }] },
  '100%': { transform: [{ rotate: '0deg' }] },
});

const orbit = css.keyframes({
  from: { transform: [{ rotate: '0deg' }] },
  to: { transform: [{ rotate: '360deg' }] },
});

const counterOrbit = css.keyframes({
  from: { transform: [{ rotate: '0deg' }] },
  to: { transform: [{ rotate: '-360deg' }] },
});

const checkPop = css.keyframes({
  '0%': { transform: [{ scale: 1 }] },
  '8%': { transform: [{ scale: 1.25 }] },
  '16%': { transform: [{ scale: 1 }] },
  '100%': { transform: [{ scale: 1 }] },
});

const BELL_ORBITERS = [
  { icon: 'car', angle: 0, color: '#38BDF8' },
  { icon: 'chatbubbles', angle: 90, color: '#A78BFA' },
  { icon: 'gift', angle: 180, color: '#FBBF24' },
  { icon: 'card', angle: 270, color: '#34D399' },
] as const;

const RADAR_BLIPS = [
  { x: 0.2, y: 0.28, delay: '0.4s' },
  { x: 0.74, y: 0.22, delay: '1.5s' },
  { x: 0.8, y: 0.7, delay: '2.3s' },
  { x: 0.26, y: 0.76, delay: '3.1s' },
] as const;

const FLOATING_HEARTS = [
  { x: -30, delay: '0s', size: 12 },
  { x: 26, delay: '1.1s', size: 10 },
  { x: -6, delay: '2.2s', size: 14 },
] as const;

function ActionChip({ action, accent }: Readonly<{ action: LivelyEmptyAction; accent: string }>) {
  const scale = useSharedValue(1);
  const animatedStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  const tint = action.primary ? '#0B1220' : accent;

  return (
    <Pressable
      onPressIn={() => {
        scale.value = withSpring(0.93, { damping: 18, stiffness: 320 });
      }}
      onPressOut={() => {
        scale.value = withSpring(1, { damping: 14, stiffness: 260 });
      }}
      onPress={() => {
        hapticFeedback('light');
        action.onPress();
      }}
      accessibilityRole="button"
      accessibilityLabel={action.label}
    >
      <Animated.View
        style={[
          styles.chip,
          action.primary
            ? { backgroundColor: accent, borderColor: accent }
            : { borderColor: `${accent}55`, backgroundColor: `${accent}14` },
          animatedStyle,
        ]}
      >
        {action.icon ? <Ionicons name={action.icon} size={14} color={tint} /> : null}
        <Text style={[styles.chipText, { color: action.primary ? '#0B1220' : '#E2E8F0' }]} numberOfLines={1}>
          {action.label}
        </Text>
      </Animated.View>
    </Pressable>
  );
}

function RotatingTips({ tips, paused }: Readonly<{ tips: string[]; paused: boolean }>) {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    if (tips.length < 2 || paused) return;
    const id = setInterval(() => setIndex((i) => (i + 1) % tips.length), TIP_INTERVAL_MS);
    return () => clearInterval(id);
  }, [tips.length, paused]);

  const tip = tips[index % tips.length];
  return (
    <View style={styles.tipRow}>
      <Animated.View
        key={`tip-${index}`}
        entering={FadeInDown.duration(320)}
        exiting={FadeOut.duration(180)}
        style={styles.tipInner}
      >
        <Ionicons name="bulb-outline" size={13} color="rgba(250,204,21,0.9)" />
        <Text style={styles.tipText} numberOfLines={1}>
          {tip}
        </Text>
      </Animated.View>
    </View>
  );
}

export default function LivelyEmptyState({
  variant,
  title,
  subtitle,
  icon,
  accent = '#38BDF8',
  actions,
  tips,
  compact = false,
  style,
}: Props) {
  const reduceMotion = useReducedMotion();
  const playState = reduceMotion ? 'paused' : 'running';
  const heroSize = compact ? 68 : 120;
  const coreSize = compact ? 40 : 68;
  const iconName = icon ?? DEFAULT_ICON[variant];

  const tapScale = useSharedValue(1);
  const tapStyle = useAnimatedStyle(() => ({ transform: [{ scale: tapScale.value }] }));
  const [burstKey, setBurstKey] = useState(0);

  const onHeroPress = () => {
    hapticFeedback(variant === 'saved' ? 'medium' : 'soft');
    tapScale.value = withSequence(
      withSpring(0.86, { damping: 14, stiffness: 420 }),
      withSpring(1, { damping: 9, stiffness: 220 }),
    );
    setBurstKey((k) => k + 1);
  };

  const ringBase = {
    width: heroSize,
    height: heroSize,
    borderRadius: heroSize / 2,
    borderColor: `${accent}66`,
  };

  const loop = (
    name: KeyframesRule,
    duration: Seconds,
    delay: Seconds = '0s',
    timing: 'linear' | 'ease-out' | 'ease-in-out' = 'ease-in-out',
  ) =>
    ({
      animationName: name,
      animationDuration: duration,
      animationDelay: delay,
      animationIterationCount: 'infinite',
      animationTimingFunction: timing,
      animationPlayState: playState,
    }) as const;

  const hero = (
      <Pressable onPress={onHeroPress} accessibilityRole="button" accessibilityLabel={title} hitSlop={8}>
        <Animated.View
          entering={FadeIn.duration(420)}
          style={[
            styles.hero,
            { width: heroSize, height: heroSize },
            compact && { marginBottom: 0, overflow: 'hidden', borderRadius: heroSize / 2, backgroundColor: `${accent}0F` },
          ]}
        >
          {variant === 'radar' || variant === 'search' ? (
            <>
              {(['0s', '0.9s', '1.8s'] as const).map((delay) => (
                <Animated.View
                  key={delay}
                  pointerEvents="none"
                  style={[styles.ring, ringBase, loop(compact ? ringPulseInset : ringPulse, '2.7s', delay, 'ease-out')]}
                />
              ))}
            </>
          ) : null}

          {variant === 'radar' ? (
            <>
              <Animated.View
                pointerEvents="none"
                style={[
                  StyleSheet.absoluteFill,
                  { borderRadius: heroSize / 2 },
                  loop(spin, '3.6s', '0s', 'linear'),
                ]}
              >
                <LinearGradient
                  colors={[`${accent}00`, `${accent}55`]}
                  start={{ x: 0, y: 0.5 }}
                  end={{ x: 1, y: 0.5 }}
                  style={[styles.sweep, { width: heroSize / 2, height: heroSize / 2, borderTopRightRadius: heroSize / 2 }]}
                />
              </Animated.View>
              {RADAR_BLIPS.map((b) => (
                <Animated.View
                  key={b.delay}
                  pointerEvents="none"
                  style={[
                    styles.blip,
                    { left: heroSize * b.x - 4, top: heroSize * b.y - 4, backgroundColor: accent },
                    loop(blip, '3.6s', b.delay, 'ease-out'),
                  ]}
                />
              ))}
            </>
          ) : null}

          {variant === 'bell' ? (
            <>
              <Animated.View
                pointerEvents="none"
                style={[styles.ring, ringBase, loop(ringPulse, '3.6s', '0.15s', 'ease-out')]}
              />
              {compact ? null : (
                <Animated.View
                  pointerEvents="none"
                  style={[StyleSheet.absoluteFill, loop(orbit, '18s', '0s', 'linear')]}
                >
                  {BELL_ORBITERS.map((o) => {
                    const r = heroSize / 2 - 4;
                    const rad = (o.angle * Math.PI) / 180;
                    return (
                      <View
                        key={o.icon}
                        style={[
                          styles.orbiter,
                          {
                            left: heroSize / 2 + r * Math.cos(rad) - ORBITER_SIZE / 2,
                            top: heroSize / 2 + r * Math.sin(rad) - ORBITER_SIZE / 2,
                            backgroundColor: `${o.color}2E`,
                          },
                        ]}
                      >
                        <Animated.View style={loop(counterOrbit, '18s', '0s', 'linear')}>
                          <Ionicons name={o.icon} size={12} color={o.color} />
                        </Animated.View>
                      </View>
                    );
                  })}
                </Animated.View>
              )}
            </>
          ) : null}

          {variant === 'saved'
            ? FLOATING_HEARTS.map((h) => (
                <Animated.View
                  key={h.delay}
                  pointerEvents="none"
                  style={[
                    styles.floatingHeart,
                    { marginLeft: h.x },
                    loop(floatUp, '3.3s', h.delay, 'ease-out'),
                  ]}
                >
                  <Ionicons name="heart" size={h.size} color={accent} />
                </Animated.View>
              ))
            : null}

          <Animated.View
            key={`burst-${burstKey}`}
            pointerEvents="none"
            style={[
              styles.ring,
              { width: coreSize, height: coreSize, borderRadius: coreSize / 2, borderColor: accent, borderWidth: 2 },
              burstKey > 0
                ? {
                    animationName: burst,
                    animationDuration: '0.6s',
                    animationTimingFunction: 'ease-out',
                    animationFillMode: 'forwards',
                  }
                : { opacity: 0 },
            ]}
          />

          <Animated.View
            style={[
              variant === 'search' ? loop(wander, '4.2s') : loop(bob, '2.8s'),
            ]}
          >
            <Animated.View style={tapStyle}>
              <Animated.View
                style={
                  variant === 'saved'
                    ? loop(heartbeat, '1.6s')
                    : variant === 'bell'
                      ? loop(bellSwing, '3.6s')
                      : undefined
                }
              >
                <HubGlassIcon icon={iconName} size={coreSize} accent={accent} />
              </Animated.View>
            </Animated.View>

            {variant === 'bell' ? (
              <Animated.View
                pointerEvents="none"
                style={[styles.checkBadge, compact && styles.checkBadgeCompact, loop(checkPop, '3.6s', '1.1s')]}
              >
                <Ionicons name="checkmark" size={compact ? 10 : 13} color="#052E1C" />
              </Animated.View>
            ) : null}

            {variant === 'chat' ? (
              <View style={[styles.typingBubble, compact && styles.typingBubbleCompact, { borderColor: `${accent}55` }]}>
                {(['0s', '0.18s', '0.36s'] as const).map((delay) => (
                  <Animated.View
                    key={delay}
                    style={[styles.typingDot, { backgroundColor: accent }, loop(typingDot, '1.2s', delay)]}
                  />
                ))}
              </View>
            ) : null}
          </Animated.View>
        </Animated.View>
      </Pressable>
  );

  const chips = actions?.map((a, i) => (
    <Animated.View key={a.key} entering={FadeInDown.delay(220 + i * 70).springify().damping(16)}>
      <ActionChip action={a} accent={accent} />
    </Animated.View>
  ));

  if (compact) {
    return (
      <View style={[styles.containerCompact, style]}>
        <View style={styles.compactRow}>
          {hero}
          <View style={styles.compactText}>
            <Animated.Text
              entering={FadeInDown.delay(80).springify().damping(18)}
              style={[styles.title, styles.titleCompact]}
              numberOfLines={1}
            >
              {title}
            </Animated.Text>
            {subtitle ? (
              <Animated.Text
                entering={FadeInDown.delay(150).springify().damping(18)}
                style={[styles.subtitle, styles.subtitleCompact]}
                numberOfLines={2}
              >
                {subtitle}
              </Animated.Text>
            ) : null}
          </View>
        </View>
        {chips && chips.length > 0 ? (
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            style={styles.compactChipScroll}
            contentContainerStyle={styles.compactChipRow}
            keyboardShouldPersistTaps="handled"
          >
            {chips}
          </ScrollView>
        ) : null}
      </View>
    );
  }

  return (
    <View style={[styles.container, style]}>
      {hero}

      <Animated.Text entering={FadeInDown.delay(80).springify().damping(18)} style={styles.title}>
        {title}
      </Animated.Text>
      {subtitle ? (
        <Animated.Text entering={FadeInDown.delay(150).springify().damping(18)} style={styles.subtitle}>
          {subtitle}
        </Animated.Text>
      ) : null}

      {tips && tips.length > 0 ? <RotatingTips tips={tips} paused={reduceMotion} /> : null}

      {chips && chips.length > 0 ? <View style={styles.chipRow}>{chips}</View> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  containerCompact: { paddingHorizontal: 4, paddingVertical: 6 },
  compactRow: { flexDirection: 'row', alignItems: 'center', gap: 14 },
  compactText: { flex: 1, minWidth: 0 },
  compactChipScroll: { marginTop: 12, flexGrow: 0 },
  compactChipRow: { gap: 8, paddingRight: 4 },
  hero: {
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 14,
  },
  ring: {
    position: 'absolute',
    borderWidth: 1.5,
  },
  sweep: {
    position: 'absolute',
    right: 0,
    top: 0,
  },
  blip: {
    position: 'absolute',
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  floatingHeart: {
    position: 'absolute',
    top: '30%',
  },
  typingBubble: {
    position: 'absolute',
    right: -26,
    top: -10,
    flexDirection: 'row',
    gap: 3,
    paddingHorizontal: 8,
    paddingVertical: 6,
    borderRadius: 12,
    borderBottomLeftRadius: 4,
    borderWidth: 1,
    backgroundColor: 'rgba(15,23,42,0.92)',
  },
  orbiter: {
    position: 'absolute',
    width: ORBITER_SIZE,
    height: ORBITER_SIZE,
    borderRadius: ORBITER_SIZE / 2,
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkBadge: {
    position: 'absolute',
    right: -4,
    bottom: -2,
    width: 22,
    height: 22,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#34D399',
    shadowColor: '#34D399',
    shadowOpacity: 0.6,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 0 },
  },
  checkBadgeCompact: { right: -3, bottom: -2, width: 16, height: 16, borderRadius: 8 },
  typingBubbleCompact: { right: -6, top: -6, paddingHorizontal: 5, paddingVertical: 4 },
  typingDot: { width: 5, height: 5, borderRadius: 2.5 },
  title: {
    color: '#F8FAFC',
    fontSize: 19,
    fontWeight: '800',
    letterSpacing: 0.2,
    textAlign: 'center',
  },
  titleCompact: { fontSize: 16, textAlign: 'left' },
  subtitle: {
    marginTop: 6,
    color: 'rgba(203,213,225,0.75)',
    fontSize: 13.5,
    lineHeight: 19,
    textAlign: 'center',
    maxWidth: 320,
  },
  subtitleCompact: { marginTop: 3, fontSize: 12.5, lineHeight: 17, textAlign: 'left', maxWidth: undefined },
  tipRow: {
    marginTop: 10,
    height: 20,
    alignSelf: 'stretch',
    alignItems: 'center',
    justifyContent: 'center',
  },
  tipInner: {
    position: 'absolute',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    maxWidth: '100%',
  },
  tipText: { color: 'rgba(226,232,240,0.7)', fontSize: 12, fontWeight: '600' },
  chipRow: {
    marginTop: 14,
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: 8,
  },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 14,
    paddingVertical: 9,
    borderRadius: 999,
    borderWidth: 1,
  },
  chipText: { fontSize: 13, fontWeight: '700' },
});
