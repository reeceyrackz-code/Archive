import React, { useEffect, useRef } from 'react';
import {
  Animated,
  Dimensions,
  Easing,
  Keyboard,
  Platform,
  StyleSheet,
  TextInput,
  type KeyboardEvent,
  type StyleProp,
  type ViewStyle,
} from 'react-native';

/** Gap kept between the bottom of the focused input and the top of the keyboard. */
const INPUT_KEYBOARD_GAP = 16;
/** While the keyboard is up, re-check this often so switching fields (or layout changes) stay visible. */
const RECHECK_INTERVAL_MS = 250;

type Props = {
  children: React.ReactNode;
  style?: StyleProp<ViewStyle>;
};

/**
 * App-wide safety net: when the keyboard is shown and the focused TextInput would sit underneath it,
 * slides the whole screen up just enough to reveal it (and back down when it's hidden).
 *
 * Runs after the keyboard has settled, so screens with their own KeyboardAvoidingView / keyboard
 * handling move first and this only corrects whatever overlap is left (usually none).
 * Inputs inside a native `Modal` render in a separate window and are not affected.
 */
export default function KeyboardInputGuard({ children, style }: Props) {
  const shift = useRef(new Animated.Value(0)).current;
  const shiftValue = useRef(0);
  const keyboardTop = useRef<number | null>(null);
  const animating = useRef(false);
  const recheckTimer = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    const animateTo = (to: number, duration = 220) => {
      if (Math.abs(to - shiftValue.current) < 1) return;
      shiftValue.current = to;
      animating.current = true;
      Animated.timing(shift, {
        toValue: to,
        duration,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }).start(() => {
        animating.current = false;
      });
    };

    const ensureFocusedInputVisible = () => {
      const top = keyboardTop.current;
      if (top == null || animating.current) return;
      const input = TextInput.State.currentlyFocusedInput?.() as
        | { measureInWindow?: (cb: (x: number, y: number, w: number, h: number) => void) => void }
        | null
        | undefined;
      if (!input?.measureInWindow) {
        animateTo(0);
        return;
      }
      input.measureInWindow((_x, y, _w, h) => {
        if (keyboardTop.current == null || !Number.isFinite(y) || h <= 0) return;
        const visibleBottom = keyboardTop.current - INPUT_KEYBOARD_GAP;
        const overlap = y + h - visibleBottom;
        // Measurement already includes the current shift; nudge by the remaining overlap,
        // never pushing the input above the top of the screen.
        const maxShift = Math.max(0, y - shiftValue.current - 60);
        const next = Math.max(-maxShift, Math.min(0, shiftValue.current - overlap));
        animateTo(next);
      });
    };

    const onShow = (e: KeyboardEvent) => {
      const screenH = Dimensions.get('window').height;
      keyboardTop.current = e.endCoordinates.screenY > 0
        ? e.endCoordinates.screenY
        : screenH - e.endCoordinates.height;
      ensureFocusedInputVisible();
      if (!recheckTimer.current) {
        recheckTimer.current = setInterval(ensureFocusedInputVisible, RECHECK_INTERVAL_MS);
      }
    };

    const onHide = () => {
      keyboardTop.current = null;
      if (recheckTimer.current) {
        clearInterval(recheckTimer.current);
        recheckTimer.current = null;
      }
      animating.current = false;
      animateTo(0, 200);
    };

    const subs = [
      Keyboard.addListener('keyboardDidShow', onShow),
      Keyboard.addListener(Platform.OS === 'ios' ? 'keyboardWillHide' : 'keyboardDidHide', onHide),
    ];
    if (Platform.OS === 'ios') {
      subs.push(Keyboard.addListener('keyboardDidChangeFrame', (e) => {
        if (keyboardTop.current != null) onShow(e);
      }));
    }

    return () => {
      subs.forEach((s) => s.remove());
      if (recheckTimer.current) clearInterval(recheckTimer.current);
    };
  }, [shift]);

  return (
    <Animated.View style={[styles.fill, style, { transform: [{ translateY: shift }] }]}>
      {children}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  fill: { flex: 1 },
});
