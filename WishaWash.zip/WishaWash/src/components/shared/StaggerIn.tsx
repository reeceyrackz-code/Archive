import React from 'react';
import type { StyleProp, ViewStyle } from 'react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';

type StaggerInProps = {
  index?: number;
  style?: StyleProp<ViewStyle>;
  children: React.ReactNode;
};

/** Fades + springs content up on mount, delayed by `index` for a staggered cascade. */
export default function StaggerIn({ index = 0, style, children }: StaggerInProps) {
  return (
    <Animated.View
      entering={FadeInDown.delay(60 + index * 70)
        .springify()
        .damping(18)
        .stiffness(170)}
      style={style}
    >
      {children}
    </Animated.View>
  );
}
