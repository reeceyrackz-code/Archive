import React, { useEffect } from 'react';
import type { StyleProp, ViewStyle } from 'react-native';
import { useVideoPlayer, VideoView, type VideoSource } from 'expo-video';

type BackgroundVideoProps = {
  source: VideoSource;
  style?: StyleProp<ViewStyle>;
  onReady?: () => void;
};

export default function BackgroundVideo({ source, style, onReady }: BackgroundVideoProps) {
  const player = useVideoPlayer(source, (p) => {
    p.loop = true;
    p.muted = true;
    p.play();
  });

  useEffect(() => {
    if (!onReady) return;
    if (player.status === 'readyToPlay') {
      onReady();
      return;
    }
    const sub = player.addListener('statusChange', ({ status }) => {
      if (status === 'readyToPlay') onReady();
    });
    return () => sub.remove();
  }, [player, onReady]);

  return (
    <VideoView
      player={player}
      style={style}
      contentFit="cover"
      nativeControls={false}
      allowsPictureInPicture={false}
      pointerEvents="none"
    />
  );
}
