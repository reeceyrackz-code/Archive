import { StyleSheet, View, type StyleProp, type ViewStyle } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import GlyphIcon, { type GlyphName } from './GlyphIcon';

export type HubGlassPalette = {
  gradient: readonly [string, string, string];
  icon: string;
  rim: string;
  glow: string;
};

/** Palettes from the dashboard "Your Hub" tiles. */
export const HUB_GLASS_PALETTES = {
  sky: {
    gradient: ['rgba(56,189,248,0.55)', 'rgba(14,165,233,0.32)', 'rgba(8,47,73,0.35)'],
    icon: '#E0F2FE',
    rim: 'rgba(125,211,252,0.55)',
    glow: '#38BDF8',
  },
  gold: {
    gradient: ['rgba(251,191,36,0.5)', 'rgba(245,158,11,0.28)', 'rgba(69,26,3,0.32)'],
    icon: '#FEF3C7',
    rim: 'rgba(252,211,77,0.5)',
    glow: '#F59E0B',
  },
  green: {
    gradient: ['rgba(52,211,153,0.48)', 'rgba(16,185,129,0.28)', 'rgba(6,78,59,0.32)'],
    icon: '#D1FAE5',
    rim: 'rgba(110,231,183,0.5)',
    glow: '#34D399',
  },
  pink: {
    gradient: ['rgba(244,114,182,0.5)', 'rgba(236,72,153,0.28)', 'rgba(80,7,36,0.32)'],
    icon: '#FCE7F3',
    rim: 'rgba(249,168,212,0.5)',
    glow: '#F472B6',
  },
  violet: {
    gradient: ['rgba(167,139,250,0.5)', 'rgba(139,92,246,0.28)', 'rgba(46,16,101,0.32)'],
    icon: '#EDE9FE',
    rim: 'rgba(196,181,253,0.5)',
    glow: '#A78BFA',
  },
  red: {
    gradient: ['rgba(248,113,113,0.5)', 'rgba(239,68,68,0.28)', 'rgba(69,10,10,0.32)'],
    icon: '#FEE2E2',
    rim: 'rgba(252,165,165,0.5)',
    glow: '#EF4444',
  },
} satisfies Record<string, HubGlassPalette>;

export type HubGlassTone = keyof typeof HUB_GLASS_PALETTES;

function parseHex(hex: string): [number, number, number] | null {
  const m = /^#?([0-9a-f]{3}|[0-9a-f]{6})(?:[0-9a-f]{2})?$/i.exec(hex.trim());
  if (!m) return null;
  let h = m[1]!;
  if (h.length === 3) h = h.split('').map((c) => c + c).join('');
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
}

const mix = (c: number, target: number, t: number) => Math.round(c + (target - c) * t);

/** Builds a Your Hub style palette from a tone name or any hex accent. */
export function hubGlassPalette(accent: HubGlassTone | string): HubGlassPalette {
  if (accent in HUB_GLASS_PALETTES) return HUB_GLASS_PALETTES[accent as HubGlassTone];
  const rgb = parseHex(accent);
  if (!rgb) return HUB_GLASS_PALETTES.sky;
  const [r, g, b] = rgb;
  const rgba = (rr: number, gg: number, bb: number, a: number) => `rgba(${rr},${gg},${bb},${a})`;
  return {
    gradient: [
      rgba(r, g, b, 0.52),
      rgba(mix(r, 0, 0.15), mix(g, 0, 0.15), mix(b, 0, 0.15), 0.3),
      rgba(mix(r, 0, 0.75), mix(g, 0, 0.75), mix(b, 0, 0.7), 0.34),
    ],
    icon: rgba(mix(r, 255, 0.82), mix(g, 255, 0.82), mix(b, 255, 0.82), 1),
    rim: rgba(mix(r, 255, 0.35), mix(g, 255, 0.35), mix(b, 255, 0.35), 0.52),
    glow: accent,
  };
}

type Props = Readonly<{
  icon: GlyphName;
  /** Well diameter. */
  size?: number;
  iconSize?: number;
  accent?: HubGlassTone | string;
  palette?: HubGlassPalette;
  glow?: boolean;
  style?: StyleProp<ViewStyle>;
}>;

export default function HubGlassIcon({
  icon,
  size = 48,
  iconSize,
  accent = 'sky',
  palette,
  glow = true,
  style,
}: Props) {
  const p = palette ?? hubGlassPalette(accent);
  return (
    <View
      style={[
        styles.well,
        {
          width: size,
          height: size,
          borderRadius: size / 2,
          shadowColor: p.glow,
          shadowRadius: Math.max(4, size * 0.2),
          shadowOffset: { width: 0, height: Math.max(2, size * 0.08) },
          shadowOpacity: glow ? 0.32 : 0,
          elevation: glow ? 6 : 0,
        },
        style,
      ]}
    >
      <View style={[StyleSheet.absoluteFill, styles.clip, { borderRadius: size / 2 }]} pointerEvents="none">
        <LinearGradient colors={[...p.gradient]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} />
        <LinearGradient
          colors={['rgba(255,255,255,0.28)', 'rgba(255,255,255,0.04)', 'transparent']}
          start={{ x: 0.2, y: 0 }}
          end={{ x: 0.8, y: 1 }}
          style={StyleSheet.absoluteFill}
        />
      </View>
      <View pointerEvents="none" style={[styles.rim, { borderColor: p.rim, borderRadius: size / 2 }]} />
      <GlyphIcon name={icon} size={iconSize ?? Math.round(size * 0.5)} color={p.icon} />
    </View>
  );
}

const styles = StyleSheet.create({
  well: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(2,10,24,0.28)',
  },
  clip: { overflow: 'hidden' },
  rim: { ...StyleSheet.absoluteFill, borderWidth: 1 },
});
