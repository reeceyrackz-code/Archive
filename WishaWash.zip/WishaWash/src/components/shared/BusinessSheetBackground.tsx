/**
 * Shared fill for map bottom sheets — matches “Where’s the ride?” header glass.
 * Also reports the sheet's frame so maps underneath keep their legal label visible.
 */
import React from 'react';
import { StyleSheet, View } from 'react-native';
import BookingMapGlassBackground from '../booking/BookingMapGlassBackground';
import { useReportMapObstruction } from '../../hooks/useMapObstruction';

type Props = Readonly<{
  /** Off for modal overlays, which sit above the map only temporarily. */
  reportObstruction?: boolean;
}>;

export default function BusinessSheetBackground({ reportObstruction = true }: Props) {
  const { ref, onLayout } = useReportMapObstruction(reportObstruction);
  return (
    <View ref={ref} onLayout={onLayout} style={StyleSheet.absoluteFill} pointerEvents="none" collapsable={false}>
      <BookingMapGlassBackground />
    </View>
  );
}
