import type { ReactNode } from 'react';
import { Image, Pressable, StyleSheet, Text, View, type ImageSourcePropType } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { FadeInDown, useAnimatedStyle, useSharedValue, withSpring } from 'react-native-reanimated';
import GlyphIcon, { type GlyphName } from './GlyphIcon';

type IconName = keyof typeof Ionicons.glyphMap;

export type InfoSheetChip = Readonly<{ icon: IconName; label: string; accent?: string }>;

/** Glass hero at the top of an info sheet: glowing icon (or picture), eyebrow, title, quick-fact chips. */
export function InfoSheetHero({
  accent,
  icon,
  image,
  imageUri,
  eyebrow,
  title,
  subtitle,
  chips,
}: Readonly<{
  accent: string;
  icon: GlyphName;
  image?: ImageSourcePropType | null;
  imageUri?: string | null;
  eyebrow?: string;
  title: string;
  subtitle?: string;
  chips?: readonly InfoSheetChip[];
}>) {
  return (
    <Animated.View entering={FadeInDown.springify().damping(18)} style={hero.shell}>
      <LinearGradient
        colors={['rgba(255,255,255,0.12)', 'rgba(255,255,255,0.03)']}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <View style={[StyleSheet.absoluteFill, { backgroundColor: accent, opacity: 0.08 }]} pointerEvents="none" />

      {imageUri ? <Image source={{ uri: imageUri }} style={hero.photo} resizeMode="cover" /> : null}

      <View style={hero.row}>
        {image ? (
          <Image source={image} style={hero.leadImage} resizeMode="cover" />
        ) : (
          <View style={[hero.iconDot, { backgroundColor: accent }]}>
            <GlyphIcon name={icon} size={22} color="#0B1220" />
          </View>
        )}
        <View style={hero.textCol}>
          {eyebrow ? (
            <Text style={[hero.eyebrow, { color: accent }]} numberOfLines={1}>
              {eyebrow}
            </Text>
          ) : null}
          <Text style={hero.title} numberOfLines={2}>
            {title}
          </Text>
          {subtitle ? (
            <Text style={hero.subtitle} numberOfLines={2}>
              {subtitle}
            </Text>
          ) : null}
        </View>
      </View>

      {chips && chips.length > 0 ? (
        <View style={hero.chips}>
          {chips.map((chip, i) => {
            const tint = chip.accent ?? accent;
            return (
              <Animated.View
                key={`${chip.icon}-${chip.label}`}
                entering={FadeInDown.delay(80 + i * 50).springify().damping(18)}
                style={hero.chip}
              >
                <Ionicons name={chip.icon} size={12} color={tint} />
                <Text style={hero.chipText} numberOfLines={1}>
                  {chip.label}
                </Text>
              </Animated.View>
            );
          })}
        </View>
      ) : null}
    </Animated.View>
  );
}

/** Titled glass card section; `index` staggers its entrance. */
export function InfoSheetSection({
  title,
  icon,
  accent,
  index = 0,
  children,
}: Readonly<{ title: string; icon?: IconName; accent: string; index?: number; children: ReactNode }>) {
  return (
    <Animated.View entering={FadeInDown.delay(120 + index * 70).springify().damping(18)} style={section.wrap}>
      <View style={section.labelRow}>
        {icon ? <Ionicons name={icon} size={13} color={accent} /> : null}
        <Text style={section.label}>{title}</Text>
      </View>
      <View style={section.card}>{children}</View>
    </Animated.View>
  );
}

/** Checklist rows with accent tick circles. */
export function InfoSheetChecklist({ items, accent }: Readonly<{ items: readonly string[]; accent: string }>) {
  return (
    <View style={list.wrap}>
      {items.map((item, i) => (
        <Animated.View
          key={item}
          entering={FadeInDown.delay(180 + Math.min(i, 8) * 40).springify().damping(18)}
          style={list.row}
        >
          <View style={[list.tick, { backgroundColor: accent }]}>
            <Ionicons name="checkmark" size={11} color="#0B1220" />
          </View>
          <Text style={list.text}>{item}</Text>
        </Animated.View>
      ))}
    </View>
  );
}

/** Label/value row with a small tinted icon; `last` drops the divider. */
export function InfoSheetRow({
  icon,
  accent,
  label,
  value,
  valueColor,
  last,
}: Readonly<{
  icon: GlyphName;
  accent: string;
  label: string;
  value: string;
  valueColor?: string;
  last?: boolean;
}>) {
  return (
    <View style={[row.wrap, !last && row.divider]}>
      <View style={[row.icon, { backgroundColor: `${accent}22` }]}>
        <GlyphIcon name={icon} size={14} color={accent} />
      </View>
      <Text style={row.label} numberOfLines={1}>
        {label}
      </Text>
      <Text style={[row.value, valueColor ? { color: valueColor } : null]} numberOfLines={2}>
        {value}
      </Text>
    </View>
  );
}

/** Small stat tile used in a row of 2–4 (e.g. washes / last clean / rating). */
export function InfoSheetStat({
  icon,
  accent,
  value,
  label,
}: Readonly<{ icon: IconName; accent: string; value: string; label: string }>) {
  return (
    <View style={[stat.tile, { backgroundColor: `${accent}14` }]}>
      <Ionicons name={icon} size={16} color={accent} />
      <Text style={stat.value} numberOfLines={1}>
        {value}
      </Text>
      <Text style={stat.label} numberOfLines={1}>
        {label}
      </Text>
    </View>
  );
}

/** Full-width gradient close / confirm button with press spring. */
export function InfoSheetButton({
  accent,
  label,
  icon = 'checkmark',
  onPress,
}: Readonly<{ accent: string; label: string; icon?: IconName; onPress: () => void }>) {
  const scale = useSharedValue(1);
  const pressStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));

  return (
    <Animated.View style={[btn.wrap, { shadowColor: accent }, pressStyle]}>
      <Pressable
        onPress={onPress}
        onPressIn={() => {
          scale.value = withSpring(0.97, { damping: 18, stiffness: 320 });
        }}
        onPressOut={() => {
          scale.value = withSpring(1, { damping: 14, stiffness: 260 });
        }}
        accessibilityRole="button"
        accessibilityLabel={label}
      >
        <View style={btn.fill}>
          <LinearGradient
            colors={[accent, `${accent}D9`]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={StyleSheet.absoluteFill}
          />
          <LinearGradient
            colors={['rgba(255,255,255,0.3)', 'rgba(255,255,255,0)']}
            start={{ x: 0, y: 0 }}
            end={{ x: 0, y: 0.75 }}
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
          />
          <Text style={btn.text}>{label}</Text>
          <View style={btn.iconWrap}>
            <Ionicons name={icon} size={17} color="#F8FAFC" />
          </View>
        </View>
      </Pressable>
    </Animated.View>
  );
}

const hero = StyleSheet.create({
  shell: {
    borderRadius: 24,
    overflow: 'hidden',
    padding: 14,
    marginBottom: 14,
    backgroundColor: 'rgba(2,6,23,0.35)',
  },
  iconDot: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  photo: {
    width: '100%',
    height: 120,
    borderRadius: 16,
    marginBottom: 12,
  },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  leadImage: { width: 48, height: 48, borderRadius: 24 },
  textCol: { flex: 1, minWidth: 0, gap: 2 },
  eyebrow: { fontSize: 10.5, fontWeight: '800', letterSpacing: 0.8, textTransform: 'uppercase' },
  title: { color: '#F8FAFC', fontSize: 18, fontWeight: '800', letterSpacing: -0.3 },
  subtitle: { color: 'rgba(203,213,225,0.82)', fontSize: 12.5, fontWeight: '500', lineHeight: 17 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 12 },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    height: 26,
    paddingHorizontal: 10,
    borderRadius: 13,
    backgroundColor: 'rgba(255,255,255,0.07)',
  },
  chipText: { color: '#E2E8F0', fontSize: 11.5, fontWeight: '700' },
});

const section = StyleSheet.create({
  wrap: { marginBottom: 14 },
  labelRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 8, paddingHorizontal: 2 },
  label: {
    color: 'rgba(148,163,184,0.9)',
    fontSize: 10.5,
    fontWeight: '800',
    letterSpacing: 0.9,
    textTransform: 'uppercase',
  },
  card: {
    borderRadius: 22,
    padding: 14,
    backgroundColor: 'rgba(2,6,23,0.35)',
  },
});

const list = StyleSheet.create({
  wrap: { gap: 10 },
  row: { flexDirection: 'row', alignItems: 'flex-start', gap: 10 },
  tick: {
    width: 20,
    height: 20,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 0,
  },
  text: { flex: 1, color: '#E2E8F0', fontSize: 13.5, lineHeight: 20, fontWeight: '500' },
});

const row = StyleSheet.create({
  wrap: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 9 },
  divider: { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: 'rgba(148,163,184,0.18)' },
  icon: { width: 28, height: 28, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  label: { color: 'rgba(203,213,225,0.85)', fontSize: 13.5, fontWeight: '500' },
  value: { flex: 1, color: '#F8FAFC', fontSize: 13.5, fontWeight: '700', textAlign: 'right' },
});

const stat = StyleSheet.create({
  tile: {
    flex: 1,
    alignItems: 'center',
    gap: 3,
    paddingVertical: 12,
    paddingHorizontal: 6,
    borderRadius: 16,
  },
  value: { color: '#F8FAFC', fontSize: 15, fontWeight: '800', letterSpacing: -0.2 },
  label: { color: 'rgba(203,213,225,0.7)', fontSize: 11, fontWeight: '600' },
});

const btn = StyleSheet.create({
  wrap: {
    marginTop: 6,
    borderRadius: 27,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.38,
    shadowRadius: 14,
    elevation: 8,
  },
  fill: {
    height: 54,
    borderRadius: 27,
    overflow: 'hidden',
    flexDirection: 'row',
    alignItems: 'center',
    paddingLeft: 20,
    paddingRight: 7,
  },
  text: { flex: 1, color: '#0B1220', fontSize: 15, fontWeight: '800', letterSpacing: -0.1 },
  iconWrap: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(11,18,32,0.88)',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
