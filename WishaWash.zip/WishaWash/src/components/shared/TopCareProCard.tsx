import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Pressable,
  Image,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import Animated, { css, useAnimatedStyle, useSharedValue, withSequence, withSpring } from 'react-native-reanimated';
import { colors } from '../../constants/colors';
import { BOOKING_CARD, BOOKING_GLASS_TOP_SHEEN, BOOKING_GLASS_TOP_SHEEN_LOCATIONS } from '../../constants/bookingCardTheme';
import { formatDisplayName } from '../../utils/formatDisplayName';
import GradientIconBox from './GradientIconBox';
import HubGlassIcon from './HubGlassIcon';
import { accentToGradient } from '../../utils/accentGradient';
import { CCP } from '../../constants/carCareProLabels';
import SearchingProState from './SearchingProState';
import { hapticFeedback } from '../../services/HapticFeedbackService';

const SKY = colors.SKY;
const ONLINE = '#34D399';
const OFFLINE = '#94A3B8';
const GOLD = '#FBBF24';

export type TopCareProCardData = {
  id: string;
  name: string;
  rating: number;
  totalJobs: number;
  reviewCount?: number;
  distance?: number | null;
  isOnline: boolean;
  profilePicture?: string | null;
  isFavourite?: boolean;
  /** Customer total for the selected service (incl. fee), when known. */
  price?: number | null;
};

type Props = {
  pro?: TopCareProCardData | null;
  width?: number;
  accent?: string;
  borderColor?: string;
  rank?: number;
  variant?: 'default' | 'compact';
  /** Scales the default card layout (1 = full size). */
  zoom?: number;
  /** Same card chrome as Pros, used while matching / loading nearby Pros. */
  searching?: boolean;
  searchingTitle?: string;
  searchingSubtitle?: string;
  searchingBusy?: boolean;
  onPress?: () => void;
  onToggleFavourite?: () => void;
  onBook?: () => void;
  /** Padlock the card (e.g. a saved pro who is offline and can't be booked yet). */
  locked?: boolean;
  style?: StyleProp<ViewStyle>;
};

const RANK_COLORS: Record<number, string> = {
  1: '#FBBF24',
  2: '#CBD5E1',
  3: '#D97706',
};

const onlinePulse = css.keyframes({
  from: { transform: [{ scale: 1 }], opacity: 0.55 },
  to: { transform: [{ scale: 1.35 }], opacity: 0 },
});

function buildCompactMeta(pro: TopCareProCardData): string {
  const parts: string[] = [];
  parts.push(pro.rating > 0 ? `${pro.rating.toFixed(1)} ★` : 'New');
  parts.push(`${pro.totalJobs} jobs`);
  if (pro.distance != null) parts.push(`${pro.distance.toFixed(1)} mi`);
  else if (pro.reviewCount != null && pro.reviewCount > 0) {
    parts.push(`${pro.reviewCount} reviews`);
  }
  if (pro.price != null && Number.isFinite(pro.price)) {
    parts.push(`£${Number(pro.price).toFixed(2)}`);
  }
  parts.push(pro.isOnline ? 'Available' : 'Offline');
  return parts.join(' · ');
}

function getProBadge(pro: TopCareProCardData): { label: string; icon: keyof typeof Ionicons.glyphMap; color: string } {
  if (pro.rating >= 4.8 && pro.totalJobs >= 10) return { label: 'Top rated', icon: 'ribbon', color: GOLD };
  if (pro.totalJobs < 5) return { label: 'New pro', icon: 'sparkles', color: '#A78BFA' };
  if (pro.totalJobs >= 50) return { label: 'Experienced', icon: 'shield-checkmark', color: ONLINE };
  return { label: 'Trusted', icon: 'thumbs-up', color: SKY };
}

type Metric = { key: string; value: string; label: string; icon: keyof typeof Ionicons.glyphMap; color: string };

function buildMetrics(pro: TopCareProCardData, accent: string): Metric[] {
  const metrics: Metric[] = [
    { key: 'rating', value: pro.rating > 0 ? pro.rating.toFixed(1) : 'New', label: 'Rating', icon: 'star', color: GOLD },
    { key: 'jobs', value: String(pro.totalJobs), label: 'Jobs', icon: 'checkmark-done', color: SKY },
  ];
  if (pro.distance != null) {
    metrics.push({ key: 'dist', value: `${pro.distance.toFixed(1)}`, label: 'Miles', icon: 'navigate', color: ONLINE });
  } else if (pro.reviewCount != null) {
    metrics.push({ key: 'reviews', value: String(pro.reviewCount), label: 'Reviews', icon: 'chatbubbles', color: '#A78BFA' });
  }
  if (pro.price != null && Number.isFinite(pro.price)) {
    metrics.push({ key: 'price', value: `£${Number(pro.price).toFixed(0)}`, label: 'Price', icon: 'pricetag', color: accent });
  }
  return metrics;
}

export default function TopCareProCard({
  pro,
  width,
  accent = SKY,
  borderColor = 'rgba(125,211,252,0.38)',
  rank,
  variant = 'default',
  zoom = 1,
  searching = false,
  searchingTitle,
  searchingSubtitle,
  searchingBusy = false,
  onPress,
  onToggleFavourite,
  onBook,
  locked = false,
  style,
}: Props) {
  const displayName = formatDisplayName(pro?.name) || pro?.name || CCP.fallbackName;
  const onlineColor = pro?.isOnline ? ONLINE : OFFLINE;
  const rankColor = rank != null ? RANK_COLORS[rank] ?? accent : null;
  const isCompact = variant === 'compact';
  const z = (n: number) => Math.round(n * zoom);

  const pressScale = useSharedValue(1);
  const heartScale = useSharedValue(1);
  const pressStyle = useAnimatedStyle(() => ({ transform: [{ scale: pressScale.value }] }));
  const heartStyle = useAnimatedStyle(() => ({ transform: [{ scale: heartScale.value }] }));

  if (searching) {
    return (
      <View style={[styles.wrap, width != null && { width }, styles.searchingWrap, style]}>
        <SearchingProState
          accent={accent}
          title={searchingTitle}
          subtitle={searchingSubtitle}
          busy={searchingBusy}
          zoom={zoom}
        />
      </View>
    );
  }

  if (!pro) return null;

  if (isCompact) {
    return (
      <View style={[styles.wrap, width != null && { width }, style]}>
        <TouchableOpacity
          onPress={onPress ?? (() => {})}
          activeOpacity={0.88}
          style={[styles.cardCompact, { borderColor: borderColor.replace('0.38', '0.22').replace('0.4', '0.22') }]}
        >
          <BlurView intensity={22} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
          <LinearGradient
            colors={[accent + '12', 'transparent']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
          />

          <View style={styles.padCompact}>
            <View style={styles.compactAvatarCol}>
              <View style={[styles.avatarRingCompact, { borderColor: pro.isOnline ? onlineColor + '99' : 'rgba(148,163,184,0.35)' }]}>
                {pro.profilePicture ? (
                  <Image source={{ uri: pro.profilePicture }} style={styles.avatarImgCompact} />
                ) : (
                  <GradientIconBox
                    icon="car-sport-outline"
                    colors={accentToGradient(accent)}
                    boxSize={34}
                    borderRadius={10}
                    size={17}
                  />
                )}
              </View>
              {rank != null && rank <= 3 ? (
                <View style={[styles.rankBadgeCompact, { backgroundColor: rankColor + 'E6', borderColor: rankColor ?? accent }]}>
                  <Text style={styles.rankBadgeTextCompact}>#{rank}</Text>
                </View>
              ) : null}
            </View>

            <View style={styles.compactMain}>
              <Text style={styles.compactName} numberOfLines={1}>
                {displayName}
              </Text>
              <Text style={styles.compactMeta} numberOfLines={1}>
                {buildCompactMeta(pro)}
              </Text>
            </View>

            {onToggleFavourite ? (
              <TouchableOpacity onPress={onToggleFavourite} hitSlop={8} style={styles.compactHeart}>
                <Ionicons
                  name={pro.isFavourite ? 'heart' : 'heart-outline'}
                  size={16}
                  color={pro.isFavourite ? '#F87171' : 'rgba(148,163,184,0.65)'}
                />
              </TouchableOpacity>
            ) : (
              <Ionicons name="chevron-forward" size={16} color="rgba(148,163,184,0.45)" />
            )}
          </View>
        </TouchableOpacity>
      </View>
    );
  }

  const badge = getProBadge(pro);
  const metrics = buildMetrics(pro, accent);
  const avatarSize = z(62);
  const statusBits = [pro.isOnline ? 'Available now' : locked ? 'Offline · available when online' : 'Offline'];
  if (pro.distance != null) statusBits.push(`${pro.distance.toFixed(1)} mi away`);

  return (
    <View style={[styles.wrap, width != null && { width }, style]}>
      <Pressable
        onPress={onPress ?? (() => {})}
        onPressIn={() => {
          pressScale.value = withSpring(0.975, { damping: 18, stiffness: 340 });
        }}
        onPressOut={() => {
          pressScale.value = withSpring(1, { damping: 14, stiffness: 260 });
        }}
        accessibilityRole="button"
        accessibilityLabel={`${displayName}, ${pro.rating > 0 ? `${pro.rating.toFixed(1)} stars` : 'new'}, ${pro.totalJobs} jobs`}
      >
        <Animated.View
          style={[
            styles.card,
            { borderColor, minHeight: z(136), borderRadius: z(BOOKING_CARD.BORDER_RADIUS) },
            pressStyle,
          ]}
        >
          <BlurView intensity={42} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
          <LinearGradient
            colors={locked ? ['rgba(100,116,139,0.22)', 'rgba(51,65,85,0.18)', 'rgba(15,23,42,0.35)'] : [accent + '26', accent + '08', 'transparent']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
          />
          <LinearGradient
            colors={[...BOOKING_GLASS_TOP_SHEEN]}
            locations={[...BOOKING_GLASS_TOP_SHEEN_LOCATIONS]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0.85 }}
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
          />

          <View style={[styles.pad, { padding: z(14), gap: z(12), minHeight: z(136) }]}>
            <View style={[styles.heroRow, { gap: z(12) }]}>
              <View style={{ width: avatarSize, height: avatarSize }}>
                {pro.isOnline ? (
                  <Animated.View
                    pointerEvents="none"
                    style={[
                      styles.pulseRing,
                      { borderRadius: avatarSize / 2, borderColor: ONLINE },
                      {
                        animationName: onlinePulse,
                        animationDuration: '1.8s',
                        animationIterationCount: 'infinite',
                        animationTimingFunction: 'ease-out',
                      },
                    ]}
                  />
                ) : null}
                <View
                  style={[
                    styles.avatarRing,
                    {
                      width: avatarSize,
                      height: avatarSize,
                      borderRadius: avatarSize / 2,
                      borderColor: pro.isOnline ? ONLINE : 'rgba(148,163,184,0.4)',
                    },
                    locked && styles.lockedDim,
                  ]}
                >
                  {pro.profilePicture ? (
                    <Image source={{ uri: pro.profilePicture }} style={styles.avatarImg} />
                  ) : (
                    <HubGlassIcon icon="person" accent={accent} size={avatarSize - 6} glow={false} />
                  )}
                </View>
                {locked ? (
                  <View
                    style={[
                      styles.lockBadge,
                      { width: z(22), height: z(22), borderRadius: z(11) },
                    ]}
                    accessibilityLabel="Locked while offline"
                  >
                    <Ionicons name="lock-closed" size={z(11)} color="#E2E8F0" />
                  </View>
                ) : (
                  <View
                    style={[
                      styles.onlineDot,
                      { backgroundColor: onlineColor, width: z(15), height: z(15), borderRadius: z(8) },
                    ]}
                  />
                )}
              </View>

              <View style={[styles.mainCol, { gap: z(5) }]}>
                <View style={styles.titleRow}>
                  <Text style={[styles.name, { fontSize: z(17) }, locked && styles.nameLocked]} numberOfLines={1}>
                    {displayName}
                  </Text>
                  {rank != null && rank <= 3 ? (
                    <View style={[styles.rankChip, { backgroundColor: `${rankColor}26`, borderColor: `${rankColor}88` }]}>
                      <Ionicons name="trophy" size={z(10)} color={rankColor ?? GOLD} />
                      <Text style={[styles.rankChipText, { color: rankColor ?? GOLD, fontSize: z(10) }]}>#{rank}</Text>
                    </View>
                  ) : null}
                  <View style={styles.flex} />
                  {onToggleFavourite ? (
                    <Pressable
                      onPress={() => {
                        hapticFeedback(pro.isFavourite ? 'light' : 'medium');
                        heartScale.value = withSequence(
                          withSpring(1.35, { damping: 8, stiffness: 400 }),
                          withSpring(1, { damping: 10, stiffness: 240 }),
                        );
                        onToggleFavourite();
                      }}
                      hitSlop={10}
                      accessibilityLabel={
                        pro.isFavourite ? `Remove ${displayName} from favourites` : `Save ${displayName} to favourites`
                      }
                    >
                      <Animated.View style={heartStyle}>
                        <Ionicons
                          name={pro.isFavourite ? 'heart' : 'heart-outline'}
                          size={z(20)}
                          color={pro.isFavourite ? '#F87171' : 'rgba(248,250,252,0.75)'}
                        />
                      </Animated.View>
                    </Pressable>
                  ) : (
                    <View style={[styles.goChip, { borderColor: `${accent}55` }]}>
                      <Ionicons name="chevron-forward" size={z(14)} color={accent} />
                    </View>
                  )}
                </View>

                {locked ? (
                  <View style={[styles.lockedPill, { paddingHorizontal: z(9), height: z(22), borderRadius: z(11) }]}>
                    <Ionicons name="moon" size={z(10)} color="rgba(203,213,225,0.9)" />
                    <Text style={[styles.lockedPillText, { fontSize: z(11) }]} numberOfLines={1}>
                      Offline · available when online
                    </Text>
                  </View>
                ) : (
                  <View style={styles.statusLine}>
                    <View style={[styles.statusDot, { backgroundColor: onlineColor, width: z(7), height: z(7), borderRadius: z(4) }]} />
                    <Text style={[styles.statusText, { color: pro.isOnline ? ONLINE : OFFLINE, fontSize: z(12) }]} numberOfLines={1}>
                      {statusBits.join(' · ')}
                    </Text>
                  </View>
                )}

                <View style={[styles.badgeRow, locked && styles.lockedDim]}>
                  <View style={[styles.badge, { backgroundColor: `${badge.color}1A`, borderColor: `${badge.color}55` }]}>
                    <Ionicons name={badge.icon} size={z(11)} color={badge.color} />
                    <Text style={[styles.badgeText, { color: badge.color, fontSize: z(11) }]}>{badge.label}</Text>
                  </View>
                  <View style={[styles.badge, styles.badgeMuted]}>
                    <Text style={[styles.badgeMutedText, { fontSize: z(11) }]} numberOfLines={1}>
                      {CCP.singularShort}
                    </Text>
                  </View>
                </View>
              </View>
            </View>

            <View style={[styles.metricsRow, { borderRadius: z(14), paddingVertical: z(9) }, locked && styles.lockedDim]}>
              {metrics.map((m, i) => (
                <View key={m.key} style={[styles.metric, i > 0 && styles.metricDivider]}>
                  <View style={styles.metricTop}>
                    <Ionicons name={m.icon} size={z(12)} color={locked ? 'rgba(148,163,184,0.9)' : m.color} />
                    <Text style={[styles.metricValue, { fontSize: z(15) }]} numberOfLines={1}>
                      {m.value}
                    </Text>
                  </View>
                  <Text style={[styles.metricLabel, { fontSize: z(9.5) }]} numberOfLines={1}>
                    {m.label}
                  </Text>
                </View>
              ))}
            </View>

            {onBook ? (
              <TouchableOpacity onPress={onBook} activeOpacity={0.88} style={[styles.bookBtnWrap, { borderRadius: z(12) }]}>
                <LinearGradient
                  colors={[accent, `${accent}CC`]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={[styles.bookBtn, { paddingVertical: z(10) }]}
                >
                  <Ionicons name="flash" size={z(15)} color="#0B1220" />
                  <Text style={[styles.bookBtnText, { fontSize: z(13) }]}>{CCP.requestButton}</Text>
                </LinearGradient>
              </TouchableOpacity>
            ) : null}
          </View>
        </Animated.View>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    alignSelf: 'stretch',
  },
  searchingWrap: {
    backgroundColor: 'transparent',
  },
  flex: { flex: 1 },
  cardCompact: {
    minHeight: 72,
    overflow: 'hidden',
    borderRadius: 14,
    backgroundColor: 'rgba(8,20,38,0.38)',
    borderWidth: StyleSheet.hairlineWidth * 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.12,
    shadowRadius: 4,
    elevation: 2,
  },
  padCompact: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 10,
    paddingVertical: 10,
  },
  compactAvatarCol: {
    position: 'relative',
  },
  avatarRingCompact: {
    width: 40,
    height: 40,
    borderRadius: 12,
    borderWidth: 1.5,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarImgCompact: {
    width: 40,
    height: 40,
    borderRadius: 12,
  },
  rankBadgeCompact: {
    position: 'absolute',
    top: -5,
    left: -5,
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 4,
  },
  rankBadgeTextCompact: {
    color: '#0F172A',
    fontSize: 8,
    fontWeight: '900',
  },
  compactMain: {
    flex: 1,
    minWidth: 0,
    gap: 2,
  },
  compactName: {
    color: '#F1F5F9',
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: -0.1,
  },
  compactMeta: {
    color: 'rgba(148,163,184,0.92)',
    fontSize: 11,
    fontWeight: '600',
  },
  compactHeart: {
    padding: 2,
  },

  card: {
    minHeight: 136,
    overflow: 'hidden',
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(6,16,32,0.55)',
    borderWidth: 1,
    shadowColor: 'rgba(56,189,248,0.18)',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.32,
    shadowRadius: 14,
    elevation: 6,
  },
  pad: {
    flexGrow: 1,
    justifyContent: 'space-between',
  },
  heroRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  pulseRing: {
    ...StyleSheet.absoluteFill,
    borderWidth: 2,
  },
  avatarRing: {
    borderWidth: 2,
    padding: 2,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(15,23,42,0.6)',
  },
  avatarImg: {
    width: '100%',
    height: '100%',
    borderRadius: 999,
  },
  onlineDot: {
    position: 'absolute',
    bottom: 1,
    right: 1,
    borderWidth: 2.5,
    borderColor: 'rgba(8,20,38,0.95)',
  },
  lockedDim: {
    opacity: 0.45,
  },
  nameLocked: {
    color: 'rgba(226,232,240,0.7)',
  },
  lockedPill: {
    alignSelf: 'flex-start',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: 'rgba(148,163,184,0.14)',
  },
  lockedPillText: {
    color: 'rgba(203,213,225,0.9)',
    fontWeight: '700',
    letterSpacing: 0.1,
  },
  lockBadge: {
    position: 'absolute',
    bottom: -2,
    right: -2,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(51,65,85,0.95)',
    shadowColor: '#000',
    shadowOpacity: 0.35,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 1 },
  },
  mainCol: {
    flex: 1,
    minWidth: 0,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  name: {
    flexShrink: 1,
    color: '#F8FAFC',
    fontWeight: '900',
    letterSpacing: -0.2,
  },
  rankChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 999,
    borderWidth: 1,
  },
  rankChipText: { fontWeight: '900' },
  goChip: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(15,23,42,0.45)',
  },
  statusLine: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  statusDot: {},
  statusText: {
    flexShrink: 1,
    fontWeight: '700',
  },
  badgeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 999,
    borderWidth: 1,
  },
  badgeText: { fontWeight: '800' },
  badgeMuted: {
    backgroundColor: 'rgba(148,163,184,0.1)',
    borderColor: 'rgba(148,163,184,0.25)',
    flexShrink: 1,
  },
  badgeMutedText: { color: 'rgba(226,232,240,0.75)', fontWeight: '700' },
  metricsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(2,6,23,0.35)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.12)',
  },
  metric: {
    flex: 1,
    alignItems: 'center',
    gap: 2,
  },
  metricDivider: {
    borderLeftWidth: StyleSheet.hairlineWidth,
    borderLeftColor: 'rgba(148,163,184,0.28)',
  },
  metricTop: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  metricValue: {
    color: '#F8FAFC',
    fontWeight: '800',
    letterSpacing: -0.2,
  },
  metricLabel: {
    color: 'rgba(148,163,184,0.85)',
    fontWeight: '700',
    letterSpacing: 0.6,
    textTransform: 'uppercase',
  },
  bookBtnWrap: {
    overflow: 'hidden',
  },
  bookBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
  },
  bookBtnText: {
    color: '#0B1220',
    fontWeight: '800',
    letterSpacing: 0.2,
  },
});
