import { View, type ViewStyle } from 'react-native';
import type { GlyphName } from './GlyphIcon';
import HubGlassIcon from './HubGlassIcon';

export const GRADIENT_PRESETS = {
  sky: ['#38BDF8', '#0EA5E9'] as [string, string],
  emerald: ['#34D399', '#059669'] as [string, string],
  green: ['#10B981', '#059669'] as [string, string],
  amber: ['#F59E0B', '#D97706'] as [string, string],
  cyan: ['#06B6D4', '#0891B2'] as [string, string],
  pink: ['#EC4899', '#DB2777'] as [string, string],
  gray: ['#6B7280', '#4B5563'] as [string, string],
  teal: ['#14B8A6', '#0D9488'] as [string, string],
  red: ['#EF4444', '#DC2626'] as [string, string],
  blue: ['#3B82F6', '#2563EB'] as [string, string],
  purple: ['#8B5CF6', '#7C3AED'] as [string, string],
} as const;

interface GradientIconBoxProps {
  icon: GlyphName;
  colors?: [string, string];
  preset?: keyof typeof GRADIENT_PRESETS;
  size?: number;
  boxSize?: number;
  /** Kept for API compatibility; icons render as round glass wells. */
  borderRadius?: number;
  /** Soft accent glow under the well. */
  elevated?: boolean;
  /** Kept for API compatibility; wells have no hard border. */
  borderless?: boolean;
  style?: ViewStyle;
  /** Softer chrome for inactive tabs / secondary affordances (dims, drops glow). */
  muted?: boolean;
}

function resolveAccent(
  colors: [string, string] | undefined,
  preset: keyof typeof GRADIENT_PRESETS | undefined
): string {
  const first = colors?.[0]?.trim();
  if (first && /^#[0-9A-Fa-f]{6}([0-9A-Fa-f]{2})?$/.test(first)) return first.slice(0, 7);
  const key = preset && preset in GRADIENT_PRESETS ? preset : 'sky';
  return GRADIENT_PRESETS[key][0];
}

/** Legacy icon box API rendered with the shared Your Hub glass well. */
export default function GradientIconBox({
  icon,
  colors,
  preset = 'sky',
  size,
  boxSize = 42,
  elevated = false,
  style,
  muted = false,
}: GradientIconBoxProps) {
  const iconSize = size ?? (boxSize <= 36 ? 18 : boxSize <= 44 ? 20 : 24);
  return (
    <View style={[{ width: boxSize, height: boxSize, opacity: muted ? 0.72 : 1 }, style]}>
      <HubGlassIcon
        icon={icon}
        accent={resolveAccent(colors, preset)}
        size={boxSize}
        iconSize={iconSize}
        glow={elevated && !muted}
      />
    </View>
  );
}
