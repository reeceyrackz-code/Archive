import React from 'react';
import { TouchableOpacity, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';

type BookingHeaderMapControlButtonProps = {
  onPress: () => void;
  accentColor?: string;
  accessibilityLabel?: string;
  size?: number;
  iconSize?: number;
  loading?: boolean;
};

/** Locate / recenter — plain icon, same as the profile pencil (no chrome box). */
export function BookingHeaderMapControlButton({
  onPress,
  accentColor = colors.SKY,
  accessibilityLabel = 'Use current location on map',
  size = 40,
  iconSize = 22,
  loading = false,
}: BookingHeaderMapControlButtonProps) {
  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={loading}
      activeOpacity={0.75}
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel}
      hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
      style={{
        width: size,
        height: size,
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      {loading ? (
        <ActivityIndicator size="small" color={accentColor} />
      ) : (
        <Ionicons name="locate" size={iconSize} color={accentColor} />
      )}
    </TouchableOpacity>
  );
}
