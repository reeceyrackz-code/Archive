import { forwardRef, useEffect, useState } from 'react';
import { StyleSheet, View } from 'react-native';
import MapView, { type MapViewProps } from 'react-native-maps';
import { useMapBottomOverlap } from '../../hooks/useMapObstruction';

/** Gap between the top of a covering sheet and the legal label / logo. */
const LEGAL_CLEARANCE = 10;

type Insets = { top: number; right: number; bottom: number; left: number };

function liftInsets(base: Partial<Insets> | undefined, minBottom: number, side: number): Insets {
  return {
    top: base?.top ?? 0,
    right: base?.right ?? side,
    left: base?.left ?? side,
    bottom: Math.max(base?.bottom ?? 0, minBottom),
  };
}

/**
 * Fabric recycles native map views, and a recycled view keeps its previous gesture flags
 * (e.g. a static preview's `scrollEnabled={false}`) when the new value equals the default.
 * Rendering the inverted flags for the first frame forces every flag to be re-applied.
 */
function useFreshGestureFlags(props: MapViewProps) {
  const [primed, setPrimed] = useState(false);
  useEffect(() => {
    const id = requestAnimationFrame(() => setPrimed(true));
    return () => cancelAnimationFrame(id);
  }, []);
  const flags = {
    scrollEnabled: props.scrollEnabled ?? true,
    zoomEnabled: props.zoomEnabled ?? true,
    rotateEnabled: props.rotateEnabled ?? true,
    pitchEnabled: props.pitchEnabled ?? true,
  };
  if (primed) return flags;
  return {
    scrollEnabled: !flags.scrollEnabled,
    zoomEnabled: !flags.zoomEnabled,
    rotateEnabled: !flags.rotateEnabled,
    pitchEnabled: !flags.pitchEnabled,
  };
}

/**
 * Drop-in `MapView` that keeps the Apple / Google legal label and logo above any bottom
 * sheet reported via `useReportMapObstruction`. Explicit `mapPadding` / `legalLabelInsets`
 * still win when they're larger. Use instead of `<MapView>` for every map in the app.
 */
const SafeMapView = forwardRef<MapView, MapViewProps>(function SafeMapView(
  { style, mapPadding, legalLabelInsets, ...rest },
  ref
) {
  const { ref: frameRef, onLayout, overlap } = useMapBottomOverlap();
  const gestureFlags = useFreshGestureFlags(rest);
  const lift = overlap > 0 ? overlap + LEGAL_CLEARANCE : 0;

  const paddingProps =
    lift > 0 || mapPadding ? { mapPadding: liftInsets(mapPadding, lift, 0) } : {};
  const legalProps =
    lift > 0 || legalLabelInsets ? { legalLabelInsets: liftInsets(legalLabelInsets, lift, 10) } : {};

  return (
    <View ref={frameRef} onLayout={onLayout} style={style} pointerEvents="box-none" collapsable={false}>
      <MapView
        ref={ref}
        style={StyleSheet.absoluteFill}
        {...rest}
        {...gestureFlags}
        {...paddingProps}
        {...legalProps}
      />
    </View>
  );
});

export default SafeMapView;
