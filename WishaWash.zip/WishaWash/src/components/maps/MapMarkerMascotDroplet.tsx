import { useEffect, useRef } from 'react';
import { Animated, Easing, Image, StyleSheet, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

const MASCOT = require('../../../assets/map-mascot.png');
const BOB_MS = 1600;
const SPLASH_MS = 2200;

/**
 * The Pro on a tracking map, matching the Pro app: the mascot inside a glassy water droplet that bobs
 * gently, with a splash ripple at its base. The marker's box is `size * 2.2` square, centred on the Pro.
 */
export default function MapMarkerMascotDroplet({
  size = 34,
  accent = '#38BDF8',
}: Readonly<{ size?: number; accent?: string }>) {
  const bob = useRef(new Animated.Value(0)).current;
  const splash = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const bobLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(bob, { toValue: 1, duration: BOB_MS / 2, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
        Animated.timing(bob, { toValue: 0, duration: BOB_MS / 2, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      ])
    );
    const splashLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(splash, { toValue: 1, duration: SPLASH_MS, easing: Easing.out(Easing.quad), useNativeDriver: true }),
        Animated.timing(splash, { toValue: 0, duration: 0, useNativeDriver: true }),
      ])
    );
    bobLoop.start();
    splashLoop.start();
    return () => {
      bobLoop.stop();
      splashLoop.stop();
    };
  }, [bob, splash]);

  const side = Math.round(size * 2.2);
  const tipRadius = Math.round(size * 0.1);
  const art = Math.round(size * 1.35);
  const baseY = size * 0.78;

  return (
    <View style={[styles.wrap, { width: side, height: side }]} collapsable={false}>
      <Animated.View
        style={[
          styles.splash,
          {
            width: size * 1.1,
            height: size * 0.36,
            borderRadius: size,
            borderColor: accent,
            transform: [
              { translateY: baseY },
              { scale: splash.interpolate({ inputRange: [0, 1], outputRange: [0.5, 1.9] }) },
            ],
            opacity: splash.interpolate({ inputRange: [0, 1], outputRange: [0.7, 0] }),
          },
        ]}
      />
      <View
        style={[
          styles.shadow,
          { width: size * 0.8, height: size * 0.2, borderRadius: size, transform: [{ translateY: baseY }], shadowColor: accent, backgroundColor: `${accent}66` },
        ]}
      />
      <Animated.View style={{ transform: [{ translateY: bob.interpolate({ inputRange: [0, 1], outputRange: [0, -size * 0.1] }) }] }}>
        <View
          style={[
            styles.drop,
            {
              width: size,
              height: size,
              borderRadius: size / 2,
              borderTopLeftRadius: tipRadius,
              backgroundColor: accent,
            },
          ]}
        >
          <View style={[styles.unrotate, { width: size, height: size }]}>
            <Image source={MASCOT} style={{ width: art, height: art }} resizeMode="cover" accessibilityIgnoresInvertColors />
          </View>
          <LinearGradient
            colors={['rgba(255,255,255,0.5)', 'rgba(255,255,255,0)']}
            start={{ x: 0, y: 0 }}
            end={{ x: 0.55, y: 0.55 }}
            style={StyleSheet.absoluteFill}
          />
        </View>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { alignItems: 'center', justifyContent: 'center' },
  splash: { position: 'absolute', borderWidth: 2 },
  shadow: {
    position: 'absolute',
    shadowOpacity: 0.9,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 0 },
  },
  drop: {
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2.5,
    borderColor: '#FFFFFF',
    transform: [{ rotate: '45deg' }],
    shadowColor: '#000',
    shadowOpacity: 0.35,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 4 },
    elevation: 8,
  },
  unrotate: {
    alignItems: 'center',
    justifyContent: 'center',
    transform: [{ rotate: '-45deg' }],
  },
});
