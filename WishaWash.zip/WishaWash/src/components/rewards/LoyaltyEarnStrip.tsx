import { View, Text, StyleSheet } from 'react-native';
import { router, type Href } from 'expo-router';
import { REFERRAL_BONUS_POINTS, REWARD_POINTS_PER_BOOKING } from '../../services/LoyaltyService';
import HubGlassIcon, { type HubGlassTone } from '../shared/HubGlassIcon';
import { PressScale } from '../pass/PassKit';

const EARN_ROWS: {
  icon: 'car-sport' | 'star' | 'gift';
  label: string;
  points: string;
  tone: HubGlassTone;
  color: string;
  href: Href;
}[] = [
  { icon: 'car-sport', label: 'Wash', points: `+${REWARD_POINTS_PER_BOOKING}`, tone: 'sky', color: '#7DD3FC', href: '/owner/booking/create' },
  { icon: 'star', label: 'Rate', points: '+5', tone: 'gold', color: '#FCD34D', href: '/owner/wash-history' },
  { icon: 'gift', label: 'Refer', points: `+${REFERRAL_BONUS_POINTS}`, tone: 'green', color: '#6EE7B7', href: '/owner/features/referral-system' },
];

export default function LoyaltyEarnStrip() {
  return (
    <View>
      <Text style={styles.title}>Earn points</Text>
      <View style={styles.row}>
        {EARN_ROWS.map((item) => (
          <PressScale
            key={item.label}
            onPress={() => router.push(item.href)}
            style={styles.tile}
            containerStyle={styles.cell}
            accessibilityLabel={`${item.label} to earn ${item.points} points`}
          >
            <HubGlassIcon icon={item.icon} accent={item.tone} size={34} iconSize={16} />
            <View>
              <Text style={styles.label}>{item.label}</Text>
              <Text style={[styles.points, { color: item.color }]}>{item.points}</Text>
            </View>
          </PressScale>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  title: {
    color: 'rgba(226,232,240,0.7)',
    fontSize: 13,
    fontWeight: '700',
    marginBottom: 10,
    paddingHorizontal: 2,
  },
  row: {
    flexDirection: 'row',
    gap: 8,
  },
  cell: {
    flex: 1,
  },
  tile: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
    paddingVertical: 11,
    paddingHorizontal: 10,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.14)',
    backgroundColor: 'rgba(15,23,42,0.42)',
  },
  label: {
    color: '#F1F5F9',
    fontSize: 13,
    fontWeight: '700',
  },
  points: {
    fontSize: 12,
    fontWeight: '800',
  },
});
