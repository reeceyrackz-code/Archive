import { View, Text, StyleSheet, Modal, Pressable, Platform } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import Animated, { css, FadeIn, FadeInDown, SlideInDown, ZoomIn, useReducedMotion } from 'react-native-reanimated';
import {
  getMilestoneTierColor,
  getRewardCategoryColor,
  getRewardCategoryLabel,
  getRewardClaimCopy,
  type RewardMilestone,
} from '../../utils/loyaltyTier';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { WWSheetCloseButton } from '../ui';
import HubGlassIcon, { hubGlassPalette } from '../shared/HubGlassIcon';
import { PressScale, loopAnim, pulseRing, withAlpha } from '../pass/PassKit';

type Props = {
  visible: boolean;
  reward: RewardMilestone | null;
  onClose: () => void;
};

const CONFETTI_COUNT = 14;
const CONFETTI = Array.from({ length: CONFETTI_COUNT }, (_, i) => {
  const angle = (i / CONFETTI_COUNT) * Math.PI * 2;
  const dist = 78 + (i % 3) * 22;
  const dx = Math.cos(angle) * dist;
  const dy = Math.sin(angle) * dist;
  return {
    key: `c${i}`,
    size: 5 + (i % 3) * 2,
    round: i % 2 === 0,
    keyframes: css.keyframes({
      '0%': { opacity: 0, transform: [{ translateX: 0 }, { translateY: 0 }, { scale: 0.3 }, { rotate: '0deg' }] },
      '15%': { opacity: 1 },
      '100%': {
        opacity: 0,
        transform: [{ translateX: dx }, { translateY: dy + 26 }, { scale: 1 }, { rotate: `${i % 2 ? 220 : -200}deg` }],
      },
    }),
  };
});

const burstRing = css.keyframes({
  from: { transform: [{ scale: 0.6 }], opacity: 0.8 },
  to: { transform: [{ scale: 2.4 }], opacity: 0 },
});

export default function LoyaltyClaimSheet({ visible, reward, onClose }: Props) {
  const insets = useSafeAreaInsets();
  const reduced = useReducedMotion();
  if (!reward) return null;

  const tierColor = getMilestoneTierColor(reward.tier);
  const categoryColor = getRewardCategoryColor(reward.category);
  const claimCopy = getRewardClaimCopy(reward);
  const confettiColors = [tierColor, categoryColor, '#FBBF24', '#F8FAFC'];

  const handlePrimary = () => {
    void hapticFeedback('medium');
    onClose();
    if (claimCopy.showBookingCta) {
      router.push('/owner/booking/create');
    }
  };

  return (
    <Modal visible={visible} transparent animationType="none" onRequestClose={onClose} statusBarTranslucent>
      <View style={styles.root}>
        <Animated.View entering={FadeIn.duration(220)} style={StyleSheet.absoluteFill}>
          <Pressable style={[StyleSheet.absoluteFill, styles.backdrop]} onPress={onClose} accessibilityLabel="Dismiss" />
        </Animated.View>

        <Animated.View
          entering={SlideInDown.springify().damping(20).stiffness(180)}
          style={[styles.panel, { paddingBottom: Math.max(18, insets.bottom + 6), borderColor: withAlpha(tierColor, 0.35) }]}
        >
          <View style={[StyleSheet.absoluteFill, styles.panelClip]} pointerEvents="none">
            <View style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(8,15,30,0.86)' }]} />
            <BlurView
              intensity={Platform.OS === 'ios' ? 40 : 50}
              tint="dark"
              style={StyleSheet.absoluteFill}
              {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
            />
            <LinearGradient
              colors={[withAlpha(tierColor, 0.3), withAlpha(tierColor, 0.06), 'transparent']}
              start={{ x: 0.5, y: 0 }}
              end={{ x: 0.5, y: 0.7 }}
              style={StyleSheet.absoluteFill}
            />
          </View>

          <View style={styles.grabber} />
          <View style={styles.topRow}>
            <Text style={[styles.kicker, { color: tierColor }]}>Reward unlocked</Text>
            <WWSheetCloseButton onPress={onClose} accessibilityLabel="Close" />
          </View>

          <View style={styles.hero}>
            <View style={styles.burstStage}>
              {!reduced ? (
                <>
                  <Animated.View
                    pointerEvents="none"
                    style={[
                      styles.burst,
                      { borderColor: withAlpha(tierColor, 0.7) },
                      { animationName: burstRing, animationDuration: '0.9s', animationTimingFunction: 'ease-out', animationFillMode: 'forwards' },
                    ]}
                  />
                  <Animated.View
                    pointerEvents="none"
                    style={[styles.burst, { borderColor: withAlpha(tierColor, 0.45) }, loopAnim(pulseRing, '2.2s', '0.6s', 'ease-out')]}
                  />
                  {CONFETTI.map((c, i) => (
                    <Animated.View
                      key={c.key}
                      pointerEvents="none"
                      style={[
                        styles.confetti,
                        {
                          width: c.size,
                          height: c.round ? c.size : c.size * 1.8,
                          borderRadius: c.round ? c.size / 2 : 1.5,
                          backgroundColor: confettiColors[i % confettiColors.length],
                        },
                        {
                          animationName: c.keyframes,
                          animationDuration: '1.3s',
                          animationDelay: `${(i % 4) * 0.05}s`,
                          animationTimingFunction: 'ease-out',
                          animationFillMode: 'forwards',
                        },
                      ]}
                    />
                  ))}
                </>
              ) : null}
              <Animated.View entering={ZoomIn.springify().damping(11).stiffness(160).delay(80)}>
                <HubGlassIcon
                  icon={reward.icon as keyof typeof Ionicons.glyphMap}
                  palette={hubGlassPalette(tierColor)}
                  size={84}
                  iconSize={38}
                />
              </Animated.View>
            </View>

            <Animated.View entering={FadeInDown.delay(160).springify().damping(18)} style={styles.copy}>
              <View style={[styles.categoryPill, { borderColor: withAlpha(categoryColor, 0.4), backgroundColor: withAlpha(categoryColor, 0.12) }]}>
                <Text style={[styles.categoryText, { color: categoryColor }]}>
                  {getRewardCategoryLabel(reward.category)}
                </Text>
              </View>
              <Text style={styles.title}>{reward.title}</Text>
              <Text style={styles.subtitle}>{reward.description}</Text>
              <View style={[styles.sparkPill, { borderColor: withAlpha(tierColor, 0.4) }]}>
                <Ionicons name="sparkles" size={14} color={tierColor} />
                <Text style={[styles.sparkText, { color: tierColor }]}>{claimCopy.walletLine}</Text>
              </View>
            </Animated.View>
          </View>

          <Animated.View entering={FadeInDown.delay(240).springify().damping(18)} style={styles.actions}>
            <PressScale onPress={handlePrimary} haptic={false} style={styles.primaryBtn} accessibilityLabel={claimCopy.primaryCta}>
              <LinearGradient
                colors={[tierColor, withAlpha(tierColor, 0.75)]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={StyleSheet.absoluteFill}
              />
              <Ionicons name={claimCopy.showBookingCta ? 'flash' : 'checkmark-circle'} size={18} color="#0F172A" />
              <Text style={styles.primaryText}>{claimCopy.primaryCta}</Text>
            </PressScale>

            <Pressable onPress={onClose} style={styles.secondaryBtn} hitSlop={8} accessibilityRole="button">
              <Text style={styles.secondaryText}>Keep browsing rewards</Text>
            </Pressable>
          </Animated.View>
        </Animated.View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  backdrop: {
    backgroundColor: 'rgba(2,6,23,0.7)',
  },
  panel: {
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    borderWidth: 1,
    borderBottomWidth: 0,
    paddingHorizontal: 20,
    paddingTop: 8,
    gap: 12,
  },
  panelClip: {
    overflow: 'hidden',
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
  },
  grabber: {
    alignSelf: 'center',
    width: 40,
    height: 5,
    borderRadius: 3,
    backgroundColor: 'rgba(148,163,184,0.4)',
    marginBottom: 4,
  },
  topRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  kicker: {
    fontSize: 12,
    fontWeight: '900',
    letterSpacing: 1.4,
    textTransform: 'uppercase',
  },
  hero: {
    alignItems: 'center',
    gap: 14,
    paddingVertical: 6,
  },
  burstStage: {
    width: 180,
    height: 150,
    alignItems: 'center',
    justifyContent: 'center',
  },
  burst: {
    position: 'absolute',
    width: 84,
    height: 84,
    borderRadius: 42,
    borderWidth: 2,
  },
  confetti: {
    position: 'absolute',
  },
  copy: {
    alignItems: 'center',
    gap: 8,
  },
  categoryPill: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
    borderWidth: 1,
  },
  categoryText: {
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
  },
  title: {
    color: '#F8FAFC',
    fontSize: 24,
    fontWeight: '900',
    textAlign: 'center',
    letterSpacing: -0.4,
  },
  subtitle: {
    color: 'rgba(203,213,225,0.9)',
    fontSize: 14,
    fontWeight: '500',
    textAlign: 'center',
    lineHeight: 20,
    paddingHorizontal: 12,
  },
  sparkPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 4,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 999,
    borderWidth: 1,
    backgroundColor: 'rgba(15,23,42,0.5)',
  },
  sparkText: {
    fontSize: 12,
    fontWeight: '800',
  },
  actions: {
    gap: 4,
    marginTop: 4,
  },
  primaryBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    height: 54,
    borderRadius: 999,
    overflow: 'hidden',
  },
  primaryText: {
    color: '#0F172A',
    fontSize: 16,
    fontWeight: '900',
  },
  secondaryBtn: {
    alignItems: 'center',
    paddingVertical: 10,
  },
  secondaryText: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 13,
    fontWeight: '700',
  },
});
