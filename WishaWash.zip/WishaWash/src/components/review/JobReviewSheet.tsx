import { useEffect, useMemo, useState, type ReactNode } from 'react';
import {
  ActivityIndicator,
  Image,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  useWindowDimensions,
} from 'react-native';
import Animated, {
  FadeIn,
  FadeInDown,
  FadeOut,
  LinearTransition,
  SlideInDown,
  SlideOutDown,
  ZoomIn,
  useAnimatedStyle,
  useSharedValue,
  withSequence,
  withSpring,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { BlurView } from 'expo-blur';
import { GlassView, isLiquidGlassAvailable } from 'expo-glass-effect';
import { SymbolView, type SFSymbol } from 'expo-symbols';
import * as Haptics from 'expo-haptics';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';

export type JobReviewResult = Readonly<{
  rating: number;
  tags: string[];
  comment: string;
  tip: number;
}>;

type Props = Readonly<{
  visible: boolean;
  proName?: string | null;
  proPhotoUrl?: string | null;
  serviceLabel?: string | null;
  price?: number | null;
  completeLabel?: string;
  tipOptions?: readonly number[];
  /** Throw to keep the sheet open (e.g. tip payment cancelled). */
  onSubmit: (result: JobReviewResult) => Promise<void>;
  onClose: () => void;
}>;

const SKY = '#38BDF8';
const GOLD = '#FBBF24';
const RATING_LABELS = ['', 'Poor', 'Fair', 'Good', 'Great', 'Excellent'];
const PRAISE = ['Spotless finish', 'On time', 'Friendly', 'Great value', 'Attention to detail'];
const IMPROVE = ['Arrived late', 'Missed spots', 'Communication', 'Felt rushed', 'Price'];

const GLASS = Platform.OS === 'ios' && isLiquidGlassAvailable();

function Icon({
  sf,
  ion,
  size,
  color,
  bounce,
}: Readonly<{
  sf: SFSymbol;
  ion: keyof typeof Ionicons.glyphMap;
  size: number;
  color: string;
  bounce?: boolean;
}>) {
  if (Platform.OS !== 'ios') return <Ionicons name={ion} size={size} color={color} />;
  return (
    <SymbolView
      name={sf}
      size={size}
      tintColor={color}
      type="hierarchical"
      {...(bounce ? { animationSpec: { effect: { type: 'bounce', wholeSymbol: true } } } : {})}
      fallback={<Ionicons name={ion} size={size} color={color} />}
    />
  );
}

function Surface({ children, style }: Readonly<{ children: ReactNode; style?: object }>) {
  if (GLASS) {
    return (
      <GlassView glassEffectStyle="regular" colorScheme="dark" tintColor="rgba(8,20,38,0.55)" style={style}>
        {children}
      </GlassView>
    );
  }
  return (
    <View style={[style, styles.surfaceFallback]}>
      <BlurView intensity={50} tint="dark" style={StyleSheet.absoluteFill} />
      <View style={[StyleSheet.absoluteFill, styles.surfaceTint]} />
      {children}
    </View>
  );
}

function Star({ index, rating, onPick }: Readonly<{ index: number; rating: number; onPick: (n: number) => void }>) {
  const filled = index < rating;
  const scale = useSharedValue(1);
  const anim = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  return (
    <Pressable
      onPress={() => {
        scale.value = withSequence(withSpring(1.25, { damping: 8 }), withSpring(1, { damping: 10 }));
        onPick(index + 1);
      }}
      hitSlop={6}
      accessibilityRole="button"
      accessibilityLabel={`${index + 1} star${index === 0 ? '' : 's'}`}
    >
      <Animated.View style={anim}>
        <Icon
          key={filled ? 'on' : 'off'}
          sf={filled ? 'star.fill' : 'star'}
          ion={filled ? 'star' : 'star-outline'}
          size={34}
          color={filled ? GOLD : 'rgba(148,163,184,0.55)'}
          bounce={filled}
        />
      </Animated.View>
    </Pressable>
  );
}

function Chip({ label, active, onPress }: Readonly<{ label: string; active: boolean; onPress: () => void }>) {
  return (
    <Pressable
      onPress={onPress}
      style={[styles.chip, active && styles.chipActive]}
      accessibilityRole="button"
      accessibilityState={{ selected: active }}
    >
      {active ? <Ionicons name="checkmark" size={13} color={SKY} /> : null}
      <Text style={[styles.chipText, active && styles.chipTextActive]}>{label}</Text>
    </Pressable>
  );
}

/** Post-job review pop-up: stars, quick tags, optional note and tip, then a thank-you state. */
export default function JobReviewSheet({
  visible,
  proName,
  proPhotoUrl,
  serviceLabel,
  price,
  completeLabel = 'WASH COMPLETE',
  tipOptions = [0, 2, 5, 10],
  onSubmit,
  onClose,
}: Props) {
  const insets = useSafeAreaInsets();
  const { height } = useWindowDimensions();
  const [rating, setRating] = useState(0);
  const [tags, setTags] = useState<string[]>([]);
  const [comment, setComment] = useState('');
  const [tip, setTip] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (!visible) return;
    setRating(0);
    setTags([]);
    setComment('');
    setTip(0);
    setSubmitting(false);
    setDone(false);
  }, [visible]);

  useEffect(() => {
    if (!done) return;
    const t = setTimeout(onClose, 1600);
    return () => clearTimeout(t);
  }, [done, onClose]);

  const firstName = (proName ?? '').trim().split(/\s+/)[0] || 'your pro';
  const tagOptions = rating >= 4 ? PRAISE : IMPROVE;
  const meta = useMemo(
    () => [serviceLabel, price != null ? `£${Number(price).toFixed(2)}` : null].filter(Boolean).join(' · '),
    [serviceLabel, price]
  );

  const pick = (n: number) => {
    void Haptics.selectionAsync();
    if ((n >= 4) !== (rating >= 4)) setTags([]);
    setRating(n);
  };

  const toggleTag = (t: string) => {
    void Haptics.selectionAsync();
    setTags((prev) => (prev.includes(t) ? prev.filter((x) => x !== t) : [...prev, t]));
  };

  const submit = async () => {
    if (!rating || submitting) return;
    setSubmitting(true);
    try {
      await onSubmit({ rating, tags, comment: comment.trim(), tip });
      void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setDone(true);
    } catch {
      setSubmitting(false);
    }
  };

  return (
    <Modal visible={visible} transparent animationType="none" statusBarTranslucent onRequestClose={onClose}>
      {visible ? (
        <KeyboardAvoidingView style={styles.root} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
          <Animated.View entering={FadeIn.duration(220)} exiting={FadeOut.duration(180)} style={StyleSheet.absoluteFill}>
            <BlurView intensity={30} tint="dark" style={StyleSheet.absoluteFill} />
            <Pressable style={[StyleSheet.absoluteFill, styles.scrim]} onPress={done ? undefined : onClose} />
          </Animated.View>

          <Animated.View
            entering={SlideInDown.springify().damping(18).stiffness(160)}
            exiting={SlideOutDown.duration(220)}
            layout={LinearTransition.springify().damping(20).stiffness(180)}
            style={[styles.sheetWrap, { maxHeight: height - insets.top - 24 }]}
          >
            <Surface style={[styles.sheet, { paddingBottom: Math.max(insets.bottom, 16) + 8 }]}>
              <LinearGradient
                colors={['rgba(56,189,248,0.16)', 'rgba(56,189,248,0)']}
                style={styles.sheetGlow}
                pointerEvents="none"
              />
              <View style={styles.handle} />

              {done ? (
                <Animated.View entering={ZoomIn.springify().damping(14)} style={styles.done}>
                  <Icon sf="checkmark.seal.fill" ion="checkmark-circle" size={56} color="#34D399" bounce />
                  <Text style={styles.doneTitle}>Thanks for the feedback</Text>
                  <Text style={styles.doneSub}>
                    {tip > 0 ? `${firstName} gets your £${tip} tip.` : `We've passed it on to ${firstName}.`}
                  </Text>
                </Animated.View>
              ) : (
                <ScrollView
                  style={styles.scroll}
                  bounces={false}
                  keyboardShouldPersistTaps="handled"
                  showsVerticalScrollIndicator={false}
                  contentContainerStyle={styles.body}
                >
                  <View style={styles.headRow}>
                    {proPhotoUrl ? (
                      <Image source={{ uri: proPhotoUrl }} style={styles.avatar} />
                    ) : (
                      <View style={[styles.avatar, styles.avatarFallback]}>
                        <Ionicons name="person" size={20} color="#E0F2FE" />
                      </View>
                    )}
                    <View style={styles.headText}>
                      <View style={styles.kickerRow}>
                        <Icon sf="checkmark.circle.fill" ion="checkmark-circle" size={12} color="#34D399" />
                        <Text style={styles.kicker}>{completeLabel}</Text>
                      </View>
                      <Text style={styles.title} numberOfLines={1}>
                        How did {firstName} do?
                      </Text>
                      {meta ? (
                        <Text style={styles.meta} numberOfLines={1}>
                          {meta}
                        </Text>
                      ) : null}
                    </View>
                    <Pressable onPress={onClose} hitSlop={10} style={styles.close} accessibilityLabel="Close">
                      <Ionicons name="close" size={16} color="rgba(226,232,240,0.8)" />
                    </Pressable>
                  </View>

                  <View style={styles.stars}>
                    {[0, 1, 2, 3, 4].map((i) => (
                      <Star key={i} index={i} rating={rating} onPick={pick} />
                    ))}
                  </View>
                  <Text style={[styles.ratingLabel, rating > 0 && styles.ratingLabelOn]}>
                    {rating ? RATING_LABELS[rating] : 'Tap to rate'}
                  </Text>

                  {rating > 0 ? (
                    <Animated.View entering={FadeInDown.duration(260)} style={styles.section}>
                      <Text style={styles.sectionLabel}>{rating >= 4 ? 'WHAT STOOD OUT' : 'WHAT COULD BE BETTER'}</Text>
                      <View style={styles.chips}>
                        {tagOptions.map((t) => (
                          <Chip key={t} label={t} active={tags.includes(t)} onPress={() => toggleTag(t)} />
                        ))}
                      </View>

                      <TextInput
                        style={styles.input}
                        value={comment}
                        onChangeText={setComment}
                        placeholder="Add a note (optional)"
                        placeholderTextColor="rgba(148,163,184,0.7)"
                        multiline
                        maxLength={500}
                      />

                      <Text style={[styles.sectionLabel, styles.tipLabel]}>ADD A TIP</Text>
                      <View style={styles.tips}>
                        {tipOptions.map((amt) => (
                          <Chip
                            key={amt}
                            label={amt === 0 ? 'None' : `£${amt}`}
                            active={tip === amt}
                            onPress={() => {
                              void Haptics.selectionAsync();
                              setTip(amt);
                            }}
                          />
                        ))}
                      </View>
                    </Animated.View>
                  ) : null}

                  <Pressable
                    onPress={() => void submit()}
                    disabled={!rating || submitting}
                    style={({ pressed }) => [
                      styles.cta,
                      (!rating || submitting) && styles.ctaDisabled,
                      pressed && styles.ctaPressed,
                    ]}
                    accessibilityRole="button"
                  >
                    <LinearGradient
                      colors={['rgba(56,189,248,0.75)', 'rgba(14,165,233,0.55)']}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 1, y: 1 }}
                      style={StyleSheet.absoluteFill}
                    />
                    <LinearGradient
                      colors={['rgba(255,255,255,0.22)', 'rgba(255,255,255,0)']}
                      style={styles.ctaSheen}
                    />
                    {submitting ? (
                      <ActivityIndicator color="#F8FAFC" />
                    ) : (
                      <Text style={styles.ctaText}>
                        {tip > 0 ? `Submit & tip £${tip}` : 'Submit review'}
                      </Text>
                    )}
                  </Pressable>
                  <Pressable onPress={onClose} hitSlop={8} style={styles.later}>
                    <Text style={styles.laterText}>Maybe later</Text>
                  </Pressable>
                </ScrollView>
              )}
            </Surface>
          </Animated.View>
        </KeyboardAvoidingView>
      ) : null}
    </Modal>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, justifyContent: 'flex-end' },
  scrim: { backgroundColor: 'rgba(2,6,23,0.45)' },
  sheetWrap: { flexShrink: 1 },
  scroll: { flexGrow: 0, flexShrink: 1 },
  sheet: {
    flexShrink: 1,
    borderTopLeftRadius: 32,
    borderTopRightRadius: 32,
    overflow: 'hidden',
    paddingTop: 8,
  },
  surfaceFallback: { overflow: 'hidden' },
  surfaceTint: { backgroundColor: 'rgba(6,16,32,0.78)' },
  sheetGlow: { position: 'absolute', left: 0, right: 0, top: 0, height: 140 },
  handle: {
    alignSelf: 'center',
    width: 38,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(226,232,240,0.28)',
    marginBottom: 10,
  },
  body: { paddingHorizontal: 20, paddingBottom: 4 },
  headRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  avatar: { width: 46, height: 46, borderRadius: 23 },
  avatarFallback: { alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(56,189,248,0.22)' },
  headText: { flex: 1, minWidth: 0 },
  kickerRow: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  kicker: { color: '#6EE7B7', fontSize: 10.5, fontWeight: '800', letterSpacing: 1.2 },
  title: { marginTop: 2, color: '#F8FAFC', fontSize: 20, fontWeight: '800', letterSpacing: -0.4 },
  meta: { marginTop: 1, color: 'rgba(226,232,240,0.6)', fontSize: 12.5, fontWeight: '600' },
  close: {
    width: 30,
    height: 30,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(148,163,184,0.16)',
    alignSelf: 'flex-start',
  },
  stars: { flexDirection: 'row', justifyContent: 'center', gap: 12, marginTop: 22 },
  ratingLabel: {
    marginTop: 8,
    textAlign: 'center',
    color: 'rgba(148,163,184,0.8)',
    fontSize: 13,
    fontWeight: '600',
  },
  ratingLabelOn: { color: GOLD, fontWeight: '800' },
  section: { marginTop: 18 },
  sectionLabel: { color: 'rgba(186,230,253,0.92)', fontSize: 10.5, fontWeight: '800', letterSpacing: 1.2 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 10 },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    height: 32,
    paddingHorizontal: 12,
    borderRadius: 16,
    backgroundColor: 'rgba(148,163,184,0.14)',
  },
  chipActive: { backgroundColor: 'rgba(56,189,248,0.2)' },
  chipText: { color: 'rgba(226,232,240,0.85)', fontSize: 13, fontWeight: '600' },
  chipTextActive: { color: '#E0F2FE', fontWeight: '700' },
  input: {
    marginTop: 14,
    minHeight: 64,
    maxHeight: 120,
    borderRadius: 16,
    paddingHorizontal: 14,
    paddingTop: 12,
    paddingBottom: 12,
    backgroundColor: 'rgba(148,163,184,0.12)',
    color: '#F8FAFC',
    fontSize: 14,
    fontWeight: '500',
    textAlignVertical: 'top',
  },
  tipLabel: { marginTop: 18 },
  tips: { flexDirection: 'row', gap: 8, marginTop: 10 },
  cta: {
    marginTop: 22,
    height: 52,
    borderRadius: 26,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: SKY,
    shadowOpacity: 0.35,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 6 },
  },
  ctaDisabled: { opacity: 0.45 },
  ctaPressed: { transform: [{ scale: 0.98 }] },
  ctaSheen: { position: 'absolute', left: 0, right: 0, top: 0, height: 26 },
  ctaText: { color: '#F8FAFC', fontSize: 15, fontWeight: '800', letterSpacing: -0.1 },
  later: { alignSelf: 'center', paddingVertical: 12 },
  laterText: { color: 'rgba(226,232,240,0.6)', fontSize: 13, fontWeight: '600' },
  done: { alignItems: 'center', paddingHorizontal: 24, paddingTop: 18, paddingBottom: 24, gap: 6 },
  doneTitle: { marginTop: 8, color: '#F8FAFC', fontSize: 19, fontWeight: '800', letterSpacing: -0.3 },
  doneSub: { color: 'rgba(226,232,240,0.65)', fontSize: 13.5, fontWeight: '500', textAlign: 'center' },
});
