import React, { useCallback, useEffect, useRef, useState } from 'react';
import { StyleSheet, View } from 'react-native';
import Animated, {
  Easing,
  useAnimatedStyle,
  useReducedMotion,
  useSharedValue,
  withDelay,
  withTiming,
} from 'react-native-reanimated';
import * as SplashScreen from 'expo-splash-screen';
import { preloadBootAssets } from '../../constants/appAssets';
import { SPLASH_BACKGROUND_COLOR, SPLASH_LOGO_SOURCE } from '../../constants/splash';
import AnimatedSplash from './AnimatedSplash';

const MIN_SPLASH_MS = 900;
const MAX_SPLASH_MS = 2200;
const CONTENT_SETTLE_DELAY_MS = 260;
const CONTENT_SETTLE_MS = 620;

type AppLaunchGateProps = {
  children: React.ReactNode;
  startupReady: boolean;
};

export default function AppLaunchGate({ children, startupReady }: Readonly<AppLaunchGateProps>) {
  const [assetsReady, setAssetsReady] = useState(false);
  const [rootLaidOut, setRootLaidOut] = useState(false);
  const [showAnimatedSplash, setShowAnimatedSplash] = useState(true);
  const [canFinish, setCanFinish] = useState(false);
  const startedAtRef = useRef(Date.now());
  const nativeHiddenRef = useRef(false);
  const reduced = useReducedMotion();
  const contentScale = useSharedValue(reduced ? 1 : 1.04);
  const contentStyle = useAnimatedStyle(() => ({ transform: [{ scale: contentScale.value }] }));

  useEffect(() => {
    if (!canFinish) return;
    contentScale.value = withDelay(
      CONTENT_SETTLE_DELAY_MS,
      withTiming(1, { duration: CONTENT_SETTLE_MS, easing: Easing.out(Easing.cubic) })
    );
  }, [canFinish, contentScale]);

  useEffect(() => {
    let active = true;
    preloadBootAssets()
      .catch(() => {})
      .finally(() => {
        if (active) setAssetsReady(true);
      });
    return () => {
      active = false;
    };
  }, []);

  const maybeHideNativeSplash = useCallback(async () => {
    if (nativeHiddenRef.current) return;
    if (!assetsReady || !rootLaidOut) return;
    nativeHiddenRef.current = true;
    SplashScreen.setOptions({ fade: true, duration: 180 });
    await SplashScreen.hideAsync().catch(() => {});
  }, [assetsReady, rootLaidOut]);

  useEffect(() => {
    void maybeHideNativeSplash();
  }, [maybeHideNativeSplash]);

  useEffect(() => {
    const elapsed = Date.now() - startedAtRef.current;
    const minDelay = Math.max(0, MIN_SPLASH_MS - elapsed);
    const maxDelay = Math.max(0, MAX_SPLASH_MS - elapsed);
    const minTimer = setTimeout(() => {
      if (startupReady) setCanFinish(true);
    }, minDelay);
    const maxTimer = setTimeout(() => {
      setCanFinish(true);
    }, maxDelay);
    return () => {
      clearTimeout(minTimer);
      clearTimeout(maxTimer);
    };
  }, [startupReady]);

  return (
    <View
      style={styles.root}
      onLayout={() => {
        setRootLaidOut(true);
      }}
    >
      <Animated.View style={[styles.root, contentStyle]}>{children}</Animated.View>
      {showAnimatedSplash ? (
        <AnimatedSplash
          startupReady={canFinish}
          onFinish={() => setShowAnimatedSplash(false)}
          logoSource={SPLASH_LOGO_SOURCE}
          backgroundColor={SPLASH_BACKGROUND_COLOR}
        />
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
  },
});
