import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, type ImageSourcePropType } from 'react-native';
import Animated, {
  cancelAnimation,
  Easing,
  FadeIn,
  FadeOut,
  runOnJS,
  useAnimatedStyle,
  useReducedMotion,
  useSharedValue,
  withDelay,
  withRepeat,
  withSequence,
  withTiming,
} from 'react-native-reanimated';
import { colors } from '../../constants/colors';
import SplashBackground from './SplashBackground';
import SplashLogo from './SplashLogo';
import SplashRipple from './SplashRipple';

const LOGO_PULSE_STEP_MS = 520;
const FALLBACK_STATE_DELAY_MS = 1200;

const EXIT_DIP_MS = 160;
const EXIT_ZOOM_MS = 460;
const EXIT_LOGO_FADE_DELAY_MS = 240;
const EXIT_LOGO_FADE_MS = 320;
const EXIT_BLOOM_DELAY_MS = 120;
const EXIT_BLOOM_MS = 640;
const EXIT_OVERLAY_DELAY_MS = 300;
const EXIT_OVERLAY_MS = 420;
const REDUCED_EXIT_MS = 220;

type AnimatedSplashProps = {
  startupReady: boolean;
  onFinish: () => void;
  logoSource: ImageSourcePropType;
  backgroundColor: string;
};

export default function AnimatedSplash({
  startupReady,
  onFinish,
  logoSource,
  backgroundColor,
}: Readonly<AnimatedSplashProps>) {
  const reduced = useReducedMotion();
  const [showFallback, setShowFallback] = useState(false);
  const containerOpacity = useSharedValue(1);
  const logoScale = useSharedValue(1);
  const logoOpacity = useSharedValue(1);
  const rippleScale = useSharedValue(0.1);
  const rippleOpacity = useSharedValue(0);

  useEffect(() => {
    const fallbackTimer = setTimeout(() => {
      setShowFallback(true);
      // Secondary state: subtle pulse while waiting on startup.
      logoScale.value = withRepeat(
        withSequence(
          withTiming(1.03, { duration: LOGO_PULSE_STEP_MS, easing: Easing.inOut(Easing.ease) }),
          withTiming(0.98, { duration: LOGO_PULSE_STEP_MS, easing: Easing.inOut(Easing.ease) })
        ),
        -1,
        false
      );
    }, FALLBACK_STATE_DELAY_MS);
    return () => clearTimeout(fallbackTimer);
  }, [logoScale]);

  useEffect(() => {
    if (!startupReady) return;
    setShowFallback(false);
    cancelAnimation(logoScale);
    const done = (finished?: boolean) => {
      'worklet';
      if (finished) runOnJS(onFinish)();
    };

    if (reduced) {
      containerOpacity.value = withTiming(0, { duration: REDUCED_EXIT_MS }, done);
      return;
    }

    logoScale.value = withSequence(
      withTiming(0.92, { duration: EXIT_DIP_MS, easing: Easing.out(Easing.quad) }),
      withTiming(1.8, { duration: EXIT_ZOOM_MS, easing: Easing.in(Easing.cubic) })
    );
    logoOpacity.value = withDelay(
      EXIT_LOGO_FADE_DELAY_MS,
      withTiming(0, { duration: EXIT_LOGO_FADE_MS, easing: Easing.out(Easing.quad) })
    );
    rippleScale.value = withDelay(
      EXIT_BLOOM_DELAY_MS,
      withTiming(18, { duration: EXIT_BLOOM_MS, easing: Easing.out(Easing.cubic) })
    );
    rippleOpacity.value = withDelay(
      EXIT_BLOOM_DELAY_MS,
      withSequence(
        withTiming(0.32, { duration: 180, easing: Easing.out(Easing.quad) }),
        withTiming(0, { duration: EXIT_BLOOM_MS - 180, easing: Easing.inOut(Easing.quad) })
      )
    );
    containerOpacity.value = withDelay(
      EXIT_OVERLAY_DELAY_MS,
      withTiming(0, { duration: EXIT_OVERLAY_MS, easing: Easing.out(Easing.cubic) }, done)
    );
  }, [containerOpacity, logoOpacity, logoScale, onFinish, reduced, rippleOpacity, rippleScale, startupReady]);

  const containerStyle = useAnimatedStyle(() => ({ opacity: containerOpacity.value }));
  return (
    <Animated.View style={[styles.root, containerStyle]} pointerEvents="auto">
      <SplashBackground backgroundColor={backgroundColor} />
      <SplashLogo source={logoSource} scale={logoScale} opacity={logoOpacity} />
      <SplashRipple scale={rippleScale} opacity={rippleOpacity} />

      {showFallback ? (
        <Animated.View entering={FadeIn.duration(260)} exiting={FadeOut.duration(160)} style={styles.fallbackWrap}>
          <Text style={styles.fallbackText}>Preparing your experience</Text>
          <View style={styles.progressTrack}>
            <View style={[styles.progressLine, { width: startupReady ? '100%' : '62%' }, startupReady ? styles.progressReady : null]} />
          </View>
        </Animated.View>
      ) : null}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  root: {
    ...StyleSheet.absoluteFill,
    zIndex: 9999,
    alignItems: 'center',
    justifyContent: 'center',
  },
  fallbackWrap: {
    position: 'absolute',
    bottom: 92,
    width: '100%',
    alignItems: 'center',
    paddingHorizontal: 24,
  },
  fallbackText: {
    color: 'rgba(241,245,249,0.85)',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 10,
  },
  progressTrack: {
    width: 190,
    height: 3,
    borderRadius: 999,
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
  progressLine: {
    height: '100%',
    backgroundColor: 'rgba(241,245,249,0.8)',
  },
  progressReady: {
    backgroundColor: colors.SKY,
  },
});
