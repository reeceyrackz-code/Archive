import { useEffect, useRef, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  TextInput,
  ActivityIndicator,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import Animated, {
  FadeIn,
  FadeOut,
  ZoomIn,
  useAnimatedStyle,
  useSharedValue,
  withSequence,
  withSpring,
} from "react-native-reanimated";
import { REFERRAL_BONUS_POINTS } from "../../services/LoyaltyService";
import { hapticFeedback } from "../../services/HapticFeedbackService";
import HubGlassIcon from "../shared/HubGlassIcon";
import { PressScale } from "../pass/PassKit";

type Props = Readonly<{
  referralCode: string;
  onCopy: () => void;
  entryCode: string;
  onChangeEntryCode: (code: string) => void;
  onApply: () => void;
  applying: boolean;
  hasApplied: boolean;
  ready: boolean;
}>;

const COPIED_MS = 1800;

export default function ReferralInviteTicket({
  referralCode,
  onCopy,
  entryCode,
  onChangeEntryCode,
  onApply,
  applying,
  hasApplied,
  ready,
}: Props) {
  const canApply = ready && !applying && entryCode.trim().length > 0;
  const [copied, setCopied] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const inputRef = useRef<TextInput>(null);
  const codeScale = useSharedValue(1);
  const codeStyle = useAnimatedStyle(() => ({
    transform: [{ scale: codeScale.value }],
  }));

  useEffect(
    () => () => {
      if (timer.current) clearTimeout(timer.current);
    },
    [],
  );

  const copy = () => {
    onCopy();
    void hapticFeedback("medium");
    codeScale.value = withSequence(
      withSpring(1.06, { damping: 10, stiffness: 400 }),
      withSpring(1, { damping: 12 }),
    );
    setCopied(true);
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setCopied(false), COPIED_MS);
  };

  return (
    <View>
      <View style={[styles.card, styles.body]}>
        <View style={styles.offerRow}>
          <HubGlassIcon icon="gift" accent="green" size={40} iconSize={18} />
          <View style={styles.offerText}>
            <Text style={styles.offerTitle}>
              Give £5, get +{REFERRAL_BONUS_POINTS} pts
            </Text>
            <Text style={styles.offerSub}>
              Friends get £5 off. You earn when they finish their first wash.
            </Text>
          </View>
        </View>

        <View style={styles.codeBox}>
          <Pressable
            onPress={copy}
            accessibilityRole="button"
            accessibilityLabel="Copy referral code"
          >
            <Animated.View style={[styles.codeRow, codeStyle]}>
              <View style={styles.codeTextWrap}>
                <Text style={styles.codeLabel}>Referral code</Text>
                <Text
                  style={styles.code}
                  numberOfLines={1}
                  adjustsFontSizeToFit
                >
                  {referralCode}
                </Text>
              </View>
              {copied ? (
                <Animated.View
                  key="done"
                  entering={ZoomIn.springify().damping(12)}
                  exiting={FadeOut.duration(120)}
                  style={[styles.copyChip, styles.copyChipDone]}
                >
                  <Ionicons name="checkmark" size={14} color="#052E1B" />
                  <Text style={styles.copyChipDoneText}>Copied</Text>
                </Animated.View>
              ) : (
                <Animated.View
                  key="copy"
                  entering={FadeIn.duration(160)}
                  style={styles.copyChip}
                >
                  <Ionicons name="copy-outline" size={14} color="#A7F3D0" />
                  <Text style={styles.copyChipText}>Copy</Text>
                </Animated.View>
              )}
            </Animated.View>
          </Pressable>

          <View style={styles.codeDivider} />

          <Pressable
            style={styles.entryRow}
            onPress={() => inputRef.current?.focus()}
            disabled={hasApplied}
          >
            <Ionicons
              name="ticket-outline"
              size={17}
              color="rgba(167,243,208,0.75)"
            />
            <TextInput
              ref={inputRef}
              value={entryCode}
              onChangeText={(t) => onChangeEntryCode(t.toUpperCase())}
              placeholder={
                hasApplied ? "Friend's code applied" : "Have a friend's code?"
              }
              placeholderTextColor="rgba(209,250,229,0.45)"
              autoCapitalize="characters"
              autoCorrect={false}
              returnKeyType="done"
              onSubmitEditing={() => {
                if (canApply) onApply();
              }}
              editable={!applying && !hasApplied}
              style={styles.entryInput}
              accessibilityLabel="Friend's referral code"
            />
            {hasApplied ? (
              <View style={styles.appliedChip}>
                <Ionicons name="checkmark-circle" size={16} color="#6EE7B7" />
                <Text style={styles.appliedText}>Applied</Text>
              </View>
            ) : (
              <PressScale
                onPress={onApply}
                disabled={!canApply}
                style={[
                  styles.applyBtn,
                  !canApply && !applying && styles.applyBtnIdle,
                ]}
                accessibilityLabel="Apply referral code"
              >
                <LinearGradient
                  colors={["#34D399", "#10B981", "#059669"]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={StyleSheet.absoluteFill}
                />
                {applying ? (
                  <ActivityIndicator size="small" color="#052E1B" />
                ) : (
                  <Text style={styles.applyText}>Apply</Text>
                )}
              </PressScale>
            )}
          </Pressable>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    padding: 16,
    borderRadius: 22,
    borderWidth: 1,
    borderColor: "rgba(52,211,153,0.2)",
    backgroundColor: "rgba(15,23,42,0.45)",
  },
  body: {
    gap: 14,
  },
  offerRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  offerText: {
    flex: 1,
    gap: 2,
  },
  offerTitle: {
    color: "#ECFDF5",
    fontSize: 15,
    fontWeight: "800",
  },
  offerSub: {
    color: "rgba(209,250,229,0.72)",
    fontSize: 12,
    fontWeight: "600",
  },
  codeBox: {
    paddingHorizontal: 16,
    paddingTop: 10,
    paddingBottom: 6,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "rgba(110,231,183,0.3)",
    backgroundColor: "rgba(6,78,59,0.3)",
  },
  codeRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  codeDivider: {
    height: StyleSheet.hairlineWidth,
    marginTop: 10,
    backgroundColor: "rgba(110,231,183,0.25)",
  },
  codeTextWrap: {
    flex: 1,
    minWidth: 0,
    gap: 2,
  },
  codeLabel: {
    color: "rgba(167,243,208,0.7)",
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 1.2,
    textTransform: "uppercase",
  },
  code: {
    color: "#ECFDF5",
    fontSize: 22,
    fontWeight: "900",
    letterSpacing: 2.4,
    fontVariant: ["tabular-nums"],
  },
  copyChip: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    paddingHorizontal: 11,
    paddingVertical: 7,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: "rgba(110,231,183,0.4)",
    backgroundColor: "rgba(16,185,129,0.16)",
  },
  copyChipText: {
    color: "#A7F3D0",
    fontSize: 12,
    fontWeight: "800",
  },
  copyChipDone: {
    backgroundColor: "#6EE7B7",
    borderColor: "#6EE7B7",
  },
  copyChipDoneText: {
    color: "#052E1B",
    fontSize: 12,
    fontWeight: "900",
  },
  entryRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    height: 50,
    marginRight: -10,
  },
  entryInput: {
    flex: 1,
    minWidth: 0,
    height: "100%",
    color: "#ECFDF5",
    fontSize: 15,
    fontWeight: "800",
    letterSpacing: 1.2,
  },
  applyBtn: {
    height: 40,
    paddingHorizontal: 18,
    borderRadius: 999,
    overflow: "hidden",
    alignItems: "center",
    justifyContent: "center",
  },
  applyBtnIdle: {
    opacity: 0.45,
  },
  applyText: {
    color: "#052E1B",
    fontSize: 14,
    fontWeight: "900",
  },
  appliedChip: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 12,
  },
  appliedText: {
    color: "#A7F3D0",
    fontSize: 13,
    fontWeight: "800",
  },
});
