import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Pressable,
  TextInput,
  ActivityIndicator,
  Alert,
  Platform,
} from 'react-native';
import Animated, {
  css,
  FadeIn,
  FadeInDown,
  FadeOutUp,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import * as Location from 'expo-location';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { router, useFocusEffect } from 'expo-router';
import { colors } from '../../constants/colors';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import {
  CUSTOMER_SAVED_LOCATIONS_KEY,
  DASHBOARD_WASH_LOCATION_KEY as SELECTION_KEY,
  SAVED_LOCATION_LABEL_META as LABEL_META,
  loadCustomerSavedLocations,
  savedLocationTitle as locationTitle,
  type CustomerSavedLocation,
  type CustomerSavedLocationLabelId,
} from '../../utils/customerSavedLocations';

const SKY = colors.SKY ?? '#87CEEB';

type Coords = { latitude: number; longitude: number };
type IconName = keyof typeof Ionicons.glyphMap;

const ADDABLE_LABELS: CustomerSavedLocationLabelId[] = ['home', 'work', 'other'];
const FINDING_YOU = 'Finding you…';

const gpsPulse = css.keyframes({
  from: { transform: [{ scale: 1 }], opacity: 0.55 },
  to: { transform: [{ scale: 1.7 }], opacity: 0 },
});

function formatAddress(r?: Location.LocationGeocodedAddress | null, fallback = 'Current location') {
  if (!r) return fallback;
  const line = [r.name && r.name !== r.street ? r.name : r.street, r.city, r.postalCode]
    .filter(Boolean)
    .join(', ');
  return line || fallback;
}

type Props = {
  userId?: string | null;
  /** `null` means "use live GPS location". */
  onSelect: (coords: Coords | null) => void;
};

export default function DashboardLocationPicker({ userId, onSelect }: Props) {
  const [saved, setSaved] = useState<CustomerSavedLocation[]>([]);
  const [selectedId, setSelectedId] = useState<string>('current');
  const [currentAddress, setCurrentAddress] = useState(FINDING_YOU);
  const [currentCoords, setCurrentCoords] = useState<Coords | null>(null);
  const [open, setOpen] = useState(false);
  const [addingLabel, setAddingLabel] = useState<CustomerSavedLocationLabelId | null>(null);
  const [draft, setDraft] = useState('');
  const [saving, setSaving] = useState(false);

  const pressScale = useSharedValue(1);
  const pressStyle = useAnimatedStyle(() => ({ transform: [{ scale: pressScale.value }] }));
  const chevron = useSharedValue(0);
  const chevronStyle = useAnimatedStyle(() => ({
    transform: [{ rotate: `${chevron.value * 180}deg` }],
  }));

  useEffect(() => {
    chevron.value = withTiming(open ? 1 : 0, { duration: 220 });
  }, [open, chevron]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const { status } = await Location.getForegroundPermissionsAsync();
        if (status !== 'granted') {
          if (!cancelled) setCurrentAddress('Current location');
          return;
        }
        const pos =
          (await Location.getLastKnownPositionAsync()) ??
          (await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced }));
        const coords = { latitude: pos.coords.latitude, longitude: pos.coords.longitude };
        const [rev] = await Location.reverseGeocodeAsync(coords);
        if (cancelled) return;
        setCurrentCoords(coords);
        setCurrentAddress(formatAddress(rev));
      } catch {
        if (!cancelled) setCurrentAddress('Current location');
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const selectedIdRef = useRef(selectedId);
  selectedIdRef.current = selectedId;

  useFocusEffect(
    useCallback(() => {
      if (!userId) return;
      let cancelled = false;
      (async () => {
        const list = await loadCustomerSavedLocations(userId);
        const persisted = await AsyncStorage.getItem(`${SELECTION_KEY}_${userId}`).catch(() => null);
        if (cancelled) return;
        setSaved(list);
        const match = persisted ? list.find((l) => l.id === persisted) : undefined;
        if (match) {
          setSelectedId(match.id);
          onSelect({ latitude: match.latitude, longitude: match.longitude });
        } else if (selectedIdRef.current !== 'current') {
          setSelectedId('current');
          onSelect(null);
        }
      })();
      return () => {
        cancelled = true;
      };
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [userId])
  );

  const selected = useMemo(() => saved.find((l) => l.id === selectedId) ?? null, [saved, selectedId]);

  const persistSaved = useCallback(
    async (next: CustomerSavedLocation[]) => {
      setSaved(next);
      if (userId) {
        await AsyncStorage.setItem(`${CUSTOMER_SAVED_LOCATIONS_KEY}_${userId}`, JSON.stringify(next));
      }
    },
    [userId]
  );

  const choose = useCallback(
    (id: string) => {
      void hapticFeedback('light');
      setSelectedId(id);
      setOpen(false);
      setAddingLabel(null);
      if (userId) void AsyncStorage.setItem(`${SELECTION_KEY}_${userId}`, id).catch(() => {});
      const loc = saved.find((l) => l.id === id);
      onSelect(loc ? { latitude: loc.latitude, longitude: loc.longitude } : null);
    },
    [saved, userId, onSelect]
  );

  const startAdd = (label: CustomerSavedLocationLabelId) => {
    void hapticFeedback('light');
    const existing = label !== 'other' ? saved.find((l) => l.label === label) : undefined;
    setAddingLabel(label);
    setDraft(existing?.address ?? '');
  };

  const saveDraft = async (useCurrent: boolean) => {
    if (!addingLabel || !userId) return;
    const text = draft.trim();
    if (!useCurrent && !text) return;
    setSaving(true);
    try {
      let coords: Coords | null = useCurrent ? currentCoords : null;
      let address = useCurrent ? currentAddress : text;
      if (!coords) {
        const [hit] = await Location.geocodeAsync(text);
        if (!hit) {
          Alert.alert('Address not found', 'Try a postcode or a more specific street address.');
          return;
        }
        coords = { latitude: hit.latitude, longitude: hit.longitude };
        const [rev] = await Location.reverseGeocodeAsync(coords).catch(() => [null]);
        address = formatAddress(rev, text);
      }
      const existing = addingLabel !== 'other' ? saved.find((l) => l.label === addingLabel) : undefined;
      const entry: CustomerSavedLocation = {
        id: existing?.id ?? `loc-${Date.now()}`,
        label: addingLabel,
        address,
        latitude: coords.latitude,
        longitude: coords.longitude,
        ...(existing?.details ? { details: existing.details } : {}),
      };
      const next = existing ? saved.map((l) => (l.id === existing.id ? entry : l)) : [...saved, entry];
      await persistSaved(next);
      await hapticFeedback('medium');
      setSelectedId(entry.id);
      void AsyncStorage.setItem(`${SELECTION_KEY}_${userId}`, entry.id).catch(() => {});
      onSelect(coords);
      setAddingLabel(null);
      setDraft('');
      setOpen(false);
    } catch (e: any) {
      Alert.alert('Could not save address', e?.message || 'Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const confirmRemove = (loc: CustomerSavedLocation) => {
    Alert.alert(`Remove ${locationTitle(loc)}?`, loc.address, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: async () => {
          await persistSaved(saved.filter((l) => l.id !== loc.id));
          if (selectedId === loc.id) choose('current');
        },
      },
    ]);
  };

  const triggerIcon: IconName = selected ? LABEL_META[selected.label].icon : 'navigate';
  const triggerTitle = selected ? locationTitle(selected) : 'Current location';
  const triggerAddress = selected ? selected.address : currentAddress;
  const usingGps = !selected && currentCoords != null;
  const locating = !selected && currentAddress === FINDING_YOU;

  return (
    <View style={styles.root}>
      <Pressable
        onPress={() => {
          void hapticFeedback('light');
          setOpen((v) => !v);
          if (open) setAddingLabel(null);
        }}
        onPressIn={() => {
          pressScale.value = withSpring(0.97, { damping: 16, stiffness: 380 });
        }}
        onPressOut={() => {
          pressScale.value = withSpring(1, { damping: 12, stiffness: 260 });
        }}
        accessibilityRole="button"
        accessibilityLabel={`Wash location: ${triggerTitle}, ${triggerAddress}`}
        accessibilityState={{ expanded: open }}
      >
        <Animated.View style={[styles.trigger, pressStyle]}>
          <View style={styles.triggerIconWrap}>
            {usingGps ? (
              <Animated.View
                style={[
                  styles.triggerPulse,
                  {
                    animationName: gpsPulse,
                    animationDuration: '2s',
                    animationIterationCount: 'infinite',
                    animationTimingFunction: 'ease-out',
                  },
                ]}
              />
            ) : null}
            <LinearGradient
              colors={['rgba(56,189,248,0.32)', 'rgba(56,189,248,0.1)']}
              start={{ x: 0.2, y: 0 }}
              end={{ x: 0.8, y: 1 }}
              style={styles.triggerIcon}
            >
              <Animated.View key={triggerIcon} entering={FadeIn.duration(220)}>
                <Ionicons name={triggerIcon} size={17} color={SKY} />
              </Animated.View>
            </LinearGradient>
          </View>
          <View style={styles.triggerText}>
            <Text style={styles.triggerKicker}>WASH AT</Text>
            <View style={styles.triggerTitleRow}>
              <Animated.Text
                key={triggerTitle}
                entering={FadeIn.duration(220)}
                style={styles.triggerTitle}
                numberOfLines={1}
              >
                {triggerTitle}
              </Animated.Text>
              <Animated.View style={[styles.chevronBadge, chevronStyle]}>
                <Ionicons name="chevron-down" size={12} color={SKY} />
              </Animated.View>
            </View>
          </View>
          <View style={styles.triggerAddressWrap}>
            {locating ? <ActivityIndicator size="small" color="rgba(148,163,184,0.85)" style={styles.locatingSpinner} /> : null}
            <Animated.Text
              key={triggerAddress}
              entering={FadeIn.duration(260)}
              style={styles.triggerAddress}
              numberOfLines={1}
            >
              {triggerAddress}
            </Animated.Text>
          </View>
        </Animated.View>
      </Pressable>

      {open ? (
        <Animated.View
          entering={FadeInDown.springify().damping(18).stiffness(220)}
          exiting={FadeOutUp.duration(140)}
          style={styles.panel}
        >
          <BlurView intensity={Platform.OS === 'ios' ? 32 : 44} tint="dark" style={StyleSheet.absoluteFill} />
          <View style={styles.panelTint} />

          <Row
            index={0}
            icon="navigate"
            title="Current"
            subtitle={currentAddress}
            active={selectedId === 'current'}
            onPress={() => choose('current')}
          />
          {saved.map((loc, i) => (
            <Row
              key={loc.id}
              index={i + 1}
              icon={LABEL_META[loc.label].icon}
              title={locationTitle(loc)}
              subtitle={loc.address}
              active={selectedId === loc.id}
              onPress={() => choose(loc.id)}
              onLongPress={() => confirmRemove(loc)}
              onRemove={() => confirmRemove(loc)}
            />
          ))}

          {addingLabel ? (
            <Animated.View entering={FadeInDown.duration(180)} style={styles.addForm}>
              <View style={styles.labelToggle}>
                {ADDABLE_LABELS.map((label) => {
                  const active = addingLabel === label;
                  return (
                    <TouchableOpacity
                      key={label}
                      onPress={() => startAdd(label)}
                      style={[styles.labelOption, active && styles.labelOptionActive]}
                      activeOpacity={0.85}
                      accessibilityLabel={`Save as ${LABEL_META[label].title}`}
                    >
                      <Ionicons name={LABEL_META[label].icon} size={13} color={active ? '#0B1220' : SKY} />
                      <Text style={[styles.labelOptionText, active && styles.labelOptionTextActive]}>
                        {LABEL_META[label].title}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </View>
              <View style={styles.inputWrap}>
                <TextInput
                  style={styles.input}
                  value={draft}
                  onChangeText={setDraft}
                  placeholder="Postcode or address"
                  placeholderTextColor="rgba(148,163,184,0.7)"
                  autoFocus
                  autoCapitalize="words"
                  returnKeyType="done"
                  onSubmitEditing={() => void saveDraft(false)}
                />
                <TouchableOpacity
                  onPress={() => void saveDraft(true)}
                  disabled={saving || !currentCoords}
                  style={[styles.inputIconBtn, !currentCoords && styles.disabled]}
                  hitSlop={6}
                  accessibilityLabel="Use current location"
                >
                  <Ionicons name="locate" size={16} color={SKY} />
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => void saveDraft(false)}
                  disabled={saving || !draft.trim()}
                  style={[styles.saveBtn, (!draft.trim() || saving) && styles.disabled]}
                  accessibilityLabel={`Save ${LABEL_META[addingLabel].title}`}
                >
                  {saving ? (
                    <ActivityIndicator size="small" color="#0B1220" />
                  ) : (
                    <Ionicons name="checkmark" size={16} color="#0B1220" />
                  )}
                </TouchableOpacity>
              </View>
            </Animated.View>
          ) : (
            <View style={styles.footer}>
              <TouchableOpacity
                onPress={() => startAdd(saved.some((l) => l.label === 'home') ? 'other' : 'home')}
                style={styles.footerBtn}
                hitSlop={6}
              >
                <Ionicons name="add" size={15} color={SKY} />
                <Text style={styles.footerText}>Add address</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  setOpen(false);
                  router.push('/owner/settings/saved-locations' as any);
                }}
                hitSlop={8}
                accessibilityLabel="Manage saved addresses"
              >
                <Text style={styles.manageText}>Manage</Text>
              </TouchableOpacity>
            </View>
          )}
        </Animated.View>
      ) : null}
    </View>
  );
}

function Row({
  index,
  icon,
  title,
  subtitle,
  active,
  onPress,
  onLongPress,
  onRemove,
}: {
  index: number;
  icon: IconName;
  title: string;
  subtitle: string;
  active: boolean;
  onPress: () => void;
  onLongPress?: () => void;
  onRemove?: () => void;
}) {
  return (
    <Animated.View entering={FadeInDown.delay(40 + index * 35).duration(220)}>
    <Pressable
      onPress={onPress}
      {...(onLongPress ? { onLongPress } : {})}
      style={({ pressed }) => [styles.row, active && styles.rowActive, pressed && styles.rowPressed]}
    >
      <View style={[styles.rowIcon, active && styles.rowIconActive]}>
        <Ionicons name={icon} size={14} color={active ? SKY : 'rgba(148,163,184,0.9)'} />
      </View>
      <Text style={styles.rowText} numberOfLines={1}>
        <Text style={[styles.rowTitle, active && styles.rowTitleActive]}>{title}</Text>
        <Text style={styles.rowSubtitle}>{`  ${subtitle}`}</Text>
      </Text>
      {active ? <Ionicons name="checkmark" size={16} color={SKY} /> : null}
      {onRemove ? (
        <TouchableOpacity
          onPress={() => {
            void hapticFeedback('light');
            onRemove();
          }}
          hitSlop={10}
          style={styles.removeBtn}
          accessibilityLabel={`Remove ${title}`}
        >
          <Ionicons name="close" size={14} color="rgba(203,213,225,0.85)" />
        </TouchableOpacity>
      ) : null}
    </Pressable>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  root: { zIndex: 20 },
  trigger: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 4,
  },
  triggerIconWrap: { width: 36, height: 36, alignItems: 'center', justifyContent: 'center' },
  triggerPulse: {
    position: 'absolute',
    width: 36,
    height: 36,
    borderRadius: 12,
    backgroundColor: 'rgba(56,189,248,0.35)',
  },
  triggerIcon: {
    width: 36,
    height: 36,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: SKY,
    shadowOpacity: 0.35,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 2 },
  },
  triggerText: { flexShrink: 0, maxWidth: '45%' },
  triggerKicker: {
    color: 'rgba(148,163,184,0.9)',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1,
  },
  triggerTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 1 },
  triggerTitle: { color: '#F8FAFC', fontSize: 16, fontWeight: '800', letterSpacing: -0.2, flexShrink: 1 },
  chevronBadge: {
    width: 18,
    height: 18,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(56,189,248,0.16)',
  },
  triggerAddressWrap: {
    flex: 1,
    minWidth: 0,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    gap: 6,
    alignSelf: 'flex-end',
    marginBottom: 2,
  },
  locatingSpinner: { transform: [{ scale: 0.7 }] },
  triggerAddress: {
    flexShrink: 1,
    textAlign: 'right',
    color: 'rgba(148,163,184,0.85)',
    fontSize: 12,
    fontWeight: '600',
  },

  panel: {
    marginTop: 8,
    borderRadius: 18,
    overflow: 'hidden',
    paddingVertical: 6,
    paddingHorizontal: 6,
    shadowColor: '#000',
    shadowOpacity: 0.35,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 10 },
    elevation: 10,
  },
  panelTint: { ...StyleSheet.absoluteFill, backgroundColor: 'rgba(6,16,32,0.7)' },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    height: 44,
    paddingHorizontal: 8,
    borderRadius: 12,
  },
  rowActive: { backgroundColor: 'rgba(56,189,248,0.12)' },
  rowPressed: { backgroundColor: 'rgba(148,163,184,0.12)' },
  rowIcon: {
    width: 28,
    height: 28,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(148,163,184,0.12)',
  },
  rowIconActive: { backgroundColor: 'rgba(56,189,248,0.2)' },
  rowText: { flex: 1, minWidth: 0 },
  rowTitle: { color: 'rgba(241,245,249,0.92)', fontSize: 14, fontWeight: '700' },
  rowTitleActive: { color: SKY },
  rowSubtitle: { color: 'rgba(148,163,184,0.85)', fontSize: 12, fontWeight: '500' },
  removeBtn: {
    width: 22,
    height: 22,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(148,163,184,0.16)',
  },

  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    height: 38,
    paddingHorizontal: 10,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(148,163,184,0.2)',
    marginTop: 2,
  },
  footerBtn: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  footerText: { color: SKY, fontSize: 13, fontWeight: '700' },
  manageText: { color: 'rgba(148,163,184,0.85)', fontSize: 12, fontWeight: '600' },

  addForm: {
    gap: 8,
    paddingHorizontal: 10,
    paddingTop: 8,
    paddingBottom: 6,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(148,163,184,0.2)',
    marginTop: 2,
  },
  labelToggle: { flexDirection: 'row', gap: 6 },
  labelOption: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    height: 28,
    paddingHorizontal: 10,
    borderRadius: 14,
    backgroundColor: 'rgba(135,206,235,0.08)',
  },
  labelOptionActive: { backgroundColor: SKY },
  labelOptionText: { color: '#E0F2FE', fontSize: 12, fontWeight: '700' },
  labelOptionTextActive: { color: '#0B1220' },
  inputWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    height: 38,
    paddingLeft: 12,
    paddingRight: 4,
    borderRadius: 19,
    backgroundColor: 'rgba(8,20,38,0.75)',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  input: { flex: 1, color: '#F8FAFC', fontSize: 14, fontWeight: '600', paddingVertical: 0 },
  inputIconBtn: { width: 30, height: 30, alignItems: 'center', justifyContent: 'center' },
  saveBtn: {
    width: 30,
    height: 30,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: SKY,
  },
  disabled: { opacity: 0.45 },
});
