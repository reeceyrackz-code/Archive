import { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Dimensions,
  ScrollView,
  RefreshControl,
  StatusBar,
  AppState,
  Image,
  Pressable,
  Modal,
  type NativeSyntheticEvent,
  type NativeScrollEvent,
} from 'react-native';
import type { Region } from 'react-native-maps';
import * as Location from 'expo-location';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useFocusEffect } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../providers/enhanced-auth-context';
import { supabase } from '../../lib/supabase';
import AsyncStorage from '@react-native-async-storage/async-storage';
import GradientIconBox from '../shared/GradientIconBox';
import LivelyEmptyState, { type LivelyEmptyAction } from '../shared/LivelyEmptyState';
import HubGlassIcon, { HUB_GLASS_PALETTES, type HubGlassPalette } from '../shared/HubGlassIcon';
import StaggerIn from '../shared/StaggerIn';
import DashboardLocationPicker from './DashboardLocationPicker';
import TopCareProCard from '../shared/TopCareProCard';
import { readSavedPros, toggleSavedProRow, writeSavedPros, type SavedProRow } from '../../utils/savedPros';
import BubbleBackground from '../shared/BubbleBackground';
import ExploreMapButton from './ExploreMapButton';
import LiveJobCard from './LiveJobCard';
import DashboardHeaderBar, { DASHBOARD_HEADER_BAR_BODY } from './DashboardHeaderBar';
import Reanimated, { css, FadeInDown, useSharedValue } from 'react-native-reanimated';
import useLiveLocation from '../../hooks/useLiveLocation';
import {
  SUBTLE_WAVE_DASHBOARD_TINT_ENABLED,
  subtleWaveDashboardTint,
} from '../../constants/subtleWaveDashboardTint';
import { useThemeOptional } from '../../contexts/ThemeContext';
import { colors } from '../../constants/colors';
import { ValeterStatsService } from '../../services/Valeterstatsservice';
import { formatDisplayName } from '../../utils/formatDisplayName';
import { fetchValeterIdentitiesByIds, fetchValeterIdentity, resolveValeterDisplayName } from '../../utils/valeterDisplayName';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { useOwnerScrollContentPadding } from '../../hooks/useOwnerScrollContentPadding';
import { SkeletonList } from '../shared/SkeletonLoader';
import ValeterProfileBottomSheet, {
  type ValeterProfileSheetSeed,
} from '../valeter/ValeterProfileBottomSheet';
import HubLocationProfileBottomSheet, {
  type HubLocationSheetSeed,
} from '../hub/HubLocationProfileBottomSheet';
import { BlurView } from 'expo-blur';
import { useAdaptiveLayout } from '../../constants/adaptiveLayout';
import { distanceKm, regionForCoordinates } from '../../utils/mapUtils';
import { isBookingManuallyStarted } from '../../utils/activeBookingGuard';
import { getLoyaltyBalance } from '../../services/LoyaltyService';
import { fetchUnreadBookingChatThreads } from '../../services/BookingChatService';
import { getNextMilestone, getTierProgress } from '../../utils/loyaltyTier';
import {
  clearPendingRatingBookingId,
  getPendingRatingBookingId,
} from '../../utils/pendingCustomerRating';
import { MOBILE_SERVICE_ONLY_LAUNCH } from '../../constants/launchCustomerScope';
import { CCP, ccpFallbackName, ccpPluralLower, ccpSingularLower } from '../../constants/carCareProLabels';
import {
  BOOKING_GLASS_TOP_SHEEN,
  BOOKING_GLASS_TOP_SHEEN_LOCATIONS,
} from '../../constants/bookingCardTheme';
import { useMapChromeColors } from '../../hooks/useMapChromeColors';
import { accentToGradient } from '../../utils/accentGradient';
import {
  cpz,
  dz,
  dzHero,
  getDashboardLayout,
  getTopCareProCardWidth,
} from '../../constants/topCareProCardLayout';

const { width } = Dimensions.get('window');

/** Dashboard Top Care Pros — sized to fit dashboard width with a next-card peek. */
const TOP_CARE_PRO_CARD_ZOOM = 0.84;

function renderTopPickGlossSheen() {
  return (
    <LinearGradient
      colors={[...BOOKING_GLASS_TOP_SHEEN]}
      locations={[...BOOKING_GLASS_TOP_SHEEN_LOCATIONS]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 0.85 }}
      style={StyleSheet.absoluteFill}
      pointerEvents="none"
    />
  );
}

type HubGlassAccent = HubGlassPalette;

const HUB_GLASS_ACCENTS: Record<'vehicles' | 'rewards' | 'referrals', HubGlassAccent> = {
  vehicles: HUB_GLASS_PALETTES.sky,
  rewards: HUB_GLASS_PALETTES.gold,
  referrals: HUB_GLASS_PALETTES.green,
};

const hubGlowBreath = css.keyframes({
  '0%': { opacity: 0.14, transform: [{ scale: 0.92 }] },
  '50%': { opacity: 0.32, transform: [{ scale: 1.06 }] },
  '100%': { opacity: 0.14, transform: [{ scale: 0.92 }] },
});

function formatHubPoints(points: number): string {
  if (points >= 10000) return `${Math.round(points / 1000)}k`;
  if (points >= 1000) return `${(points / 1000).toFixed(1).replace(/\.0$/, '')}k`;
  return `${points}`;
}

function HubGlassActionTile({
  index,
  icon,
  label,
  hint,
  badge,
  accent,
  scaleAnim,
  onPress,
  large,
  scale = 1,
}: Readonly<{
  index: number;
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  hint: string;
  badge?: string | null;
  accent: HubGlassAccent;
  scaleAnim: Animated.Value;
  onPress: () => void;
  large?: boolean;
  scale?: number;
}>) {
  const iconWell = Math.round((large ? dzHero(52) : dzHero(48)) * scale);
  const iconSize = Math.round((large ? dzHero(26) : dzHero(24)) * scale);
  const labelSize = Math.max(11, Math.round(dzHero(12) * scale));
  const hintSize = Math.max(9, Math.round(dzHero(11) * scale));
  const glowSize = Math.round(iconWell * 1.35);

  return (
    <Reanimated.View
      entering={FadeInDown.delay(80 + index * 70).springify().damping(16)}
      style={styles.quickActionPressable}
    >
    <Pressable
      onPressIn={() => {
        void hapticFeedback('light');
        Animated.spring(scaleAnim, { toValue: 0.93, useNativeDriver: true, speed: 140, bounciness: 0 }).start();
      }}
      onPressOut={() => Animated.spring(scaleAnim, { toValue: 1, useNativeDriver: true, speed: 18, bounciness: 10 }).start()}
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={`${label}. ${hint}`}
    >
      <Animated.View style={[styles.hubGlassTile, { transform: [{ scale: scaleAnim }] }]}>
        <View style={[styles.hubIconStage, { width: iconWell, height: iconWell }]}>
          <Reanimated.View
            pointerEvents="none"
            style={[
              styles.hubIconGlow,
              {
                width: glowSize,
                height: glowSize,
                borderRadius: glowSize / 2,
                backgroundColor: accent.glow,
                shadowColor: accent.glow,
                animationName: hubGlowBreath,
                animationDuration: '3.2s',
                animationDelay: `${index * 0.5}s`,
                animationIterationCount: 'infinite',
                animationTimingFunction: 'ease-in-out',
              },
            ]}
          />
          <HubGlassIcon
            icon={icon}
            size={iconWell}
            iconSize={iconSize}
            palette={accent}
            style={styles.hubIconWell}
          />
          {badge ? (
            <Reanimated.View
              entering={FadeInDown.delay(260 + index * 70).duration(240)}
              style={[styles.hubBadge, { backgroundColor: accent.glow }]}
            >
              <Text style={styles.hubBadgeText} numberOfLines={1}>
                {badge}
              </Text>
            </Reanimated.View>
          ) : null}
        </View>

        <Text style={[styles.hubGlassLabel, { fontSize: labelSize }]}>{label}</Text>
        <Text style={[styles.hubGlassHint, { fontSize: hintSize }]} numberOfLines={1}>
          {hint}
        </Text>
      </Animated.View>
    </Pressable>
    </Reanimated.View>
  );
}

const isSmallScreen = width < 375;
const DASHBOARD_H_INSET = isSmallScreen ? 12 : 16;
const DASHBOARD_V_GAP = dz(8);
/** Even breathing room between dashboard sections (picker · hub · explore · top pros). */
const DASHBOARD_SECTION_GAP = isSmallScreen ? 16 : 20;
/** Pinned wash-location picker row height (36pt icon + trigger padding). */
const PINNED_PICKER_H = 44;
/** Pulls the pinned location picker up toward the header bar. */
const PINNED_PICKER_LIFT = 14;
const DASHBOARD_NEARBY_RADIUS_KM = 40; // ~25 miles
/** Top Care Pros are ranked per area: only pros/locations within this distance of the chosen location. */
const TOP_PROS_RADIUS_KM = 100;
const TOP_PROS_MAX = 10;
type AvailabilityFilter = 'all' | 'online' | 'offline';
const AVAILABILITY_OPTIONS: readonly AvailabilityFilter[] = ['all', 'online', 'offline'];
const AVAILABILITY_LABELS: Record<AvailabilityFilter, string> = {
  all: 'All',
  online: 'Online',
  offline: 'Offline',
};
const AVAILABILITY_ICONS: Record<AvailabilityFilter, keyof typeof Ionicons.glyphMap> = {
  all: 'people-outline',
  online: 'radio-button-on',
  offline: 'moon-outline',
};
const TOP_PROS_AVAILABILITY_STORAGE_KEY = 'wishawash:dashboard:topProsAvailability';
const SKY = colors.SKY;
interface NearbyValeter {
  id: string;
  name: string;
  organization: string;
  rating: number;
  distance: number | null;
  isOnline: boolean;
  latitude?: number | null;
  longitude?: number | null;
}

interface ValeterReview {
  rating: number;
  review?: string | null;
}

type TopWasherValeter = {
  kind: 'valeter';
  id: string;
  name: string;
  organization: string;
  rating: number;
  jobsCompleted: number;
  reviewCount: number;
  isOnline: boolean;
  profilePicture?: string | null;
  joinedAt?: string | null;
  reviews?: ValeterReview[];
  latitude?: number | null;
  longitude?: number | null;
};

type TopWasherHub = {
  kind: 'hub';
  id: string;
  name: string;
  organization: string;
  rating: number;
  jobsCompleted: number;
  reviewCount: number;
  isOnline: boolean;
  profilePicture?: string | null;
  latitude?: number | null;
  longitude?: number | null;
};

type TopWasher = TopWasherValeter | TopWasherHub;

interface LoyaltyData {
  points: number;
  tier: 'Bronze' | 'Silver' | 'Gold' | 'Platinum';
  pointsToNextTier: number;
  nextReward?: string;
}

type DbBookingStatus =
  | 'scheduled'
  | 'in_progress'
  | 'completed'
  | 'cancelled'
  | 'pending_payment'
  | 'pending_valeter_acceptance'
  | 'pending_business_acceptance'
  | 'pending'
  | 'confirmed'
  | 'valeter_assigned'
  | 'en_route'
  | 'arrived';

type ActiveBooking = {
  id: string;
  status: DbBookingStatus;
  service_type: string;
  service_name: string | null;
  location_address: string | null;
  location_id: string | null;
  scheduled_at: string;
  price: number;
  valeter_name: string | null;
  valeter_id: string | null;
  counterparty_photo_url: string | null;
  latitude: number | null;
  longitude: number | null;
  vehicle_id?: string | null;
  wash_type?: string | null;
};

const ACTIVE_STATUSES: DbBookingStatus[] = [
  'scheduled',
  'in_progress',
  'pending_payment',
  'pending_valeter_acceptance',
  'pending_business_acceptance',
  'pending',
  'confirmed',
  'valeter_assigned',
  'en_route',
  'arrived',
];
const ACTIVE_STATUSES_FALLBACK = ACTIVE_STATUSES.filter((s) => s !== 'pending_business_acceptance');

function formatReviewCount(count: number): string {
  if (count <= 0) return 'No reviews';
  return `${count} ${count === 1 ? 'review' : 'reviews'}`;
}

function getPicksEmptySubtitle(
  segment: 'pros' | 'locations',
  valeterCount: number,
  hubCount: number,
  availabilityFilter: AvailabilityFilter
): string {
  if (segment === 'pros') {
    if (valeterCount === 0 && hubCount > 0) return `No ${ccpPluralLower()} in this list — try the Locations tab.`;
    return getValetersEmptyMessage(availabilityFilter);
  }
  if (hubCount === 0 && valeterCount > 0) return `No wash locations in this list — try the ${CCP.pluralShort} tab.`;
  return getLocationsEmptyMessage(availabilityFilter);
}

function getValetersEmptyMessage(availabilityFilter: AvailabilityFilter): string {
  if (availabilityFilter === 'online') return `No ${ccpPluralLower()} online nearby right now`;
  if (availabilityFilter === 'offline') return `Saved ${ccpPluralLower()} who are offline show here`;
  return `No ${ccpPluralLower()} online nearby right now`;
}

function getLocationsEmptyMessage(_availabilityFilter: AvailabilityFilter): string {
  return 'No wash locations in this list';
}

export default function EnhancedCustomerDashboard() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const ownerScrollPad = useOwnerScrollContentPadding(true);
  const adaptive = useAdaptiveLayout();
  const chrome = useMapChromeColors();
  const isTabletLayout = adaptive.isTablet;
  const dashboardLayout = useMemo(
    () => getDashboardLayout(adaptive.width, adaptive.height),
    [adaptive.width, adaptive.height]
  );
  const horizontalInset = adaptive.horizontalPadding;
  const contentMaxWidth = adaptive.isTablet ? adaptive.contentMaxWidth : undefined;
  const sectionContainerStyle = isTabletLayout
    ? { width: '100%' as const, maxWidth: contentMaxWidth, alignSelf: 'center' as const }
    : undefined;
  const tabletSectionMarginReset = isTabletLayout ? { marginHorizontal: 0 } : undefined;

  const [nearbyValeters, setNearbyValeters] = useState<NearbyValeter[]>([]); // value reserved for future UI
  const [loading, setLoading] = useState(true);
  const [profileName, setProfileName] = useState<string>('');
  const [headerProfilePicture, setHeaderProfilePicture] = useState<string | null>(null);
  const [notificationCount, setNotificationCount] = useState(0);
  const [activeBooking, setActiveBooking] = useState<ActiveBooking | null>(null);
  const [activeBookingLoading, setActiveBookingLoading] = useState(false);
  const [valeterLocation, setValeterLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  /** Saved address picked in the location picker; overrides live GPS for map + distances. */
  const manualLocationRef = useRef<{ latitude: number; longitude: number } | null>(null);
  const topProsOriginRef = useRef<{ latitude: number; longitude: number } | null>(null);
  const valeterPresenceChannelRef = useRef<any>(null);

  const [topWashers, setTopWashers] = useState<TopWasher[]>([]);
  /** Same on-device saved pros as Explore. */
  const [savedPros, setSavedPros] = useState<SavedProRow[]>([]);
  const savedProIds = useMemo(() => new Set(savedPros.map((f) => f.valeter_id)), [savedPros]);
  const [availabilityFilter, setAvailabilityFilterState] = useState<AvailabilityFilter>('all');
  const setAvailabilityFilter = useCallback((next: AvailabilityFilter) => {
    setAvailabilityFilterState(next);
    void AsyncStorage.setItem(TOP_PROS_AVAILABILITY_STORAGE_KEY, next).catch(() => {});
  }, []);
  useEffect(() => {
    void AsyncStorage.getItem(TOP_PROS_AVAILABILITY_STORAGE_KEY)
      .then((raw) => {
        if (raw === 'all' || raw === 'online' || raw === 'offline') setAvailabilityFilterState(raw);
      })
      .catch(() => {});
  }, []);
  /** Split Car care pros vs fixed wash locations in the top-picks section. */
  const [washPicksSegment, setWashPicksSegment] = useState<'pros' | 'locations'>('pros');
  const [showAvailabilityPicker, setShowAvailabilityPicker] = useState(false);
  const nextAvailabilityActions = useMemo<LivelyEmptyAction[]>(() => {
    return [
      ...AVAILABILITY_OPTIONS.filter((o) => o !== availabilityFilter).map((o, i) => ({
        key: o,
        label: o === 'all' ? 'Show all' : AVAILABILITY_LABELS[o],
        icon: AVAILABILITY_ICONS[o],
        primary: i === 0,
        onPress: () => setAvailabilityFilter(o),
      })),
      { key: 'map', label: 'Open map', icon: 'map-outline', onPress: () => router.push('/owner/explore') },
    ];
  }, [availabilityFilter, setAvailabilityFilter]);
  const [valeterProfileSheet, setValeterProfileSheet] = useState<ValeterProfileSheetSeed | null>(null);
  const [hubLocationSheet, setHubLocationSheet] = useState<HubLocationSheetSeed | null>(null);
  const [failedValeterImageIds, setFailedValeterImageIds] = useState<Set<string>>(new Set());
  const [dashboardRefreshing, setDashboardRefreshing] = useState(false);

  const quickScale0 = useRef(new Animated.Value(1)).current;
  const quickScale1 = useRef(new Animated.Value(1)).current;
  const quickScale2 = useRef(new Animated.Value(1)).current;
  const [loyaltyData, setLoyaltyData] = useState<LoyaltyData | null>(null);
  const { refresh } = useLiveLocation();

  const loadLoyaltyData = useCallback(async () => {
    if (!user?.id) {
      setLoyaltyData(null);
      return;
    }
    try {
      const balance = await getLoyaltyBalance(user.id);
      const tierInfo = getTierProgress(balance.effectivePoints);
      const nextMilestone = getNextMilestone(balance.effectivePoints);
      setLoyaltyData({
        points: balance.effectivePoints,
        tier: tierInfo.tier,
        pointsToNextTier: tierInfo.pointsToNextTier || (nextMilestone ? nextMilestone.points - balance.effectivePoints : 0),
        nextReward: nextMilestone?.title ?? 'All rewards unlocked',
      });
    } catch {
      setLoyaltyData(null);
    }
  }, [user?.id]);

  const notificationStatuses = useMemo(
    () => [
      'pending',
      'pending_business_acceptance',
      'pending_valeter_acceptance',
      'pending_payment',
      'confirmed',
      'valeter_assigned',
      'en_route',
      'arrived',
      'in_progress',
      'scheduled',
      'completed',
      'cancelled',
    ],
    []
  );

  const filteredTopWashers = useMemo(() => {
    const byJobsAndRating = (a: TopWasher, b: TopWasher) =>
      b.jobsCompleted - a.jobsCompleted || b.rating - a.rating;
    // Same rule as Explore: only online pros, plus saved pros (shown locked while offline).
    const valeters = topWashers.filter(
      (w): w is TopWasherValeter =>
        w.kind === 'valeter' &&
        (w.isOnline || savedProIds.has(w.id)) &&
        (availabilityFilter === 'all' || (availabilityFilter === 'online') === w.isOnline)
    );
    const hubs = MOBILE_SERVICE_ONLY_LAUNCH
      ? []
      : topWashers.filter((w): w is TopWasherHub => w.kind === 'hub');
    return [...valeters, ...hubs].sort(byJobsAndRating);
  }, [topWashers, savedProIds, availabilityFilter]);

  const topPicksValeters = useMemo(
    () => filteredTopWashers.filter((w): w is TopWasherValeter => w.kind === 'valeter'),
    [filteredTopWashers]
  );
  const topPicksHubs = useMemo(
    () => filteredTopWashers.filter((w): w is TopWasherHub => w.kind === 'hub'),
    [filteredTopWashers]
  );
  const displayedWashPicks = MOBILE_SERVICE_ONLY_LAUNCH || washPicksSegment === 'pros' ? topPicksValeters : topPicksHubs;

  /** Live online pros within radius of the customer — drives map markers + nearby count. */
  const exploreNearbyPros = useMemo(() => {
    const withCoords = nearbyValeters.filter(
      (v): v is NearbyValeter & { latitude: number; longitude: number } =>
        typeof v.latitude === 'number' &&
        typeof v.longitude === 'number' &&
        Number.isFinite(v.latitude) &&
        Number.isFinite(v.longitude)
    );

    if (!userLocation) {
      return withCoords.map((v) => ({ ...v, distance: v.distance }));
    }

    return withCoords
      .map((v) => ({
        ...v,
        distance: distanceKm(userLocation, { latitude: v.latitude, longitude: v.longitude }),
      }))
      .filter((v) => (v.distance ?? 999) <= DASHBOARD_NEARBY_RADIUS_KM)
      .sort((a, b) => (a.distance ?? 0) - (b.distance ?? 0));
  }, [nearbyValeters, userLocation]);

  const exploreNearbyCount = exploreNearbyPros.length;
  const exploreOnlineCount = useMemo(() => exploreNearbyPros.filter((v) => v.isOnline).length, [exploreNearbyPros]);
  const explorePreviewNames = useMemo(
    () =>
      exploreNearbyPros
        .map((v) => v.name || v.organization)
        .filter((n): n is string => Boolean(n?.trim()))
        .slice(0, 4),
    [exploreNearbyPros]
  );
  const exploreMapMarkers = useMemo(() => exploreNearbyPros.slice(0, 12), [exploreNearbyPros]);

  const explorePreviewHubs = useMemo(() => {
    if (MOBILE_SERVICE_ONLY_LAUNCH) return [] as TopWasherHub[];
    return topPicksHubs
      .filter((h) => h.latitude != null && h.longitude != null)
      .slice(0, 4);
  }, [topPicksHubs]);

  const explorePreviewRegion: Region | null = useMemo(() => {
    if (userLocation) {
      return {
        latitude: userLocation.latitude,
        longitude: userLocation.longitude,
        latitudeDelta: dashboardLayout.mapZoomDelta,
        longitudeDelta: dashboardLayout.mapZoomDelta,
      };
    }
    const points: { latitude: number; longitude: number }[] = [
      ...exploreMapMarkers.map((p) => ({ latitude: p.latitude, longitude: p.longitude })),
      ...explorePreviewHubs
        .map((h) =>
          h.latitude != null && h.longitude != null
            ? { latitude: h.latitude, longitude: h.longitude }
            : null
        )
        .filter((p): p is { latitude: number; longitude: number } => p != null),
    ];
    if (points.length === 0) return null;
    return regionForCoordinates(points, 0.2);
  }, [exploreMapMarkers, explorePreviewHubs, userLocation, dashboardLayout.mapZoomDelta]);

  const showActiveJobInHub = activeBookingLoading || Boolean(activeBooking);
  const hubActiveBookingSectionStyle = { marginHorizontal: 0, marginTop: DASHBOARD_V_GAP, marginBottom: 0 };

  const topPickCardWidth = useMemo(() => {
    if (!isTabletLayout) return getTopCareProCardWidth(adaptive.width);
    const inner = Math.min(adaptive.width, adaptive.contentMaxWidth) - horizontalInset * 2;
    return Math.min(Math.floor(inner * 0.88), Math.max(300, Math.floor(inner - 40)));
  }, [isTabletLayout, adaptive.width, adaptive.contentMaxWidth, horizontalInset]);

  /** Keep Top Care Pros visible; `false` would hide the section via `styles.hiddenSection`. */
  const refreshRef = useRef(refresh);
  useEffect(() => {
    refreshRef.current = refresh;
  }, [refresh]);

  useEffect(() => {
    const interval = setInterval(() => {
      refreshRef.current?.();
    }, 60000);
    return () => clearInterval(interval);
  }, []);

  const scrollY = useRef(new Animated.Value(0)).current;
  const bgScrollY = useSharedValue(0);
  const headerScrollClearance = insets.top + DASHBOARD_HEADER_BAR_BODY;
  /** Hub + Explore + Top Care Pros fill the first screen; spare height goes to the Explore map. */
  const pinnedPickerClearance = PINNED_PICKER_H + DASHBOARD_V_GAP;
  const firstScreenMinHeight = Math.max(
    0,
    adaptive.height -
      headerScrollClearance -
      pinnedPickerClearance +
      PINNED_PICKER_LIFT -
      (ownerScrollPad.paddingBottom ?? 0) -
      dz(18)
  );
  const handleWashLocationSelect = useCallback(
    (coords: { latitude: number; longitude: number } | null) => {
      manualLocationRef.current = coords;
      if (coords) setUserLocation(coords);
      else void getCurrentLocation();
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        console.warn('Location permission not granted');
        return;
      }

      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });

      const coords = manualLocationRef.current ?? {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      };

      setUserLocation(coords);
      return coords;
    } catch (error) {
      console.warn('Error getting location:', error);
      return null;
    }
  };

  const loadValeterLocation = async (valeterId: string) => {
    try {
      const { data, error } = await supabase
        .from('valeter_presence')
        .select('last_lat, last_lng')
        .eq('user_id', valeterId)
        .maybeSingle();

      if (error) {
        console.warn('Error loading valeter location:', error);
        return;
      }

      if (data?.last_lat && data?.last_lng) {
        const valeterCoords = {
          latitude: Number(data.last_lat),
          longitude: Number(data.last_lng),
        };
        setValeterLocation(valeterCoords);
      } else {
        setValeterLocation(null);
      }
    } catch (error) {
      console.warn('Error loading valeter location:', error);
    }
  };

  const subscribeToValeterPresence = (valeterId: string) => {
    // Remove existing subscription
    if (valeterPresenceChannelRef.current) {
      supabase.removeChannel(valeterPresenceChannelRef.current);
      valeterPresenceChannelRef.current = null;
    }

    const channel = supabase
      .channel(`valeter-presence-dashboard-${valeterId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'valeter_presence',
          filter: `user_id=eq.${valeterId}`,
        },
        (payload) => {
          const updated = payload.new as any;
          if (updated?.last_lat && updated?.last_lng) {
            const valeterCoords = {
              latitude: Number(updated.last_lat),
              longitude: Number(updated.last_lng),
            };
            setValeterLocation(valeterCoords);
          }
        }
      )
      .subscribe();

    valeterPresenceChannelRef.current = channel;
  };

  const loadActiveBooking = async () => {
    if (!user?.id) return;

    try {
      setActiveBookingLoading(true);

      let { data, error } = await supabase
        .from('bookings')
        .select('id,status,service_type,service_name,location_address,location_lat,location_lng,scheduled_at,price,valeter_name,valeter_id')
        .eq('user_id', user.id)
        .in('status', ACTIVE_STATUSES as any)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error?.code === '22P02') {
        const retry = await supabase
          .from('bookings')
          .select('id,status,service_type,service_name,location_address,location_lat,location_lng,scheduled_at,price,valeter_name,valeter_id')
          .eq('user_id', user.id)
          .in('status', ACTIVE_STATUSES_FALLBACK as any)
          .order('created_at', { ascending: false })
          .limit(1)
          .maybeSingle();
        data = retry.data;
        error = retry.error;
      }

      if (error) {
        console.warn('[CustomerDashboard] loadActiveBooking error:', error);
        setActiveBooking(null);
        return;
      }

      if (!data) {
        setActiveBooking(null);
        setValeterLocation(null);
        return;
      }

      if (data.status === 'scheduled' || data.status === 'confirmed') {
        const startAt = data.scheduled_at ? new Date(data.scheduled_at).getTime() : Number.NaN;
        const withinLeadWindow = Number.isFinite(startAt) && startAt - Date.now() <= 60 * 60 * 1000;
        const manuallyStarted = await isBookingManuallyStarted(data.id);
        if (!withinLeadWindow && !manuallyStarted) {
          setActiveBooking(null);
          setValeterLocation(null);
          return;
        }
      }

      const lat = data.location_lat == null ? null : Number(data.location_lat);
      const lng = data.location_lng == null ? null : Number(data.location_lng);

      let resolvedValeterName = data.valeter_name ?? null;
      if (data.valeter_id) {
        const identity = await fetchValeterIdentity(data.valeter_id);
        if (identity.name && identity.name !== ccpFallbackName()) {
          resolvedValeterName = identity.name;
        } else {
          resolvedValeterName = resolveValeterDisplayName(null, null, data.valeter_name);
        }
      }

      setActiveBooking({
        id: data.id,
        status: data.status as DbBookingStatus,
        service_type: data.service_type,
        service_name: data.service_name ?? null,
        location_address: data.location_address ?? null,
        location_id: null,
        scheduled_at: data.scheduled_at,
        price: Number(data.price ?? 0),
        valeter_name: resolvedValeterName,
        valeter_id: data.valeter_id ?? null,
        counterparty_photo_url: null,
        latitude: lat,
        longitude: lng,
      });

      if (data.valeter_id) {
        loadValeterLocation(data.valeter_id);
        subscribeToValeterPresence(data.valeter_id);
      } else {
        setValeterLocation(null);
      }
    } catch (e) {
      console.warn('[CustomerDashboard] loadActiveBooking exception:', e);
      setActiveBooking(null);
    } finally {
      setActiveBookingLoading(false);
    }
  };

  useEffect(() => {
    if (!user?.id) return;

    getCurrentLocation();
    loadActiveBooking();

    const channel = supabase
      .channel(`customer-active-booking-${user.id}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'bookings', filter: `user_id=eq.${user.id}` },
        () => {
          loadActiveBooking();
        }
      )
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'bookings', filter: `user_id=eq.${user.id}` },
        (payload) => {
          const updated = payload.new as any;

          if (activeBooking?.id && updated?.id === activeBooking.id) {
            const newStatus = updated.status as DbBookingStatus;
            const terminalStatuses = ['completed', 'cancelled', 'valeter_declined', 'valeter_timeout'];

            if (terminalStatuses.includes(newStatus)) {
              setActiveBooking(null);
            } else {
              setActiveBooking((prev) =>
                prev
                  ? {
                      ...prev,
                      status: newStatus,
                      valeter_name: updated.valeter_name ?? prev.valeter_name,
                      price: Number(updated.price ?? prev.price),
                      service_name: updated.service_name ?? prev.service_name,
                      location_address: updated.location_address ?? prev.location_address,
                    }
                  : prev
              );
            }
            return;
          }

          loadActiveBooking();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
      if (valeterPresenceChannelRef.current) {
        supabase.removeChannel(valeterPresenceChannelRef.current);
        valeterPresenceChannelRef.current = null;
      }
    };
  }, [user?.id, activeBooking?.id]);

  const refreshNotificationCountRef = useRef<(() => Promise<void>) | null>(null);
  useEffect(() => {
    if (!user?.id) return;
    let isMounted = true;
    const DISMISSED_STORAGE_KEY = 'wishawash:dismissed-notifications-v1';

    const fetchVehicleReminders = async (
      userId: string
    ): Promise<Array<{ id: string; type: 'vehicle_reminder' }>> => {
      try {
        const { data: vehicles, error } = await supabase
          .from('customer_vehicles')
          .select('id,make,model,registration,tax_due_date,mot_expiry_date')
          .eq('user_id', userId);

        if (error || !vehicles) return [];

        const reminders: Array<{ id: string; type: 'vehicle_reminder' }> = [];
        const now = new Date();
        const thirtyDaysFromNow = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

        vehicles.forEach((vehicle) => {
          if (vehicle.tax_due_date) {
            const taxExpiry = new Date(vehicle.tax_due_date);
            if (taxExpiry <= thirtyDaysFromNow) {
              reminders.push({ id: `tax-reminder-${vehicle.id}`, type: 'vehicle_reminder' });
            }
          }
          if (vehicle.mot_expiry_date) {
            const motExpiry = new Date(vehicle.mot_expiry_date);
            if (motExpiry <= thirtyDaysFromNow) {
              reminders.push({ id: `mot-reminder-${vehicle.id}`, type: 'vehicle_reminder' });
            }
          }
        });

        return reminders;
      } catch (error) {
        console.warn('[CustomerDashboard] Vehicle reminders error', error);
        return [];
      }
    };

    const fetchRewardNotifications = async (userId: string): Promise<Array<{ id: string; type: 'reward' }>> => {
      try {
        const { data: userData, error } = await supabase
          .from('users')
          .select('tier_points,tier')
          .eq('id', userId)
          .single();

        if (error || !userData) return [];

        const notifications: Array<{ id: string; type: 'reward' }> = [];
        const points = userData.tier_points || 0;
        const milestones = [500, 1000, 2000, 3000, 5000];
        const nextMilestone = milestones.find((m) => m > points);

        if (nextMilestone && points > 0) {
          const pointsNeeded = nextMilestone - points;
          if (pointsNeeded <= 100) {
            notifications.push({ id: `reward-milestone-${nextMilestone}`, type: 'reward' });
          }
        }

        return notifications;
      } catch (error) {
        console.warn('[CustomerDashboard] Reward notifications error', error);
        return [];
      }
    };

    const fetchNotificationCount = async () => {
      try {
        const [bookingsResult, chatThreads, vehicleReminders, rewardNotifications] = await Promise.all([
          supabase
            .from('bookings')
            .select(
              'id,status,service_name,service_type,price,created_at,updated_at,scheduled_at,time_slot,location_address,address,valeter_name'
            )
            .eq('user_id', user.id)
            .in('status', notificationStatuses as any)
            .order('created_at', { ascending: false })
            .limit(100),
          fetchUnreadBookingChatThreads(user.id),
          fetchVehicleReminders(user.id),
          fetchRewardNotifications(user.id),
        ]);

        if (!isMounted) return;

        const bookingNotifications: Array<{ id: string; type: 'booking' }> = [];
        if (!bookingsResult.error && bookingsResult.data) {
          bookingNotifications.push(
            ...bookingsResult.data.map((b) => ({
              id: `booking-${b.id}`,
              type: 'booking' as const,
            }))
          );
        }

        const chatNotifications = chatThreads.map((thread) => ({
          id: `chat-${thread.bookingId}`,
          type: 'chat' as const,
        }));
        const allNotifications = [...bookingNotifications, ...chatNotifications, ...vehicleReminders, ...rewardNotifications];

        try {
          const raw = await AsyncStorage.getItem(DISMISSED_STORAGE_KEY);
          const dismissedStore = raw ? JSON.parse(raw) : {};
          const dismissedIds = new Set(dismissedStore[user.id] || []);
          const visibleNotifications = allNotifications.filter((notif) => !dismissedIds.has(notif.id));
          setNotificationCount(visibleNotifications.length);
        } catch (storageError) {
          console.warn('[CustomerDashboard] Storage read error:', storageError);
          setNotificationCount(allNotifications.length);
        }
      } catch (error) {
        if (isMounted) {
          console.warn('[CustomerDashboard] Notification count exception:', error);
          setNotificationCount(0);
        }
      }
    };

    refreshNotificationCountRef.current = fetchNotificationCount;
    fetchNotificationCount();
    const interval = setInterval(fetchNotificationCount, 45000);
    const channel = supabase
      .channel(`customer-notification-count-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'bookings',
          filter: `user_id=eq.${user.id}`,
        },
        () => {
          fetchNotificationCount();
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'customer_vehicles',
          filter: `user_id=eq.${user.id}`,
        },
        () => {
          fetchNotificationCount();
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'booking_messages',
        },
        () => {
          fetchNotificationCount();
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'users',
          filter: `id=eq.${user.id}`,
        },
        () => {
          fetchNotificationCount();
        }
      )
      .subscribe();
    const appStateSub = AppState.addEventListener('change', (state) => {
      if (state === 'active') fetchNotificationCount();
    });
    return () => {
      isMounted = false;
      refreshNotificationCountRef.current = null;
      clearInterval(interval);
      appStateSub.remove();
      supabase.removeChannel(channel);
    };
  }, [user?.id, notificationStatuses]);

  useFocusEffect(
    useCallback(() => {
      void refreshNotificationCountRef.current?.();
    }, [])
  );

  // Load profile name
  useEffect(() => {
    if (!user?.id) return;
    const loadProfile = async () => {
      const { data: profileData } = await supabase
        .from('profiles')
        .select('full_name, profile_picture')
        .eq('id', user.id)
        .maybeSingle();

      if (profileData) {
        setProfileName(profileData.full_name || user.name || 'Customer');
        const pic = (profileData as { profile_picture?: string | null }).profile_picture;
        setHeaderProfilePicture(pic && typeof pic === 'string' ? pic : null);
      } else {
        setProfileName(user.name || 'Customer');
        setHeaderProfilePicture(null);
      }
    };
    loadProfile();
  }, [user?.id]);

  const loadNearbyValeters = async () => {
    if (!user?.id) return;
    try {
      const { data: presence, error: presErr } = await supabase
        .from('valeter_presence')
        .select('user_id, is_online, last_lat, last_lng')
        .eq('is_online', true);

      if (presErr) console.warn('[NearbyValeters] presence error:', presErr);
      if (!presence || presence.length === 0) {
        setNearbyValeters([]);
        return;
      }

      const ids = presence.map((p) => p.user_id);
      const [identityMap, vpOrgRes] = await Promise.all([
        fetchValeterIdentitiesByIds(ids),
        supabase.from('valeter_profiles').select('user_id, company_name').in('user_id', ids),
      ]);
      const orgById = new Map<string, string>();
      for (const row of vpOrgRes.data || []) {
        const r = row as { user_id: string; company_name?: string | null };
        if (r.company_name) orgById.set(r.user_id, r.company_name);
      }

      const list: NearbyValeter[] = (presence || []).map((p) => {
        const identity = identityMap.get(p.user_id);
        return {
          id: p.user_id,
          name: identity?.name || ccpFallbackName(),
          organization: orgById.get(p.user_id) || 'Independent',
          rating: 4.5,
          distance: null,
          isOnline: p.is_online,
          latitude: p.last_lat == null ? null : Number(p.last_lat),
          longitude: p.last_lng == null ? null : Number(p.last_lng),
        };
      });

      setNearbyValeters(list);
    } catch (e) {
      console.error('[NearbyValeters] load error:', e);
      setNearbyValeters([]);
    }
  };

  const loadTopWashers = async () => {
    const origin = topProsOriginRef.current;
    if (!origin) return;
    const inArea = (lat: number | null | undefined, lng: number | null | undefined) =>
      lat != null &&
      lng != null &&
      Number.isFinite(Number(lat)) &&
      Number.isFinite(Number(lng)) &&
      distanceKm(origin, { latitude: Number(lat), longitude: Number(lng) }) <= TOP_PROS_RADIUS_KM;
    /** Only real pro accounts — bookings / presence can reference customer or test accounts. */
    const filterToProIds = async (ids: string[]): Promise<Set<string>> => {
      if (ids.length === 0) return new Set();
      const [typeRes, vpRes] = await Promise.all([
        supabase.from('profiles').select('id, user_type').in('id', ids),
        supabase.from('valeter_profiles').select('user_id').in('user_id', ids),
      ]);
      const typeById = new Map(
        ((typeRes.data || []) as { id: string; user_type?: string | null }[]).map((r) => [r.id, r.user_type ?? null])
      );
      const hasValeterProfile = new Set(((vpRes.data || []) as { user_id: string }[]).map((r) => r.user_id));
      return new Set(
        ids.filter((id) => {
          const type = typeById.get(id);
          if (type) return type === 'valeter';
          return hasValeterProfile.has(id);
        })
      );
    };
    try {
      const { data: completedRows, error: completedError } = await supabase
        .from('bookings')
        .select('valeter_id, location_id, rating, location_lat, location_lng')
        .eq('status', 'completed');
      if (completedError) throw completedError;

      type ValeterAgg = { jobs: number; ratingSum: number; ratingCount: number; latSum: number; lngSum: number; coordCount: number };
      const valeterAgg = new Map<string, ValeterAgg>();
      const hubJobCounts = new Map<string, number>();
      const hubRatingCounts = new Map<string, number>();
      for (const row of completedRows || []) {
        const vid = (row as { valeter_id?: string | null }).valeter_id;
        const lid = (row as { location_id?: string | null }).location_id;
        const ratingRaw = (row as { rating?: number | null }).rating;
        const rv = ratingRaw != null && Number.isFinite(Number(ratingRaw)) ? Number(ratingRaw) : null;
        const bLat = Number((row as { location_lat?: number | null }).location_lat);
        const bLng = Number((row as { location_lng?: number | null }).location_lng);
        if (vid) {
          const cur = valeterAgg.get(vid) ?? { jobs: 0, ratingSum: 0, ratingCount: 0, latSum: 0, lngSum: 0, coordCount: 0 };
          cur.jobs += 1;
          if (Number.isFinite(bLat) && Number.isFinite(bLng) && (bLat !== 0 || bLng !== 0)) {
            cur.latSum += bLat;
            cur.lngSum += bLng;
            cur.coordCount += 1;
          }
          if (rv != null) {
            cur.ratingSum += rv;
            cur.ratingCount += 1;
          }
          valeterAgg.set(vid, cur);
        }
        if (lid) {
          hubJobCounts.set(lid, (hubJobCounts.get(lid) || 0) + 1);
          if (rv != null) {
            hubRatingCounts.set(lid, (hubRatingCounts.get(lid) || 0) + 1);
          }
        }
      }

      const valeterAvgFromAgg = (a: ValeterAgg) => (a.ratingCount > 0 ? a.ratingSum / a.ratingCount : 0);

      type Cand =
        | { kind: 'valeter'; id: string; jobs: number; completionAvgRating: number; reviewCount: number }
        | { kind: 'hub'; id: string; jobs: number; reviewCount: number };
      let cands: Cand[] = [
        ...Array.from(valeterAgg.entries()).map(([id, agg]) => ({
          kind: 'valeter' as const,
          id,
          jobs: agg.jobs,
          completionAvgRating: valeterAvgFromAgg(agg),
          reviewCount: agg.ratingCount,
        })),
        ...Array.from(hubJobCounts.entries()).map(([id, jobs]) => ({
          kind: 'hub' as const,
          id,
          jobs,
          reviewCount: hubRatingCounts.get(id) || 0,
        })),
      ]
        .filter((c) => c.jobs > 0);

      const proIds = await filterToProIds(cands.filter((c) => c.kind === 'valeter').map((c) => c.id));
      cands = cands.filter((c) => c.kind === 'hub' || proIds.has(c.id));

      // Place each candidate: pros by last known position, else where they've worked; hubs by site.
      const aggValeterIds = cands.filter((c) => c.kind === 'valeter').map((c) => c.id);
      const aggHubIds = cands.filter((c) => c.kind === 'hub').map((c) => c.id);
      const [aggPresenceRes, aggHubRes] = await Promise.all([
        aggValeterIds.length
          ? supabase.from('valeter_presence').select('user_id, last_lat, last_lng').in('user_id', aggValeterIds)
          : Promise.resolve({ data: [] as { user_id: string; last_lat?: number | null; last_lng?: number | null }[] }),
        aggHubIds.length
          ? supabase.from('car_wash_locations').select('id, latitude, longitude').in('id', aggHubIds)
          : Promise.resolve({ data: [] as { id: string; latitude?: number | null; longitude?: number | null }[] }),
      ]);
      const presenceById = new Map((aggPresenceRes.data || []).map((p) => [p.user_id, p]));
      const hubById = new Map((aggHubRes.data || []).map((h) => [h.id, h]));

      cands = cands
        .filter((c) => {
          if (c.kind === 'hub') {
            const h = hubById.get(c.id);
            return inArea(h?.latitude, h?.longitude);
          }
          const p = presenceById.get(c.id);
          if (inArea(p?.last_lat, p?.last_lng)) return true;
          const agg = valeterAgg.get(c.id);
          return agg != null && agg.coordCount > 0 && inArea(agg.latSum / agg.coordCount, agg.lngSum / agg.coordCount);
        })
        .sort((a, b) => {
          if (b.jobs !== a.jobs) return b.jobs - a.jobs;
          const ar = a.kind === 'valeter' ? a.completionAvgRating : 0;
          const br = b.kind === 'valeter' ? b.completionAvgRating : 0;
          return br - ar;
        })
        .slice(0, TOP_PROS_MAX);

      if (cands.length === 0) {
        const [{ data: presenceRows }, { data: hubRows }] = await Promise.all([
          supabase
            .from('valeter_presence')
            .select('user_id, last_lat, last_lng')
            .not('last_lat', 'is', null)
            .not('last_lng', 'is', null)
            .limit(500),
          supabase
            .from('car_wash_locations')
            .select('id, latitude, longitude')
            .not('latitude', 'is', null)
            .not('longitude', 'is', null)
            .limit(500),
        ]);
        const inAreaPresence = ((presenceRows || []) as { user_id: string; last_lat: number; last_lng: number }[]).filter(
          (p) => inArea(p.last_lat, p.last_lng)
        );
        const fallbackProIds = await filterToProIds(inAreaPresence.map((p) => p.user_id));
        const vFallback = inAreaPresence
          .filter((p) => fallbackProIds.has(p.user_id))
          .map((p) => ({
            kind: 'valeter' as const,
            id: p.user_id,
            jobs: 0,
            completionAvgRating: 0,
            reviewCount: 0,
          }));
        const hFallback = ((hubRows || []) as { id: string; latitude: number; longitude: number }[])
          .filter((h) => inArea(h.latitude, h.longitude))
          .map((h) => ({
            kind: 'hub' as const,
            id: h.id,
            jobs: 0,
            reviewCount: 0,
          }));
        cands = [...vFallback, ...hFallback].slice(0, 8);
      }

      if (cands.length === 0) {
        setTopWashers([]);
        return;
      }

      const valeterIds = cands.filter((c): c is Extract<Cand, { kind: 'valeter' }> => c.kind === 'valeter').map((c) => c.id);
      const hubIds = cands.filter((c): c is Extract<Cand, { kind: 'hub' }> => c.kind === 'hub').map((c) => c.id);

      const [presenceRes, profilesRes, fallbackProfilesRes, statsBatch, hubLocRes] = await Promise.all([
        valeterIds.length
          ? supabase.from('valeter_presence').select('user_id, is_online, last_lat, last_lng').in('user_id', valeterIds)
          : Promise.resolve({ data: [] as { user_id: string; is_online: boolean; last_lat?: number | null; last_lng?: number | null }[] }),
        valeterIds.length
          ? supabase
              .from('valeter_profiles')
              .select('user_id, full_name, company_name, profile_photo_url, created_at')
              .in('user_id', valeterIds)
          : Promise.resolve({ data: [] as Record<string, unknown>[] }),
        valeterIds.length
          ? supabase
              .from('profiles')
              .select('id, full_name, profile_picture, created_at')
              .in('id', valeterIds)
          : Promise.resolve({
              data: [] as {
                id: string;
                full_name?: string | null;
                profile_picture?: string | null;
                created_at?: string | null;
              }[],
            }),
        valeterIds.length ? ValeterStatsService.getValeterStatsBatch(valeterIds) : Promise.resolve(new Map()),
        hubIds.length
          ? supabase.from('car_wash_locations').select('id,name,rating,total_reviews,latitude,longitude').in('id', hubIds)
          : Promise.resolve({ data: [] as { id: string; name?: string; rating?: number; total_reviews?: number | null; latitude?: number | null; longitude?: number | null }[] }),
      ]);

      const presence = presenceRes.data;
      const profiles = profilesRes.data;
      const fallbackProfiles = fallbackProfilesRes.data || [];
      const hubLocations = hubLocRes.data || [];

      const list = await Promise.all(
        cands.map(async (cand): Promise<TopWasher> => {
          if (cand.kind === 'hub') {
            const loc = hubLocations.find((h) => h.id === cand.id);
            const name = String(loc?.name || 'Car wash');
            const rating = Number(loc?.rating) || 0;
            const reviewCount =
              loc?.total_reviews != null && Number(loc.total_reviews) > 0
                ? Number(loc.total_reviews)
                : cand.reviewCount;
            const base: TopWasherHub = {
              kind: 'hub',
              id: cand.id,
              name,
              organization: 'Car wash venue',
              rating,
              jobsCompleted: cand.jobs,
              reviewCount,
              isOnline: false,
              latitude: loc?.latitude == null ? null : Number(loc.latitude),
              longitude: loc?.longitude == null ? null : Number(loc.longitude),
            };
            return base;
          }

          const r = cand;
          const p = presence?.find((x) => x.user_id === r.id);
          const pr = profiles?.find((x) => (x as { user_id: string }).user_id === r.id) as
            | {
                user_id: string;
                full_name?: string | null;
                company_name?: string | null;
                profile_photo_url?: string | null;
                created_at?: string | null;
              }
            | undefined;
          const stats = statsBatch.get(r.id);
          const fallbackProfile = fallbackProfiles.find((fp) => fp.id === r.id);
          const name: string = String(pr?.full_name || fallbackProfile?.full_name || ccpFallbackName());
          let profilePicture: string | null = pr?.profile_photo_url ?? null;
          let joinedAt: string | null = pr?.created_at ?? null;
          if (!profilePicture && fallbackProfile?.profile_picture) {
            profilePicture = fallbackProfile.profile_picture;
          }
          if (!joinedAt && fallbackProfile?.created_at) {
            joinedAt = fallbackProfile.created_at;
          }
          const { data: reviewRows } = await supabase
            .from('bookings')
            .select('rating, review')
            .eq('valeter_id', r.id)
            .eq('status', 'completed')
            .not('rating', 'is', null)
            .order('completed_at', { ascending: false })
            .limit(5);
          const reviews: ValeterReview[] = (reviewRows || []).map((row: any) => ({
            rating: Number(row.rating) || 0,
            review: row.review ?? null,
          }));
          let displayRating = 0;
          if (reviews.length > 0) {
            displayRating = reviews.reduce((s, x) => s + x.rating, 0) / reviews.length;
          } else if (stats != null && stats.averageRating > 0) {
            displayRating = stats.averageRating;
          }
          const base: TopWasherValeter = {
            kind: 'valeter',
            id: r.id,
            name,
            organization: String(pr?.company_name || 'Independent'),
            rating: displayRating,
            jobsCompleted: r.jobs,
            reviewCount: stats?.customerReviews ?? r.reviewCount ?? reviews.length,
            isOnline: !!p?.is_online,
            latitude: p?.last_lat == null ? null : Number(p.last_lat),
            longitude: p?.last_lng == null ? null : Number(p.last_lng),
          };
          if (profilePicture) base.profilePicture = profilePicture;
          if (joinedAt) base.joinedAt = joinedAt;
          if (reviews.length > 0) base.reviews = reviews;
          return base;
        })
      );

      if (topProsOriginRef.current !== origin) return;
      setTopWashers(list);
    } catch (e) {
      console.error('[TopWashers] load error:', e);
      setTopWashers([]);
    }
  };

  useEffect(() => {
    if (!userLocation) return;
    const prev = topProsOriginRef.current;
    if (prev && distanceKm(prev, userLocation) < 1) return;
    topProsOriginRef.current = userLocation;
    setTopWashers([]);
    void loadTopWashers();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userLocation]);

  useEffect(() => {
    loadNearbyValeters();
    loadTopWashers();
    const interval = setInterval(() => {
      loadNearbyValeters();
      loadTopWashers();
    }, 30000);
    return () => clearInterval(interval);
  }, [user?.id]);

  useFocusEffect(
    useCallback(() => {
      if (user?.id) {
        void loadLoyaltyData();
      }
    }, [user?.id, loadLoyaltyData])
  );

  useFocusEffect(
    useCallback(() => {
      if (!user?.id) {
        setSavedPros([]);
        return;
      }
      let cancelled = false;
      void readSavedPros(user.id).then((rows) => {
        if (!cancelled) setSavedPros(rows);
      });
      return () => {
        cancelled = true;
      };
    }, [user?.id])
  );

  const toggleSavedPro = useCallback(
    (pro: { id: string; name?: string | null; profilePicture?: string | null; rating?: number; totalJobs?: number }) => {
      if (!user?.id) return;
      void hapticFeedback('light');
      setSavedPros((prev) => {
        const next = toggleSavedProRow(prev, pro);
        writeSavedPros(user.id, next);
        return next;
      });
      setValeterProfileSheet((prev) =>
        prev?.id === pro.id ? { ...prev, isFavourite: !savedProIds.has(pro.id) } : prev
      );
    },
    [user?.id, savedProIds]
  );

  useFocusEffect(
    useCallback(() => {
      let cancelled = false;
      void (async () => {
        if (!user?.id) return;
        const pendingId = await getPendingRatingBookingId();
        if (!pendingId || cancelled) return;
        const { data, error } = await supabase
          .from('bookings')
          .select('id,status,rating,user_id')
          .eq('id', pendingId)
          .maybeSingle();
        if (cancelled || error || !data) return;
        if (data.user_id !== user.id) {
          await clearPendingRatingBookingId();
          return;
        }
        if (data.status !== 'completed') {
          await clearPendingRatingBookingId();
          return;
        }
        const r = data.rating;
        if (r != null && Number(r) >= 1 && Number(r) <= 5) {
          await clearPendingRatingBookingId();
          return;
        }
        await clearPendingRatingBookingId();
        router.replace({
          pathname: '/owner/booking/completion',
          params: { bookingId: pendingId, celebrated: '1' },
        } as any);
      })();
      return () => {
        cancelled = true;
      };
    }, [user?.id])
  );

  useEffect(() => {
    if (user?.id) {
      const timer = setTimeout(() => setLoading(false), 500);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, [user?.id]);

  const handleNotificationPress = () => {
    router.push('/owner/features/notifications');
  };

  const handleResumeTracking = () => {
    if (!activeBooking?.id) return;
    router.push({
      pathname: '/owner/track',
      params: { bookingId: activeBooking.id },
    } as any);
  };

  const handleAttemptNewBooking = (route: string, params?: Record<string, string>) => {
    if (!activeBooking?.id) {
      if (params != null && Object.keys(params).length > 0) {
        router.push({ pathname: route, params } as any);
      } else {
        router.push(route as any);
      }
      return;
    }

    handleResumeTracking();
  };

  const onDashboardRefresh = async () => {
    if (!user?.id) return;
    setDashboardRefreshing(true);
    try {
      await getCurrentLocation();
      await Promise.all([
        loadActiveBooking(),
        loadTopWashers(),
        loadNearbyValeters(),
        loadLoyaltyData(),
      ]);
    } finally {
      setDashboardRefreshing(false);
    }
  };

  const activeBookingMapRegion: Region | null = useMemo(() => {
    if (!userLocation) return null;
    const points: { latitude: number; longitude: number }[] = [userLocation];
    if (valeterLocation) points.push(valeterLocation);
    if (activeBooking?.latitude != null && activeBooking?.longitude != null) {
      points.push({ latitude: activeBooking.latitude, longitude: activeBooking.longitude });
    }
    const lats = points.map((p) => p.latitude);
    const lngs = points.map((p) => p.longitude);
    const minLat = Math.min(...lats);
    const maxLat = Math.max(...lats);
    const minLng = Math.min(...lngs);
    const maxLng = Math.max(...lngs);
    const pad = 0.006;
    return {
      latitude: (minLat + maxLat) / 2,
      longitude: (minLng + maxLng) / 2,
      latitudeDelta: Math.max(0.012, (maxLat - minLat) * 1.6 + pad * 2),
      longitudeDelta: Math.max(0.012, (maxLng - minLng) * 1.6 + pad * 2),
    };
  }, [userLocation, valeterLocation, activeBooking?.latitude, activeBooking?.longitude]);

  const themeOptional = useThemeOptional();
  const colorScheme = themeOptional?.colorScheme ?? 'light';
  const showSubtleWaveTint =
    SUBTLE_WAVE_DASHBOARD_TINT_ENABLED && colorScheme === 'light';

  return (
    <SafeAreaView style={styles.container}>
      {showSubtleWaveTint ? (
        <LinearGradient
          colors={[...subtleWaveDashboardTint.colors]}
          locations={[...subtleWaveDashboardTint.locations]}
          start={subtleWaveDashboardTint.start}
          end={subtleWaveDashboardTint.end}
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
        />
      ) : null}
      <StatusBar barStyle="light-content" backgroundColor="transparent" />
      <BubbleBackground accountType="customer" scrollY={bgScrollY} />

      <DashboardHeaderBar
        name={formatDisplayName(profileName || user?.name || 'Customer')}
        photoUrl={headerProfilePicture || null}
        {...(loyaltyData?.points === undefined ? {} : { points: loyaltyData.points })}
        notificationCount={notificationCount}
        onProfilePress={() => {
          hapticFeedback('light');
          router.push('/owner/owner-profile' as any);
        }}
        onPointsPress={() => {
          void hapticFeedback('light');
          router.push('/owner/features/rewards');
        }}
        onNotificationsPress={handleNotificationPress}
      />

      <View style={styles.scrollView}>
      <Animated.ScrollView
        style={[styles.scrollView, { marginTop: headerScrollClearance + pinnedPickerClearance - PINNED_PICKER_LIFT }]}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], {
          useNativeDriver: false,
          listener: (e: NativeSyntheticEvent<NativeScrollEvent>) => {
            bgScrollY.value = e.nativeEvent.contentOffset.y;
          },
        })}
        scrollEventThrottle={16}
        contentContainerStyle={{
          paddingBottom: ownerScrollPad.paddingBottom + dz(4),
        }}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={dashboardRefreshing} onRefresh={onDashboardRefresh} tintColor={SKY} colors={[SKY]} />
        }
      >
        {loading ? (
          <View style={[styles.bookingButtonsSection, sectionContainerStyle, tabletSectionMarginReset]}>
            <View style={{ marginHorizontal: horizontalInset, marginTop: 16 }}>
              <SkeletonList count={4} />
            </View>
          </View>
        ) : (
          <View style={{ flex: 1 }}>
            <View style={[styles.firstScreen, { minHeight: firstScreenMinHeight }]}>
            <StaggerIn index={0}>
            <View style={[styles.bookingButtonsSection, sectionContainerStyle, tabletSectionMarginReset]}>
              <View style={styles.yourHubSection}>
                <View style={styles.yourHubHeader}>
                  <View style={styles.topWashersHeaderMain}>
                    <Text
                      style={[styles.topPickTrackKicker, styles.sectionKicker]}
                      numberOfLines={1}
                      maxFontSizeMultiplier={1}
                    >
                      QUICK ACCESS
                    </Text>
                  </View>
                </View>
                <View style={styles.quickActionsRow}>
                  <HubGlassActionTile
                    index={0}
                    icon="car-sport"
                    label="Vehicles"
                    hint="Garages & docs"
                    accent={HUB_GLASS_ACCENTS.vehicles}
                    scaleAnim={quickScale0}
                    large={isTabletLayout}
                    scale={dashboardLayout.hubScale}
                    onPress={() => {
                      router.push('/owner/settings/vehicle-management');
                    }}
                  />
                  <HubGlassActionTile
                    index={1}
                    icon="trophy"
                    label="Rewards"
                    hint={loyaltyData ? `${loyaltyData.tier} tier` : 'Points & perks'}
                    badge={loyaltyData && loyaltyData.points > 0 ? formatHubPoints(loyaltyData.points) : null}
                    accent={HUB_GLASS_ACCENTS.rewards}
                    scaleAnim={quickScale1}
                    large={isTabletLayout}
                    scale={dashboardLayout.hubScale}
                    onPress={() => {
                      router.push('/owner/features/rewards');
                    }}
                  />
                  <HubGlassActionTile
                    index={2}
                    icon="gift"
                    label="Referrals"
                    hint="Invite & earn"
                    accent={HUB_GLASS_ACCENTS.referrals}
                    scaleAnim={quickScale2}
                    large={isTabletLayout}
                    scale={dashboardLayout.hubScale}
                    onPress={() => {
                      router.push('/owner/features/referral-system');
                    }}
                  />
                </View>
                <Pressable
                  onPress={() => {
                    void hapticFeedback('light');
                    router.push({ pathname: '/owner/booking/tracking', params: { bookingId: 'preview', preview: '1' } } as any);
                  }}
                  style={({ pressed }) => [styles.trackPreviewBtn, pressed && styles.trackPreviewBtnPressed]}
                  accessibilityRole="button"
                  accessibilityLabel="Preview the tracking journey"
                >
                  <View style={styles.trackPreviewIcon}>
                    <Ionicons name="navigate" size={14} color="#04121F" />
                  </View>
                  <View style={styles.trackPreviewCopy}>
                    <Text style={styles.trackPreviewTitle}>Preview tracking journey</Text>
                    <Text style={styles.trackPreviewHint}>See every stage, from booking to done</Text>
                  </View>
                  <Ionicons name="chevron-forward" size={16} color="rgba(224,242,254,0.6)" />
                </Pressable>
              </View>

              {showActiveJobInHub ? (
                <LiveJobCard
                  loading={activeBookingLoading}
                  booking={activeBooking}
                  mapRegion={activeBookingMapRegion}
                  userLocation={userLocation}
                  valeterLocation={valeterLocation}
                  onResumeTracking={handleResumeTracking}
                  style={hubActiveBookingSectionStyle}
                />
              ) : null}
            </View>
            </StaggerIn>

            <View style={[styles.exploreGap, sectionContainerStyle, tabletSectionMarginReset]}>
              {!showActiveJobInHub ? (
                <View style={styles.exploreCardSlot}>
                <ExploreMapButton
                  region={explorePreviewRegion}
                  userLocation={userLocation}
                  proPins={exploreMapMarkers}
                  nearbyCount={exploreNearbyCount}
                  onlineCount={exploreOnlineCount}
                  radiusKm={DASHBOARD_NEARBY_RADIUS_KM}
                  previewNames={explorePreviewNames}
                  proLabelSingular={ccpSingularLower()}
                  proLabelPlural={ccpPluralLower()}
                  scale={dashboardLayout.hubScale}
                  onPress={() => router.push('/owner/explore')}
                />
                </View>
              ) : null}
            </View>

        {/* Top picks — mobile pros (and locations when hub booking is enabled) */}
            <StaggerIn index={1}>
            <View
              style={[
                styles.availabilitySectionBottom,
                sectionContainerStyle,
                tabletSectionMarginReset,
              ]}
            >
              <View style={styles.topWashersHeader}>
                <View style={styles.topWashersHeaderTopRow}>
                  <View style={styles.topWashersHeaderMain}>
                    <View style={styles.topWashersTitleRow}>
                      <Text
                        style={[styles.topPickTrackKicker, styles.sectionKicker, styles.topWashersKickerInline]}
                        numberOfLines={1}
                        maxFontSizeMultiplier={1}
                      >
                        {MOBILE_SERVICE_ONLY_LAUNCH ? 'TOP CARE PROS' : 'TOP WASH PICKS'}
                      </Text>
                      <Text style={styles.topWashersCountText}>{displayedWashPicks.length}</Text>
                    </View>
                  </View>
                  <TouchableOpacity
                    style={styles.topWashersFilterBtn}
                    onPress={() => {
                      hapticFeedback('light');
                      setShowAvailabilityPicker(true);
                    }}
                    activeOpacity={0.8}
                  >
                    {availabilityFilter === 'online' ? (
                      <View style={styles.topWashersFilterDot} />
                    ) : availabilityFilter === 'offline' ? (
                      <Ionicons name="moon" size={13} color="rgba(148,163,184,0.95)" />
                    ) : null}
                    <Text style={[styles.topWashersFilterBtnText, { color: chrome.icon }]}>
                      {AVAILABILITY_LABELS[availabilityFilter]}
                    </Text>
                    <Ionicons name="chevron-down" size={16} color={chrome.icon} />
                  </TouchableOpacity>
                </View>

                {!MOBILE_SERVICE_ONLY_LAUNCH ? (
                  <View style={styles.topWashersSegmentRow}>
                      <Pressable
                        style={[
                          styles.topWashersSegmentTab,
                          washPicksSegment === 'pros'
                            ? {
                                borderColor: chrome.border,
                                backgroundColor: `${chrome.accent}1A`,
                              }
                            : styles.topWashersSegmentTabIdle,
                        ]}
                        onPress={() => {
                          hapticFeedback('light');
                          setWashPicksSegment('pros');
                        }}
                      >
                        <Ionicons
                          name={washPicksSegment === 'pros' ? 'person' : 'person-outline'}
                          size={13}
                          color={washPicksSegment === 'pros' ? chrome.icon : 'rgba(148,163,184,0.55)'}
                        />
                        <Text
                          style={[
                            styles.topWashersSegmentLabel,
                            washPicksSegment === 'pros' && { color: chrome.icon },
                          ]}
                          numberOfLines={1}
                        >
                          {CCP.pluralShort}
                        </Text>
                        {topPicksValeters.length > 0 ? (
                          <View style={styles.topWashersSegmentCount}>
                            <Text
                              style={[
                                styles.topWashersSegmentCountText,
                                washPicksSegment === 'pros' && { color: chrome.icon },
                              ]}
                            >
                              {topPicksValeters.length}
                            </Text>
                          </View>
                        ) : null}
                      </Pressable>
                      <Pressable
                        style={[
                          styles.topWashersSegmentTab,
                          washPicksSegment === 'locations'
                            ? {
                                borderColor: 'rgba(125,211,252,0.45)',
                                backgroundColor: `${SKY}1A`,
                              }
                            : styles.topWashersSegmentTabIdle,
                        ]}
                        onPress={() => {
                          hapticFeedback('light');
                          setWashPicksSegment('locations');
                        }}
                      >
                        <Ionicons
                          name={washPicksSegment === 'locations' ? 'business' : 'business-outline'}
                          size={13}
                          color={washPicksSegment === 'locations' ? '#E0F2FE' : 'rgba(148,163,184,0.55)'}
                        />
                        <Text
                          style={[
                            styles.topWashersSegmentLabel,
                            washPicksSegment === 'locations' && { color: '#E0F2FE' },
                          ]}
                          numberOfLines={1}
                        >
                          Locations
                        </Text>
                        {topPicksHubs.length > 0 ? (
                          <View style={styles.topWashersSegmentCount}>
                            <Text
                              style={[
                                styles.topWashersSegmentCountText,
                                washPicksSegment === 'locations' && { color: '#E0F2FE' },
                              ]}
                            >
                              {topPicksHubs.length}
                            </Text>
                          </View>
                        ) : null}
                      </Pressable>
                    </View>
                  ) : null}
              </View>

                <View style={styles.prosNearbyContainer}>
                  {filteredTopWashers.length > 0 ? (
                    displayedWashPicks.length > 0 ? (
                      (() => {
                        const imageFailKey = (w: TopWasher) => `${w.kind}:${w.id}`;
                        const openHubSheet = (w: TopWasherHub) => {
                          setHubLocationSheet({
                            id: w.id,
                            name: w.name,
                            rating: w.rating,
                            jobsCompleted: w.jobsCompleted,
                          });
                        };
                        const cards = displayedWashPicks.map((w, pickIndex) => {
                          const accent = w.kind === 'hub' ? SKY : chrome.accent;
                          const cardBorder = w.kind === 'hub' ? 'rgba(148,196,220,0.4)' : chrome.border;
                          const displayName =
                            w.kind === 'hub'
                              ? w.name || 'Car wash'
                              : formatDisplayName(w.name) || w.name || ccpFallbackName();

                          if (w.kind === 'valeter') {
                            return (
                              <TopCareProCard
                                key={`valeter-${w.id}`}
                                width={topPickCardWidth}
                                zoom={TOP_CARE_PRO_CARD_ZOOM}
                                pro={{
                                  id: w.id,
                                  name: w.name,
                                  rating: w.rating,
                                  totalJobs: w.jobsCompleted,
                                  reviewCount: w.reviewCount,
                                  isOnline: w.isOnline,
                                  profilePicture: w.profilePicture ?? null,
                                  isFavourite: savedProIds.has(w.id),
                                }}
                                rank={pickIndex + 1}
                                accent={accent}
                                borderColor={cardBorder}
                                locked={!w.isOnline}
                                {...(user?.id
                                  ? {
                                      onToggleFavourite: () =>
                                        toggleSavedPro({
                                          id: w.id,
                                          name: w.name,
                                          profilePicture: w.profilePicture ?? null,
                                          rating: w.rating,
                                          totalJobs: w.jobsCompleted,
                                        }),
                                    }
                                  : {})}
                                onPress={() => {
                                  hapticFeedback('light');
                                  setValeterProfileSheet({
                                    id: w.id,
                                    name: w.name,
                                    rating: w.rating,
                                    totalJobs: w.jobsCompleted,
                                    reviewCount: w.reviewCount,
                                    profilePicture: w.profilePicture ?? null,
                                    isOnline: w.isOnline,
                                    rank: pickIndex + 1,
                                    isFavourite: savedProIds.has(w.id),
                                  });
                                }}
                              />
                            );
                          }

                          const hub = w;
                          return (
                            <View
                              key={`hub-${hub.id}`}
                              style={[styles.topPickTrackCard, { width: topPickCardWidth, borderColor: cardBorder }]}
                            >
                              <View
                                style={[styles.topPickTrackAccentRail, { backgroundColor: accent }]}
                                pointerEvents="none"
                              />
                              <Pressable
                                style={({ pressed }) => [pressed && { opacity: 0.92 }]}
                                onPress={() => {
                                  hapticFeedback('light');
                                  openHubSheet(hub);
                                }}
                              >
                                <BlurView intensity={50} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
                                <LinearGradient
                                  colors={[accent + '18', 'transparent']}
                                  start={{ x: 0, y: 0 }}
                                  end={{ x: 1, y: 1 }}
                                  style={StyleSheet.absoluteFill}
                                  pointerEvents="none"
                                />
                                {renderTopPickGlossSheen()}
                                <View style={styles.topPickTrackCardPad}>
                                  <View style={styles.topPickTrackCardTop}>
                                    <View style={[styles.topPickTrackIconWrap, { backgroundColor: accent + '25' }]}>
                                      {hub.profilePicture && !failedValeterImageIds.has(imageFailKey(hub)) ? (
                                        <Image
                                          source={{ uri: hub.profilePicture }}
                                          style={styles.topPickTrackAvatarImg}
                                          resizeMode="cover"
                                          onError={() =>
                                            setFailedValeterImageIds((prev) => new Set(prev).add(imageFailKey(hub)))
                                          }
                                        />
                                      ) : (
                                        <GradientIconBox
                                          icon="business"
                                          colors={accentToGradient(accent)}
                                          boxSize={cpz(dz(36))}
                                          borderRadius={cpz(dz(10))}
                                          elevated
                                          size={cpz(dz(20))}
                                        />
                                      )}
                                    </View>
                                    <View style={styles.topPickTrackCardMain}>
                                      <Text style={styles.topPickTrackKicker}>CAR WASH</Text>
                                      <Text style={styles.topPickTrackTitle} numberOfLines={1}>
                                        {displayName}
                                      </Text>
                                      <Text style={styles.topPickTrackSubtitle} numberOfLines={1}>
                                        {hub.organization || 'Wash location'}
                                      </Text>
                                    </View>
                                  </View>
                                  <View style={styles.topPickTrackCardBottom}>
                                    <View style={styles.topPickTrackBottomMeta}>
                                      <View style={styles.topPickTrackEtaWrap}>
                                        <Ionicons name="star" size={14} color="#FBBF24" />
                                        <Text style={styles.topPickTrackEtaText}>
                                          {hub.rating > 0 ? hub.rating.toFixed(1) : 'New'}
                                        </Text>
                                      </View>
                                      <View style={styles.topPickTrackEtaWrap}>
                                        <Ionicons name="checkmark-done-outline" size={14} color={SKY} />
                                        <Text style={styles.topPickTrackEtaText}>{hub.jobsCompleted} jobs</Text>
                                      </View>
                                      <View style={styles.topPickTrackEtaWrap}>
                                        <Ionicons name="chatbubble-outline" size={14} color={SKY} />
                                        <Text style={styles.topPickTrackEtaText}>
                                          {formatReviewCount(hub.reviewCount)}
                                        </Text>
                                      </View>
                                    </View>
                                  </View>
                                </View>
                              </Pressable>
                            </View>
                          );
                        });
                        return (
                          <ScrollView
                            horizontal
                            showsHorizontalScrollIndicator={false}
                            contentContainerStyle={styles.topPicksCarouselContent}
                          >
                            {cards}
                          </ScrollView>
                        );
                      })()
                    ) : (
                      <View style={styles.prosEmptyState}>
                        <LivelyEmptyState
                          key={`picks-empty-${washPicksSegment}-${availabilityFilter}`}
                          variant="radar"
                          compact
                          accent={washPicksSegment === 'pros' ? chrome.accent : SKY}
                          icon={washPicksSegment === 'pros' ? 'car-sport' : 'business'}
                          title={washPicksSegment === 'pros' ? `Scanning for ${ccpPluralLower()}` : 'Scanning for locations'}
                          subtitle={getPicksEmptySubtitle(
                            washPicksSegment,
                            topPicksValeters.length,
                            topPicksHubs.length,
                            availabilityFilter
                          )}
                          actions={nextAvailabilityActions}
                        />
                      </View>
                    )
                  ) : (
                    <View style={styles.prosEmptyState}>
                      <LivelyEmptyState
                        key={`picks-none-${availabilityFilter}`}
                        variant="radar"
                        compact
                        accent={chrome.accent}
                        icon="sparkles"
                        title={availabilityFilter === 'offline' ? 'No offline saved pros' : 'Nobody online yet'}
                        subtitle={
                          availabilityFilter === 'offline'
                            ? `Save ${ccpPluralLower()} on Explore — they show here when offline.`
                            : `${CCP.pluralShort} appear here as soon as they come online.`
                        }
                        actions={nextAvailabilityActions}
                      />
                    </View>
                  )}
                </View>

              {/* Availability picker modal (All / Online / Offline) */}
              <Modal visible={showAvailabilityPicker} transparent animationType="fade" onRequestClose={() => setShowAvailabilityPicker(false)}>
                <Pressable style={styles.availabilityPickerOverlay} onPress={() => setShowAvailabilityPicker(false)}>
                  <Pressable style={styles.availabilityPickerContent} onPress={(e) => e.stopPropagation()}>
                    <Text style={styles.availabilityPickerTitle}>Availability</Text>
                    {AVAILABILITY_OPTIONS.map((option) => (
                      <TouchableOpacity
                        key={option}
                        style={[styles.availabilityPickerOption, availabilityFilter === option && styles.availabilityPickerOptionActive]}
                        onPress={() => {
                          hapticFeedback('light');
                          setAvailabilityFilter(option);
                          setShowAvailabilityPicker(false);
                        }}
                        activeOpacity={0.8}
                      >
                        <View style={styles.availabilityPickerOptionLabel}>
                          <Ionicons
                            name={AVAILABILITY_ICONS[option]}
                            size={15}
                            color={
                              option === 'online'
                                ? '#34D399'
                                : availabilityFilter === option
                                  ? SKY
                                  : 'rgba(148,163,184,0.9)'
                            }
                          />
                          <Text style={[styles.availabilityPickerOptionText, availabilityFilter === option && styles.availabilityPickerOptionTextActive]}>
                            {AVAILABILITY_LABELS[option]}
                          </Text>
                        </View>
                        {availabilityFilter === option && <Ionicons name="checkmark" size={18} color={SKY} />}
                      </TouchableOpacity>
                    ))}
                  </Pressable>
                </Pressable>
              </Modal>
            </View>
            </StaggerIn>
            </View>


          </View>
        )}
      </Animated.ScrollView>

      <View pointerEvents="box-none" style={[styles.pinnedPicker, { paddingTop: headerScrollClearance - PINNED_PICKER_LIFT }]}>
        <View
          pointerEvents="box-none"
          style={[styles.pinnedPickerInner, sectionContainerStyle, tabletSectionMarginReset]}
        >
          <DashboardLocationPicker userId={user?.id ?? null} onSelect={handleWashLocationSelect} />
        </View>
      </View>
      </View>

      <ValeterProfileBottomSheet
        visible={valeterProfileSheet != null}
        onClose={() => setValeterProfileSheet(null)}
        valeterId={valeterProfileSheet?.id ?? null}
        seed={valeterProfileSheet}
        requireOnlineToBook
        {...(user?.id && valeterProfileSheet
          ? {
              onToggleFavourite: () =>
                toggleSavedPro({
                  id: valeterProfileSheet.id,
                  name: valeterProfileSheet.name ?? null,
                  profilePicture: valeterProfileSheet.profilePicture ?? null,
                  ...(valeterProfileSheet.rating != null ? { rating: valeterProfileSheet.rating } : {}),
                  ...(valeterProfileSheet.totalJobs != null ? { totalJobs: valeterProfileSheet.totalJobs } : {}),
                }),
            }
          : {})}
        onRequestBook={() => {
          const id = valeterProfileSheet?.id;
          if (!id) return;
          setValeterProfileSheet(null);
          handleAttemptNewBooking('/owner/booking/create', { preferredValeterId: id });
        }}
      />

      {!MOBILE_SERVICE_ONLY_LAUNCH ? (
      <HubLocationProfileBottomSheet
        visible={hubLocationSheet != null}
        onClose={() => setHubLocationSheet(null)}
        locationId={hubLocationSheet?.id ?? null}
        seed={hubLocationSheet}
        onRequestBook={(hubId) => {
          setHubLocationSheet(null);
          router.push({ pathname: '/owner/booking/physical/vehicle', params: { locationId: hubId } } as any);
        }}
      />
      ) : null}

    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  scrollView: { flex: 1 },
  firstScreen: { justifyContent: 'space-between' },
  pinnedPicker: { position: 'absolute', top: 0, left: 0, right: 0, zIndex: 30 },
  pinnedPickerInner: { marginHorizontal: DASHBOARD_H_INSET, minHeight: PINNED_PICKER_H },

  bookingButtonsSection: {
    flexDirection: 'column',
    gap: DASHBOARD_V_GAP,
    marginHorizontal: DASHBOARD_H_INSET,
    marginTop: 0,
    marginBottom: 0,
  },
  trackPreviewBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginTop: 12,
    paddingHorizontal: 14,
    paddingVertical: 11,
    borderRadius: 18,
    backgroundColor: 'rgba(14,165,233,0.1)',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(125,211,252,0.35)',
  },
  trackPreviewBtnPressed: { opacity: 0.75, transform: [{ scale: 0.98 }] },
  trackPreviewIcon: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: '#38BDF8',
    alignItems: 'center',
    justifyContent: 'center',
  },
  trackPreviewCopy: { flex: 1, minWidth: 0 },
  trackPreviewTitle: { color: '#F0F9FF', fontSize: 14, fontWeight: '800' },
  trackPreviewHint: { marginTop: 1, color: 'rgba(224,242,254,0.6)', fontSize: 11.5, fontWeight: '600' },
  quickActionsRow: {
    flexDirection: 'row',
    width: '100%',
    gap: dzHero(8),
  },
  quickActionPressable: {
    flex: 1,
    minWidth: 0,
  },
  hubGlassTile: {
    alignItems: 'center',
    justifyContent: 'center',
    gap: dzHero(6),
    paddingVertical: dzHero(4),
    paddingHorizontal: dzHero(4),
    backgroundColor: 'transparent',
    borderWidth: 0,
  },
  hubIconStage: { alignItems: 'center', justifyContent: 'center', marginBottom: dzHero(2) },
  hubIconWell: {
    marginBottom: 0,
  },
  hubIconGlow: {
    position: 'absolute',
    shadowOpacity: 0.9,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 0 },
  },
  hubBadge: {
    position: 'absolute',
    top: -dzHero(5),
    right: -dzHero(10),
    minWidth: dzHero(20),
    height: dzHero(18),
    paddingHorizontal: dzHero(5),
    borderRadius: dzHero(9),
    alignItems: 'center',
    justifyContent: 'center',
  },
  hubBadgeText: { color: '#0B1220', fontSize: dzHero(10), fontWeight: '900', letterSpacing: -0.2 },
  hubGlassLabel: {
    color: '#F8FAFC',
    fontSize: dzHero(12),
    fontWeight: '800',
    textAlign: 'center',
    letterSpacing: 0.2,
  },
  hubGlassHint: {
    color: 'rgba(186,230,253,0.72)',
    fontSize: dzHero(11),
    fontWeight: '600',
    textAlign: 'center',
  },
  exploreCardSlot: {
    height: 190,
  },
  exploreGap: {
    alignItems: 'stretch',
    marginHorizontal: DASHBOARD_H_INSET,
    paddingTop: Math.round(DASHBOARD_SECTION_GAP * 0.6),
    paddingBottom: Math.round(DASHBOARD_SECTION_GAP * 0.2),
  },
  yourHubSection: {
    marginTop: DASHBOARD_SECTION_GAP - DASHBOARD_V_GAP,
    paddingTop: 0,
  },
  yourHubHeader: {
    marginBottom: DASHBOARD_V_GAP,
  },

  hiddenSection: {
    display: 'none',
  },
  /* Live Availability - Bottom Redesigned */
  availabilitySectionBottom: {
    marginHorizontal: DASHBOARD_H_INSET,
    marginBottom: dz(6),
    marginTop: 0,
    paddingTop: DASHBOARD_SECTION_GAP - 4,
    borderTopWidth: StyleSheet.hairlineWidth * 2,
    borderTopColor: 'rgba(148,163,184,0.16)',
  },
  /* Top Care Pros section header — text only */
  topWashersHeader: {
    marginBottom: DASHBOARD_V_GAP,
    gap: DASHBOARD_V_GAP,
  },
  topWashersHeaderTopRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
  },
  topWashersHeaderMain: {
    flex: 1,
    minWidth: 0,
    gap: 2,
  },
  topWashersTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flexWrap: 'wrap',
  },
  topWashersCountText: {
    color: 'rgba(186,230,253,0.92)',
    fontSize: 10.5,
    fontWeight: '800',
    fontVariant: ['tabular-nums'],
    letterSpacing: 0.4,
  },
  topWashersFilterBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingTop: 0,
    flexShrink: 0,
  },
  topWashersFilterBtnText: {
    fontSize: 14,
    fontWeight: '700',
  },
  topWashersFilterDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#34D399' },
  availabilityPickerOptionLabel: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  topWashersSegmentRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  topWashersSegmentTab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: dz(4),
    minHeight: dz(28),
    paddingVertical: dz(4),
    paddingHorizontal: dz(6),
    borderRadius: dz(8),
    borderWidth: 1,
  },
  topWashersSegmentTabIdle: {
    borderColor: 'rgba(148,163,184,0.14)',
    backgroundColor: 'rgba(8,20,38,0.28)',
  },
  topWashersSegmentLabel: {
    color: 'rgba(148,163,184,0.78)',
    fontSize: dz(11),
    fontWeight: '700',
    letterSpacing: 0.15,
    flexShrink: 1,
  },
  topWashersSegmentCount: {
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 5,
    backgroundColor: 'rgba(8,20,38,0.45)',
  },
  topWashersSegmentCountText: {
    color: 'rgba(148,163,184,0.85)',
    fontSize: 11,
    fontWeight: '800',
    fontVariant: ['tabular-nums'],
  },
  availabilityPickerOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  availabilityPickerContent: {
    width: '100%',
    maxWidth: 280,
    borderRadius: 16,
    backgroundColor: '#1E293B',
    borderWidth: 0,
    borderColor: 'transparent',
    padding: 16,
  },
  availabilityPickerTitle: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '700',
    marginBottom: 12,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  availabilityPickerOption: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 14,
    paddingHorizontal: 14,
    borderRadius: 12,
    marginBottom: 4,
  },
  availabilityPickerOptionActive: {
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  availabilityPickerOptionText: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 15,
    fontWeight: '600',
  },
  availabilityPickerOptionTextActive: {
    color: '#E0F2FE',
  },
  prosNearbyContainer: {
    marginBottom: 0,
  },
  topPicksCarouselContent: {
    gap: dz(10),
    paddingTop: dz(4),
    paddingBottom: dz(2),
    paddingRight: dz(8),
    alignItems: 'stretch',
  },
  topPickTrackCard: {
    overflow: 'hidden',
    borderRadius: cpz(dz(16)),
    backgroundColor: 'rgba(6,16,32,0.55)',
    alignSelf: 'stretch',
    minHeight: cpz(dz(136)),
    shadowColor: 'rgba(56,189,248,0.18)',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.32,
    shadowRadius: 14,
    elevation: 6,
    borderWidth: 1,
    borderColor: 'rgba(148,196,220,0.38)',
  },
  topPickTrackCardPad: {
    padding: cpz(dz(12)),
    paddingBottom: cpz(dz(14)),
    position: 'relative',
    gap: cpz(dz(10)),
    minHeight: cpz(dz(136)),
    justifyContent: 'space-between',
  },
  topPickTrackAccentRail: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 2,
    opacity: 0.85,
  },
  topPickTrackCardTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: cpz(dz(10)),
  },
  topPickTrackIconWrap: {
    width: cpz(dz(48)),
    height: cpz(dz(48)),
    borderRadius: cpz(dz(14)),
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.36)',
  },
  topPickTrackAvatarImg: { width: cpz(dz(48)), height: cpz(dz(48)), borderRadius: cpz(dz(14)) },
  topPickTrackCardMain: { flex: 1, minWidth: 0, gap: cpz(dz(2)) },
  topPickTrackKicker: {
    fontSize: 10.5,
    fontWeight: '800',
    color: 'rgba(186,230,253,0.92)',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
    marginBottom: 5,
  },
  sectionKicker: {
    fontSize: 9,
    letterSpacing: 1,
  },
  topWashersKickerInline: {
    marginBottom: 0,
  },
  topPickTrackTitle: {
    color: '#F8FAFC',
    fontSize: cpz(dz(16)),
    fontWeight: '900',
    letterSpacing: 0.1,
  },
  topPickTrackSubtitle: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 13,
    fontWeight: '600',
    marginBottom: cpz(dz(4)),
  },
  topPickTrackCardBottom: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingTop: 8,
    marginTop: 2,
    borderTopWidth: 1,
    borderTopColor: 'rgba(148,163,184,0.15)',
  },
  topPickTrackBottomMeta: { flex: 1, flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', gap: 8 },
  topPickTrackEtaWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.3)',
    backgroundColor: 'rgba(8,20,38,0.56)',
    borderRadius: 999,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  topPickTrackEtaText: { color: SKY, fontSize: dz(11), fontWeight: '800' },
  prosEmptyState: {
    paddingVertical: 10,
    paddingHorizontal: 8,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    backgroundColor: 'rgba(255,255,255,0.03)',
    borderRadius: 18,
    borderWidth: 0,
    borderColor: 'transparent',
  },


});
