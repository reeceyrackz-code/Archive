import { useCallback, useEffect, useRef, useState } from 'react';
import { Alert, Image, Pressable, StyleSheet, Text, View, type StyleProp, type ViewStyle } from 'react-native';
import { Marker, Polyline, type Region } from 'react-native-maps';
import type MapView from 'react-native-maps';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import type { SFSymbol } from 'expo-symbols';
import type { Ionicons } from '@expo/vector-icons';
import Reanimated, {
  Easing,
  FadeIn,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withRepeat,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import SafeMapView from '../maps/SafeMapView';
import { MapMarkerServiceSpot, MapMarkerTopDownCar } from '../maps/MapMarkerViews';
import MapMarkerMascotDroplet from '../maps/MapMarkerMascotDroplet';
import { GlassSurface, GlassSymbol } from '../shared/Glass';
import AnimatedProgress from '../booking/AnimatedProgress';
import { MAP_LOCKED_DARK, NAVIGATION_MAP_STYLE } from '../../constants/mapConstants';
import { CCP, ccpSingularLower } from '../../constants/carCareProLabels';
import { colors } from '../../constants/colors';
import { dz } from '../../constants/topCareProCardLayout';
import { accentToGradient } from '../../utils/accentGradient';
import { formatDisplayName } from '../../utils/formatDisplayName';
import { getServiceDisplayName } from '../../utils/serviceNameMapper';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { ROUTE_LINE_COLOR, useRoadRoute } from '../../utils/roadRoute';
import {
  getRingColorForStep,
  getStatusMessage,
  getStatusProgress,
  isCustomerDetailingService,
  normalizeStatusForTracking,
} from '../../utils/trackingStatusHelpers';

const SKY = colors.SKY;
const AMBER = '#F59E0B';
const BODY_BG = 'rgba(6,14,30,0.82)';

type IonName = keyof typeof Ionicons.glyphMap;

export type LiveJobBooking = {
  id: string;
  status: string;
  service_type: string;
  service_name: string | null;
  location_address: string | null;
  location_id: string | null;
  price: number;
  valeter_name: string | null;
  counterparty_photo_url: string | null;
  latitude: number | null;
  longitude: number | null;
};

type LatLng = { latitude: number; longitude: number };

/** From request until the Pro pulls up, the card map shows their driving route to you. */
const ROUTE_STATUSES = new Set(['pending_valeter_acceptance', 'pending_payment', 'confirmed', 'valeter_assigned', 'en_route']);
/** Car and van pins share one nose-to-tail length so they read as the same scale. */
const PIN_LENGTH = 44;
const MASCOT_SIZE = 26;
const ROUTE_EDGE = { top: 52, right: 40, bottom: 48, left: 40 };

type Props = Readonly<{
  loading: boolean;
  booking: LiveJobBooking | null;
  mapRegion: Region | null;
  userLocation: LatLng | null;
  valeterLocation: LatLng | null;
  onResumeTracking: () => void;
  style?: StyleProp<ViewStyle>;
}>;

const STEPS: ReadonlyArray<{ label: string; sf: SFSymbol; ion: IonName }> = [
  { label: 'Booked', sf: 'checkmark.seal.fill', ion: 'checkmark-circle' },
  { label: 'On the way', sf: 'car.side.fill', ion: 'car-sport' },
  { label: 'Arrived', sf: 'mappin.and.ellipse', ion: 'location' },
  { label: 'Washing', sf: 'sparkles', ion: 'sparkles' },
];

function stepIndexFor(status: string): number {
  switch (status) {
    case 'en_route':
      return 1;
    case 'arrived':
      return 2;
    case 'in_progress':
      return 3;
    default:
      return 0;
  }
}

function PulseDot({ color }: Readonly<{ color: string }>) {
  const t = useSharedValue(0);
  useEffect(() => {
    t.value = withRepeat(withTiming(1, { duration: 1400, easing: Easing.out(Easing.quad) }), -1, false);
  }, [t]);
  const halo = useAnimatedStyle(() => ({
    opacity: 0.55 * (1 - t.value),
    transform: [{ scale: 1 + t.value * 1.6 }],
  }));
  return (
    <View style={styles.dotWrap}>
      <Reanimated.View style={[styles.dotHalo, { backgroundColor: color }, halo]} />
      <View style={[styles.dot, { backgroundColor: color }]} />
    </View>
  );
}

function StepBar({
  state,
  accent,
  index,
}: Readonly<{ state: 'done' | 'active' | 'todo'; accent: string; index: number }>) {
  const fill = useSharedValue(0);
  const glow = useSharedValue(1);
  useEffect(() => {
    const target = state === 'done' ? 1 : state === 'active' ? 0.5 : 0;
    fill.value = withDelay(150 + index * 110, withTiming(target, { duration: 650, easing: Easing.out(Easing.cubic) }));
    glow.value =
      state === 'active'
        ? withRepeat(withSequence(withTiming(0.4, { duration: 900 }), withTiming(1, { duration: 900 })), -1, false)
        : withTiming(1, { duration: 200 });
  }, [state, index, fill, glow]);
  const fillStyle = useAnimatedStyle(() => ({ width: `${fill.value * 100}%`, opacity: glow.value }));
  return (
    <View style={styles.stepBar}>
      <Reanimated.View style={[styles.stepFill, { backgroundColor: accent }, fillStyle]} />
    </View>
  );
}

function LiveJobMap({
  accent,
  mapRegion,
  customer,
  valeter,
  serviceSpot,
  showRoute,
}: Readonly<{
  accent: string;
  mapRegion: Region;
  customer: LatLng;
  valeter: LatLng | null;
  serviceSpot: LatLng | null;
  showRoute: boolean;
}>) {
  const mapRef = useRef<MapView>(null);
  const [ready, setReady] = useState(false);
  const route = useRoadRoute(showRoute ? valeter : null, showRoute ? customer : null);

  const fit = useCallback(() => {
    if (!route || !valeter) return;
    mapRef.current?.fitToCoordinates([customer, valeter, ...route.coords], { edgePadding: ROUTE_EDGE, animated: true });
  }, [route, customer, valeter]);

  useEffect(() => {
    if (ready) fit();
  }, [ready, fit]);

  return (
    <>
      <SafeMapView
        ref={mapRef}
        style={StyleSheet.absoluteFill}
        {...(route ? { initialRegion: mapRegion } : { region: mapRegion })}
        scrollEnabled={false}
        zoomEnabled={false}
        pitchEnabled={false}
        rotateEnabled={false}
        customMapStyle={NAVIGATION_MAP_STYLE}
        userInterfaceStyle={MAP_LOCKED_DARK}
        pointerEvents="none"
        onMapReady={() => setReady(true)}
        onLayout={() => ready && fit()}
      >
        {route ? (
          <>
            <Polyline coordinates={route.coords} strokeColor={`${ROUTE_LINE_COLOR}55`} strokeWidth={9} lineCap="round" lineJoin="round" zIndex={1} />
            <Polyline
              coordinates={route.coords}
              strokeColor={ROUTE_LINE_COLOR}
              strokeWidth={3.5}
              lineCap="round"
              lineJoin="round"
              zIndex={2}
              {...(route.onRoads ? {} : { lineDashPattern: [6, 6] })}
            />
          </>
        ) : null}
        <Marker coordinate={customer} zIndex={3}>
          <MapMarkerTopDownCar length={PIN_LENGTH} />
        </Marker>
        {valeter ? (
          <Marker coordinate={valeter} anchor={{ x: 0.5, y: 0.5 }} zIndex={4}>
            <MapMarkerMascotDroplet size={MASCOT_SIZE} />
          </Marker>
        ) : serviceSpot ? (
          <Marker coordinate={serviceSpot}>
            <MapMarkerServiceSpot size={dz(30)} />
          </Marker>
        ) : null}
      </SafeMapView>
      {route ? (
        <View pointerEvents="none" style={[styles.routeChip, { borderColor: `${accent}88` }]}>
          <View style={[styles.routeChipDot, { backgroundColor: accent }]} />
          <Text style={styles.routeChipMain}>{`${route.minutes} min`}</Text>
          <Text style={styles.routeChipSub}>{`${route.miles < 0.1 ? '<0.1' : route.miles.toFixed(1)} mi away`}</Text>
        </View>
      ) : null}
    </>
  );
}

export default function LiveJobCard({
  loading,
  booking,
  mapRegion,
  userLocation,
  valeterLocation,
  onResumeTracking,
  style,
}: Props) {
  const press = useSharedValue(1);
  const pressStyle = useAnimatedStyle(() => ({ transform: [{ scale: press.value }] }));

  if (loading) {
    return (
      <Reanimated.View entering={FadeIn.duration(300)} style={style}>
        <GlassSurface style={styles.skeleton}>
          <PulseDot color={SKY} />
          <Text style={styles.skeletonText}>Checking for a live job…</Text>
        </GlassSurface>
      </Reanimated.View>
    );
  }

  if (!booking) return null;

  const isPaymentDue = booking.status === 'pending_payment';
  const isConnecting =
    booking.status === 'pending_valeter_acceptance' ||
    booking.status === 'pending' ||
    booking.status === 'pending_business_acceptance';
  const chatLocked = isPaymentDue || isConnecting;
  const normalized = normalizeStatusForTracking(booking.status);
  const isDetailing = isCustomerDetailingService(booking.service_type, booking.service_name);
  const accent = isPaymentDue ? AMBER : getRingColorForStep(normalized) || SKY;
  const progress = getStatusProgress(normalized);
  const step = stepIndexFor(normalized);
  const current = STEPS[step] ?? STEPS[0]!;
  const serviceLabel = getServiceDisplayName(booking.service_type, booking.service_name);
  const statusTitle = isPaymentDue
    ? 'Payment due'
    : getStatusMessage(normalized, booking.location_id ? { name: 'Car Wash' } : null, isDetailing);
  const proName = booking.valeter_name ? formatDisplayName(booking.valeter_name) : null;
  const proRole = isDetailing ? 'Detailer' : CCP.singularShort;
  const metaLine = proName
    ? `${serviceLabel} · ${proRole} ${proName}`
    : `${serviceLabel} · ${booking.location_address || `Matching your ${CCP.singularShort.toLowerCase()}`}`;
  const badgeLabel = isPaymentDue ? 'Action needed' : isConnecting ? 'Connecting' : 'Live';
  const ctaLabel = isPaymentDue ? 'Pay now' : 'Track live';
  const [ctaFrom, ctaTo] = accentToGradient(accent);
  const bookingSpot = booking.latitude != null && booking.longitude != null ? { latitude: booking.latitude, longitude: booking.longitude } : null;
  const routeTarget = valeterLocation ? bookingSpot : null;

  const openPrimary = () => {
    void hapticFeedback('light');
    if (isPaymentDue) {
      router.push({ pathname: '/owner/track', params: { bookingId: booking.id } });
      return;
    }
    onResumeTracking();
  };

  const openChat = () => {
    if (isPaymentDue) {
      Alert.alert('Payment needed', 'Finish payment first, then you can message your Care Pro.');
      return;
    }
    if (isConnecting) {
      Alert.alert('Still connecting', `Chat unlocks once your ${ccpSingularLower()} accepts the booking.`);
      return;
    }
    void hapticFeedback('light');
    router.push({ pathname: '/owner/inbox', params: { bookingId: booking.id } });
  };

  return (
    <Reanimated.View entering={FadeIn.duration(420)} style={style}>
      <Pressable
        onPress={openPrimary}
        onPressIn={() => {
          press.value = withSpring(0.985, { damping: 18, stiffness: 320 });
        }}
        onPressOut={() => {
          press.value = withSpring(1, { damping: 16, stiffness: 260 });
        }}
        accessibilityRole="button"
        accessibilityLabel={`${statusTitle}. ${ctaLabel}`}
      >
        <Reanimated.View style={[styles.card, pressStyle]}>
          <View style={styles.map}>
            {mapRegion && userLocation ? (
              <LiveJobMap
                accent={accent}
                mapRegion={mapRegion}
                customer={routeTarget ?? userLocation}
                valeter={valeterLocation}
                serviceSpot={bookingSpot}
                showRoute={ROUTE_STATUSES.has(normalized) && valeterLocation != null}
              />
            ) : (
              <LinearGradient
                colors={[`${accent}38`, 'rgba(15,23,42,0.5)']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={StyleSheet.absoluteFill}
              />
            )}
            <LinearGradient
              colors={['rgba(2,6,23,0.28)', 'rgba(6,14,30,0)', 'rgba(6,14,30,0)', BODY_BG]}
              locations={[0, 0.3, 0.8, 1]}
              style={StyleSheet.absoluteFill}
              pointerEvents="none"
            />
            <View style={styles.mapTop}>
              <GlassSurface style={styles.badge}>
                <PulseDot color={accent} />
                <Text style={styles.badgeText}>{badgeLabel}</Text>
              </GlassSurface>
              <Pressable
                onPress={openChat}
                hitSlop={8}
                accessibilityRole="button"
                accessibilityLabel={chatLocked ? 'Chat locked' : 'Open chat'}
              >
                <GlassSurface style={styles.chatBtn} interactive>
                  <GlassSymbol
                    sf={chatLocked ? 'lock.fill' : 'bubble.left.and.bubble.right.fill'}
                    ion={chatLocked ? 'lock-closed' : 'chatbubbles'}
                    size={13}
                    color={chatLocked ? 'rgba(226,232,240,0.6)' : '#F8FAFC'}
                  />
                </GlassSurface>
              </Pressable>
            </View>
          </View>

          <View style={styles.body}>
            <View style={styles.headRow}>
              <AnimatedProgress
                progress={progress}
                size={46}
                strokeWidth={2.5}
                showPercentage={false}
                color={accent}
                light
                centerContent={
                  booking.counterparty_photo_url ? (
                    <Image source={{ uri: booking.counterparty_photo_url }} style={styles.avatar} />
                  ) : (
                    <View style={[styles.avatar, styles.avatarFallback, { backgroundColor: `${accent}1F` }]}>
                      <GlassSymbol
                        sf={isPaymentDue ? 'creditcard.fill' : current.sf}
                        ion={isPaymentDue ? 'card' : current.ion}
                        size={15}
                        color={accent}
                      />
                    </View>
                  )
                }
              />
              <View style={styles.headText}>
                <Text style={styles.title} numberOfLines={1}>
                  {statusTitle}
                </Text>
                <Text style={styles.meta} numberOfLines={1}>
                  {metaLine}
                </Text>
              </View>
              <View style={styles.priceCol}>
                <Text style={styles.price}>£{Number(booking.price || 0).toFixed(2)}</Text>
                <Text style={styles.priceLabel}>Total</Text>
              </View>
            </View>

            <View style={styles.stepBars}>
              {STEPS.map((s, i) => (
                <StepBar key={s.label} state={i < step ? 'done' : i === step ? 'active' : 'todo'} accent={accent} index={i} />
              ))}
            </View>

            <View style={styles.footRow}>
              <View style={styles.stepNow}>
                <GlassSymbol sf={current.sf} ion={current.ion} size={12} color={accent} />
                <Text style={styles.stepNowText} numberOfLines={1}>
                  <Text style={styles.stepNowStrong}>{current.label}</Text>
                  {`  ·  Step ${step + 1} of ${STEPS.length}`}
                </Text>
              </View>
              <View style={styles.cta}>
                <LinearGradient
                  colors={[ctaFrom, ctaTo]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={StyleSheet.absoluteFill}
                />
                <Text style={styles.ctaText}>{ctaLabel}</Text>
                <GlassSymbol sf="arrow.right" ion="arrow-forward" size={12} color="#0B1220" />
              </View>
            </View>
          </View>
        </Reanimated.View>
      </Pressable>
    </Reanimated.View>
  );
}

const styles = StyleSheet.create({
  skeleton: {
    borderRadius: 18,
    paddingVertical: 18,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
  },
  skeletonText: {
    color: 'rgba(226,232,240,0.8)',
    fontSize: 13,
    fontWeight: '600',
  },
  card: {
    borderRadius: 18,
    overflow: 'hidden',
    backgroundColor: BODY_BG,
    shadowColor: '#020617',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.22,
    shadowRadius: 16,
    elevation: 8,
  },
  map: {
    height: 168,
    overflow: 'hidden',
  },
  routeChip: {
    position: 'absolute',
    left: 10,
    bottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    height: 28,
    borderRadius: 10,
    borderWidth: 1,
    backgroundColor: 'rgba(2,6,23,0.85)',
  },
  routeChipDot: { width: 6, height: 6, borderRadius: 3 },
  routeChipMain: { color: '#F8FAFC', fontSize: 13, fontWeight: '800', fontVariant: ['tabular-nums'] },
  routeChipSub: { color: 'rgba(226,232,240,0.72)', fontSize: 11.5, fontWeight: '700', fontVariant: ['tabular-nums'] },
  mapTop: {
    position: 'absolute',
    top: 8,
    left: 8,
    right: 8,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    height: 24,
    borderRadius: 999,
  },
  badgeText: {
    color: '#F8FAFC',
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  dotWrap: {
    width: 7,
    height: 7,
    alignItems: 'center',
    justifyContent: 'center',
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  dotHalo: {
    position: 'absolute',
    width: 7,
    height: 7,
    borderRadius: 4,
  },
  chatBtn: {
    width: 30,
    height: 30,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
  },
  body: {
    paddingHorizontal: 12,
    paddingTop: 2,
    paddingBottom: 10,
    gap: 9,
  },
  headRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  avatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(148,163,184,0.18)',
  },
  avatarFallback: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  headText: {
    flex: 1,
    minWidth: 0,
    gap: 2,
  },
  title: {
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '700',
    letterSpacing: -0.2,
  },
  meta: {
    color: 'rgba(226,232,240,0.62)',
    fontSize: 12,
    fontWeight: '500',
  },
  priceCol: {
    alignItems: 'flex-end',
    gap: 1,
  },
  price: {
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '700',
    letterSpacing: -0.3,
  },
  priceLabel: {
    color: 'rgba(226,232,240,0.45)',
    fontSize: 10,
    fontWeight: '600',
    letterSpacing: 0.3,
    textTransform: 'uppercase',
  },
  stepBars: {
    flexDirection: 'row',
    gap: 4,
  },
  stepBar: {
    flex: 1,
    height: 3,
    borderRadius: 2,
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.1)',
  },
  stepFill: {
    height: '100%',
    borderRadius: 2,
  },
  footRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10,
  },
  stepNow: {
    flex: 1,
    minWidth: 0,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  stepNowText: {
    flexShrink: 1,
    color: 'rgba(226,232,240,0.5)',
    fontSize: 11,
    fontWeight: '500',
  },
  stepNowStrong: {
    color: 'rgba(248,250,252,0.9)',
    fontWeight: '600',
  },
  cta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    height: 32,
    paddingHorizontal: 14,
    borderRadius: 999,
    overflow: 'hidden',
  },
  ctaText: {
    color: '#0B1220',
    fontSize: 12,
    fontWeight: '700',
  },
});
