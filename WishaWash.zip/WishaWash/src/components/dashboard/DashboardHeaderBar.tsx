import { Image, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import Animated, { FadeIn, FadeInRight } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import GradientNotificationBell from '../shared/GradientNotificationBell';
import { useMapChromeColors } from '../../hooks/useMapChromeColors';
import {
  HEADER_BAR_BODY,
  HEADER_BAR_PAD_BOTTOM,
  HEADER_BAR_PAD_H,
  HEADER_BAR_PAD_TOP,
  HEADER_TILE as TILE,
  HEADER_TILE_BG as TILE_BG,
  HEADER_TILE_BORDER as TILE_BORDER,
  HEADER_TILE_RADIUS as TILE_RADIUS,
} from '../../constants/headerChrome';

type DayPart = Readonly<{ greeting: string; icon: keyof typeof Ionicons.glyphMap; tint: string }>;

function dayPart(hour: number): DayPart {
  if (hour < 12) return { greeting: 'Good morning', icon: 'sunny', tint: '#FBBF24' };
  if (hour < 17) return { greeting: 'Good afternoon', icon: 'partly-sunny', tint: '#FCD34D' };
  return { greeting: 'Good evening', icon: 'moon', tint: '#A5B4FC' };
}

function formatPoints(points: number): string {
  if (points >= 10000) return `${Math.round(points / 1000)}k`;
  return points.toLocaleString();
}

export const DASHBOARD_HEADER_BAR_BODY = HEADER_BAR_BODY;

type Props = Readonly<{
  name: string;
  photoUrl: string | null;
  points?: number;
  notificationCount: number;
  onProfilePress: () => void;
  onPointsPress?: () => void;
  onNotificationsPress: () => void;
}>;

/** Customer dashboard top bar: bordered glass strip with profile, greeting, points and notifications. */
export default function DashboardHeaderBar({ name, photoUrl, points, notificationCount, onProfilePress, onPointsPress, onNotificationsPress }: Props) {
  const insets = useSafeAreaInsets();
  const chrome = useMapChromeColors();
  const part = dayPart(new Date().getHours());

  return (
    <View style={[styles.bar, { paddingTop: insets.top + HEADER_BAR_PAD_TOP }]} pointerEvents="box-none">
      <BlurView
        intensity={40}
        tint="dark"
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
        {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
      />
      <LinearGradient
        colors={[...chrome.gradient]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />

      <Animated.View entering={FadeIn.duration(320)} style={styles.row}>
        <Pressable
          onPress={onProfilePress}
          accessibilityRole="button"
          accessibilityLabel="Profile"
          style={({ pressed }) => [styles.avatarTile, { borderColor: chrome.border }, pressed && styles.pressed]}
        >
          {photoUrl ? (
            <Image source={{ uri: photoUrl }} style={styles.avatarImg} resizeMode="cover" />
          ) : (
            <View style={styles.avatarFallback}>
              <Ionicons name="person" size={20} color="#E0F2FE" />
            </View>
          )}
        </Pressable>

        <View style={styles.textCol}>
          <View style={styles.greetingRow}>
            <Ionicons name={part.icon} size={12} color={part.tint} />
            <Text style={styles.greeting} numberOfLines={1}>
              {part.greeting}
            </Text>
          </View>
          <Text style={styles.name} numberOfLines={1}>
            {name}
          </Text>
        </View>

        {points === undefined ? null : (
          <Animated.View entering={FadeInRight.delay(160).springify().damping(16)}>
            <Pressable
              onPress={onPointsPress}
              disabled={!onPointsPress}
              hitSlop={6}
              accessibilityRole="button"
              accessibilityLabel={`${points} reward points`}
              style={({ pressed }) => [styles.pointsChip, pressed && styles.pressed]}
            >
              <Ionicons name="trophy" size={13} color="#FBBF24" />
              <Text style={styles.pointsValue}>{formatPoints(points)}</Text>
              <Text style={styles.pointsSuffix}>pts</Text>
            </Pressable>
          </Animated.View>
        )}

        <View style={styles.bellTile}>
          <GradientNotificationBell count={notificationCount} onPress={onNotificationsPress} />
        </View>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  bar: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    paddingHorizontal: HEADER_BAR_PAD_H,
    paddingBottom: HEADER_BAR_PAD_BOTTOM,
    overflow: 'hidden',
  },
  row: { flexDirection: 'row', alignItems: 'center', gap: 10, minHeight: TILE },
  pressed: { opacity: 0.75 },
  avatarTile: {
    width: TILE,
    height: TILE,
    borderRadius: TILE_RADIUS,
    borderWidth: 1.5,
    overflow: 'hidden',
    backgroundColor: TILE_BG,
  },
  avatarImg: { width: '100%', height: '100%' },
  avatarFallback: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(56,189,248,0.2)' },
  textCol: { flex: 1, minWidth: 0, gap: 1 },
  greetingRow: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  greeting: { color: 'rgba(203,213,225,0.82)', fontSize: 12, fontWeight: '700', letterSpacing: 0.2 },
  name: { color: '#F8FAFC', fontSize: 18, fontWeight: '800', letterSpacing: -0.3 },
  pointsChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    height: 34,
    paddingHorizontal: 11,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(251,191,36,0.38)',
    backgroundColor: 'rgba(251,191,36,0.1)',
  },
  pointsValue: { color: '#FBBF24', fontSize: 14, fontWeight: '800', letterSpacing: -0.2, fontVariant: ['tabular-nums'] },
  pointsSuffix: { color: 'rgba(251,191,36,0.75)', fontSize: 11, fontWeight: '700', marginTop: 1 },
  bellTile: {
    width: TILE,
    height: TILE,
    borderRadius: TILE_RADIUS,
    borderWidth: 1,
    borderColor: TILE_BORDER,
    backgroundColor: TILE_BG,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
