import { memo, useCallback, useState } from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { Marker, type Region } from 'react-native-maps';
import SafeMapView from '../maps/SafeMapView';
import { useFocusEffect } from 'expo-router';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import Animated, { css, FadeInDown, useAnimatedStyle, useSharedValue, withSpring } from 'react-native-reanimated';
import { MapMarkerCustomerVehicle, MapMarkerValeterLive } from '../maps/MapMarkerViews';
import { MAP_LOCKED_DARK, NAVIGATION_MAP_STYLE } from '../../constants/mapConstants';
import { hapticFeedback } from '../../services/HapticFeedbackService';

type Coord = { latitude: number; longitude: number };

type Props = Readonly<{
  nearbyCount: number;
  proLabelSingular: string;
  proLabelPlural: string;
  onPress: () => void;
  scale?: number;
  onlineCount?: number;
  radiusKm?: number;
  previewNames?: readonly string[];
  region?: Region | null;
  userLocation?: Coord | null;
  proPins?: readonly (Coord & { id: string })[];
}>;

const KM_PER_MILE = 1.609344;
const AVATAR_TINTS = ['#38BDF8', '#34D399', '#FBBF24'] as const;

const livePulse = css.keyframes({
  from: { transform: [{ scale: 1 }], opacity: 0.7 },
  to: { transform: [{ scale: 2.6 }], opacity: 0 },
});

/** Non-interactive tinted map behind the card; unmounted while the screen is blurred to save battery. */
const CardMap = memo(function CardMap({
  region,
  userLocation,
  proPins,
  markerSize,
}: Readonly<{ region: Region; userLocation: Coord | null; proPins: readonly (Coord & { id: string })[]; markerSize: number }>) {
  const [focused, setFocused] = useState(true);
  useFocusEffect(
    useCallback(() => {
      setFocused(true);
      return () => setFocused(false);
    }, [])
  );
  if (!focused) return null;
  return (
    <SafeMapView
      style={StyleSheet.absoluteFill}
      region={region}
      scrollEnabled={false}
      zoomEnabled={false}
      pitchEnabled={false}
      rotateEnabled={false}
      toolbarEnabled={false}
      showsPointsOfInterests={false}
      customMapStyle={NAVIGATION_MAP_STYLE}
      userInterfaceStyle={MAP_LOCKED_DARK}
      pointerEvents="none"
      {...(Platform.OS === 'android' ? { liteMode: true } : {})}
    >
      {proPins.map((p) => (
        <Marker
          key={`card-pro-${p.id}`}
          coordinate={{ latitude: p.latitude, longitude: p.longitude }}
          anchor={{ x: 0.5, y: 0.5 }}
          tracksViewChanges={false}
        >
          <MapMarkerValeterLive size={markerSize} />
        </Marker>
      ))}
      {userLocation ? (
        <Marker coordinate={userLocation} anchor={{ x: 0.5, y: 0.5 }} tracksViewChanges={false}>
          <MapMarkerCustomerVehicle size={Math.round(markerSize * 1.1)} />
        </Marker>
      ) : null}
    </SafeMapView>
  );
});

function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return '?';
  return ((parts[0]?.[0] ?? '') + (parts.length > 1 ? (parts[parts.length - 1]?.[0] ?? '') : '')).toUpperCase();
}

function firstName(name: string): string {
  return name.trim().split(/\s+/)[0] ?? name;
}

function LiveDot() {
  return (
    <View style={styles.liveDotWrap}>
      <Animated.View
        style={[
          styles.liveDot,
          styles.liveDotRing,
          {
            animationName: livePulse,
            animationDuration: '1.6s',
            animationIterationCount: 'infinite',
            animationTimingFunction: 'ease-out',
          },
        ]}
      />
      <View style={styles.liveDot} />
    </View>
  );
}

export default function ExploreMapButton({
  nearbyCount,
  proLabelSingular,
  proLabelPlural,
  onPress,
  scale = 1,
  onlineCount,
  radiusKm,
  previewNames = [],
  region = null,
  userLocation = null,
  proPins = [],
}: Props) {
  const pressScale = useSharedValue(1);
  const pressStyle = useAnimatedStyle(() => ({ transform: [{ scale: pressScale.value }] }));
  const s = (n: number) => Math.round(n * scale);
  const online = onlineCount ?? nearbyCount;
  const live = online > 0;

  const subtitle = live
    ? `Live now${radiusKm ? ` · within ${Math.round(radiusKm / KM_PER_MILE)} mi` : ''}`
    : 'See pros & washes around you';

  const avatars = previewNames.slice(0, 3);
  const names = avatars.slice(0, 2).map(firstName);
  const more = Math.max(0, Math.max(nearbyCount, avatars.length) - names.length);
  let peopleLine = `No ${proLabelPlural} online right now`;
  if (avatars.length > 0) {
    peopleLine =
      more > 0
        ? `${names.join(', ')} & ${more} more ready near you`
        : `${names.join(' & ')} ${names.length === 1 ? 'is' : 'are'} ready near you`;
  }

  return (
    <Animated.View entering={FadeInDown.delay(120).springify().damping(16)} style={styles.outer}>
      <Pressable
        style={styles.fill}
        onPress={() => {
          void hapticFeedback('light');
          onPress();
        }}
        onPressIn={() => {
          pressScale.value = withSpring(0.97, { damping: 16, stiffness: 360 });
        }}
        onPressOut={() => {
          pressScale.value = withSpring(1, { damping: 12, stiffness: 240 });
        }}
        accessibilityRole="button"
        accessibilityLabel={`Explore the map. ${subtitle}. ${online} ${online === 1 ? proLabelSingular : proLabelPlural} online.`}
      >
        <Animated.View style={[styles.shell, styles.fill, { borderRadius: s(24) }, pressStyle]}>
          <View style={[StyleSheet.absoluteFill, styles.fallback]} />
          {region ? (
            <CardMap region={region} userLocation={userLocation} proPins={proPins} markerSize={s(26)} />
          ) : null}
          <LinearGradient
            colors={['rgba(2,10,24,0.72)', 'rgba(2,10,24,0.08)', 'rgba(2,10,24,0.08)', 'rgba(2,10,24,0.6)']}
            locations={[0, 0.35, 0.65, 1]}
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
          />
          <View style={[styles.rim, { borderRadius: s(24) }]} pointerEvents="none" />

          <View style={[styles.content, { padding: s(12) }]}>
            <View style={[styles.row, { gap: s(10) }]}>
              <View style={styles.copy}>
                <Text style={[styles.title, { fontSize: s(17) }]}>Explore the map</Text>
                <View style={styles.subRow}>
                  {live ? <LiveDot /> : null}
                  <Text style={[styles.subtitle, { fontSize: s(12) }]} numberOfLines={1}>
                    {subtitle}
                  </Text>
                </View>
              </View>
              <View style={[styles.arrow, { width: s(34), height: s(34), borderRadius: s(17) }]}>
                <Ionicons name="arrow-forward" size={s(17)} color="#0B1220" />
              </View>
            </View>

            <View style={styles.spacer} />

            <View style={[styles.peopleBar, { borderRadius: s(16), paddingVertical: s(7), paddingHorizontal: s(8) }]}>
              <BlurView
                intensity={Platform.OS === 'ios' ? 20 : 28}
                tint="dark"
                style={StyleSheet.absoluteFill}
                {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
              />
              {avatars.length > 0 ? (
                <View style={styles.avatarStack}>
                  {avatars.map((name, i) => (
                    <View
                      key={`${name}-${i}`}
                      style={[
                        styles.avatar,
                        {
                          width: s(22),
                          height: s(22),
                          borderRadius: s(11),
                          marginLeft: i === 0 ? 0 : -s(7),
                          backgroundColor: AVATAR_TINTS[i % AVATAR_TINTS.length],
                          zIndex: avatars.length - i,
                        },
                      ]}
                    >
                      <Text style={[styles.avatarText, { fontSize: s(9) }]}>{initials(name)}</Text>
                    </View>
                  ))}
                </View>
              ) : null}
              <Text style={[styles.people, { fontSize: s(12) }]} numberOfLines={1}>
                {peopleLine}
              </Text>
            </View>
          </View>
        </Animated.View>
      </Pressable>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  outer: { alignSelf: 'stretch', flexGrow: 1 },
  fill: { flexGrow: 1 },
  shell: {
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.3,
    shadowRadius: 16,
    elevation: 8,
  },
  fallback: { backgroundColor: '#0E2238' },
  rim: {
    ...StyleSheet.absoluteFill,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(186,230,253,0.28)',
  },
  content: { flexGrow: 1 },
  spacer: { flexGrow: 1 },
  row: { flexDirection: 'row', alignItems: 'center' },
  copy: { flex: 1, gap: 3 },
  title: { color: '#F8FAFC', fontWeight: '800', letterSpacing: -0.3 },
  subRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  subtitle: { color: 'rgba(186,230,253,0.95)', fontWeight: '600' },
  liveDotWrap: { width: 7, height: 7, alignItems: 'center', justifyContent: 'center' },
  liveDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#34D399' },
  liveDotRing: { position: 'absolute' },
  arrow: { alignItems: 'center', justifyContent: 'center', backgroundColor: '#7DD3FC' },
  peopleBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    overflow: 'hidden',
    backgroundColor: 'rgba(2,10,24,0.35)',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(186,230,253,0.16)',
  },
  avatarStack: { flexDirection: 'row', alignItems: 'center' },
  avatar: {
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1.5,
    borderColor: '#0E2238',
  },
  avatarText: { color: '#0B1220', fontWeight: '800' },
  people: { flex: 1, color: 'rgba(226,232,240,0.92)', fontWeight: '600' },
});
