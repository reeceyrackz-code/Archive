import { useEffect, useRef, useState, type RefObject } from 'react';
import {
  Animated,
  Dimensions,
  Easing,
  Keyboard,
  Platform,
  TextInput,
  type KeyboardEvent,
  type View,
} from 'react-native';

/** Minimum usable height between the header's bottom edge and the keyboard before the header gets out of the way. */
const MIN_CONTENT_ROOM = 240;
/** Gap the focused input needs below the header's bottom edge. */
const INPUT_HEADER_GAP = 8;
const RECHECK_INTERVAL_MS = 250;

type Measurable = { measureInWindow?: (cb: (x: number, y: number, w: number, h: number) => void) => void };

/**
 * Slides a floating header away while the keyboard is open and the header would either cover the
 * focused input or leave too little room above the keyboard. It returns once the keyboard closes.
 * Once hidden it stays hidden until the keyboard goes, so it never flickers while typing.
 *
 * Returns a 0 (visible) → 1 (hidden) progress value plus a boolean for pointer events.
 */
export function useSmartHeaderHide(headerRef: RefObject<View | null>, enabled = true) {
  const progress = useRef(new Animated.Value(0)).current;
  const [hidden, setHidden] = useState(false);
  const hiddenRef = useRef(false);

  useEffect(() => {
    if (!enabled) return undefined;

    let keyboardTop: number | null = null;
    let timer: ReturnType<typeof setInterval> | null = null;

    const setHide = (next: boolean) => {
      if (hiddenRef.current === next) return;
      hiddenRef.current = next;
      setHidden(next);
      Animated.timing(progress, {
        toValue: next ? 1 : 0,
        duration: next ? 200 : 240,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }).start();
    };

    const check = () => {
      if (keyboardTop == null || hiddenRef.current) return;
      const header = headerRef.current as unknown as Measurable | null;
      if (!header?.measureInWindow) return;
      header.measureInWindow((_hx, hy, _hw, hh) => {
        if (keyboardTop == null || hiddenRef.current || !Number.isFinite(hy) || hh <= 0) return;
        const headerBottom = hy + hh;
        const input = TextInput.State.currentlyFocusedInput?.() as Measurable | null | undefined;
        if (!input?.measureInWindow) {
          if (keyboardTop - headerBottom < MIN_CONTENT_ROOM) setHide(true);
          return;
        }
        input.measureInWindow((_x, y, _w, h) => {
          if (keyboardTop == null || hiddenRef.current || !Number.isFinite(y) || h <= 0) return;
          // The input lives inside the header (e.g. a search bar) — hiding would hide what's being typed in.
          if (y >= hy - 1 && y + h <= headerBottom + 1) return;
          if (keyboardTop - headerBottom < MIN_CONTENT_ROOM || y < headerBottom + INPUT_HEADER_GAP) {
            setHide(true);
          }
        });
      });
    };

    const onShow = (e: KeyboardEvent) => {
      const screenH = Dimensions.get('window').height;
      keyboardTop = e.endCoordinates.screenY > 0 ? e.endCoordinates.screenY : screenH - e.endCoordinates.height;
      check();
      if (!timer) timer = setInterval(check, RECHECK_INTERVAL_MS);
    };

    const onHide = () => {
      keyboardTop = null;
      if (timer) {
        clearInterval(timer);
        timer = null;
      }
      setHide(false);
    };

    const subs = [
      Keyboard.addListener('keyboardDidShow', onShow),
      Keyboard.addListener(Platform.OS === 'ios' ? 'keyboardWillHide' : 'keyboardDidHide', onHide),
    ];
    if (Platform.OS === 'ios') {
      subs.push(
        Keyboard.addListener('keyboardDidChangeFrame', (e) => {
          if (keyboardTop != null) onShow(e);
        })
      );
    }

    return () => {
      subs.forEach((s) => s.remove());
      if (timer) clearInterval(timer);
      hiddenRef.current = false;
      setHidden(false);
      progress.setValue(0);
    };
  }, [enabled, headerRef, progress]);

  return { progress, hidden };
}
