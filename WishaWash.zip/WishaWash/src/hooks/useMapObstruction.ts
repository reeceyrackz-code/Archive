import { useCallback, useEffect, useRef, useState, useSyncExternalStore } from 'react';
import type { View } from 'react-native';
import {
  bottomOverlapForMap,
  createObstructionId,
  getMapObstructionVersion,
  setMapObstruction,
  subscribeMapObstructions,
} from '../utils/mapObstructionStore';

/** Re-measure after layout so slide-in / spring animations settle before we trust the rect. */
const SETTLE_DELAYS_MS = [0, 320, 900];

function useWindowRect(onRect: (rect: { top: number; bottom: number } | null) => void) {
  const ref = useRef<View>(null);
  const timers = useRef<ReturnType<typeof setTimeout>[]>([]);
  const onRectRef = useRef(onRect);
  onRectRef.current = onRect;

  const measure = useCallback(() => {
    ref.current?.measureInWindow((_x, y, _w, h) => {
      if (!Number.isFinite(y) || !Number.isFinite(h)) return;
      onRectRef.current(h > 0 ? { top: y, bottom: y + h } : null);
    });
  }, []);

  const onLayout = useCallback(() => {
    timers.current.forEach(clearTimeout);
    timers.current = SETTLE_DELAYS_MS.map((ms) => setTimeout(measure, ms));
  }, [measure]);

  useEffect(
    () => () => {
      timers.current.forEach(clearTimeout);
    },
    []
  );

  return { ref, onLayout, measure };
}

/**
 * Attach to a bottom sheet's outer view (or an absolute-fill child of it) so maps underneath
 * lift their legal label / logo above it. Pass `enabled={false}` for modal overlays.
 */
export function useReportMapObstruction(enabled = true) {
  const idRef = useRef<string | null>(null);
  if (idRef.current == null) idRef.current = createObstructionId();
  const id = idRef.current;

  const rect = useWindowRect((r) => {
    if (enabled) setMapObstruction(id, r);
  });

  useEffect(() => {
    if (!enabled) setMapObstruction(id, null);
    return () => setMapObstruction(id, null);
  }, [enabled, id]);

  return { ref: rect.ref, onLayout: rect.onLayout };
}

/** For a map: how many px of its bottom edge are covered by reported sheets. */
export function useMapBottomOverlap() {
  const [mapRect, setMapRect] = useState<{ top: number; bottom: number } | null>(null);
  const rect = useWindowRect(setMapRect);
  useSyncExternalStore(subscribeMapObstructions, getMapObstructionVersion, getMapObstructionVersion);
  const overlap = mapRect ? bottomOverlapForMap(mapRect.top, mapRect.bottom) : 0;
  return { ref: rect.ref, onLayout: rect.onLayout, overlap };
}
