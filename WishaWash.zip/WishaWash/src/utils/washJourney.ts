import type { ComponentProps } from 'react';
import type { Ionicons } from '@expo/vector-icons';
import {
  detailingServiceOptions,
  repairServiceOptions,
  LEGACY_ECO_SERVICE_ID_MAP,
} from '../constants/serviceOptions';

type IconName = ComponentProps<typeof Ionicons>['name'];

/** Animation played over the car while the Pro is at a station. */
export type StationFx =
  | 'water'
  | 'foam'
  | 'wheels'
  | 'mitt'
  | 'air'
  | 'sparkle'
  | 'vacuum'
  | 'scan'
  | 'polisher'
  | 'mist'
  | 'tools'
  | 'headlights'
  | 'dab';

export type WashStation = { label: string; icon: IconName; fx: StationFx };
export type JobKind = 'wash' | 'detail' | 'repair';

const st = (label: string, icon: IconName, fx: StationFx): WashStation => ({ label, icon, fx });
const FINISH = st('Finish', 'flag', 'sparkle');

const EXTERIOR_WASH: WashStation[] = [
  st('Pre-rinse', 'water', 'water'),
  st('Snow foam', 'snow', 'foam'),
  st('Wheels', 'disc', 'wheels'),
  st('Hand wash', 'hand-left', 'mitt'),
  st('Rinse', 'rainy', 'water'),
  st('Dry', 'sunny', 'air'),
  st('Glass', 'tablet-landscape-outline', 'scan'),
  FINISH,
];

const LIGHT_INTERIOR: WashStation[] = [
  st('Tidy up', 'file-tray-outline', 'sparkle'),
  st('Vacuum', 'aperture-outline', 'vacuum'),
  st('Wipe-down', 'hand-left', 'mitt'),
  st('Glass', 'tablet-landscape-outline', 'scan'),
  FINISH,
];

/** Stations per catalogue package, in the order each description lists the work. */
const PLANS: Record<string, WashStation[]> = {
  'bronze-wash': EXTERIOR_WASH,
  'silver-wash': [
    st('Pre-rinse', 'water', 'water'),
    st('Hand wash', 'hand-left', 'mitt'),
    st('Wheels', 'disc', 'wheels'),
    st('Dry', 'sunny', 'air'),
    st('Vacuum', 'aperture-outline', 'vacuum'),
    st('Dashboard', 'speedometer-outline', 'mitt'),
    st('Glass', 'tablet-landscape-outline', 'scan'),
    st('Tyre shine', 'ellipse-outline', 'wheels'),
    FINISH,
  ],
  'gold-wash': [
    st('Deep vacuum', 'aperture-outline', 'vacuum'),
    st('Stains', 'color-wand-outline', 'dab'),
    st('Shampoo', 'water-outline', 'foam'),
    st('Surfaces', 'hand-left', 'mitt'),
    st('Leather', 'shirt-outline', 'mitt'),
    st('Headliner', 'arrow-up-circle-outline', 'scan'),
    st('Glass', 'tablet-landscape-outline', 'scan'),
    st('Freshen', 'leaf-outline', 'mist'),
    FINISH,
  ],
  'platinum-wash': [
    st('Pre-rinse', 'water', 'water'),
    st('Snow foam', 'snow', 'foam'),
    st('Arches', 'disc', 'wheels'),
    st('Hand wash', 'hand-left', 'mitt'),
    st('Dry', 'sunny', 'air'),
    st('Deep vacuum', 'aperture-outline', 'vacuum'),
    st('Shampoo', 'water-outline', 'foam'),
    st('Trims & glass', 'tablet-landscape-outline', 'scan'),
    FINISH,
  ],
  'emerald-wash': [
    st('Snow foam', 'snow', 'foam'),
    st('Hand wash', 'hand-left', 'mitt'),
    st('Decon', 'flask-outline', 'mist'),
    st('Dry', 'sunny', 'air'),
    st('Polish', 'color-filter-outline', 'polisher'),
    st('Protect', 'shield-checkmark-outline', 'mist'),
    st('Deep interior', 'aperture-outline', 'vacuum'),
    st('Leather care', 'shirt-outline', 'mitt'),
    FINISH,
  ],
  'ceramic-coating': [
    st('Wash', 'water', 'foam'),
    st('Decon', 'flask-outline', 'mist'),
    st('Paint prep', 'search-outline', 'scan'),
    st('Correction', 'color-filter-outline', 'polisher'),
    st('Coating', 'shield-checkmark-outline', 'mist'),
    st('Curing', 'sunny-outline', 'scan'),
    FINISH,
  ],
  'machine-polishing': [
    st('Wash', 'water', 'foam'),
    st('Decon', 'flask-outline', 'mist'),
    st('Inspect', 'search-outline', 'scan'),
    st('Cut', 'color-filter-outline', 'polisher'),
    st('Refine', 'sparkles-outline', 'polisher'),
    st('Seal', 'shield-checkmark-outline', 'mist'),
    FINISH,
  ],
  'soft-top-restoration': [
    st('Gentle wash', 'water', 'water'),
    st('Mould treat', 'medkit-outline', 'mist'),
    st('Clean fabric', 'brush-outline', 'mitt'),
    st('Condition', 'color-palette-outline', 'mitt'),
    st('Waterproof', 'umbrella-outline', 'mist'),
    st('Seals check', 'search-outline', 'scan'),
    FINISH,
  ],
  'mould-removal': [
    st('Inspect', 'search-outline', 'scan'),
    st('Air-con', 'snow-outline', 'mist'),
    st('Treat mould', 'medkit-outline', 'mist'),
    st('Upholstery', 'shirt-outline', 'mitt'),
    st('De-odour', 'leaf-outline', 'mist'),
    FINISH,
  ],
  'maintenance-pack': [
    st('Oil check', 'speedometer-outline', 'tools'),
    st('Coolant', 'thermometer-outline', 'tools'),
    st('Screen wash', 'rainy-outline', 'tools'),
    st('Health check', 'search-outline', 'scan'),
    st('Tyres', 'disc', 'wheels'),
    FINISH,
  ],
  'headlight-restoration': [
    st('Inspect', 'search-outline', 'scan'),
    st('Prep', 'hand-left', 'mitt'),
    st('Remove haze', 'bulb-outline', 'polisher'),
    st('Polish', 'sparkles-outline', 'polisher'),
    st('UV seal', 'shield-checkmark-outline', 'mist'),
    st('Lights on', 'bulb', 'headlights'),
    FINISH,
  ],
  'scratch-removal': [
    st('Inspect', 'search-outline', 'scan'),
    st('Clean area', 'water', 'mitt'),
    st('Correct', 'color-filter-outline', 'polisher'),
    st('Refine', 'sparkles-outline', 'polisher'),
    st('Protect', 'shield-checkmark-outline', 'mist'),
    FINISH,
  ],
  'paint-chip-repair': [
    st('Clean', 'water', 'mitt'),
    st('Rust treat', 'medkit-outline', 'dab'),
    st('Touch-in', 'color-palette-outline', 'dab'),
    st('Level & seal', 'shield-checkmark-outline', 'mist'),
    FINISH,
  ],
  'trim-restoration': [
    st('Clean trim', 'hand-left', 'mitt'),
    st('Treat fade', 'color-wand-outline', 'dab'),
    st('Restore', 'albums-outline', 'mitt'),
    st('UV protect', 'shield-checkmark-outline', 'mist'),
    FINISH,
  ],
  'leather-repair': [
    st('Assess', 'search-outline', 'scan'),
    st('Clean', 'hand-left', 'mitt'),
    st('Repair', 'build-outline', 'dab'),
    st('Colour blend', 'color-palette-outline', 'dab'),
    st('Condition', 'shirt-outline', 'mitt'),
    FINISH,
  ],
};

const DETAIL_IDS = new Set(detailingServiceOptions.map((o) => o.id));
const REPAIR_IDS = new Set([...repairServiceOptions.map((o) => o.id), 'maintenance-check']);

const GENERIC: Record<JobKind, WashStation[]> = {
  wash: EXTERIOR_WASH,
  detail: [
    st('Prep', 'water', 'water'),
    st('Decon', 'flask-outline', 'mist'),
    st('Interior', 'aperture-outline', 'vacuum'),
    st('Polish', 'color-filter-outline', 'polisher'),
    st('Protect', 'shield-checkmark-outline', 'mist'),
    FINISH,
  ],
  repair: [
    st('Inspect', 'search-outline', 'scan'),
    st('Prep', 'hand-left', 'mitt'),
    st('Repair', 'build-outline', 'tools'),
    st('Check', 'checkmark-done-outline', 'scan'),
    FINISH,
  ],
};

export function jobKindFor(serviceId: string | null | undefined, isDetailing: boolean): JobKind {
  const id = serviceId ? (LEGACY_ECO_SERVICE_ID_MAP[serviceId] ?? serviceId) : '';
  if (REPAIR_IDS.has(id)) return 'repair';
  if (DETAIL_IDS.has(id) || isDetailing) return 'detail';
  return 'wash';
}

/** Stations for a booking, following what its package says is included. */
export function stationsForService(
  serviceId: string | null | undefined,
  washType: string | null | undefined,
  kind: JobKind
): WashStation[] {
  const id = serviceId ? (LEGACY_ECO_SERVICE_ID_MAP[serviceId] ?? serviceId) : '';
  if (id === 'bronze-wash' && washType === 'interior') return LIGHT_INTERIOR;
  return PLANS[id] ?? GENERIC[kind];
}

/**
 * Midpoint of a duration label like "20–35 min", "60–90 mins" or "2–3 hours".
 * Returns null when the label can't be read.
 */
export function minutesFromDurationLabel(label: string | null | undefined): number | null {
  if (!label) return null;
  const m = label.match(/(\d+(?:\.\d+)?)\s*(?:[–-]\s*(\d+(?:\.\d+)?))?\s*(h|hr|hrs|hour|hours|m|min|mins|minutes)\b/i);
  if (!m) return null;
  const lo = Number(m[1]);
  const hi = m[2] ? Number(m[2]) : lo;
  const unitIsHours = /^h/i.test(m[3] ?? '');
  const mid = (lo + hi) / 2;
  const minutes = unitIsHours ? mid * 60 : mid;
  return Number.isFinite(minutes) && minutes > 0 ? minutes : null;
}

/** 0..1 progress through the job, held just short of the finish until the Pro marks it done. */
export function washJourneyProgress(startedAtMs: number, estimateMs: number, nowMs: number): number {
  if (!Number.isFinite(startedAtMs) || estimateMs <= 0) return 0;
  return Math.max(0, Math.min(0.999, (nowMs - startedAtMs) / estimateMs));
}
