import AsyncStorage from '@react-native-async-storage/async-storage';
import type { Ionicons } from '@expo/vector-icons';

/** Must match `app/owner/settings/saved-locations.tsx` storage key root. */
export const CUSTOMER_SAVED_LOCATIONS_KEY = 'customer_saved_locations';

/** Saved-location id (or `'current'`) chosen in the dashboard "Wash at" picker. */
export const DASHBOARD_WASH_LOCATION_KEY = 'dashboard_wash_location';
export const CURRENT_LOCATION_ID = 'current';

export type CustomerSavedLocationLabelId = 'home' | 'work' | 'gym' | 'other';

/** Optional per-address details the customer can add, edit or clear. */
export type CustomerSavedLocationDetails = {
  /** Flat / house number or building name. */
  unit?: string;
  /** Where the car is usually parked (e.g. "Driveway", "Bay 14"). */
  parking?: string;
  /** Gate codes, access instructions or anything the Pro should know. */
  notes?: string;
};

export type CustomerSavedLocation = {
  id: string;
  label: CustomerSavedLocationLabelId;
  customLabel?: string;
  address: string;
  latitude: number;
  longitude: number;
  details?: CustomerSavedLocationDetails;
};

export const SAVED_LOCATION_DETAIL_FIELDS: {
  key: keyof CustomerSavedLocationDetails;
  label: string;
  placeholder: string;
  icon: keyof typeof Ionicons.glyphMap;
  multiline?: boolean;
}[] = [
  { key: 'unit', label: 'Flat / house no.', placeholder: 'e.g. Flat 4B', icon: 'business-outline' },
  { key: 'parking', label: 'Parking', placeholder: 'e.g. Driveway, bay 14', icon: 'car-outline' },
  { key: 'notes', label: 'Notes for your Pro', placeholder: 'Gate code, access, water tap…', icon: 'document-text-outline', multiline: true },
];

/** Trims values and drops empty fields; returns `undefined` when nothing is left. */
export function cleanSavedLocationDetails(
  details?: CustomerSavedLocationDetails | null
): CustomerSavedLocationDetails | undefined {
  if (!details) return undefined;
  const out: CustomerSavedLocationDetails = {};
  for (const f of SAVED_LOCATION_DETAIL_FIELDS) {
    const v = details[f.key]?.trim();
    if (v) out[f.key] = v;
  }
  return Object.keys(out).length ? out : undefined;
}

/** One-line summary of the details, e.g. "Flat 4B · Driveway". */
export function savedLocationDetailsSummary(details?: CustomerSavedLocationDetails): string {
  if (!details) return '';
  return [details.unit, details.parking, details.notes].filter(Boolean).join(' · ');
}

export const SAVED_LOCATION_LABEL_META: Record<
  CustomerSavedLocationLabelId,
  { title: string; icon: keyof typeof Ionicons.glyphMap }
> = {
  home: { title: 'Home', icon: 'home' },
  work: { title: 'Work', icon: 'briefcase' },
  gym: { title: 'Gym', icon: 'barbell' },
  other: { title: 'Other', icon: 'location' },
};

export function savedLocationTitle(loc: CustomerSavedLocation): string {
  if (loc.label === 'other' && loc.customLabel) return loc.customLabel;
  return SAVED_LOCATION_LABEL_META[loc.label]?.title ?? loc.customLabel ?? 'Saved';
}

export function savedLocationIcon(loc: CustomerSavedLocation): keyof typeof Ionicons.glyphMap {
  return SAVED_LOCATION_LABEL_META[loc.label]?.icon ?? 'location';
}

export async function loadCustomerSavedLocations(userId: string): Promise<CustomerSavedLocation[]> {
  try {
    const raw = await AsyncStorage.getItem(`${CUSTOMER_SAVED_LOCATIONS_KEY}_${userId}`);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as unknown;
    return Array.isArray(parsed) ? (parsed as CustomerSavedLocation[]) : [];
  } catch {
    return [];
  }
}

/** Notes for addresses that aren't saved places, keyed by rounded coordinates (~10 m). */
const ADDRESS_NOTES_KEY = 'customer_address_notes';
const NEARBY_SAVED_METERS = 40;

function coordKey(lat: number, lng: number) {
  return `${lat.toFixed(4)},${lng.toFixed(4)}`;
}

function metersBetween(aLat: number, aLng: number, bLat: number, bLng: number) {
  const R = 6371000;
  const dLat = ((bLat - aLat) * Math.PI) / 180;
  const dLng = ((bLng - aLng) * Math.PI) / 180;
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((aLat * Math.PI) / 180) * Math.cos((bLat * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

export function findSavedLocationNear(
  list: CustomerSavedLocation[],
  latitude: number,
  longitude: number
): CustomerSavedLocation | null {
  let best: CustomerSavedLocation | null = null;
  let bestDist = NEARBY_SAVED_METERS;
  for (const l of list) {
    const d = metersBetween(latitude, longitude, l.latitude, l.longitude);
    if (d <= bestDist) {
      best = l;
      bestDist = d;
    }
  }
  return best;
}

async function loadAddressNotesMap(userId: string): Promise<Record<string, string>> {
  try {
    const raw = await AsyncStorage.getItem(`${ADDRESS_NOTES_KEY}_${userId}`);
    const parsed = raw ? (JSON.parse(raw) as unknown) : null;
    return parsed && typeof parsed === 'object' ? (parsed as Record<string, string>) : {};
  } catch {
    return {};
  }
}

/** The remembered booking note for an address, plus the saved place it belongs to (if any). */
export async function loadAddressNote(
  userId: string,
  latitude: number,
  longitude: number
): Promise<{ note: string; savedLocation: CustomerSavedLocation | null }> {
  const list = await loadCustomerSavedLocations(userId);
  const savedLocation = findSavedLocationNear(list, latitude, longitude);
  if (savedLocation) return { note: savedLocation.details?.notes ?? '', savedLocation };
  const map = await loadAddressNotesMap(userId);
  return { note: map[coordKey(latitude, longitude)] ?? '', savedLocation: null };
}

/** Saves (or, with an empty string, removes) the remembered booking note for an address. */
export async function saveAddressNote(
  userId: string,
  latitude: number,
  longitude: number,
  note: string
): Promise<void> {
  const value = note.trim();
  const list = await loadCustomerSavedLocations(userId);
  const savedLocation = findSavedLocationNear(list, latitude, longitude);
  if (savedLocation) {
    const next = list.map((l) => {
      if (l.id !== savedLocation.id) return l;
      const details = cleanSavedLocationDetails({ ...l.details, notes: value });
      const updated: CustomerSavedLocation = { ...l };
      if (details) updated.details = details;
      else delete updated.details;
      return updated;
    });
    await AsyncStorage.setItem(`${CUSTOMER_SAVED_LOCATIONS_KEY}_${userId}`, JSON.stringify(next));
    return;
  }
  const map = await loadAddressNotesMap(userId);
  const key = coordKey(latitude, longitude);
  if (value) map[key] = value;
  else delete map[key];
  await AsyncStorage.setItem(`${ADDRESS_NOTES_KEY}_${userId}`, JSON.stringify(map));
}

/** Returns the saved location picked on the dashboard, or `null` when "Current location" is chosen. */
export async function loadDashboardWashLocation(userId: string): Promise<CustomerSavedLocation | null> {
  try {
    const id = await AsyncStorage.getItem(`${DASHBOARD_WASH_LOCATION_KEY}_${userId}`);
    if (!id || id === CURRENT_LOCATION_ID) return null;
    const list = await loadCustomerSavedLocations(userId);
    return list.find((l) => l.id === id) ?? null;
  } catch {
    return null;
  }
}

export async function saveDashboardWashLocationId(userId: string, id: string): Promise<void> {
  await AsyncStorage.setItem(`${DASHBOARD_WASH_LOCATION_KEY}_${userId}`, id).catch(() => {});
}
