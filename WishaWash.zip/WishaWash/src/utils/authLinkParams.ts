/** Reads params from both the query string and the `#fragment` Supabase uses for tokens. */
export function readLinkParams(url: string | null): Record<string, string> {
  const out: Record<string, string> = {};
  if (!url) return out;
  const collect = (part: string | undefined) => {
    if (!part) return;
    for (const pair of part.split('&')) {
      const [k, v = ''] = pair.split('=');
      if (k) out[decodeURIComponent(k)] = decodeURIComponent(v.replace(/\+/g, ' '));
    }
  };
  const [beforeHash, hash] = url.split('#');
  collect(beforeHash?.split('?')[1]);
  collect(hash);
  return out;
}
