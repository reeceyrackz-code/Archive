import AsyncStorage from '@react-native-async-storage/async-storage';

/** A pro the customer has saved (heart). Lives on-device only; shared by Explore and the dashboard. */
export type SavedProRow = {
  id: string;
  valeter_id: string;
  valeter_profiles?: {
    user_id: string;
    full_name?: string | null;
    profile_photo_url?: string | null;
    specializations?: string[];
  } | null;
  rating?: number;
  totalJobs?: number;
  specializations?: string[];
};

export type SavedProSnapshot = {
  id: string;
  name?: string | null;
  profilePicture?: string | null;
  rating?: number;
  totalJobs?: number;
  specializations?: string[];
};

const savedProsStorageKey = (userId: string) => `explore:savedValeters:${userId}`;

export async function readSavedPros(userId: string): Promise<SavedProRow[]> {
  try {
    const raw = await AsyncStorage.getItem(savedProsStorageKey(userId));
    const parsed = raw ? (JSON.parse(raw) as unknown) : [];
    return Array.isArray(parsed) ? (parsed as SavedProRow[]).filter((f) => f && typeof f.valeter_id === 'string') : [];
  } catch {
    return [];
  }
}

export function writeSavedPros(userId: string, rows: SavedProRow[]) {
  void AsyncStorage.setItem(savedProsStorageKey(userId), JSON.stringify(rows)).catch(() => {});
}

/** Returns the list with `pro` added (or removed if already saved). Caller persists via `writeSavedPros`. */
export function toggleSavedProRow(rows: SavedProRow[], pro: SavedProSnapshot): SavedProRow[] {
  const rest = rows.filter((f) => f.valeter_id !== pro.id);
  if (rest.length !== rows.length) return rest;
  return [
    ...rest,
    {
      id: pro.id,
      valeter_id: pro.id,
      rating: pro.rating ?? 0,
      totalJobs: pro.totalJobs ?? 0,
      specializations: pro.specializations ?? [],
      valeter_profiles: {
        user_id: pro.id,
        full_name: pro.name ?? null,
        profile_photo_url: pro.profilePicture ?? null,
      },
    },
  ];
}
