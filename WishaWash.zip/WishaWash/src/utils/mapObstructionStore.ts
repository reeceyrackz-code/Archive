/**
 * Registry of on-screen bottom sheets (window coordinates) so every map can keep its
 * Apple / Google legal label and logo above whatever sheet is covering it.
 */
export type ObstructionRect = Readonly<{ top: number; bottom: number }>;

const entries = new Map<string, ObstructionRect>();
const listeners = new Set<() => void>();
let version = 0;
let nextId = 0;

function emit() {
  version += 1;
  listeners.forEach((l) => l());
}

export function createObstructionId(): string {
  nextId += 1;
  return `obstruction-${nextId}`;
}

export function setMapObstruction(id: string, rect: ObstructionRect | null) {
  const prev = entries.get(id);
  if (rect == null || rect.bottom - rect.top <= 1) {
    if (prev) {
      entries.delete(id);
      emit();
    }
    return;
  }
  if (prev && Math.abs(prev.top - rect.top) < 1 && Math.abs(prev.bottom - rect.bottom) < 1) return;
  entries.set(id, rect);
  emit();
}

export function subscribeMapObstructions(listener: () => void) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

export function getMapObstructionVersion() {
  return version;
}

/**
 * Height of the map (window rect top..bottom) hidden behind sheets that sit on its bottom edge.
 * Floating panels that don't reach the map's bottom edge are ignored.
 */
export function bottomOverlapForMap(mapTop: number, mapBottom: number): number {
  const mapHeight = mapBottom - mapTop;
  if (mapHeight <= 0) return 0;
  let overlap = 0;
  entries.forEach((rect) => {
    const reachesBottom = rect.bottom >= mapBottom - 4;
    if (!reachesBottom || rect.top >= mapBottom) return;
    overlap = Math.max(overlap, Math.min(mapHeight, mapBottom - Math.max(rect.top, mapTop)));
  });
  return overlap;
}
