import { useEffect, useMemo, useRef, useState } from 'react';
import { distanceMiles } from './mapUtils';

type Coord = { latitude: number; longitude: number };

export type RoadRoute = Readonly<{
  coords: Coord[];
  miles: number;
  minutes: number;
  /** False while showing the curved placeholder (route not fetched, offline, or router failed). */
  onRoads: boolean;
}>;

/** Colour of every Pro → you route line. */
export const ROUTE_LINE_COLOR = '#89CFF0';

const OSRM_URL = 'https://router.project-osrm.org/route/v1/driving';
const FETCH_TIMEOUT_MS = 6000;
/** Re-route only once the Pro has moved this far from where the last route started. */
const REROUTE_MILES = 0.12;
/** Rough urban driving speed, used when the router gives no duration. */
const FALLBACK_MPH = 18;
const METERS_PER_MILE = 1609.344;

const cache = new Map<string, RoadRoute>();
const keyFor = (a: Coord, b: Coord) => [a.latitude, a.longitude, b.latitude, b.longitude].map((n) => n.toFixed(4)).join(',');

async function fetchRoadRoute(from: Coord, to: Coord): Promise<RoadRoute | null> {
  const key = keyFor(from, to);
  const hit = cache.get(key);
  if (hit) return hit;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
  try {
    const url = `${OSRM_URL}/${from.longitude},${from.latitude};${to.longitude},${to.latitude}?overview=full&geometries=geojson`;
    const res = await fetch(url, { signal: controller.signal });
    if (!res.ok) return null;
    const json = (await res.json()) as { routes?: { distance: number; duration: number; geometry: { coordinates: [number, number][] } }[] };
    const r = json.routes?.[0];
    if (!r || r.geometry.coordinates.length < 2) return null;
    const route: RoadRoute = {
      coords: r.geometry.coordinates.map(([lng, lat]) => ({ latitude: lat, longitude: lng })),
      miles: r.distance / METERS_PER_MILE,
      minutes: Math.max(1, Math.round(r.duration / 60)),
      onRoads: true,
    };
    if (cache.size > 40) cache.clear();
    cache.set(key, route);
    return route;
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

/** Gentle arc between two points — stands in for the road route until (or if) it loads. */
function curvedRoute(from: Coord, to: Coord): RoadRoute {
  const dLat = to.latitude - from.latitude;
  const dLng = to.longitude - from.longitude;
  const ctrl = { latitude: from.latitude + dLat / 2 - dLng * 0.18, longitude: from.longitude + dLng / 2 + dLat * 0.18 };
  const coords: Coord[] = [];
  for (let i = 0; i <= 24; i++) {
    const t = i / 24;
    const u = 1 - t;
    coords.push({
      latitude: u * u * from.latitude + 2 * u * t * ctrl.latitude + t * t * to.latitude,
      longitude: u * u * from.longitude + 2 * u * t * ctrl.longitude + t * t * to.longitude,
    });
  }
  const miles = distanceMiles(from, to) * 1.25;
  return { coords, miles, minutes: Math.max(1, Math.round((miles / FALLBACK_MPH) * 60)), onRoads: false };
}

/** Drop the part of the route the Pro has already driven, starting the line at their live position. */
function trimToPro(route: RoadRoute, pro: Coord): RoadRoute {
  let best = 0;
  let bestD = Infinity;
  route.coords.forEach((c, i) => {
    const d = distanceMiles(c, pro);
    if (d < bestD) {
      bestD = d;
      best = i;
    }
  });
  const coords = [pro, ...route.coords.slice(best + 1)];
  if (coords.length < 2) return route;
  let left = 0;
  for (let i = 1; i < coords.length; i++) left += distanceMiles(coords[i - 1]!, coords[i]!);
  const ratio = route.miles > 0 ? Math.min(1, left / route.miles) : 1;
  return { ...route, coords, miles: left, minutes: Math.max(1, Math.round(route.minutes * ratio)) };
}

/** Driving route from the Pro to the customer, kept fresh as the Pro moves. */
export function useRoadRoute(from: Coord | null, to: Coord | null): RoadRoute | null {
  const [fetched, setFetched] = useState<RoadRoute | null>(null);
  const originRef = useRef<{ from: Coord; to: Coord } | null>(null);
  const requestRef = useRef(0);

  useEffect(() => () => {
    requestRef.current = -1;
  }, []);

  useEffect(() => {
    if (!from || !to) {
      setFetched(null);
      originRef.current = null;
      return;
    }
    const origin = originRef.current;
    if (origin && distanceMiles(origin.from, from) < REROUTE_MILES && distanceMiles(origin.to, to) < REROUTE_MILES) return;
    originRef.current = { from, to };
    const id = ++requestRef.current;
    void fetchRoadRoute(from, to).then((r) => {
      if (r && requestRef.current === id) setFetched(r);
    });
  }, [from?.latitude, from?.longitude, to?.latitude, to?.longitude]);

  return useMemo(() => {
    if (!from || !to) return null;
    return fetched ? trimToPro(fetched, from) : curvedRoute(from, to);
  }, [fetched, from?.latitude, from?.longitude, to?.latitude, to?.longitude]);
}
