// Boot wrapper at app root: animated launch overlay that exits as soon as auth is restored.
import React from 'react';
import { useAuth } from '../providers/enhanced-auth-context';
import AppLaunchGate from '../components/loading/AppLaunchGate';

export function BootProvider({ children }: { children: React.ReactNode }) {
  const { authReady } = useAuth();

  return <AppLaunchGate startupReady={authReady}>{children}</AppLaunchGate>;
}
