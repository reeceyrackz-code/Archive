import * as Linking from 'expo-linking';
import { supabase } from '../lib/supabase';

export type SignupErrorCode =
  | 'already_registered'
  | 'weak_password'
  | 'invalid_email'
  | 'rate_limited'
  | 'network'
  | 'signup_disabled'
  | 'unknown';

export class SignupError extends Error {
  readonly code: SignupErrorCode;
  constructor(code: SignupErrorCode, message: string) {
    super(message);
    this.name = 'SignupError';
    this.code = code;
  }
}

const MESSAGES: Record<SignupErrorCode, string> = {
  already_registered: 'You already have an account with this email.',
  weak_password: 'That password is too easy to guess. Try a longer one.',
  invalid_email: "That email address doesn't look right.",
  rate_limited: 'Too many attempts. Please wait a minute and try again.',
  network: 'Connection problem. Check your signal and try again.',
  signup_disabled: 'Sign up is paused right now. Please try again later.',
  unknown: 'Could not create your account. Please try again.',
};

/** Deep link Supabase sends people back to after they tap the verification email. */
export function getEmailRedirectUrl(): string {
  return Linking.createURL('auth/callback');
}

export function toSignupError(raw: unknown): SignupError {
  if (raw instanceof SignupError) return raw;
  const err = (raw ?? {}) as { code?: string; message?: string; status?: number; name?: string };
  const code = String(err.code ?? '').toLowerCase();
  const msg = String(err.message ?? '').toLowerCase();

  let kind: SignupErrorCode = 'unknown';
  if (code === 'user_already_exists' || code === 'email_exists' || msg.includes('already registered')) {
    kind = 'already_registered';
  } else if (code === 'weak_password' || msg.includes('password should')) {
    kind = 'weak_password';
  } else if (code === 'email_address_invalid' || code === 'validation_failed' || msg.includes('invalid email')) {
    kind = 'invalid_email';
  } else if (err.status === 429 || code.includes('rate_limit') || msg.includes('rate limit')) {
    kind = 'rate_limited';
  } else if (code === 'signup_disabled' || msg.includes('signups not allowed')) {
    kind = 'signup_disabled';
  } else if (msg.includes('timeout') || msg.includes('network') || msg.includes('fetch')) {
    kind = 'network';
  }
  return new SignupError(kind, MESSAGES[kind]);
}

export function alreadyRegisteredError(): SignupError {
  return new SignupError('already_registered', MESSAGES.already_registered);
}

export async function resendSignupEmail(email: string): Promise<void> {
  const { error } = await supabase.auth.resend({
    type: 'signup',
    email: email.trim(),
    options: { emailRedirectTo: getEmailRedirectUrl() },
  });
  if (error) throw toSignupError(error);
}

/**
 * Held in memory only (never persisted) so the inbox screen can quietly sign in
 * once the email is verified on another device.
 */
let pendingSignup: { email: string; password: string } | null = null;

export function setPendingSignup(email: string, password: string): void {
  pendingSignup = { email: email.trim(), password };
}

export function getPendingSignup(): { email: string; password: string } | null {
  return pendingSignup;
}

export function clearPendingSignup(): void {
  pendingSignup = null;
}
