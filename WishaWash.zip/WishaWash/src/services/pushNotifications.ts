import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import Constants from 'expo-constants';
import type { useRouter } from 'expo-router';
import { supabase } from '../lib/supabase';

type Router = ReturnType<typeof useRouter>;

export const ANDROID_BOOKING_CHANNEL_ID = 'booking-updates';

let handlerConfigured = false;
let channelReady = false;

function isPushEnabledEnv(): boolean {
  const v = process.env.EXPO_PUBLIC_ENABLE_PUSH_NOTIFICATIONS;
  return v !== 'false' && Platform.OS !== 'web';
}

/** Android 8+ channel: high importance + default sound + vibration */
export async function ensureAndroidBookingChannel(): Promise<void> {
  if (Platform.OS !== 'android' || channelReady) return;
  await Notifications.setNotificationChannelAsync(ANDROID_BOOKING_CHANNEL_ID, {
    name: 'Booking & service updates',
    importance: Notifications.AndroidImportance.HIGH,
    vibrationPattern: [0, 250, 250, 250],
    sound: 'default',
    enableVibrate: true,
    showBadge: true,
  });
  channelReady = true;
}

export function configureNotificationHandler(): void {
  if (handlerConfigured) return;
  handlerConfigured = true;
  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldShowAlert: true,
      shouldPlaySound: true,
      shouldSetBadge: true,
      shouldShowBanner: true,
      shouldShowList: true,
    }),
  });
}

let registeredKey: string | null = null;
let inFlight: Promise<string | null> | null = null;

export function registerPushTokenWithSupabase(): Promise<string | null> {
  if (!isPushEnabledEnv()) return Promise.resolve(null);
  inFlight ??= doRegisterPushToken().finally(() => {
    inFlight = null;
  });
  return inFlight;
}

async function doRegisterPushToken(): Promise<string | null> {
  try {
    await ensureAndroidBookingChannel();
    const { status: existing } = await Notifications.getPermissionsAsync();
    let finalStatus = existing;
    if (existing !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync({
        ios: {
          allowAlert: true,
          allowBadge: true,
          allowSound: true,
        },
      });
      finalStatus = status;
    }
    if (finalStatus !== 'granted') return null;

    const projectId =
      Constants.expoConfig?.extra?.eas?.projectId ?? process.env.EXPO_PUBLIC_EXPO_PROJECT_ID;
    const token = (
      await Notifications.getExpoPushTokenAsync(
        projectId ? { projectId: String(projectId) } : undefined
      )
    ).data;

    const session = (await supabase.auth.getSession()).data.session;
    const userId = session?.user?.id;
    if (!userId || !token) return null;
    const key = `${userId}:${token}`;
    if (registeredKey === key) return token;

    const row = {
      user_id: userId,
      expo_push_token: token,
      platform: Platform.OS as 'ios' | 'android' | 'web',
      updated_at: new Date().toISOString(),
    };

    const { error } = await supabase.from('user_devices').upsert(row, {
      onConflict: 'user_id,expo_push_token',
    });
    if (error) {
      if (__DEV__) console.warn('[push] user_devices upsert:', error.message);
    } else {
      registeredKey = key;
    }
    return token;
  } catch (e) {
    if (__DEV__) console.warn('[push] registerPushTokenWithSupabase', e);
    return null;
  }
}

export function openNotificationFromPushData(router: Router, data: Record<string, unknown> | undefined) {
  if (!data || typeof data !== 'object') return;

  const screen = typeof data.screen === 'string' ? data.screen : '';
  if (screen) {
    router.push({
      pathname: screen as any,
      params: typeof data.params === 'object' && data.params ? (data.params as Record<string, string>) : undefined,
    } as any);
    return;
  }

  const bookingId =
    (typeof data.bookingId === 'string' && data.bookingId) ||
    (typeof data.booking_id === 'string' && data.booking_id);
  if (!bookingId) return;
  const type = typeof data.type === 'string' ? data.type : '';
  if (type === 'booking_completed' || data.screen === 'completion') {
    router.push({
      pathname: '/owner/booking/completion',
      params: { bookingId, celebrated: '1' },
    } as any);
    return;
  }
  router.push({
    pathname: '/owner/booking/tracking',
    params: { bookingId },
  } as any);
}

export function subscribePushNotificationResponse(router: Router): () => void {
  const sub = Notifications.addNotificationResponseReceivedListener((response) => {
    const data = response.notification.request.content.data;
    openNotificationFromPushData(router, data);
  });
  return () => sub.remove();
}

/**
 * Register for Expo push, Android channel, and tap-to-open booking routes.
 * Call once when the user is signed in (not web). Returns cleanup for listeners.
 */
export function initPushNotifications(router: Router): () => void {
  if (!isPushEnabledEnv()) return () => {};
  configureNotificationHandler();
  void (async () => {
    await ensureAndroidBookingChannel();
    await registerPushTokenWithSupabase();
  })();

  const removeResponse = subscribePushNotificationResponse(router);
  const tokenSub = Notifications.addPushTokenListener(() => {
    void registerPushTokenWithSupabase();
  });

  return () => {
    removeResponse();
    tokenSub.remove();
  };
}
