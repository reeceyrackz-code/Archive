import { supabase } from '../lib/supabase';
import { grantCompletedBookingLoyalty } from './LoyaltyService';

type StripeLike = {
  initPaymentSheet: (params: Record<string, unknown>) => Promise<{ error?: { message?: string } | null }>;
  presentPaymentSheet: () => Promise<{ error?: { code?: string; message?: string } | null }>;
};

/** Charges a tip on the booking via the Stripe payment sheet. Returns false if the customer cancelled. */
export async function payBookingTip(
  stripe: StripeLike | null | undefined,
  opts: Readonly<{ bookingId: string; customerId: string; amount: number; description: string }>,
): Promise<boolean> {
  if (!stripe?.presentPaymentSheet) throw new Error('Tip payment is not supported on this device.');
  const { data, error } = await supabase.functions.invoke('booking-extra-charge', {
    body: {
      action: 'create_payment_intent',
      bookingId: opts.bookingId,
      amount: Math.round(opts.amount * 100),
      currency: 'gbp',
      customerId: opts.customerId,
      description: opts.description,
    },
  });
  if (error) throw error;
  const cs =
    data?.clientSecret ??
    data?.client_secret ??
    data?.paymentIntentClientSecret ??
    data?.payment_intent_client_secret ??
    data?.paymentIntent?.clientSecret ??
    data?.paymentIntent?.client_secret;
  if (!cs) throw new Error('No payment secret returned');
  const { error: initErr } = await stripe.initPaymentSheet({
    paymentIntentClientSecret: cs,
    merchantDisplayName: 'Wish a Wash',
    returnURL: 'waw://stripe-redirect',
    style: 'automatic',
  });
  if (initErr) throw new Error(initErr.message || 'Could not start payment');
  const { error: presentErr } = await stripe.presentPaymentSheet();
  if (presentErr) {
    if (presentErr.code === 'Canceled') return false;
    throw new Error(presentErr.message || 'Payment failed');
  }
  await supabase.from('bookings').update({ tip_amount: opts.amount }).eq('id', opts.bookingId);
  return true;
}

/** Saves the customer's rating on the booking and the Pro's reviews, then syncs loyalty points. */
export async function submitBookingReview(
  opts: Readonly<{ bookingId: string; customerId: string; valeterId: string | null; rating: number; comment: string | null; tip: number }>,
): Promise<{ loyaltyBalance: number | null }> {
  const { error } = await supabase
    .from('bookings')
    .update({ rating: opts.rating, review: opts.comment, tip_amount: opts.tip })
    .eq('id', opts.bookingId);
  if (error) throw error;

  if (opts.valeterId) {
    const { error: reviewError } = await supabase.from('reviews').upsert(
      {
        booking_id: opts.bookingId,
        customer_profile_id: opts.customerId,
        valeter_profile_id: opts.valeterId,
        rating: opts.rating,
        comment: opts.comment,
      },
      { onConflict: 'booking_id' },
    );
    if (reviewError) console.warn('[BookingReview] review upsert failed:', reviewError.message);
  }

  try {
    const loyalty = await grantCompletedBookingLoyalty(opts.customerId, opts.bookingId);
    return { loyaltyBalance: loyalty.customerBalance >= 0 ? loyalty.customerBalance : null };
  } catch (e) {
    console.warn('[BookingReview] loyalty sync failed:', e);
    return { loyaltyBalance: null };
  }
}
