import React, { useEffect, useRef, useState } from 'react';
import { View, Text, ActivityIndicator, StyleSheet, TouchableOpacity } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import * as Linking from 'expo-linking';
import type { EmailOtpType } from '@supabase/supabase-js';
import { supabase } from '../../src/lib/supabase';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { clearPendingSignup } from '../../src/services/EmailVerificationService';
import { readLinkParams } from '../../src/utils/authLinkParams';

const SESSION_WAIT_MS = 8000;
const NO_LINK_FALLBACK_MS = 1500;
const EMAIL_LINK_TYPES = new Set(['signup', 'email', 'magiclink', 'invite', 'email_change']);

export default function AuthCallbackScreen() {
  const params = useLocalSearchParams();
  const url = Linking.useURL();
  const { user } = useAuth();
  const [message, setMessage] = useState('Completing sign in...');
  const [failed, setFailed] = useState(false);
  const [sessionReady, setSessionReady] = useState(false);
  const handledRef = useRef(false);

  useEffect(() => {
    if (handledRef.current) return;
    let cancelled = false;

    const finish = async () => {
      const link = readLinkParams(url);
      const pick = (key: string) =>
        (typeof params[key] === 'string' ? (params[key] as string) : undefined) ?? link[key];

      const code = pick('code');
      const accessToken = pick('access_token');
      const refreshToken = pick('refresh_token');
      const tokenHash = pick('token_hash');
      const type = (pick('type') ?? '').toLowerCase();
      const linkError = pick('error_description') ?? pick('error');
      const isRecovery = type === 'recovery' || type === 'password_recovery';
      const isEmailLink = Boolean(tokenHash) || EMAIL_LINK_TYPES.has(type);

      // Wait for the opening URL before deciding there is nothing to handle.
      if (!code && !accessToken && !tokenHash && !linkError && url === null) return;
      handledRef.current = true;

      try {
        if (linkError) {
          throw new Error(
            /expired|invalid/i.test(linkError)
              ? 'This link has expired or was already used. Sign in, or request a new verification email.'
              : linkError
          );
        }
        if ((isEmailLink || isRecovery) && accessToken && refreshToken) {
          const { error } = await supabase.auth.setSession({ access_token: accessToken, refresh_token: refreshToken });
          if (error) throw error;
        } else if (tokenHash) {
          const { error } = await supabase.auth.verifyOtp({
            token_hash: tokenHash,
            type: (isRecovery ? 'recovery' : type || 'signup') as EmailOtpType,
          });
          if (error) throw error;
        } else if (code) {
          const { error } = await supabase.auth.exchangeCodeForSession(code);
          if (error) throw error;
        }

        if (cancelled) return;
        if (isRecovery) {
          router.replace({ pathname: '/reset-password', params: { ready: '1' } } as any);
          return;
        }
        if (isEmailLink) {
          clearPendingSignup();
          setMessage('Email verified! Signing you in...');
          setSessionReady(true);
          return;
        }
        router.replace('/');
      } catch (error: any) {
        if (!cancelled) {
          setMessage(error?.message || 'Unable to complete sign in.');
          setFailed(true);
        }
      }
    };

    void finish();
    return () => {
      cancelled = true;
    };
  }, [params, url]);

  useEffect(() => {
    const t = setTimeout(() => {
      if (handledRef.current) return;
      handledRef.current = true;
      router.replace('/');
    }, NO_LINK_FALLBACK_MS);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    if (!sessionReady) return;
    if (user) {
      router.replace('/');
      return;
    }
    const t = setTimeout(() => router.replace('/'), SESSION_WAIT_MS);
    return () => clearTimeout(t);
  }, [sessionReady, user]);

  return (
    <View style={styles.container}>
      {failed ? null : <ActivityIndicator color="#87CEEB" />}
      <Text style={styles.text}>{message}</Text>
      {failed ? (
        <TouchableOpacity style={styles.button} onPress={() => router.replace('/auth/login' as any)} activeOpacity={0.85}>
          <Text style={styles.buttonText}>Go to sign in</Text>
        </TouchableOpacity>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
    backgroundColor: '#0A1929',
    gap: 16,
  },
  text: {
    color: '#F9FAFB',
    textAlign: 'center',
    fontSize: 16,
    lineHeight: 22,
  },
  button: {
    marginTop: 8,
    paddingHorizontal: 22,
    height: 44,
    borderRadius: 999,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(56,189,248,0.18)',
  },
  buttonText: {
    color: '#E0F2FE',
    fontSize: 14,
    fontWeight: '700',
  },
});
