import React, { useEffect, useState } from 'react';
import { Alert, Platform } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as AppleAuthentication from 'expo-apple-authentication';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AuthLandingShell from '../../src/components/auth/AuthLandingShell';
import AuthEmailSheet from '../../src/components/auth/AuthEmailSheet';
import AuthResetPasswordSheet from '../../src/components/auth/AuthResetPasswordSheet';
import { resolvePostAuthRoute } from '../../src/utils/profileSetupGate';

const SESSION_KEY = 'user_session';
const RESET_COOLDOWN_MS = 60_000;
/** Outlives the sheet so closing and reopening it doesn't reset the countdown. */
const resetCooldownUntil: Record<string, number> = {};

function resetSecondsLeft(email: string): number {
  const until = resetCooldownUntil[email.trim().toLowerCase()] ?? 0;
  return Math.max(0, Math.ceil((until - Date.now()) / 1000));
}

function friendlyResetError(err: any): string {
  const msg = String(err?.message ?? '').toLowerCase();
  if (err?.status === 429 || msg.includes('rate limit') || msg.includes('security purposes')) {
    return 'Too many emails sent right now. Please try again later.';
  }
  if (msg.includes('timeout') || msg.includes('network') || msg.includes('fetch')) {
    return 'Connection problem. Check your signal and try again.';
  }
  return 'Could not send reset email. Please try again.';
}

export default function LoginScreen() {
  const { login, loginWithApple, loginWithGoogle, resetPassword, user } = useAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [resetEmail, setResetEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [resetLoading, setResetLoading] = useState(false);
  const [resetError, setResetError] = useState<string | null>(null);
  const [resetSent, setResetSent] = useState(false);
  const isAppleAvailable = Platform.OS === 'ios';
  const [emailSheetVisible, setEmailSheetVisible] = useState(false);
  const [resetSheetVisible, setResetSheetVisible] = useState(false);


  const finishRouting = async () => {
    let sessionUser = user;
    try {
      const raw = await AsyncStorage.getItem(SESSION_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed?.id) sessionUser = parsed;
      }
    } catch {
      /* keep context user */
    }

    if (!sessionUser?.id) {
      router.replace('/owner/owner-dashboard');
      return;
    }
    const dest = await resolvePostAuthRoute(sessionUser);
    router.replace(dest);
  };

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert('Error', 'Please enter both email and password');
      return;
    }

    await hapticFeedback('medium');
    setIsLoading(true);

    try {
      const ok = await login(email.trim(), password);
      if (!ok) {
        Alert.alert('Login Failed', 'Invalid email or password.');
        return;
      }

      setEmailSheetVisible(false);
      // Read latest session user from storage via a short tick — auth context updates async.
      // Prefer resolve after login returns; user state may lag one frame.
      await finishRouting();
    } catch {
      Alert.alert('Login Failed', 'Something went wrong. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const openResetSheet = () => {
    setResetEmail(email.trim());
    setResetError(null);
    setResetSent(false);
    setEmailSheetVisible(false);
    setResetSheetVisible(true);
  };

  // Arriving from an expired reset link opens the reset sheet straight away.
  const { reset: resetParam } = useLocalSearchParams<{ reset?: string }>();
  useEffect(() => {
    if (resetParam === '1') openResetSheet();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [resetParam]);

  const closeResetSheet = () => {
    setResetSheetVisible(false);
    setResetError(null);
    setResetSent(false);
  };

  const backToSignIn = () => {
    closeResetSheet();
    setEmailSheetVisible(true);
  };

  const [resendIn, setResendIn] = useState(0);
  useEffect(() => {
    if (!resetSheetVisible) return;
    const tick = () => setResendIn(resetSecondsLeft(resetEmail));
    tick();
    const t = setInterval(tick, 1000);
    return () => clearInterval(t);
  }, [resetSheetVisible, resetEmail]);

  const handleResetPassword = async () => {
    const trimmed = resetEmail.trim();
    if (!trimmed || !trimmed.includes('@')) {
      setResetError('Please enter a valid email address');
      return;
    }
    if (resetSecondsLeft(trimmed) > 0) return;
    await hapticFeedback('medium');
    setResetLoading(true);
    setResetError(null);

    try {
      await resetPassword(trimmed);
      resetCooldownUntil[trimmed.toLowerCase()] = Date.now() + RESET_COOLDOWN_MS;
      setResendIn(resetSecondsLeft(trimmed));
      setResetSent(true);
      if (!email.trim()) setEmail(trimmed);
    } catch (err: any) {
      setResetError(friendlyResetError(err));
    } finally {
      setResetLoading(false);
    }
  };

  const handleAppleLogin = async () => {
    try {
      await hapticFeedback('light');
      setIsLoading(true);

      const credential = await AppleAuthentication.signInAsync({
        requestedScopes: [
          AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
          AppleAuthentication.AppleAuthenticationScope.EMAIL,
        ],
      });

      const ok = await loginWithApple(credential);
      if (!ok) {
        Alert.alert('Apple Sign In Failed', 'Please try again.');
        return;
      }

      await finishRouting();
    } catch (error: any) {
      if (error?.code !== 'ERR_CANCELED') {
        Alert.alert('Apple Sign In Failed', 'Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    try {
      await hapticFeedback('light');
      setIsLoading(true);
      const ok = await loginWithGoogle();
      if (!ok) {
        Alert.alert('Google Sign In Failed', 'Please try again.');
        return;
      }
      await finishRouting();
    } catch (error: any) {
      Alert.alert('Google Sign In Failed', error?.message || 'Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <AuthLandingShell
        mode="login"
        subcopy="Future Of Vehicle Care"
        switchLabel="Sign up"
        onSwitchAuth={() => router.push('/auth/signup' as any)}
        onContinueEmail={() => setEmailSheetVisible(true)}
        onApple={() => void handleAppleLogin()}
        onGoogle={() => void handleGoogleLogin()}
        isAppleAvailable={isAppleAvailable}
        disabled={isLoading || resetLoading}
      />

      <AuthEmailSheet
        visible={emailSheetVisible}
        onClose={() => setEmailSheetVisible(false)}
        mode="login"
        loading={isLoading}
        email={email}
        password={password}
        onChangeEmail={setEmail}
        onChangePassword={setPassword}
        onSubmit={() => void handleLogin()}
        onSwitchMode={() => {
          setEmailSheetVisible(false);
          router.push('/auth/signup' as any);
        }}
        onForgotPassword={openResetSheet}
      />

      <AuthResetPasswordSheet
        visible={resetSheetVisible}
        onClose={closeResetSheet}
        email={resetEmail}
        onChangeEmail={(v) => {
          setResetEmail(v);
          setResetError(null);
        }}
        onSubmit={() => void handleResetPassword()}
        onBackToSignIn={backToSignIn}
        loading={resetLoading}
        error={resetError}
        sent={resetSent}
        resendIn={resendIn}
        onResend={() => void handleResetPassword()}
      />
    </>
  );
}
