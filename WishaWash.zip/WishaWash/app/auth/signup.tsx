import React, { useEffect, useState } from 'react';
import { Alert, Platform } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as AppleAuthentication from 'expo-apple-authentication';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AuthLandingShell from '../../src/components/auth/AuthLandingShell';
import { resolvePostAuthRoute } from '../../src/utils/profileSetupGate';

const SESSION_KEY = 'user_session';

export default function SignupScreen() {
  const params = useLocalSearchParams<{ referralCode?: string; code?: string }>();
  const { registerWithApple, registerWithGoogle, user } = useAuth();

  const USER_TYPE = 'customer' as const;

  const [formData, setFormData] = useState({ referralCode: '' });
  const [isLoading, setIsLoading] = useState(false);
  const isAppleAvailable = Platform.OS === 'ios';

  useEffect(() => {
    const incoming =
      (typeof params.referralCode === 'string' && params.referralCode.trim()) ||
      (typeof params.code === 'string' && params.code.trim()) ||
      '';
    if (!incoming) return;
    setFormData((prev) => ({
      ...prev,
      referralCode: incoming.trim().toUpperCase(),
    }));
  }, [params.referralCode, params.code]);


  const finishRouting = async () => {
    let sessionUser = user;
    try {
      const raw = await AsyncStorage.getItem(SESSION_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed?.id) sessionUser = parsed;
      }
    } catch {
      /* keep context user */
    }
    if (!sessionUser?.id) {
      router.replace('/owner/profile-setup');
      return;
    }
    const dest = await resolvePostAuthRoute(sessionUser);
    router.replace(dest);
  };

  const handleAppleSignup = async () => {
    try {
      await hapticFeedback('light');
      setIsLoading(true);

      const cred = await AppleAuthentication.signInAsync({
        requestedScopes: [
          AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
          AppleAuthentication.AppleAuthenticationScope.EMAIL,
        ],
      });

      const referralCode = formData.referralCode.trim();
      type AppleSeed = NonNullable<Parameters<typeof registerWithApple>[1]>;
      const appleSeed: AppleSeed = {
        userType: USER_TYPE,
      };
      if (referralCode) appleSeed.referralCode = referralCode;

      const ok = await registerWithApple(cred, appleSeed);
      if (!ok) {
        Alert.alert('Apple Sign Up Failed', 'Please try again.');
        return;
      }

      await finishRouting();
    } catch (error: any) {
      if (error?.code !== 'ERR_CANCELED') {
        Alert.alert('Apple Sign Up Failed', 'Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleSignup = async () => {
    try {
      await hapticFeedback('light');
      setIsLoading(true);
      const referralCode = formData.referralCode.trim();
      const ok = await registerWithGoogle({
        userType: USER_TYPE,
        ...(referralCode ? { referralCode } : {}),
      });
      if (!ok) {
        Alert.alert('Google Sign Up Failed', 'Please try again.');
        return;
      }
      await finishRouting();
    } catch (error: any) {
      Alert.alert('Google Sign Up Failed', error?.message || 'Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <AuthLandingShell
        mode="signup"
        subcopy="Create an account to book your first wash"
        switchLabel="Sign in"
        onSwitchAuth={() => router.replace('/auth/login')}
        onContinueEmail={() =>
          router.push({
            pathname: '/auth/signup-email',
            params: formData.referralCode ? { referralCode: formData.referralCode } : {},
          } as any)
        }
        onApple={() => void handleAppleSignup()}
        onGoogle={() => void handleGoogleSignup()}
        isAppleAvailable={isAppleAvailable}
        disabled={isLoading}
      />
    </>
  );
}
