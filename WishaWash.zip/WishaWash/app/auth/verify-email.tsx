/**
 * Shown after email sign up while the account waits for its verification link.
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import { AppState, Linking, Platform, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import Animated, { FadeIn, FadeInDown } from 'react-native-reanimated';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useFocusEffect, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { WWPrimaryButton } from '../../src/components/ui';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import HubGlassIcon from '../../src/components/shared/HubGlassIcon';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import {
  clearPendingSignup,
  getPendingSignup,
  resendSignupEmail,
  toSignupError,
} from '../../src/services/EmailVerificationService';

const RESEND_COOLDOWN_S = 60;
const SKY = '#38BDF8';

export default function VerifyEmailScreen() {
  const params = useLocalSearchParams<{ email?: string }>();
  const email = typeof params.email === 'string' ? params.email : getPendingSignup()?.email ?? '';
  const { user } = useAuth();

  const [cooldown, setCooldown] = useState(RESEND_COOLDOWN_S);
  const [resending, setResending] = useState(false);
  const [status, setStatus] = useState<{ tone: 'ok' | 'error'; text: string } | null>(null);
  const checkingRef = useRef(false);
  const leftRef = useRef(false);

  const leaveSignedIn = useCallback(() => {
    if (leftRef.current) return;
    leftRef.current = true;
    clearPendingSignup();
    router.replace('/');
  }, []);

  const focusedRef = useRef(false);
  const userRef = useRef(user);
  userRef.current = user;

  useFocusEffect(
    useCallback(() => {
      focusedRef.current = true;
      if (userRef.current) leaveSignedIn();
      return () => {
        focusedRef.current = false;
      };
    }, [leaveSignedIn])
  );

  // The callback screen handles navigation when the link opens on top of this screen.
  useEffect(() => {
    if (user && focusedRef.current) leaveSignedIn();
  }, [user, leaveSignedIn]);

  useEffect(() => {
    if (cooldown <= 0) return;
    const t = setTimeout(() => setCooldown((c) => c - 1), 1000);
    return () => clearTimeout(t);
  }, [cooldown]);

  /** Covers verifying on another device: quietly try the held credentials when the app regains focus. */
  const tryQuietSignIn = useCallback(async () => {
    const pending = getPendingSignup();
    if (!pending || checkingRef.current || leftRef.current) return;
    checkingRef.current = true;
    try {
      const { data, error } = await supabase.auth.signInWithPassword(pending);
      if (!error && data.session) setStatus({ tone: 'ok', text: 'Email verified! Signing you in…' });
    } catch {
      /* still unverified */
    } finally {
      checkingRef.current = false;
    }
  }, []);

  useEffect(() => {
    let t: ReturnType<typeof setTimeout> | undefined;
    const sub = AppState.addEventListener('change', (state) => {
      if (state !== 'active') return;
      clearTimeout(t);
      // Give a tapped verification link time to open the callback screen first.
      t = setTimeout(() => {
        if (focusedRef.current) void tryQuietSignIn();
      }, 1200);
    });
    return () => {
      clearTimeout(t);
      sub.remove();
    };
  }, [tryQuietSignIn]);

  const handleResend = async () => {
    if (cooldown > 0 || resending || !email) return;
    void hapticFeedback('light');
    setResending(true);
    setStatus(null);
    try {
      await resendSignupEmail(email);
      setStatus({ tone: 'ok', text: 'Sent! Check your inbox and spam folder.' });
      setCooldown(RESEND_COOLDOWN_S);
    } catch (e) {
      setStatus({ tone: 'error', text: toSignupError(e).message });
    } finally {
      setResending(false);
    }
  };

  const openMail = () => {
    void hapticFeedback('light');
    Linking.openURL('message://').catch(() => {
      setStatus({ tone: 'error', text: "Couldn't open your mail app. Open it from your home screen." });
    });
  };

  const changeEmail = () => {
    void hapticFeedback('light');
    clearPendingSignup();
    if (router.canGoBack()) router.back();
    else router.replace('/auth/signup-email' as any);
  };

  const goToSignIn = () => {
    clearPendingSignup();
    router.replace('/auth/login');
  };

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" />
      <BubbleBackground accountType="customer" />
      <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
        <View style={styles.topBar}>
          <TouchableOpacity onPress={changeEmail} style={styles.backBtn} hitSlop={12} accessibilityLabel="Back">
            <Ionicons name="chevron-back" size={22} color="#F8FAFC" />
          </TouchableOpacity>
        </View>

        <View style={styles.body}>
          <Animated.View entering={FadeIn.duration(400)}>
            <HubGlassIcon icon="mail-unread" accent="violet" size={76} />
          </Animated.View>
          <Animated.Text entering={FadeInDown.delay(80).duration(380)} style={styles.title}>
            Check your inbox
          </Animated.Text>
          <Animated.Text entering={FadeInDown.delay(140).duration(380)} style={styles.hint}>
            We sent a verification link to
          </Animated.Text>
          <Animated.View entering={FadeInDown.delay(180).duration(380)} style={styles.emailPill}>
            <Ionicons name="mail-outline" size={15} color="rgba(226,232,240,0.75)" />
            <Text style={styles.emailText} numberOfLines={1}>
              {email || 'your email'}
            </Text>
          </Animated.View>
          <Animated.Text entering={FadeInDown.delay(220).duration(380)} style={styles.subhint}>
            Tap the link to finish setting up your account. It can take a minute to arrive.
          </Animated.Text>

          {status ? (
            <Animated.View entering={FadeIn} style={styles.statusRow}>
              <Ionicons
                name={status.tone === 'ok' ? 'checkmark-circle' : 'alert-circle'}
                size={16}
                color={status.tone === 'ok' ? '#34D399' : '#F87171'}
              />
              <Text style={[styles.statusText, status.tone === 'error' && styles.statusTextError]}>{status.text}</Text>
            </Animated.View>
          ) : null}
        </View>

        <View style={styles.footer}>
          {Platform.OS === 'ios' ? (
            <WWPrimaryButton title="Open Mail" leftIconName="mail-open-outline" onPress={openMail} />
          ) : null}

          <TouchableOpacity
            style={[styles.secondaryBtn, (cooldown > 0 || resending) && styles.secondaryBtnDisabled]}
            onPress={() => void handleResend()}
            disabled={cooldown > 0 || resending}
            activeOpacity={0.85}
            accessibilityRole="button"
          >
            <Ionicons name="refresh" size={15} color={cooldown > 0 ? 'rgba(226,232,240,0.45)' : '#E0F2FE'} />
            <Text style={[styles.secondaryText, cooldown > 0 && styles.secondaryTextMuted]}>
              {resending ? 'Sending…' : cooldown > 0 ? `Resend email in ${cooldown}s` : 'Resend email'}
            </Text>
          </TouchableOpacity>

          <View style={styles.linksRow}>
            <TouchableOpacity onPress={changeEmail} hitSlop={8}>
              <Text style={styles.linkText}>Wrong email? <Text style={styles.linkAccent}>Change it</Text></Text>
            </TouchableOpacity>
            <Text style={styles.linkDot}>·</Text>
            <TouchableOpacity onPress={goToSignIn} hitSlop={8}>
              <Text style={styles.linkAccent}>Sign in</Text>
            </TouchableOpacity>
          </View>
        </View>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: 'transparent' },
  safe: { flex: 1 },
  topBar: { paddingHorizontal: 16, paddingTop: 6 },
  backBtn: { width: 32, height: 32, alignItems: 'center', justifyContent: 'center' },

  body: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 28, gap: 10 },
  title: { marginTop: 14, color: '#F8FAFC', fontSize: 24, fontWeight: '800', letterSpacing: -0.5 },
  hint: { color: 'rgba(226,232,240,0.65)', fontSize: 14, fontWeight: '500' },
  emailPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    maxWidth: '100%',
    paddingHorizontal: 14,
    height: 36,
    borderRadius: 999,
    backgroundColor: 'rgba(148,163,184,0.14)',
  },
  emailText: { flexShrink: 1, color: '#F8FAFC', fontSize: 14, fontWeight: '700' },
  subhint: {
    marginTop: 4,
    textAlign: 'center',
    color: 'rgba(226,232,240,0.55)',
    fontSize: 13,
    fontWeight: '500',
    lineHeight: 19,
  },
  statusRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 10 },
  statusText: { flexShrink: 1, color: '#A7F3D0', fontSize: 13, fontWeight: '600' },
  statusTextError: { color: '#FCA5A5' },

  footer: { paddingHorizontal: 18, paddingTop: 8, paddingBottom: 12, gap: 10 },
  secondaryBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    height: 48,
    borderRadius: 999,
    backgroundColor: 'rgba(56,189,248,0.14)',
  },
  secondaryBtnDisabled: { backgroundColor: 'rgba(148,163,184,0.1)' },
  secondaryText: { color: '#E0F2FE', fontSize: 14, fontWeight: '700' },
  secondaryTextMuted: { color: 'rgba(226,232,240,0.45)' },
  linksRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 6 },
  linkText: { color: 'rgba(226,232,240,0.6)', fontSize: 13, fontWeight: '600' },
  linkAccent: { color: SKY, fontSize: 13, fontWeight: '800' },
  linkDot: { color: 'rgba(226,232,240,0.35)', fontSize: 13 },
});
