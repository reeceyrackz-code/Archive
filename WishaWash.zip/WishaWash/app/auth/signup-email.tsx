/**
 * Email sign up as onboarding-style steps: name → email → password → referral (optional).
 */
import { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  StatusBar,
  useWindowDimensions,
} from 'react-native';
import Animated, {
  Easing,
  FadeIn,
  FadeInDown,
  FadeOut,
  useAnimatedStyle,
  useSharedValue,
  withTiming,
  type SharedValue,
} from 'react-native-reanimated';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { WWPrimaryButton } from '../../src/components/ui';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import OnboardingCarRoad, { type RoadLandmark } from '../../src/components/onboarding/OnboardingCarRoad';
import { hubGlassPalette, type HubGlassTone } from '../../src/components/shared/HubGlassIcon';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { supabase } from '../../src/lib/supabase';
import {
  setPendingSignup,
  toSignupError,
  type SignupErrorCode,
} from '../../src/services/EmailVerificationService';
import { suggestEmailCorrection } from '../../src/utils/emailTypo';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

type StepId = 'name' | 'email' | 'password' | 'referral';

const STEPS: readonly {
  id: StepId;
  label: string;
  icon: keyof typeof Ionicons.glyphMap;
  tone: HubGlassTone;
  title: string;
  hint: string;
}[] = [
  { id: 'name', label: 'Name', icon: 'person', tone: 'sky', title: 'What should we call you?', hint: 'Shown on your bookings and messages.' },
  { id: 'email', label: 'Email', icon: 'mail', tone: 'violet', title: "What's your email?", hint: "We'll send a link to verify it." },
  { id: 'password', label: 'Password', icon: 'lock-closed', tone: 'gold', title: 'Create a password', hint: 'At least 6 characters.' },
  { id: 'referral', label: 'Referral', icon: 'gift', tone: 'pink', title: 'Got a referral code?', hint: 'Optional. You both get credit.' },
];

function passwordStrength(pw: string): 0 | 1 | 2 | 3 {
  if (pw.length < 6) return pw.length ? 1 : 0;
  let score = 1;
  if (pw.length >= 10) score += 1;
  if (/\d/.test(pw) && /[A-Za-z]/.test(pw) && (/[^A-Za-z0-9]/.test(pw) || /[A-Z]/.test(pw))) score += 1;
  return Math.min(score, 3) as 1 | 2 | 3;
}

const STRENGTH = [
  { label: '', color: 'transparent' },
  { label: 'Weak', color: '#F87171' },
  { label: 'Good', color: '#FBBF24' },
  { label: 'Strong', color: '#34D399' },
] as const;

export default function SignupEmailScreen() {
  const params = useLocalSearchParams<{ referralCode?: string }>();
  const { register } = useAuth();
  const { width: windowW, height: windowH } = useWindowDimensions();

  const [step, setStep] = useState(0);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [referralCode, setReferralCode] = useState(
    typeof params.referralCode === 'string' ? params.referralCode.trim().toUpperCase() : ''
  );
  const [showPassword, setShowPassword] = useState(false);
  const [focused, setFocused] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setErrorText] = useState<string | null>(null);
  const [errorCode, setErrorCode] = useState<SignupErrorCode | null>(null);
  const setError = (text: string | null, code: SignupErrorCode | null = null) => {
    setErrorText(text);
    setErrorCode(code);
  };

  // 172 is the smallest height that still fits the roadside signs above and below the road.
  const heroHeight = Math.round(Math.min(Math.max(windowH * 0.2, 172), 210));
  const roadProgress = useSharedValue(0);
  const segProgress = useSharedValue(0);
  useEffect(() => {
    roadProgress.value = withTiming(step, { duration: 900, easing: Easing.inOut(Easing.cubic) });
    segProgress.value = withTiming(step, { duration: 380 });
  }, [step, roadProgress, segProgress]);

  const current = STEPS[step]!;
  const accent = hubGlassPalette(current.tone).glow;
  const isLast = step === STEPS.length - 1;
  const landmarks: RoadLandmark[] = STEPS.map((s) => ({ tone: s.tone, icon: s.icon }));
  const strength = passwordStrength(password);

  const valid: Record<StepId, boolean> = {
    name: name.trim().length >= 2,
    email: EMAIL_RE.test(email.trim()),
    password: password.length >= 6,
    referral: true,
  };
  const canContinue = valid[current.id];
  const emailSuggestion = current.id === 'email' ? suggestEmailCorrection(email) : null;

  const goToStep = (next: number) => {
    setError(null);
    setFocused(false);
    setStep(next);
  };

  const handleBack = () => {
    if (loading) return;
    void hapticFeedback('light');
    if (step === 0) {
      router.back();
      return;
    }
    goToStep(step - 1);
  };

  const createAccount = async () => {
    setLoading(true);
    setError(null);
    try {
      const code = referralCode.trim();
      const payload: Parameters<typeof register>[0] = {
        email: email.trim(),
        name: name.trim(),
        isVerified: false,
        verificationType: 'none',
        totalWashes: 0,
        tier: 'bronze',
        tierPoints: 0,
        password,
        userType: 'customer',
      };
      if (code) payload.referralCode = code;

      const success = await register(payload);
      if (!success) {
        setError('Could not create your account. Please try again.');
        return;
      }
      const { data } = await supabase.auth.getSession();
      if (data.session) {
        router.replace('/');
        return;
      }
      setPendingSignup(email, password);
      router.push({ pathname: '/auth/verify-email', params: { email: email.trim() } } as any);
    } catch (e) {
      const err = toSignupError(e);
      setError(err.message, err.code);
    } finally {
      setLoading(false);
    }
  };

  const handleContinue = async () => {
    if (!canContinue || loading) return;
    await hapticFeedback('medium');
    if (isLast) {
      await createAccount();
      return;
    }
    goToStep(step + 1);
  };

  const ctaTitle = loading
    ? 'Creating account…'
    : isLast
      ? referralCode.trim()
        ? 'Create account'
        : 'Skip & create account'
      : 'Continue';

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" />
      <BubbleBackground accountType="customer" />

      <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
        <KeyboardAvoidingView
          style={styles.flex}
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
          keyboardVerticalOffset={8}
        >
          <View style={styles.topBar}>
            <TouchableOpacity
              onPress={handleBack}
              style={styles.backBtn}
              hitSlop={12}
              accessibilityLabel={step === 0 ? 'Back to sign up' : 'Previous step'}
            >
              <Ionicons name={step === 0 ? 'close' : 'chevron-back'} size={22} color="#F8FAFC" />
            </TouchableOpacity>
            <View style={styles.segments}>
              {STEPS.map((s, i) => (
                <Segment key={s.id} index={i} progress={segProgress} color={accent} />
              ))}
            </View>
            <View style={styles.topBarSpacer} />
          </View>

          <ScrollView
            style={styles.flex}
            contentContainerStyle={styles.scrollContent}
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
          >
            <OnboardingCarRoad
              progress={roadProgress}
              landmarks={landmarks}
              height={heroHeight}
              style={{ width: windowW, marginLeft: -18 }}
            />

            <Animated.View key={current.id} entering={FadeInDown.duration(320)} style={styles.panel}>
              <Text style={styles.title}>{current.title}</Text>
              <Text style={styles.hint}>{current.hint}</Text>

              <View style={[styles.field, focused && { borderBottomColor: accent }]}>
                <Ionicons
                  name={`${current.icon}-outline` as keyof typeof Ionicons.glyphMap}
                  size={20}
                  color={focused ? accent : 'rgba(148,163,184,0.8)'}
                />
                <TextInput
                  key={current.id}
                  style={styles.input}
                  autoFocus
                  placeholderTextColor="rgba(148,163,184,0.6)"
                  onFocus={() => setFocused(true)}
                  onBlur={() => setFocused(false)}
                  onSubmitEditing={() => void handleContinue()}
                  submitBehavior="submit"
                  returnKeyType={isLast ? 'go' : 'next'}
                  {...(current.id === 'name'
                    ? {
                        value: name,
                        onChangeText: (t: string) => {
                          setName(t);
                          setError(null);
                        },
                        placeholder: 'Full name',
                        autoCapitalize: 'words' as const,
                        autoComplete: 'name' as const,
                        textContentType: 'name' as const,
                        accessibilityLabel: 'Full name',
                      }
                    : current.id === 'email'
                      ? {
                          value: email,
                          onChangeText: (t: string) => {
                            setEmail(t);
                            setError(null);
                          },
                          placeholder: 'you@email.com',
                          autoCapitalize: 'none' as const,
                          autoCorrect: false,
                          keyboardType: 'email-address' as const,
                          autoComplete: 'email' as const,
                          textContentType: 'emailAddress' as const,
                          accessibilityLabel: 'Email address',
                        }
                      : current.id === 'password'
                        ? {
                            value: password,
                            onChangeText: (t: string) => {
                              setPassword(t);
                              setError(null);
                            },
                            placeholder: 'Password',
                            secureTextEntry: !showPassword,
                            autoCapitalize: 'none' as const,
                            autoComplete: 'password-new' as const,
                            textContentType: 'newPassword' as const,
                            accessibilityLabel: 'Password',
                          }
                        : {
                            value: referralCode,
                            onChangeText: (t: string) => {
                              setReferralCode(t.toUpperCase());
                              setError(null);
                            },
                            placeholder: 'Referral code',
                            autoCapitalize: 'characters' as const,
                            autoCorrect: false,
                            accessibilityLabel: 'Referral code',
                          })}
                />
                {current.id === 'password' ? (
                  <TouchableOpacity
                    onPress={() => setShowPassword((v) => !v)}
                    hitSlop={10}
                    accessibilityLabel={showPassword ? 'Hide password' : 'Show password'}
                  >
                    <Ionicons
                      name={showPassword ? 'eye-off-outline' : 'eye-outline'}
                      size={20}
                      color="rgba(148,163,184,0.9)"
                    />
                  </TouchableOpacity>
                ) : canContinue && current.id !== 'referral' ? (
                  <Ionicons name="checkmark-circle" size={22} color="#34D399" />
                ) : null}
              </View>

              {current.id === 'password' && password.length > 0 ? (
                <Animated.View entering={FadeIn} exiting={FadeOut} style={styles.strengthRow}>
                  <View style={styles.strengthBars}>
                    {[1, 2, 3].map((n) => (
                      <View
                        key={n}
                        style={[styles.strengthBar, n <= strength && { backgroundColor: STRENGTH[strength].color }]}
                      />
                    ))}
                  </View>
                  <Text style={[styles.strengthLabel, { color: STRENGTH[strength].color }]}>
                    {password.length < 6 ? `${6 - password.length} more characters` : STRENGTH[strength].label}
                  </Text>
                </Animated.View>
              ) : null}

              {emailSuggestion ? (
                <Animated.View entering={FadeIn} exiting={FadeOut}>
                  <TouchableOpacity
                    style={styles.suggestion}
                    onPress={() => {
                      void hapticFeedback('light');
                      setEmail(emailSuggestion);
                      setError(null);
                    }}
                    activeOpacity={0.85}
                    accessibilityLabel={`Use ${emailSuggestion}`}
                  >
                    <Ionicons name="sparkles-outline" size={14} color="#FBBF24" />
                    <Text style={styles.suggestionText} numberOfLines={1}>
                      Did you mean <Text style={styles.suggestionStrong}>{emailSuggestion}</Text>?
                    </Text>
                  </TouchableOpacity>
                </Animated.View>
              ) : null}

              {current.id === 'referral' ? (
                <View style={styles.summary}>
                  <Ionicons name="checkmark-circle" size={16} color="#34D399" />
                  <Text style={styles.summaryText} numberOfLines={1}>
                    {name.trim()} · {email.trim()}
                  </Text>
                </View>
              ) : null}

              {error ? (
                <View style={styles.errorRow}>
                  <Ionicons name="alert-circle" size={16} color="#F87171" />
                  <Text style={styles.errorText}>{error}</Text>
                  {errorCode === 'already_registered' ? (
                    <TouchableOpacity onPress={() => router.replace('/auth/login')} hitSlop={8}>
                      <Text style={styles.errorAction}>Sign in instead</Text>
                    </TouchableOpacity>
                  ) : null}
                </View>
              ) : null}
            </Animated.View>
          </ScrollView>

          <View style={styles.footer}>
            <WWPrimaryButton
              title={ctaTitle}
              onPress={() => void handleContinue()}
              disabled={loading || !canContinue}
              loading={loading}
            />
            {step === 0 ? (
              <TouchableOpacity style={styles.footerLink} onPress={() => router.replace('/auth/login')}>
                <Text style={styles.footerLinkText}>
                  Already have an account? <Text style={styles.footerLinkAccent}>Sign in</Text>
                </Text>
              </TouchableOpacity>
            ) : null}
          </View>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </View>
  );
}

function Segment({
  index,
  progress,
  color,
}: Readonly<{ index: number; progress: SharedValue<number>; color: string }>) {
  const fill = useAnimatedStyle(() => ({
    transform: [{ scaleX: Math.min(Math.max(progress.value - index + 1, 0), 1) }],
  }));
  return (
    <View style={styles.segmentTrack}>
      <Animated.View style={[styles.segmentFill, { backgroundColor: color }, fill]} />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: 'transparent' },
  safe: { flex: 1 },
  flex: { flex: 1 },

  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 6,
    gap: 12,
  },
  backBtn: { width: 32, height: 32, alignItems: 'center', justifyContent: 'center' },
  segments: { flex: 1, flexDirection: 'row', gap: 6 },
  segmentTrack: {
    flex: 1,
    height: 4,
    borderRadius: 999,
    backgroundColor: 'rgba(148,163,184,0.18)',
    overflow: 'hidden',
  },
  segmentFill: { height: '100%', borderRadius: 999, transformOrigin: 'left' },
  topBarSpacer: { width: 32 },

  scrollContent: { flexGrow: 1, paddingHorizontal: 18, paddingTop: 8, paddingBottom: 12 },

  panel: { width: '100%', paddingHorizontal: 6, paddingTop: 4 },
  title: { color: '#F8FAFC', fontSize: 20, fontWeight: '700', letterSpacing: -0.4, lineHeight: 25 },
  hint: {
    marginTop: 4,
    color: 'rgba(226,232,240,0.6)',
    fontSize: 13,
    fontWeight: '500',
    lineHeight: 18,
  },

  field: {
    marginTop: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    height: 56,
    borderBottomWidth: 2,
    borderBottomColor: 'rgba(148,163,184,0.25)',
  },
  input: { flex: 1, color: '#F8FAFC', fontSize: 17, fontWeight: '600', paddingVertical: 0 },

  strengthRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 14 },
  strengthBars: { flex: 1, flexDirection: 'row', gap: 6 },
  strengthBar: { flex: 1, height: 4, borderRadius: 2, backgroundColor: 'rgba(148,163,184,0.2)' },
  strengthLabel: { fontSize: 12, fontWeight: '700', minWidth: 110, textAlign: 'right' },

  summary: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 14 },
  summaryText: { flex: 1, color: 'rgba(226,232,240,0.6)', fontSize: 13, fontWeight: '600' },

  errorRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 16 },
  errorText: { flexShrink: 1, color: '#FCA5A5', fontSize: 13, fontWeight: '600' },
  errorAction: { color: '#38BDF8', fontSize: 13, fontWeight: '800' },

  suggestion: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    gap: 8,
    marginTop: 14,
    paddingHorizontal: 12,
    height: 32,
    borderRadius: 999,
    backgroundColor: 'rgba(251,191,36,0.12)',
  },
  suggestionText: { flexShrink: 1, color: 'rgba(226,232,240,0.75)', fontSize: 13, fontWeight: '600' },
  suggestionStrong: { color: '#FDE68A', fontWeight: '800' },

  footer: { paddingHorizontal: 18, paddingTop: 8, paddingBottom: 12, gap: 4 },
  footerLink: { alignSelf: 'center', paddingVertical: 10 },
  footerLinkText: { color: 'rgba(226,232,240,0.65)', fontSize: 13, fontWeight: '600' },
  footerLinkAccent: { color: '#38BDF8', fontWeight: '800' },
});
