// app/_layout.tsx (RootLayout)
// Single isBooting at root; Wish-a-Wash splash only during app boot and auth restoration.

import React, { Component, useEffect, useRef, useState } from 'react';
import {
  Stack,
  useRouter,
  DarkTheme,
  ThemeProvider as NavigationThemeProvider,
} from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { AuthProvider, useAuth } from '../src/providers/enhanced-auth-context';
import { BootProvider } from '../src/contexts/BootContext';
import { ToastProvider } from '../src/contexts/ToastContext';
import { ThemeProvider, useTheme } from '../src/contexts/ThemeContext';
import { AccountThemeProvider } from '../src/components/shared/AccountThemeProvider';
import type { AccountType } from '../src/constants/accountThemes';
import { BookingFlowThemeProvider } from '../src/contexts/BookingFlowThemeContext';
import { LogBox, Platform, View, StyleSheet, Text, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { colors } from '../src/constants/colors';
import { BORDER_RADIUS, SPACING } from '../src/constants/designTokens';
import * as SplashScreen from 'expo-splash-screen';
import NavigationTab from './components/NavigationTab';
import KeyboardInputGuard from '../src/components/shared/KeyboardInputGuard';
import { TabBarInsetProvider } from '../src/contexts/TabBarInsetContext';
import { initPushNotifications } from '../src/services/pushNotifications';
import { syncCustomerVehicleExpiryNotifications } from '../src/services/vehicleExpiryNotifications';

const NAVIGATION_THEME = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    background: 'transparent',
    card: 'transparent',
  },
};

const TAB_ROOT_ROUTES = new Set([
  'owner/owner-dashboard',
  'owner/inbox',
  'owner/track',
  'owner/wash-history',
  'owner/owner-profile',
  'valeter/valeter-dashboard',
  'valeter/jobs/queue',
  'valeter/jobs/tracking',
  'valeter/valeter-wash-history',
  'valeter/profile/valeter-profile',
  'business/dashboard',
  'business/locations',
  'business/bookings',
  'business/team',
  'business/profile',
]);

function screenTransitionFor(routeName: string) {
  if (TAB_ROOT_ROUTES.has(routeName)) {
    return { animation: 'fade' as const, animationDuration: 220 };
  }
  if (routeName === 'owner/booking/create') {
    return { animation: 'slide_from_bottom' as const, animationDuration: 320 };
  }
  return { animation: 'slide_from_right' as const, animationDuration: 300 };
}

let StripeProvider: any = ({ children }: { children: React.ReactNode }) => <>{children}</>;
if (Platform.OS !== 'web') {
  try {
    const stripe = require('@stripe/stripe-react-native');
    StripeProvider = stripe.StripeProvider;
  } catch (e) {
    if (__DEV__) console.warn('Stripe not available:', e);
  }
}

LogBox.ignoreLogs([
  'Non-serializable values were found in the navigation state',
  'AsyncStorage has been extracted from react-native',
]);

/** Catches React tree errors so the app shows a fallback instead of a blank crash. */
class RootErrorBoundary extends Component<
  { children: React.ReactNode },
  { hasError: boolean; error: Error | null }
> {
  state = { hasError: false, error: null as Error | null };

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    if (__DEV__) {
      console.error('RootErrorBoundary:', error, errorInfo?.componentStack);
    }
  }

  render() {
    if (this.state.hasError && this.state.error) {
      return (
        <View style={styles.errorRoot}>
          <View style={styles.errorIconCircle}>
            <Text style={styles.errorIconText}>!</Text>
          </View>
          <Text style={styles.errorTitle}>Something went wrong</Text>
          <Text style={styles.errorText} numberOfLines={5}>
            {this.state.error?.message}
          </Text>
          <Text style={styles.errorHint}>You can try again or restart the app.</Text>
          <TouchableOpacity
            style={styles.errorButton}
            onPress={() => this.setState({ hasError: false, error: null })}
            activeOpacity={0.8}
            accessibilityLabel="Try again"
            accessibilityRole="button"
          >
            <Text style={styles.errorButtonText}>Try again</Text>
          </TouchableOpacity>
        </View>
      );
    }
    return <>{this.props.children}</>;
  }
}

/** Defers mounting Stripe so the app shell renders first; avoids native init crash taking down the whole app. */
function DeferredStripeProvider({ children }: Readonly<{ children: React.ReactNode }>) {
  const [mountStripe, setMountStripe] = useState(Platform.OS === 'web');
  useEffect(() => {
    if (Platform.OS === 'web') return;
    const t = setTimeout(() => setMountStripe(true), 100);
    return () => clearTimeout(t);
  }, []);

  if (!mountStripe) {
    return <>{children}</>;
  }
  return (
    <StripeProvider
      publishableKey="pk_test_51S3OQLGYkpu3JDyWrHRRw6kvG9t4BNGpCiFVDAUeQCptnXAFJYnNEyWyv1HJG7XYsOd7Io4qYAn9T4deCcYUu2zC00O9yRUMdU"
      merchantIdentifier="merchant.com.wishawashapp"
      urlScheme="waw"
    >
      {children}
    </StripeProvider>
  );
}

function AccountThemeRoot({ children }: Readonly<{ children: React.ReactNode }>) {
  const { user } = useAuth();
  let accountType: AccountType = 'customer';
  if (user?.userType === 'valeter') accountType = 'valeter';
  else if (user?.userType === 'organization') accountType = 'business';
  return <AccountThemeProvider accountType={accountType}>{children}</AccountThemeProvider>;
}

function RootContent() {
  const { theme } = useTheme();
  return (
    <>
      <StatusBar style="light" />
      <View style={styles.contentWrapper}>
        <LinearGradient
          colors={theme.backgroundGradient}
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
        />
        <KeyboardInputGuard>
        <View style={styles.stackClip}>
          <NavigationThemeProvider value={NAVIGATION_THEME}>
            <Stack
              screenOptions={({ route }) => ({
                headerShown: false,
                contentStyle: { backgroundColor: 'transparent' },
                gestureEnabled: false,
                ...screenTransitionFor(route.name),
              })}
            />
          </NavigationThemeProvider>
        </View>
        <NavigationTab />
        </KeyboardInputGuard>
      </View>
    </>
  );
}

function NotificationBootstrap({ children }: Readonly<{ children: React.ReactNode }>) {
  const { user, authReady } = useAuth();
  const router = useRouter();
  const routerRef = useRef(router);
  routerRef.current = router;
  const userId = user?.id;

  useEffect(() => {
    if (!authReady || !userId) return;
    return initPushNotifications(routerRef.current);
  }, [authReady, userId]);

  useEffect(() => {
    if (!authReady || user?.userType !== 'customer' || !user?.id) return;
    void syncCustomerVehicleExpiryNotifications(user.id);
  }, [authReady, user?.id, user?.userType]);

  return <>{children}</>;
}

export default function RootLayout() {
  useEffect(() => {
    SplashScreen.preventAutoHideAsync().catch((e: unknown) => {
      if (__DEV__) console.warn('SplashScreen.preventAutoHideAsync failed:', e);
    });
  }, []);

  return (
    <RootErrorBoundary>
      <DeferredStripeProvider>
        <AuthProvider>
          <ThemeProvider>
            <AccountThemeRoot>
              <NotificationBootstrap>
                <BootProvider>
                  <ToastProvider>
                    <BookingFlowThemeProvider>
                      <TabBarInsetProvider>
                        <View style={styles.root}>
                          <RootContent />
                        </View>
                      </TabBarInsetProvider>
                    </BookingFlowThemeProvider>
                  </ToastProvider>
                </BootProvider>
              </NotificationBootstrap>
            </AccountThemeRoot>
          </ThemeProvider>
        </AuthProvider>
      </DeferredStripeProvider>
    </RootErrorBoundary>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: 'transparent' },
  contentWrapper: { flex: 1 },
  /** Keep screens full-height; the floating nav now overlays them with blur instead of reserving space. */
  stackClip: { flex: 1, overflow: 'hidden' },
  errorRoot: {
    flex: 1,
    backgroundColor: colors.bgPrimary,
    justifyContent: 'center',
    alignItems: 'center',
    padding: SPACING.xxl,
  },
  errorIconCircle: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: colors.surfaceOverlayStrong,
    borderWidth: 2,
    borderColor: colors.inputErrorBorder,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: SPACING.lg,
  },
  errorIconText: {
    color: colors.inputError,
    fontSize: 24,
    fontWeight: '700',
  },
  errorTitle: {
    color: colors.textOnDarkPrimary,
    fontSize: 18,
    fontWeight: '700',
    marginBottom: SPACING.md,
  },
  errorText: {
    color: colors.textOnDarkTertiary,
    fontSize: 14,
    textAlign: 'center',
    marginBottom: SPACING.sm,
  },
  errorHint: {
    color: colors.greyMedium,
    fontSize: 13,
    textAlign: 'center',
    marginBottom: SPACING.xxl,
  },
  errorButton: {
    backgroundColor: colors.SKY,
    paddingHorizontal: SPACING.xxl,
    paddingVertical: SPACING.md,
    borderRadius: BORDER_RADIUS.sm,
    minWidth: 160,
    alignItems: 'center',
  },
  errorButtonText: { color: colors.textOnDarkPrimary, fontWeight: '700', fontSize: 16 },
});
