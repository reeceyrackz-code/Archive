import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Animated,
  Image,
  Alert,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { Marker, Region } from 'react-native-maps';
import type MapView from 'react-native-maps';
import SafeMapView from '../../../src/components/maps/SafeMapView';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { HISTORY_SNAPSHOT_MAP_STYLE, MAP_LOCKED_DARK } from '../../../src/constants/mapConstants';
import { MapMarkerWashHub } from '../../../src/components/maps/MapMarkerViews';
import HubGlassIcon from '../../../src/components/shared/HubGlassIcon';

let useStripe: any = null;
if (Platform.OS !== 'web') {
  try {
    const stripe = require('@stripe/stripe-react-native');
    useStripe = stripe.useStripe;
  } catch {}
}
import GlassCard from '@/components/booking/GlassCard';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { colors } from '../../../src/constants/colors';
import SuccessOverlay from '../../../src/components/booking/SuccessOverlay';
import { WWPrimaryButton } from '../../../src/components/ui';
import { ValeterStatsService } from '../../../src/services/Valeterstatsservice';
import { CCP, ccpFallbackName, ccpSingularLower } from '../../../src/constants/carCareProLabels';
import { fetchValeterIdentity } from '../../../src/utils/valeterDisplayName';
import { formatDisplayName } from '../../../src/utils/formatDisplayName';
import { WashHubStatsService } from '../../../src/services/WashHubStatsService';
import {
  clearPendingRatingBookingId,
  getPendingRatingBookingId,
} from '../../../src/utils/pendingCustomerRating';
import { grantCompletedBookingLoyalty } from '../../../src/services/LoyaltyService';

const SKY = colors.SKY;

const TIP_OPTIONS = [0, 2, 5, 10];

export default function BookingCompletion() {
  const { user, updateUser } = useAuth();
    const params = useLocalSearchParams();
  const bookingId = params.bookingId as string;
  const alreadyCelebrated = params.celebrated === '1';

  const [booking, setBooking] = useState<any | null>(null);
  const [rating, setRating] = useState(0);
  const [review, setReview] = useState('');
  const [tipAmount, setTipAmount] = useState(0);
  const [tipPaid, setTipPaid] = useState(false);
  const [tipPaying, setTipPaying] = useState(false);
  const [valeterName, setValeterName] = useState<string>('');
  const [valeterPhoto, setValeterPhoto] = useState<string | null>(null);
  const [valeterStats, setValeterStats] = useState<{ totalJobs: number; averageRating: number } | null>(null);
  const [hubName, setHubName] = useState<string>('');
  const [hubAddress, setHubAddress] = useState<string>('');
  const [hubStats, setHubStats] = useState<{ totalJobs: number; averageRating: number } | null>(null);

  const stripeHook = useStripe ? useStripe() : null;
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const mapRef = useRef<MapView>(null);
  const [showSuccessOverlay, setShowSuccessOverlay] = useState(!alreadyCelebrated);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    loadBooking();
  }, [bookingId]);

  useEffect(() => {
    if (!bookingId) return;
    void (async () => {
      const pending = await getPendingRatingBookingId();
      if (pending === bookingId) await clearPendingRatingBookingId();
    })();
  }, [bookingId]);

  const loadBooking = async () => {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('id', bookingId)
        .single();

      if (error) throw error;
      setBooking(data);

      if (data?.valeter_id) {
        const [identity, stats] = await Promise.all([
          fetchValeterIdentity(data.valeter_id),
          ValeterStatsService.getValeterStats(data.valeter_id),
        ]);
        setValeterName(identity.name);
        setValeterPhoto(identity.photoUrl);
        setValeterStats({ totalJobs: stats.totalJobs, averageRating: stats.averageRating });
      }

      if (data?.location_id) {
        try {
          const { data: hub } = await supabase
            .from('car_wash_locations')
            .select('name, address')
            .eq('id', data.location_id)
            .single();
          if (hub) {
            setHubName(hub.name || 'Car Wash');
            setHubAddress(hub.address || '');
          }
          const stats = await WashHubStatsService.getHubStats(data.location_id);
          setHubStats(stats);
        } catch (e) {
          console.warn('Error loading wash hub:', e);
        }
      }
    } catch (error) {
      console.error('Error loading booking:', error);
    }
  };

  const handleRatingSelect = async (value: number) => {
    await hapticFeedback('light');
    setRating(value);
  };

  const handlePayTip = async () => {
    if (!bookingId || !user?.id || tipAmount <= 0 || tipPaid || Platform.OS === 'web') return;
    const presentSheet = stripeHook?.presentPaymentSheet;
    if (!presentSheet) {
      Alert.alert('Payment not available', 'Tip payment is not supported on this device.');
      return;
    }
    setTipPaying(true);
    try {
      const amountPence = Math.round(tipAmount * 100);
      const { data, error } = await supabase.functions.invoke('booking-extra-charge', {
        body: {
          action: 'create_payment_intent',
          bookingId,
          amount: amountPence,
          currency: 'gbp',
          customerId: user.id,
          description: `${booking?.location_id ? 'Tip for wash hub' : `Tip for ${ccpSingularLower()}`} - booking ${bookingId}`,
        },
      });
      if (error) throw error;
      const cs = data?.clientSecret ?? data?.client_secret ?? data?.paymentIntentClientSecret ?? data?.payment_intent_client_secret ?? data?.paymentIntent?.clientSecret ?? data?.paymentIntent?.client_secret;
      if (!cs) throw new Error('No payment secret returned');
      const { error: initErr } = await stripeHook.initPaymentSheet({
        paymentIntentClientSecret: cs,
        merchantDisplayName: 'Wish a Wash',
        returnURL: 'waw://stripe-redirect',
        style: 'automatic',
      });
      if (initErr) throw initErr;
      const { error: presentErr } = await presentSheet();
      if (presentErr) {
        if (presentErr.code !== 'Canceled') throw presentErr;
        setTipPaying(false);
        return;
      }
      await supabase.from('bookings').update({ tip_amount: tipAmount }).eq('id', bookingId);
      setTipPaid(true);
      hapticFeedback('medium');
    } catch (e: any) {
      Alert.alert('Tip payment failed', e?.message || 'Please try again.');
    } finally {
      setTipPaying(false);
    }
  };

  const handleSubmitReview = async () => {
    if (rating === 0) {
      Alert.alert('Rating Required', 'Please select a rating');
      return;
    }
    if (tipAmount > 0 && !tipPaid) {
      Alert.alert('Tip not paid', 'You selected a tip but haven\'t paid it yet. Tap "Pay £' + tipAmount + ' tip" to add a tip, or choose "None" to skip.');
      return;
    }

    await hapticFeedback('medium');

    try {
      const completedAt = new Date().toISOString();
      const { error } = await supabase
        .from('bookings')
        .update({
          rating,
          review: review.trim() || null,
          tip_amount: tipPaid ? tipAmount : 0,
          status: 'completed',
          completed_at: completedAt,
        })
        .eq('id', bookingId);

      if (error) throw error;

      if (booking?.valeter_id && booking?.user_id) {
        const { error: reviewError } = await supabase
          .from('reviews')
          .upsert(
            {
              booking_id: bookingId,
              customer_profile_id: booking.user_id,
              valeter_profile_id: booking.valeter_id,
              rating,
              comment: review.trim() || null,
            },
            { onConflict: 'booking_id' },
          );

        if (reviewError) {
          console.warn('[BookingCompletion] review upsert failed:', reviewError.message);
        }
      }

      if (user?.id) {
        try {
          const loyalty = await grantCompletedBookingLoyalty(user.id, bookingId);
          if (loyalty.customerBalance >= 0) {
            await updateUser({ tierPoints: loyalty.customerBalance });
          }
        } catch (loyaltyError) {
          console.warn('[BookingCompletion] loyalty sync failed:', loyaltyError);
        }
      }

      router.replace('/owner/owner-dashboard');
    } catch (error) {
      console.error('Error submitting review:', error);
      Alert.alert('Error', 'Could not save your rating. Please try again.');
    }
  };

  const handleSkip = () => {
    router.replace('/owner/owner-dashboard');
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      <AppHeader
        title="Rate your wash"
        subtitle={
          booking
            ? getServiceDisplayName(booking.service_type, booking.service_name)
            : 'Service complete!'
        }
        showBack
        fullWidth
        accountType="customer"
        bookingSheetHeaderChrome
        onBack={() => { hapticFeedback('light'); router.back(); }}
      />

      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
          },
        ]}
      >
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[
            styles.scrollContent,
            { paddingTop: HEADER_CONTENT_OFFSET, opacity: showSuccessOverlay ? 0 : 1 },
          ]}
          pointerEvents={showSuccessOverlay ? 'none' : 'auto'}
        >
          {/* Journey complete – mini map */}
          {booking?.location_lat != null && booking?.location_lng != null && (() => {
            const mapRegion: Region = {
              latitude: booking.location_lat,
              longitude: booking.location_lng,
              latitudeDelta: 0.001,
              longitudeDelta: 0.001,
            };
            return (
            <View style={styles.journeyCompleteSection}>
              <Text style={styles.journeyCompleteTitle}>Journey complete</Text>
              <View style={styles.miniMapWrap}>
                <SafeMapView
                  ref={mapRef}
                  style={styles.miniMap}
                  region={mapRegion}
                  legalLabelInsets={{ top: 0, right: 8, bottom: 120, left: 8 }}
                  scrollEnabled={false}
                  pitchEnabled={false}
                  rotateEnabled={false}
                  customMapStyle={HISTORY_SNAPSHOT_MAP_STYLE}
                  userInterfaceStyle={MAP_LOCKED_DARK}
                >
                  <Marker
                    coordinate={{
                      latitude: booking.location_lat,
                      longitude: booking.location_lng,
                    }}
                    title="Service completed"
                    anchor={{ x: 0.5, y: 1 }}
                  >
                    <MapMarkerWashHub size={40} />
                  </Marker>
                </SafeMapView>
                <TouchableOpacity
                  onPress={() => {
                    hapticFeedback('light');
                    mapRef.current?.animateToRegion(mapRegion, 350);
                  }}
                  style={styles.completionRecenterButton}
                  activeOpacity={0.7}
                >
                  <Ionicons name="locate" size={20} color={SKY} />
                </TouchableOpacity>
              </View>
            </View>
            );
          })()}

          {/* Valeter Profile Card */}
          {booking?.valeter_id && (
            <GlassCard style={styles.profileCard}>
              <View style={styles.profileCardRow}>
                <View style={styles.profileAvatarWrap}>
                  {valeterPhoto ? (
                    <Image source={{ uri: valeterPhoto }} style={styles.profileAvatar} />
                  ) : (
                    <HubGlassIcon icon="person" accent="sky" size={64} iconSize={30} />

                  )}
                </View>
                <View style={styles.profileInfo}>
                  <Text style={styles.profileName}>{formatDisplayName(valeterName) || valeterName}</Text>
                  {valeterStats && (
                    <View style={styles.profileStatsRow}>
                      <View style={styles.profileStat}>
                        <Ionicons name="water" size={14} color={SKY} />
                        <Text style={styles.profileStatText}>{valeterStats.totalJobs} washes</Text>
                      </View>
                      {valeterStats.averageRating > 0 && (
                        <View style={styles.profileStat}>
                          <Ionicons name="star" size={14} color="#FBBF24" />
                          <Text style={styles.profileStatText}>{valeterStats.averageRating.toFixed(1)}</Text>
                        </View>
                      )}
                    </View>
                  )}
                  <View style={styles.serviceTheyDid}>
                    <Text style={styles.serviceTheyDidLabel}>Wash they did for you</Text>
                    <Text style={styles.serviceTheyDidValue}>
                      {getServiceDisplayName(booking.service_type, booking.service_name)} • £{Number(booking.price ?? 0).toFixed(2)}
                    </Text>
                  </View>
                </View>
              </View>
            </GlassCard>
          )}

          {/* Wash Hub Profile Card */}
          {booking?.location_id && (
            <GlassCard style={styles.profileCard}>
              <View style={styles.profileCardRow}>
                <HubGlassIcon icon="business" accent="sky" size={64} iconSize={30} />
                <View style={styles.profileInfo}>
                  <Text style={styles.profileName}>{hubName || 'Car Wash'}</Text>
                  {hubAddress ? (
                    <Text style={styles.profileMeta} numberOfLines={2}>{hubAddress}</Text>
                  ) : null}
                  {hubStats && (
                    <View style={styles.profileStatsRow}>
                      <View style={styles.profileStat}>
                        <Ionicons name="water" size={14} color={SKY} />
                        <Text style={styles.profileStatText}>{hubStats.totalJobs} washes</Text>
                      </View>
                      {hubStats.averageRating > 0 && (
                        <View style={styles.profileStat}>
                          <Ionicons name="star" size={14} color="#FBBF24" />
                          <Text style={styles.profileStatText}>{hubStats.averageRating.toFixed(1)}</Text>
                        </View>
                      )}
                    </View>
                  )}
                  <View style={styles.serviceTheyDid}>
                    <Text style={styles.serviceTheyDidLabel}>Service you had</Text>
                    <Text style={styles.serviceTheyDidValue}>
                      {getServiceDisplayName(booking.service_type, booking.service_name)} • £{Number(booking.price ?? 0).toFixed(2)}
                    </Text>
                  </View>
                </View>
              </View>
            </GlassCard>
          )}

          {/* Rating Section */}
          <GlassCard style={styles.ratingCard}>
            <View style={styles.ratingHeader}>
              <HubGlassIcon icon="star" accent="gold" size={36} />
              <Text style={styles.ratingTitle}>Rate Your Experience</Text>
            </View>
            <View style={styles.starsContainer}>
              {[1, 2, 3, 4, 5].map((value) => (
                <TouchableOpacity
                  key={value}
                  onPress={() => handleRatingSelect(value)}
                  style={styles.starButton}
                >
                  <Ionicons
                    name={value <= rating ? 'star' : 'star-outline'}
                    size={40}
                    color={value <= rating ? '#FBBF24' : '#6B7280'}
                  />
                </TouchableOpacity>
              ))}
            </View>
            {rating > 0 && (
              <Text style={styles.ratingText}>
                {rating === 5 ? 'Excellent!' : rating === 4 ? 'Great!' : rating === 3 ? 'Good!' : rating === 2 ? 'Fair' : 'Poor'}
              </Text>
            )}
          </GlassCard>

          {/* Leave a comment */}
          <GlassCard style={styles.commentCard}>
            <View style={styles.commentHeader}>
              <HubGlassIcon icon="chatbubble-ellipses" accent="sky" size={36} />
              <Text style={styles.commentTitle}>Leave a comment (optional)</Text>
            </View>
            <TextInput
              style={styles.commentInput}
              placeholder={`How was your experience? Share feedback for the ${ccpSingularLower()} or wash hub...`}
              placeholderTextColor="#6B7280"
              value={review}
              onChangeText={setReview}
              multiline
              numberOfLines={4}
              textAlignVertical="top"
              maxLength={500}
            />
            {review.length > 0 && (
              <Text style={styles.commentCount}>{review.length}/500</Text>
            )}
          </GlassCard>

          {/* Tip Section - always show after completion */}
          <GlassCard style={styles.tipCard}>
            <View style={styles.tipHeader}>
              <HubGlassIcon icon="heart" accent="pink" size={36} />
              <Text style={styles.tipTitle}>
                {booking?.valeter_id
                  ? `Add a tip for your ${ccpSingularLower()}?`
                  : booking?.location_id
                    ? 'Add a tip for the wash hub?'
                    : 'Leave a tip? (optional)'}
              </Text>
            </View>
              <View style={styles.tipOptions}>
                {TIP_OPTIONS.map((amount) => (
                  <TouchableOpacity
                    key={amount}
                    onPress={async () => {
                      await hapticFeedback('light');
                      setTipAmount(amount);
                      if (amount === 0) setTipPaid(false);
                    }}
                    style={[styles.tipOption, tipAmount === amount && styles.tipOptionSelected]}
                  >
                    <Text style={[styles.tipOptionText, tipAmount === amount && styles.tipOptionTextSelected]}>
                      {amount === 0 ? 'None' : `£${amount}`}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
              {tipAmount > 0 &&
                (tipPaid ? (
                  <View style={[styles.payTipButton, styles.payTipButtonPaid]}>
                    <LinearGradient colors={['#10B981', '#059669']} style={styles.payTipGradient}>
                      <Ionicons name="checkmark-circle" size={20} color="#FFFFFF" />
                      <Text style={styles.payTipText}>Tip paid £{tipAmount}</Text>
                    </LinearGradient>
                  </View>
                ) : (
                  <View style={styles.payTipButton}>
                    <WWPrimaryButton
                      title={`Pay £${tipAmount} tip`}
                      onPress={handlePayTip}
                      disabled={tipPaying}
                      loading={tipPaying}
                      leftIconName="wallet"
                      leftIconSize={20}
                    />
                  </View>
                ))}
          </GlassCard>

          {/* Action Buttons */}
          <View style={styles.actionsContainer}>
            <WWPrimaryButton
              title={`${rating > 0 ? 'Submit Review' : 'Submit Rating'}${tipAmount > 0 ? ` + £${tipAmount} tip` : ''}`}
              onPress={handleSubmitReview}
            />

            <TouchableOpacity
              onPress={handleSkip}
              style={styles.skipButton}
            >
              <Text style={styles.skipText}>Skip for Now</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </Animated.View>

      {/* Boom! overlay with confetti - shows first, then ratings/profile/tip */}
      <SuccessOverlay
        visible={showSuccessOverlay}
        type="completed"
        message="Boom! You're super clean now"
        onComplete={() => setShowSuccessOverlay(false)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
    alignItems: 'center',
  },
  journeyCompleteSection: {
    width: '100%',
    maxWidth: 400,
    marginBottom: 20,
  },
  journeyCompleteTitle: {
    color: 'rgba(186,230,253,0.92)',
    fontSize: 10.5,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 1.2,
    marginBottom: 8,
    paddingHorizontal: 4,
  },
  miniMapWrap: {
    height: 160,
    borderRadius: 16,
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  miniMap: {
    width: '100%',
    height: '100%',
    borderRadius: 16,
  },
  completionRecenterButton: {
    position: 'absolute',
    top: 8,
    right: 8,
    zIndex: 10,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.78)',
    shadowColor: '#38BDF8',
    shadowOpacity: 0.35,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 0 },
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileCard: {
    padding: 20,
    marginBottom: 16,
    width: '100%',
  },
  profileCardRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 16,
  },
  profileAvatarWrap: {
    width: 64,
    height: 64,
  },
  profileAvatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
  },
  profileInfo: {
    flex: 1,
    minWidth: 0,
  },
  profileName: {
    color: '#F8FAFC',
    fontSize: 20,
    fontWeight: '800',
    letterSpacing: -0.4,
    marginBottom: 4,
  },
  profileMeta: {
    color: 'rgba(226,232,240,0.7)',
    fontSize: 13,
    fontWeight: '500',
    marginBottom: 8,
  },
  profileStatsRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 10,
  },
  profileStat: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  profileStatText: {
    color: 'rgba(226,232,240,0.7)',
    fontSize: 13,
    fontWeight: '600',
  },
  serviceTheyDid: {
    paddingTop: 10,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(255,255,255,0.14)',
  },
  serviceTheyDidLabel: {
    color: 'rgba(186,230,253,0.92)',
    fontSize: 10.5,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
    marginBottom: 4,
  },
  serviceTheyDidValue: {
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '700',
  },
  commentCard: {
    padding: 20,
    marginBottom: 24,
    width: '100%',
  },
  commentHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 12,
  },
  commentTitle: {
    flex: 1,
    color: '#F8FAFC',
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: -0.4,
  },
  commentInput: {
    backgroundColor: 'rgba(148,163,184,0.12)',
    borderRadius: 14,
    padding: 14,
    color: '#F8FAFC',
    fontSize: 15,
    minHeight: 100,
    maxHeight: 140,
  },
  commentCount: {
    color: '#6B7280',
    fontSize: 12,
    marginTop: 6,
    textAlign: 'right',
  },
  tipCard: {
    padding: 20,
    marginBottom: 24,
    width: '100%',
  },
  tipHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 14,
  },
  tipTitle: {
    flex: 1,
    color: '#F8FAFC',
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: -0.4,
  },
  tipOptions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  tipOption: {
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 999,
    backgroundColor: 'rgba(148,163,184,0.12)',
  },
  tipOptionSelected: {
    backgroundColor: 'rgba(56,189,248,0.16)',
    shadowColor: '#38BDF8',
    shadowOpacity: 0.35,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 0 },
  },
  tipOptionText: {
    color: 'rgba(226,232,240,0.7)',
    fontSize: 15,
    fontWeight: '700',
  },
  tipOptionTextSelected: {
    color: '#7DD3FC',
  },
  payTipButton: {
    marginTop: 16,
    borderRadius: 14,
    overflow: 'hidden',
  },
  payTipButtonPaid: {
    opacity: 0.9,
  },
  payTipGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 24,
    gap: 10,
  },
  payTipText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
  ratingCard: {
    padding: 24,
    marginBottom: 24,
    width: '100%',
  },
  ratingHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 20,
  },
  ratingTitle: {
    color: '#F8FAFC',
    fontSize: 20,
    fontWeight: '800',
    letterSpacing: -0.4,
  },
  starsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 12,
    marginBottom: 16,
  },
  starButton: {
    padding: 4,
  },
  ratingText: {
    color: SKY,
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
  },
  actionsContainer: {
    width: '100%',
    gap: 12,
  },
  skipButton: {
    paddingVertical: 12,
    alignItems: 'center',
  },
  skipText: {
    color: 'rgba(226,232,240,0.7)',
    fontSize: 14,
    fontWeight: '600',
  },
});
