import React, { useEffect, useState, useRef, useMemo, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Alert,
  ScrollView,
  Modal,
  Pressable,
  Dimensions,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { Region, Marker, Circle } from 'react-native-maps';
import type MapView from 'react-native-maps';
import SafeMapView from '../../../../src/components/maps/SafeMapView';
import * as Location from 'expo-location';
import Slider from '@react-native-community/slider';

import { supabase } from '../../../../src/lib/supabase';
import useLiveLocation from '../../../../src/hooks/useLiveLocation';
import AppHeader from '../../../../src/components/shared/AppHeader';
import { colors } from '../../../../src/constants/colors';
import { Hub } from '../../../../src/types/booking';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import { WWSheetCloseButton } from '../../../../src/components/ui';
import {
  getIndexTrackingCardSnapInterval,
  getIndexTrackingCardWidth,
  INDEX_TRACKING_CARD_BORDER_RADIUS,
  PREMIUM_BOOKING_MAP_SHEET_GLASS,
} from '../../../../src/constants/bookingCardTheme';
import IndexTrackingCardShell, { indexTrackingCardStyles as ix } from '../../../../src/components/booking/IndexTrackingCardShell';
import {
  BOOKING_MAP_STYLE,
  MAP_CAMERA_ANIMATION_DURATION,
  MAP_LOCKED_DARK,
} from '../../../../src/constants/mapConstants';
import { MapMarkerScheduledHub, MapMarkerCustomerVehicle } from '../../../../src/components/maps/MapMarkerViews';
import BusinessSheetBackground from '../../../../src/components/shared/BusinessSheetBackground';
import BookingSheetPremiumLayers from '../../../../src/components/booking/BookingSheetPremiumLayers';
import BookingBottomSheetOverlay from '../../../../src/components/booking/BookingBottomSheetOverlay';
import HubSpotlightSheetBody from '../../../../src/components/hub/HubSpotlightSheetBody';
import GradientIconBox from '../../../../src/components/shared/GradientIconBox';
import HubGlassIcon from '../../../../src/components/shared/HubGlassIcon';
import { accentToGradient } from '../../../../src/utils/accentGradient';
const SKY = colors.SKY;
const { width } = Dimensions.get('window');
const HUB_CARD_WIDTH = getIndexTrackingCardWidth(width);
const HUB_CARD_STEP = getIndexTrackingCardSnapInterval(width);
/** Map legal / padding so Apple/Google attribution sits above the glass sheet. */
const LOCATION_SHEET_MAP_BOTTOM = 268;

type HubRow = Hub & {
  eco_washing?: boolean | null;
  detailing_offered?: boolean | null;
  created_at?: string | null;
  rating?: number | null;
  imageUrl?: string | null;
};

const safeBool = (v: any) => v === true;

export default function PhysicalLocationSelect() {
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ vehicleId?: string; vehicleIds?: string }>();
  const { coords } = useLiveLocation();
  const vehicleId = params.vehicleId;
  const vehicleIds = params.vehicleIds;

  const [hubs, setHubs] = useState<HubRow[]>([]);
  const [selectedHub, setSelectedHub] = useState<HubRow | null>(null);
  const [radiusMiles, setRadiusMiles] = useState(10);
  const [radiusModalVisible, setRadiusModalVisible] = useState(false);
  const [infoModalHub, setInfoModalHub] = useState<HubRow | null>(null);
  const [hubStats, setHubStats] = useState<{ completed: number; active: number } | null>(null);

  const [region, setRegion] = useState<Region>({
    latitude: coords?.latitude ?? 51.5074,
    longitude: coords?.longitude ?? -0.1278,
    latitudeDelta: 0.001,
    longitudeDelta: 0.001,
  });

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;
  const cardsScrollRef = useRef<ScrollView>(null);
  const mapRef = useRef<MapView>(null);
  const [locationPulseVisible, setLocationPulseVisible] = useState(false);
  const pulseScale = useRef(new Animated.Value(1)).current;
  const pulseOpacity = useRef(new Animated.Value(0.5)).current;
  const pulseLoopRef = useRef<Animated.CompositeAnimation | null>(null);

  // After 1–2s on a selected hub, tint and pulse the location on the map
  useEffect(() => {
    if (!selectedHub) {
      setLocationPulseVisible(false);
      pulseScale.setValue(1);
      pulseOpacity.setValue(0.5);
      pulseLoopRef.current = null;
      return;
    }
    const timer = setTimeout(() => {
      setLocationPulseVisible(true);
      pulseScale.setValue(1);
      pulseOpacity.setValue(0.5);
      const pulseOut = Animated.parallel([
        Animated.timing(pulseScale, { toValue: 1.85, duration: 1200, useNativeDriver: true }),
        Animated.timing(pulseOpacity, { toValue: 0, duration: 1200, useNativeDriver: true }),
      ]);
      const reset = Animated.parallel([
        Animated.timing(pulseScale, { toValue: 1, duration: 1, useNativeDriver: true }),
        Animated.timing(pulseOpacity, { toValue: 0.5, duration: 1, useNativeDriver: true }),
      ]);
      pulseLoopRef.current = Animated.loop(Animated.sequence([pulseOut, Animated.delay(200), reset]));
      pulseLoopRef.current.start();
    }, 1500);
    return () => {
      clearTimeout(timer);
      pulseLoopRef.current?.stop();
    };
  }, [selectedHub?.id]);

  // Keep map centered on live location when no hub selected; when coords updates, show user
  useEffect(() => {
    if (coords && !selectedHub) {
      setRegion({
        latitude: coords.latitude,
        longitude: coords.longitude,
        latitudeDelta: 0.001,
        longitudeDelta: 0.001,
      });
    }
  }, [coords?.latitude, coords?.longitude, selectedHub]);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.spring(slideAnim, { toValue: 0, tension: 50, friction: 8, useNativeDriver: true }),
    ]).start();

    loadHubs();
  }, []);

  const normalizeHubs = (rows: any[]): HubRow[] =>
    (rows || [])
      .map((h) => ({
        ...h,
        latitude: Number(h.latitude),
        longitude: Number(h.longitude),
        eco_washing: safeBool(h.eco_washing),
        detailing_offered: safeBool(h.detailing_offered),
      }))
      .filter((h) => Number.isFinite(h.latitude) && Number.isFinite(h.longitude));

  const loadHubs = async () => {
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id,name,address,latitude,longitude,status,eco_washing,detailing_offered,created_at,rating');

      if (error) throw error;
      const rows = (data || []).map((h: any) => ({
        ...h,
        imageUrl: undefined,
      }));
      setHubs(normalizeHubs(rows));
    } catch (err: any) {
      Alert.alert('Hubs Error', err?.message || 'Failed to load hubs');
      setHubs([]);
    }
  };

  const calculateDistance = useCallback(
    (hub: HubRow) => {
      if (!coords || !hub.latitude || !hub.longitude) return null;
      const toRad = (v: number) => (v * Math.PI) / 180;
      const R = 3959;
      const dLat = toRad(hub.latitude - coords.latitude);
      const dLon = toRad(hub.longitude - coords.longitude);
      const a =
        Math.sin(dLat / 2) ** 2 +
        Math.cos(toRad(coords.latitude)) *
          Math.cos(toRad(hub.latitude)) *
          Math.sin(dLon / 2) ** 2;
      return (R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)))).toFixed(1);
    },
    [coords]
  );

  const filteredHubs = useMemo(() => {
    const list = hubs;
    if (!coords) return list;
    return list
      .map((hub) => ({ hub, distance: calculateDistance(hub) }))
      .filter(({ distance }) => distance && Number(distance) <= radiusMiles)
      .sort((a, b) => Number(a.distance) - Number(b.distance))
      .map(({ hub }) => hub);
  }, [hubs, coords, radiusMiles, calculateDistance]);

  // When selection changes, scroll the card list so the selected hub is in view
  useEffect(() => {
    if (!selectedHub || !filteredHubs.length) return;
    const index = filteredHubs.findIndex((h) => String(h.id) === String(selectedHub.id));
    if (index < 0) return;
    const timer = setTimeout(() => {
      cardsScrollRef.current?.scrollTo({
        x: index * HUB_CARD_STEP,
        animated: true,
      });
    }, 150);
    return () => clearTimeout(timer);
  }, [selectedHub?.id, filteredHubs]);

  const mapBottomPad = LOCATION_SHEET_MAP_BOTTOM + Math.max(insets.bottom, 12);

  useEffect(() => {
    if (!coords) return;
    const pts: { latitude: number; longitude: number }[] =
      filteredHubs.length > 0
        ? [
            { latitude: coords.latitude, longitude: coords.longitude },
            ...filteredHubs.map((h) => ({ latitude: h.latitude, longitude: h.longitude })),
          ]
        : [{ latitude: coords.latitude, longitude: coords.longitude }];
    const t = setTimeout(() => {
      if (pts.length === 1) {
        mapRef.current?.animateToRegion(
          {
            latitude: coords.latitude,
            longitude: coords.longitude,
            latitudeDelta: Math.min(0.12, (radiusMiles / 69) * 2.2),
            longitudeDelta: Math.min(0.12, (radiusMiles / 69) * 2.2),
          },
          MAP_CAMERA_ANIMATION_DURATION,
        );
        return;
      }
      mapRef.current?.fitToCoordinates(pts, {
        edgePadding: { top: 100, right: 36, bottom: mapBottomPad + 24, left: 36 },
        animated: true,
      });
    }, 400);
    return () => clearTimeout(t);
  }, [coords?.latitude, coords?.longitude, radiusMiles, filteredHubs.length, mapBottomPad]);

  const handleHubSelect = (hub: HubRow) => {
    setSelectedHub(hub);
    const lat = hub.latitude ?? 51.5074;
    const lng = hub.longitude ?? -0.1278;
    setRegion({
      latitude: lat,
      longitude: lng,
      latitudeDelta: 0.001,
      longitudeDelta: 0.001,
    });
  };

  const handleCardContinue = async (hub: HubRow) => {
    handleHubSelect(hub);
    await hapticFeedback('medium');
    if (!vehicleId) {
      router.push({
        pathname: '/owner/booking/physical/vehicle',
        params: { locationId: hub.id },
      });
      return;
    }
    router.push({
      pathname: '/owner/booking/physical/service',
      params: {
        locationId: hub.id,
        vehicleId,
        ...(vehicleIds ? { vehicleIds } : {}),
      },
    });
  };

  const openRadiusModal = async () => {
    await hapticFeedback('light');
    setRadiusModalVisible(true);
  };

  const openHubInfo = async (hub: HubRow) => {
    hapticFeedback('light');
    setInfoModalHub(hub);
    setHubStats(null);
    try {
      const [completedRes, activeRes] = await Promise.all([
        supabase.from('bookings').select('id', { count: 'exact', head: true }).eq('location_id', hub.id).eq('status', 'completed'),
        supabase.from('bookings').select('id', { count: 'exact', head: true }).eq('location_id', hub.id).in('status', ['scheduled', 'in_progress', 'valeter_assigned', 'en_route', 'arrived']),
      ]);
      setHubStats({
        completed: (completedRes as { count?: number })?.count ?? 0,
        active: (activeRes as { count?: number })?.count ?? 0,
      });
    } catch {
      setHubStats({ completed: 0, active: 0 });
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      <SafeMapView
        ref={mapRef}
        style={StyleSheet.absoluteFill}
        region={region}
        onRegionChangeComplete={setRegion}
        customMapStyle={BOOKING_MAP_STYLE}
        userInterfaceStyle={MAP_LOCKED_DARK}
        showsUserLocation={false}
        showsMyLocationButton={false}
        toolbarEnabled={false}
        mapPadding={{
          top: Math.max(insets.top, 8) + 72,
          right: 12,
          bottom: mapBottomPad,
          left: 12,
        }}
        legalLabelInsets={{
          top: 0,
          right: 10,
          bottom: mapBottomPad - 36,
          left: 10,
        }}
      >
        {coords ? (
          <Circle
            center={{ latitude: coords.latitude, longitude: coords.longitude }}
            radius={radiusMiles * 1609.34}
            strokeColor={`${SKY}99`}
            fillColor={`${SKY}18`}
            strokeWidth={2}
          />
        ) : null}
        {coords ? (
          <Marker coordinate={{ latitude: coords.latitude, longitude: coords.longitude }} tracksViewChanges={false}>
            <MapMarkerCustomerVehicle size={40} variant="pin" />
          </Marker>
        ) : null}
        {filteredHubs.map((hub) => (
          <Marker
            key={String(hub.id)}
            coordinate={{ latitude: hub.latitude, longitude: hub.longitude }}
            tracksViewChanges={false}
            onPress={() => {
              void hapticFeedback('light');
              handleHubSelect(hub);
            }}
          >
            <MapMarkerScheduledHub />
          </Marker>
        ))}
      </SafeMapView>

      <TouchableOpacity
        style={[styles.recenterButtonFloating, { top: Math.max(insets.top, 8) + 76, right: 16 }]}
        onPress={() => {
          void hapticFeedback('light');
          if (!coords) return;
          const r = {
            latitude: coords.latitude,
            longitude: coords.longitude,
            latitudeDelta: 0.04,
            longitudeDelta: 0.04,
          };
          setRegion(r);
          mapRef.current?.animateToRegion(r, MAP_CAMERA_ANIMATION_DURATION);
        }}
        activeOpacity={0.85}
        accessibilityLabel="Recenter map on your location"
      >
        <Ionicons name="locate" size={22} color={SKY} />
      </TouchableOpacity>

      <AppHeader
        title="Nearby car washes"
        subtitle="Pick a location"
        showBack
        fullWidth
        onBack={() => router.back()}
        rightAction={
          <TouchableOpacity onPress={openRadiusModal} style={styles.radiusButton} activeOpacity={0.8}>
            <Ionicons name="radio-button-on" size={18} color={SKY} />
            <Text style={styles.radiusButtonText}>{radiusMiles} mi</Text>
          </TouchableOpacity>
        }
      />

      <Animated.View
        style={[
          styles.sheetContainer,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
            bottom: -10,
            paddingBottom: Math.max(insets.bottom, 12) + 8,
          },
        ]}
      >
        <BusinessSheetBackground />
        <BookingSheetPremiumLayers />
        <View style={styles.sheetHandle} />
        <View style={styles.cardsContainer}>
          <ScrollView
            ref={cardsScrollRef}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.cardsScrollContent}
            snapToInterval={HUB_CARD_STEP}
            decelerationRate="fast"
          >
            {filteredHubs.map((hub) => {
              const primaryColor = SKY;
              return (
                <View key={hub.id} style={[styles.cardWrapper, { width: HUB_CARD_WIDTH }]}>
                  <View style={[ix.cardWrap, { width: HUB_CARD_WIDTH }]}>
                    <IndexTrackingCardShell accentColor={primaryColor} style={styles.hubCardShell}>
                      <View style={ix.optionCardTopRow}>
                        <GradientIconBox
                          icon="camera-outline"
                          colors={accentToGradient(primaryColor)}
                          boxSize={44}
                          borderRadius={16}
                          elevated
                          size={20}
                        />
                        <View style={ix.optionTitleMain}>
                          <Text style={ix.optionKicker}>LOCAL HUB</Text>
                          <Pressable
                            onPress={() => {
                              hapticFeedback('light');
                              openHubInfo(hub);
                            }}
                            hitSlop={6}
                          >
                            <Text style={ix.optionTitle} numberOfLines={1}>
                              {hub.name}
                            </Text>
                          </Pressable>
                          <Text style={ix.optionSubtitle} numberOfLines={1}>{hub.address}</Text>
                        </View>
                        {selectedHub?.id === hub.id ? (
                          <HubGlassIcon icon="checkmark" accent="sky" size={44} iconSize={20} />
                        ) : (
                          <View style={styles.hubCardTrailSpacer} />
                        )}
                      </View>
                      <View style={ix.optionFooterRow}>
                        <View style={ix.optionFooterLeft}>
                          <View style={[ix.optionStatusPill, { backgroundColor: 'rgba(16,185,129,0.2)' }]}>
                            <View style={ix.optionStatusDot} />
                            <Text style={ix.optionStatusText}>Live</Text>
                          </View>
                        </View>
                        <TouchableOpacity
                          style={[ix.optionContinueInline, styles.hubContinueChip]}
                          onPress={() => { void handleCardContinue(hub); }}
                          activeOpacity={0.88}
                        >
                          <Text style={[ix.optionContinueText, { color: primaryColor }]}>Continue</Text>
                          <Ionicons name="chevron-forward" size={15} color={primaryColor} />
                        </TouchableOpacity>
                      </View>
                    </IndexTrackingCardShell>
                  </View>
                </View>
              );
            })}
          </ScrollView>
        </View>
      </Animated.View>

      <BookingBottomSheetOverlay visible={!!infoModalHub} onClose={() => setInfoModalHub(null)} maxHeightRatio={0.82}>
        {infoModalHub ? (
          <HubSpotlightSheetBody
            name={infoModalHub.name}
            address={infoModalHub.address}
            rating={infoModalHub.rating}
            washesCompleted={hubStats?.completed ?? null}
            distanceMiles={(() => {
              const d = calculateDistance(infoModalHub);
              return d != null ? Number.parseFloat(d) : null;
            })()}
            createdAt={infoModalHub.created_at ?? null}
            onSelectHub={() => {
              const hubToSelect = filteredHubs.find((h) => String(h.id) === String(infoModalHub.id)) ?? infoModalHub;
              handleHubSelect(hubToSelect);
              setInfoModalHub(null);
            }}
          />
        ) : null}
      </BookingBottomSheetOverlay>

      {/* Radius popup overlay */}
      <Modal
        visible={radiusModalVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setRadiusModalVisible(false)}
      >
        <Pressable
          style={styles.modalOverlay}
          onPress={() => setRadiusModalVisible(false)}
        >
          <Pressable style={styles.modalContent} onPress={(e) => e.stopPropagation()}>
            <BlurView intensity={40} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
            <LinearGradient
              colors={['rgba(255,255,255,0.14)', 'rgba(255,255,255,0)']}
              style={styles.modalSheen}
              pointerEvents="none"
            />
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Search Radius</Text>
                <WWSheetCloseButton
                  variant="plain"
                  size={40}
                  iconSize={24}
                  iconColor={colors.headerSubtext}
                  hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
                  onPress={() => setRadiusModalVisible(false)}
                  accessibilityLabel="Close"
                />
            </View>
            <Text style={styles.modalValue}>{radiusMiles} miles</Text>
            <Slider
              minimumValue={5}
              maximumValue={60}
              step={1}
              value={radiusMiles}
              onValueChange={setRadiusMiles}
              minimumTrackTintColor={SKY}
              maximumTrackTintColor="#334155"
              thumbTintColor={SKY}
              style={styles.slider}
            />
            <TouchableOpacity
              onPress={() => {
                setRadiusModalVisible(false);
                hapticFeedback('light');
              }}
              style={styles.modalDone}
              activeOpacity={0.9}
            >
              <BlurView intensity={30} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
              <View style={[StyleSheet.absoluteFill, styles.modalDoneFill]} pointerEvents="none" />
              <LinearGradient
                colors={['rgba(255,255,255,0.2)', 'rgba(255,255,255,0)']}
                start={{ x: 0.5, y: 0 }}
                end={{ x: 0.5, y: 1 }}
                style={styles.modalDoneSheen}
                pointerEvents="none"
              />
              <Text style={styles.modalDoneText}>Done</Text>
            </TouchableOpacity>
          </Pressable>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  recenterButtonFloating: {
    position: 'absolute',
    zIndex: 100,
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: 'rgba(15,23,42,0.72)',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
  },
  radiusButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    height: 44,
    paddingHorizontal: 14,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(148,196,220,0.26)',
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  radiusButtonText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
  },
  sheetContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    ...PREMIUM_BOOKING_MAP_SHEET_GLASS,
  },
  sheetHandle: {
    width: 46,
    height: 4,
    borderRadius: 999,
    backgroundColor: 'rgba(148,163,184,0.55)',
    alignSelf: 'center',
    marginTop: 8,
    marginBottom: 8,
  },
  cardsContainer: {
    width: '100%',
    paddingHorizontal: 16,
  },
  cardsScrollContent: {
    paddingRight: 16,
    paddingBottom: 6,
  },
  cardWrapper: {
    marginRight: 12,
  },
  hubCardShell: {
    borderWidth: 0,
  },
  hubContinueChip: {
    borderWidth: 0,
    backgroundColor: 'rgba(56,189,248,0.16)',
  },
  hubCardTrailSpacer: {
    width: 44,
    height: 44,
  },
  // Modal
  modalOverlay: {
    flex: 1,
    backgroundColor: 'transparent',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  modalContent: {
    width: '100%',
    maxWidth: 320,
    backgroundColor: 'rgba(15,23,42,0.72)',
    borderRadius: INDEX_TRACKING_CARD_BORDER_RADIUS,
    padding: 24,
    overflow: 'hidden',
  },
  modalSheen: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    height: 64,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  modalTitle: {
    color: '#F8FAFC',
    fontSize: 20,
    fontWeight: '800',
    letterSpacing: -0.4,
  },
  modalValue: {
    color: '#7DD3FC',
    fontSize: 28,
    fontWeight: '800',
    letterSpacing: -0.4,
    marginBottom: 16,
    textAlign: 'center',
  },
  slider: {
    width: '100%',
    height: 40,
    marginBottom: 20,
  },
  modalDone: {
    height: 50,
    borderRadius: 25,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalDoneFill: {
    backgroundColor: 'rgba(56,189,248,0.45)',
  },
  modalDoneSheen: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    height: 25,
  },
  modalDoneText: {
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '700',
  },
});
