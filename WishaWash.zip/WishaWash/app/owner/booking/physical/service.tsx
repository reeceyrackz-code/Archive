import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Animated,
  ActivityIndicator,
  Alert,
  Dimensions,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import BackgroundVideo from '../../../../src/components/shared/BackgroundVideo';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import AppHeader from '../../../../src/components/shared/AppHeader';
import { WWSheetCloseButton } from '../../../../src/components/ui';
import { colors } from '../../../../src/constants/colors';
import IndexTrackingCardShell from '../../../../src/components/booking/IndexTrackingCardShell';
import HubGlassIcon from '../../../../src/components/shared/HubGlassIcon';
import { supabase } from '../../../../src/lib/supabase';
import {
  PREMIUM_BOOKING_MAP_SHEET_GLASS,
  getCustomerBookingSheetScreenBottom,
  BOOKING_H_CARD_GAP,
  getIndexTrackingCardWidth,
  getIndexTrackingCardSnapInterval,
} from '../../../../src/constants/bookingCardTheme';
import { getVehicleSize } from '../../../../src/pricing/pricingEngine';
import { BOOKING_FLOW_VIDEO } from '../../../../assets/assetExports';
import BusinessSheetBackground from '../../../../src/components/shared/BusinessSheetBackground';
import BookingBottomSheetOverlay from '../../../../src/components/booking/BookingBottomSheetOverlay';
import { BOOKING_INFO_SHEET_ACCENT } from '../../../../src/constants/bookingInfoSheetTheme';
import { ChoiceSheetHeader, WashTypeChoiceCards } from '../../../../src/components/booking/ChoiceSheetModern';
import {
  InfoSheetButton,
  InfoSheetHero,
  InfoSheetSection,
} from '../../../../src/components/shared/InfoSheetKit';
import { CCP } from '../../../../src/constants/carCareProLabels';
import useLiveLocation from '../../../../src/hooks/useLiveLocation';
import PhysicalBookingHubMapLayer from '../../../../src/components/booking/PhysicalBookingHubMapLayer';
import { useAuth } from '../../../../src/providers/enhanced-auth-context';
import {
  ActiveBookingBlockedError,
  createHubPendingPaymentBooking,
  fetchCarWashHub,
} from '../../../../src/utils/hubPendingPaymentBooking';
import {
  getPhysicalWashAvailableSizes,
  isBronzePhysicalWash,
  resolveVehicleSizeKey,
  sumPhysicalWashPriceForVehicles,
  type PhysicalWashServiceRow,
  type VehicleSizeKey,
} from '../../../../src/utils/physicalWashServicePricing';
import {
  formatBookingVehicleInfo,
  parseBookingVehicleIdsParam,
} from '../../../../src/utils/bookingVehicleSelection';

const SKY = colors.SKY;
const HUB_CARD_W = getIndexTrackingCardWidth(Dimensions.get('window').width);
const HUB_CARD_STEP = getIndexTrackingCardSnapInterval(Dimensions.get('window').width);

function engineSizeToKey(engineSize: ReturnType<typeof getVehicleSize>): VehicleSizeKey {
  if (engineSize === 'SMALL') return 'small';
  if (engineSize === 'XXL') return 'xxl';
  if (engineSize === 'XL') return 'xl';
  if (engineSize === 'LARGE') return 'large';
  return 'medium';
}

export default function PhysicalServiceSelection() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { coords } = useLiveLocation();
  const sheetBottom = getCustomerBookingSheetScreenBottom();
  const params = useLocalSearchParams();
  const locationId = params.locationId as string;
  const vehicleId = params.vehicleId as string;
  const vehicleIdsParam = (params.vehicleIds as string) || '';
  const bookingVehicleIds = parseBookingVehicleIdsParam(vehicleIdsParam, vehicleId);
  const scheduledAt = params.scheduledAt as string | undefined;
  const preSelectedServiceId = params.serviceId as string | undefined;

  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [washType, setWashType] = useState<'exterior' | 'interior' | 'both' | null>(null);
  const [infoModalService, setInfoModalService] = useState<PhysicalWashServiceRow | null>(null);
  const [washTypeModalVisible, setWashTypeModalVisible] = useState(false);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  const [loading, setLoading] = useState(true);
  const [serviceRows, setServiceRows] = useState<PhysicalWashServiceRow[]>([]);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [checkoutSubmitting, setCheckoutSubmitting] = useState(false);
  const [hubLocation, setHubLocation] = useState<{ latitude: number; longitude: number; name: string; address: string } | null>(null);
  /** Vehicle sizes for pricing (one per selected vehicle) */
  const [vehicleSizeKeys, setVehicleSizeKeys] = useState<VehicleSizeKey[]>(['medium']);
  const [selectedVehicles, setSelectedVehicles] = useState<
    Array<{ id: string; make?: string; model?: string; type?: string; size?: string; registration?: string }>
  >([]);

  const vehicleSizeKey = vehicleSizeKeys[0] ?? 'medium';
  const vehicleCount = Math.max(1, vehicleSizeKeys.length);
  const bookingVehicleInfo = formatBookingVehicleInfo(
    selectedVehicles.map((v) => ({
      id: v.id,
      make: v.make ?? 'Vehicle',
      model: v.model ?? '',
      ...(v.registration ? { registration: v.registration } : {}),
    })),
    bookingVehicleIds
  );

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  useEffect(() => {
    if (!locationId) {
      setLoading(false);
      setLoadError('Missing location.');
      return;
    }
    loadHubLocation();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [locationId]);

  useEffect(() => {
    if (!locationId) return;
    loadServices();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [locationId, vehicleSizeKeys.join('|')]);

  // Load selected vehicles to get sizes for pricing (cards show sum for all selected)
  useEffect(() => {
    if (bookingVehicleIds.length === 0) {
      setVehicleSizeKeys(['medium']);
      setSelectedVehicles([]);
      return;
    }
    let cancelled = false;
    (async () => {
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('id, make, model, type, size, registration')
        .in('id', bookingVehicleIds);
      if (cancelled) return;
      if (error || !data?.length) {
        setVehicleSizeKeys(['medium']);
        setSelectedVehicles([]);
        return;
      }
      const ordered = bookingVehicleIds
        .map((id) => data.find((row) => row.id === id))
        .filter(Boolean) as Array<{
        id: string;
        make?: string;
        model?: string;
        type?: string;
        size?: string;
        registration?: string;
      }>;
      setSelectedVehicles(ordered);
      setVehicleSizeKeys(
        ordered.map((v) => {
          const resolvedSize = resolveVehicleSizeKey(v.size);
          if (resolvedSize) return resolvedSize;
          return engineSizeToKey(
            getVehicleSize({
              ...(v.make ? { make: v.make } : {}),
              ...(v.model ? { model: v.model } : {}),
              ...(v.type ? { type: v.type } : {}),
            })
          );
        })
      );
    })();
    return () => {
      cancelled = true;
    };
  }, [bookingVehicleIds.join(',')]);

  const loadHubLocation = async () => {
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id, name, address, latitude, longitude')
        .eq('id', locationId)
        .single();

      if (error) throw error;
      if (data?.latitude != null && data?.longitude != null) {
        const hub = {
          latitude: Number(data.latitude),
          longitude: Number(data.longitude),
          name: data.name || 'Car Wash',
          address: data.address || '',
        };
        setHubLocation(hub);
      }
    } catch (err) {
      console.error('Error loading hub location:', err);
    }
  };

  const loadServices = async () => {
    try {
      setLoading(true);
      setLoadError(null);

      const { data, error } = await supabase
        .from('location_services')
        .select('id, location_id, service_name, is_enabled, price, duration_minutes, price_by_size')
        .eq('location_id', locationId);

      if (error) throw error;

      const rows = (data || []) as PhysicalWashServiceRow[];
      const built = rows
        .filter((row) => row.location_id === locationId && row.is_enabled !== false)
        .filter((row) => sumPhysicalWashPriceForVehicles(row, vehicleSizeKeys) != null);

      setServiceRows(built);

      if (preSelectedServiceId && built.some((b) => b.id === preSelectedServiceId)) {
        setSelectedService(preSelectedServiceId);
        if (!isBronzePhysicalWash(built.find((b) => b.id === preSelectedServiceId)?.service_name)) setWashType('both');
      } else {
        setSelectedService((prev) => {
          if (!prev) return prev;
          const stillThere = built.some((b) => b.id === prev);
          return stillThere ? prev : null;
        });
      }
    } catch (e: any) {
      console.error('[PhysicalServiceSelection] loadServices error:', e);
      setLoadError(e?.message || 'Failed to load pricing.');
      setServiceRows([]);
    } finally {
      setLoading(false);
    }
  };

  const handleServiceSelect = async (serviceId: string) => {
    await hapticFeedback('light');
    setSelectedService(serviceId);
    const selected = services.find((s) => s.id === serviceId);
    if (isBronzePhysicalWash(selected?.service_name)) {
      setWashType(null);
      setWashTypeModalVisible(true);
    } else {
      setWashType('both');
    }
  };

  const handleWashTypeSelect = async (type: 'exterior' | 'interior' | 'both') => {
    await hapticFeedback('light');
    setWashType(type);
    setWashTypeModalVisible(false);
  };

  const services = useMemo(
    () =>
      serviceRows.map((row, index) => {
        const price = sumPhysicalWashPriceForVehicles(row, vehicleSizeKeys);
        const duration = typeof row.duration_minutes === 'number' && row.duration_minutes > 0 ? row.duration_minutes : null;
        const accentPalette = ['#CD7F32', '#A8A8A8', '#FFD700', '#E5E4E2', '#22D3EE'];
        const accent = accentPalette[index % accentPalette.length];
        const sizeLabel =
          vehicleCount > 1
            ? `${vehicleCount} vehicles`
            : `${(vehicleSizeKey === 'xxl' ? 'XXL (HGV)' : vehicleSizeKey.toUpperCase())} vehicle`;

        return {
          ...row,
          name: row.service_name,
          desc: price != null
            ? `Set by this location for your ${sizeLabel}.`
            : 'Pricing is not set for your vehicle size.',
          dur: duration != null ? `${duration} min` : 'Duration not set',
          minutes: duration ?? 0,
          price: price ?? 0,
          is_enabled: row.is_enabled !== false && price != null,
          accent,
          priceTiers: getPhysicalWashAvailableSizes(row),
        };
      }).filter((row) => row.is_enabled),
    [serviceRows, vehicleSizeKey, vehicleSizeKeys, vehicleCount]
  );

  const selectedServiceData = useMemo(
    () => services.find((s) => s.id === selectedService) || null,
    [services, selectedService]
  );

  const washTypePrice =
    selectedServiceData?.price != null ? `£${selectedServiceData.price.toFixed(0)}` : undefined;

  const serviceContinueReady = !!(
    selectedService &&
    selectedServiceData &&
    Number.isFinite(selectedServiceData.price) &&
    selectedServiceData.price > 0 &&
    (!isBronzePhysicalWash(selectedServiceData.service_name) || !!washType)
  );

  const onPrimaryContinue = async () => {
    if (!locationId || !vehicleId || !selectedService) return;
    const selected = services.find((s) => s.id === selectedService);
    if (!selected) return;

    if (!Number.isFinite(selected.price) || selected.price <= 0) {
      Alert.alert('Unavailable', 'This service does not have a price set yet. Please pick another option.');
      return;
    }

    if (isBronzePhysicalWash(selected.service_name) && !washType) {
      setWashTypeModalVisible(true);
      return;
    }

    await hapticFeedback('medium');

    const finalPrice = selected.price;
    const effectiveWashType: 'exterior' | 'interior' | 'both' =
      isBronzePhysicalWash(selected.service_name) ? (washType as 'exterior' | 'interior') : 'both';

    const baseParams = {
      serviceId: selectedService,
      vehicleId: bookingVehicleIds[0] || vehicleId,
      vehicleIds: bookingVehicleIds.join(','),
      locationId,
      washType: effectiveWashType,
      price: String(finalPrice),
      ...(bookingVehicleInfo ? { vehicleInfo: bookingVehicleInfo } : {}),
    };

    if (scheduledAt) {
      if (!user?.id) {
        Alert.alert('Sign in required', 'Please sign in to complete your booking.');
        return;
      }
      try {
        setCheckoutSubmitting(true);
        const hub = await fetchCarWashHub(locationId);
        if (!hub) {
          Alert.alert('Error', 'Could not load this location.');
          return;
        }
        const bookingId = await createHubPendingPaymentBooking({
          userId: user.id,
          vehicleId: bookingVehicleIds[0] || vehicleId,
          vehicleIds: bookingVehicleIds,
          vehicleInfo: bookingVehicleInfo || null,
          vehicleType: selectedVehicles[0]?.type ?? null,
          hub,
          service: { id: selected.id, name: selected.service_name },
          price: finalPrice,
          washType: effectiveWashType,
          scheduledAt,
        });
        router.replace({
          pathname: '/owner/booking/payment',
          params: { bookingId },
        });
      } catch (err: unknown) {
        if (err instanceof ActiveBookingBlockedError) {
          Alert.alert(
            'One booking at a time',
            'You already have an active booking. Please complete or cancel it before starting a new one.',
            [
              { text: 'OK', style: 'cancel' },
              {
                text: 'View my booking',
                onPress: () =>
                  router.push({ pathname: '/owner/booking/tracking', params: { bookingId: err.activeBookingId } } as any),
              },
            ]
          );
        } else {
          console.error('[PhysicalService] booking error', err);
          const message = err && typeof err === 'object' && 'message' in err ? String((err as { message: string }).message) : 'Unable to create booking';
          Alert.alert('Error', message);
        }
      } finally {
        setCheckoutSubmitting(false);
      }
    } else {
      router.push({
        pathname: '/owner/booking/physical/schedule',
        params: baseParams,
      });
    }
  };

  const handleExitBooking = async () => {
    await hapticFeedback('light');
    router.replace('/owner/owner-dashboard' as any);
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <AppHeader 
          title="Choose a wash" 
          showBack={true}
          fullWidth
          onBack={() => router.back()}
        />
        <View style={styles.loadingWrap}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading prices...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (loadError) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <AppHeader 
          title="Choose a wash" 
          showBack={true}
          fullWidth
          onBack={() => router.back()}
        />
        <View style={styles.loadingWrap}>
          <Ionicons name="alert-circle-outline" size={44} color={SKY} style={{ opacity: 0.9 }} />
          <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320 }]}>{loadError}</Text>
            <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              loadServices();
            }}
            style={styles.retryBtn}
            activeOpacity={0.85}
          >
            <BlurView intensity={30} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
            <View style={[StyleSheet.absoluteFill, styles.glassPillFill]} pointerEvents="none" />
            <LinearGradient
              colors={['rgba(255,255,255,0.2)', 'rgba(255,255,255,0)']}
              start={{ x: 0.5, y: 0 }}
              end={{ x: 0.5, y: 1 }}
              style={styles.retrySheen}
              pointerEvents="none"
            />
            <Ionicons name="refresh" size={18} color="#F8FAFC" />
            <Text style={styles.retryText}>Retry</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  if (!services.length) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <AppHeader 
          title="Choose a wash" 
          showBack={true}
          fullWidth
          onBack={() => router.back()}
        />
        <View style={styles.loadingWrap}>
          <Ionicons name="pricetag-outline" size={44} color={SKY} style={{ opacity: 0.9 }} />
          <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320 }]}>
            This location hasn't enabled any services yet.
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      {hubLocation && Number.isFinite(hubLocation.latitude) && Number.isFinite(hubLocation.longitude) ? (
        <PhysicalBookingHubMapLayer
          hubLatitude={hubLocation.latitude}
          hubLongitude={hubLocation.longitude}
          userLatitude={coords?.latitude}
          userLongitude={coords?.longitude}
          mapPaddingBottom={sheetBottom + 52}
        />
      ) : (
        <BackgroundVideo source={BOOKING_FLOW_VIDEO} style={StyleSheet.absoluteFill} />
      )}

      <AppHeader 
        title="Choose a wash" 
        subtitle={hubLocation?.name || 'Choose your wash service'}
        showBack={true}
        fullWidth
        onBack={() => router.back()}
        rightAction={
          <WWSheetCloseButton
            size={40}
            iconSize={22}
            onPress={handleExitBooking}
            accessibilityLabel="Exit booking"
          />
        }
      />

      <Animated.View style={[styles.cardsContainer, { opacity: fadeAnim, bottom: sheetBottom }]}>
        <View style={[styles.vehicleBottomSheet, { paddingBottom: Math.max(insets.bottom, 8) }]}>
          <BusinessSheetBackground />
          <View style={styles.locationSheetHandle} />
          <ScrollView
            horizontal
            style={styles.bookingStepHorizontalScroll}
            contentContainerStyle={styles.bookingIndexOptionsListH}
            showsHorizontalScrollIndicator={false}
            snapToInterval={HUB_CARD_STEP}
            decelerationRate="fast"
            snapToAlignment="start"
            keyboardShouldPersistTaps="handled"
          >
            {services.map((service) => {
              const isSelected = selectedService === service.id;
              const tierColor = {
                main: service.accent,
              };
              const leadIcon = service.service_name.toLowerCase().includes('detail')
                ? 'sparkles-outline'
                : service.service_name.toLowerCase().includes('repair')
                  ? 'construct-outline'
                  : 'car-sport-outline';

              return (
                <TouchableOpacity
                  key={service.id}
                  activeOpacity={0.92}
                  onPress={() => void handleServiceSelect(service.id)}
                  style={[
                    styles.physicalListCardWrap,
                    isSelected && styles.physicalListCardGlow,
                    { width: HUB_CARD_W, marginRight: BOOKING_H_CARD_GAP },
                  ]}
                >
                  <IndexTrackingCardShell
                    accentColor={tierColor.main}
                    style={[
                      styles.physicalListCard,
                      isSelected ? styles.physicalListCardSelected : undefined,
                    ]}
                  >
                    <View style={styles.physicalCardTopRow}>
                      <HubGlassIcon
                        icon={isSelected ? 'checkmark' : (leadIcon as any)}
                        accent={isSelected ? 'sky' : tierColor.main}
                        size={36}
                        iconSize={18}
                        style={styles.physicalCardIconWrap}
                      />
                      <View style={styles.physicalCardTitleMain}>
                        <Text
                          style={[styles.physicalCardTitle, isSelected && styles.physicalCardTitleSelected]}
                          numberOfLines={2}
                        >
                          {service.name}
                        </Text>
                        <Text style={styles.physicalCardSubtitle} numberOfLines={2}>
                          {service.dur} · £{service.price.toFixed(0)} for your {vehicleCount > 1 ? 'vehicles' : 'vehicle'}
                        </Text>
                        <Text style={[styles.tierTagline, { color: tierColor.main + 'CC' }]} numberOfLines={2}>
                          Prices are set by this location
                        </Text>
                      </View>
                      <TouchableOpacity
                        style={[styles.physicalInfoBtn, { backgroundColor: tierColor.main + '1F' }]}
                        onPress={() => { hapticFeedback('light'); setInfoModalService(service); }}
                        activeOpacity={0.85}
                        accessibilityLabel="Service details"
                        accessibilityRole="button"
                      >
                        <Ionicons name="information-circle-outline" size={22} color={tierColor.main} />
                      </TouchableOpacity>
                    </View>
                    {isSelected && isBronzePhysicalWash(service.service_name) ? (
                      <TouchableOpacity
                        onPress={() => setWashTypeModalVisible(true)}
                        style={[styles.washTypeChip, { backgroundColor: tierColor.main + '26' }]}
                        activeOpacity={0.8}
                      >
                        {washType ? (
                          <>
                            <Ionicons
                              name={washType === 'exterior' ? 'car-sport-outline' : 'home-outline'}
                              size={14}
                              color={tierColor.main}
                            />
                            <Text style={[styles.washTypeChipText, { color: tierColor.main }]}>
                              {washType === 'exterior' ? 'Exterior' : 'Interior'}
                            </Text>
                          </>
                        ) : (
                          <Text style={[styles.washTypeChipText, { color: tierColor.main }]}>Set clean area</Text>
                        )}
                      </TouchableOpacity>
                    ) : null}
                  </IndexTrackingCardShell>
                </TouchableOpacity>
              );
            })}
          </ScrollView>
          <View style={[styles.sheetPrimaryCtaRow, styles.sheetPrimaryCtaRowVehicleStep]}>
            <TouchableOpacity
              style={[styles.bookingSheetTrackingCta, { opacity: serviceContinueReady ? 1 : 0.45 }]}
              onPress={() => void onPrimaryContinue()}
              disabled={!serviceContinueReady || checkoutSubmitting}
              activeOpacity={0.85}
            >
              <BlurView intensity={30} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
              <View
                style={[StyleSheet.absoluteFill, serviceContinueReady ? styles.glassPillFill : styles.glassPillFillMuted]}
                pointerEvents="none"
              />
              <LinearGradient
                colors={['rgba(255,255,255,0.2)', 'rgba(255,255,255,0)']}
                start={{ x: 0.5, y: 0 }}
                end={{ x: 0.5, y: 1 }}
                style={styles.bookingSheetCtaSheen}
                pointerEvents="none"
              />
              <Ionicons name="arrow-forward-circle" size={18} color="#F8FAFC" />
              <Text style={styles.bookingSheetCtaLabel}>
                {checkoutSubmitting ? 'Creating booking…' : `Continue to ${CCP.singularShort}`}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Animated.View>

      <BookingBottomSheetOverlay visible={!!infoModalService} onClose={() => setInfoModalService(null)} maxHeightRatio={0.88}>
        {infoModalService ? (() => {
              const accent = BOOKING_INFO_SHEET_ACCENT;
              const priceTiers = getPhysicalWashAvailableSizes(infoModalService);
              const selectedVehiclePrice = sumPhysicalWashPriceForVehicles(infoModalService, vehicleSizeKeys);
              const hasDuration =
                typeof infoModalService.duration_minutes === 'number' && infoModalService.duration_minutes > 0;
              const sizeLabel = (key: string) =>
                ({ small: 'S', medium: 'M', large: 'L', xl: 'XL', xxl: 'XXL' } as Record<string, string>)[key] ??
                key.toUpperCase();
              const yourSize =
                vehicleCount > 1
                  ? `${vehicleCount} vehicles`
                  : vehicleSizeKey === 'xxl'
                    ? 'XXL (HGV)'
                    : sizeLabel(vehicleSizeKey);
              return (
                <>
                  <ScrollView
                    style={styles.infoModalScroll}
                    contentContainerStyle={styles.infoModalScrollContent}
                    showsVerticalScrollIndicator={false}
                  >
                    <InfoSheetHero
                      accent={accent}
                      icon="water"
                      eyebrow={hubLocation?.name ?? 'Set by this location'}
                      title={infoModalService.service_name}
                      subtitle="Prices and availability are managed by this location."
                      chips={[
                        {
                          icon: 'pricetag',
                          label: selectedVehiclePrice != null ? `£${selectedVehiclePrice.toFixed(0)}` : 'Unavailable',
                          ...(selectedVehiclePrice == null ? { accent: '#F87171' } : {}),
                        },
                        { icon: 'time', label: hasDuration ? `${infoModalService.duration_minutes} min` : 'Duration not set' },
                        { icon: 'car-sport', label: yourSize, accent: '#CBD5E1' },
                      ]}
                    />
                    {priceTiers.length > 0 ? (
                      <InfoSheetSection title="Price by size" icon="resize" accent={accent} index={0}>
                        <View style={styles.infoModalTiers}>
                          {priceTiers.map((tier) => {
                            const isYours = vehicleSizeKeys.includes(tier.key);
                            return (
                              <View
                                key={tier.key}
                                style={[
                                  styles.infoModalTierItem,
                                  { backgroundColor: isYours ? `${accent}2E` : 'rgba(255,255,255,0.05)' },
                                ]}
                              >
                                <Text style={styles.infoModalTierLabel}>{sizeLabel(tier.key)}</Text>
                                <Text style={[styles.infoModalTierValue, { color: tier.price != null ? accent : '#64748B' }]}>
                                  {tier.price != null ? `£${tier.price.toFixed(0)}` : '—'}
                                </Text>
                              </View>
                            );
                          })}
                        </View>
                        {selectedVehiclePrice == null ? (
                          <Text style={styles.infoModalUnavailable}>Not available for your vehicle size</Text>
                        ) : null}
                      </InfoSheetSection>
                    ) : null}
                  </ScrollView>
                  <InfoSheetButton accent={accent} label="Close" icon="close" onPress={() => setInfoModalService(null)} />
                </>
              );
            })() : null}
      </BookingBottomSheetOverlay>

      <BookingBottomSheetOverlay
        visible={washTypeModalVisible}
        onClose={() => setWashTypeModalVisible(false)}
        maxHeightRatio={0.6}
      >
        <ChoiceSheetHeader
          accent={BOOKING_INFO_SHEET_ACCENT}
          icon="water"
          eyebrow={selectedServiceData?.service_name ?? 'Wash'}
          title="What do you want cleaned?"
          subtitle="Pick the area for this booking"
        />
        <WashTypeChoiceCards
          accent={BOOKING_INFO_SHEET_ACCENT}
          value={null}
          onSelect={(id) => {
            void handleWashTypeSelect(id);
          }}
          options={[
            {
              id: 'exterior' as const,
              icon: 'car-sport',
              title: 'Exterior',
              meta: 'Body, wheels & glass',
              perks: ['Snow foam & hand wash', 'Wheels & arches', 'Windows & mirrors'],
              ...(washTypePrice ? { price: washTypePrice } : {}),
            },
            {
              id: 'interior' as const,
              icon: 'layers',
              title: 'Interior',
              meta: 'Cabin refresh',
              perks: ['Full vacuum', 'Wipe-down & wheel', 'Glass & freshener'],
              ...(washTypePrice ? { price: washTypePrice } : {}),
            },
          ]}
        />
      </BookingBottomSheetOverlay>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  cardsContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    width: '100%',
  },
  vehicleBottomSheet: {
    width: '100%',
    paddingTop: 2,
    ...PREMIUM_BOOKING_MAP_SHEET_GLASS,
  },
  locationSheetHandle: {
    width: 42,
    height: 4,
    borderRadius: 2,
    alignSelf: 'center',
    marginTop: 10,
    marginBottom: 4,
    backgroundColor: 'rgba(255,255,255,0.55)',
  },
  bookingStepHorizontalScroll: {
    flexGrow: 0,
    width: '100%',
  },
  bookingIndexOptionsListH: {
    marginTop: 10,
    paddingHorizontal: 14,
    paddingBottom: 4,
    alignItems: 'stretch',
  },
  physicalListCardWrap: {
    width: '100%',
  },
  physicalListCard: {
    width: '100%',
    minHeight: 116,
    borderWidth: 0,
  },
  physicalListCardSelected: {
    backgroundColor: 'rgba(56,189,248,0.32)',
  },
  physicalListCardGlow: {
    shadowColor: '#38BDF8',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.35,
    shadowRadius: 12,
  },
  sheetPrimaryCtaRow: {
    paddingLeft: 14,
    paddingRight: 14,
    paddingTop: 0,
    marginTop: -10,
    paddingBottom: 2,
  },
  sheetPrimaryCtaRowVehicleStep: {
    marginTop: 10,
  },
  bookingSheetTrackingCta: {
    alignSelf: 'stretch',
    height: 50,
    paddingHorizontal: 18,
    borderRadius: 25,
    overflow: 'hidden',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  glassPillFill: {
    backgroundColor: 'rgba(56,189,248,0.45)',
  },
  glassPillFillMuted: {
    backgroundColor: 'rgba(255,255,255,0.1)',
  },
  bookingSheetCtaSheen: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    height: 25,
  },
  bookingSheetCtaLabel: {
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '700',
    includeFontPadding: false,
  },
  loadingWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, paddingHorizontal: 24 },
  loadingText: { color: 'rgba(226,232,240,0.7)', fontSize: 14, fontWeight: '600' },
  retryBtn: {
    marginTop: 10,
    height: 46,
    borderRadius: 23,
    overflow: 'hidden',
    flexDirection: 'row',
    gap: 8,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 22,
  },
  retrySheen: { position: 'absolute', left: 0, right: 0, top: 0, height: 23 },
  retryText: { color: '#F8FAFC', fontSize: 15, fontWeight: '700' },
  physicalCardTopRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  physicalCardIconWrap: {
    marginRight: 10,
  },
  physicalCardTitleMain: {
    flex: 1,
    minWidth: 0,
    paddingRight: 44,
  },
  physicalCardTitle: {
    color: '#F8FAFC',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: -0.2,
    marginBottom: 3,
  },
  physicalCardTitleSelected: {
    color: '#7DD3FC',
  },
  physicalCardSubtitle: {
    color: 'rgba(226,232,240,0.7)',
    fontSize: 13,
    fontWeight: '600',
  },
  physicalInfoBtn: {
    padding: 6,
    borderRadius: 10,
  },
  washTypeChip: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 12,
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 12,
    backgroundColor: 'rgba(148,163,184,0.12)',
    gap: 8,
  },
  washTypeChipText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
    flex: 1,
  },
  tierTagline: {
    marginTop: 6,
    fontSize: 12,
    fontWeight: '600',
    lineHeight: 16,
  },
  infoModalScroll: {
    flex: 1,
  },
  infoModalScrollContent: {
    paddingTop: 4,
    paddingBottom: 16,
  },
  infoModalUnavailable: {
    color: '#F87171',
    fontSize: 13,
    fontWeight: '600',
    marginTop: 10,
    textAlign: 'center',
  },
  infoModalTiers: {
    flexDirection: 'row',
    gap: 6,
  },
  infoModalTierItem: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 4,
    borderRadius: 14,
  },
  infoModalTierLabel: {
    color: 'rgba(226,232,240,0.7)',
    fontSize: 11,
    fontWeight: '700',
    marginBottom: 4,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  infoModalTierValue: { fontSize: 16, fontWeight: '800' },
});
