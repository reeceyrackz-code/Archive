import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Alert,
  BackHandler,
  Platform,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Stack, router, useFocusEffect, useLocalSearchParams } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../../../src/lib/supabase';
import { colors } from '../../../src/constants/colors';
import AppHeader from '../../../src/components/shared/AppHeader';
import LiveTrackingSheet from '../../../src/components/booking/LiveTrackingSheet';
import WishGrantedMoment from '../../../src/components/booking/WishGrantedMoment';
import TrackingNudge, { type TrackingNudgeMessage } from '../../../src/components/booking/TrackingNudge';
import {
  TrackingProAvatar,
  TrackingProNamePill,
  TrackingProVerifiedBadge,
} from '../../../src/components/booking/TrackingProHeader';
import TrackingProProfilePopup from '../../../src/components/booking/TrackingProProfilePopup';
import TrackingStageBackdrop, { type TrackingBackdropStage } from '../../../src/components/booking/TrackingStageBackdrop';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { clearPendingRatingBookingId, setPendingRatingBookingId } from '../../../src/utils/pendingCustomerRating';
import JobReviewSheet, { type JobReviewResult } from '../../../src/components/review/JobReviewSheet';
import { payBookingTip, submitBookingReview } from '../../../src/services/BookingReviewService';
import {
  getStatusMessage,
  getStages,
  getStageProgressPercent,
  getRingColorForStep,
  isCustomerDetailingService,
  normalizeStatusForTracking,
} from '../../../src/utils/trackingStatusHelpers';
import { removeBookingFromDeviceCalendar } from '../../../src/services/BookingCalendarSync';
import { ValeterStatsService } from '../../../src/services/Valeterstatsservice';
import BookingPaymentSheet from '../../../src/components/booking/BookingPaymentSheet';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { CCP, ccpFallbackName, ccpSingularLower } from '../../../src/constants/carCareProLabels';
import { fetchValeterIdentity, resolveValeterDisplayName } from '../../../src/utils/valeterDisplayName';
import { formatDisplayName } from '../../../src/utils/formatDisplayName';
import { getServiceDisplayName, getServiceDescription } from '../../../src/utils/serviceNameMapper';
import { serviceOptions, detailingServiceOptions, repairServiceOptions } from '../../../src/constants/serviceOptions';
import FrozenBookingMapStage from '../../../src/components/booking/FrozenBookingMapStage';
import LiveEnRouteFollowMap from '../../../src/components/booking/LiveEnRouteFollowMap';
import { frozenMapViewFromCoords } from '../../../src/utils/frozenBookingMapView';
import { distanceMiles } from '../../../src/utils/mapUtils';
import { HEADER_BAR_BODY } from '../../../src/constants/headerChrome';
import { useRoadRoute } from '../../../src/utils/roadRoute';
import { jobKindFor, minutesFromDurationLabel, stationsForService, type JobKind } from '../../../src/utils/washJourney';

let useStripe: (() => any) | null = null;
if (Platform.OS !== 'web') {
  try {
    useStripe = require('@stripe/stripe-react-native').useStripe;
  } catch {
    useStripe = null;
  }
}

/** Start camera-follow of the Care Pro once they are within this range. */
const EN_ROUTE_FOLLOW_MILES = 2;
/** Rough urban driving speed used for the en-route ETA. */
const AVG_EN_ROUTE_MPH = 18;

const SKY = colors.SKY ?? '#38BDF8';

const PREVIEW_STEPS = [
  { status: 'pending_valeter_acceptance', ms: 7000 },
  { status: 'pending_payment', ms: 10000 },
  { status: 'en_route', ms: 11000 },
  { status: 'arrived', ms: 6500 },
  { status: 'in_progress', ms: 14000 },
  { status: 'completed', ms: 7500 },
] as const;
const PREVIEW_CUSTOMER = { latitude: 51.5079, longitude: -0.0877 };
const PREVIEW_PRO_START = { latitude: 51.5232, longitude: -0.1045 };
const PREVIEW_PRO_NAME = 'Jordan M.';
/** Preview cycles one wash, one detail and one repair so each journey can be seen. */
const PREVIEW_SERVICES = ['platinum-wash', 'ceramic-coating', 'headlight-restoration'] as const;
const PREVIEW_MS_PER_STATION = 2600;

function previewJourneyMs(serviceId: string): number {
  const n = stationsForService(serviceId, 'exterior', jobKindFor(serviceId, false)).length;
  return (n - 1) * PREVIEW_MS_PER_STATION + 800;
}

function previewBookingRow(status: string, serviceId: string): BookingRow {
  return {
    id: 'preview',
    status,
    service_type: serviceId,
    service_name: null,
    location_lat: PREVIEW_CUSTOMER.latitude,
    location_lng: PREVIEW_CUSTOMER.longitude,
    location_address: '1 London Bridge St, London',
    valeter_id: 'preview',
    price: 45,
    add_ons_total: 0,
    discount_amount: 0,
    platform_fee_amount: 2.5,
    wash_type: 'exterior',
    vehicle_info: 'Tesla Model 3 · White',
    vehicle_type: null,
  };
}

function moneyGBP(value: unknown) {
  const n = Number(value);
  if (!Number.isFinite(n)) return '0.00';
  return n.toFixed(2);
}

/** Price line in details: show em dash when total not stored yet */
function moneyGBPOrDash(value: unknown) {
  if (value == null || value === '') return '—';
  const n = Number(value);
  if (!Number.isFinite(n)) return '—';
  return n.toFixed(2);
}

function bookingIdFromSearchParams(params: { bookingId?: string | string[] }): string {
  const v = params.bookingId;
  if (typeof v === 'string' && v.length > 0) return v;
  if (Array.isArray(v) && typeof v[0] === 'string' && v[0].length > 0) return v[0];
  return '';
}

/** Text form of a scalar column value; objects and arrays are never stringified. */
function stringOrNull(v: unknown): string | null {
  if (typeof v === 'string') return v;
  if (typeof v === 'number' || typeof v === 'boolean' || typeof v === 'bigint') return v.toString();
  return null;
}

function numOrNull(v: unknown): number | null {
  if (typeof v === 'number') return Number.isFinite(v) ? v : null;
  const s = stringOrNull(v);
  if (!s) return null;
  const n = Number.parseFloat(s);
  return Number.isFinite(n) ? n : null;
}

function trimmedOrNull(v: unknown): string | null {
  return stringOrNull(v)?.trim() || null;
}

function nestedLocation(locRaw: unknown): { lat: number | null; lng: number | null; address: string | null } {
  if (!locRaw || typeof locRaw !== 'object') return { lat: null, lng: null, address: null };
  const o = locRaw as Record<string, unknown>;
  return {
    lat: numOrNull(o.latitude ?? o.lat),
    lng: numOrNull(o.longitude ?? o.lng),
    address: typeof o.address === 'string' ? trimmedOrNull(o.address) : null,
  };
}

function normalizeBookingRow(raw: Record<string, unknown> | null | undefined): BookingRow | null {
  if (!raw || typeof raw !== 'object') return null;
  const loc = nestedLocation(raw.location);
  const flatAddr = typeof raw.location_address === 'string' ? trimmedOrNull(raw.location_address) : null;

  return {
    id: stringOrNull(raw.id) ?? '',
    status: stringOrNull(raw.status) ?? 'pending_valeter_acceptance',
    service_type: trimmedOrNull(raw.service_type),
    service_name: trimmedOrNull(raw.service_name),
    location_lat: numOrNull(raw.location_lat) ?? loc.lat,
    location_lng: numOrNull(raw.location_lng) ?? loc.lng,
    location_address: flatAddr ?? loc.address,
    valeter_id: stringOrNull(raw.valeter_id),
    cancelled_by: trimmedOrNull(raw.cancelled_by)?.toLowerCase() ?? null,
    updated_at: stringOrNull(raw.updated_at),
    price: numOrNull(raw.price),
    add_ons_total: numOrNull(raw.add_ons_total),
    discount_amount: numOrNull(raw.discount_amount),
    platform_fee_amount: numOrNull(raw.platform_fee_amount),
    wash_type: stringOrNull(raw.wash_type),
    vehicle_info: trimmedOrNull(raw.vehicle_info),
    vehicle_type: trimmedOrNull(raw.vehicle_type),
  };
}

function findServiceOption(serviceType: string | null, serviceName: string | null) {
  const display = getServiceDisplayName(serviceType, serviceName);
  const isDetailing =
    (serviceType || '').toLowerCase().includes('detail') ||
    display.toLowerCase().includes('detail');
  const allPackages = [...serviceOptions, ...detailingServiceOptions, ...repairServiceOptions];
  const opts = isDetailing ? [...detailingServiceOptions, ...repairServiceOptions] : serviceOptions;
  let opt = serviceType ? allPackages.find((o) => o.id === serviceType) : undefined;
  if (!opt && serviceType) opt = opts.find((o) => o.id === serviceType);
  opt ??= allPackages.find((o) => o.name === display);
  return { opt, display };
}

function getServiceSummaryLines(serviceType: string | null, serviceName: string | null): string[] {
  const { opt, display } = findServiceOption(serviceType, serviceName);
  if (opt?.confirmationSummary?.length) return opt.confirmationSummary;
  if (opt?.bulletPoints?.length) return opt.bulletPoints.slice(0, 8);
  return [getServiceDescription(display)];
}

function getServiceEstimateMinutes(serviceType: string | null, serviceName: string | null, isDetailing: boolean): number {
  const { opt } = findServiceOption(serviceType, serviceName);
  return minutesFromDurationLabel(opt?.dur) ?? (isDetailing ? 150 : 45);
}

type BookingRow = {
  id: string;
  status: string;
  service_type: string | null;
  service_name: string | null;
  location_lat: number | null;
  location_lng: number | null;
  location_address: string | null;
  valeter_id: string | null;
  cancelled_by?: string | null;
  updated_at?: string | null;
  price?: number | null;
  add_ons_total?: number | null;
  discount_amount?: number | null;
  platform_fee_amount?: number | null;
  wash_type?: string | null;
  vehicle_info?: string | null;
  vehicle_type?: string | null;
};

type ValeterInfo = {
  fullName: string;
  photoUrl: string | null;
  totalJobs: number;
  reviews: number;
  rating: number;
  experienceMonths: number;
  onTimePercentage: number;
};

function statusTitle(status: string): string {
  if (status === 'pending_valeter_acceptance') return `Connecting to your ${CCP.singularShort}`;
  if (status === 'pending_payment') return 'Awaiting payment';
  if (status === 'scheduled') return 'Accepted';
  if (status === 'confirmed' || status === 'valeter_assigned') return 'Accepted';
  if (status === 'en_route') return 'On the way';
  if (status === 'arrived') return 'Arrived';
  if (status === 'in_progress') return 'In progress';
  if (status === 'completed') return 'Completed';
  if (status === 'cancelled' || status === 'valeter_declined' || status === 'valeter_timeout') {
    return 'Booking cancelled';
  }
  return 'Tracking';
}

function isCustomerInitiatedCancel(cancelledBy?: string | null): boolean {
  const v = (cancelledBy || '').toLowerCase();
  return v === 'customer' || v === 'user' || v === 'owner';
}

function isTerminalCancelStatus(status: string): boolean {
  return status === 'cancelled' || status === 'valeter_declined' || status === 'valeter_timeout';
}

function cancelExitCopy(
  status: string,
  cancelledBy?: string | null,
): { title: string; message: string } {
  const s = (status || '').toLowerCase();
  const by = (cancelledBy || '').toLowerCase();
  if (s === 'valeter_declined') {
    return {
      title: 'Pro declined',
      message: `Your ${ccpSingularLower()} declined this booking. You can book again anytime.`,
    };
  }
  if (s === 'valeter_timeout') {
    return {
      title: 'Pro timed out',
      message: `Your ${ccpSingularLower()} didn’t respond in time. This booking was cancelled.`,
    };
  }
  if (by.includes('valeter') || by === 'pro') {
    return {
      title: 'Pro cancelled',
      message: `Your ${ccpSingularLower()} cancelled this booking. You can book again anytime.`,
    };
  }
  if (by === 'system') {
    return {
      title: 'Booking cancelled',
      message: 'This booking was cancelled automatically. You can book again anytime.',
    };
  }
  return {
    title: 'Booking cancelled',
    message: 'This booking was cancelled. You can book again anytime.',
  };
}

const ECO_GREEN = colors.ECO_GREEN ?? '#10B981';
const PAYMENT_WINDOW_SEC = 5 * 60;

const WORK_LABEL: Record<JobKind, string> = { wash: 'Washing', detail: 'Detailing', repair: 'Repairing' };
const COMPLETE_LABEL: Record<JobKind, string> = { wash: 'WASH COMPLETE', detail: 'DETAIL COMPLETE', repair: 'REPAIR COMPLETE' };

const PREVIEW_WASHER_INFO: ValeterInfo = {
  fullName: PREVIEW_PRO_NAME,
  photoUrl: null,
  totalJobs: 128,
  reviews: 94,
  rating: 4.9,
  experienceMonths: 18,
  onTimePercentage: 97,
};

type LatLng = { latitude: number; longitude: number };

async function fetchValeterPresence(valeterId: string): Promise<LatLng | null> {
  const { data: p } = await supabase
    .from('valeter_presence')
    .select('last_lat,last_lng')
    .eq('user_id', valeterId)
    .maybeSingle();
  if (p?.last_lat == null || p?.last_lng == null) return null;
  return { latitude: Number(p.last_lat), longitude: Number(p.last_lng) };
}

async function fetchWasherInfo(valeterId: string, valeterName: string): Promise<ValeterInfo> {
  try {
    const [profileRes, fallbackRes, stats] = await Promise.all([
      supabase.from('valeter_profiles').select('full_name, profile_photo_url').eq('user_id', valeterId).maybeSingle(),
      supabase.from('profiles').select('full_name, profile_picture').eq('id', valeterId).maybeSingle(),
      ValeterStatsService.getValeterStats(valeterId),
    ]);
    const profile = profileRes.data as { full_name?: string | null; profile_photo_url?: string | null } | null;
    const fallback = fallbackRes.data as { full_name?: string | null; profile_picture?: string | null } | null;
    return {
      fullName: resolveValeterDisplayName(profile?.full_name, fallback?.full_name, valeterName),
      photoUrl: profile?.profile_photo_url || fallback?.profile_picture || null,
      totalJobs: stats.totalJobs || 0,
      reviews: stats.customerReviews || 0,
      rating: stats.averageRating || 0,
      experienceMonths: stats.experienceMonths || 1,
      onTimePercentage: stats.onTimePercentage || 0,
    };
  } catch {
    return {
      fullName: valeterName || ccpFallbackName(),
      photoUrl: null,
      totalJobs: 0,
      reviews: 0,
      rating: 0,
      experienceMonths: 1,
      onTimePercentage: 0,
    };
  }
}

function cancelFailureMessage(e: unknown): string {
  const msg = e && typeof e === 'object' && 'message' in e ? String((e as { message?: string }).message) : '';
  if (!msg) return 'Please try again in a moment.';
  return `${msg}\n\nIf this keeps happening, check that you own this booking and it can still be cancelled.`;
}

/** Drives the demo run (On the way → Completed) with mock data; returns a setter to jump to a step. */
function usePreviewDriver(
  isPreview: boolean,
  set: {
    setBooking: (row: BookingRow) => void;
    setValeterName: (name: string) => void;
    setLoading: (loading: boolean) => void;
    setValeterLoc: (loc: LatLng | null) => void;
  },
) {
  const { setBooking, setValeterName, setLoading, setValeterLoc } = set;
  const [previewStep, setPreviewStep] = useState(0);
  const [previewLoop, setPreviewLoop] = useState(0);
  const previewService = PREVIEW_SERVICES[previewLoop % PREVIEW_SERVICES.length];

  useEffect(() => {
    if (!isPreview) return;
    const step = PREVIEW_STEPS[previewStep];
    setBooking(previewBookingRow(step.status, previewService));
    setValeterName(PREVIEW_PRO_NAME);
    setLoading(false);
    const ms = step.status === 'in_progress' ? previewJourneyMs(previewService) + 2400 : step.ms;
    const t = setTimeout(() => {
      if (previewStep === PREVIEW_STEPS.length - 1) setPreviewLoop((l) => l + 1);
      setPreviewStep((i) => (i + 1) % PREVIEW_STEPS.length);
    }, ms);
    return () => clearTimeout(t);
  }, [isPreview, previewStep, previewService, setBooking, setValeterName, setLoading]);

  useEffect(() => {
    if (!isPreview) return;
    const step = PREVIEW_STEPS[previewStep];
    if (step.status === 'arrived') {
      setValeterLoc({ latitude: PREVIEW_CUSTOMER.latitude + 0.0004, longitude: PREVIEW_CUSTOMER.longitude });
      return;
    }
    if (step.status === 'pending_valeter_acceptance' || step.status === 'pending_payment') {
      setValeterLoc(PREVIEW_PRO_START);
      return;
    }
    if (step.status !== 'en_route') {
      setValeterLoc(null);
      return;
    }
    const startedAt = Date.now();
    const tick = () => {
      const t = Math.min(1, (Date.now() - startedAt) / step.ms);
      setValeterLoc({
        latitude: PREVIEW_PRO_START.latitude + (PREVIEW_CUSTOMER.latitude - PREVIEW_PRO_START.latitude) * t,
        longitude: PREVIEW_PRO_START.longitude + (PREVIEW_CUSTOMER.longitude - PREVIEW_PRO_START.longitude) * t,
      });
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [isPreview, previewStep, setValeterLoc]);

  return setPreviewStep;
}

function connectHint(secondsLeft: number): string {
  if (secondsLeft <= 60) return 'Hurry';
  if (secondsLeft <= 180) return 'Soon';
  return 'Live';
}

function sheetEtaFor(status: string, miles: number | null): { value: string; unit: string; caption: string } | null {
  if (status === 'en_route' && miles != null) {
    return { value: String(Math.max(1, Math.round((miles / AVG_EN_ROUTE_MPH) * 60))), unit: 'min', caption: `${miles.toFixed(1)} mi away` };
  }
  if (status === 'arrived') return { value: 'Here', unit: '', caption: 'Arrived' };
  return null;
}

function washTypeLabel(washType: string | null | undefined): string | null {
  if (!washType) return null;
  if (washType === 'exterior') return 'Exterior';
  if (washType === 'interior') return 'Interior';
  return String(washType);
}

const EN_ROUTE_OR_ARRIVED = new Set(['en_route', 'arrived']);
/** From request until the Pro pulls up, the map shows their driving route to you. */
/** Stages where the map sits in its own box between the header and the sheet instead of full-screen. */
/** How far the boxed map runs under the sheet so its rounded top corners never show a gap. */
const SHEET_TUCK = 30;
const SKIP_LEAVE_CONFIRM_KEY = 'wishawash:tracking:skipLeaveConfirm';
const ROUTE_STATUSES = new Set(['pending_valeter_acceptance', 'pending_payment', 'confirmed', 'valeter_assigned', 'en_route']);

function statusCopyFor(a: {
  rawStatus: string;
  stepStatus: Parameters<typeof getStatusMessage>[0];
  isDetailing: boolean;
  jobKind: JobKind;
  isAwaitingPro: boolean;
  proName: string | null;
}): { title: string; message: string | null } {
  if (a.isAwaitingPro) {
    return {
      title: `Connecting to your ${CCP.singularShort}`,
      message: a.proName ? 'Waiting for them to accept' : `Matching a nearby ${CCP.singularShort.toLowerCase()}`,
    };
  }
  const title = statusTitle(a.rawStatus || 'tracking');
  const base = getStatusMessage(a.stepStatus, null, a.isDetailing);
  const message = a.jobKind === 'repair' ? toRepairCopy(base) : base;
  const sameAsTitle = message.trim().toLowerCase() === title.trim().toLowerCase();
  return { title, message: sameAsTitle ? null : message };
}

function headerProFor(name: string | null, valeterId: string | null, pro: ReturnType<typeof proSummary>) {
  if (!name || !valeterId) return null;
  return { ...pro, name };
}

type StepStatus = Parameters<typeof getStages>[0];
const CHAT_LOCKED_STATUSES = new Set(['pending_valeter_acceptance', 'pending', 'pending_business_acceptance']);
const PARKED_MAP_STATUSES = new Set(['pending_valeter_acceptance', 'pending_payment', 'confirmed', 'valeter_assigned']);

function sheetExtrasFor(booking: BookingRow | null) {
  const extras: { label: string; value: string; positive?: boolean }[] = [];
  if (Number(booking?.platform_fee_amount) > 0) extras.push({ label: 'Service fee', value: `£${moneyGBP(booking?.platform_fee_amount)}` });
  if (Number(booking?.add_ons_total) > 0) extras.push({ label: 'Add-ons', value: `£${moneyGBP(booking?.add_ons_total)}` });
  if (Number(booking?.discount_amount) > 0) extras.push({ label: 'Discount', value: `−£${moneyGBP(booking?.discount_amount)}`, positive: true });
  return extras;
}

/** Everything the screen derives straight from the booking row. */
function bookingView(booking: BookingRow | null) {
  const rawStatus = booking?.status || '';
  const paymentCompleted = rawStatus !== 'pending_payment';
  return {
    rawStatus,
    stepStatus: (rawStatus || 'pending_valeter_acceptance') as StepStatus,
    chatLocked: !paymentCompleted || CHAT_LOCKED_STATUSES.has(rawStatus),
    chatLockReason: paymentCompleted
      ? { title: 'Still connecting', message: `Chat unlocks once your ${ccpSingularLower()} accepts the booking.` }
      : { title: 'Payment needed', message: 'Finish payment first, then you can message your Care Pro.' },
    isAwaitingPro: rawStatus === 'pending_valeter_acceptance',
    isPaymentDue: rawStatus === 'pending_payment',
    vehicleLabel: booking?.vehicle_info || booking?.vehicle_type || null,
    address: booking?.location_address?.trim() || null,
    price: booking?.price == null ? null : Number(booking.price),
    washType: washTypeLabel(booking?.wash_type),
    extras: sheetExtrasFor(booking),
  };
}

function showsParkedMap(status: string, isEnRouteOrArrived: boolean, hasValeterLoc: boolean): boolean {
  return PARKED_MAP_STATUSES.has(status) || (isEnRouteOrArrived && !hasValeterLoc);
}

function sheetStateFor(a: {
  isAwaitingPro: boolean;
  isPaymentDue: boolean;
  timerLabel: string;
  connectProgressPercent: number;
  secondsLeft: number;
  paymentClock: string;
  paymentSecondsLeft: number;
}): { mode: 'connecting' | 'payment' | 'live'; countdown: { label: string; progress: number; hint: string; urgent: boolean } | null } {
  if (a.isAwaitingPro) {
    return {
      mode: 'connecting',
      countdown: { label: a.timerLabel, progress: a.connectProgressPercent, hint: connectHint(a.secondsLeft), urgent: a.secondsLeft <= 60 },
    };
  }
  if (a.isPaymentDue) {
    return {
      mode: 'payment',
      countdown: {
        label: a.paymentClock,
        progress: Math.round((1 - a.paymentSecondsLeft / PAYMENT_WINDOW_SEC) * 100),
        hint: 'To pay',
        urgent: a.paymentSecondsLeft <= 60,
      },
    };
  }
  return { mode: 'live', countdown: null };
}

function proSummary(name: string | null, info: ValeterInfo | null) {
  return { name, photoUrl: info?.photoUrl ?? null, rating: info?.rating ?? 0, jobs: info?.totalJobs ?? 0 };
}

function proProfileFor(name: string | null, info: ValeterInfo | null) {
  if (!name) return null;
  return {
    name,
    photoUrl: info?.photoUrl ?? null,
    rating: info?.rating ?? 0,
    reviews: info?.reviews ?? 0,
    totalJobs: info?.totalJobs ?? 0,
    experienceMonths: info?.experienceMonths ?? 1,
    onTimePercentage: info?.onTimePercentage ?? 0,
  };
}

/** Live map (Pro + car) during On the way / Arrived when both coords exist, else the parked-car map. */
function TrackingMapLayer({
  customer,
  valeter,
  liveEligible,
  showRoute,
  accent,
  edgePadding,
  tinted,
  milesToCustomer,
  frozenMapView,
  showFrozen,
}: Readonly<{
  customer: LatLng | null;
  valeter: LatLng | null;
  liveEligible: boolean;
  showRoute: boolean;
  accent: string;
  edgePadding: { top: number; bottom: number };
  tinted: boolean;
  milesToCustomer: number | null;
  frozenMapView: ReturnType<typeof frozenMapViewFromCoords> | null;
  showFrozen: boolean;
}>) {
  if ((liveEligible || showRoute) && customer && valeter) {
    const follow = milesToCustomer != null && milesToCustomer <= EN_ROUTE_FOLLOW_MILES;
    return (
      <LiveEnRouteFollowMap customer={customer} valeter={valeter} followValeter={follow} showRoute={showRoute} accent={accent} edgePadding={edgePadding} tinted={tinted} />
    );
  }
  if (showFrozen && frozenMapView) return <FrozenBookingMapStage mapView={frozenMapView} tinted={tinted} />;
  return <LinearGradient colors={['#0c1929', '#020617', '#0f172a']} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={StyleSheet.absoluteFill} />;
}

function TrackingHeader({
  pro,
  accent,
  address,
  update,
  onProPress,
  onBack,
}: Readonly<{
  pro: { name: string; photoUrl: string | null; rating: number; jobs: number } | null;
  accent: string;
  address: string | null;
  /** When set, the header shows the live status update instead of the Pro's profile. */
  update: { title: string; message: string | null; eta: string | null } | null;
  onProPress: () => void;
  onBack: () => void;
}>) {
  if (update) {
    return (
      <AppHeader
        title="Live tracking"
        showBack
        fullWidth
        floating
        accountType="customer"
        bookingSheetHeaderChrome
        onBack={onBack}
        centerContent={
          <View style={styles.headerUpdate} accessibilityLiveRegion="polite">
            <Text style={styles.headerUpdateTitle} numberOfLines={1}>
              {update.title}
            </Text>
            {update.message ? (
              <Text style={styles.headerUpdateMessage} numberOfLines={1}>
                {update.message}
              </Text>
            ) : null}
          </View>
        }
        {...(update.eta
          ? {
              rightAction: (
                <View style={[styles.headerEta, { borderColor: `${accent}66`, backgroundColor: `${accent}1A` }]}>
                  <Ionicons name="navigate" size={13} color={accent} />
                  <Text style={[styles.headerEtaText, { color: accent }]}>{update.eta}</Text>
                </View>
              ),
            }
          : {})}
      />
    );
  }
  const proChrome = pro
    ? {
        leftAction: <TrackingProAvatar photoUrl={pro.photoUrl} accent={accent} onPress={onProPress} />,
        centerContent: <TrackingProNamePill name={pro.name} rating={pro.rating} jobs={pro.jobs} />,
        rightAction: <TrackingProVerifiedBadge />,
      }
    : {};
  const subtitle = address && !pro ? { subtitle: address } : {};
  return (
    <AppHeader
      title="Live tracking"
      {...subtitle}
      showBack={!pro}
      fullWidth
      floating
      accountType="customer"
      bookingSheetHeaderChrome
      onBack={onBack}
      {...proChrome}
    />
  );
}

function toRepairCopy(message: string): string {
  return message
    .replace(/Detail in progress/i, 'Repair in progress')
    .replaceAll(/detailing/gi, 'repair')
    .replaceAll(/detailer/gi, 'repair Pro');
}

function backdropStageFor(status: string): TrackingBackdropStage | null {
  if (status === 'pending_valeter_acceptance') return 'matching';
  if (status === 'in_progress' || status === 'completed') return status;
  return null;
}

export default function BookingTrackingRedesigned() {
  const insets = useSafeAreaInsets();
  const { height: windowHeight } = useWindowDimensions();
  const { user, updateUser } = useAuth();
  const stripe = useStripe ? useStripe() : null;
  const params = useLocalSearchParams();
  const bookingId = bookingIdFromSearchParams(params);
  /** Arrived straight from sending a request — no way back into the booking flow. */
  const justRequested = params.justRequested === '1';
  /** Demo run through On the way → Completed with mock data; no backend reads or writes. */
  const isPreview = params.preview === '1';
  const leaveTracking = useCallback(() => {
    if (!justRequested && router.canGoBack()) router.back();
    else router.replace('/owner/owner-dashboard');
  }, [justRequested]);
  const confirmLeaveTracking = useCallback(() => {
    void (async () => {
      const skip = await AsyncStorage.getItem(SKIP_LEAVE_CONFIRM_KEY).catch(() => null);
      if (skip === '1') {
        leaveTracking();
        return;
      }
      void hapticFeedback('light');
      Alert.alert('Go back home?', 'Your booking carries on. You can reopen tracking from your dashboard anytime.', [
        { text: 'Stay here', style: 'cancel' },
        {
          text: "Don't ask again",
          onPress: () => {
            AsyncStorage.setItem(SKIP_LEAVE_CONFIRM_KEY, '1').catch(() => {});
            leaveTracking();
          },
        },
        { text: 'Go home', onPress: leaveTracking },
      ]);
    })();
  }, [leaveTracking]);

  useFocusEffect(
    useCallback(() => {
      const sub = BackHandler.addEventListener('hardwareBackPress', () => {
        confirmLeaveTracking();
        return true;
      });
      return () => sub.remove();
    }, [confirmLeaveTracking])
  );
  const [booking, setBooking] = useState<BookingRow | null>(null);
  const [valeterLoc, setValeterLoc] = useState<{ latitude: number; longitude: number } | null>(null);
  const [loading, setLoading] = useState(true);
  const [washerInfo, setWasherInfo] = useState<ValeterInfo | null>(null);
  const [cancelling, setCancelling] = useState(false);
  const [valeterName, setValeterName] = useState<string>(ccpFallbackName());
  const [secondsLeft, setSecondsLeft] = useState(10 * 60);
  const [paymentSecondsLeft, setPaymentSecondsLeft] = useState(5 * 60);
  const [openingChat, setOpeningChat] = useState(false);
  const [showPaymentSheet, setShowPaymentSheet] = useState(false);
  const [showProProfile, setShowProProfile] = useState(false);
  const hasAutoCancelledRef = useRef(false);
  const hasPaymentTimedOutRef = useRef(false);
  const userCancelledRef = useRef(false);
  /** Prevents double navigation when cancel / timeout / Pro cancel fire together. */
  const leftTrackingRef = useRef(false);
  /** Ensures we only auto-navigate to rate & tip once when the job completes. */
  const hasNavigatedToCompletionRef = useRef(false);
  /** 2s Done-stage delay before opening the rating screen. */
  const completionNavTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  /** True while the delayed navigation is scheduled but has not run yet. */
  const completionNavScheduledRef = useRef(false);

  const loadBooking = useCallback(async () => {
    if (!bookingId || isPreview) return;
    let q = supabase.from('bookings').select('*').eq('id', bookingId);
    if (user?.id) {
      q = q.eq('user_id', user.id);
    }
    const { data, error } = await q.maybeSingle();
    if (error) {
      if (__DEV__) console.warn('[tracking] loadBooking', error.message);
      setBooking(null);
      setLoading(false);
      return;
    }
    const row = normalizeBookingRow(data as Record<string, unknown>);
    if (!row?.id) {
      setBooking(null);
      setLoading(false);
      return;
    }
    setBooking(row);
    if (row.valeter_id) {
      const identity = await fetchValeterIdentity(row.valeter_id);
      setValeterName(identity.name);
      setValeterLoc(await fetchValeterPresence(row.valeter_id));
    } else {
      setValeterName(ccpFallbackName());
      setValeterLoc(null);
    }
    setLoading(false);
  }, [bookingId, user?.id, isPreview]);

  const setPreviewStep = usePreviewDriver(isPreview, { setBooking, setValeterName, setLoading, setValeterLoc });

  useEffect(() => {
    if (!bookingId) {
      router.replace('/owner/owner-dashboard');
      return;
    }
    void loadBooking();
    const timer = setInterval(() => {
      void loadBooking();
    }, 15000);
    return () => clearInterval(timer);
  }, [bookingId, loadBooking]);

  useEffect(() => {
    if (!bookingId || isPreview) return;
    const channel = supabase
      .channel(`tracking-booking-${bookingId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'bookings',
          filter: `id=eq.${bookingId}`,
        },
        () => {
          void loadBooking();
        },
      )
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [bookingId, loadBooking, isPreview]);

  useEffect(() => {
    hasNavigatedToCompletionRef.current = false;
    userCancelledRef.current = false;
    leftTrackingRef.current = false;
    if (completionNavTimerRef.current) {
      clearTimeout(completionNavTimerRef.current);
      completionNavTimerRef.current = null;
    }
    completionNavScheduledRef.current = false;
  }, [bookingId]);

  const exitTrackingToDashboard = useCallback((title: string, message: string) => {
    if (leftTrackingRef.current) return;
    leftTrackingRef.current = true;
    setShowPaymentSheet(false);
    router.replace('/owner/owner-dashboard');
    setTimeout(() => {
      Alert.alert(title, message);
    }, 400);
  }, []);

  useEffect(() => {
    if (!booking?.id || loading) return;
    if (!isTerminalCancelStatus(booking.status)) return;
    if (userCancelledRef.current || isCustomerInitiatedCancel(booking.cancelled_by)) return;
    if (leftTrackingRef.current) return;
    const copy = cancelExitCopy(booking.status, booking.cancelled_by);
    void removeBookingFromDeviceCalendar(booking.id);
    exitTrackingToDashboard(copy.title, copy.message);
  }, [booking?.id, booking?.status, booking?.cancelled_by, loading, exitTrackingToDashboard]);

  const bookingStatus = booking?.status;
  const bookingIdRef = useRef(bookingId);
  bookingIdRef.current = bookingId;

  const scheduleCompletionNav = useCallback(
    (delayMs: number) => {
      if (completionNavTimerRef.current) {
        clearTimeout(completionNavTimerRef.current);
        completionNavTimerRef.current = null;
      }
      completionNavScheduledRef.current = true;
      completionNavTimerRef.current = setTimeout(() => {
        completionNavTimerRef.current = null;
        completionNavScheduledRef.current = false;
        hasNavigatedToCompletionRef.current = true;
        void hapticFeedback('heavy');
        router.replace({
          pathname: '/owner/booking/completion',
          params: { bookingId, celebrated: '1' },
        } as any);
      }, delayMs);
    },
    [bookingId],
  );

  useEffect(() => {
    if (!bookingId || loading || isPreview) return;
    if (bookingStatus !== 'completed') return;
    if (hasNavigatedToCompletionRef.current) return;

    /** Long enough to play with the rub-to-polish backdrop; polishing moves on sooner. */
    scheduleCompletionNav(8500);

    return () => {
      if (completionNavTimerRef.current) {
        clearTimeout(completionNavTimerRef.current);
        completionNavTimerRef.current = null;
      }
      completionNavScheduledRef.current = false;
    };
  }, [bookingStatus, bookingId, loading, isPreview, scheduleCompletionNav]);

  useEffect(() => {
    return () => {
      if (completionNavScheduledRef.current) {
        void setPendingRatingBookingId(bookingIdRef.current);
      }
      if (completionNavTimerRef.current) {
        clearTimeout(completionNavTimerRef.current);
        completionNavTimerRef.current = null;
      }
      completionNavScheduledRef.current = false;
    };
  }, []);

  useEffect(() => {
    const vid = booking?.valeter_id;
    if (!vid || isPreview) return;
    const channel = supabase
      .channel(`tracking-presence-${vid}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'valeter_presence',
          filter: `user_id=eq.${vid}`,
        },
        (payload) => {
          const n = payload.new as { last_lat?: number; last_lng?: number };
          if (n?.last_lat != null && n?.last_lng != null) {
            setValeterLoc({ latitude: Number(n.last_lat), longitude: Number(n.last_lng) });
          }
        },
      )
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [booking?.valeter_id, isPreview]);

  const loadWasherInfo = useCallback(async () => {
    const valeterId = booking?.valeter_id;
    if (!valeterId) {
      setWasherInfo(null);
      return;
    }
    setWasherInfo(isPreview ? PREVIEW_WASHER_INFO : await fetchWasherInfo(valeterId, valeterName));
  }, [booking?.valeter_id, valeterName, isPreview]);

  const cancelBooking = useCallback(async () => {
    if (!booking?.id || cancelling) return;
    const uid = user?.id;
    if (!uid) {
      Alert.alert('Sign in required', 'Please sign in again to cancel this booking.');
      return;
    }
    setCancelling(true);
    userCancelledRef.current = true;
    leftTrackingRef.current = true;
    const cancelledBookingId = booking.id;
    try {
      const { data: updatedRow, error } = await supabase
        .from('bookings')
        .update({
          status: 'cancelled',
          cancelled_at: new Date().toISOString(),
          cancelled_by: 'customer',
          cancellation_reason: 'Cancelled by customer from tracking',
        })
        .eq('id', cancelledBookingId)
        .eq('user_id', uid)
        .select('id')
        .maybeSingle();
      if (error) throw error;
      if (!updatedRow) {
        userCancelledRef.current = false;
        leftTrackingRef.current = false;
        Alert.alert(
          'Could not cancel',
          'Your account may not own this booking, or it was already updated. Pull to refresh or open the booking from My washes.',
        );
        return;
      }
      void removeBookingFromDeviceCalendar(cancelledBookingId);
      setShowPaymentSheet(false);
      router.replace('/owner/owner-dashboard');
    } catch (e: unknown) {
      userCancelledRef.current = false;
      leftTrackingRef.current = false;
      Alert.alert('Could not cancel', cancelFailureMessage(e));
    } finally {
      setCancelling(false);
    }
  }, [booking?.id, cancelling, user?.id]);

  const autoCancelBookingOnTimeout = useCallback(async () => {
    if (!booking?.id || leftTrackingRef.current) return;
    leftTrackingRef.current = true;
    try {
      await supabase
        .from('bookings')
        .update({
          status: 'cancelled',
          cancelled_at: new Date().toISOString(),
          cancelled_by: 'system',
          cancellation_reason: 'No Pro accepted within the matching window',
        })
        .eq('id', booking.id)
        .eq('status', 'pending_valeter_acceptance');
      void removeBookingFromDeviceCalendar(booking.id);
    } catch {
      // Still leave tracking so the customer is not stuck on a dead matching screen.
    }
    setShowPaymentSheet(false);
    router.replace('/owner/owner-dashboard');
    setTimeout(() => {
      Alert.alert(
        'Matching timed out',
        `No ${ccpSingularLower()} accepted in time. This booking was cancelled — you can book again anytime.`,
      );
    }, 400);
  }, [booking?.id]);

  const autoCancelUnpaidBooking = useCallback(async () => {
    if (!booking?.id || hasPaymentTimedOutRef.current || leftTrackingRef.current) return;
    hasPaymentTimedOutRef.current = true;
    leftTrackingRef.current = true;
    try {
      const { error } = await supabase
        .from('bookings')
        .update({
          status: 'cancelled',
          cancelled_by: 'system',
          cancellation_reason: 'Payment window expired',
        })
        .eq('id', booking.id)
        .eq('status', 'pending_payment');
      if (error) throw error;
      void removeBookingFromDeviceCalendar(booking.id);
      setShowPaymentSheet(false);
      router.replace('/owner/owner-dashboard');
      setTimeout(() => {
        Alert.alert(
          'Payment timed out',
          'You have 5 minutes to pay after a Pro accepts. This booking was cancelled — you can book again anytime.',
        );
      }, 400);
    } catch {
      hasPaymentTimedOutRef.current = false;
      leftTrackingRef.current = false;
      Alert.alert('Payment window ended', 'Please check your booking status or try booking again.');
    }
  }, [booking?.id]);

  useEffect(() => {
    if ((booking?.status || '') !== 'pending_valeter_acceptance') {
      hasAutoCancelledRef.current = false;
      setSecondsLeft(10 * 60);
      return;
    }
    const id = setInterval(() => {
      setSecondsLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(id);
  }, [booking?.status]);

  useEffect(() => {
    if ((booking?.status || '') !== 'pending_valeter_acceptance') return;
    if (secondsLeft > 0) return;
    if (hasAutoCancelledRef.current) return;
    hasAutoCancelledRef.current = true;
    void autoCancelBookingOnTimeout();
  }, [secondsLeft, booking?.status, autoCancelBookingOnTimeout]);


  useEffect(() => {
    if ((booking?.status || '') !== 'pending_payment') {
      hasPaymentTimedOutRef.current = false;
      setPaymentSecondsLeft(PAYMENT_WINDOW_SEC);
      return;
    }
    const startedMs = booking?.updated_at ? Date.parse(booking.updated_at) : Number.NaN;
    const base = Number.isFinite(startedMs) ? startedMs : Date.now();
    const tick = () => {
      const elapsed = Math.floor((Date.now() - base) / 1000);
      setPaymentSecondsLeft(Math.max(0, PAYMENT_WINDOW_SEC - elapsed));
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [booking?.status, booking?.updated_at]);

  useEffect(() => {
    if ((booking?.status || '') !== 'pending_payment') return;
    if (paymentSecondsLeft > 0) return;
    if (hasPaymentTimedOutRef.current) return;
    void autoCancelUnpaidBooking();
  }, [paymentSecondsLeft, booking?.status, autoCancelUnpaidBooking]);

  const isDetailingJob = useMemo(
    () => isCustomerDetailingService(booking?.service_type, booking?.service_name),
    [booking?.service_type, booking?.service_name],
  );
  const jobKind = useMemo(() => jobKindFor(booking?.service_type, isDetailingJob), [booking?.service_type, isDetailingJob]);
  const view = bookingView(booking);
  const { stepStatus, chatLocked, chatLockReason, isAwaitingPro, isPaymentDue } = view;
  const stages = useMemo(() => {
    const base = getStages(stepStatus, isDetailingJob, false);
    const workLabel = WORK_LABEL[jobKind];
    return base.map((st) => (st.label === 'Washing' || st.label === 'Detailing' ? { ...st, label: workLabel, ...(jobKind === 'repair' ? { icon: 'build' as typeof st.icon } : {}) } : st));
  }, [stepStatus, isDetailingJob, jobKind]);
  const stageProgressPercent = useMemo(
    () => getStageProgressPercent(stepStatus, isDetailingJob, false),
    [stepStatus, isDetailingJob],
  );
  const statusRingColor = useMemo(() => getRingColorForStep(stepStatus) || ECO_GREEN, [stepStatus]);
  const timerLabel = useMemo(() => {
    const mins = Math.floor(secondsLeft / 60);
    const secs = secondsLeft % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }, [secondsLeft]);
  const timerAccent = useMemo(() => {
    if (secondsLeft <= 60) return '#EF4444';
    if (secondsLeft <= 180) return ECO_GREEN;
    return SKY;
  }, [secondsLeft]);
  const connectProgressPercent = useMemo(() => {
    const total = 10 * 60;
    return Math.max(0, Math.min(100, Math.round(((total - secondsLeft) / total) * 100)));
  }, [secondsLeft]);
  const [wishMomentKey, setWishMomentKey] = useState<number | null>(null);
  const prevStatusRef = useRef<string | null>(null);
  useEffect(() => {
    const next = String(booking?.status ?? '');
    const prev = prevStatusRef.current;
    prevStatusRef.current = next || prev;
    if (prev !== 'pending_valeter_acceptance' || !next || next === prev) return;
    if (['cancelled', 'declined', 'rejected', 'expired', 'valeter_declined', 'valeter_timeout'].includes(next)) return;
    setWishMomentKey(Date.now());
  }, [booking?.status]);
  const clearWishMoment = useCallback(() => setWishMomentKey(null), []);
  const normalizedStatus = normalizeStatusForTracking(String(booking?.status ?? ''));
  const customerCoord = useMemo(() => {
    const lat = booking?.location_lat;
    const lng = booking?.location_lng;
    if (lat == null || lng == null || !Number.isFinite(Number(lat)) || !Number.isFinite(Number(lng))) {
      return null;
    }
    return { latitude: Number(lat), longitude: Number(lng) };
  }, [booking?.location_lat, booking?.location_lng]);
  const frozenMapView = useMemo(() => {
    if (!customerCoord) return null;
    const view = frozenMapViewFromCoords(customerCoord.latitude, customerCoord.longitude, insets.bottom);
    return {
      ...view,
      mapPadding: { top: insets.top + HEADER_BAR_BODY, right: 0, bottom: SHEET_TUCK, left: 0 },
      legalLabelInsets: { ...view.legalLabelInsets, bottom: SHEET_TUCK + 6 },
    };
  }, [customerCoord, insets.bottom, insets.top]);

  const bookingServiceDisplay = useMemo(
    () => getServiceDisplayName(booking?.service_type, booking?.service_name) || null,
    [booking?.service_type, booking?.service_name],
  );
  const serviceSummaryLines = useMemo(
    () => getServiceSummaryLines(booking?.service_type ?? null, booking?.service_name ?? null),
    [booking?.service_type, booking?.service_name],
  );
  const isEnRouteOrArrived = EN_ROUTE_OR_ARRIVED.has(normalizedStatus);
  const milesToCustomer = useMemo(() => {
    if (!customerCoord || !valeterLoc) return null;
    return distanceMiles(valeterLoc, customerCoord);
  }, [customerCoord, valeterLoc]);
  const [sheetHeight, setSheetHeight] = useState(300);
  /** Parked car map until On the way, or when Pro location is not available yet. */
  const showFrozenParkedMap = showsParkedMap(normalizedStatus, isEnRouteOrArrived, valeterLoc != null);

  const showProRoute = ROUTE_STATUSES.has(normalizedStatus) && customerCoord != null && valeterLoc != null;
  const backdropStage = showProRoute ? null : backdropStageFor(normalizedStatus);
  const [washStartedAt, setWashStartedAt] = useState<number | null>(null);
  useEffect(() => {
    if (normalizedStatus !== 'in_progress' || !bookingId) {
      setWashStartedAt(null);
      return;
    }
    if (isPreview) {
      setWashStartedAt(Date.now());
      return;
    }
    let cancelled = false;
    const key = `wishawash:washStartedAt:${bookingId}`;
    void (async () => {
      let started = Number.NaN;
      try {
        const raw = await AsyncStorage.getItem(key);
        started = raw ? Number(raw) : Number.NaN;
      } catch {
        /* fall through to a fresh start time */
      }
      if (!Number.isFinite(started)) {
        const fromRow = booking?.updated_at ? Date.parse(booking.updated_at) : Number.NaN;
        started = Number.isFinite(fromRow) && fromRow <= Date.now() ? fromRow : Date.now();
        try {
          await AsyncStorage.setItem(key, String(started));
        } catch {
          /* journey still runs for this session */
        }
      }
      if (!cancelled) setWashStartedAt(started);
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [normalizedStatus, bookingId, isPreview]);
  const jobStations = useMemo(
    () => stationsForService(booking?.service_type, booking?.wash_type, jobKind),
    [booking?.service_type, booking?.wash_type, jobKind],
  );
  const washJourney = useMemo(
    () =>
      washStartedAt == null
        ? null
        : {
            startedAt: washStartedAt,
            estimateMs: isPreview
              ? previewJourneyMs(booking?.service_type ?? '')
              : getServiceEstimateMinutes(booking?.service_type ?? null, booking?.service_name ?? null, isDetailingJob) * 60000,
            kind: jobKind,
            stations: stationsForService(booking?.service_type, booking?.wash_type, jobKind),
          },
    [washStartedAt, isPreview, booking?.service_type, booking?.service_name, booking?.wash_type, isDetailingJob, jobKind],
  );

  const [showReview, setShowReview] = useState(false);
  const handleFinaleDone = useCallback(() => {
    if (isPreview) {
      setShowReview(true);
      return;
    }
    if (hasNavigatedToCompletionRef.current) return;
    hasNavigatedToCompletionRef.current = true;
    if (completionNavTimerRef.current) {
      clearTimeout(completionNavTimerRef.current);
      completionNavTimerRef.current = null;
    }
    completionNavScheduledRef.current = false;
    if (bookingId) void setPendingRatingBookingId(bookingId);
    void hapticFeedback('medium');
    setShowReview(true);
  }, [isPreview, bookingId]);

  const submitReview = useCallback(
    async (r: JobReviewResult) => {
      if (isPreview || !bookingId || !user?.id) return;
      if (r.tip > 0) {
        try {
          const paid = await payBookingTip(stripe, {
            bookingId,
            customerId: user.id,
            amount: r.tip,
            description: `Tip for ${ccpSingularLower()} - booking ${bookingId}`,
          });
          if (!paid) throw new Error('cancelled');
        } catch (e) {
          const msg = e instanceof Error ? e.message : '';
          if (msg !== 'cancelled') Alert.alert('Tip payment failed', msg || 'Please try again.');
          throw e;
        }
      }
      const note = [r.tags.join(' · '), r.comment].filter(Boolean).join(' — ');
      try {
        const { loyaltyBalance } = await submitBookingReview({
          bookingId,
          customerId: user.id,
          valeterId: booking?.valeter_id ?? null,
          rating: r.rating,
          comment: note || null,
          tip: r.tip,
        });
        if (loyaltyBalance != null) await updateUser({ tierPoints: loyaltyBalance });
        await clearPendingRatingBookingId();
      } catch (e) {
        Alert.alert('Could not save your review', 'Please try again.');
        throw e;
      }
    },
    [isPreview, bookingId, user?.id, stripe, booking?.valeter_id, updateUser],
  );

  const closeReview = useCallback(() => {
    setShowReview(false);
    if (isPreview) return;
    void clearPendingRatingBookingId();
    router.replace('/owner/owner-dashboard');
  }, [isPreview]);


  useEffect(() => {
    if (!booking?.valeter_id) return;
    void loadWasherInfo();
  }, [booking?.valeter_id, loadWasherInfo]);

  const liveProName = useMemo(() => {
    const raw = washerInfo?.fullName || valeterName || '';
    const trimmed = formatDisplayName(raw) || raw.trim();
    if (!trimmed || trimmed === ccpFallbackName()) return null;
    return trimmed;
  }, [washerInfo?.fullName, valeterName]);

  const liveCardAccent = isAwaitingPro ? timerAccent : statusRingColor;
  const pro = proSummary(liveProName, washerInfo);
  const headerPro = headerProFor(liveProName, booking?.valeter_id ?? null, pro);
  const paymentClock = `${String(Math.floor(paymentSecondsLeft / 60)).padStart(2, '0')}:${String(paymentSecondsLeft % 60).padStart(2, '0')}`;
  const sheet = sheetStateFor({ isAwaitingPro, isPaymentDue, timerLabel, connectProgressPercent, secondsLeft, paymentClock, paymentSecondsLeft });
  const paymentRoute = useRoadRoute(isPaymentDue && showProRoute ? valeterLoc : null, isPaymentDue && showProRoute ? customerCoord : null);
  const sheetEta = paymentRoute
    ? { value: String(paymentRoute.minutes), unit: 'min', caption: `${paymentRoute.miles.toFixed(1)} mi away` }
    : sheetEtaFor(normalizedStatus, milesToCustomer);
  const openPayment = () => {
    if (!bookingId) return;
    void hapticFeedback('light');
    setShowPaymentSheet(true);
  };
  const payNow = isPreview ? () => setPreviewStep(PREVIEW_STEPS.findIndex((s) => s.status === 'en_route')) : openPayment;
  const openTrackingChat = useCallback(() => {
    if (!bookingId || openingChat) return;
    if (isPreview) {
      Alert.alert('Preview', 'Chat with your Care Pro unlocks on a real booking.');
      return;
    }
    if (chatLocked) {
      Alert.alert(chatLockReason.title, chatLockReason.message);
      return;
    }
    setOpeningChat(true);
    void hapticFeedback('light');
    router.push({ pathname: '/owner/booking/chat', params: { bookingId } });
    setTimeout(() => setOpeningChat(false), 900);
  }, [bookingId, openingChat, chatLocked, chatLockReason.message, chatLockReason.title, isPreview]);

  const confirmCancelBooking = () => {
    void hapticFeedback('light');
    if (isPreview) {
      leaveTracking();
      return;
    }
    Alert.alert('Cancel booking?', 'This will cancel your active booking.', [
      { text: 'Keep booking', style: 'cancel' },
      { text: 'Cancel booking', style: 'destructive', onPress: () => { void cancelBooking(); } },
    ]);
  };

  const [nudge, setNudge] = useState<TrackingNudgeMessage | null>(null);
  const nudgedRef = useRef<{ booking: string; near: boolean; here: boolean }>({ booking: '', near: false, here: false });
  const nudgeEtaMin = milesToCustomer == null ? null : (milesToCustomer / AVG_EN_ROUTE_MPH) * 60;
  useEffect(() => {
    if (!bookingId) return;
    if (nudgedRef.current.booking !== bookingId) nudgedRef.current = { booking: bookingId, near: false, here: false };
    const seen = nudgedRef.current;
    const first = liveProName?.split(' ')[0] ?? 'Your Pro';
    if (normalizedStatus === 'en_route' && nudgeEtaMin != null && nudgeEtaMin <= 2.5 && !seen.near) {
      seen.near = true;
      setNudge({ id: 'near', icon: 'car-sport', title: `${first} is about 2 min away`, body: 'Unlock your car and make sure it’s easy to reach.' });
    } else if (normalizedStatus === 'arrived' && !seen.here) {
      seen.here = true;
      seen.near = true;
      setNudge({ id: 'here', icon: 'location', title: `${first} has arrived`, body: 'Pop out to say hi, and leave your keys out if they need them.' });
    } else if (normalizedStatus !== 'en_route' && normalizedStatus !== 'arrived') {
      setNudge(null);
    }
  }, [bookingId, normalizedStatus, nudgeEtaMin, liveProName]);
  const dismissNudge = useCallback(() => setNudge(null), []);

  /** The map runs up under the header (no seam); content inside it is offset by the header's height. */
  const headerClearance = insets.top + HEADER_BAR_BODY;
  const mapBoxBottom = Math.max(0, sheetHeight - SHEET_TUCK);
  const mapBoxHeight = Math.max(0, windowHeight - mapBoxBottom);

  const headerUpdate = normalizedStatus === 'en_route';
  const copy = statusCopyFor({ rawStatus: view.rawStatus, stepStatus, isDetailing: isDetailingJob, jobKind, isAwaitingPro, proName: liveProName });

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#0c1929', '#020617']} style={StyleSheet.absoluteFill} />
      <View style={[styles.mapBox, { top: 0, bottom: mapBoxBottom }]}>
        <TrackingMapLayer
          customer={customerCoord}
          valeter={valeterLoc}
          liveEligible={isEnRouteOrArrived}
          showRoute={showProRoute}
          accent={liveCardAccent}
          edgePadding={{ top: headerClearance + 20, bottom: SHEET_TUCK + 20 }}
          tinted={normalizedStatus !== 'pending_payment'}
          milesToCustomer={milesToCustomer}
          frozenMapView={frozenMapView}
          showFrozen={showFrozenParkedMap}
        />
        <TrackingStageBackdrop
          boxHeight={mapBoxHeight}
          topClearance={headerClearance}
          bottomTuck={SHEET_TUCK}
          stage={backdropStage}
          accent={liveCardAccent}
          journey={washJourney}
          stations={jobStations}
          kind={jobKind}
          proName={liveProName}
          onFinaleDone={handleFinaleDone}
        />
      </View>
      <Stack.Screen options={{ gestureEnabled: false }} />
      <TrackingHeader
        onBack={confirmLeaveTracking}
        pro={headerPro}
        accent={liveCardAccent}
        address={view.address}
        update={
          headerUpdate
            ? { title: copy.title, message: copy.message ?? null, eta: sheetEta ? (sheetEta.unit ? `${sheetEta.value} ${sheetEta.unit}` : sheetEta.value) : null }
            : null
        }
        onProPress={() => {
          void hapticFeedback('light');
          setShowProProfile(true);
        }}
      />
      <TrackingNudge nudge={nudge} accent={liveCardAccent} top={insets.top + 70} onDismiss={dismissNudge} />
      <LiveTrackingSheet
        accent={liveCardAccent}
        mode={sheet.mode}
        statusKey={String(booking?.status ?? 'loading')}
        statusTitle={copy.title}
        statusMessage={copy.message}
        serviceName={bookingServiceDisplay ?? CCP.singularShort}
        stages={stages}
        progressPercent={stageProgressPercent}
        countdown={sheet.countdown}
        eta={sheetEta}
        pro={pro}
        details={{
          price: moneyGBPOrDash(booking?.price),
          washType: view.washType,
          vehicle: view.vehicleLabel,
          address: view.address,
          includes: serviceSummaryLines,
          extras: view.extras,
        }}
        chatLocked={chatLocked}
        openingChat={openingChat}
        cancelling={cancelling}
        onChat={openTrackingChat}
        onPay={payNow}
        onCancel={confirmCancelBooking}
        onDismiss={confirmLeaveTracking}
        onCollapsedHeight={setSheetHeight}
        headerUpdate={headerUpdate}
      />
      {wishMomentKey == null ? null : (
        <WishGrantedMoment
          momentKey={wishMomentKey}
          accent={liveCardAccent}
          photoUrl={washerInfo?.photoUrl ?? null}
          onDone={clearWishMoment}
        />
      )}
      <TrackingProProfilePopup
        visible={showProProfile}
        valeterId={booking?.valeter_id ?? null}
        preview={isPreview}
        accent={liveCardAccent}
        pro={proProfileFor(liveProName, washerInfo)}
        onClose={() => setShowProProfile(false)}
      />
      <JobReviewSheet
        visible={showReview}
        proName={liveProName}
        proPhotoUrl={washerInfo?.photoUrl ?? null}
        serviceLabel={bookingServiceDisplay}
        price={view.price}
        completeLabel={COMPLETE_LABEL[jobKind]}
        onSubmit={submitReview}
        onClose={closeReview}
      />
      <BookingPaymentSheet
        visible={showPaymentSheet}
        bookingId={bookingId}
        onClose={() => setShowPaymentSheet(false)}
        onPaid={() => {
          setShowPaymentSheet(false);
          void loadBooking();
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  headerUpdate: { flex: 1, minWidth: 0, justifyContent: 'center' },
  headerUpdateTitle: { color: '#F8FAFC', fontSize: 16, fontWeight: '800', letterSpacing: -0.2 },
  headerUpdateMessage: { color: 'rgba(203,213,225,0.8)', fontSize: 12, fontWeight: '500', marginTop: 2 },
  headerEta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    height: 34,
    paddingHorizontal: 10,
    borderRadius: 12,
    borderWidth: 1,
  },
  headerEtaText: { fontSize: 13, fontWeight: '800', fontVariant: ['tabular-nums'] },
  container: { flex: 1, backgroundColor: 'transparent' },
  mapBox: { position: 'absolute', left: 0, right: 0, overflow: 'hidden' },
});
