import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Animated,
  Alert,
  ActivityIndicator,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  PanResponder,
  Dimensions,
  Keyboard,
  LayoutAnimation,
  type KeyboardEvent,
  type LayoutChangeEvent,
  type PanResponderGestureState,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import Reanimated, { FadeIn, FadeInDown } from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { router, useFocusEffect, useLocalSearchParams } from 'expo-router';
import MapView, { Region, MapPressEvent } from 'react-native-maps';
import SafeMapView from '../../../src/components/maps/SafeMapView';
import * as Location from 'expo-location';
import useLiveLocation from '../../../src/hooks/useLiveLocation';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import {
  serviceOptions,
  detailingServiceOptions,
  repairServiceOptions,
  REPAIR_PACKAGE_IDS,
  addOnOptions,
  ADD_ON_SECTION_TITLE,
  getAvailableAddOnIdsForService,
  LEGACY_ECO_SERVICE_ID_MAP,
} from '../../../src/constants/serviceOptions';
import { BookingMapChromePill } from '../../../src/components/booking/BookingMapChromeHeader';
import AppHeader from '../../../src/components/shared/AppHeader';
import { BookingHeaderMapControlButton } from '../../../src/components/shared/BookingHeaderMapControlButton';
import { colors } from '../../../src/constants/colors';
import { AUTO_SELECT_DEFAULT_VEHICLE_KEY } from '../../../src/constants/userPreferences';
import {
  CURRENT_LOCATION_ID,
  loadCustomerSavedLocations,
  loadDashboardWashLocation,
  saveDashboardWashLocationId,
  savedLocationIcon,
  savedLocationTitle,
} from '../../../src/utils/customerSavedLocations';

import {
  BOOKING_CARD,
  PREMIUM_BOOKING_MAP_SHEET_GLASS,
  BOOKING_H_CARD_GAP,
  getBookingIndexOptionCardWidth,
  getBookingIndexOptionSnapInterval,
} from '../../../src/constants/bookingCardTheme';
import BusinessSheetBackground from '../../../src/components/shared/BusinessSheetBackground';
import HubGlassIcon from '../../../src/components/shared/HubGlassIcon';
import { GlassSurface } from '../../../src/components/shared/Glass';
import { useMapChromeColors } from '../../../src/hooks/useMapChromeColors';
import { useThemeOptional } from '../../../src/contexts/ThemeContext';
import { WWPrimaryButton } from '../../../src/components/ui';
import { getAddOnIconName, getServiceTierLeadIconName, getServiceTierLeadImage } from '../../../src/components/booking/ServiceTierSpongeIcon';
import BookingBottomSheetOverlay from '../../../src/components/booking/BookingBottomSheetOverlay';
import { VehiclePickerInline } from '../../../src/components/booking/VehiclePickerSheet';
import {
  formatBookingVehicleInfo,
  sumServiceBaseForVehicles,
  toggleBookingVehicleId,
} from '../../../src/utils/bookingVehicleSelection';
import { VehicleInfoOverlay } from '../../../src/components/booking/VehicleInfoOverlay';
import {
  DEFAULT_MAP_REGION,
  LOCATION_PICKER_MAP_STYLE,
  LOCATION_PICKER_CLOSE_ZOOM_DELTA,
  MAP_LOCKED_DARK,
  MAP_CAMERA_ANIMATION_DURATION,
} from '../../../src/constants/mapConstants';
import { MapMarkerCustomerVehicle } from '../../../src/components/maps/MapMarkerViews';
import { useAdaptiveLayout } from '../../../src/constants/adaptiveLayout';
import { useBookingFlowTheme } from '../../../src/contexts/BookingFlowThemeContext';
import { MOBILE_SERVICE_ONLY_LAUNCH } from '../../../src/constants/launchCustomerScope';
import { CCP } from '../../../src/constants/carCareProLabels';
import { createMobileValeterBookingPendingPayment } from '../../../src/utils/createMobileValeterBookingPendingPayment';
import { ActiveBookingBlockedError } from '../../../src/utils/hubPendingPaymentBooking';
import { addVehicleByRegistration, cleanVehicleReg } from '../../../src/utils/vehicleQuickAdd';
import {
  buildFrozenBookingMapView,
  type FrozenBookingMapView,
} from '../../../src/utils/frozenBookingMapView';
import { getActiveBookingForCustomer } from '../../../src/utils/activeBookingGuard';
import BookingWashTypeMapPill from '../../../src/components/booking/BookingWashTypeMapPill';
import {
  InfoSheetButton,
  InfoSheetChecklist,
  InfoSheetHero,
  InfoSheetRow,
  InfoSheetSection,
} from '../../../src/components/shared/InfoSheetKit';
import {
  AddOnToggleRow,
  AddOnsSummaryBar,
  ChoiceSheetHeader,
  WashTypeChoiceCards,
  type WashTypeOption,
} from '../../../src/components/booking/ChoiceSheetModern';
import {
  ServiceModeSegmented,
  ServiceOptionCard,
  ServicePagerDots,
  ServiceSheetCta,
} from '../../../src/components/booking/ServiceSheetModern';

const SKY = colors.SKY;
/** Floating app header row below the safe area when it shows a subtitle (8 + 50pt pill + 8). */
const FLOATING_HEADER_BODY_HEIGHT = 66;
const EMPTY_VEHICLE_STATS = { washCount: 0, lastCleanedAt: null, cleanRating: null } as const;
const DETAILING_YELLOW = colors.DETAILING_YELLOW;
const REPAIR_ACCENT = colors.ECO_GREEN;
/** Active Repair tab — green (distinct from wash sky / detail yellow). */
const REPAIR_TAB_ACCENT = colors.ECO_GREEN;
const SCREEN_W = Dimensions.get('window').width;
const SCREEN_H = Dimensions.get('window').height;
/** Uber-style wish carousel — one card + peek of the next. */
const WISH_CARD_W = getBookingIndexOptionCardWidth(SCREEN_W);
const WISH_CARD_STEP = getBookingIndexOptionSnapInterval(SCREEN_W);
const WISH_CAROUSEL_H = 140;
/** Leaves room above/below the card for its selected lift and glow. */
const SERVICE_CARD_H = WISH_CAROUSEL_H - 18;
const CONDITION_BANNER_DISMISS_MS = 4600;
const BRONZE_WASH_TYPE_OPTIONS: readonly WashTypeOption<'exterior' | 'interior'>[] = [
  {
    id: 'exterior',
    icon: 'mci:car-wash',
    title: 'Exterior',
    meta: 'Body, wheels & glass',
    perks: ['Snow foam pre-wash', 'Safe hand wash', 'Wheels & arches'],
  },
  {
    id: 'interior',
    icon: 'mci:car-seat',
    title: 'Interior',
    meta: 'Cabin refresh',
    perks: ['Full vacuum', 'Surfaces wiped', 'Glass & freshener'],
  },
];
/** Keeps a dropped car this far inside the visible map. */
const PIN_EDGE_MARGIN = 36;
const CONDITION_BANNER_ADDRESS_OFFSET = 54;

const SERVICE_MODE_TAB_BASE = [
  {
    id: 'wash' as const,
    label: 'Wash',
    icon: 'mci:car-wash' as const,
    accent: SKY,
    activeBorder: 'rgba(125,211,252,0.45)',
    activeIcon: '#E0F2FE',
    idleIcon: 'rgba(148,163,184,0.55)',
  },
  {
    id: 'detailing' as const,
    label: 'Detail',
    icon: 'mci:auto-fix' as const,
    accent: DETAILING_YELLOW,
    activeBorder: 'rgba(234,179,8,0.45)',
    activeIcon: '#FDE047',
    idleIcon: 'rgba(148,163,184,0.55)',
  },
  {
    id: 'repair' as const,
    label: 'Repair',
    icon: 'mci:wrench' as const,
    accent: REPAIR_TAB_ACCENT,
    activeBorder: 'rgba(16,185,129,0.45)',
    activeIcon: '#6EE7B7',
    idleIcon: 'rgba(148,163,184,0.55)',
  },
];

type SavedLocationItem = {
  id: string;
  label: string;
  icon: keyof typeof Ionicons.glyphMap;
  address: string;
  latitude: number;
  longitude: number;
};

/** Forward-geocode result row for address search (device geocoding via Expo, no Google API). */
type AddressGeocodeSuggestion = {
  id: string;
  description: string;
  latitude: number;
  longitude: number;
};

type Vehicle = {
  id: string;
  type?: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  is_default: boolean;
  size?: string;
  image_url?: string | null;
  photo?: string | null;
};


/** Strip color for service card side border: wash tiers, or yellow for all detailing services. */
function getServiceStripColor(serviceId: string, fallback: string): string {
  const id = serviceId.toLowerCase();
  const washKey = LEGACY_ECO_SERVICE_ID_MAP[id] ?? id;
  const washMap: Record<string, string> = {
    'bronze-wash': '#92400E',
    'silver-wash': '#C0C0C0',
    'gold-wash': '#EAB308',
    'platinum-wash': '#334155',
    'emerald-wash': '#22D3EE',
  };
  if (washMap[washKey]) return washMap[washKey];
  if (REPAIR_PACKAGE_IDS.includes(id)) return REPAIR_ACCENT;
  const detailingIds = ['ceramic-coating', 'machine-polishing', 'soft-top-restoration', 'mould-removal'];
  if (detailingIds.includes(id)) return DETAILING_YELLOW;
  return fallback;
}

type BookingStep = 'location' | 'service';

type ServiceMode = 'wash' | 'detailing' | 'repair';

function getServiceModeTabAccent(mode: ServiceMode): string {
  if (mode === 'detailing') return DETAILING_YELLOW;
  if (mode === 'repair') return REPAIR_TAB_ACCENT;
  return SKY;
}

function getBookingHeaderConfig(step: BookingStep): { title: string; subtitle: string } {
  if (step === 'location') {
    return { title: 'Set location', subtitle: 'Set where your washer will arrive' };
  }
  return { title: 'Choose your wash', subtitle: 'Pick a package and any extras' };
}

/** Short tier explainer on service cards (mobile wash tiers). */
function getWashPackageTagline(serviceId: string): string | null {
  const id = serviceId.toLowerCase();
  const tierId = LEGACY_ECO_SERVICE_ID_MAP[id] ?? id;
  const map: Record<string, string> = {
    'bronze-wash': 'Interior OR exterior',
    'silver-wash': 'Interior + Exterior',
    'gold-wash': 'Interior Deep Clean',
    'platinum-wash': 'Full Valet',
    'emerald-wash': 'Premium Full Detail',
    'headlight-restoration': 'Lens clarity restore',
    'scratch-removal': 'Light scratch & swirl care',
    'paint-chip-repair': 'Chip touch-in & protection',
    'trim-restoration': 'Faded plastic revived',
    'leather-repair': 'Scuffs, wear & small tears',
    'maintenance-pack': 'Fluids, levels & quick checks',
  };
  return map[tierId] ?? null;
}

// eslint-disable-next-line sonarjs/cognitive-complexity -- multi-step booking flow; logic split via getBookingHeaderConfig and step renderers
export default function BookingCreate() {
  const params = useLocalSearchParams<{
    serviceMode?: string;
    customerOffersWater?: string;
    customerOffersElectricity?: string;
    preferredValeterId?: string;
    latitude?: string;
    longitude?: string;
    address?: string;
    startAtVehicle?: string;
    openAddressOverlay?: string;
  }>();
  const offersWater = false;
  const offersElectricity = false;
  const [infoService, setInfoService] = useState<{ id?: string; name?: string; icon?: string; desc?: string; bulletPoints?: string[]; descriptionTitle?: string } | null>(null);
  const [infoVehicle, setInfoVehicle] = useState<Vehicle | null>(null);
  const vehicleStats = EMPTY_VEHICLE_STATS;
  const [showAddressOverlay, setShowAddressOverlay] = useState(false);
  const [addressSearchInput, setAddressSearchInput] = useState('');
  const [addressSearching, setAddressSearching] = useState(false);
  const [addressSuggestions, setAddressSuggestions] = useState<AddressGeocodeSuggestion[]>([]);
  const [loadingSuggestions, setLoadingSuggestions] = useState(false);
  const [showInlineSuggestions, setShowInlineSuggestions] = useState(false);
  const [locationKeyboardHeight, setLocationKeyboardHeight] = useState(0);
  /** Header search keeps the sheet and map padding still; only the sheet's reg field lifts above the keyboard. */
  const headerSearchFocusedRef = useRef(false);
  const locationKeyboardHeightRef = useRef(0);
  locationKeyboardHeightRef.current = locationKeyboardHeight;
  const suggestDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const suggestRequestRef = useRef(0);
  const insets = useSafeAreaInsets();
  const chrome = useMapChromeColors();
  const isDark = useThemeOptional()?.isDark === true;
  const sheetRimColor = isDark ? chrome.border : undefined;
  const serviceModeTabs = SERVICE_MODE_TAB_BASE;
  const { user } = useAuth();

  useEffect(() => {
    if (!user?.id) return undefined;
    let cancelled = false;
    void getActiveBookingForCustomer(user.id).then((active) => {
      if (!cancelled && active?.id) {
        router.replace({ pathname: '/owner/booking/tracking', params: { bookingId: active.id } } as any);
      }
    });
    return () => {
      cancelled = true;
    };
  }, [user?.id]);
  const { setTheme } = useBookingFlowTheme();
  const [currentStep, setCurrentStep] = useState<BookingStep>('location');
  const [skippedLocationStep, setSkippedLocationStep] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState<{ latitude: number; longitude: number; address: string } | null>(null);
  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [selectedVehicleIds, setSelectedVehicleIds] = useState<string[]>([]);
  const [washType, setWashType] = useState<'exterior' | 'interior' | null>(null);
  const [serviceMode, setServiceMode] = useState<ServiceMode>(() => {
    const m = (params.serviceMode as string | undefined)?.toLowerCase();
    if (m === 'repair') return 'repair';
    if (m === 'detailing') return 'detailing';
    return 'wash';
  });
  const [selectedAddOns, setSelectedAddOns] = useState<string[]>([]);
  const [showAddOnsModal, setShowAddOnsModal] = useState(false);
  const [showBronzeWashTypeOverlay, setShowBronzeWashTypeOverlay] = useState(false);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const adaptive = useAdaptiveLayout();
  const { coords: liveCoords } = useLiveLocation();
  const [region, setRegion] = useState<Region | null>(null);
  const [frozenServiceMapView, setFrozenServiceMapView] = useState<FrozenBookingMapView | null>(null);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [pickerGpsReady, setPickerGpsReady] = useState(false);
  const [savedLocations, setSavedLocations] = useState<SavedLocationItem[]>([]);
  const [showVehicleRegInput, setShowVehicleRegInput] = useState(false);
  const vehicleRegInputOpenRef = useRef(false);
  vehicleRegInputOpenRef.current = showVehicleRegInput;
  const [vehicleRegInput, setVehicleRegInput] = useState('');
  const [vehicleRegSaving, setVehicleRegSaving] = useState(false);

  const mapRef = useRef<MapView>(null);
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const stepSlideAnim = useRef(new Animated.Value(0)).current;
  const sheetDragY = useRef(new Animated.Value(0)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;
  const pinLift = useRef(new Animated.Value(0)).current;
  const pinLiftedRef = useRef(false);
  const setPinLifted = useCallback(
    (lifted: boolean) => {
      if (pinLiftedRef.current === lifted) return;
      pinLiftedRef.current = lifted;
      Animated.spring(pinLift, {
        toValue: lifted ? 1 : 0,
        useNativeDriver: true,
        damping: lifted ? 18 : 11,
        stiffness: 260,
      }).start();
    },
    [pinLift]
  );
  const pinDrag = useRef(new Animated.ValueXY({ x: 0, y: 0 })).current;
  const mapStageSizeRef = useRef({ width: 0, height: 0 });
  const pickerDeltaRef = useRef(LOCATION_PICKER_CLOSE_ZOOM_DELTA);
  const onMapStageLayout = useCallback((e: LayoutChangeEvent) => {
    const { width, height } = e.nativeEvent.layout;
    mapStageSizeRef.current = { width, height };
  }, []);
  /** Where the dropped car sits relative to the map centre; the wash location is the point under it. */
  const pinOffsetRef = useRef({ x: 0, y: 0 });
  const panelHeightRef = useRef(0);
  const applyPickerCoordsRef = useRef<(coords: { latitude: number; longitude: number }) => void>(() => {});
  const resetPinOffset = useCallback(() => {
    const { x, y } = pinOffsetRef.current;
    if (x === 0 && y === 0) return;
    pinOffsetRef.current = { x: 0, y: 0 };
    Animated.timing(pinDrag, {
      toValue: { x: 0, y: 0 },
      duration: MAP_CAMERA_ANIMATION_DURATION,
      useNativeDriver: false,
    }).start();
  }, [pinDrag]);
  const movePickerTo = useCallback(
    (nextRegion: Region, duration: number) => {
      resetPinOffset();
      mapRef.current?.animateToRegion(nextRegion, duration);
    },
    [resetPinOffset]
  );
  const coordinateUnderPin = useCallback(async (fallback: { latitude: number; longitude: number }) => {
    const { x, y } = pinOffsetRef.current;
    const { width, height } = mapStageSizeRef.current;
    const map = mapRef.current;
    if ((x === 0 && y === 0) || !map || !width || !height) return fallback;
    try {
      return await map.coordinateForPoint({ x: width / 2 + x, y: height / 2 + y });
    } catch {
      return fallback;
    }
  }, []);
  const dropDraggedPin = useCallback(
    async (g: PanResponderGestureState) => {
      setPinLifted(false);
      pinDrag.flattenOffset();
      const { width, height } = mapStageSizeRef.current;
      const prev = pinOffsetRef.current;
      const maxX = Math.max(0, width / 2 - PIN_EDGE_MARGIN);
      const minY = -Math.max(0, height / 2 - PIN_EDGE_MARGIN);
      const maxY = Math.max(minY, height / 2 - panelHeightRef.current - PIN_EDGE_MARGIN);
      const raw = { x: prev.x + g.dx, y: prev.y + g.dy };
      const next = {
        x: Math.min(maxX, Math.max(-maxX, raw.x)),
        y: Math.min(maxY, Math.max(minY, raw.y)),
      };
      pinOffsetRef.current = next;
      if (next.x === raw.x && next.y === raw.y) {
        pinDrag.setValue(next);
      } else {
        Animated.spring(pinDrag, { toValue: next, useNativeDriver: false, damping: 16, stiffness: 220 }).start();
      }
      if (Math.abs(g.dx) < 4 && Math.abs(g.dy) < 4) return;
      const map = mapRef.current;
      if (!map || !width || !height) return;
      try {
        const coord = await map.coordinateForPoint({ x: width / 2 + next.x, y: height / 2 + next.y });
        suppressPickerGeocodeRef.current = false;
        hasInitializedPickerAtUserLocationRef.current = true;
        void hapticFeedback('light');
        applyPickerCoordsRef.current(coord);
      } catch {
        /* keep the previous location */
      }
    },
    [pinDrag, setPinLifted]
  );
  const pinPanResponder = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => true,
        onMoveShouldSetPanResponder: () => true,
        onPanResponderTerminationRequest: () => false,
        onPanResponderGrant: () => {
          pinDrag.stopAnimation();
          pinDrag.setOffset(pinOffsetRef.current);
          pinDrag.setValue({ x: 0, y: 0 });
          setPinLifted(true);
          void hapticFeedback('light');
        },
        onPanResponderMove: Animated.event([null, { dx: pinDrag.x, dy: pinDrag.y }], { useNativeDriver: false }),
        onPanResponderRelease: (_e, g) => {
          void dropDraggedPin(g);
        },
        onPanResponderTerminate: () => {
          setPinLifted(false);
          pinDrag.flattenOffset();
          pinDrag.setValue(pinOffsetRef.current);
        },
      }),
    [dropDraggedPin, pinDrag, setPinLifted]
  );
  const conditionBannerOpacity = useRef(new Animated.Value(0)).current;
  const conditionBannerSlide = useRef(new Animated.Value(-16)).current;
  const conditionBannerScale = useRef(new Animated.Value(0.94)).current;
  const addressPillShift = useRef(new Animated.Value(0)).current;
  const [conditionBannerMounted, setConditionBannerMounted] = useState(false);
  const pickerGeocodeDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pickerGeocodeRequestRef = useRef(0);
  const suppressPickerGeocodeRef = useRef(false);
  const hasInitializedPickerAtUserLocationRef = useRef(false);
  const pickerBootstrapInFlightRef = useRef(false);
  const userMovingPickerRef = useRef(false);
  const pickerSeededRef = useRef(false);
  const [pickerResolving, setPickerResolving] = useState(false);
  const [locationPanelHeight, setLocationPanelHeight] = useState(0);
  panelHeightRef.current = locationPanelHeight;

  const centerPickerOnCoords = useCallback(
    async (coords: { latitude: number; longitude: number }) => {
      const nextRegion: Region = {
        latitude: coords.latitude,
        longitude: coords.longitude,
        latitudeDelta: LOCATION_PICKER_CLOSE_ZOOM_DELTA,
        longitudeDelta: LOCATION_PICKER_CLOSE_ZOOM_DELTA,
      };
      suppressPickerGeocodeRef.current = true;
      setRegion(nextRegion);
      movePickerTo(nextRegion, MAP_CAMERA_ANIMATION_DURATION);
      try {
        const [result] = await Location.reverseGeocodeAsync(coords);
        const addr = result
          ? `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim() || 'Current Location'
          : 'Current Location';
        setSelectedLocation({ ...coords, address: addr });
      } catch {
        setSelectedLocation({ ...coords, address: 'Current Location' });
      }
    },
    [movePickerTo]
  );

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, { toValue: 1.2, duration: 1000, useNativeDriver: true }),
        Animated.timing(markerPulse, { toValue: 1, duration: 1000, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  useEffect(() => {
    loadVehicles();
    void AsyncStorage.removeItem('booking_create_draft_v1').catch(() => {});
  }, [user?.id]);

  useEffect(() => {
    setTheme(serviceMode === 'wash' ? 'wash' : 'detailing');
  }, [serviceMode, setTheme]);

  useEffect(() => {
    setSelectedService(null);
    setWashType(null);
    setSelectedAddOns([]);
    setShowBronzeWashTypeOverlay(false);
    setShowAddOnsModal(false);
  }, [serviceMode]);

  useEffect(() => {
    if (!showAddOnsModal && !showBronzeWashTypeOverlay) return;
    sheetDragY.setValue(0);
  }, [showAddOnsModal, showBronzeWashTypeOverlay, sheetDragY]);

  useEffect(() => {
    if (currentStep !== 'service' || serviceMode !== 'detailing') {
      setConditionBannerMounted(false);
      conditionBannerOpacity.setValue(0);
      conditionBannerSlide.setValue(-16);
      conditionBannerScale.setValue(0.94);
      addressPillShift.setValue(0);
      return;
    }

    setConditionBannerMounted(true);
    conditionBannerOpacity.setValue(0);
    conditionBannerSlide.setValue(-16);
    conditionBannerScale.setValue(0.94);
    addressPillShift.setValue(0);

    const enterAnim = Animated.parallel([
      Animated.spring(conditionBannerSlide, {
        toValue: 0,
        damping: 16,
        stiffness: 210,
        mass: 0.85,
        useNativeDriver: true,
      }),
      Animated.spring(conditionBannerScale, {
        toValue: 1,
        damping: 16,
        stiffness: 210,
        mass: 0.85,
        useNativeDriver: true,
      }),
      Animated.timing(conditionBannerOpacity, {
        toValue: 1,
        duration: 340,
        useNativeDriver: true,
      }),
      Animated.spring(addressPillShift, {
        toValue: CONDITION_BANNER_ADDRESS_OFFSET - 8,
        damping: 18,
        stiffness: 220,
        useNativeDriver: true,
      }),
    ]);

    let dismissTimer: ReturnType<typeof setTimeout> | undefined;
    enterAnim.start(() => {
      dismissTimer = setTimeout(() => {
        Animated.parallel([
          Animated.timing(conditionBannerOpacity, {
            toValue: 0,
            duration: 520,
            useNativeDriver: true,
          }),
          Animated.timing(conditionBannerSlide, {
            toValue: -22,
            duration: 520,
            useNativeDriver: true,
          }),
          Animated.timing(conditionBannerScale, {
            toValue: 0.9,
            duration: 520,
            useNativeDriver: true,
          }),
          Animated.spring(addressPillShift, {
            toValue: 0,
            damping: 20,
            stiffness: 240,
            useNativeDriver: true,
          }),
        ]).start(({ finished }) => {
          if (finished) setConditionBannerMounted(false);
        });
      }, CONDITION_BANNER_DISMISS_MS);
    });

    return () => {
      if (dismissTimer) clearTimeout(dismissTimer);
      enterAnim.stop();
    };
  }, [
    currentStep,
    serviceMode,
    conditionBannerOpacity,
    conditionBannerSlide,
    conditionBannerScale,
    addressPillShift,
  ]);

  const exitBookingFlow = () => {
    router.replace('/owner/owner-dashboard' as any);
  };

  const sheetPanResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: (_, g) => g.dy > 4 && Math.abs(g.dy) > Math.abs(g.dx),
      onPanResponderMove: (_, g) => {
        const y = Math.max(0, Math.min(g.dy, 220));
        sheetDragY.setValue(y);
      },
      onPanResponderRelease: (_, g) => {
        if (g.dy > 90) {
          Animated.timing(sheetDragY, { toValue: 220, duration: 160, useNativeDriver: true }).start(() => {
            exitBookingFlow();
          });
          return;
        }
        Animated.spring(sheetDragY, {
          toValue: 0,
          useNativeDriver: true,
          damping: 24,
          stiffness: 260,
        }).start();
      },
    })
  ).current;

  useEffect(() => {
    const lat = params.latitude ? Number(params.latitude) : Number.NaN;
    const lng = params.longitude ? Number(params.longitude) : Number.NaN;
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) return;
    const addr = (params.address as string) || 'Selected Location';
    const coords = { latitude: lat, longitude: lng };
    setSelectedLocation({ ...coords, address: addr });
    const nextRegion = { ...coords, latitudeDelta: LOCATION_PICKER_CLOSE_ZOOM_DELTA, longitudeDelta: LOCATION_PICKER_CLOSE_ZOOM_DELTA };
    setRegion(nextRegion);
    setFrozenServiceMapView(buildFrozenBookingMapView(coords, insets.bottom, nextRegion));
    setSkippedLocationStep(true);
    setCurrentStep('service');
    if (params.openAddressOverlay === 'true') {
      setShowAddressOverlay(false);
      setShowInlineSuggestions(true);
    }
  }, [params.latitude, params.longitude, params.address, params.startAtVehicle, params.openAddressOverlay, insets.bottom]);

  useEffect(() => {
    stepSlideAnim.setValue(24);
    Animated.timing(stepSlideAnim, {
      toValue: 0,
      duration: 320,
      useNativeDriver: true,
    }).start();
  }, [currentStep]);

  // Default the centred car marker to the user's exact GPS on first load.
  useEffect(() => {
    const bootstrapUserLocation = async () => {
      if (currentStep !== 'location' || selectedLocation !== null || hasInitializedPickerAtUserLocationRef.current) {
        setPickerGpsReady(true);
        return;
      }
      if (pickerBootstrapInFlightRef.current) return;
      pickerBootstrapInFlightRef.current = true;

      let coords: { latitude: number; longitude: number } | null = null;
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status === 'granted') {
          const lastKnown = await Location.getLastKnownPositionAsync().catch(() => null);
          if (lastKnown && !hasInitializedPickerAtUserLocationRef.current) {
            suppressPickerGeocodeRef.current = true;
            const lastKnownRegion: Region = {
              latitude: lastKnown.coords.latitude,
              longitude: lastKnown.coords.longitude,
              latitudeDelta: LOCATION_PICKER_CLOSE_ZOOM_DELTA,
              longitudeDelta: LOCATION_PICKER_CLOSE_ZOOM_DELTA,
            };
            setRegion(lastKnownRegion);
            movePickerTo(lastKnownRegion, 0);
          }
          const fresh = await Promise.race([
            Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.BestForNavigation }),
            new Promise<null>((resolve) => setTimeout(() => resolve(null), 4000)),
          ]).catch(() => null);
          if (fresh) coords = { latitude: fresh.coords.latitude, longitude: fresh.coords.longitude };
        }
        if (!coords && liveCoords) {
          coords = { latitude: liveCoords.latitude, longitude: liveCoords.longitude };
        }
        if (!coords || hasInitializedPickerAtUserLocationRef.current) return;
        setUserLocation(coords);
        hasInitializedPickerAtUserLocationRef.current = true;
        await centerPickerOnCoords(coords);
      } catch (error) {
        console.warn('Error getting location:', error);
      } finally {
        pickerBootstrapInFlightRef.current = false;
        setPickerGpsReady(true);
      }
    };

    void bootstrapUserLocation();
  }, [liveCoords, currentStep, selectedLocation, centerPickerOnCoords]);

  // Seed the picker from live GPS as soon as it exists so the map never opens on a placeholder region.
  useEffect(() => {
    if (region || !liveCoords || currentStep !== 'location') return;
    suppressPickerGeocodeRef.current = true;
    setRegion({
      latitude: liveCoords.latitude,
      longitude: liveCoords.longitude,
      latitudeDelta: LOCATION_PICKER_CLOSE_ZOOM_DELTA,
      longitudeDelta: LOCATION_PICKER_CLOSE_ZOOM_DELTA,
    });
  }, [liveCoords, region, currentStep]);

  // Seeds the picker's initialRegion; the map is uncontrolled so a pushed region never cancels an in-progress drag.
  useEffect(() => {
    if (region || currentStep !== 'location') return;
    if (selectedLocation) {
      suppressPickerGeocodeRef.current = true;
      setRegion({
        latitude: selectedLocation.latitude,
        longitude: selectedLocation.longitude,
        latitudeDelta: LOCATION_PICKER_CLOSE_ZOOM_DELTA,
        longitudeDelta: LOCATION_PICKER_CLOSE_ZOOM_DELTA,
      });
    } else if (pickerGpsReady) {
      suppressPickerGeocodeRef.current = true;
      setRegion(DEFAULT_MAP_REGION);
    }
  }, [region, currentStep, selectedLocation, pickerGpsReady]);

  // The picker map mounts with the screen (a late-mounted MapView can come back inert), so jump it to the first real region.
  useEffect(() => {
    if (currentStep !== 'location') {
      pickerSeededRef.current = false;
      return;
    }
    if (!region || pickerSeededRef.current) return;
    pickerSeededRef.current = true;
    suppressPickerGeocodeRef.current = true;
    mapRef.current?.animateToRegion(region, 0);
  }, [currentStep, region]);

  // The same MapView becomes the frozen service backdrop, centred on the exact spot the car was left.
  useEffect(() => {
    if (currentStep !== 'service' || !selectedLocation) return;
    const delta = region?.latitudeDelta ?? LOCATION_PICKER_CLOSE_ZOOM_DELTA;
    mapRef.current?.animateToRegion(
      {
        latitude: selectedLocation.latitude,
        longitude: selectedLocation.longitude,
        latitudeDelta: delta,
        longitudeDelta: region?.longitudeDelta ?? delta,
      },
      0
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentStep, selectedLocation?.latitude, selectedLocation?.longitude]);

  // Keep userLocation in sync when live GPS updates (without moving the picker once set).
  useEffect(() => {
    if (!liveCoords) return;
    setUserLocation({ latitude: liveCoords.latitude, longitude: liveCoords.longitude });
  }, [liveCoords]);

  useEffect(() => {
    if (currentStep !== 'service' || !selectedLocation || frozenServiceMapView) return;
    setFrozenServiceMapView(buildFrozenBookingMapView(selectedLocation, insets.bottom, region));
  }, [currentStep, selectedLocation, region, frozenServiceMapView, insets.bottom]);

  // Saved locations shared with the dashboard picker and Settings > Saved locations; refreshed on focus.
  useFocusEffect(
    useCallback(() => {
      if (!user?.id) return;
      let cancelled = false;
      void loadCustomerSavedLocations(user.id).then((list) => {
        if (cancelled) return;
        setSavedLocations(
          list.map((item) => ({
            id: item.id,
            label: savedLocationTitle(item),
            icon: savedLocationIcon(item),
            address: item.address,
            latitude: item.latitude,
            longitude: item.longitude,
          }))
        );
      });
      return () => {
        cancelled = true;
      };
    }, [user?.id])
  );

  // Open on the address picked in the dashboard picker; "Current location" keeps the GPS bootstrap.
  const appliedDashboardLocationRef = useRef(false);
  useEffect(() => {
    if (!user?.id || appliedDashboardLocationRef.current) return;
    if (currentStep !== 'location' || (params.latitude && params.longitude)) return;
    appliedDashboardLocationRef.current = true;
    void loadDashboardWashLocation(user.id).then((loc) => {
      if (!loc) return;
      const coords = { latitude: loc.latitude, longitude: loc.longitude };
      const nextRegion: Region = {
        ...coords,
        latitudeDelta: LOCATION_PICKER_CLOSE_ZOOM_DELTA,
        longitudeDelta: LOCATION_PICKER_CLOSE_ZOOM_DELTA,
      };
      hasInitializedPickerAtUserLocationRef.current = true;
      suppressPickerGeocodeRef.current = true;
      setRegion(nextRegion);
      movePickerTo(nextRegion, MAP_CAMERA_ANIMATION_DURATION);
      setSelectedLocation({ ...coords, address: loc.address });
      setPickerGpsReady(true);
    });
  }, [user?.id, currentStep, params.latitude, params.longitude]);

  const activeQuickLocationId = useMemo(() => {
    if (!selectedLocation) return null;
    const near = (a: { latitude: number; longitude: number }) =>
      Math.abs(a.latitude - selectedLocation.latitude) < 0.0003 &&
      Math.abs(a.longitude - selectedLocation.longitude) < 0.0003;
    const saved = savedLocations.find(near);
    if (saved) return saved.id;
    if (userLocation && near(userLocation)) return CURRENT_LOCATION_ID;
    return null;
  }, [selectedLocation, savedLocations, userLocation]);

  // When service or wash type changes, drop any selected add-ons that are no longer allowed
  useEffect(() => {
    const isNonWash = serviceMode === 'detailing' || serviceMode === 'repair';
    const allowed = selectedService
      ? getAvailableAddOnIdsForService(selectedService, washType ?? '', isNonWash)
      : [];
    setSelectedAddOns((prev) => prev.filter((id) => allowed.includes(id)));
  }, [selectedService, washType, serviceMode]);

  const resolvePickerAddress = async (coords: { latitude: number; longitude: number }) => {
    const requestId = Date.now();
    pickerGeocodeRequestRef.current = requestId;
    try {
      const [result] = await Location.reverseGeocodeAsync(coords);
      if (pickerGeocodeRequestRef.current !== requestId) return;
      const addr = result
        ? `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim() || 'Selected Location'
        : 'Selected Location';
      setSelectedLocation({ ...coords, address: addr });
    } catch (e) {
      if (pickerGeocodeRequestRef.current === requestId) {
        setSelectedLocation({ ...coords, address: 'Selected Location' });
      }
      console.warn('Reverse geocode error:', e);
    }
  };

  const applyPickerCoords = (coords: { latitude: number; longitude: number }) => {
    // Pin coordinates update immediately; the street name follows once geocoded.
    setPickerResolving(true);
    setSelectedLocation((prev) => ({ ...coords, address: prev?.address ?? 'Finding address…' }));
    if (pickerGeocodeDebounceRef.current) clearTimeout(pickerGeocodeDebounceRef.current);
    pickerGeocodeDebounceRef.current = setTimeout(() => {
      void resolvePickerAddress(coords).finally(() => setPickerResolving(false));
    }, 250);
  };
  applyPickerCoordsRef.current = applyPickerCoords;

  const handleMapPress = async (event: MapPressEvent) => {
    const coords = event.nativeEvent.coordinate;
    const nextRegion = {
      latitude: coords.latitude,
      longitude: coords.longitude,
      latitudeDelta: region?.latitudeDelta ?? LOCATION_PICKER_CLOSE_ZOOM_DELTA,
      longitudeDelta: region?.longitudeDelta ?? LOCATION_PICKER_CLOSE_ZOOM_DELTA,
    };
    setRegion(nextRegion);
    movePickerTo(nextRegion, MAP_CAMERA_ANIMATION_DURATION);
    await resolvePickerAddress(coords);
    await hapticFeedback('light');
  };

  const handleUseCurrentLocation = async () => {
    await hapticFeedback('medium');
    if (!userLocation) return;
    hasInitializedPickerAtUserLocationRef.current = true;
    if (user?.id) void saveDashboardWashLocationId(user.id, CURRENT_LOCATION_ID);
    await centerPickerOnCoords(userLocation);
  };

  const handlePickSavedLocation = (item: SavedLocationItem) => {
    hapticFeedback('light');
    const coords = { latitude: item.latitude, longitude: item.longitude };
    const nextRegion: Region = { ...coords, latitudeDelta: LOCATION_PICKER_CLOSE_ZOOM_DELTA, longitudeDelta: LOCATION_PICKER_CLOSE_ZOOM_DELTA };
    hasInitializedPickerAtUserLocationRef.current = true;
    suppressPickerGeocodeRef.current = true;
    setRegion(nextRegion);
    movePickerTo(nextRegion, MAP_CAMERA_ANIMATION_DURATION);
    setSelectedLocation({ ...coords, address: item.address });
    if (user?.id) void saveDashboardWashLocationId(user.id, item.id);
    setAddressSearchInput('');
    setAddressSuggestions([]);
    setShowAddressOverlay(false);
  };

  const closeAddressOverlayWithoutSaving = () => {
    setAddressSearchInput('');
    setAddressSuggestions([]);
    setShowAddressOverlay(false);
  };

  useEffect(() => {
    if (currentStep !== 'location') {
      setLocationKeyboardHeight(0);
      return;
    }
    const showEvent = Platform.OS === 'ios' ? 'keyboardWillShow' : 'keyboardDidShow';
    const hideEvent = Platform.OS === 'ios' ? 'keyboardWillHide' : 'keyboardDidHide';
    const syncWithKeyboard = (e?: KeyboardEvent) => {
      if (Platform.OS !== 'ios') return;
      LayoutAnimation.configureNext(
        LayoutAnimation.create(e?.duration || 250, LayoutAnimation.Types.keyboard, LayoutAnimation.Properties.opacity)
      );
    };
    const onShow = (e: KeyboardEvent) => {
      if (!vehicleRegInputOpenRef.current || headerSearchFocusedRef.current) return;
      syncWithKeyboard(e);
      setLocationKeyboardHeight(e.endCoordinates.height);
    };
    const onHide = (e: KeyboardEvent) => {
      if (locationKeyboardHeightRef.current === 0) return;
      syncWithKeyboard(e);
      setLocationKeyboardHeight(0);
    };
    const subShow = Keyboard.addListener(showEvent, onShow);
    const subHide = Keyboard.addListener(hideEvent, onHide);
    return () => {
      subShow.remove();
      subHide.remove();
    };
  }, [currentStep]);

  useEffect(() => {
    const allowSuggest = showAddressOverlay || currentStep === 'location';
    if (!allowSuggest) {
      setAddressSuggestions([]);
      return;
    }
    const q = addressSearchInput.trim();
    if (q.length < 2) {
      setAddressSuggestions([]);
      return;
    }
    if (suggestDebounceRef.current) clearTimeout(suggestDebounceRef.current);
    suggestDebounceRef.current = setTimeout(async () => {
      const reqId = ++suggestRequestRef.current;
      setLoadingSuggestions(true);
      try {
        const results = await Location.geocodeAsync(q);
        if (suggestRequestRef.current !== reqId) return;
        if (!results?.length) {
          setAddressSuggestions([]);
          return;
        }
        const max = Math.min(results.length, 8);
        const items: AddressGeocodeSuggestion[] = [];
        for (let i = 0; i < max; i++) {
          const r = results[i];
          let description = q;
          try {
            const [rev] = await Location.reverseGeocodeAsync({ latitude: r.latitude, longitude: r.longitude });
            if (rev) {
              const line = `${rev.street || ''} ${rev.city || ''} ${rev.postalCode || ''}`.trim();
              if (line) description = line;
            }
          } catch {
            /* keep query as label */
          }
          items.push({
            id: `${r.latitude.toFixed(5)}-${r.longitude.toFixed(5)}-${i}`,
            description,
            latitude: r.latitude,
            longitude: r.longitude,
          });
        }
        if (suggestRequestRef.current === reqId) setAddressSuggestions(items);
      } catch {
        if (suggestRequestRef.current === reqId) setAddressSuggestions([]);
      } finally {
        if (suggestRequestRef.current === reqId) setLoadingSuggestions(false);
      }
    }, 320);
    return () => {
      if (suggestDebounceRef.current) clearTimeout(suggestDebounceRef.current);
    };
  }, [showAddressOverlay, currentStep, addressSearchInput]);

  const handleSelectSuggestion = async (suggestion: AddressGeocodeSuggestion) => {
    setAddressSearching(true);
    setAddressSuggestions([]);
    try {
      const coords = { latitude: suggestion.latitude, longitude: suggestion.longitude };
      const nextRegion = { ...coords, latitudeDelta: LOCATION_PICKER_CLOSE_ZOOM_DELTA, longitudeDelta: LOCATION_PICKER_CLOSE_ZOOM_DELTA };
      suppressPickerGeocodeRef.current = true;
      setRegion(nextRegion);
      movePickerTo(nextRegion, MAP_CAMERA_ANIMATION_DURATION);
      setSelectedLocation({ ...coords, address: suggestion.description });
      setShowAddressOverlay(false);
      setAddressSearchInput('');
      await hapticFeedback('medium');
    } finally {
      setAddressSearching(false);
    }
  };

  const handleAddressSearch = async () => {
    const q = addressSearchInput.trim();
    if (!q) return;
    setAddressSearching(true);
    try {
      const results = await Location.geocodeAsync(q);
      if (results?.length && results.length > 0) {
        const { latitude, longitude } = results[0];
        const coords = { latitude, longitude };
        const nextRegion = { ...coords, latitudeDelta: LOCATION_PICKER_CLOSE_ZOOM_DELTA, longitudeDelta: LOCATION_PICKER_CLOSE_ZOOM_DELTA };
        suppressPickerGeocodeRef.current = true;
        setRegion(nextRegion);
        movePickerTo(nextRegion, MAP_CAMERA_ANIMATION_DURATION);
        const [rev] = await Location.reverseGeocodeAsync(coords);
        const addr = rev
          ? `${rev.street || ''} ${rev.city || ''} ${rev.postalCode || ''}`.trim() || q
          : q;
        setSelectedLocation({ ...coords, address: addr });
        setShowAddressOverlay(false);
        setAddressSearchInput('');
        await hapticFeedback('medium');
      } else {
        Alert.alert('Address not found', 'Try a different address or more specific search.');
      }
    } catch (e) {
      Alert.alert('Search failed', (e as Error)?.message || 'Could not find that address.');
    } finally {
      setAddressSearching(false);
    }
  };

  const loadVehicles = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('*')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false });

      if (error) throw error;
      const rows = (data || []).map((r: any) => ({ ...r, image_url: r.image_url ?? r.photo ?? null }));
      setVehicles(rows);
      if (rows.length > 0) {
        const defaultVehicle = rows.find((v: Vehicle) => v.is_default) || rows[0];
        setSelectedVehicleIds((prev) => (prev.length > 0 ? prev : [defaultVehicle.id]));
        try {
          const autoSelect = await AsyncStorage.getItem(AUTO_SELECT_DEFAULT_VEHICLE_KEY);
          if (autoSelect === 'true') {
            setCurrentStep((prev) => (prev === 'location' ? 'service' : prev));
          }
        } catch {}
      }
    } catch (error) {
      console.error('Error loading vehicles:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLocationAndVehicleContinue = async () => {
    if (!selectedLocation) {
      Alert.alert('Location Required', 'Please select a location on the map or use your current location.');
      return;
    }
    if (selectedVehicleIds.length === 0) {
      Alert.alert('Vehicle Required', 'Please choose at least one vehicle for this booking.');
      return;
    }
    await hapticFeedback('medium');
    setFrozenServiceMapView(buildFrozenBookingMapView(selectedLocation, insets.bottom, region));
    setCurrentStep('service');
  };

  const toggleSelectedVehicle = (vehicleId: string) => {
    setSelectedVehicleIds((prev) => toggleBookingVehicleId(prev, vehicleId));
  };

  const openVehicleRegInput = () => {
    setShowVehicleRegInput(true);
    setVehicleRegInput('');
    setShowInlineSuggestions(false);
    setAddressSuggestions([]);
  };

  const closeVehicleRegInput = () => {
    setShowVehicleRegInput(false);
    setVehicleRegInput('');
    setVehicleRegSaving(false);
  };

  const handleVehicleRegSubmit = async () => {
    if (!user?.id) return;
    const reg = cleanVehicleReg(vehicleRegInput);
    if (!reg) {
      Alert.alert('Registration required', 'Enter your vehicle registration to continue.');
      return;
    }

    setVehicleRegSaving(true);
    try {
      await hapticFeedback('light');
      const result = await addVehicleByRegistration({
        userId: user.id,
        registration: reg,
        isFirstVehicle: vehicles.length === 0,
      });

      if (!result.ok) {
        Alert.alert('Could not add vehicle', result.message);
        return;
      }

      await loadVehicles();
      setSelectedVehicleIds((prev) =>
        prev.includes(result.vehicleId) ? prev : [...prev, result.vehicleId]
      );
      closeVehicleRegInput();
      await hapticFeedback('medium');
    } catch (error: unknown) {
      Alert.alert('Could not add vehicle', (error as Error)?.message || 'Something went wrong. Try again.');
    } finally {
      setVehicleRegSaving(false);
    }
  };

  type ServicePickOutcome = 'bronze-overlay' | 'addons-modal' | 'ready';

  const isDetailingOrRepairPackage = serviceMode === 'detailing' || serviceMode === 'repair';

  const currentServiceOptions =
    serviceMode === 'wash'
      ? serviceOptions
      : serviceMode === 'repair'
        ? repairServiceOptions
        : detailingServiceOptions;

  const handleServiceSelect = async (serviceId: string): Promise<ServicePickOutcome> => {
    await hapticFeedback('light');
    const nextOption = currentServiceOptions.find((s) => s.id === serviceId);
    setSelectedAddOns((prev) => prev.filter((id) => !nextOption?.includedAddOnIds?.includes(id)));
    setSelectedService(serviceId);
    if (serviceId === 'bronze-wash') {
      setShowBronzeWashTypeOverlay(true);
      return 'bronze-overlay';
    }
    setWashType(null);
    const allowed = getAvailableAddOnIdsForService(serviceId, '', isDetailingOrRepairPackage);
    const opts = addOnOptions.filter(
      (a) => allowed.includes(a.id) && !nextOption?.includedAddOnIds?.includes(a.id)
    );
    if (opts.length > 0) {
      setShowAddOnsModal(true);
      return 'addons-modal';
    }
    return 'ready';
  };

  /** Build valeter params from explicit ids so we can navigate in the same tap as selection (no stale state). */
  const navigateToValeterSelection = async (args: {
    serviceId: string;
    vehicleIds: string[];
    location: { latitude: number; longitude: number; address: string };
    washType: string;
  }) => {
    const primaryVehicleId = args.vehicleIds[0];
    if (!primaryVehicleId) return;
    const nextOption = currentServiceOptions.find((s) => s.id === args.serviceId);
    const washKeyForAddOns: '' | 'exterior' | 'interior' | 'both' =
      args.serviceId !== 'bronze-wash'
        ? ''
        : args.washType === 'exterior' || args.washType === 'interior' || args.washType === 'both'
          ? args.washType
          : '';
    const allowed = getAvailableAddOnIdsForService(
      args.serviceId,
      washKeyForAddOns,
      serviceMode === 'detailing' || serviceMode === 'repair'
    );
    const filteredAddOns = selectedAddOns.filter((id) => !nextOption?.includedAddOnIds?.includes(id));
    const effective = filteredAddOns.filter((id) => allowed.includes(id));
    const extrasTotal = effective.reduce((sum, id) => {
      const addOn = addOnOptions.find((a) => a.id === id);
      return sum + (addOn?.price ?? 0);
    }, 0);
    await hapticFeedback('medium');
    const discountAmount = 0;
    const vehicleInfo = formatBookingVehicleInfo(vehicles, args.vehicleIds);
    const computedServiceBase = sumServiceBaseForVehicles(
      args.serviceId,
      vehicles,
      args.vehicleIds,
      nextOption?.price ?? 25
    );
    const valeterParams: Record<string, string> = {
      serviceId: args.serviceId,
      vehicleId: primaryVehicleId,
      vehicleIds: args.vehicleIds.join(','),
      vehicleInfo,
      latitude: args.location.latitude.toString(),
      longitude: args.location.longitude.toString(),
      address: args.location.address,
      washType: args.washType,
      serviceMode: serviceMode,
      addOnIds: effective.length ? effective.join(',') : '',
      addOnsTotal: extrasTotal.toString(),
      customerOffersWater: 'false',
      customerOffersElectricity: 'false',
      discountAmount: discountAmount.toString(),
      serviceBasePriceGBP: computedServiceBase.toFixed(2),
    };
    if (params.preferredValeterId) valeterParams.preferredValeterId = params.preferredValeterId;
    if (frozenServiceMapView) {
      valeterParams.mapLat = frozenServiceMapView.region.latitude.toString();
      valeterParams.mapLng = frozenServiceMapView.region.longitude.toString();
      valeterParams.mapLatDelta = frozenServiceMapView.region.latitudeDelta.toString();
      valeterParams.mapLngDelta = frozenServiceMapView.region.longitudeDelta.toString();
    }
    if (params.preferredValeterId && user?.id) {
      try {
        const bookingId = await createMobileValeterBookingPendingPayment({
          userId: user.id,
          valeterId: params.preferredValeterId,
          vehicleId: primaryVehicleId,
          vehicleIds: args.vehicleIds,
          vehicleInfo,
          serviceId: args.serviceId,
          location: args.location,
          washType: args.washType,
          ...(effective.length ? { addOnIds: effective.join(',') } : {}),
          addOnsTotal: extrasTotal,
          discountAmount,
          serviceBasePriceGBP: computedServiceBase,
          customerOffersWater: false,
          customerOffersElectricity: false,
        });
        router.replace({
          pathname: '/owner/booking/payment',
          params: { bookingId },
        });
      } catch (error) {
        if (error instanceof ActiveBookingBlockedError) {
          Alert.alert(
            'One booking at a time',
            'You already have an active booking. Please complete or cancel it before starting a new one.',
            [
              { text: 'OK', style: 'cancel' },
              {
                text: 'View my booking',
                onPress: () =>
                  router.push({ pathname: '/owner/booking/tracking', params: { bookingId: error.activeBookingId } } as any),
              },
            ]
          );
          return;
        }
        Alert.alert('Error', error instanceof Error ? error.message : 'Failed to create booking');
      }
      return;
    }

    router.push({
      pathname: '/owner/booking/valeter-selection',
      params: valeterParams,
    });
  };

  const handleWashTypeSelect = async (type: 'exterior' | 'interior') => {
    await hapticFeedback('light');
    setWashType(type);
    setShowBronzeWashTypeOverlay(false);
    const bronze = serviceOptions.find((s) => s.id === 'bronze-wash');
    const allowed = getAvailableAddOnIdsForService('bronze-wash', type, false);
    const opts = addOnOptions.filter(
      (a) => allowed.includes(a.id) && !bronze?.includedAddOnIds?.includes(a.id)
    );
    if (opts.length > 0) {
      setShowAddOnsModal(true);
    }
  };

  const handleServiceContinue = async () => {
    if (!selectedService || selectedVehicleIds.length === 0 || !selectedLocation) return;
    if (serviceMode === 'wash' && selectedService === 'bronze-wash' && !washType) {
      return;
    }
    await navigateToValeterSelection({
      serviceId: selectedService,
      vehicleIds: selectedVehicleIds,
      location: selectedLocation,
      washType: washType || '',
    });
  };
  const selectedServiceData = currentServiceOptions.find(s => s.id === selectedService);

  const allowedAddOnIds = selectedService
    ? getAvailableAddOnIdsForService(selectedService, washType ?? '', isDetailingOrRepairPackage)
    : [];
  const availableAddOnOptions = addOnOptions.filter(
    (a) => allowedAddOnIds.includes(a.id) && !selectedServiceData?.includedAddOnIds?.includes(a.id)
  );

  const effectiveSelectedAddOns = selectedAddOns.filter((id) => allowedAddOnIds.includes(id));
  const addOnsTotal = effectiveSelectedAddOns.reduce((sum, id) => {
    const addOn = addOnOptions.find(a => a.id === id);
    return sum + (addOn?.price ?? 0);
  }, 0);

  const wishCarouselHeight = WISH_CAROUSEL_H;

  const serviceContinueReady =
    Boolean(selectedService && selectedVehicleIds.length > 0 && selectedLocation) &&
    !(serviceMode === 'wash' && selectedService === 'bronze-wash' && !washType);

  const serviceContinueAccent = selectedServiceData?.colors[0] ?? getServiceModeTabAccent(serviceMode);

  const serviceCtaSubtitle = (() => {
    if (!selectedServiceData) return 'Tap a card above to pick your package';
    if (serviceMode === 'wash' && selectedService === 'bronze-wash' && !washType) {
      return `${selectedServiceData.name} · choose exterior or interior`;
    }
    const addOnCount = effectiveSelectedAddOns.length;
    return addOnCount > 0
      ? `${selectedServiceData.name} · +${addOnCount} add-on${addOnCount === 1 ? '' : 's'}`
      : selectedServiceData.name;
  })();

  const infoServiceOption = infoService?.id
    ? currentServiceOptions.find((s) => s.id === infoService.id)
    : undefined;

  const infoSheetAccent = useMemo(() => {
    if (!infoService?.id) return getServiceModeTabAccent(serviceMode);
    if (serviceMode === 'repair') return REPAIR_TAB_ACCENT;
    if (serviceMode === 'detailing') return DETAILING_YELLOW;
    return currentServiceOptions.find((s) => s.id === infoService.id)?.colors[0] ?? SKY;
  }, [infoService?.id, serviceMode, currentServiceOptions]);

  const addOnsSheetAccent = useMemo(() => {
    if (serviceMode === 'repair') return REPAIR_TAB_ACCENT;
    if (serviceMode === 'detailing') return DETAILING_YELLOW;
    return selectedServiceData?.colors[0] ?? SKY;
  }, [serviceMode, selectedServiceData]);

  const bronzeWashSheetAccent = selectedServiceData?.colors[0] ?? '#92400E';

  const toggleAddOn = (id: string) => {
    hapticFeedback('light');
    setSelectedAddOns((prev) => {
      if (prev.includes(id)) return prev.filter((x) => x !== id);
      return [...prev, id];
    });
  };

  const headerConfig = getBookingHeaderConfig(currentStep);
  const headerTitle = headerConfig.title;
  const pickerRegion = region;
  /** Keeps the Apple logo and Legal link above the location sheet (and keyboard when typing a reg). */
  const pickerAttributionBottom =
    (locationPanelHeight > 0 ? locationPanelHeight : 148 + Math.max(insets.bottom, 14)) +
    locationKeyboardHeight +
    8;
  const headerSubtitle = headerConfig.subtitle;
  const headerOnBack = (() => {
    if (currentStep === 'location') return () => router.back();
    if (currentStep === 'service' && MOBILE_SERVICE_ONLY_LAUNCH && !skippedLocationStep) {
      return () => setCurrentStep('location');
    }
    return () => router.back();
  })();

  const handleLocationRecenter = async () => {
    hapticFeedback('light');
    await handleUseCurrentLocation();
  };

  const addOnsPopupScrollMaxHeight = Math.min(SCREEN_H * 0.38, 340);

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <AppHeader
        title={currentStep === 'location' ? "Where's the ride?" : headerTitle}
        subtitle={
          currentStep === 'location'
            ? 'Drag the map or the car to your spot'
            : selectedLocation?.address || headerSubtitle
        }
        titleIcon={currentStep === 'location' ? 'car-sport-outline' : 'sparkles'}
        showBack
        fullWidth
        floating
        onBack={headerOnBack}
        {...(currentStep === 'location'
          ? {
              centerContent: (
                <BookingMapChromePill style={styles.headerSearchPillTall} innerStyle={styles.headerSearchPillInner}>
                  <HubGlassIcon icon="search" accent={chrome.accent} size={34} iconSize={17} glow={false} />
                  <TextInput
                    style={styles.headerSearchInput}
                    placeholder="Search address or postcode"
                    placeholderTextColor="rgba(148,163,184,0.85)"
                    value={addressSearchInput}
                    onChangeText={(text) => {
                      setAddressSearchInput(text);
                      setShowInlineSuggestions(true);
                    }}
                    onFocus={() => {
                      headerSearchFocusedRef.current = true;
                      setLocationKeyboardHeight(0);
                      setShowInlineSuggestions(true);
                    }}
                    onBlur={() => {
                      headerSearchFocusedRef.current = false;
                    }}
                    onSubmitEditing={() => { void handleAddressSearch(); }}
                    returnKeyType="search"
                    autoCorrect={false}
                  />
                  {addressSearchInput.length > 0 ? (
                    <TouchableOpacity
                      onPress={() => {
                        setAddressSearchInput('');
                        setAddressSuggestions([]);
                        setShowInlineSuggestions(false);
                      }}
                      hitSlop={8}
                      accessibilityLabel="Clear search"
                    >
                      <Ionicons name="close-circle" size={17} color="rgba(148,163,184,0.9)" />
                    </TouchableOpacity>
                  ) : null}
                </BookingMapChromePill>
              ),
              rightAction: (
                <BookingHeaderMapControlButton
                  onPress={() => { void handleLocationRecenter(); }}
                  accentColor={SKY}
                  accessibilityLabel="Recenter map on your location"
                />
              ),
            }
          : {})}
      />
      {currentStep === 'location' ? (
        <>
          {showInlineSuggestions && addressSuggestions.length > 0 ? (
            <Reanimated.View
              entering={FadeInDown.duration(220)}
              style={[styles.headerSuggestionsWrap, { top: insets.top + FLOATING_HEADER_BODY_HEIGHT + 4 }]}
            >
              <GlassSurface style={styles.headerSuggestionsGlass}>
                <ScrollView
                  style={styles.headerSuggestionsList}
                  keyboardShouldPersistTaps="handled"
                  nestedScrollEnabled
                >
                  {addressSuggestions.map((s) => (
                    <TouchableOpacity
                      key={s.id}
                      style={styles.headerSuggestionItem}
                      onPress={() => {
                        void handleSelectSuggestion(s);
                        setShowInlineSuggestions(false);
                        Keyboard.dismiss();
                      }}
                      activeOpacity={0.7}
                    >
                      <View style={styles.headerSuggestionIcon}>
                        <Ionicons name="location" size={13} color={SKY} />
                      </View>
                      <Text style={styles.inlineSuggestionText} numberOfLines={1}>{s.description}</Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
              </GlassSurface>
            </Reanimated.View>
          ) : null}
        </>
      ) : null}

      {/* Location step: interactive picker. Service step: frozen tinted map from location step. */}
      <View
        style={styles.mapStageWrap}
        pointerEvents={currentStep === 'service' ? 'box-none' : 'auto'}
        onLayout={onMapStageLayout}
      >
        {currentStep === 'location' || selectedLocation ? (
          <SafeMapView
            ref={mapRef}
            style={StyleSheet.absoluteFill}
            pointerEvents={currentStep === 'location' ? 'auto' : 'none'}
            initialRegion={pickerRegion ?? DEFAULT_MAP_REGION}
            onPress={(e) => { void handleMapPress(e); }}
            onTouchStart={() => {
              userMovingPickerRef.current = true;
            }}
            onPanDrag={() => {
              userMovingPickerRef.current = true;
              setPinLifted(true);
            }}
            onRegionChangeComplete={(nextRegion) => {
              setPinLifted(false);
              if (currentStep !== 'location' || !pickerSeededRef.current) return;
              pickerDeltaRef.current = nextRegion.latitudeDelta;
              setRegion(nextRegion);
              const userMoved = userMovingPickerRef.current;
              userMovingPickerRef.current = false;
              if (userMoved) {
                // A real drag always wins: drop any pending programmatic skip and stop GPS bootstrap re-centring.
                suppressPickerGeocodeRef.current = false;
                hasInitializedPickerAtUserLocationRef.current = true;
                void hapticFeedback('light');
              } else {
                if (suppressPickerGeocodeRef.current) {
                  suppressPickerGeocodeRef.current = false;
                  return;
                }
                if (!pickerGpsReady) return;
              }
              const centre = { latitude: nextRegion.latitude, longitude: nextRegion.longitude };
              void coordinateUnderPin(centre).then(applyPickerCoords);
            }}
            scrollEnabled={currentStep === 'location'}
            zoomEnabled={currentStep === 'location'}
            rotateEnabled={false}
            pitchEnabled={false}
            showsUserLocation={currentStep === 'location'}
            showsMyLocationButton={false}
            toolbarEnabled={false}
            customMapStyle={LOCATION_PICKER_MAP_STYLE}
            userInterfaceStyle={MAP_LOCKED_DARK}
            legalLabelInsets={
              currentStep === 'location' || !frozenServiceMapView
                ? { top: 0, right: 10, bottom: pickerAttributionBottom, left: 10 }
                : frozenServiceMapView.legalLabelInsets
            }
            {...(Platform.OS === 'ios'
              ? { mapPadding: { top: 0, right: 0, bottom: pickerAttributionBottom, left: 0 } }
              : {})}
          />
        ) : null}
        {currentStep === 'service' && selectedLocation ? (
          <>
            <View pointerEvents="none" style={styles.serviceMapTint} />
            <LinearGradient
              pointerEvents="none"
              colors={['rgba(2,6,23,0.12)', 'rgba(2,6,23,0.42)', 'rgba(2,6,23,0.58)']}
              locations={[0, 0.55, 1]}
              style={StyleSheet.absoluteFill}
            />
            <View pointerEvents="none" style={styles.centerPickerWrap}>
              <Animated.View style={[styles.centerPickerPin, { transform: [{ scale: markerPulse }] }]}>
                <MapMarkerCustomerVehicle size={44} variant="car" />
              </Animated.View>
            </View>
          </>
        ) : null}
        {currentStep === 'location' && !pickerRegion ? (
          <View style={styles.pickerLocating}>
            <ActivityIndicator color="#7DD3FC" />
            <Text style={styles.pickerLocatingText}>Finding your location…</Text>
          </View>
        ) : null}
        {currentStep === 'location' && pickerRegion && (
          <View pointerEvents="box-none" style={styles.centerPickerWrap}>
            <Animated.View
              {...pinPanResponder.panHandlers}
              hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
              accessibilityLabel="Drag the car to your vehicle's exact spot"
              style={[styles.centerPickerTouch, { transform: pinDrag.getTranslateTransform() }]}
            >
              <Animated.View
                pointerEvents="none"
                style={[
                  styles.centerPickerShadow,
                  {
                    opacity: pinLift.interpolate({ inputRange: [0, 1], outputRange: [0, 0.55] }),
                    transform: [{ scale: pinLift.interpolate({ inputRange: [0, 1], outputRange: [0.4, 1] }) }],
                  },
                ]}
              />
              <Animated.View
                pointerEvents="none"
                style={{
                  transform: [{ translateY: pinLift.interpolate({ inputRange: [0, 1], outputRange: [0, -16] }) }],
                }}
              >
                <Animated.View style={[styles.centerPickerPin, { transform: [{ scale: markerPulse }] }]}>
                  <MapMarkerCustomerVehicle size={44} variant="car" />
                </Animated.View>
              </Animated.View>
            </Animated.View>
          </View>
        )}

        {currentStep === 'service' && serviceMode === 'detailing' && conditionBannerMounted ? (
          <Animated.View
            pointerEvents="none"
            style={[
              styles.conditionMapBannerWrap,
              {
                top: insets.top + FLOATING_HEADER_BODY_HEIGHT + 8,
                opacity: conditionBannerOpacity,
                transform: [
                  { translateY: conditionBannerSlide },
                  { scale: conditionBannerScale },
                ],
              },
            ]}
          >
            <BlurView intensity={24} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
            <LinearGradient
              colors={[`${DETAILING_YELLOW}24`, 'rgba(15,23,42,0.78)']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={StyleSheet.absoluteFill}
              pointerEvents="none"
            />
            <LinearGradient
              colors={['rgba(255,255,255,0.14)', 'transparent']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0.6 }}
              style={StyleSheet.absoluteFill}
              pointerEvents="none"
            />
            <View style={styles.conditionMapBannerInner}>
              <HubGlassIcon icon="information-circle-outline" accent={DETAILING_YELLOW} size={34} iconSize={18} />
              <Text style={styles.conditionMapBannerText}>
                Detailing is condition-based. Results vary by vehicle condition.
              </Text>
            </View>
          </Animated.View>
        ) : null}

        {currentStep === 'service' && selectedLocation ? (
        <Animated.View style={{ transform: [{ translateY: addressPillShift }] }}>
          {selectedService === 'bronze-wash' && washType ? (
            <BookingWashTypeMapPill
              washType={washType}
              accentColor={bronzeWashSheetAccent}
              onPress={() => {
                hapticFeedback('light');
                setShowBronzeWashTypeOverlay(true);
              }}
              style={[styles.washTypeMapPillWrap, { top: insets.top + FLOATING_HEADER_BODY_HEIGHT + 8 }]}
            />
          ) : null}
        </Animated.View>
        ) : null}
      </View>

      {/* Floating cards container - matches Book Your Wash */}
      <Animated.View
        style={[
          styles.cardsContainer,
          {
            opacity: fadeAnim,
            transform: [{ translateY: Animated.add(slideAnim, sheetDragY) }],
            paddingBottom:
              currentStep === 'service'
                ? 0
                : Math.max(insets.bottom, 4) + 22,
            paddingHorizontal: currentStep === 'service' ? 0 : adaptive.horizontalPadding,
          },
        ]}
        pointerEvents={currentStep === 'location' ? 'none' : 'auto'}
        {...(currentStep === 'service' && !showAddOnsModal && !showBronzeWashTypeOverlay ? sheetPanResponder.panHandlers : {})}
      >
        <Animated.View style={{ width: '100%', flex: 1, transform: [{ translateX: stepSlideAnim }] }}>
        {/* Step 1: Location only */}
        {/* Step 3: Service Selection */}
        {currentStep === 'service' && (
          <View style={styles.vehicleSheetScreen}>
            <View
              style={[
                styles.vehicleBottomSheet,
                { paddingBottom: Math.max(insets.bottom, 6) },
                sheetRimColor ? { borderColor: sheetRimColor } : null,
              ]}
            >
              <BusinessSheetBackground />
              <View style={styles.vehicleSheetHandle} />
              <ServiceModeSegmented tabs={serviceModeTabs} value={serviceMode} onChange={setServiceMode} />

              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                style={[styles.vehicleSheetScrollH, { height: wishCarouselHeight }]}
                contentContainerStyle={styles.serviceCardsRow}
                snapToInterval={WISH_CARD_STEP}
                decelerationRate="fast"
                snapToAlignment="start"
                keyboardShouldPersistTaps="handled"
              >
                {currentServiceOptions.map((service, index) => {
                  const isSelected = selectedService === service.id;
                  const packageTagline =
                    getWashPackageTagline(service.id) ?? service.descriptionTitle ?? '';
                  return (
                    <View key={`${serviceMode}-${service.id}`} style={styles.wishOptionCardOuter}>
                      <ServiceOptionCard
                        service={service}
                        index={index}
                        width={WISH_CARD_W}
                        height={SERVICE_CARD_H}
                        subtitle={packageTagline || service.desc || ''}
                        icon={getServiceTierLeadIconName(service.id)}
                        image={getServiceTierLeadImage(service.id) ?? getServiceTierLeadImage(service.name)}
                        selected={isSelected}
                        addOnsCount={isSelected ? effectiveSelectedAddOns.length : 0}
                        onPress={() => {
                          void handleServiceSelect(service.id);
                        }}
                        onInfo={() => {
                          hapticFeedback('light');
                          setInfoService(service);
                        }}
                        onAddOns={() => {
                          hapticFeedback('light');
                          setShowAddOnsModal(true);
                        }}
                      />
                    </View>
                  );
                })}
              </ScrollView>
              <ServicePagerDots
                count={currentServiceOptions.length}
                activeIndex={Math.max(0, currentServiceOptions.findIndex((s) => s.id === selectedService))}
                accent={serviceContinueAccent}
              />
              <ServiceSheetCta
                accent={serviceContinueAccent}
                ready={serviceContinueReady}
                title={serviceContinueReady ? `Continue to ${CCP.singularShort}` : 'Choose a package'}
                subtitle={serviceCtaSubtitle}
                vehicleCount={selectedVehicleIds.length}
                onPress={() => void handleServiceContinue()}
                onVehiclesPress={() => setCurrentStep('location')}
              />
            </View>
          </View>
        )}
        </Animated.View>

        <BookingBottomSheetOverlay visible={!!infoService} onClose={() => setInfoService(null)} maxHeightRatio={0.9}>
          {infoService ? (
            <>
              <ScrollView
                style={styles.serviceInfoScroll}
                contentContainerStyle={styles.infoModalScrollContent}
                showsVerticalScrollIndicator={false}
              >
                <InfoSheetHero
                  accent={infoSheetAccent}
                  icon={getServiceTierLeadIconName(infoService.id ?? '')}
                  image={getServiceTierLeadImage(infoService.id ?? '') ?? getServiceTierLeadImage(infoService.name ?? '')}
                  eyebrow={serviceModeTabs.find((t) => t.id === serviceMode)?.label ?? 'Package'}
                  title={`${infoService.name ?? ''}${
                    infoService.id === 'bronze-wash' && washType
                      ? ` · ${washType === 'exterior' ? 'Exterior' : 'Interior'}`
                      : ''
                  }`}
                  {...(infoService.descriptionTitle ? { subtitle: infoService.descriptionTitle } : {})}
                  chips={[
                    ...(infoServiceOption?.dur ? [{ icon: 'time' as const, label: infoServiceOption.dur }] : []),
                    { icon: 'pricetag', label: 'Prices vary', accent: '#CBD5E1' },
                    ...(infoServiceOption?.badge ? [{ icon: 'sparkles' as const, label: infoServiceOption.badge }] : []),
                  ]}
                />
                <Text style={styles.infoModalDesc}>
                  {(() => {
                    if (infoService.id === 'bronze-wash' && washType === 'exterior') {
                      return 'A quick exterior refresh to keep your vehicle looking clean and presentable.';
                    }
                    if (infoService.id === 'bronze-wash' && washType === 'interior') {
                      return "A light interior refresh designed to tidy and freshen your vehicle's cabin.";
                    }
                    return infoService.desc ?? '';
                  })()}
                </Text>
                {(() => {
                  let bulletPoints: string[];
                  if (infoService.id === 'bronze-wash' && washType === 'exterior') {
                    bulletPoints = [
                      'Wheels and wheel arches cleaned',
                      'Snow foam pre-wash applied',
                      'Safe exterior hand wash',
                      'Vehicle fully rinsed',
                      'Exterior hand dried',
                      'Windows and mirrors cleaned',
                      'Ideal for regular maintenance washes and light dirt removal',
                    ];
                  } else if (infoService.id === 'bronze-wash' && washType === 'interior') {
                    bulletPoints = [
                      'Rubbish removed',
                      'Interior vacuum (seats, carpets, and mats)',
                      'Dashboard and main surfaces wiped down',
                      'Steering wheel cleaned',
                      'Interior glass cleaned',
                      'Air freshener applied',
                      'Perfect for maintaining a clean and comfortable interior between deeper cleans',
                    ];
                  } else {
                    bulletPoints = infoService.bulletPoints ?? [];
                  }
                  return bulletPoints.length > 0 ? (
                    <InfoSheetSection title="What's included" icon="sparkles" accent={infoSheetAccent} index={0}>
                      <InfoSheetChecklist items={bulletPoints} accent={infoSheetAccent} />
                    </InfoSheetSection>
                  ) : null;
                })()}
                {effectiveSelectedAddOns.length > 0 ? (
                  <InfoSheetSection title="Your add-ons" icon="add-circle" accent={infoSheetAccent} index={1}>
                    {effectiveSelectedAddOns.map((id) => {
                      const addOn = addOnOptions.find((a) => a.id === id);
                      if (!addOn) return null;
                      return (
                        <InfoSheetRow
                          key={addOn.id}
                          icon={getAddOnIconName(addOn)}
                          accent={infoSheetAccent}
                          label={addOn.name}
                          value={`+£${addOn.price}`}
                        />
                      );
                    })}
                    <InfoSheetRow
                      icon="wallet"
                      accent={infoSheetAccent}
                      label="Add-ons total"
                      value={`+£${addOnsTotal}`}
                      valueColor={infoSheetAccent}
                      last
                    />
                  </InfoSheetSection>
                ) : null}
              </ScrollView>
              <InfoSheetButton accent={infoSheetAccent} label="Got it" onPress={() => setInfoService(null)} />
            </>
          ) : null}
        </BookingBottomSheetOverlay>

        <VehicleInfoOverlay
          visible={!!infoVehicle}
          vehicle={infoVehicle ? { ...infoVehicle, mot_expiry: (infoVehicle as any).mot_expiry ?? null, mot_expiry_date: (infoVehicle as any).mot_expiry_date ?? null, mileage: (infoVehicle as any).mileage ?? null, tax_status: (infoVehicle as any).tax_status ?? null, tax_due_date: (infoVehicle as any).tax_due_date ?? null, tax_expiry: (infoVehicle as any).tax_expiry ?? null } : null}
          stats={vehicleStats}
          accentColor={SKY}
          onClose={() => setInfoVehicle(null)}
        />

        {/* Address search bottom sheet */}
        <BookingBottomSheetOverlay visible={showAddressOverlay} onClose={closeAddressOverlayWithoutSaving} maxHeightRatio={0.92}>
          <KeyboardAvoidingView
            style={styles.addressOverlayKeyboardWrap}
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          >
            <View style={styles.addressOverlayContent}>
              <View style={styles.addressOverlayContentInner}>
                <Text style={styles.addressOverlayTitle}>Change location</Text>
                <Text style={styles.addressOverlaySubtitle}>Current location is default. Pick a saved place or search.</Text>
                <TouchableOpacity
                  style={styles.addressOverlayUseCurrent}
                  onPress={async () => {
                    await handleUseCurrentLocation();
                    closeAddressOverlayWithoutSaving();
                  }}
                  activeOpacity={0.8}
                >
                  <Ionicons name="locate" size={18} color={SKY} />
                  <Text style={styles.addressOverlayUseCurrentText}>Use current location</Text>
                </TouchableOpacity>
                {savedLocations.length > 0 && (
                  <>
                    <Text style={styles.addressOverlaySavedLabel}>Saved locations</Text>
                    <ScrollView style={styles.addressOverlaySavedList} keyboardShouldPersistTaps="handled" nestedScrollEnabled>
                      {savedLocations.map((item) => (
                        <TouchableOpacity
                          key={item.id}
                          style={styles.addressOverlaySavedItem}
                          onPress={() => handlePickSavedLocation(item)}
                          activeOpacity={0.8}
                        >
                          <Ionicons name={item.icon} size={18} color={SKY} />
                          <View style={styles.addressOverlaySavedItemText}>
                            <Text style={styles.addressOverlaySavedItemLabel}>{item.label}</Text>
                            <Text style={styles.addressOverlaySavedItemAddress} numberOfLines={1}>{item.address}</Text>
                          </View>
                          <Ionicons name="chevron-forward" size={18} color="#64748B" />
                        </TouchableOpacity>
                      ))}
                    </ScrollView>
                  </>
                )}
                <Text style={styles.addressOverlaySearchLabel}>Or search for an address</Text>
                <TextInput
                  style={styles.addressOverlayInput}
                  placeholder="Find your postcode..."
                  placeholderTextColor="#64748B"
                  value={addressSearchInput}
                  onChangeText={setAddressSearchInput}
                  onFocus={() => {
                    setAddressSearchInput('');
                    setAddressSuggestions([]);
                    setLoadingSuggestions(false);
                  }}
                  onSubmitEditing={handleAddressSearch}
                  returnKeyType="search"
                  autoCapitalize="none"
                />
                {loadingSuggestions && (
                  <View style={styles.addressSuggestionsLoading}>
                    <ActivityIndicator size="small" color={SKY} />
                  </View>
                )}
                {!loadingSuggestions && addressSuggestions.length > 0 && (
                  <ScrollView
                    style={styles.addressSuggestionsList}
                    keyboardShouldPersistTaps="handled"
                    nestedScrollEnabled
                  >
                    {addressSuggestions.map((s) => (
                      <TouchableOpacity
                        key={s.id}
                        style={styles.addressSuggestionItem}
                        onPress={() => handleSelectSuggestion(s)}
                        activeOpacity={0.7}
                      >
                        <Ionicons name="location-outline" size={18} color={SKY} />
                        <Text style={styles.addressSuggestionText} numberOfLines={2}>{s.description}</Text>
                      </TouchableOpacity>
                    ))}
                  </ScrollView>
                )}
                <View style={styles.addressOverlayButtons}>
                  <TouchableOpacity style={styles.addressOverlayCancel} onPress={closeAddressOverlayWithoutSaving} activeOpacity={0.8}>
                    <BlurView intensity={30} tint="dark" style={StyleSheet.absoluteFill} />
                    <View style={[StyleSheet.absoluteFill, styles.glassFillSecondary]} />
                    <LinearGradient
                      colors={['rgba(255,255,255,0.14)', 'rgba(255,255,255,0)']}
                      style={styles.glassSheen}
                      pointerEvents="none"
                    />
                    <Text style={styles.addressOverlayCancelText}>Cancel</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[styles.addressOverlaySearch, addressSearching && { opacity: 0.7 }]}
                    onPress={handleAddressSearch}
                    disabled={addressSearching}
                    activeOpacity={0.8}
                  >
                    <BlurView intensity={30} tint="dark" style={StyleSheet.absoluteFill} />
                    <View style={[StyleSheet.absoluteFill, styles.glassFillPrimary]} />
                    <LinearGradient
                      colors={['rgba(255,255,255,0.14)', 'rgba(255,255,255,0)']}
                      style={styles.glassSheen}
                      pointerEvents="none"
                    />
                    {addressSearching ? (
                      <ActivityIndicator size="small" color="#fff" />
                    ) : (
                      <>
                        <Ionicons name="search" size={18} color="#fff" />
                        <Text style={styles.addressOverlaySearchText}>Search</Text>
                      </>
                    )}
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </KeyboardAvoidingView>
        </BookingBottomSheetOverlay>
      </Animated.View>

      {currentStep === 'location' ? (
        <View
          onLayout={(e) => {
            const h = Math.round(e.nativeEvent.layout.height);
            setLocationPanelHeight((prev) => (Math.abs(prev - h) < 2 ? prev : h));
          }}
          style={[
            styles.locationBottomPanel,
            {
              bottom: locationKeyboardHeight,
              paddingBottom: locationKeyboardHeight > 0 ? 12 : Math.max(insets.bottom, 14) + 10,
            },
          ]}
        >
          <BusinessSheetBackground />
          <View style={styles.locationSheetHandle} />
          {showVehicleRegInput ? (
          <View style={styles.locationSheetSearchWrap}>
              <View style={styles.inlineSearchRow}>
                <TouchableOpacity
                  onPress={closeVehicleRegInput}
                  style={styles.inlineRegBackBtn}
                  activeOpacity={0.8}
                  accessibilityLabel="Back to address search"
                >
                  <Ionicons name="chevron-back" size={18} color={SKY} />
                </TouchableOpacity>
                <Ionicons name="car-sport-outline" size={18} color={SKY} />
                <TextInput
                  style={styles.inlineSearchInput}
                  placeholder="Enter registration (e.g. AB12 CDE)"
                  placeholderTextColor="#94A3B8"
                  value={vehicleRegInput}
                  onChangeText={(text) => setVehicleRegInput(text.toUpperCase())}
                  onSubmitEditing={() => { void handleVehicleRegSubmit(); }}
                  returnKeyType="done"
                  autoCapitalize="characters"
                  autoCorrect={false}
                  editable={!vehicleRegSaving}
                />
                <TouchableOpacity
                  onPress={() => { void handleVehicleRegSubmit(); }}
                  style={[styles.inlineSearchGo, vehicleRegSaving && { opacity: 0.6 }]}
                  activeOpacity={0.8}
                  disabled={vehicleRegSaving}
                >
                  {vehicleRegSaving ? (
                    <ActivityIndicator size="small" color="#FFFFFF" />
                  ) : (
                    <Ionicons name="add" size={18} color="#FFFFFF" />
                  )}
                </TouchableOpacity>
              </View>
          </View>
          ) : null}
          <View style={styles.locationBottomCard}>
            <View style={styles.locationAddressRow}>
              <HubGlassIcon icon="location" accent={SKY} size={40} iconSize={18} glow={false} />
              <View style={styles.locationAddressCol}>
                <Text style={styles.locationLocationLabel}>Wash location</Text>
                {pickerResolving ? (
                  <View style={styles.locationResolvingRow}>
                    <ActivityIndicator size="small" color="rgba(148,163,184,0.9)" />
                    <Text style={[styles.locationAddressText, styles.locationAddressResolving]}>Finding address…</Text>
                  </View>
                ) : (
                  <Reanimated.Text
                    key={selectedLocation?.address ?? 'empty'}
                    entering={FadeIn.duration(220)}
                    style={[styles.locationAddressText, !selectedLocation?.address && styles.locationAddressResolving]}
                    numberOfLines={2}
                  >
                    {selectedLocation?.address || 'Drag the map or the car to your spot'}
                  </Reanimated.Text>
                )}
              </View>
            </View>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              keyboardShouldPersistTaps="handled"
              style={styles.quickLocationScroll}
              contentContainerStyle={styles.quickLocationRow}
            >
              <TouchableOpacity
                style={[styles.quickLocationChip, activeQuickLocationId === CURRENT_LOCATION_ID && styles.quickLocationChipActive]}
                onPress={() => { void handleUseCurrentLocation(); }}
                activeOpacity={0.8}
                accessibilityLabel="Use current location"
              >
                <Ionicons name="navigate" size={14} color={activeQuickLocationId === CURRENT_LOCATION_ID ? '#38BDF8' : SKY} />
                <Text style={[styles.quickLocationChipText, activeQuickLocationId === CURRENT_LOCATION_ID && styles.quickLocationChipTextActive]}>
                  Current
                </Text>
              </TouchableOpacity>
              {savedLocations.map((item) => {
                const active = activeQuickLocationId === item.id;
                return (
                  <TouchableOpacity
                    key={item.id}
                    style={[styles.quickLocationChip, active && styles.quickLocationChipActive]}
                    onPress={() => handlePickSavedLocation(item)}
                    activeOpacity={0.8}
                    accessibilityLabel={`Wash at ${item.label}`}
                  >
                    <Ionicons name={item.icon} size={14} color={active ? '#38BDF8' : SKY} />
                    <Text style={[styles.quickLocationChipText, active && styles.quickLocationChipTextActive]} numberOfLines={1}>
                      {item.label}
                    </Text>
                  </TouchableOpacity>
                );
              })}
              {savedLocations.length === 0 ? (
                <TouchableOpacity
                  style={[styles.quickLocationChip, styles.quickLocationChipGhost]}
                  onPress={() => {
                    hapticFeedback('light');
                    router.push('/owner/settings/saved-locations' as any);
                  }}
                  activeOpacity={0.8}
                  accessibilityLabel="Save home address"
                >
                  <Ionicons name="home-outline" size={14} color={SKY} />
                  <Text style={styles.quickLocationChipText}>Save Home</Text>
                </TouchableOpacity>
              ) : null}
            </ScrollView>
            <VehiclePickerInline
              vehicles={vehicles}
              selectedIds={selectedVehicleIds}
              onToggle={toggleSelectedVehicle}
              loading={loading}
              compact
              onAddVehicle={openVehicleRegInput}
            />
            <WWPrimaryButton
              title="Continue"
              onPress={() => { void handleLocationAndVehicleContinue(); }}
              disabled={!selectedLocation || pickerResolving || selectedVehicleIds.length === 0}
              leftIconName="arrow-forward"
              leftIconSize={18}
              style={{ width: '100%' }}
            />
          </View>
        </View>
      ) : null}

      {/* Add-ons bottom sheet — root level so layout is not clipped by the animated service sheet */}
      <BookingBottomSheetOverlay
        visible={showAddOnsModal}
        onClose={() => setShowAddOnsModal(false)}
        maxHeightRatio={0.68}
        compact
        sheetStyle={styles.uberPopupSheet}
      >
        <View style={styles.uberPopupWrap}>
          <ChoiceSheetHeader
            accent={addOnsSheetAccent}
            icon="sparkles"
            {...(selectedServiceData?.name ? { eyebrow: selectedServiceData.name } : {})}
            title={ADD_ON_SECTION_TITLE}
            subtitle="Tap to add extra treatments to your booking"
          />

          {availableAddOnOptions.length > 0 ? (
            <ScrollView
              style={[styles.uberPopupScroll, { maxHeight: addOnsPopupScrollMaxHeight }]}
              contentContainerStyle={styles.uberPopupScrollContent}
              showsVerticalScrollIndicator={false}
              keyboardShouldPersistTaps="handled"
              nestedScrollEnabled
            >
              {availableAddOnOptions.map((addOn, index) => (
                <AddOnToggleRow
                  key={addOn.id}
                  accent={addOnsSheetAccent}
                  icon={getAddOnIconName(addOn)}
                  title={addOn.name}
                  {...(addOn.desc ? { desc: addOn.desc } : {})}
                  price={`£${addOn.price}`}
                  selected={selectedAddOns.includes(addOn.id)}
                  index={index}
                  onPress={() => toggleAddOn(addOn.id)}
                />
              ))}
            </ScrollView>
          ) : (
            <View style={styles.uberPopupEmpty}>
              <Text style={styles.uberPopupEmptyText}>No add-ons available for this service.</Text>
            </View>
          )}

          <AddOnsSummaryBar
            accent={addOnsSheetAccent}
            count={effectiveSelectedAddOns.length}
            total={`£${addOnsTotal.toFixed(2)}`}
            onDone={() => setShowAddOnsModal(false)}
          />
        </View>
      </BookingBottomSheetOverlay>

      {/* Bronze wash: exterior / interior bottom sheet */}
      <BookingBottomSheetOverlay
        visible={showBronzeWashTypeOverlay}
        onClose={() => setShowBronzeWashTypeOverlay(false)}
        maxHeightRatio={0.6}
        compact
        sheetStyle={styles.uberPopupSheet}
      >
        <View style={styles.uberPopupWrap}>
          <ChoiceSheetHeader
            accent={bronzeWashSheetAccent}
            icon="water"
            eyebrow={selectedServiceData?.name ?? 'Bronze wash'}
            title="Inside or outside?"
            subtitle="Pick the area you want cleaned"
          />
          <WashTypeChoiceCards
            accent={bronzeWashSheetAccent}
            value={washType || null}
            onSelect={(id) => {
              void handleWashTypeSelect(id);
            }}
            options={BRONZE_WASH_TYPE_OPTIONS}
          />
        </View>
      </BookingBottomSheetOverlay>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  centerPickerWrap: {
    ...StyleSheet.absoluteFill,
    alignItems: 'center',
    justifyContent: 'center',
  },
  centerPickerTouch: {
    width: 64,
    height: 64,
    alignItems: 'center',
    justifyContent: 'center',
  },
  centerPickerShadow: {
    position: 'absolute',
    width: 26,
    height: 8,
    borderRadius: 13,
    backgroundColor: '#000',
    marginTop: 46,
  },
  centerPickerPin: {
    width: 54,
    height: 54,
    borderRadius: 27,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(135,206,235,0.22)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.45)',
  },
  cardsContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingTop: 10,
  },
  locationSheetHandle: {
    width: 36,
    height: 4,
    borderRadius: 2,
    alignSelf: 'center',
    marginTop: 8,
    marginBottom: 12,
    backgroundColor: 'rgba(255,255,255,0.28)',
  },
  mapStageWrap: {
    flex: 1,
    overflow: 'hidden',
  },
  pickerLocating: {
    ...StyleSheet.absoluteFill,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    backgroundColor: '#0A1929',
  },
  pickerLocatingText: { color: 'rgba(186,230,253,0.85)', fontSize: 14, fontWeight: '600' },
  serviceMapTint: {
    ...StyleSheet.absoluteFill,
    backgroundColor: 'rgba(15,23,42,0.28)',
  },
  locationSheetSearchWrap: {
    marginBottom: 10,
  },
  locationBottomPanel: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 18,
    paddingTop: 0,
    zIndex: 7,
    overflow: 'hidden',
    ...PREMIUM_BOOKING_MAP_SHEET_GLASS,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    borderTopWidth: 0,
    borderLeftWidth: 0,
    borderRightWidth: 0,
  },
  locationBottomCard: {
    gap: 14,
    backgroundColor: 'transparent',
  },
  locationAddressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  locationAddressCol: {
    flex: 1,
    minWidth: 0,
    gap: 2,
  },
  locationResolvingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  locationLocationLabel: {
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 1,
    textTransform: 'uppercase',
    color: 'rgba(148,163,184,0.85)',
  },
  locationAddressText: {
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '700',
    lineHeight: 20,
    letterSpacing: -0.1,
  },
  locationAddressResolving: {
    color: 'rgba(148,163,184,0.9)',
    fontWeight: '600',
  },
  quickLocationScroll: {
    flexGrow: 0,
    marginHorizontal: -18,
  },
  quickLocationRow: {
    gap: 8,
    paddingHorizontal: 18,
  },
  quickLocationChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    height: 34,
    paddingHorizontal: 14,
    borderRadius: 17,
    backgroundColor: 'rgba(255,255,255,0.06)',
    maxWidth: 170,
  },
  quickLocationChipActive: {
    backgroundColor: 'rgba(56,189,248,0.18)',
  },
  quickLocationChipGhost: {
    backgroundColor: 'rgba(255,255,255,0.03)',
  },
  quickLocationChipText: {
    color: 'rgba(226,232,240,0.9)',
    fontSize: 13,
    fontWeight: '600',
  },
  quickLocationChipTextActive: {
    color: '#F8FAFC',
    fontWeight: '700',
  },
  conditionMapBannerWrap: {
    position: 'absolute',
    top: 10,
    left: 16,
    right: 16,
    zIndex: 130,
    borderRadius: 18,
    overflow: 'hidden',
    backgroundColor: 'rgba(2,6,23,0.72)',
    shadowColor: DETAILING_YELLOW,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.22,
    shadowRadius: 16,
    elevation: 10,
  },
  conditionMapBannerInner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 11,
    paddingHorizontal: 12,
    zIndex: 1,
  },
  conditionMapBannerText: {
    flex: 1,
    color: 'rgba(248,250,252,0.92)',
    fontSize: 12,
    lineHeight: 17,
    fontWeight: '600',
    letterSpacing: 0.1,
  },
  vehicleSheetScreen: {
    flex: 1,
    width: '100%',
    justifyContent: 'flex-end',
  },
  vehicleBottomSheet: {
    width: '100%',
    paddingTop: 0,
    ...PREMIUM_BOOKING_MAP_SHEET_GLASS,
  },
  vehicleSheetHandle: {
    width: 42,
    height: 4,
    borderRadius: 2,
    alignSelf: 'center',
    marginTop: 10,
    marginBottom: 6,
    backgroundColor: 'rgba(255,255,255,0.55)',
  },
  vehicleSheetScrollH: {
    flexGrow: 0,
    width: '100%',
  },
  serviceCardsRow: {
    paddingLeft: 14,
    paddingRight: 20,
    paddingTop: 8,
    paddingBottom: 10,
    alignItems: 'flex-start',
  },
  wishOptionCardOuter: {
    marginRight: BOOKING_H_CARD_GAP,
    alignSelf: 'flex-start',
  },
  /** Compact Uber-style sheets for add-ons + bronze wash. */
  uberPopupSheet: {
    alignSelf: 'stretch',
  },
  uberPopupWrap: {
    width: '100%',
    paddingBottom: 2,
  },
  uberPopupScroll: {
    width: '100%',
  },
  uberPopupScrollContent: {
    gap: 6,
    paddingBottom: 4,
  },
  uberPopupEmpty: {
    minHeight: 72,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  uberPopupEmptyText: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '600',
    textAlign: 'center',
  },
  washTypeMapPillWrap: {
    left: 16,
  },
  inlineSearchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    borderRadius: 16,
    backgroundColor: 'rgba(148,163,184,0.12)',
    paddingHorizontal: 12,
    paddingVertical: 10,
  },
  inlineSearchInput: {
    flex: 1,
    color: '#F8FAFC',
    fontSize: 14,
    fontWeight: '600',
    paddingVertical: 0,
  },
  inlineRegBackBtn: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  inlineSearchGo: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerSearchPillTall: {
    height: 50,
    borderRadius: 25,
  },
  headerSearchPillInner: {
    paddingLeft: 6,
    gap: 10,
  },
  headerSuggestionsGlass: {
    borderRadius: 20,
  },
  headerSuggestionsList: {
    maxHeight: 240,
    paddingVertical: 6,
  },
  headerSuggestionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
  },
  headerSuggestionIcon: {
    width: 26,
    height: 26,
    borderRadius: 13,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(56,189,248,0.14)',
  },
  headerSearchInput: {
    flex: 1,
    color: '#F8FAFC',
    fontSize: 14,
    fontWeight: '600',
    paddingVertical: 0,
  },
  headerSuggestionsWrap: {
    position: 'absolute',
    left: 12,
    right: 12,
    zIndex: 950,
  },
  inlineSuggestionText: {
    flex: 1,
    color: '#E2E8F0',
    fontSize: 13,
    fontWeight: '600',
  },
  infoModalScrollContent: {
    paddingTop: 4,
    paddingBottom: 24,
  },
  serviceInfoScroll: {
    maxHeight: 520,
  },
  infoModalDesc: {
    color: 'rgba(203,213,225,0.9)',
    fontSize: 14,
    lineHeight: 21,
    marginBottom: 16,
    paddingHorizontal: 2,
  },
  addressOverlayKeyboardWrap: {
    flex: 1,
  },
  addressOverlayContent: {
    width: '100%',
    borderRadius: 26,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.35,
    shadowRadius: 24,
    elevation: 24,
    overflow: 'hidden',
  },
  addressOverlayContentInner: {
    padding: 24,
  },
  addressOverlayTitle: {
    color: '#F8FAFC',
    fontSize: 22,
    fontWeight: '800',
    marginBottom: 4,
    letterSpacing: -0.4,
  },
  addressOverlaySubtitle: {
    color: 'rgba(226,232,240,0.7)',
    fontSize: 14,
    fontWeight: '500',
    marginBottom: 12,
    lineHeight: 20,
  },
  addressOverlayUseCurrent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 12,
    marginBottom: 16,
    borderRadius: 999,
    backgroundColor: 'rgba(56,189,248,0.16)',
  },
  addressOverlayUseCurrentText: {
    color: SKY,
    fontSize: 15,
    fontWeight: '700',
  },
  addressOverlaySavedLabel: {
    color: 'rgba(186,230,253,0.92)',
    fontSize: 10.5,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  addressOverlaySavedList: {
    maxHeight: 160,
    marginBottom: 16,
  },
  addressOverlaySavedItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 12,
    marginBottom: 4,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(255,255,255,0.06)',
    gap: 10,
  },
  addressOverlaySavedItemText: {
    flex: 1,
  },
  addressOverlaySavedItemLabel: {
    color: '#F1F5F9',
    fontSize: 15,
    fontWeight: '700',
  },
  addressOverlaySavedItemAddress: {
    color: '#94A3B8',
    fontSize: 13,
    marginTop: 2,
  },
  addressOverlaySearchLabel: {
    color: 'rgba(186,230,253,0.92)',
    fontSize: 10.5,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  addressOverlayInput: {
    backgroundColor: 'rgba(148,163,184,0.12)',
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    paddingHorizontal: 18,
    paddingVertical: 16,
    color: '#F9FAFB',
    fontSize: 16,
  },
  addressSuggestionsLoading: { paddingVertical: 12, alignItems: 'center' },
  addressSuggestionsList: { maxHeight: 200, marginTop: 8 },
  addressSuggestionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 12,
    paddingHorizontal: 14,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 12,
    marginBottom: 6,
  },
  addressSuggestionText: { color: '#F1F5F9', fontSize: 14, flex: 1 },
  addressOverlayButtons: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 24,
  },
  addressOverlayCancel: {
    flex: 1,
    height: 52,
    borderRadius: 26,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
  },
  addressOverlayCancelText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
  glassFillPrimary: { backgroundColor: 'rgba(56,189,248,0.45)' },
  glassFillSecondary: { backgroundColor: 'rgba(255,255,255,0.1)' },
  glassSheen: { position: 'absolute', left: 0, right: 0, top: 0, height: 26 },
  addressOverlaySearch: {
    flex: 1,
    height: 52,
    borderRadius: 26,
    overflow: 'hidden',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingHorizontal: 20,
  },
  addressOverlaySearchText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
});
