import { useCallback, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  StatusBar,
  useWindowDimensions,
  type NativeScrollEvent,
  type NativeSyntheticEvent,
} from 'react-native';
import Animated, {
  Extrapolation,
  FadeIn,
  FadeInDown,
  interpolate,
  useAnimatedScrollHandler,
  useAnimatedStyle,
  useDerivedValue,
  useSharedValue,
  withSpring,
  type SharedValue,
} from 'react-native-reanimated';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import OnboardingCarRoad, { type RoadLandmark } from '../../src/components/onboarding/OnboardingCarRoad';
import { hubGlassPalette, type HubGlassTone } from '../../src/components/shared/HubGlassIcon';
import { formatDisplayName } from '../../src/utils/formatDisplayName';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { CCP, ccpSingularLower } from '../../src/constants/carCareProLabels';

const START_ICON = require('../../assets/onboarding-start.png');

type IconName = keyof typeof Ionicons.glyphMap;

interface Step {
  id: string;
  kicker: string;
  title: string;
  description: string;
  icon: IconName;
  tone: HubGlassTone;
  image?: number;
  /** Transparent artwork shown without the rounded tile. */
  freeImage?: boolean;
  bullets?: readonly { icon: IconName; title: string; text: string }[];
  chips?: readonly string[];
}

export default function CustomerOnboarding() {
  const { user } = useAuth();
  const { preview } = useLocalSearchParams<{ preview?: string }>();
  const isPreview = preview === '1';
  const insets = useSafeAreaInsets();
  const { width, height } = useWindowDimensions();
  const [index, setIndex] = useState(0);
  const listRef = useRef<Animated.FlatList<Step>>(null);
  const scrollX = useSharedValue(0);
  const roadProgress = useDerivedValue(() => scrollX.value / Math.max(width, 1));

  const compact = height < 760;
  const heroHeight = Math.round(Math.min(Math.max(height * 0.36, 220), 330));

  const displayName =
    formatDisplayName(
      user?.name ?? (user as any)?.user_metadata?.full_name ?? user?.email?.split('@')[0] ?? '',
    ) || 'there';
  const firstName = displayName.split(/\s+/)[0] ?? displayName;

  const steps = useMemo<Step[]>(
    () => [
      {
        id: 'welcome',
        kicker: "You're in",
        title: `Hi ${firstName}, welcome to Wish a Wash`,
        description: `A ${ccpSingularLower()} comes to you, at home, at work or wherever your car is parked.`,
        icon: 'sparkles',
        tone: 'sky',
        image: START_ICON,
        chips: ['Mobile washes', 'At your door', 'Detailing'],
      },
      {
        id: 'book',
        kicker: 'Book',
        title: 'Your wash, your way',
        description: 'From a quick Bronze to a full Platinum detail. Pick a service, a place and a time.',
        icon: 'water',
        tone: 'sky',
        bullets: [
          { icon: 'flash', title: 'Instant or scheduled', text: 'Book now or pick a slot' },
          { icon: 'location', title: 'Anywhere', text: 'Home, work or on the go' },
          { icon: 'pricetag', title: 'Clear pricing', text: 'See the price before you book' },
        ],
      },
      {
        id: 'pros',
        kicker: 'Trust',
        title: `Vetted ${CCP.pluralShort}`,
        description: `Every ${ccpSingularLower()} is checked, trained and insured, so your car is in safe hands.`,
        icon: 'shield-checkmark',
        tone: 'violet',
        bullets: [
          { icon: 'checkmark-circle', title: 'Background checked', text: 'Identity and history verified' },
          { icon: 'ribbon', title: 'Trained pros', text: 'Quality products, every time' },
          { icon: 'shield-checkmark', title: 'Fully insured', text: 'Covered from start to finish' },
        ],
      },
      {
        id: 'track',
        kicker: 'Live',
        title: 'Follow every step',
        description: `Watch your ${ccpSingularLower()} on the map with a live ETA and before & after photos.`,
        icon: 'navigate',
        tone: 'pink',
        bullets: [
          { icon: 'map', title: 'Live tracking', text: 'Real-time map and ETA' },
          { icon: 'camera', title: 'Before & after', text: 'Photos of the finished job' },
          { icon: 'chatbubble-ellipses', title: 'In-app chat', text: 'Message your Pro directly' },
        ],
      },
      {
        id: 'rewards',
        kicker: 'Perks',
        title: 'Wash more, get more',
        description: 'Earn points on every wash, unlock member discounts and give friends credit.',
        icon: 'gift',
        tone: 'gold',
        bullets: [
          { icon: 'star', title: 'Points on every wash', text: 'Spend them on your next one' },
          { icon: 'wallet', title: 'Member discounts', text: 'Better prices as you go' },
          { icon: 'people', title: 'Referral rewards', text: 'You both get credit' },
        ],
      },
      {
        id: 'ready',
        kicker: 'All set',
        title: 'Time for your first wash',
        description: `Head to your dashboard and book. We'll match you with a top ${ccpSingularLower()} nearby.`,
        icon: 'checkmark-circle',
        tone: 'green',
        chips: ['A few taps', 'No queue', 'Gleaming car'],
      },
    ],
    [firstName],
  );

  const accents = useMemo(() => steps.map((s) => hubGlassPalette(s.tone).glow), [steps]);
  const landmarks = useMemo<RoadLandmark[]>(
    () =>
      steps.map((s, i) =>
        i === steps.length - 1
          ? { tone: s.tone, finish: true }
          : s.image && !s.freeImage
            ? { tone: s.tone, image: s.image }
            : { tone: s.tone, icon: s.icon },
      ),
    [steps],
  );
  const isLast = index === steps.length - 1;

  const onScroll = useAnimatedScrollHandler((e) => {
    scrollX.value = e.contentOffset.x;
  });

  const onMomentumEnd = useCallback(
    (e: NativeSyntheticEvent<NativeScrollEvent>) => {
      const next = Math.round(e.nativeEvent.contentOffset.x / width);
      if (next !== index) {
        setIndex(next);
        void hapticFeedback('light');
      }
    },
    [index, width],
  );

  const goTo = (i: number) => {
    listRef.current?.scrollToIndex({ index: i, animated: true });
    setIndex(i);
    void hapticFeedback('light');
  };

  const complete = async () => {
    void hapticFeedback('medium');
    if (isPreview) {
      router.replace('/auth/login');
      return;
    }
    try {
      await AsyncStorage.setItem('customer_onboarding_seen', 'true');
      await AsyncStorage.setItem('onboarding_seen', 'customer');
    } catch {
      // ignore
    }
    router.replace('/owner/owner-dashboard');
  };

  const handleNext = () => (isLast ? void complete() : goTo(index + 1));

  const renderStep = ({ item, index: i }: { item: Step; index: number }) => (
    <StepSlide
      step={item}
      index={i}
      total={steps.length}
      width={width}
      heroHeight={heroHeight}
      compact={compact}
      scrollX={scrollX}
    />
  );

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />
      <BubbleBackground accountType="customer" />

      <View style={[styles.topBar, { paddingTop: insets.top + 10 }]}>
        <View style={styles.segments}>
          {steps.map((s, i) => (
            <ProgressSegment key={s.id} i={i} width={width} scrollX={scrollX} color={accents[i]!} />
          ))}
        </View>
        {isLast ? (
          <View style={styles.skip} />
        ) : (
          <Pressable onPress={() => void complete()} hitSlop={10} style={styles.skip}>
            <Text style={styles.skipText}>Skip</Text>
          </Pressable>
        )}
      </View>

      {isPreview ? (
        <Animated.View entering={FadeIn.delay(200)} style={styles.previewBadge}>
          <Ionicons name="flask" size={12} color="#FDE68A" />
          <Text style={styles.previewText}>Preview: nothing is saved</Text>
        </Animated.View>
      ) : null}

      <View style={styles.listWrap}>
        <OnboardingCarRoad
          progress={roadProgress}
          landmarks={landmarks}
          height={heroHeight}
          style={styles.road}
        />
        <Animated.FlatList
          ref={listRef}
          data={steps}
          renderItem={renderStep}
          keyExtractor={(s) => s.id}
          horizontal
          pagingEnabled
          bounces={false}
          showsHorizontalScrollIndicator={false}
          onScroll={onScroll}
          scrollEventThrottle={16}
          onMomentumScrollEnd={onMomentumEnd}
          getItemLayout={(_, i) => ({ length: width, offset: width * i, index: i })}
          style={styles.list}
        />
      </View>

      <View style={[styles.footer, { paddingBottom: Math.max(insets.bottom, 14) + 8 }]}>
        {index > 0 ? (
          <Animated.View entering={FadeIn}>
            <Pressable
              onPress={() => goTo(index - 1)}
              style={({ pressed }) => [styles.backBtn, pressed && styles.pressed]}
              accessibilityLabel="Previous step"
            >
              <Ionicons name="chevron-back" size={22} color="#F8FAFC" />
            </Pressable>
          </Animated.View>
        ) : null}
        <NextButton
          accent={accents[index]!}
          label={
            isLast
              ? isPreview
                ? 'Finish preview'
                : 'Go to my dashboard'
              : index === 0
                ? "Let's go"
                : 'Continue'
          }
          icon={isLast ? 'rocket' : 'arrow-forward'}
          onPress={handleNext}
        />
      </View>
    </View>
  );
}

function ProgressSegment({
  i,
  width,
  scrollX,
  color,
}: Readonly<{ i: number; width: number; scrollX: SharedValue<number>; color: string }>) {
  const fill = useAnimatedStyle(() => ({
    width: `${interpolate(scrollX.value, [(i - 1) * width, i * width], [0, 100], Extrapolation.CLAMP)}%`,
  }));
  return (
    <View style={styles.segmentTrack}>
      <Animated.View style={[styles.segmentFill, { backgroundColor: color }, fill]} />
    </View>
  );
}

function StepSlide({
  step,
  index,
  total,
  width,
  heroHeight,
  compact,
  scrollX,
}: Readonly<{
  step: Step;
  index: number;
  total: number;
  width: number;
  heroHeight: number;
  compact: boolean;
  scrollX: SharedValue<number>;
}>) {
  const palette = hubGlassPalette(step.tone);
  const range = [(index - 1) * width, index * width, (index + 1) * width];
  const panelStyle = useAnimatedStyle(() => ({
    opacity: interpolate(scrollX.value, range, [0.2, 1, 0.2], Extrapolation.CLAMP),
    transform: [
      { translateY: interpolate(scrollX.value, range, [24, 0, 24], Extrapolation.CLAMP) },
      { scale: interpolate(scrollX.value, range, [0.96, 1, 0.96], Extrapolation.CLAMP) },
    ],
  }));
  const copyStyle = useAnimatedStyle(() => ({
    transform: [
      {
        translateX: interpolate(scrollX.value, range, [width * 0.12, 0, -width * 0.12], Extrapolation.CLAMP),
      },
    ],
  }));

  return (
    <View style={[styles.slide, { width }]}>
      <View style={{ height: heroHeight }} />

      <Animated.View style={[styles.panel, compact && styles.panelCompact, panelStyle]}>
        <Animated.View style={copyStyle}>
          <View style={styles.kickerRow}>
            <View style={styles.kickerWrap}>
              <View style={[styles.kickerDot, { backgroundColor: palette.glow }]} />
              <Text style={[styles.kicker, { color: palette.glow }]}>{step.kicker.toUpperCase()}</Text>
            </View>
            <Text style={styles.stepCount}>
              {index + 1} of {total}
            </Text>
          </View>
          <Text style={[styles.title, compact && styles.titleCompact]}>{step.title}</Text>
          <Text style={[styles.description, compact && styles.descriptionCompact]}>{step.description}</Text>
        </Animated.View>

        {step.bullets ? (
          <View style={[styles.bullets, compact && styles.bulletsCompact]}>
            {step.bullets.map((b) => (
              <View key={b.title} style={[styles.bulletRow, compact && styles.bulletRowCompact]}>
                <Ionicons
                  name={b.icon}
                  size={compact ? 19 : 21}
                  color={palette.glow}
                  style={styles.bulletIcon}
                />
                <View style={styles.bulletTextWrap}>
                  <Text style={styles.bulletTitle} numberOfLines={1}>
                    {b.title}
                  </Text>
                  <Text style={styles.bulletText} numberOfLines={1}>
                    {b.text}
                  </Text>
                </View>
              </View>
            ))}
          </View>
        ) : null}

        {step.chips ? (
          <View style={[styles.chips, compact && styles.bulletsCompact]}>
            {step.chips.map((c) => (
              <View key={c} style={styles.chip}>
                <Ionicons name="checkmark" size={15} color={palette.glow} />
                <Text style={styles.chipText}>{c}</Text>
              </View>
            ))}
          </View>
        ) : null}
      </Animated.View>
    </View>
  );
}

function NextButton({
  accent,
  label,
  icon,
  onPress,
}: Readonly<{ accent: string; label: string; icon: IconName; onPress: () => void }>) {
  const scale = useSharedValue(1);
  const pressStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  return (
    <Animated.View style={[styles.nextWrap, { shadowColor: accent }, pressStyle]}>
      <Pressable
        onPress={onPress}
        onPressIn={() => {
          scale.value = withSpring(0.96, { damping: 18, stiffness: 320 });
        }}
        onPressOut={() => {
          scale.value = withSpring(1, { damping: 14, stiffness: 260 });
        }}
        style={styles.nextBtn}
        accessibilityRole="button"
        accessibilityLabel={label}
      >
        <LinearGradient
          colors={[accent, `${accent}CC`]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={StyleSheet.absoluteFill}
        />
        <LinearGradient
          colors={['rgba(255,255,255,0.28)', 'rgba(255,255,255,0)']}
          start={{ x: 0.5, y: 0 }}
          end={{ x: 0.5, y: 1 }}
          style={styles.nextSheen}
        />
        <Animated.Text key={label} entering={FadeInDown.duration(220)} style={styles.nextText}>
          {label}
        </Animated.Text>
        <View style={styles.nextIcon}>
          <Ionicons name={icon} size={18} color="#fff" />
        </View>
      </Pressable>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: 'transparent' },

  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    gap: 14,
  },
  segments: { flex: 1, flexDirection: 'row', gap: 6 },
  segmentTrack: {
    flex: 1,
    height: 4,
    borderRadius: 999,
    backgroundColor: 'rgba(148,163,184,0.18)',
    overflow: 'hidden',
  },
  segmentFill: { height: '100%', borderRadius: 999 },
  skip: { minWidth: 44, alignItems: 'flex-end' },
  skipText: { color: 'rgba(226,232,240,0.75)', fontSize: 14, fontWeight: '700' },

  previewBadge: {
    alignSelf: 'center',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 10,
  },
  previewText: { color: '#FDE68A', fontSize: 12, fontWeight: '700' },

  listWrap: { flex: 1 },
  road: { position: 'absolute', top: 0, left: 0, right: 0 },
  list: { flex: 1 },
  slide: { flex: 1, paddingHorizontal: 18, paddingTop: 8 },

  panel: { paddingHorizontal: 8, paddingBottom: 8 },
  panelCompact: { paddingBottom: 2 },
  kickerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  kickerWrap: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  kickerDot: { width: 6, height: 6, borderRadius: 3 },
  kicker: { fontSize: 11, fontWeight: '800', letterSpacing: 1.4 },
  stepCount: { color: 'rgba(226,232,240,0.5)', fontSize: 12, fontWeight: '700' },
  title: {
    color: '#F8FAFC',
    fontSize: 24,
    fontWeight: '800',
    letterSpacing: -0.5,
    lineHeight: 29,
  },
  titleCompact: { fontSize: 22, lineHeight: 27 },
  description: {
    marginTop: 8,
    color: 'rgba(226,232,240,0.7)',
    fontSize: 14,
    fontWeight: '500',
    lineHeight: 20,
  },
  descriptionCompact: { fontSize: 13, lineHeight: 18 },

  bullets: { marginTop: 22, gap: 16 },
  bulletsCompact: { marginTop: 16, gap: 12 },
  bulletRow: { flexDirection: 'row', alignItems: 'center', gap: 14 },
  bulletRowCompact: { gap: 12 },
  bulletIcon: { width: 24, textAlign: 'center' },
  bulletTextWrap: { flex: 1 },
  bulletTitle: { color: '#F8FAFC', fontSize: 13, fontWeight: '700' },
  bulletText: { marginTop: 1, color: 'rgba(226,232,240,0.6)', fontSize: 12, fontWeight: '500' },

  chips: { marginTop: 20, flexDirection: 'row', flexWrap: 'wrap', columnGap: 18, rowGap: 10 },
  chip: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  chipText: { color: 'rgba(241,245,249,0.85)', fontSize: 13, fontWeight: '600' },

  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 18,
    paddingTop: 14,
  },
  backBtn: {
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(148,163,184,0.12)',
  },
  pressed: { transform: [{ scale: 0.95 }] },
  nextWrap: {
    flex: 1,
    borderRadius: 28,
    shadowOpacity: 0.45,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 6 },
    elevation: 8,
  },
  nextBtn: {
    height: 56,
    borderRadius: 28,
    overflow: 'hidden',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
  },
  nextSheen: { position: 'absolute', left: 0, right: 0, top: 0, height: 28 },
  nextText: { color: '#fff', fontSize: 16, fontWeight: '700', letterSpacing: -0.2 },
  nextIcon: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
});
