import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  TextInput,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import AppHeader from '../../../src/components/shared/AppHeader';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { useOwnerScrollContentPadding } from '../../../src/hooks/useOwnerScrollContentPadding';
import { CONTENT_PADDING_H, SECTION_GAP } from '../../../src/constants/pageStyles';
import { colors } from '../../../src/constants/colors';
import GradientIconBox from '../../../src/components/shared/GradientIconBox';
import { accentToGradient } from '../../../src/utils/accentGradient';
import { BORDER_RADIUS, FONT_SIZES, SPACING } from '../../../src/constants/designTokens';
import { CCP } from '../../../src/constants/carCareProLabels';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;

export default function ReportIssue() {
  const scrollPad = useOwnerScrollContentPadding(true);
  useAuth();
  const [issueType, setIssueType] = useState('');
  const [issueDescription, setIssueDescription] = useState('');
  const [bookingId, setBookingId] = useState('');

  const issueTypes = [
    { id: 'service', label: 'Service Issue', icon: 'car' },
    { id: 'payment', label: 'Payment Problem', icon: 'card' },
    { id: 'valeter', label: `${CCP.singularShort} issue`, icon: 'person' },
    { id: 'app', label: 'App Problem', icon: 'phone-portrait' },
    { id: 'other', label: 'Other', icon: 'help-circle' },
  ];

  const handleSubmit = () => {
    if (!issueType || !issueDescription) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }
    Alert.alert('Success', 'Your issue has been reported. We\'ll get back to you soon!');
    router.back();
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      <AppHeader
        title="Report an issue"
        subtitle="Tell us what happened"
        variant="dashboard"
        accountType="customer"
        showBack
        fullWidth
        onBack={() => { hapticFeedback('light'); router.back(); }}
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingHorizontal: CONTENT_PADDING_H, ...scrollPad }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Issue Type Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Issue Type *</Text>
          <View style={styles.typeGrid}>
            {issueTypes.map((type) => (
              <TouchableOpacity
                key={type.id}
                style={[
                  styles.typeCard,
                  issueType === type.id && styles.typeCardSelected,
                ]}
                onPress={() => setIssueType(type.id)}
              >
                <GradientIconBox
                  icon={type.icon as keyof typeof Ionicons.glyphMap}
                  colors={accentToGradient(SKY)}
                  boxSize={44}
                  size={22}
                  borderRadius={14}
                  elevated
                />
                <Text
                  style={[
                    styles.typeLabel,
                    issueType === type.id && styles.typeLabelSelected,
                  ]}
                >
                  {type.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Booking ID */}
        <View style={styles.section}>
          <Text style={styles.inputLabel}>Booking ID (Optional)</Text>
          <TextInput
            style={styles.input}
            value={bookingId}
            onChangeText={setBookingId}
            placeholder="Enter booking ID if related"
            placeholderTextColor="#6B7280"
          />
        </View>

        {/* Description */}
        <View style={styles.section}>
          <Text style={styles.inputLabel}>Description *</Text>
          <TextInput
            style={[styles.input, styles.textArea]}
            value={issueDescription}
            onChangeText={setIssueDescription}
            placeholder="Please describe the issue in detail..."
            placeholderTextColor="#6B7280"
            multiline
            numberOfLines={6}
            textAlignVertical="top"
          />
        </View>

        {/* Submit Button */}
        <TouchableOpacity style={styles.submitButton} onPress={handleSubmit} activeOpacity={0.85}>
          <BlurView intensity={30} tint="dark" style={StyleSheet.absoluteFill} />
          <View style={[StyleSheet.absoluteFill, styles.submitFill]} />
          <LinearGradient
            colors={['rgba(255,255,255,0.2)', 'rgba(255,255,255,0)']}
            style={styles.submitSheen}
            pointerEvents="none"
          />
          <Ionicons name="send" size={18} color="#FFFFFF" />
          <Text style={styles.submitText}>Submit Report</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 120, paddingHorizontal: isSmallScreen ? SPACING.md : SPACING.xl },
  section: {
    marginBottom: SECTION_GAP,
  },
  sectionTitle: {
    color: 'rgba(186,230,253,0.92)',
    fontSize: 10.5,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
    marginBottom: SPACING.md,
  },
  typeGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  typeCard: {
    width: (width - (isSmallScreen ? 48 : 60)) / 2 - 6,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 18,
    padding: 16,
    alignItems: 'center',
  },
  typeCardSelected: {
    backgroundColor: 'rgba(56,189,248,0.16)',
    shadowColor: '#38BDF8',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.35,
    shadowRadius: 12,
    elevation: 6,
  },
  typeLabel: {
    color: '#F8FAFC',
    fontSize: 13,
    fontWeight: '700',
    marginTop: 8,
    textAlign: 'center',
  },
  typeLabelSelected: {
    color: '#7DD3FC',
  },
  inputLabel: {
    color: 'rgba(186,230,253,0.92)',
    fontSize: 10.5,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  input: {
    backgroundColor: 'rgba(148,163,184,0.12)',
    borderRadius: BORDER_RADIUS.md,
    padding: SPACING.lg,
    color: '#F8FAFC',
    fontSize: FONT_SIZES.base,
  },
  textArea: {
    minHeight: 120,
    paddingTop: 14,
  },
  submitButton: {
    height: 52,
    borderRadius: 26,
    overflow: 'hidden',
    marginTop: 8,
    marginBottom: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  submitFill: { backgroundColor: 'rgba(56,189,248,0.45)' },
  submitSheen: { position: 'absolute', left: 0, right: 0, top: 0, height: 26 },
  submitText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
});
