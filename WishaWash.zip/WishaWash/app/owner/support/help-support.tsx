import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Linking,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { LinearGradient } from 'expo-linear-gradient';
import AppHeader from '../../../src/components/shared/AppHeader';
import { useOwnerScrollContentPadding } from '../../../src/hooks/useOwnerScrollContentPadding';
import { CONTENT_PADDING_H, SECTION_GAP } from '../../../src/constants/pageStyles';
import HubGlassIcon from '../../../src/components/shared/HubGlassIcon';
import { Ionicons } from '@expo/vector-icons';
import { MOBILE_SERVICE_ONLY_LAUNCH } from '../../../src/constants/launchCustomerScope';
import { CCP, ccpPluralLower, ccpSingularLower } from '../../../src/constants/carCareProLabels';
import { SUPPORT_EMAIL } from '../../../src/constants/contactEmails';

const POLICY_URL = 'https://www.instagram.com/wishawash.app/';

export default function HelpSupport() {
  const scrollPad = useOwnerScrollContentPadding(true);
  const [expandedFAQ, setExpandedFAQ] = useState<string | null>(null);

  // Updated FAQ
  const faqs = [
    {
      id: '1',
      question: 'How do I book a car wash service?',
      answer: MOBILE_SERVICE_ONLY_LAUNCH
        ? `**Booking Process:**\n\n1. Start a booking from your dashboard\n2. Confirm your location\n3. Select your vehicle (or add one if needed)\n4. Choose your wash\n5. Pick a ${ccpSingularLower()} and review\n6. Confirm and pay\n\nA ${ccpSingularLower()} will be assigned within 5-10 minutes.`
        : `**Booking Process:**\n\n1. Tap "Book a Wash" on your dashboard\n2. Choose between "${CCP.singular}" (${ccpSingularLower()} comes to you) or "Go to Car Wash" (physical car wash)\n3. Select your vehicle (or add one if needed)\n4. Choose service type\n5. Set your location\n6. Review and confirm\n\nA ${ccpSingularLower()} will be assigned within 5-10 minutes for mobile bookings.`,
      category: 'booking'
    },
    {
      id: '2',
      question: 'What is the cancellation policy?',
      answer: '**Cancellation & Refund Policy:**\n\n**Mobile Bookings:**\n• Within 5 minutes: 100% refund\n• Within 15 minutes: 90% refund\n• Within 30 minutes: 75% refund\n• Within 1 hour: 50% refund\n• After 1 hour: No refund\n\n**Scheduled Bookings:**\n• Cancel 24+ hours before: Full refund\n• Cancel 12-24 hours before: 75% refund\n• Cancel less than 12 hours: No refund\n\n**Processing:** Refunds are processed within 24-48 hours to your original payment method.',
      category: 'refunds'
    },
    {
      id: '3',
      question: `How do I track my ${ccpSingularLower()}?`,
      answer: `**Real-Time Tracking:**\n\nOnce a ${ccpSingularLower()} accepts your booking:\n• View their live location on the map\n• See estimated arrival time (ETA)\n• Track their route in real-time\n• Updates every 30 seconds\n\n**If tracking isn't working:**\n1. Refresh the app\n2. Check your internet connection\n3. Ensure location permissions are enabled`,
      category: 'tracking'
    },
    {
      id: '4',
      question: 'What payment methods are accepted?',
      answer: '**Payment Methods:**\n\n**Accepted:**\n• Visa, Mastercard, American Express\n• Debit cards\n• PayPal\n• Apple Pay\n• Google Pay\n\n**Security:**\n• All payments processed via Stripe\n• 256-bit SSL encryption\n• Your card details are never stored\n• PCI DSS compliant',
      category: 'payments'
    },
    {
      id: '5',
      question: `How do I become a ${ccpSingularLower()}?`,
      answer: `**Become a ${CCP.singularShort}:**\n\n**Requirements:**\n• Valid UK driving license\n• Valid car insurance\n• DBS check\n• Vehicle in good condition\n• Smartphone with GPS\n\n**Application Process:**\n1. Download app and select "Join as ${CCP.singularShort}"\n2. Complete profile information\n3. Upload required documents\n4. Background check (5-7 business days)\n5. Account verification\n\n**Timeline:** Verification typically takes 3-5 business days.\n\n**Earnings:** Set your own schedule, competitive rates, weekly payments.`,
      category: 'valeter'
    },
    {
      id: '6',
      question: 'What if I\'m not satisfied with the service?',
      answer: '**Service Quality Guarantee:**\n\n**If you\'re not satisfied:**\n1. Contact us within 24 hours of service\n2. Include photos if applicable\n3. Provide booking ID and details\n4. Describe the issue clearly\n\n**We may offer:**\n• Full or partial refund\n• Free re-service\n• Account credit\n• Discount on next booking\n\n**Resolution Timeline:**\n• Response within 24 hours\n• Investigation within 48 hours\n• Resolution within 72 hours',
      category: 'quality'
    },
    {
      id: '7',
      question: 'How do rewards and points work?',
      answer: `**Rewards & Loyalty Program:**\n\n**Earn Points:**\n• 10 points per £1 spent on bookings\n• 5 points for rating ${CCP.pluralShort}\n• 50 points per friend referral\n• Bonus points during promotions\n\n**Tier Levels:**\n• **Bronze:** 0-500 points (5% discount)\n• **Silver:** 501-1,500 points (10% discount)\n• **Gold:** 1,501-3,000 points (15% discount)\n• **Platinum:** 3,000+ points (20% discount + exclusive perks)\n\n**Redeem For:**\n• Discounts on services\n• Free washes\n• Exclusive rewards\n• Priority booking\n\n**Check your tier:** Go to Rewards section on your dashboard`,
      category: 'rewards'
    },
    {
      id: '8',
      question: 'Is my data secure?',
      answer: `🔒 **Data Security & Privacy:**\n\n**Security Measures:**\n• 256-bit SSL encryption\n• Secure payment processing (Stripe)\n• PCI DSS compliant\n• Regular security audits\n\n**Privacy:**\n• GDPR compliant\n• We never share your data with third parties\n• Your location is only shared with your assigned ${ccpSingularLower()}\n• You control your privacy settings\n• Data deletion available on request\n\n**Your Rights:**\n• Access your data anytime\n• Request data deletion\n• Update preferences\n• Opt-out of marketing`,
      category: 'security'
    },
    {
      id: '9',
      question: 'How do I report an issue?',
      answer: `**Reporting Issues:**\n\n**How to Report:**\n1. Go to Help & Support\n2. Tap "Report an Issue"\n3. Select issue type\n4. Provide details:\n   - Booking ID (if applicable)\n   - Description of issue\n   - Photos (if relevant)\n\n**Response Times:**\n• Urgent issues: Within 24 hours\n• General issues: Within 48 hours\n\n**Resolution:**\n• Investigation within 48 hours\n• Resolution within 72 hours\n\n**Contact:** Email ${SUPPORT_EMAIL}`,
      category: 'support'
    },
    {
      id: '10',
      question: 'What are the service areas?',
      answer: MOBILE_SERVICE_ONLY_LAUNCH
        ? `🗺️ **Service Coverage:**\n\n**Current Service Areas:**\n• London (Greater London)\n• Manchester\n• Birmingham\n• Leeds\n• Liverpool\n• Surrounding areas\n\n**How to Check:**\n• Enter your postcode in the app\n• View available ${ccpPluralLower()} in your area\n• See estimated wait times\n• Check service availability\n\n**Expanding:**\nWe're constantly expanding to new areas. Check the app regularly for updates!`
        : `🗺️ **Service Coverage:**\n\n**Current Service Areas:**\n• London (Greater London)\n• Manchester\n• Birmingham\n• Leeds\n• Liverpool\n• Surrounding areas\n\n**How to Check:**\n• Enter your postcode in the app\n• View available ${ccpPluralLower()} in your area\n• See estimated wait times\n• Check service availability\n\n**Expanding:**\nWe're constantly expanding to new areas. Check the app regularly for updates!\n\n**Physical Locations:**\nWe also have physical car wash locations. Check the map for nearest locations.`,
      category: 'coverage'
    },
    {
      id: '11',
      question: 'How do I change my booking?',
      answer: `**Modifying Bookings:**\n\n**What You Can Change:**\n• Service type (upgrade/downgrade)\n• Location (before your ${ccpSingularLower()} accepts)\n• Time (if scheduled)\n• Vehicle (if multiple saved)\n\n**Time Limits:**\n• Mobile: Can change before your ${ccpSingularLower()} accepts\n• Scheduled: Modify up to 1 hour before\n• After your ${ccpSingularLower()} accepts: Contact support\n\n**How to Modify:**\n1. Go to Active Bookings\n2. Select booking to modify\n3. Tap "Edit Booking"\n4. Make changes\n5. Confirm updates\n\n**Cancellations:**\nFollow our refund policy (see Cancellation Policy FAQ)`,
      category: 'booking'
    },
    {
      id: '12',
      question: `What if my ${ccpSingularLower()} doesn't show up?`,
      answer: `🚨 **${CCP.singularShort} no-show policy:**\n\n**If your ${ccpSingularLower()} doesn't arrive:**\n• Wait 15 minutes past scheduled time\n• Contact us immediately via email\n• We'll find you another ${ccpSingularLower()}\n• Or provide full refund + compensation\n\n**What We Do:**\n• Immediately assign a new ${ccpSingularLower()}\n• Priority booking for you\n• Full refund if no replacement\n• Compensation for inconvenience\n\n**Compensation:**\n• Account credit\n• Discount on next booking\n• Free service upgrade\n\n**Response Time:**\n• Within 24 hours of contact\n• New ${ccpSingularLower()} assigned within 48 hours\n• Full resolution within 72 hours`,
      category: 'service'
    },
    {
      id: '13',
      question: 'How do I update my profile?',
      answer: `**Updating Your Profile:**\n\n**What You Can Update:**\n• Name and contact information\n• Email address\n• Phone number\n• Profile picture\n• Vehicle information\n• Payment methods\n• Notification preferences\n\n**How to Update:**\n1. Go to Profile section\n2. Tap "Edit Profile"\n3. Make your changes\n4. Save updates\n\n**For ${CCP.pluralShort}:**\n• Update documents\n• Change availability\n• Update vehicle info\n• Modify service areas`,
      category: 'account'
    },
    {
      id: '14',
      question: 'How do I contact support?',
      answer: `📧 **Contact Support:**\n\n**Email Support:**\n• ${SUPPORT_EMAIL}\n• General inquiries\n• Response within 24 hours\n• Include booking ID if applicable\n\n**Response Times:**\n• General inquiries: Within 24 hours\n• Urgent issues: Within 12 hours\n• Non-urgent: Within 48 hours`,
      category: 'support'
    }
  ];

  const toggleFAQ = async (id: string) => {
    try {
      await hapticFeedback('light');
      setExpandedFAQ(expandedFAQ === id ? null : id);
    } catch (error) {
      console.error('Error in toggleFAQ:', error);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <AppHeader
        title="Help & Support"
        subtitle="Priority answers and contact options"
        accountType="customer"
        showBack
        fullWidth
        onBack={() => { hapticFeedback('light'); router.back(); }}
      />

      <ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingHorizontal: CONTENT_PADDING_H, ...scrollPad }}
      >

        {/* Email Support */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Contact Support</Text>
            <Text style={styles.sectionSubtitle}>Get help via email</Text>
          </View>
          <TouchableOpacity 
            style={styles.emailSupportCard} 
            onPress={() => Linking.openURL(`mailto:${SUPPORT_EMAIL}?subject=Support Request`)}
            activeOpacity={0.85}
          >
            <LinearGradient
              colors={['rgba(255,255,255,0.14)', 'rgba(255,255,255,0)']}
              style={styles.emailSupportSheen}
              pointerEvents="none"
            />
            <View style={styles.emailSupportGradient}>
              <View style={styles.emailSupportIconWrapper}>
                <HubGlassIcon icon="mail" accent="sky" size={52} />
              </View>
              <Text style={styles.emailSupportTitle}>Email Support</Text>
              <Text style={styles.emailSupportSubtitle}>{SUPPORT_EMAIL}</Text>
              <Text style={styles.emailSupportDescription}>Send us an email and we'll get back to you within 24 hours</Text>
            </View>
          </TouchableOpacity>
        </View>

        {/* FAQ Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Frequently Asked Questions</Text>
          <View style={styles.faqContainer}>
            {faqs.map((faq, index) => (
              <TouchableOpacity
                key={faq.id}
                style={[styles.faqItem, index > 0 && styles.faqItemDivider]}
                onPress={() => toggleFAQ(faq.id)}
              >
                <View style={styles.faqHeader}>
                  <Text style={styles.faqQuestion}>{faq.question}</Text>
                  <Text style={styles.faqToggle}>
                    {expandedFAQ === faq.id ? '−' : '+'}
                  </Text>
                </View>
                {expandedFAQ === faq.id && (
                  <Text style={styles.faqAnswer}>{faq.answer}</Text>
                )}
              </TouchableOpacity>
            ))}
          </View>
        </View>


        {/* Legal Links */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Legal</Text>
          <View style={styles.legalGrid}>
            <TouchableOpacity style={styles.legalLink} onPress={() => void Linking.openURL(POLICY_URL)}>
              <Text style={styles.legalLinkText}>Terms and conditions</Text>
              <Ionicons name="chevron-forward" size={18} color="rgba(148,163,184,0.75)" />
            </TouchableOpacity>
            <TouchableOpacity style={[styles.legalLink, styles.legalLinkDivider]} onPress={() => void Linking.openURL(POLICY_URL)}>
              <Text style={styles.legalLinkText}>Privacy policy</Text>
              <Ionicons name="chevron-forward" size={18} color="rgba(148,163,184,0.75)" />
            </TouchableOpacity>
            <TouchableOpacity style={[styles.legalLink, styles.legalLinkDivider]} onPress={() => void Linking.openURL(POLICY_URL)}>
              <Text style={styles.legalLinkText}>Cookie policy</Text>
              <Ionicons name="chevron-forward" size={18} color="rgba(148,163,184,0.75)" />
            </TouchableOpacity>
          </View>
        </View>

        {/* App Info */}
        <View style={styles.appInfoCard}>
          <Text style={styles.appInfoTitle}>Wish a Wash</Text>
          <Text style={styles.appInfoVersion}>Version 1.0.0</Text>
          <Text style={styles.appInfoCopyright}>© 2025 Wish a Wash. All rights reserved.</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  scrollView: {
    flex: 1,
  },
  section: {
    paddingVertical: 12,
    marginBottom: SECTION_GAP,
  },
  sectionTitle: {
    color: 'rgba(186,230,253,0.92)',
    fontSize: 10.5,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
    marginBottom: 12,
  },
  sectionHeader: {
    marginBottom: 4,
  },
  sectionSubtitle: {
    color: 'rgba(226,232,240,0.7)',
    fontSize: 14,
    fontWeight: '500',
    marginTop: -6,
    marginBottom: 12,
  },
  faqContainer: {
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 20,
    overflow: 'hidden',
  },
  faqItem: {
    paddingHorizontal: 16,
    paddingVertical: 14,
  },
  faqItemDivider: {
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(255,255,255,0.12)',
  },
  faqHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  faqQuestion: {
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '600',
    flex: 1,
    marginRight: 16,
  },
  faqToggle: {
    color: '#7DD3FC',
    fontSize: 20,
    fontWeight: '700',
  },
  faqAnswer: {
    color: 'rgba(226,232,240,0.7)',
    fontSize: 14,
    fontWeight: '500',
    lineHeight: 20,
    marginTop: 10,
  },
  legalGrid: {
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 20,
    overflow: 'hidden',
  },
  legalLink: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 14,
  },
  legalLinkDivider: {
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(255,255,255,0.12)',
  },
  legalLinkText: {
    flex: 1,
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '600',
  },
  appInfoCard: {
    paddingVertical: 20,
    alignItems: 'center',
    marginBottom: 20,
  },
  appInfoTitle: {
    color: '#F8FAFC',
    fontSize: 20,
    fontWeight: '800',
    letterSpacing: -0.4,
    marginBottom: 4,
  },
  appInfoVersion: {
    color: 'rgba(186,230,253,0.92)',
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 4,
  },
  appInfoCopyright: {
    color: 'rgba(226,232,240,0.5)',
    fontSize: 11,
    fontWeight: '500',
    textAlign: 'center',
  },
  emailSupportCard: {
    borderRadius: 22,
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  emailSupportSheen: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    height: 80,
  },
  emailSupportGradient: {
    padding: 24,
    alignItems: 'center',
  },
  emailSupportIconWrapper: {
    marginBottom: 14,
    alignItems: 'center',
  },
  emailSupportTitle: {
    color: '#F8FAFC',
    fontSize: 20,
    fontWeight: '800',
    letterSpacing: -0.4,
    marginBottom: 6,
    textAlign: 'center',
  },
  emailSupportSubtitle: {
    color: '#7DD3FC',
    fontSize: 15,
    fontWeight: '700',
    marginBottom: 10,
    textAlign: 'center',
  },
  emailSupportDescription: {
    color: 'rgba(226,232,240,0.7)',
    fontSize: 14,
    fontWeight: '500',
    textAlign: 'center',
    lineHeight: 20,
  },
});
