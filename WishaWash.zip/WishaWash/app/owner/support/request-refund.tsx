import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  TextInput,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import AppHeader from '../../../src/components/shared/AppHeader';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { useOwnerScrollContentPadding } from '../../../src/hooks/useOwnerScrollContentPadding';
import { CONTENT_PADDING_H, SECTION_GAP } from '../../../src/constants/pageStyles';
import { colors } from '../../../src/constants/colors';
import GradientIconBox from '../../../src/components/shared/GradientIconBox';
import HubGlassIcon from '../../../src/components/shared/HubGlassIcon';
import { accentToGradient } from '../../../src/utils/accentGradient';
import { BORDER_RADIUS, FONT_SIZES, SPACING } from '../../../src/constants/designTokens';
import { CCP } from '../../../src/constants/carCareProLabels';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;

export default function RequestRefund() {
  const scrollPad = useOwnerScrollContentPadding(true);
  useAuth();
  const [selectedBooking, setSelectedBooking] = useState('');
  const [refundReason, setRefundReason] = useState('');
  const [refundAmount, setRefundAmount] = useState('');

  const refundReasons = [
    { id: 'service', label: 'Service Not Completed', icon: 'close-circle' },
    { id: 'quality', label: 'Poor Quality', icon: 'thumbs-down' },
    { id: 'cancelled', label: `Cancelled by ${CCP.singularShort}`, icon: 'ban' },
    { id: 'other', label: 'Other', icon: 'help-circle' },
  ];

  const handleSubmit = () => {
    if (!selectedBooking || !refundReason) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }
    Alert.alert('Success', 'Your refund request has been submitted. We\'ll review it within 24-48 hours.');
    router.back();
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      <AppHeader
        title="Request a refund"
        subtitle="Fast review within 24-48 hours"
        variant="dashboard"
        accountType="customer"
        showBack
        fullWidth
        onBack={() => { hapticFeedback('light'); router.back(); }}
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingHorizontal: CONTENT_PADDING_H, ...scrollPad }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Booking Selection */}
        <View style={styles.section}>
          <Text style={styles.inputLabel}>Booking ID *</Text>
          <TextInput
            style={styles.input}
            value={selectedBooking}
            onChangeText={setSelectedBooking}
            placeholder="Enter booking ID"
            placeholderTextColor="#6B7280"
          />
        </View>

        {/* Refund Reason */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Refund Reason *</Text>
          <View style={styles.reasonGrid}>
            {refundReasons.map((reason) => (
              <TouchableOpacity
                key={reason.id}
                style={[
                  styles.reasonCard,
                  refundReason === reason.id && styles.reasonCardSelected,
                ]}
                onPress={() => setRefundReason(reason.id)}
              >
                <GradientIconBox
                  icon={reason.icon as keyof typeof Ionicons.glyphMap}
                  colors={accentToGradient(SKY)}
                  boxSize={44}
                  size={22}
                  borderRadius={14}
                  elevated
                />
                <Text
                  style={[
                    styles.reasonLabel,
                    refundReason === reason.id && styles.reasonLabelSelected,
                  ]}
                >
                  {reason.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Refund Amount */}
        <View style={styles.section}>
          <Text style={styles.inputLabel}>Refund Amount (£) *</Text>
          <TextInput
            style={styles.input}
            value={refundAmount}
            onChangeText={setRefundAmount}
            placeholder="Enter amount"
            placeholderTextColor="#6B7280"
            keyboardType="decimal-pad"
          />
        </View>

        {/* Info Card */}
        <View style={styles.infoCard}>
          <HubGlassIcon icon="information-circle" accent="sky" size={36} />
          <Text style={styles.infoText}>
            Refunds are typically processed within 5-7 business days. You'll receive a confirmation email once your request is reviewed.
          </Text>
        </View>

        {/* Submit Button */}
        <TouchableOpacity style={styles.submitButton} onPress={handleSubmit} activeOpacity={0.85}>
          <BlurView intensity={30} tint="dark" style={StyleSheet.absoluteFill} />
          <View style={[StyleSheet.absoluteFill, styles.submitFill]} />
          <LinearGradient
            colors={['rgba(255,255,255,0.2)', 'rgba(255,255,255,0)']}
            style={styles.submitSheen}
            pointerEvents="none"
          />
          <Ionicons name="card" size={18} color="#FFFFFF" />
          <Text style={styles.submitText}>Submit Refund Request</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 120, paddingHorizontal: isSmallScreen ? SPACING.md : SPACING.xl },
  section: {
    marginBottom: SECTION_GAP,
  },
  sectionTitle: {
    color: 'rgba(186,230,253,0.92)',
    fontSize: 10.5,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
    marginBottom: SPACING.md,
  },
  inputLabel: {
    color: 'rgba(186,230,253,0.92)',
    fontSize: 10.5,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  input: {
    backgroundColor: 'rgba(148,163,184,0.12)',
    borderRadius: BORDER_RADIUS.md,
    padding: SPACING.md,
    color: '#F8FAFC',
    fontSize: FONT_SIZES.base,
  },
  reasonGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  reasonCard: {
    width: (width - (isSmallScreen ? 48 : 60)) / 2 - 6,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 18,
    padding: 16,
    alignItems: 'center',
  },
  reasonCardSelected: {
    backgroundColor: 'rgba(56,189,248,0.16)',
    shadowColor: '#38BDF8',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.35,
    shadowRadius: 12,
    elevation: 6,
  },
  reasonLabel: {
    color: '#F8FAFC',
    fontSize: 12,
    fontWeight: '700',
    marginTop: 8,
    textAlign: 'center',
  },
  reasonLabelSelected: {
    color: '#7DD3FC',
  },
  infoCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(56,189,248,0.1)',
    borderRadius: 18,
    padding: 16,
    marginBottom: 24,
    gap: 12,
  },
  infoText: {
    flex: 1,
    color: 'rgba(226,232,240,0.7)',
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '500',
  },
  submitButton: {
    height: 52,
    borderRadius: 26,
    overflow: 'hidden',
    marginTop: 8,
    marginBottom: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  submitFill: { backgroundColor: 'rgba(56,189,248,0.45)' },
  submitSheen: { position: 'absolute', left: 0, right: 0, top: 0, height: 26 },
  submitText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
});
