/**
 * Post-auth profile setup — required name + vehicle reg, optional profile photo.
 * Used after Apple Sign In (and any customer missing those fields).
 */
import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  Platform,
  KeyboardAvoidingView,
  ScrollView,
  StatusBar,
  Animated,
  useWindowDimensions,
} from 'react-native';
import { Easing, useSharedValue, withTiming } from 'react-native-reanimated';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system/legacy';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { colors } from '../../src/constants/colors';
import { WWPrimaryButton } from '../../src/components/ui';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import {
  hubGlassPalette,
  type HubGlassTone,
} from '../../src/components/shared/HubGlassIcon';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import OnboardingCarRoad, {
  type RoadLandmark,
} from '../../src/components/onboarding/OnboardingCarRoad';
import { addVehicleByRegistration, cleanVehicleReg } from '../../src/utils/vehicleQuickAdd';
import { hasUsableDisplayName, resolvePostAuthRoute } from '../../src/utils/profileSetupGate';
import {
  profilePicturePathFromUrl,
  uploadProfilePictureBytes,
} from '../../src/utils/profilePictureStorage';

const SKY = colors.SKY ?? '#38BDF8';
const PLATE_YELLOW = '#F8D70C';
const PLATE_BLUE = '#003399';

type StepConfig = {
  label: string;
  icon: React.ComponentProps<typeof Ionicons>['name'];
  tone: HubGlassTone;
  title: string;
  hint: string;
};

const STEPS: readonly StepConfig[] = [
  {
    label: 'Name',
    icon: 'person',
    tone: 'sky',
    title: 'What should we call you?',
    hint: 'Shown on your bookings and messages.',
  },
  {
    label: 'Vehicle',
    icon: 'car-sport',
    tone: 'gold',
    title: 'Add your ride',
    hint: 'Enter your reg — we’ll pull the make and model.',
  },
  {
    label: 'Photo',
    icon: 'camera',
    tone: 'violet',
    title: 'Put a face to the name',
    hint: 'Optional — helps your Pro spot you. You can skip.',
  },
];

const base64ToUint8Array = (base64: string) => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
  let str = base64.replace(/[^A-Za-z0-9+/=]/g, '');
  let output = '';
  let bc = 0;
  let bs = 0;
  let buffer: string;
  let idx = 0;
  while ((buffer = str.charAt(idx++))) {
    const val = chars.indexOf(buffer);
    if (val === -1) continue;
    bs = bc % 4 ? bs * 64 + val : val;
    if (bc++ % 4) output += String.fromCharCode(255 & (bs >> ((-2 * bc) & 6)));
  }
  const bytes = new Uint8Array(output.length);
  for (let i = 0; i < output.length; i += 1) bytes[i] = output.charCodeAt(i);
  return bytes;
};

const getImagePickerMediaTypes = () => {
  const anyPicker: any = ImagePicker;
  return anyPicker.MediaType?.Images ?? anyPicker.MediaTypeOptions?.Images ?? 'Images';
};

export default function ProfileSetupScreen() {
  const { user, updateUser } = useAuth();
  const { preview } = useLocalSearchParams<{ preview?: string }>();
  const isPreview = preview === '1';

  const initialStep = !isPreview && hasUsableDisplayName(user?.name) ? 1 : 0;
  const [step, setStep] = useState(initialStep);
  const [name, setName] = useState(() =>
    !isPreview && hasUsableDisplayName(user?.name) ? user!.name.trim() : '',
  );
  const [registration, setRegistration] = useState('');
  const [photoUri, setPhotoUri] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [focused, setFocused] = useState(false);

  const { width: windowW, height: windowH } = useWindowDimensions();
  const heroHeight = Math.round(Math.min(Math.max(windowH * 0.34, 200), 300));
  const roadProgress = useSharedValue(initialStep);
  useEffect(() => {
    roadProgress.value = withTiming(step, { duration: 900, easing: Easing.inOut(Easing.cubic) });
  }, [step, roadProgress]);

  const enterAnim = useRef(new Animated.Value(1)).current;
  const progressAnim = useRef(new Animated.Value(initialStep)).current;

  useEffect(() => {
    enterAnim.setValue(0);
    Animated.parallel([
      Animated.spring(enterAnim, {
        toValue: 1,
        tension: 60,
        friction: 10,
        useNativeDriver: true,
      }),
      Animated.timing(progressAnim, {
        toValue: step,
        duration: 380,
        useNativeDriver: false,
      }),
    ]).start();
  }, [step, enterAnim, progressAnim]);


  const goToStep = (next: number) => {
    setError(null);
    setFocused(false);
    setStep(next);
  };

  const handleBack = () => {
    if (step === 0 || loading) return;
    void hapticFeedback('light');
    goToStep(step - 1);
  };

  const finishAndRoute = async () => {
    if (isPreview) {
      router.replace('/owner/customer-onboarding?preview=1');
      return;
    }
    if (!user?.id) {
      router.replace('/owner/owner-dashboard');
      return;
    }
    const next = await resolvePostAuthRoute({
      ...user,
      name: name.trim() || user.name,
    });
    if (next === '/owner/profile-setup') {
      router.replace('/owner/customer-onboarding');
      return;
    }
    router.replace(next);
  };

  const handleSaveName = async () => {
    const trimmed = name.trim();
    if (!hasUsableDisplayName(trimmed)) {
      setError('Please enter your full name');
      return;
    }
    await hapticFeedback('medium');
    if (isPreview) {
      goToStep(1);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      await updateUser({ name: trimmed });
      goToStep(1);
    } catch (e: any) {
      setError(e?.message || 'Could not save your name. Try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleSaveVehicle = async () => {
    const reg = cleanVehicleReg(registration);
    if (reg.length < 2) {
      setError('Enter your vehicle registration');
      return;
    }
    await hapticFeedback('medium');
    if (isPreview) {
      goToStep(2);
      return;
    }
    if (!user?.id) return;
    setLoading(true);
    setError(null);
    try {
      const result = await addVehicleByRegistration({
        userId: user.id,
        registration: reg,
        isFirstVehicle: true,
      });
      if (!result.ok) {
        setError(result.message);
        return;
      }
      goToStep(2);
    } catch (e: any) {
      setError(e?.message || 'Could not add that vehicle. Try again.');
    } finally {
      setLoading(false);
    }
  };

  const pickPhoto = async (source: 'library' | 'camera') => {
    try {
      await hapticFeedback('light');
      const perm =
        source === 'camera'
          ? await ImagePicker.requestCameraPermissionsAsync()
          : await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted) {
        setError(
          source === 'camera'
            ? 'Camera permission is needed to take a profile picture.'
            : 'Photo library permission is needed to upload a profile picture.',
        );
        return;
      }
      const options = {
        mediaTypes: getImagePickerMediaTypes(),
        allowsEditing: true,
        aspect: [1, 1] as [number, number],
        quality: 0.85,
      };
      const result =
        source === 'camera'
          ? await ImagePicker.launchCameraAsync(options)
          : await ImagePicker.launchImageLibraryAsync(options);
      if (result.canceled || !result.assets?.[0]?.uri) return;
      setPhotoUri(result.assets[0].uri);
      setError(null);
    } catch (e: any) {
      setError(e?.message || 'Could not open photos.');
    }
  };

  const uploadPhotoIfNeeded = async () => {
    if (!user?.id || !photoUri) return;
    const base64 = await FileSystem.readAsStringAsync(photoUri, {
      encoding: FileSystem.EncodingType.Base64,
    });
    const bytes = base64ToUint8Array(base64);
    const previous = profilePicturePathFromUrl(user.profilePicture);
    const uploadedUrl = await uploadProfilePictureBytes(user.id, bytes, {
      previousUrl: previous,
    });
    const clean = String(uploadedUrl || '').split('?')[0];
    if (!clean) throw new Error('Could not upload profile picture');
    await supabase.from('profiles').update({ profile_picture: clean }).eq('id', user.id);
    await updateUser({ profilePicture: clean });
  };

  const handleFinishPhoto = async (skip: boolean) => {
    await hapticFeedback('medium');
    setLoading(true);
    setError(null);
    try {
      if (isPreview) {
        await finishAndRoute();
        return;
      }
      if (!skip && photoUri) {
        await uploadPhotoIfNeeded();
      }
      try {
        await AsyncStorage.setItem('customer_profile_setup_complete', 'true');
      } catch {
        /* ignore */
      }
      await finishAndRoute();
    } catch (e: any) {
      setError(e?.message || 'Could not finish setup. Try again.');
    } finally {
      setLoading(false);
    }
  };

  const current = STEPS[step]!;
  const roadLandmarks: RoadLandmark[] = STEPS.map((st, i) =>
    i === 2 && photoUri ? { tone: st.tone, image: { uri: photoUri } } : { tone: st.tone, icon: st.icon }
  );
  const accent = hubGlassPalette(current.tone).glow;
  const firstName = name.trim().split(/\s+/)[0] ?? '';
  const nameReady = hasUsableDisplayName(name.trim());
  const regReady = cleanVehicleReg(registration).length >= 2;

  const enterStyle = {
    opacity: enterAnim,
    transform: [
      {
        translateY: enterAnim.interpolate({
          inputRange: [0, 1],
          outputRange: [18, 0],
        }),
      },
      {
        scale: enterAnim.interpolate({
          inputRange: [0, 1],
          outputRange: [0.98, 1],
        }),
      },
    ],
  };

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" />
      <BubbleBackground accountType="customer" />

      <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
        <KeyboardAvoidingView
          style={styles.flex}
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
          keyboardVerticalOffset={8}
        >
          <View style={styles.topBar}>
            <TouchableOpacity
              onPress={handleBack}
              disabled={step === 0}
              style={[styles.backBtn, step === 0 && styles.hidden]}
              hitSlop={12}
              accessibilityLabel="Previous step"
            >
              <Ionicons name="chevron-back" size={24} color="#F8FAFC" />
            </TouchableOpacity>

            <View style={styles.segments}>
              {STEPS.map((s, i) => (
                <View key={s.label} style={styles.segmentTrack}>
                  <Animated.View
                    style={[
                      styles.segmentFill,
                      {
                        width: progressAnim.interpolate({
                          inputRange: [i - 1, i],
                          outputRange: ['0%', '100%'],
                          extrapolate: 'clamp',
                        }),
                      },
                    ]}
                  />
                </View>
              ))}
            </View>

            {isPreview ? (
              <TouchableOpacity
                onPress={() => router.replace('/auth/login')}
                style={styles.exitBtn}
                hitSlop={10}
                accessibilityLabel="Exit preview"
              >
                <Ionicons name="close" size={18} color="#F8FAFC" />
              </TouchableOpacity>
            ) : (
              <Text style={styles.stepCount}>
                {step + 1}/{STEPS.length}
              </Text>
            )}
          </View>

          {isPreview ? (
            <View style={styles.previewBadge}>
              <Ionicons name="flask" size={12} color="#FDE68A" />
              <Text style={styles.previewText}>Preview: nothing is saved</Text>
            </View>
          ) : null}

          <ScrollView
            style={styles.flex}
            contentContainerStyle={styles.scrollContent}
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
          >
            <Animated.View style={[styles.stage, enterStyle]}>
              <OnboardingCarRoad
                progress={roadProgress}
                landmarks={roadLandmarks}
                height={heroHeight}
                style={{ width: windowW }}
              />

              <View style={styles.panel}>
                <View style={styles.kickerRow}>
                  <View style={styles.kickerWrap}>
                    <View style={[styles.kickerDot, { backgroundColor: accent }]} />
                    <Text style={[styles.kicker, { color: accent }]}>
                      {current.label.toUpperCase()}
                    </Text>
                  </View>
                  <Text style={styles.panelCount}>
                    Step {step + 1} of {STEPS.length}
                  </Text>
                </View>
                <Text style={styles.title}>{current.title}</Text>
                <Text style={styles.hint}>{current.hint}</Text>

                {step === 0 ? (
                  <View style={styles.fieldBlock}>
                    <View style={[styles.nameField, focused && styles.fieldFocused]}>
                      <Ionicons
                        name="person-outline"
                        size={20}
                        color={focused ? SKY : 'rgba(148,163,184,0.8)'}
                      />
                      <TextInput
                        style={styles.nameInput}
                        placeholder="Full name"
                        placeholderTextColor="rgba(148,163,184,0.6)"
                        value={name}
                        onChangeText={(t) => {
                          setName(t);
                          setError(null);
                        }}
                        onFocus={() => setFocused(true)}
                        onBlur={() => setFocused(false)}
                        onSubmitEditing={() => void handleSaveName()}
                        returnKeyType="next"
                        autoComplete="name"
                        autoCapitalize="words"
                        accessibilityLabel="Full name"
                      />
                      {nameReady ? (
                        <Ionicons name="checkmark-circle" size={22} color="#34D399" />
                      ) : null}
                    </View>
                    {firstName.length > 1 ? (
                      <View style={styles.greetChip}>
                        <Ionicons name="sparkles" size={14} color={PLATE_YELLOW} />
                        <Text style={styles.greetText}>Hi {firstName}, nice to meet you</Text>
                      </View>
                    ) : null}
                  </View>
                ) : null}

                {step === 1 ? (
                  <View style={styles.fieldBlock}>
                    <View style={[styles.plate, focused && styles.plateFocused]}>
                      <View style={styles.plateBand}>
                        <Text style={styles.plateBandStars}>★</Text>
                        <Text style={styles.plateBandText}>UK</Text>
                      </View>
                      <TextInput
                        style={styles.plateInput}
                        placeholder="AB12 CDE"
                        placeholderTextColor="rgba(11,11,11,0.28)"
                        value={registration}
                        onChangeText={(t) => {
                          setRegistration(t.toUpperCase());
                          setError(null);
                        }}
                        onFocus={() => setFocused(true)}
                        onBlur={() => setFocused(false)}
                        onSubmitEditing={() => void handleSaveVehicle()}
                        returnKeyType="next"
                        maxLength={8}
                        autoCapitalize="characters"
                        autoCorrect={false}
                        accessibilityLabel="Vehicle registration"
                      />
                    </View>
                    <View style={styles.trustRow}>
                      {loading ? (
                        <ActivityIndicator size="small" color={SKY} />
                      ) : (
                        <Ionicons name="shield-checkmark" size={14} color="#34D399" />
                      )}
                      <Text style={styles.trustText}>
                        {loading ? 'Checking DVLA…' : 'Details looked up securely via DVLA'}
                      </Text>
                    </View>
                  </View>
                ) : null}

                {step === 2 ? (
                  <View style={styles.photoBlock}>
                    <View style={styles.sourceRow}>
                      <TouchableOpacity
                        style={styles.sourcePill}
                        onPress={() => void pickPhoto('camera')}
                        activeOpacity={0.85}
                      >
                        <Ionicons name="camera-outline" size={18} color={SKY} />
                        <Text style={styles.sourceText}>Camera</Text>
                      </TouchableOpacity>
                      <TouchableOpacity
                        style={styles.sourcePill}
                        onPress={() => void pickPhoto('library')}
                        activeOpacity={0.85}
                      >
                        <Ionicons name="images-outline" size={18} color={SKY} />
                        <Text style={styles.sourceText}>Library</Text>
                      </TouchableOpacity>
                    </View>

                    {photoUri ? (
                      <TouchableOpacity onPress={() => setPhotoUri(null)} hitSlop={8}>
                        <Text style={styles.removeText}>Remove photo</Text>
                      </TouchableOpacity>
                    ) : null}
                  </View>
                ) : null}

                {error ? (
                  <View style={styles.errorRow}>
                    <Ionicons name="alert-circle" size={16} color="#F87171" />
                    <Text style={styles.errorText}>{error}</Text>
                  </View>
                ) : null}
              </View>
            </Animated.View>
          </ScrollView>

          <View style={styles.footer}>
            {step === 0 ? (
              <WWPrimaryButton
                title={loading ? 'Saving…' : 'Continue'}
                onPress={() => void handleSaveName()}
                disabled={loading || !nameReady}
                loading={loading}
              />
            ) : null}
            {step === 1 ? (
              <WWPrimaryButton
                title={loading ? 'Looking up…' : 'Continue'}
                onPress={() => void handleSaveVehicle()}
                disabled={loading || !regReady}
                loading={loading}
              />
            ) : null}
            {step === 2 ? (
              <>
                <WWPrimaryButton
                  title={loading ? 'Finishing…' : photoUri ? 'Save & finish' : 'Finish'}
                  onPress={() => void handleFinishPhoto(!photoUri)}
                  disabled={loading}
                  loading={loading}
                />
                {!photoUri ? (
                  <TouchableOpacity
                    style={styles.skipBtn}
                    onPress={() => void handleFinishPhoto(true)}
                    disabled={loading}
                    activeOpacity={0.8}
                  >
                    <Text style={styles.skipText}>Skip for now</Text>
                  </TouchableOpacity>
                ) : null}
              </>
            ) : null}
          </View>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: 'transparent' },
  safe: { flex: 1 },
  flex: { flex: 1 },
  hidden: { opacity: 0 },

  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 6,
    gap: 12,
  },
  backBtn: {
    width: 32,
    height: 32,
    alignItems: 'center',
    justifyContent: 'center',
  },
  segments: { flex: 1, flexDirection: 'row', gap: 6 },
  segmentTrack: {
    flex: 1,
    height: 4,
    borderRadius: 999,
    backgroundColor: 'rgba(148,163,184,0.18)',
    overflow: 'hidden',
  },
  segmentFill: { height: '100%', borderRadius: 999, backgroundColor: SKY },
  stepCount: {
    width: 32,
    textAlign: 'right',
    color: 'rgba(226,232,240,0.7)',
    fontSize: 12,
    fontWeight: '800',
  },

  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 18,
    paddingTop: 8,
    paddingBottom: 12,
  },
  stage: { flex: 1, alignItems: 'center' },
  exitBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(148,163,184,0.18)',
  },
  previewBadge: {
    alignSelf: 'center',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 10,
  },
  previewText: { color: '#FDE68A', fontSize: 12, fontWeight: '700' },
  panel: { width: '100%', paddingHorizontal: 6, paddingBottom: 4 },
  kickerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  kickerWrap: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  kickerDot: { width: 6, height: 6, borderRadius: 3 },
  panelCount: { color: 'rgba(226,232,240,0.5)', fontSize: 12, fontWeight: '700' },
  kicker: {
    color: SKY,
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.6,
  },
  title: {
    color: '#F8FAFC',
    fontSize: 24,
    fontWeight: '800',
    letterSpacing: -0.5,
    lineHeight: 29,
  },
  hint: {
    marginTop: 6,
    color: 'rgba(226,232,240,0.65)',
    fontSize: 14,
    fontWeight: '500',
    lineHeight: 20,
  },

  fieldBlock: { width: '100%', marginTop: 20, alignItems: 'flex-start' },
  nameField: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    height: 56,
    borderBottomWidth: 2,
    borderBottomColor: 'rgba(148,163,184,0.25)',
  },
  fieldFocused: {
    borderBottomColor: SKY,
  },
  nameInput: {
    flex: 1,
    color: '#F8FAFC',
    fontSize: 18,
    fontWeight: '700',
    paddingVertical: 0,
  },
  greetChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 14,
  },
  greetText: { color: '#FDE68A', fontSize: 13, fontWeight: '700' },

  plate: {
    width: '100%',
    height: 76,
    flexDirection: 'row',
    borderRadius: 12,
    backgroundColor: PLATE_YELLOW,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: '#111',
  },
  plateFocused: {
    borderColor: SKY,
    shadowColor: PLATE_YELLOW,
    shadowOpacity: 0.45,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 0 },
  },
  plateBand: {
    width: 44,
    backgroundColor: PLATE_BLUE,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
  },
  plateBandStars: { color: PLATE_YELLOW, fontSize: 14 },
  plateBandText: { color: '#FFFFFF', fontSize: 13, fontWeight: '900' },
  plateInput: {
    flex: 1,
    textAlign: 'center',
    color: '#0B0B0B',
    fontSize: 30,
    fontWeight: '900',
    letterSpacing: 3,
    paddingVertical: 0,
  },
  trustRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 14,
  },
  trustText: {
    color: 'rgba(226,232,240,0.65)',
    fontSize: 13,
    fontWeight: '600',
  },

  photoBlock: { alignItems: 'flex-start', marginTop: 18 },
  sourceRow: { flexDirection: 'row', gap: 22 },
  sourcePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    height: 40,
    paddingRight: 8,
  },
  sourceText: { color: '#E0F2FE', fontSize: 14, fontWeight: '800' },
  removeText: {
    marginTop: 14,
    color: 'rgba(226,232,240,0.6)',
    fontSize: 13,
    fontWeight: '700',
  },

  errorRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 16,
  },
  errorText: {
    flexShrink: 1,
    color: '#FCA5A5',
    fontSize: 13,
    fontWeight: '600',
  },

  footer: {
    paddingHorizontal: 18,
    paddingTop: 8,
    paddingBottom: 12,
    gap: 4,
  },
  skipBtn: { alignSelf: 'center', paddingVertical: 10, paddingHorizontal: 16 },
  skipText: { color: 'rgba(226,232,240,0.7)', fontWeight: '700', fontSize: 14 },
});
