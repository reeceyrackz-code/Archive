// app/owner/owner-profile.tsx

import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Image,
  ActivityIndicator,
  TextInput,
  Alert,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { router, useFocusEffect } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system/legacy';
import { SkeletonList } from '../../src/components/shared/SkeletonLoader';
import { useOwnerScrollContentPadding } from '../../src/hooks/useOwnerScrollContentPadding';
import { colors } from '../../src/constants/colors';
import { useToast } from '../../src/contexts/ToastContext';
import { formatDisplayName } from '../../src/utils/formatDisplayName';
import GradientIconBox from '../../src/components/shared/GradientIconBox';
import AppHeader from '../../src/components/shared/AppHeader';
import {
  profilePicturePathFromUrl,
  uploadProfilePictureBytes,
} from '../../src/utils/profilePictureStorage';
import { loadCustomerSavedLocations, savedLocationTitle } from '../../src/utils/customerSavedLocations';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

const base64ToUint8Array = (base64: string) => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
  let str = base64.replace(/[^A-Za-z0-9+/=]/g, '');
  let output = '';
  let bc = 0;
  let bs: number;
  let buffer: string;
  let idx = 0;
  while ((buffer = str.charAt(idx++))) {
    const val = chars.indexOf(buffer);
    if (val === -1) continue;
    bs = bc % 4 ? (bs! * 64) + val : val;
    if (bc++ % 4) output += String.fromCharCode(255 & (bs >> ((-2 * bc) & 6)));
  }
  const bytes = new Uint8Array(output.length);
  for (let i = 0; i < output.length; i += 1) bytes[i] = output.charCodeAt(i);
  return bytes;
};


const uploadProfilePictureToSupabase = async (
  imageUri: string,
  userId: string,
  previousUrl?: string | null,
) => {
  const base64 = await FileSystem.readAsStringAsync(imageUri, {
    encoding: FileSystem.EncodingType.Base64,
  });
  const bytes = base64ToUint8Array(base64);
  return previousUrl == null
    ? uploadProfilePictureBytes(userId, bytes)
    : uploadProfilePictureBytes(userId, bytes, { previousUrl });
};


const cleanUrl = (u?: string | null) => {
  if (!u) return null;
  const s = String(u);
  return s.split('?')[0];
};

const toPublicAvatarUrl = (value?: string | null): string | null => {
  const raw = String(value || '').trim();
  if (!raw) return null;
  if (/^https?:\/\//i.test(raw)) return cleanUrl(raw);

  const path = raw.replace(/^\/+/, '');
  if (!path) return null;
  const { data } = supabase.storage.from('uploads').getPublicUrl(path);
  return cleanUrl(data?.publicUrl ?? null);
};

// ✅ Backwards-compatible mediaTypes for expo-image-picker
const getImagePickerMediaTypes = () => {
  const anyPicker: any = ImagePicker;
  if (anyPicker?.MediaType?.Images) return anyPicker.MediaType.Images;
  if (anyPicker?.MediaType?.Image) return [anyPicker.MediaType.Image];
  if (anyPicker?.MediaTypeOptions?.Images) return anyPicker.MediaTypeOptions.Images;
  return anyPicker?.MediaTypeOptions?.All ?? undefined;
};

// ✅ Resolve the actual avatar file in storage so we don’t assume profile_picture.jpg exists
const resolveAvatarUrl = async (userId: string): Promise<string | null> => {
  try {
    const folders = [`${userId}`, `users/${userId}`];
    let resolvedPath: string | null = null;

    for (const folder of folders) {
      const { data: files, error } = await supabase.storage
        .from('uploads')
        .list(folder, {
          limit: 50,
          offset: 0,
          // sortBy exists in newer supabase-js; safe to ignore if unsupported
          // @ts-ignore
          sortBy: { column: 'updated_at', order: 'desc' },
        } as any);

      if (error || !files || files.length === 0) continue;

      // Prefer profile_picture* if present, else newest file
      const preferred =
        (files as any[]).find((f) => String(f?.name || '').toLowerCase().startsWith('profile_picture')) ??
        (files as any[])[0];

      if (!preferred?.name) continue;
      resolvedPath = `${folder}/${preferred.name}`;
      break;
    }

    if (!resolvedPath) return null;

    const { data: publicData } = supabase.storage.from('uploads').getPublicUrl(resolvedPath);
    const url = publicData?.publicUrl;

    if (!url) return null;

    return `${cleanUrl(url)}?v=${Date.now()}`;
  } catch {
    return null;
  }
};

export default function OwnerProfile() {
  const scrollPad = useOwnerScrollContentPadding(true);
  const { user, logout, deleteAccount, updateUser } = useAuth();
  const { showToast } = useToast();

  const [profileName, setProfileName] = useState<string>('');
  const [profileEmail, setProfileEmail] = useState<string>('');
  const [profilePicture, setProfilePicture] = useState<string | null>(null);
  const [uploadingPicture, setUploadingPicture] = useState(false);
  const [deletingAccount, setDeletingAccount] = useState(false);

  const [loading, setLoading] = useState(true);

  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const [savedAddressesSummary, setSavedAddressesSummary] = useState('Home, work & favourite spots');
  useFocusEffect(
    useCallback(() => {
      if (!user?.id) return;
      let cancelled = false;
      void loadCustomerSavedLocations(user.id).then((list) => {
        if (cancelled) return;
        if (list.length === 0) {
          setSavedAddressesSummary('Add home, work & favourite spots');
          return;
        }
        const names = list.slice(0, 3).map(savedLocationTitle).join(', ');
        setSavedAddressesSummary(list.length > 3 ? `${names} +${list.length - 3}` : names);
      });
      return () => {
        cancelled = true;
      };
    }, [user?.id])
  );

  // Fallback + cache
  const lastPickedUriRef = useRef<string | null>(null);
  const savedPublicUrlRef = useRef<string | null>(null);
  const lastFailedUrlRef = useRef<string | null>(null);

  const loadProfile = async (userId: string) => {
    try {
      // 1) Load profile data
      const { data: profileData, error } = await supabase
        .from('profiles')
        .select('full_name, profile_picture')
        .eq('id', userId)
        .maybeSingle();

      if (error) {
        console.warn('[profile] load error', error);
      }

      if (profileData) {
        setProfileName(profileData.full_name || user?.name || 'Customer');

        // 2) Always use the Supabase profile value first
        if (profileData.profile_picture) {
          const clean = toPublicAvatarUrl(profileData.profile_picture);
          if (clean) {
            setProfilePicture(`${clean}?v=${Date.now()}`);
            savedPublicUrlRef.current = clean;
          } else {
            setProfilePicture(null);
            savedPublicUrlRef.current = null;
          }
        } else {
          const resolved = await resolveAvatarUrl(userId);
          const clean = cleanUrl(resolved);
          if (clean) {
            setProfilePicture(`${clean}?v=${Date.now()}`);
            savedPublicUrlRef.current = clean;
          } else {
            setProfilePicture(null);
            savedPublicUrlRef.current = null;
          }
        }
      } else {
        setProfileName(user?.name || 'Customer');
        setProfilePicture(null);
        savedPublicUrlRef.current = null;
      }

      setProfileEmail(user?.email || '');
    } catch (err) {
      console.error('[profile] load error', err);
    }
  };

  useEffect(() => {
    if (!user?.id) return;

    const loadAll = async () => {
      setLoading(true);
      try {
        await loadProfile(user.id);
      } finally {
        setLoading(false);
      }
    };

    loadAll();
  }, [user?.id]);

  const handlePickImage = async () => {
    if (!user?.id) return;

    try {
      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted) {
        Alert.alert('Permission needed', 'Please allow photo library access.');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: getImagePickerMediaTypes(),
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      } as any);

      if ((result as any).canceled || !(result as any).assets?.[0]?.uri) return;

      const imageUri = (result as any).assets[0].uri as string;
      lastPickedUriRef.current = imageUri;
      setProfilePicture(imageUri);
      setUploadingPicture(true);

      // Upload to Supabase storage and persist URL on profile row.
      const previousUrl = savedPublicUrlRef.current ?? profilePicturePathFromUrl(profilePicture);
      const uploadedUrl = await uploadProfilePictureToSupabase(imageUri, user.id, previousUrl);
      const clean = cleanUrl(uploadedUrl);
      if (!clean) throw new Error('Could not resolve uploaded photo URL');

      const { error: profileError } = await supabase
        .from('profiles')
        .update({ profile_picture: clean })
        .eq('id', user.id);

      if (profileError) throw profileError;

      savedPublicUrlRef.current = clean;
      setProfilePicture(`${clean}?v=${Date.now()}`);
      lastPickedUriRef.current = null;

      // Best-effort context sync; profile row is already saved.
      if (updateUser) {
        try {
          await updateUser({ profilePicture: clean });
        } catch (syncErr) {
          console.warn('[profile] updateUser(profilePicture) failed:', syncErr);
        }
      }
    } catch (err: any) {
      console.error('[profile] image upload error', err);
      Alert.alert('Error', err?.message || 'Failed to upload profile picture');
      if (savedPublicUrlRef.current) {
        setProfilePicture(`${savedPublicUrlRef.current}?v=${Date.now()}`);
      }
    } finally {
      setUploadingPicture(false);
    }
  };


  const handleSaveProfile = async () => {
    if (!user?.id) return;

    try {
      setIsSaving(true);

      let avatarUrlClean = savedPublicUrlRef.current ?? cleanUrl(profilePicture);

      // Safety net in case a local URI is still pending.
      if (profilePicture && !String(profilePicture).startsWith('http')) {
        setUploadingPicture(true);
        const previousUrl = savedPublicUrlRef.current ?? profilePicturePathFromUrl(profilePicture);
        const uploadedUrl = await uploadProfilePictureToSupabase(profilePicture, user.id, previousUrl);
        avatarUrlClean = cleanUrl(uploadedUrl);
        savedPublicUrlRef.current = avatarUrlClean;
        if (avatarUrlClean) setProfilePicture(`${avatarUrlClean}?v=${Date.now()}`);

        setUploadingPicture(false);
      }

      // Update profile in profiles table (name + profile_picture)
      const updateData: { full_name: string; profile_picture?: string | null } = { 
        full_name: profileName,
      };
      if (avatarUrlClean?.startsWith('http')) updateData.profile_picture = avatarUrlClean;

      const { error: profileError } = await supabase.from('profiles').update(updateData).eq('id', user.id);
      if (profileError) throw profileError;

      // Update email if changed (requires auth update)
      if (profileEmail !== user.email) {
        const { error: emailError } = await supabase.auth.updateUser({ email: profileEmail });
        if (emailError) {
          Alert.alert('Email Update', 'Email verification sent to new email address. Please check your inbox.', [{ text: 'OK' }]);
        }
      }

      // Best-effort context sync; DB/auth updates above are source of truth.
      if (updateUser) {
        try {
          await updateUser({
            name: profileName,
            email: profileEmail,
            ...(avatarUrlClean?.startsWith('http') && { profilePicture: avatarUrlClean }),
          });
        } catch (syncErr) {
          console.warn('[profile] updateUser(save) failed:', syncErr);
        }
      }

      setIsEditing(false);
      showToast('Profile updated successfully!', 'success');
    } catch (error: any) {
      console.error('Error saving profile:', error);
      Alert.alert('Error', error?.message || 'Failed to save profile');
    } finally {
      setIsSaving(false);
      setUploadingPicture(false);
    }
  };

  const handleCancel = async () => {
    setProfileName(user?.name || '');
    setProfileEmail(user?.email || '');
    setIsEditing(false);

    // Reload from DB/storage to restore saved avatar and display name
    if (user?.id) {
      await loadProfile(user.id);
    }
  };

  const handleLogout = async () => {
    await logout();
    router.replace('/auth/login');
  };

  const handleDeleteAccount = () => {
    Alert.alert(
      'Delete account?',
      'This will permanently delete your account, profile data, saved vehicles, favourites, bookings, messages, and device tokens where possible. This cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete account',
          style: 'destructive',
          onPress: async () => {
            try {
              setDeletingAccount(true);
              const ok = await deleteAccount();
              if (!ok) {
                Alert.alert('Delete failed', 'We could not delete your account right now. Please try again.');
                return;
              }
              router.replace('/auth/login');
            } finally {
              setDeletingAccount(false);
            }
          },
        },
      ]
    );
  };

  const renderProfileImageContent = () => {
    if (uploadingPicture) {
      return (
        <View style={styles.profilePicturePlaceholder}>
          <ActivityIndicator size="large" color={SKY} />
        </View>
      );
    }
    if (profilePicture) {
      return (
        <Image
          source={{ uri: profilePicture }}
          style={[styles.profilePicture, uploadingPicture && { opacity: 0.6 }]}
          onError={async () => {
            const failedClean = cleanUrl(profilePicture);
            if (lastFailedUrlRef.current !== failedClean) {
              lastFailedUrlRef.current = failedClean;
              if (__DEV__) {
                console.warn('[profile] avatar image failed to load, using placeholder');
              }
            }
            if (lastPickedUriRef.current) {
              setProfilePicture(lastPickedUriRef.current);
              return;
            }
            if (user?.id) {
              const resolved = await resolveAvatarUrl(user.id);
              const resolvedClean = cleanUrl(resolved);
              if (resolvedClean && resolvedClean !== failedClean) {
                setProfilePicture(resolved);
                return;
              }
            }
            setProfilePicture(null);
          }}
        />
      );
    }
    return (
      <View style={styles.profilePicturePlaceholder}>
        <GradientIconBox icon="person" preset="sky" boxSize={94} size={44} borderRadius={47} elevated />
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <AppHeader
        title="Profile"
        variant="dashboard"
        accountType="customer"
        fullWidth
        rightAction={
          !loading ? (
            <TouchableOpacity
              onPress={() => {
                if (isEditing) handleCancel();
                else setIsEditing(true);
              }}
              style={styles.editButton}
              hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
              accessibilityRole="button"
              accessibilityLabel={isEditing ? 'Cancel editing profile' : 'Edit profile'}
            >
              <Ionicons
                name={isEditing ? 'close' : 'pencil'}
                size={22}
                color="#60A5FA"
              />
            </TouchableOpacity>
          ) : undefined
        }
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingHorizontal: isSmallScreen ? 12 : 20, paddingTop: (scrollPad.paddingTop ?? 0) + 16, paddingBottom: scrollPad.paddingBottom },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {loading ? (
          <View style={styles.profileLoadingWrap}>
            <SkeletonList count={7} />
          </View>
        ) : (
          <>
        {/* Profile Picture Section */}
        <View style={styles.profileSection}>
          <TouchableOpacity
            onPress={handlePickImage}
            style={styles.profilePictureContainer}
            disabled={uploadingPicture}
            activeOpacity={0.85}
            accessibilityRole="button"
            accessibilityLabel="Profile photo. Tap to change picture"
          >
            {renderProfileImageContent()}

            {!uploadingPicture && (
              <View style={styles.editBadge}>
                <Ionicons name="camera" size={14} color={BG} />
              </View>
            )}
          </TouchableOpacity>

          {isEditing ? (
            <>
              <TextInput
              style={styles.profileNameInput}
              value={profileName}
              onChangeText={setProfileName}
              placeholder="Enter your name"
              placeholderTextColor="#64748B"
            />
              <TextInput
                style={styles.profileEmailInput}
                value={profileEmail}
                onChangeText={setProfileEmail}
                placeholder="Enter your email"
                placeholderTextColor="#64748B"
                keyboardType="email-address"
                autoCapitalize="none"
              />
            </>
          ) : (
            <>
              <Text style={styles.profileName}>{formatDisplayName(profileName)}</Text>
              <Text style={styles.profileEmail}>{profileEmail}</Text>
            </>
          )}
        </View>

        {/* Menu Items */}
        <View style={styles.menuSection}>
          <TouchableOpacity
            style={styles.menuItem}
            onPress={() => router.push('/owner/settings/appearance')}
            accessibilityRole="button"
            accessibilityLabel="Appearance. Theme and legal"
          >
            <View style={styles.menuIconWrapper}>
              <GradientIconBox icon="color-palette-outline" preset="sky" boxSize={36} size={18} elevated />
            </View>
            <View style={styles.menuContent}>
              <Text style={styles.menuTitle}>Appearance</Text>
              <Text style={styles.menuSubtitle}>Light & dark mode, legal</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="rgba(148,163,184,0.75)" />
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.menuItem, styles.menuItemDivider]}
            onPress={() => router.push('/owner/features/referral-system')}
            accessibilityRole="button"
            accessibilityLabel="Referrals. Invite friends and earn rewards"
          >
            <View style={styles.menuIconWrapper}>
              <GradientIconBox icon="people" preset="purple" boxSize={36} size={18} elevated />
            </View>
            <View style={styles.menuContent}>
              <Text style={styles.menuTitle}>Referrals</Text>
              <Text style={styles.menuSubtitle}>Invite friends, earn rewards</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="rgba(148,163,184,0.75)" />
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.menuItem, styles.menuItemDivider]}
            onPress={() => router.push('/owner/features/rewards')}
            accessibilityRole="button"
            accessibilityLabel="Rewards. Points, tiers and perks"
          >
            <View style={styles.menuIconWrapper}>
              <GradientIconBox icon="gift" preset="amber" boxSize={36} size={18} elevated />
            </View>
            <View style={styles.menuContent}>
              <Text style={styles.menuTitle}>Rewards</Text>
              <Text style={styles.menuSubtitle}>Points, tiers & perks</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="rgba(148,163,184,0.75)" />
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.menuItem, styles.menuItemDivider]}
            onPress={() => router.push('/owner/settings/vehicle-management')}
            accessibilityRole="button"
            accessibilityLabel="My vehicles. Manage your vehicles"
          >
            <View style={styles.menuIconWrapper}>
              <GradientIconBox icon="car" preset="blue" boxSize={36} size={18} elevated />
            </View>
            <View style={styles.menuContent}>
              <Text style={styles.menuTitle}>My Vehicles</Text>
              <Text style={styles.menuSubtitle}>Manage your vehicles</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="rgba(148,163,184,0.75)" />
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.menuItem, styles.menuItemDivider]}
            onPress={() => router.push('/owner/settings/saved-locations' as any)}
            accessibilityRole="button"
            accessibilityLabel={`Saved addresses. ${savedAddressesSummary}`}
          >
            <View style={styles.menuIconWrapper}>
              <GradientIconBox icon="home" preset="teal" boxSize={36} size={18} elevated />
            </View>
            <View style={styles.menuContent}>
              <Text style={styles.menuTitle}>Saved Addresses</Text>
              <Text style={styles.menuSubtitle} numberOfLines={1}>{savedAddressesSummary}</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="rgba(148,163,184,0.75)" />
          </TouchableOpacity>

        </View>

        {/* Save Button */}
        {isEditing && (
          <TouchableOpacity style={styles.saveButton} onPress={handleSaveProfile} disabled={isSaving} activeOpacity={0.85}>
            <GlassFill fillStyle={styles.saveFill} />
            {isSaving ? (
              <ActivityIndicator size="small" color="#FFFFFF" />
            ) : (
              <>
                <Ionicons name="checkmark" size={18} color="#FFFFFF" />
                <Text style={styles.saveText}>Save Changes</Text>
              </>
            )}
          </TouchableOpacity>
        )}

        {/* Logout Button */}
        <TouchableOpacity style={styles.logoutButton} onPress={handleLogout} activeOpacity={0.85}>
          <GlassFill fillStyle={styles.logoutFill} />
          <Ionicons name="log-out" size={18} color="#FFFFFF" />
          <Text style={styles.logoutText}>Sign Out</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.deleteButton}
          onPress={handleDeleteAccount}
          disabled={deletingAccount}
          accessibilityRole="button"
          accessibilityLabel="Delete account"
        >
          {deletingAccount ? (
            <ActivityIndicator size="small" color="#FCA5A5" />
          ) : (
            <>
              <Ionicons name="trash-outline" size={18} color="#FCA5A5" />
              <Text style={styles.deleteText}>Delete Account</Text>
            </>
          )}
        </TouchableOpacity>
          </>
        )}
      </ScrollView>

    </SafeAreaView>
  );
}

function GlassFill({ fillStyle }: Readonly<{ fillStyle: StyleProp<ViewStyle> }>) {
  return (
    <>
      <BlurView intensity={30} tint="dark" style={StyleSheet.absoluteFill} />
      <View style={[StyleSheet.absoluteFill, fillStyle]} />
      <LinearGradient
        colors={['rgba(255,255,255,0.2)', 'rgba(255,255,255,0)']}
        style={styles.glassSheen}
        pointerEvents="none"
      />
    </>
  );
}

// styles
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 120, paddingHorizontal: isSmallScreen ? 12 : 20 },
  profileLoadingWrap: { paddingTop: 12 },

  editButton: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },

  profileSection: { alignItems: 'center', marginBottom: 32, marginTop: 20 },
  profilePictureContainer: { position: 'relative', marginBottom: 16 },
  profilePicture: { width: 100, height: 100, borderRadius: 30, borderWidth: 1, borderColor: SKY },
  profilePicturePlaceholder: {
    width: 100,
    height: 100,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: SKY,
  },
  editBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 32,
    height: 32,
    borderRadius: 10,
    backgroundColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2.5,
    borderColor: BG,
  },

  profileName: { color: '#F8FAFC', fontSize: isSmallScreen ? 20 : 22, fontWeight: '800', letterSpacing: -0.4, marginBottom: 4 },
  profileEmail: { color: 'rgba(226,232,240,0.7)', fontSize: 14, fontWeight: '500' },

  profileNameInput: {
    color: '#F8FAFC',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: '800',
    marginBottom: 8,
    textAlign: 'center',
    backgroundColor: 'rgba(148,163,184,0.12)',
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 10,
    minWidth: 220,
  },
  profileEmailInput: {
    color: '#F8FAFC',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
    backgroundColor: 'rgba(148,163,184,0.12)',
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 10,
    minWidth: 220,
  },

  glassSheen: { position: 'absolute', left: 0, right: 0, top: 0, height: 24 },

  saveButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    height: 48,
    borderRadius: 24,
    overflow: 'hidden',
    marginBottom: 12,
  },
  saveFill: { backgroundColor: 'rgba(56,189,248,0.45)' },
  saveText: { color: '#FFFFFF', fontSize: 15, fontWeight: '700' },

  menuSection: {
    marginBottom: 28,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 20,
    overflow: 'hidden',
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 13,
    paddingHorizontal: 14,
  },
  menuItemDivider: {
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(255,255,255,0.12)',
  },

  menuIconWrapper: {
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  menuContent: { flex: 1 },
  menuTitle: { color: '#F8FAFC', fontSize: 15, fontWeight: '700', marginBottom: 2 },
  menuSubtitle: { color: 'rgba(226,232,240,0.7)', fontSize: 12, fontWeight: '500' },

  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    height: 48,
    borderRadius: 24,
    overflow: 'hidden',
    marginBottom: 10,
  },
  logoutFill: { backgroundColor: 'rgba(239,68,68,0.32)' },
  logoutText: { color: '#FFFFFF', fontSize: 15, fontWeight: '700' },

  deleteButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    height: 44,
    marginBottom: 28,
  },
  deleteText: { color: '#FCA5A5', fontSize: 14, fontWeight: '700' },
});
