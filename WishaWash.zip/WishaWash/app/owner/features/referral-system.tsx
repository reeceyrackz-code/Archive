import { useCallback, useEffect, useMemo, useState } from 'react';
import { StyleSheet, Share, Alert, Platform, ScrollView, Pressable } from 'react-native';
import * as Clipboard from 'expo-clipboard';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { router, useLocalSearchParams } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import AppHeader from '../../../src/components/shared/AppHeader';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { useOwnerScrollContentPadding } from '../../../src/hooks/useOwnerScrollContentPadding';
import { SPACING } from '../../../src/constants/designTokens';
import {
  getReferralSummary,
  generateReferralCode,
  applyReferralCodeToUser,
} from '../../../src/services/LoyaltyService';
import {
  buildReferralJoinLink,
  buildReferralShareMessage,
} from '../../../src/utils/referralLinks';
import ReferralInviteTicket from '../../../src/components/referrals/ReferralInviteTicket';
import MilestoneRoad, { roadPosition, type MilestoneStop } from '../../../src/components/road/MilestoneRoad';
import { REFERRAL_TIERS } from '../../../src/utils/referralTier';

const TIER_THRESHOLDS = REFERRAL_TIERS.map((t) => t.min);
const TIER_TONES = ['sky', 'gold', 'pink', 'violet', 'green'] as const;

function ownerWord(n: number) {
  return n === 1 ? 'owner' : 'owners';
}

export default function ReferralSystem() {
  const params = useLocalSearchParams<{ enterCode?: string }>();
  const scrollPad = useOwnerScrollContentPadding(true);
  const { user } = useAuth();

  const [loading, setLoading] = useState(true);
  const [referralCode, setReferralCode] = useState(user?.id ? generateReferralCode(user.id) : 'WAW-00000000');
  const [hasAppliedReferral, setHasAppliedReferral] = useState(false);
  const [entryCode, setEntryCode] = useState('');
  const [applyingEntryCode, setApplyingEntryCode] = useState(false);
  const [referralStatuses, setReferralStatuses] = useState<string[]>([]);

  const rewardedReferralCount = useMemo(
    () => referralStatuses.filter((status) => status === 'rewarded').length,
    [referralStatuses],
  );

  const loadReferrals = useCallback(async () => {
    if (!user?.id) {
      setReferralStatuses([]);
      setLoading(false);
      setReferralCode('WAW-00000000');
      setHasAppliedReferral(false);
      return;
    }

    try {
      const summary = await getReferralSummary(user.id);
      setReferralCode(summary.referralCode);
      setHasAppliedReferral(summary.referredBy);
      setReferralStatuses(summary.referrals.map((row) => row.status));
    } catch (err) {
      console.warn('[Referral] load failed:', err);
      setReferralStatuses([]);
    } finally {
      setLoading(false);
    }
  }, [user?.id]);

  useEffect(() => {
    void loadReferrals();
  }, [loadReferrals]);

  useEffect(() => {
    const incoming = typeof params.enterCode === 'string' ? params.enterCode.trim().toUpperCase() : '';
    if (incoming) setEntryCode(incoming);
  }, [params.enterCode]);

  const handleShare = async () => {
    try {
      await hapticFeedback('light');
      const message = buildReferralShareMessage(referralCode);
      const link = buildReferralJoinLink(referralCode);
      await Share.share(
        Platform.OS === 'ios'
          ? { message, url: link }
          : { message, title: 'Join Wish a Wash' },
      );
    } catch (err) {
      console.warn('[Referral] Share failed:', err);
      Alert.alert('Error', 'Unable to share referral code');
    }
  };

  const handleCopy = () => {
    const link = buildReferralJoinLink(referralCode);
    void Clipboard.setStringAsync(`${referralCode}\n${link}`);
  };

  const handleApplyEntryCode = async () => {
    if (!user?.id) {
      router.push({ pathname: '/auth/signup', params: { referralCode: entryCode.trim() } });
      return;
    }
    const normalized = entryCode.trim().toUpperCase();
    if (!normalized) {
      Alert.alert('Enter a code', "Paste or type your friend's referral code.");
      return;
    }
    if (normalized === referralCode.trim().toUpperCase()) {
      Alert.alert("That's your code", "Enter a friend's referral code, not your own.");
      return;
    }
    if (hasAppliedReferral) {
      Alert.alert('Already applied', "You've already used a referral code on this account.");
      return;
    }

    try {
      setApplyingEntryCode(true);
      await hapticFeedback('light');
      const applied = await applyReferralCodeToUser(user.id, normalized);
      if (applied) {
        setHasAppliedReferral(true);
        setEntryCode('');
        Alert.alert('Code applied', 'Your referral code is saved. Complete your first booking to unlock rewards.');
        void loadReferrals();
      } else {
        Alert.alert('Invalid code', "We couldn't find that referral code. Check it and try again.");
      }
    } catch (err) {
      console.warn('[Referral] apply entry failed:', err);
      Alert.alert('Error', 'Unable to apply referral code right now.');
    } finally {
      setApplyingEntryCode(false);
    }
  };

  const firstLocked = REFERRAL_TIERS.findIndex((t) => rewardedReferralCount < t.min);
  const roadStops: MilestoneStop[] = REFERRAL_TIERS.map((tier, i) => {
    const reached = rewardedReferralCount >= tier.min;
    const toGo = tier.min - rewardedReferralCount;
    return {
      key: tier.name,
      label: tier.min === 0 ? 'Start' : `${tier.min} ${ownerWord(tier.min)}`,
      title: tier.name,
      subtitle: tier.subtitle,
      icon: tier.icon as MilestoneStop['icon'],
      tone: TIER_TONES[i % TIER_TONES.length]!,
      reached,
      status: reached ? 'Unlocked' : `${toGo} more ${ownerWord(toGo)} to go`,
      ...(i === firstLocked
        ? { action: { label: 'Invite', icon: 'share-outline' as const, onPress: () => void handleShare() } }
        : {}),
    };
  });

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <AppHeader
        title="Referrals"
        showBack
        fullWidth
        onBack={() => {
          void hapticFeedback('light');
          router.back();
        }}
        accountType="customer"
        rightAction={
          <Pressable onPress={() => void handleShare()} style={styles.headerShareBtn} hitSlop={8} accessibilityRole="button" accessibilityLabel="Share invite">
            <Ionicons name="share-social" size={20} color="#6EE7B7" />
          </Pressable>
        }
      />

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={[styles.content, scrollPad]}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        automaticallyAdjustKeyboardInsets
      >
        <Animated.View entering={FadeInDown.delay(60).springify().damping(18)}>
          <MilestoneRoad
            kicker="REFERRAL ROAD"
            stops={roadStops}
            position={roadPosition(TIER_THRESHOLDS, rewardedReferralCount)}
            ready={!loading}
          />
        </Animated.View>

        <Animated.View entering={FadeInDown.delay(120).springify().damping(18)}>
          <ReferralInviteTicket
            referralCode={referralCode}
            onCopy={handleCopy}
            entryCode={entryCode}
            onChangeEntryCode={setEntryCode}
            onApply={() => void handleApplyEntryCode()}
            applying={applyingEntryCode}
            hasApplied={hasAppliedReferral}
            ready={!loading}
          />
        </Animated.View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  scroll: { flex: 1 },
  content: {
    flexGrow: 1,
    paddingHorizontal: SPACING.xl,
    gap: 14,
  },
  headerShareBtn: {
    width: 44,
    height: 44,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
