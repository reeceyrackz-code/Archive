import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Alert,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LinearGradient } from 'expo-linear-gradient';
import Reanimated, {
  css,
  FadeIn,
  FadeInDown,
  FadeOutLeft,
  LinearTransition,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from 'react-native-reanimated';

import HubGlassIcon, { HUB_GLASS_PALETTES, type HubGlassTone } from '../../../src/components/shared/HubGlassIcon';
import StatusBadge from '../../../src/components/booking/StatusBadge';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import AppHeader from '../../../src/components/shared/AppHeader';
import { useOwnerScrollContentPadding } from '../../../src/hooks/useOwnerScrollContentPadding';
import { SkeletonList } from '../../../src/components/shared/SkeletonLoader';
import GradientNotificationBell from '../../../src/components/shared/GradientNotificationBell';
import LivelyEmptyState, { type LivelyEmptyAction } from '../../../src/components/shared/LivelyEmptyState';
import { colors } from '../../../src/constants/colors';
import { CCP, ccpSingularLower } from '../../../src/constants/carCareProLabels';
import { FONT_SIZES, SPACING } from '../../../src/constants/designTokens';
import { fetchUnreadBookingChatThreads } from '../../../src/services/BookingChatService';

const SKY = colors.SKY;
const DISMISSED_STORAGE_KEY = 'wishawash:dismissed-notifications-v1';

// Include all booking statuses that should show notifications
const NOTIFICATION_STATUSES = [
  'pending',
  'pending_valeter_acceptance',
  'pending_payment',
  'confirmed',
  'valeter_assigned',
  'en_route',
  'arrived',
  'in_progress',
  'scheduled',
  'completed',
  'cancelled',
] as const;

const TRACKABLE_STATUSES = new Set(['confirmed', 'valeter_assigned', 'en_route', 'arrived', 'in_progress']);
const WAITING_STATUSES = new Set([
  'pending',
  'pending_business_acceptance',
  'pending_valeter_acceptance',
  'scheduled',
]);

type NotificationType = 
  | 'booking'
  | 'chat'
  | 'vehicle_reminder'
  | 'reward'
  | 'payment'
  | 'document'
  | 'system'
  | 'referral';

function notificationIconSolid(type: NotificationType): keyof typeof Ionicons.glyphMap {
  switch (type) {
    case 'booking':
      return 'car';
    case 'chat':
      return 'chatbubbles';
    case 'vehicle_reminder':
      return 'warning';
    case 'reward':
      return 'gift';
    case 'payment':
      return 'card';
    case 'document':
      return 'document-text';
    case 'referral':
      return 'people';
    case 'system':
    default:
      return 'notifications';
  }
}

type UnifiedNotification = {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  createdAt: string;
  priority: 'low' | 'medium' | 'high';
  // Booking-specific
  bookingId?: string;
  status?: string;
  serviceName?: string;
  scheduledAt?: string | null;
  timeSlot?: string | null;
  price?: number | null;
  address?: string | null;
  valeterName?: string | null;
  // Vehicle reminder-specific
  vehicleId?: string;
  vehicleMake?: string;
  vehicleModel?: string;
  reminderType?: 'tax' | 'mot';
  expiryDate?: string;
  daysRemaining?: number;
  // Reward-specific
  rewardTitle?: string;
  points?: number;
  chatUnreadCount?: number;
  chatPreview?: string;
  // Payment-specific
  paymentAmount?: number;
  paymentStatus?: string;
  // Document-specific
  documentType?: string;
  documentStatus?: string;
  // Action route
  actionRoute?: string;
  actionParams?: Record<string, string>;
};

type DismissedStore = Record<string, string[]>;

export default function NotificationsCentre() {
  const scrollPad = useOwnerScrollContentPadding(true);
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [allNotifications, setAllNotifications] = useState<UnifiedNotification[]>([]);
  const [visibleNotifications, setVisibleNotifications] = useState<UnifiedNotification[]>([]);
  const [dismissedIds, setDismissedIds] = useState<Set<string>>(new Set());
  const [activeFilter, setActiveFilter] = useState<FilterKey>('all');
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);

  const loadDismissed = useCallback(async () => {
    if (!user?.id) return;
    try {
      const raw = await AsyncStorage.getItem(DISMISSED_STORAGE_KEY);
      if (!raw) {
        setDismissedIds(new Set());
        return;
      }
      const parsed = JSON.parse(raw) as DismissedStore;
      const ids = parsed?.[user.id] ?? [];
      setDismissedIds(new Set(ids));
    } catch (error) {
      console.warn('[Notifications] failed to read dismissed list', error);
      setDismissedIds(new Set());
    }
  }, [user?.id]);

  const persistDismissed = useCallback(
    async (next: Set<string>) => {
      if (!user?.id) return;
      try {
        const raw = await AsyncStorage.getItem(DISMISSED_STORAGE_KEY);
        const parsed = raw ? (JSON.parse(raw) as DismissedStore) : {};
        parsed[user.id] = Array.from(next);
        await AsyncStorage.setItem(DISMISSED_STORAGE_KEY, JSON.stringify(parsed));
      } catch (error) {
        console.warn('[Notifications] failed to persist dismissed list', error);
      }
    },
    [user?.id]
  );

  const mapBookingToNotification = (row: any): UnifiedNotification => {
    const status = row.status ?? 'pending';
    const serviceName = row.service_name ?? row.service_type ?? 'Car wash';

    let title: string;
    let message: string;
    let priority: 'low' | 'medium' | 'high' = 'medium';

    switch (status) {
      case 'pending':
      case 'pending_valeter_acceptance':
        title = `Connecting to your ${ccpSingularLower()}`;
        message = `We're connecting you with a ${ccpSingularLower()} for your ${serviceName} booking`;
        priority = 'high';
        break;
      case 'pending_payment':
        title = 'Payment Required';
        message = `Complete payment for your ${serviceName} booking`;
        priority = 'high';
        break;
      case 'confirmed':
      case 'valeter_assigned':
        title = `${CCP.singularShort} assigned`;
        message = `A ${ccpSingularLower()} has been assigned to your ${serviceName} booking`;
        priority = 'high';
        break;
      case 'en_route':
        title = `${CCP.singularShort} on the way`;
        message = `Your ${ccpSingularLower()} is en route to your location`;
        priority = 'high';
        break;
      case 'arrived':
        title = `${CCP.singularShort} arrived`;
        message = `Your ${ccpSingularLower()} has arrived at your location`;
        priority = 'high';
        break;
      case 'in_progress':
        title = 'Service In Progress';
        message = `Your ${serviceName} is currently being performed`;
        break;
      case 'completed':
        title = 'Service Completed';
        message = `Your ${serviceName} has been completed. Please rate your experience`;
        break;
      case 'cancelled':
        title = 'Booking Cancelled';
        message = `Your ${serviceName} booking has been cancelled`;
        priority = 'low';
        break;
      case 'scheduled':
        title = 'Booking Scheduled';
        message = `Your ${serviceName} is scheduled for ${row.scheduled_at ? new Date(row.scheduled_at).toLocaleDateString('en-GB') : 'later'}`;
        break;
      default:
        title = serviceName;
        message = `Update on your ${serviceName} booking`;
    }

    return {
      id: `booking-${row.id}`,
      type: 'booking',
      title,
      message,
      createdAt: row.created_at || row.updated_at || new Date().toISOString(),
      priority,
      bookingId: String(row.id),
      status,
      serviceName,
      scheduledAt: row.scheduled_at,
      timeSlot: row.time_slot,
      price: row.price,
      address: row.location_address ?? row.address ?? null,
      valeterName: row.valeter_name ?? null,
      actionRoute: (() => {
        if (WAITING_STATUSES.has(status)) return '/owner/track';
        if (status === 'pending_payment') return '/owner/track';
        if (TRACKABLE_STATUSES.has(status)) return '/owner/track';
        return '/owner/wash-history';
      })(),
      actionParams: status === 'completed' 
        ? { highlightId: String(row.id) }
        : { bookingId: String(row.id) },
    };
  };

  const mapChatThreadToNotification = (thread: Awaited<ReturnType<typeof fetchUnreadBookingChatThreads>>[number]): UnifiedNotification => {
    const serviceName = thread.serviceName ?? thread.serviceType ?? 'Booking';
    const unreadLabel = thread.unreadCount === 1 ? '1 new message' : `${thread.unreadCount} new messages`;
    const valeterLabel = thread.valeterName ? `from ${thread.valeterName}` : 'from your pro';

    const notification: UnifiedNotification = {
      id: `chat-${thread.bookingId}`,
      type: 'chat',
      title: unreadLabel,
      message: `${serviceName} ${valeterLabel} · ${thread.latestMessagePreview}`,
      createdAt: thread.latestMessageAt,
      priority: thread.unreadCount > 2 ? 'high' : 'medium',
      bookingId: thread.bookingId,
      serviceName,
      scheduledAt: thread.scheduledAt,
      timeSlot: thread.timeSlot,
      address: thread.address ?? thread.locationAddress ?? null,
      valeterName: thread.valeterName ?? null,
      chatUnreadCount: thread.unreadCount,
      chatPreview: thread.latestMessagePreview,
      actionRoute: '/owner/booking/chat',
      actionParams: { bookingId: thread.bookingId },
    };

    if (thread.bookingStatus) {
      notification.status = thread.bookingStatus;
    }

    return notification;
  };

  const fetchVehicleReminders = useCallback(async (userId: string): Promise<UnifiedNotification[]> => {
    try {
      const { data: vehicles, error } = await supabase
        .from('customer_vehicles')
        .select('id,make,model,registration,tax_due_date,mot_expiry_date')
        .eq('user_id', userId);

      if (error || !vehicles) return [];

      const reminders: UnifiedNotification[] = [];
      const now = new Date();
      const thirtyDaysFromNow = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

      vehicles.forEach((vehicle) => {
        // Tax reminder
        if (vehicle.tax_due_date) {
          const taxExpiry = new Date(vehicle.tax_due_date);
          const daysRemaining = Math.ceil((taxExpiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
          if (taxExpiry <= thirtyDaysFromNow) {
            const dayLabel = daysRemaining === 1 ? '' : 's';
            const expired = daysRemaining <= 0;
            reminders.push({
              id: `tax-reminder-${vehicle.id}`,
              type: 'vehicle_reminder',
              title: expired ? 'Vehicle Tax Expired' : 'Vehicle Tax Expiring Soon',
              message: expired
                ? `${vehicle.make} ${vehicle.model} (${vehicle.registration}) tax has expired.`
                : `${vehicle.make} ${vehicle.model} (${vehicle.registration}) tax expires in ${daysRemaining} day${dayLabel}`,
              createdAt: now.toISOString(),
              priority: (() => {
                if (expired) return 'high';
                if (daysRemaining <= 7) return 'high';
                if (daysRemaining <= 14) return 'medium';
                return 'low';
              })(),
              vehicleId: vehicle.id,
              vehicleMake: vehicle.make,
              vehicleModel: vehicle.model,
              reminderType: 'tax',
              expiryDate: vehicle.tax_due_date,
              daysRemaining,
              actionRoute: '/owner/settings/vehicle-management',
            });
          }
        }

        // MOT reminder
        if (vehicle.mot_expiry_date) {
          const motExpiry = new Date(vehicle.mot_expiry_date);
          const daysRemaining = Math.ceil((motExpiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
          if (motExpiry <= thirtyDaysFromNow) {
            const dayLabel = daysRemaining === 1 ? '' : 's';
            const expired = daysRemaining <= 0;
            reminders.push({
              id: `mot-reminder-${vehicle.id}`,
              type: 'vehicle_reminder',
              title: expired ? 'MOT Expired' : 'MOT Expiring Soon',
              message: expired
                ? `${vehicle.make} ${vehicle.model} (${vehicle.registration}) MOT has expired.`
                : `${vehicle.make} ${vehicle.model} (${vehicle.registration}) MOT expires in ${daysRemaining} day${dayLabel}`,
              createdAt: now.toISOString(),
              priority: (() => {
                if (expired) return 'high';
                if (daysRemaining <= 7) return 'high';
                if (daysRemaining <= 14) return 'medium';
                return 'low';
              })(),
              vehicleId: vehicle.id,
              vehicleMake: vehicle.make,
              vehicleModel: vehicle.model,
              reminderType: 'mot',
              expiryDate: vehicle.mot_expiry_date,
              daysRemaining,
              actionRoute: '/owner/settings/vehicle-management',
            });
          }
        }
      });

      return reminders;
    } catch (error) {
      console.warn('[Notifications] vehicle reminders error', error);
      return [];
    }
  }, []);

  const fetchRewardNotifications = useCallback(async (userId: string): Promise<UnifiedNotification[]> => {
    try {
      // Check user's reward points and tier
      const { data: userData, error } = await supabase
        .from('users')
        .select('tier_points,tier')
        .eq('id', userId)
        .single();

      if (error || !userData) return [];

      const notifications: UnifiedNotification[] = [];
      const points = userData.tier_points || 0;

      // Check for milestone rewards
      const milestones = [500, 1000, 2000, 3000, 5000];
      const nextMilestone = milestones.find(m => m > points);
      
      if (nextMilestone && points > 0) {
        const pointsNeeded = nextMilestone - points;
        if (pointsNeeded <= 100) {
          notifications.push({
            id: `reward-milestone-${nextMilestone}`,
            type: 'reward',
            title: 'Reward Milestone Approaching',
            message: `You're ${pointsNeeded} points away from unlocking a new reward!`,
            createdAt: new Date().toISOString(),
            priority: 'medium',
            points: nextMilestone,
            actionRoute: '/owner/features/rewards',
          });
        }
      }

      return notifications;
    } catch (error) {
      console.warn('[Notifications] reward notifications error', error);
      return [];
    }
  }, []);

  const fetchNotifications = useCallback(async () => {
    if (!user?.id) {
      setAllNotifications([]);
      setVisibleNotifications([]);
      setLoading(false);
      setRefreshing(false);
      return;
    }

    try {
      if (!refreshing) {
        setLoading(true);
      }

      // Fetch from all sources in parallel
      const [bookingsResult, chatThreads, vehicleReminders, rewardNotifications] = await Promise.all([
        supabase
          .from('bookings')
          .select(
            'id,status,service_name,service_type,price,created_at,updated_at,scheduled_at,time_slot,location_address,address,valeter_name'
          )
          .eq('user_id', user.id)
          .in('status', NOTIFICATION_STATUSES as any)
          .order('created_at', { ascending: false })
          .limit(100),
        fetchUnreadBookingChatThreads(user.id),
        fetchVehicleReminders(user.id),
        fetchRewardNotifications(user.id),
      ]);

      const bookingNotifications = (bookingsResult.data && !bookingsResult.error)
        ? bookingsResult.data.map(mapBookingToNotification)
        : [];
      const chatNotifications = chatThreads.map(mapChatThreadToNotification);
      const notifications: UnifiedNotification[] = [
        ...bookingNotifications,
        ...chatNotifications,
        ...vehicleReminders,
        ...rewardNotifications,
      ];

      // Sort by priority and date (high priority first, then by date)
      notifications.sort((a, b) => {
        const priorityOrder = { high: 3, medium: 2, low: 1 };
        const priorityDiff = priorityOrder[b.priority] - priorityOrder[a.priority];
        if (priorityDiff !== 0) return priorityDiff;
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      });

      setAllNotifications(notifications);
      
      // Debug logging
      if (notifications.length > 0) {
        console.log('[Notifications] Fetched notifications:', {
          total: notifications.length,
          bookingCount: bookingsResult.data?.length || 0,
          chatCount: chatNotifications.length,
          vehicleCount: vehicleReminders.length,
          rewardCount: rewardNotifications.length,
        });
      }
    } catch (error) {
      console.warn('[Notifications] unexpected load error', error);
      setAllNotifications([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [refreshing, user?.id, fetchVehicleReminders, fetchRewardNotifications]);

  const attachRealtime = useCallback(() => {
    if (!user?.id) return;
    if (channelRef.current) {
      supabase.removeChannel(channelRef.current);
      channelRef.current = null;
    }
    const channel = supabase
      .channel(`notifications-centre-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'bookings',
          filter: `user_id=eq.${user.id}`,
        },
        () => {
          fetchNotifications();
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'booking_messages',
        },
        () => {
          fetchNotifications();
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'customer_vehicles',
          filter: `user_id=eq.${user.id}`,
        },
        () => {
          fetchNotifications();
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'users',
          filter: `id=eq.${user.id}`,
        },
        () => {
          fetchNotifications();
        }
      )
      .subscribe();
    channelRef.current = channel;
  }, [fetchNotifications, user?.id]);

  useEffect(() => {
    loadDismissed();
  }, [loadDismissed]);

  useEffect(() => {
    fetchNotifications();
  }, [fetchNotifications]);

  useEffect(() => {
    attachRealtime();
    return () => {
      if (channelRef.current) {
        supabase.removeChannel(channelRef.current);
        channelRef.current = null;
      }
    };
  }, [attachRealtime]);

  useEffect(() => {
    const visible = allNotifications.filter((notification) => !dismissedIds.has(notification.id));
    setVisibleNotifications(visible);
    
    // Debug logging
    if (allNotifications.length > 0 || visible.length !== allNotifications.length) {
      console.log('[Notifications] Visible notifications:', {
        total: allNotifications.length,
        dismissed: dismissedIds.size,
        visible: visible.length,
      });
    }
  }, [allNotifications, dismissedIds]);

  const handleDismiss = useCallback(
    async (notificationId: string) => {
      await hapticFeedback('light');
      setVisibleNotifications((prev) => prev.filter((notification) => notification.id !== notificationId));
      setAllNotifications((prev) => prev.filter((notification) => notification.id !== notificationId));
      const next = new Set(dismissedIds);
      next.add(notificationId);
      setDismissedIds(next);
      await persistDismissed(next);
    },
    [dismissedIds, persistDismissed]
  );

  const handleResetDismissed = useCallback(async () => {
    if (!user?.id) return;
    const next = new Set<string>();
    setDismissedIds(next);
    await persistDismissed(next);
    fetchNotifications();
  }, [fetchNotifications, persistDismissed, user?.id]);

  const handleRefresh = useCallback(async () => {
    setRefreshing(true);
    await fetchNotifications();
  }, [fetchNotifications]);

  const primaryRouteForStatus = useCallback((status: string) => {
    if (WAITING_STATUSES.has(status)) return '/owner/track';
    if (status === 'pending_payment') return '/owner/track';
    if (TRACKABLE_STATUSES.has(status)) return '/owner/track';
    return '/owner/wash-history';
  }, []);

  const handleGoToNotification = useCallback(
    (notification: UnifiedNotification) => {
      if (notification.actionRoute) {
        router.push({
          pathname: notification.actionRoute as any,
          params: notification.actionParams || {},
        });
      } else if (notification.type === 'booking' && notification.bookingId) {
        const route = notification.actionRoute || primaryRouteForStatus(notification.status || '');
        router.push({
          pathname: route as any,
          params: notification.actionParams || { bookingId: notification.bookingId },
        });
      } else if (notification.type === 'vehicle_reminder') {
        router.push({
          pathname: '/owner/settings/vehicle-management',
        });
      } else if (notification.type === 'reward') {
        router.push({
          pathname: '/owner/features/rewards',
        });
      }
    },
    []
  );

  const handleGoToHistory = useCallback((notification: UnifiedNotification) => {
    if (notification.bookingId) {
      router.push({
        pathname: '/owner/wash-history',
        params: { highlightId: notification.bookingId },
      });
    } else {
      router.push({
        pathname: '/owner/wash-history',
      });
    }
  }, []);

  const presentTypes = useMemo(() => {
    const counts = new Map<NotificationType, number>();
    for (const n of visibleNotifications) counts.set(n.type, (counts.get(n.type) ?? 0) + 1);
    return FILTER_ORDER.filter((t) => counts.has(t)).map((t) => ({ type: t, count: counts.get(t)! }));
  }, [visibleNotifications]);

  useEffect(() => {
    if (activeFilter !== 'all' && !presentTypes.some((p) => p.type === activeFilter)) setActiveFilter('all');
  }, [activeFilter, presentTypes]);

  const filteredNotifications = useMemo(
    () => (activeFilter === 'all' ? visibleNotifications : visibleNotifications.filter((n) => n.type === activeFilter)),
    [activeFilter, visibleNotifications]
  );

  const urgentCount = useMemo(
    () => visibleNotifications.filter((n) => n.priority === 'high').length,
    [visibleNotifications]
  );

  const formattedCount = useMemo(
    () => `${visibleNotifications.length} notification${visibleNotifications.length === 1 ? '' : 's'}`,
    [visibleNotifications.length]
  );

  const handleSelectFilter = useCallback((key: FilterKey) => {
    hapticFeedback('light');
    setActiveFilter(key);
  }, []);

  const handleClearVisible = useCallback(() => {
    const ids = filteredNotifications.map((n) => n.id);
    if (ids.length === 0) return;
    Alert.alert(
      'Clear notifications?',
      activeFilter === 'all'
        ? 'This will dismiss everything in your list.'
        : `This will dismiss all ${TYPE_META[activeFilter].label.toLowerCase()}.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Clear',
          style: 'destructive',
          onPress: async () => {
            await hapticFeedback('medium');
            const idSet = new Set(ids);
            setVisibleNotifications((prev) => prev.filter((n) => !idSet.has(n.id)));
            setAllNotifications((prev) => prev.filter((n) => !idSet.has(n.id)));
            const next = new Set(dismissedIds);
            ids.forEach((id) => next.add(id));
            setDismissedIds(next);
            await persistDismissed(next);
          },
        },
      ]
    );
  }, [activeFilter, dismissedIds, filteredNotifications, persistDismissed]);

  const renderNotification = useCallback(
    ({ item, index }: { item: UnifiedNotification; index: number }) => (
      <NotificationCard
        item={item}
        index={index}
        onOpen={handleGoToNotification}
        onHistory={handleGoToHistory}
        onDismiss={handleDismiss}
      />
    ),
    [handleDismiss, handleGoToHistory, handleGoToNotification]
  );

  const listHeader =
    visibleNotifications.length > 0 ? (
      <Reanimated.View entering={FadeIn.duration(260)} style={styles.listHeader}>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.chipRow}
          style={styles.chipScroll}
        >
          <FilterChip
            label="All"
            count={visibleNotifications.length}
            active={activeFilter === 'all'}
            onPress={() => handleSelectFilter('all')}
          />
          {presentTypes.map(({ type, count }) => (
            <FilterChip
              key={type}
              label={TYPE_META[type].label}
              icon={notificationIconSolid(type)}
              tone={TYPE_META[type].tone}
              count={count}
              active={activeFilter === type}
              onPress={() => handleSelectFilter(type)}
            />
          ))}
        </ScrollView>
        <View style={styles.toolbar}>
          <View style={styles.toolbarLeft}>
            {urgentCount > 0 ? (
              <>
                <PulseDot color="#F87171" />
                <Text style={styles.toolbarText}>
                  {urgentCount} need{urgentCount === 1 ? 's' : ''} attention
                </Text>
              </>
            ) : (
              <Text style={styles.toolbarText}>
                {filteredNotifications.length} update{filteredNotifications.length === 1 ? '' : 's'}
              </Text>
            )}
          </View>
          <Pressable onPress={handleClearVisible} hitSlop={8} style={styles.clearButton}>
            <Ionicons name="checkmark-done" size={14} color={SKY} />
            <Text style={styles.clearText}>Clear {activeFilter === 'all' ? 'all' : 'these'}</Text>
          </Pressable>
        </View>
      </Reanimated.View>
    ) : null;

  const emptyActions = useMemo<LivelyEmptyAction[]>(
    () => [
      {
        key: 'book',
        label: 'Book a wash',
        icon: 'sparkles',
        primary: true,
        onPress: () => router.push('/owner/booking/create'),
      },
      { key: 'bookings', label: 'View bookings', icon: 'receipt-outline', onPress: () => router.push('/owner/track') },
      ...(dismissedIds.size > 0
        ? [
            {
              key: 'restore',
              label: `Restore ${dismissedIds.size} dismissed`,
              icon: 'refresh' as const,
              onPress: handleResetDismissed,
            },
          ]
        : []),
    ],
    [dismissedIds.size, handleResetDismissed]
  );

  const listEmptyComponent = () => (
    <Reanimated.View entering={FadeInDown.delay(100)} style={styles.emptyState}>
      <LivelyEmptyState
        variant="bell"
        accent={SKY}
        title="You're all caught up"
        subtitle="Bookings, chats, vehicle reminders and rewards land here the moment they happen."
        tips={[
          'Tap the bell for a little ring',
          'Pull down to check for new updates',
          `Live updates from your ${ccpSingularLower()} appear instantly`,
        ]}
        actions={emptyActions}
      />
    </Reanimated.View>
  );

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      <AppHeader
        title="Notifications"
        {...(!loading ? { subtitle: `Priority updates · ${formattedCount}` } : {})}
        variant="dashboard"
        showBack
        fullWidth
        onBack={() => { hapticFeedback('light'); router.back(); }}
        accountType="customer"
        rightAction={
          <GradientNotificationBell
            count={visibleNotifications.length}
            accentColor={colors.SKY}
            disabled
          />
        }
      />

      {loading ? (
        <View style={[styles.listContent, scrollPad]}>
          <SkeletonList count={6} />
        </View>
      ) : (
        <Reanimated.FlatList
          data={filteredNotifications}
          keyExtractor={(item) => item.id}
          contentContainerStyle={[styles.listContent, scrollPad]}
          renderItem={renderNotification}
          itemLayoutAnimation={LinearTransition.springify().damping(18)}
          ListHeaderComponent={listHeader}
          ListEmptyComponent={listEmptyComponent}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={SKY} />}
        />
      )}
    </SafeAreaView>
  );
}

type FilterKey = 'all' | NotificationType;

const TYPE_META: Record<NotificationType, { tone: HubGlassTone; label: string; action: string }> = {
  booking: { tone: 'sky', label: 'Bookings', action: 'Go to booking' },
  chat: { tone: 'violet', label: 'Chats', action: 'Open chat' },
  vehicle_reminder: { tone: 'red', label: 'Vehicles', action: 'Manage vehicles' },
  reward: { tone: 'gold', label: 'Rewards', action: 'View rewards' },
  payment: { tone: 'green', label: 'Payments', action: 'View details' },
  document: { tone: 'pink', label: 'Documents', action: 'View details' },
  referral: { tone: 'green', label: 'Referrals', action: 'View details' },
  system: { tone: 'sky', label: 'Updates', action: 'View details' },
};

const FILTER_ORDER: NotificationType[] = [
  'booking',
  'chat',
  'vehicle_reminder',
  'reward',
  'payment',
  'document',
  'referral',
  'system',
];

const pulseKeyframes = css.keyframes({
  from: { transform: [{ scale: 0.6 }], opacity: 0.7 },
  to: { transform: [{ scale: 2.2 }], opacity: 0 },
});

function PulseDot({ color }: Readonly<{ color: string }>) {
  return (
    <View style={styles.pulseWrap}>
      <Reanimated.View
        style={[
          styles.pulseRing,
          {
            backgroundColor: color,
            animationName: pulseKeyframes,
            animationDuration: '1.6s',
            animationIterationCount: 'infinite',
            animationTimingFunction: 'ease-out',
          },
        ]}
      />
      <View style={[styles.pulseCore, { backgroundColor: color }]} />
    </View>
  );
}

function usePressScale(to = 0.97) {
  const scale = useSharedValue(1);
  const style = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  const onPressIn = useCallback(() => {
    scale.value = withSpring(to, { damping: 18, stiffness: 320 });
  }, [scale, to]);
  const onPressOut = useCallback(() => {
    scale.value = withSpring(1, { damping: 14, stiffness: 260 });
  }, [scale]);
  return { style, onPressIn, onPressOut };
}

const FilterChip = React.memo(function FilterChip({
  label,
  count,
  active,
  onPress,
  icon,
  tone = 'sky',
}: Readonly<{
  label: string;
  count: number;
  active: boolean;
  onPress: () => void;
  icon?: keyof typeof Ionicons.glyphMap;
  tone?: HubGlassTone;
}>) {
  const press = usePressScale(0.94);
  const palette = HUB_GLASS_PALETTES[tone];
  return (
    <Pressable onPress={onPress} onPressIn={press.onPressIn} onPressOut={press.onPressOut}>
      <Reanimated.View style={[styles.chip, active && styles.chipActive, press.style]}>
        {icon ? <Ionicons name={icon} size={13} color={active ? '#7DD3FC' : palette.glow} /> : null}
        <Text style={[styles.chipText, active && styles.chipTextActive]}>{label}</Text>
        <View style={[styles.chipCount, active && styles.chipCountActive]}>
          <Text style={[styles.chipCountText, active && styles.chipTextActive]}>{count}</Text>
        </View>
      </Reanimated.View>
    </Pressable>
  );
});

const NotificationCard = React.memo(function NotificationCard({
  item,
  index,
  onOpen,
  onHistory,
  onDismiss,
}: Readonly<{
  item: UnifiedNotification;
  index: number;
  onOpen: (n: UnifiedNotification) => void;
  onHistory: (n: UnifiedNotification) => void;
  onDismiss: (id: string) => void;
}>) {
  const press = usePressScale();
  const meta = TYPE_META[item.type];
  const palette = HUB_GLASS_PALETTES[meta.tone];
  const isBooking = item.type === 'booking';

  const chips: { icon: keyof typeof Ionicons.glyphMap; text: string }[] = [];
  if (isBooking && item.valeterName) chips.push({ icon: 'person', text: item.valeterName });
  if (isBooking && typeof item.price === 'number') chips.push({ icon: 'pricetag', text: formatCurrency(item.price) });
  if (item.type === 'vehicle_reminder' && (item.vehicleMake || item.vehicleModel)) {
    chips.push({ icon: 'car', text: [item.vehicleMake, item.vehicleModel].filter(Boolean).join(' ') });
  }
  if (item.type === 'vehicle_reminder' && item.daysRemaining !== undefined) {
    chips.push({ icon: 'time', text: `${item.daysRemaining} day${item.daysRemaining === 1 ? '' : 's'} left` });
  }
  if (item.type === 'reward' && item.points) chips.push({ icon: 'trophy', text: `${item.points} pts` });

  const open = () => {
    hapticFeedback('light');
    onOpen(item);
  };

  return (
    <Reanimated.View
      entering={FadeInDown.delay(Math.min(index, 8) * 55)
        .springify()
        .damping(16)}
      exiting={FadeOutLeft.duration(220)}
    >
      <Pressable
        onPress={open}
        onPressIn={press.onPressIn}
        onPressOut={press.onPressOut}
        onLongPress={() => {
          hapticFeedback('medium');
          onDismiss(item.id);
        }}
        delayLongPress={450}
      >
        <Reanimated.View style={[styles.card, press.style]}>
          <LinearGradient
            colors={[`${palette.glow}26`, 'rgba(255,255,255,0.03)']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={StyleSheet.absoluteFill}
          />

          <View style={styles.cardTop}>
            <View>
              <HubGlassIcon icon={notificationIconSolid(item.type)} accent={meta.tone} size={42} iconSize={19} />
              {item.priority === 'high' ? (
                <View style={styles.cardPulse}>
                  <PulseDot color="#F87171" />
                </View>
              ) : null}
            </View>
            <View style={styles.cardHeading}>
              <View style={styles.cardTitleRow}>
                <Text style={styles.cardTitle} numberOfLines={1}>
                  {item.title}
                </Text>
                <Text style={styles.cardTime}>{formatRelative(item.createdAt)}</Text>
              </View>
              <View style={styles.cardSubRow}>
                <Text style={[styles.cardKicker, { color: palette.glow }]}>{meta.label.replace(/s$/, '')}</Text>
                {isBooking && item.status ? <StatusBadge status={item.status as any} size="small" /> : null}
              </View>
            </View>
          </View>

          <Text style={styles.messageText} numberOfLines={3}>
            {item.message}
          </Text>

          {isBooking && item.address ? (
            <View style={styles.addressRow}>
              <Ionicons name="location" size={13} color={palette.glow} />
              <Text style={styles.addressText} numberOfLines={1}>
                {item.address}
              </Text>
            </View>
          ) : null}

          {chips.length > 0 ? (
            <View style={styles.chipsWrap}>
              {chips.map((c) => (
                <View key={c.icon + c.text} style={styles.metaChip}>
                  <Ionicons name={c.icon} size={12} color={palette.icon} />
                  <Text style={styles.metaChipText} numberOfLines={1}>
                    {c.text}
                  </Text>
                </View>
              ))}
            </View>
          ) : null}

          <View style={styles.actionsRow}>
            <View style={[styles.primaryAction, { backgroundColor: `${palette.glow}2E` }]}>
              <Text style={[styles.primaryActionText, { color: palette.icon }]}>{meta.action}</Text>
              <Ionicons name="arrow-forward" size={14} color={palette.icon} />
            </View>
            {isBooking ? (
              <Pressable
                hitSlop={6}
                style={styles.ghostAction}
                onPress={() => {
                  hapticFeedback('light');
                  onHistory(item);
                }}
              >
                <Ionicons name="time-outline" size={14} color="#B3C0D5" />
                <Text style={styles.ghostActionText}>My washes</Text>
              </Pressable>
            ) : null}
            <Pressable
              hitSlop={8}
              style={styles.dismissButton}
              onPress={() => onDismiss(item.id)}
              accessibilityLabel="Dismiss notification"
            >
              <Ionicons name="close" size={16} color="#B3C0D5" />
            </Pressable>
          </View>
        </Reanimated.View>
      </Pressable>
    </Reanimated.View>
  );
});

const formatCurrency = (value?: number | null) => {
  if (typeof value !== 'number') return '£—';
  return `£${value.toFixed(2).replace(/\.00$/, '')}`;
};

const formatRelative = (iso?: string | null) => {
  if (!iso) return 'Just now';
  const then = new Date(iso).getTime();
  if (Number.isNaN(then)) return 'Just now';
  const diff = Date.now() - then;
  const future = diff < 0;
  const mins = Math.round(Math.abs(diff) / 60000);
  if (mins < 1) return 'Just now';
  const fmt = (v: number, unit: string) => (future ? `in ${v}${unit}` : `${v}${unit} ago`);
  if (mins < 60) return fmt(mins, 'm');
  const hours = Math.round(mins / 60);
  if (hours < 24) return fmt(hours, 'h');
  const days = Math.round(hours / 24);
  if (days < 7) return fmt(days, 'd');
  return new Date(iso).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  listContent: {
    paddingHorizontal: SPACING.xl,
    paddingTop: SPACING.md,
    paddingBottom: 40,
    gap: SPACING.md,
  },
  listHeader: {
    marginHorizontal: -SPACING.xl,
    gap: SPACING.sm,
  },
  chipScroll: {
    flexGrow: 0,
  },
  chipRow: {
    paddingHorizontal: SPACING.xl,
    gap: 8,
  },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingLeft: 12,
    paddingRight: 6,
    height: 34,
    borderRadius: 17,
    backgroundColor: 'rgba(148,163,184,0.12)',
  },
  chipActive: {
    backgroundColor: 'rgba(56,189,248,0.16)',
    shadowColor: '#38BDF8',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.35,
    shadowRadius: 12,
  },
  chipText: {
    color: '#E5E7EB',
    fontSize: 13,
    fontWeight: '700',
  },
  chipTextActive: {
    color: '#7DD3FC',
  },
  chipCount: {
    minWidth: 22,
    height: 22,
    paddingHorizontal: 6,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
  },
  chipCountActive: {
    backgroundColor: 'rgba(56,189,248,0.28)',
  },
  chipCountText: {
    color: '#CBD5E1',
    fontSize: 11,
    fontWeight: '800',
  },
  toolbar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: SPACING.xl,
    paddingVertical: 2,
  },
  toolbarLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  toolbarText: {
    color: '#B3C0D5',
    fontSize: 12,
    fontWeight: '600',
  },
  clearButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.12)',
  },
  clearText: {
    color: SKY,
    fontSize: 12,
    fontWeight: '700',
  },
  pulseWrap: {
    width: 10,
    height: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  pulseRing: {
    position: 'absolute',
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  pulseCore: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  card: {
    overflow: 'hidden',
    padding: SPACING.lg,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  cardTop: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  cardPulse: {
    position: 'absolute',
    top: -1,
    right: -1,
  },
  cardHeading: {
    flex: 1,
    gap: 3,
  },
  cardTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  cardTitle: {
    flex: 1,
    color: '#F8FAFC',
    fontSize: FONT_SIZES.base,
    fontWeight: '800',
  },
  cardTime: {
    color: '#94A3B8',
    fontSize: 11,
    fontWeight: '600',
  },
  cardSubRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  cardKicker: {
    fontSize: 10.5,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  messageText: {
    color: 'rgba(226,232,240,0.7)',
    fontSize: FONT_SIZES.md,
    fontWeight: '500',
    marginTop: SPACING.md,
    lineHeight: 20,
  },
  addressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: SPACING.sm,
  },
  addressText: {
    flex: 1,
    color: '#CBD5E1',
    fontSize: 13,
  },
  chipsWrap: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 6,
    marginTop: SPACING.sm,
  },
  metaChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 9,
    paddingVertical: 4,
    borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.07)',
    maxWidth: '100%',
  },
  metaChipText: {
    color: '#E5E7EB',
    fontSize: 12,
    fontWeight: '600',
  },
  actionsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: SPACING.md,
  },
  primaryAction: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    height: 32,
    borderRadius: 16,
  },
  primaryActionText: {
    fontSize: 13,
    fontWeight: '700',
  },
  ghostAction: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  ghostActionText: {
    color: '#B3C0D5',
    fontSize: 13,
    fontWeight: '600',
  },
  dismissButton: {
    marginLeft: 'auto',
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 72,
  },
});
