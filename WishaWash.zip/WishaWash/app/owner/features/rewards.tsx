import { useEffect, useState, useCallback, useMemo } from 'react';
import { Text, StyleSheet, Alert, ScrollView } from 'react-native';
import Animated, { FadeIn, FadeInDown } from 'react-native-reanimated';
import { router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import AppHeader from '../../../src/components/shared/AppHeader';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { useOwnerScrollContentPadding } from '../../../src/hooks/useOwnerScrollContentPadding';
import { SPACING } from '../../../src/constants/designTokens';
import { getLoyaltyBalance, redeemRewardPoints } from '../../../src/services/LoyaltyService';
import MilestoneRoad, { roadPosition, type MilestoneStop } from '../../../src/components/road/MilestoneRoad';
import LoyaltyEarnStrip from '../../../src/components/rewards/LoyaltyEarnStrip';
import LoyaltyClaimSheet from '../../../src/components/rewards/LoyaltyClaimSheet';
import { WASH_REWARD_MILESTONES, type RewardMilestone } from '../../../src/utils/loyaltyTier';

const REWARD_THRESHOLDS = [0, ...WASH_REWARD_MILESTONES.map((m) => m.points)];
const TIER_TONE = { rare: 'sky', epic: 'violet', legendary: 'gold' } as const;

export default function Rewards() {
  const scrollPad = useOwnerScrollContentPadding(true);
  const { user, updateUser } = useAuth();

  const [loading, setLoading] = useState(true);
  const [redeemingId, setRedeemingId] = useState<string | null>(null);
  const [claimedReward, setClaimedReward] = useState<RewardMilestone | null>(null);

  const [points, setPoints] = useState(0);

  const loadPoints = useCallback(async () => {
    if (!user?.id) {
      setPoints(0);
      setLoading(false);
      return;
    }

    try {
      const balance = await getLoyaltyBalance(user.id);
      setPoints(balance.effectivePoints);
    } catch (e: unknown) {
      console.warn('[Rewards] Could not load loyalty.', e);
      setPoints(0);
    } finally {
      setLoading(false);
    }
  }, [user?.id]);

  useEffect(() => {
    void loadPoints();
  }, [loadPoints]);

  const handleRedeem = (reward: RewardMilestone) => {
    if (!user?.id || redeemingId || points < reward.points) return;
    Alert.alert(
      'Claim reward',
      `Spend ${reward.points.toLocaleString()} points to unlock "${reward.title}"?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Claim',
          onPress: () => {
            void (async () => {
              try {
                setRedeemingId(reward.id);
                const nextBalance = await redeemRewardPoints(user.id, {
                  id: reward.id,
                  title: reward.title,
                  points: reward.points,
                });
                await updateUser({ tierPoints: nextBalance });
                setPoints(nextBalance);
                setClaimedReward(reward);
                void hapticFeedback('medium');
              } catch (err: unknown) {
                const message = err instanceof Error ? err.message : 'Unable to redeem this reward right now.';
                Alert.alert('Claim failed', message);
              } finally {
                setRedeemingId(null);
              }
            })();
          },
        },
      ]
    );
  };

  const roadStops = useMemo<MilestoneStop[]>(
    () => [
      {
        key: 'start',
        label: 'Start',
        title: 'Your rewards journey',
        subtitle: 'Every wash moves you further down the road.',
        icon: 'flag',
        tone: 'green',
        reached: true,
        status: `${points.toLocaleString()} pts banked`,
      },
      ...WASH_REWARD_MILESTONES.map((m): MilestoneStop => {
        const reached = points >= m.points;
        return {
          key: m.id,
          label: `${m.points.toLocaleString()} pts`,
          title: m.title,
          subtitle: m.description,
          icon: m.icon as MilestoneStop['icon'],
          tone: TIER_TONE[m.tier],
          reached,
          status: reached ? 'Ready to claim' : `${(m.points - points).toLocaleString()} pts to go`,
          ...(reached
            ? {
                action: {
                  label: 'Claim',
                  icon: 'gift' as const,
                  onPress: () => handleRedeem(m),
                  busy: redeemingId === m.id,
                },
              }
            : {}),
        };
      }),
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [points, redeemingId]
  );

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <AppHeader
        title="Rewards"
        showBack
        fullWidth
        {...(loading ? {} : { points })}
        onBack={() => {
          void hapticFeedback('light');
          router.back();
        }}
        accountType="customer"
      />

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={[styles.content, scrollPad]}
        showsVerticalScrollIndicator={false}
      >
        <Animated.View entering={FadeInDown.delay(70).springify().damping(18)}>
          <MilestoneRoad
            kicker="REWARDS ROAD"
            stops={roadStops}
            position={roadPosition(REWARD_THRESHOLDS, points)}
            ready={!loading}
          />
        </Animated.View>

        <Animated.View entering={FadeInDown.delay(140).springify().damping(18)}>
          <LoyaltyEarnStrip />
        </Animated.View>

        <Animated.View entering={FadeIn.delay(220)} style={styles.bottom}>
          <Text style={styles.disclaimerText}>Rewards do not apply to detailing services.</Text>
        </Animated.View>
      </ScrollView>

      <LoyaltyClaimSheet
        visible={claimedReward != null}
        reward={claimedReward}
        onClose={() => setClaimedReward(null)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  scroll: { flex: 1 },
  content: {
    flexGrow: 1,
    paddingHorizontal: SPACING.xl,
    gap: 14,
  },
  bottom: {
    marginTop: 'auto',
    alignItems: 'center',
  },
  disclaimerText: {
    color: 'rgba(148,163,184,0.7)',
    fontSize: 11,
    fontWeight: '500',
  },
});
