import { useState, useEffect, useCallback, useMemo, useRef, type ReactNode } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  RefreshControl,
  Alert,
  ScrollView,
  type LayoutChangeEvent,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import Animated, {
  css,
  FadeIn,
  FadeInDown,
  FadeOut,
  LinearTransition,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from 'react-native-reanimated';
import { Marker } from 'react-native-maps';
import SafeMapView from '../../src/components/maps/SafeMapView';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import AppHeader from '../../src/components/shared/AppHeader';
import LivelyEmptyState from '../../src/components/shared/LivelyEmptyState';
import { SkeletonList } from '../../src/components/shared/SkeletonLoader';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { useOwnerScrollContentPadding } from '../../src/hooks/useOwnerScrollContentPadding';
import { CONTENT_PADDING_H } from '../../src/constants/pageStyles';
import { colors } from '../../src/constants/colors';
import { getServiceDisplayName } from '../../src/utils/serviceNameMapper';
import { HISTORY_SNAPSHOT_MAP_STYLE, MAP_LOCKED_DARK } from '../../src/constants/mapConstants';
import { MapMarkerCustomerVehicle } from '../../src/components/maps/MapMarkerViews';
import HubGlassIcon, { type HubGlassTone } from '../../src/components/shared/HubGlassIcon';
import { markBookingManuallyStarted } from '../../src/utils/activeBookingGuard';
import { removeBookingFromDeviceCalendar } from '../../src/services/BookingCalendarSync';

const SKY = colors.SKY;
const RATING_GOLD = '#FBBF24';
const ECO_GREEN = colors.ECO_GREEN ?? '#10B981';
const DETAILING_YELLOW = colors.DETAILING_YELLOW ?? '#EAB308';
const CARD_BG = 'rgba(255,255,255,0.06)';
const COUNTDOWN_TICK_MS = 30_000;

type CompletedStatus =
  | 'completed'
  | 'rated'
  | 'closed'
  | 'archived'
  | 'complete';

const COMPLETED_STATUSES = new Set<CompletedStatus>([
  'completed',
  'rated',
  'closed',
  'archived',
  'complete',
]);

type NormalizedCompletion = {
  id: string;
  status: string;
  serviceName?: string | null;
  service_type?: string | null;
  price?: number | null;
  completedAt?: string | Date | null;
  createdAt?: string | Date | null;
  scheduledAt?: string | Date | null;
  valeterName?: string | null;
  valeterOrganization?: string | null;
  address?: string | null;
  location?: { latitude: number; longitude: number } | null;
  notes?: string | null;
  rating?: number | null;
  customerReview?: string | null;
  tipAmount?: number | null;
  photos?: any[] | null;
};

type HistoryTab = 'upcoming' | 'completed';
const TABS: HistoryTab[] = ['upcoming', 'completed'];

const liveDotPulse = css.keyframes({
  from: { transform: [{ scale: 1 }], opacity: 0.7 },
  to: { transform: [{ scale: 2.6 }], opacity: 0 },
});

function getRelativeDate(dateLike: Date | string | number | undefined | null): string {
  if (!dateLike) return '';
  const d = new Date(dateLike);
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffDays = Math.floor(diffMs / (24 * 60 * 60 * 1000));
  if (diffDays === 0) return 'Today';
  if (diffDays === 1) return 'Yesterday';
  if (diffDays < 7) return `${diffDays} days ago`;
  if (diffDays < 14) return 'Last week';
  if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`;
  if (diffDays < 60) return 'Last month';
  if (diffDays < 365) return `${Math.floor(diffDays / 30)} months ago`;
  const years = Math.floor(diffDays / 365);
  return years > 1 ? `${years} years ago` : '1 year ago';
}

function getSectionLabel(key: string): string {
  switch (key) {
    case 'this_month':
      return 'This month';
    case 'last_month':
      return 'Last month';
    case 'older':
      return 'Older';
    default:
      return key;
  }
}

function getSectionKey(completion: NormalizedCompletion): string {
  const d = new Date((completion.completedAt ?? completion.createdAt ?? 0) as any);
  const now = new Date();
  const thisMonth = now.getFullYear() * 12 + now.getMonth();
  const thatMonth = d.getFullYear() * 12 + d.getMonth();
  const diff = thisMonth - thatMonth;
  if (diff === 0) return 'this_month';
  if (diff === 1) return 'last_month';
  return 'older';
}

function getServiceAccent(completion: NormalizedCompletion): string {
  const t = (completion.service_type ?? completion.serviceName ?? '').toLowerCase();
  if (t.includes('detailing')) return DETAILING_YELLOW;
  if (t.includes('eco')) return ECO_GREEN;
  return SKY;
}

function getServiceTone(accent: string): HubGlassTone {
  if (accent === ECO_GREEN) return 'green';
  if (accent === DETAILING_YELLOW) return 'gold';
  return 'sky';
}

function getServiceIconName(accent: string): 'leaf' | 'sparkles' | 'water' {
  if (accent === ECO_GREEN) return 'leaf';
  if (accent === DETAILING_YELLOW) return 'sparkles';
  return 'water';
}

function splitCountdown(target: Date | null, nowTs: number) {
  const diffMs = target ? Math.max(0, target.getTime() - nowTs) : 0;
  const days = Math.floor(diffMs / 86_400_000);
  const hours = Math.floor((diffMs % 86_400_000) / 3_600_000);
  const mins = Math.floor((diffMs % 3_600_000) / 60_000);
  return { days, hours, mins, short: days > 0 ? `${days}d ${hours}h` : `${hours}h ${mins}m` };
}

function useCountUp(target: number, durationMs = 750) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    let raf = 0;
    const start = Date.now();
    const tick = () => {
      const t = Math.min(1, (Date.now() - start) / durationMs);
      const eased = 1 - Math.pow(1 - t, 3);
      setValue(target * eased);
      if (t < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, durationMs]);
  return value;
}

function PressScale({
  children,
  onPress,
  style,
  accessibilityLabel,
  hitSlop,
}: Readonly<{
  children: ReactNode;
  onPress: () => void;
  style?: any;
  accessibilityLabel?: string;
  hitSlop?: number;
}>) {
  const scale = useSharedValue(1);
  const animatedStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  return (
    <Pressable
      onPress={onPress}
      onPressIn={() => {
        scale.value = withSpring(0.96, { damping: 18, stiffness: 340 });
      }}
      onPressOut={() => {
        scale.value = withSpring(1, { damping: 14, stiffness: 260 });
      }}
      accessibilityRole="button"
      {...(accessibilityLabel ? { accessibilityLabel } : {})}
      {...(hitSlop ? { hitSlop } : {})}
    >
      <Animated.View style={[style, animatedStyle]}>{children}</Animated.View>
    </Pressable>
  );
}

function StatTile({
  icon,
  label,
  value,
  accent,
  delay,
}: Readonly<{ icon: keyof typeof Ionicons.glyphMap; label: string; value: string; accent: HubGlassTone; delay: number }>) {
  return (
    <Animated.View entering={FadeInDown.delay(delay).springify().damping(18)} style={styles.statTile}>
      <HubGlassIcon icon={icon} accent={accent} size={32} iconSize={15} />
      <Text style={styles.statValue} numberOfLines={1} adjustsFontSizeToFit>
        {value}
      </Text>
      <Text style={styles.statLabel} numberOfLines={1}>
        {label}
      </Text>
    </Animated.View>
  );
}

function SegmentedTabs({
  value,
  onChange,
  counts,
}: Readonly<{ value: HistoryTab; onChange: (t: HistoryTab) => void; counts: Record<HistoryTab, number> }>) {
  const [width, setWidth] = useState(0);
  const segW = width > 0 ? (width - 8) / TABS.length : 0;
  const x = useSharedValue(0);

  useEffect(() => {
    x.value = withSpring(TABS.indexOf(value) * segW, { damping: 20, stiffness: 220 });
  }, [value, segW, x]);

  const indicatorStyle = useAnimatedStyle(() => ({ transform: [{ translateX: x.value }] }));

  return (
    <View style={styles.segment} onLayout={(e: LayoutChangeEvent) => setWidth(e.nativeEvent.layout.width)}>
      {segW > 0 ? (
        <Animated.View pointerEvents="none" style={[styles.segmentIndicator, { width: segW }, indicatorStyle]}>
          <LinearGradient
            colors={['rgba(56,189,248,0.38)', 'rgba(56,189,248,0.16)']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={StyleSheet.absoluteFill}
          />
        </Animated.View>
      ) : null}
      {TABS.map((t) => {
        const active = t === value;
        return (
          <Pressable
            key={t}
            style={styles.segmentTab}
            onPress={() => {
              if (active) return;
              hapticFeedback('light');
              onChange(t);
            }}
            accessibilityRole="tab"
            accessibilityState={{ selected: active }}
          >
            <Ionicons
              name={t === 'upcoming' ? (active ? 'calendar' : 'calendar-outline') : active ? 'checkmark-done-circle' : 'checkmark-done-circle-outline'}
              size={15}
              color={active ? '#E0F2FE' : 'rgba(148,163,184,0.8)'}
            />
            <Text style={[styles.segmentText, active && styles.segmentTextActive]}>
              {t === 'upcoming' ? 'Upcoming' : 'Completed'}
            </Text>
            {counts[t] > 0 ? (
              <View style={[styles.segmentCount, active && styles.segmentCountActive]}>
                <Text style={[styles.segmentCountText, active && styles.segmentTextActive]}>{counts[t]}</Text>
              </View>
            ) : null}
          </Pressable>
        );
      })}
    </View>
  );
}

function CountdownBlock({ value, label }: Readonly<{ value: number; label: string }>) {
  return (
    <View style={styles.countBlock}>
      <Animated.Text key={`${label}-${value}`} entering={FadeInDown.duration(260)} style={styles.countValue}>
        {String(value).padStart(2, '0')}
      </Animated.Text>
      <Text style={styles.countLabel}>{label}</Text>
    </View>
  );
}

export default function WashHistory() {
  const { user } = useAuth();
  const params = useLocalSearchParams<{ highlightId?: string | string[] }>();
  const scrollPad = useOwnerScrollContentPadding(true);

  const highlightId = useMemo(() => {
    const raw = params?.highlightId;
    if (Array.isArray(raw)) return raw[0] ?? null;
    return raw ?? null;
  }, [params]);

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [washCompletions, setWashCompletions] = useState<NormalizedCompletion[]>([]);
  const [upcomingBookings, setUpcomingBookings] = useState<NormalizedCompletion[]>([]);
  const [historyTab, setHistoryTab] = useState<HistoryTab>('completed');
  const [expandedId, setExpandedId] = useState<string | null>(highlightId);
  const [nowTs, setNowTs] = useState(() => Date.now());
  const autoTabChosenRef = useRef(false);

  useEffect(() => {
    if (highlightId) setExpandedId(highlightId);
  }, [highlightId]);

  useEffect(() => {
    const id = setInterval(() => setNowTs(Date.now()), COUNTDOWN_TICK_MS);
    return () => clearInterval(id);
  }, []);

  const formatCurrency = (n?: number | null) =>
    typeof n === 'number' ? `£${n.toFixed(2).replace(/\.00$/, '')}` : '—';

  const numberish = (v: any): number | null => {
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  };

  const isCompleted = (wc: NormalizedCompletion) =>
    COMPLETED_STATUSES.has(((wc?.status || 'completed') as CompletedStatus)) ||
    !!wc.completedAt;

  const sortByCompletedAtDesc = (a: NormalizedCompletion, b: NormalizedCompletion) => {
    const ta = new Date((a.completedAt ?? a.createdAt ?? 0) as any).getTime();
    const tb = new Date((b.completedAt ?? b.createdAt ?? 0) as any).getTime();
    return tb - ta;
  };

  const normalizeFromBookings = (rows: any[]): NormalizedCompletion[] =>
    rows.map((r) => ({
      id: String(r.id),
      status: r.status ?? 'scheduled',
      serviceName: r.service_name ?? r.service_type ?? r.wash_type ?? 'Car Wash',
      service_type: r.service_type ?? r.wash_type ?? null,
      price: numberish(r.price),
      completedAt: r.completed_at ?? null,
      createdAt: r.created_at ?? null,
      scheduledAt: r.scheduled_at ?? null,
      valeterName: r.valeter_name ?? null,
      valeterOrganization: null,
      address: r.location_address ?? null,
      location:
        typeof r.location_lat === 'number' && typeof r.location_lng === 'number'
          ? { latitude: r.location_lat, longitude: r.location_lng }
          : null,
      notes: r.special_instructions ?? null,
      rating: numberish(r.rating),
      customerReview: r.customer_review ?? null,
      tipAmount: numberish(r.tip_amount),
      photos: null,
    }));

  const formatDate = (dateLike: Date | string | number | undefined | null) => {
    const d = dateLike ? new Date(dateLike) : new Date();
    return d.toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const formatDayTime = (dateLike: Date | string | number | undefined | null) => {
    const d = dateLike ? new Date(dateLike) : new Date();
    return d.toLocaleString('en-GB', { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
  };

  const groupedBySection = useMemo(() => {
    const sorted = [...washCompletions].sort(sortByCompletedAtDesc);
    const map = new Map<string, NormalizedCompletion[]>();
    sorted.forEach((c) => {
      const key = getSectionKey(c);
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(c);
    });
    const order = ['this_month', 'last_month', 'older'];
    return order.map((key) => ({ key, items: map.get(key) ?? [] })).filter((g) => g.items.length > 0);
  }, [washCompletions]);

  const stats = useMemo(() => {
    const spent = washCompletions.reduce((sum, c) => sum + (c.price ?? 0), 0);
    const rated = washCompletions.filter((c) => typeof c.rating === 'number');
    const avg = rated.length ? rated.reduce((s, c) => s + (c.rating ?? 0), 0) / rated.length : null;
    const thisMonth = washCompletions.filter((c) => getSectionKey(c) === 'this_month').length;
    return { count: washCompletions.length, spent, avg, thisMonth };
  }, [washCompletions]);

  const animatedSpent = useCountUp(stats.spent);
  const animatedCount = useCountUp(stats.count);

  const loadWashHistory = async () => {
    if (!user?.id) {
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      const { data: bookingRows, error: completedError } = await supabase
        .from('bookings')
        .select(
          `id, user_id, status, service_name, service_type, wash_type, price, scheduled_at, created_at, completed_at, valeter_name, location_address, location_lat, location_lng, rating, customer_review, tip_amount, special_instructions, cancelled_at`
        )
        .eq('user_id', user.id)
        .is('cancelled_at', null)
        .order('scheduled_at', { ascending: false })
        .limit(200);

      if (completedError) throw completedError;

      const normalized = normalizeFromBookings(bookingRows || []);
      const completedList = normalized
        .filter(isCompleted)
        .sort(sortByCompletedAtDesc);
      const now = Date.now();
      const upcomingList = normalized
        .filter((b) => {
          if (isCompleted(b)) return false;
          if (!b.scheduledAt) return false;
          const startTs = new Date(b.scheduledAt).getTime();
          if (!Number.isFinite(startTs)) return false;
          return startTs > now;
        })
        .sort((a, b) => {
          const ta = new Date((a.scheduledAt ?? a.createdAt ?? 0) as any).getTime();
          const tb = new Date((b.scheduledAt ?? b.createdAt ?? 0) as any).getTime();
          return ta - tb;
        });

      setWashCompletions(completedList);
      setUpcomingBookings(upcomingList);
      if (!autoTabChosenRef.current && !highlightId) {
        autoTabChosenRef.current = true;
        if (upcomingList.length > 0) setHistoryTab('upcoming');
      }
    } catch (error) {
      console.error('[wash-history] Error loading wash history:', error);
      Alert.alert('Error', 'Failed to load activity');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadWashHistory();
  }, [user?.id]);

  const onRefresh = useCallback(async () => {
    try {
      setRefreshing(true);
      setNowTs(Date.now());
      await loadWashHistory();
    } finally {
      setRefreshing(false);
    }
  }, [user?.id]);

  const performDeleteOne = useCallback(async (completion: NormalizedCompletion) => {
    if (!user?.id) return;
    try {
      const { error } = await supabase
        .from('bookings')
        .update({ cancelled_at: new Date().toISOString() })
        .eq('id', completion.id)
        .eq('user_id', user.id);
      if (error) throw error;
      setWashCompletions((prev) => prev.filter((c) => c.id !== completion.id));
    } catch (e) {
      console.error('[wash-history] Delete error:', e);
      Alert.alert('Error', 'Could not remove from activity');
    }
  }, [user?.id]);

  const handleDeleteOne = useCallback((completion: NormalizedCompletion) => {
    Alert.alert(
      'Remove from activity',
      `Remove "${getServiceDisplayName(completion.service_type, completion.serviceName) ?? completion.serviceName ?? 'this booking'}" from your activity?`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Remove', style: 'destructive', onPress: () => void performDeleteOne(completion) },
      ]
    );
  }, [performDeleteOne]);

  const performCancelUpcoming = useCallback(async (booking: NormalizedCompletion) => {
    if (!user?.id) return;
    try {
      const { data: updatedRow, error } = await supabase
        .from('bookings')
        .update({
          status: 'cancelled',
          cancelled_at: new Date().toISOString(),
          cancelled_by: 'customer',
          cancellation_reason: 'Cancelled by customer from activity',
        })
        .eq('id', booking.id)
        .eq('user_id', user.id)
        .select('id')
        .maybeSingle();
      if (error) throw error;
      if (!updatedRow) {
        Alert.alert('Could not cancel', 'This booking may have already been updated.');
        return;
      }
      await removeBookingFromDeviceCalendar(booking.id);
      setUpcomingBookings((prev) => prev.filter((b) => b.id !== booking.id));
    } catch (e) {
      console.error('[wash-history] Cancel upcoming error:', e);
      Alert.alert('Error', 'Could not cancel this booking');
    }
  }, [user?.id]);

  const handleCancelUpcoming = useCallback((booking: NormalizedCompletion) => {
    const label =
      getServiceDisplayName(booking.service_type, booking.serviceName) ??
      booking.serviceName ??
      'this booking';
    Alert.alert(
      'Cancel booking?',
      `Cancel "${label}" scheduled for ${formatDate(booking.scheduledAt ?? booking.createdAt)}?`,
      [
        { text: 'Keep booking', style: 'cancel' },
        { text: 'Cancel booking', style: 'destructive', onPress: () => void performCancelUpcoming(booking) },
      ]
    );
  }, [performCancelUpcoming]);

  const handleRepeatBooking = (completion: NormalizedCompletion) => {
    hapticFeedback('light');
    const serviceType = (completion.service_type || completion.serviceName || '').toLowerCase();
    router.push({
      pathname: '/owner/explore',
      params: {
        ...(serviceType.includes('eco') && { tab: 'valeters' }),
        ...(completion.address && { address: completion.address }),
        ...(completion.location?.latitude && { latitude: String(completion.location.latitude) }),
        ...(completion.location?.longitude && { longitude: String(completion.location.longitude) }),
      },
    });
  };

  const openTracking = (bookingId: string) =>
    router.push({ pathname: '/owner/booking/tracking', params: { bookingId } } as any);

  const startJourney = async (bookingId: string) => {
    await hapticFeedback('medium');
    await markBookingManuallyStarted(bookingId);
    openTracking(bookingId);
  };

  const toggleExpanded = (id: string) => {
    hapticFeedback('light');
    setExpandedId((cur) => (cur === id ? null : id));
  };

  const renderNextUp = (booking: NormalizedCompletion) => {
    const accent = getServiceAccent(booking);
    const displayName = getServiceDisplayName(booking.service_type, booking.serviceName) ?? booking.serviceName ?? 'Car Wash';
    const startsAt = booking.scheduledAt ? new Date(booking.scheduledAt) : null;
    const cd = splitCountdown(startsAt, nowTs);
    const soon = startsAt != null && startsAt.getTime() - nowTs < 2 * 3_600_000;

    return (
      <Animated.View entering={FadeInDown.springify().damping(18)} layout={LinearTransition.springify().damping(18)}>
        <LinearGradient
          colors={[`${accent}29`, 'rgba(255,255,255,0.05)']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.nextCard}
        >
          <View style={styles.nextHeaderRow}>
            <View style={styles.nextKickerRow}>
              <View style={styles.liveDotWrap}>
                <Animated.View
                  style={[
                    styles.liveDotRing,
                    { backgroundColor: soon ? '#F59E0B' : accent },
                    {
                      animationName: liveDotPulse,
                      animationDuration: '1.6s',
                      animationIterationCount: 'infinite',
                      animationTimingFunction: 'ease-out',
                    },
                  ]}
                />
                <View style={[styles.liveDot, { backgroundColor: soon ? '#F59E0B' : accent }]} />
              </View>
              <Text style={[styles.nextKicker, { color: soon ? '#FCD34D' : accent }]}>
                {soon ? 'STARTING SOON' : 'NEXT UP'}
              </Text>
            </View>
            <PressScale
              onPress={() => {
                hapticFeedback('light');
                handleCancelUpcoming(booking);
              }}
              style={styles.iconBtn}
              accessibilityLabel="Cancel booking"
              hitSlop={8}
            >
              <Ionicons name="close" size={16} color="#CBD5E1" />
            </PressScale>
          </View>

          <View style={styles.nextTitleRow}>
            <HubGlassIcon icon={getServiceIconName(accent)} accent={getServiceTone(accent)} size={46} />
            <View style={styles.flexShrink}>
              <Text style={styles.nextTitle} numberOfLines={1}>{displayName}</Text>
              <Text style={styles.nextWhen} numberOfLines={1}>{formatDayTime(booking.scheduledAt ?? booking.createdAt)}</Text>
            </View>
            {booking.price != null ? <Text style={styles.nextPrice}>{formatCurrency(booking.price)}</Text> : null}
          </View>

          <View style={styles.countRow}>
            <CountdownBlock value={cd.days} label="DAYS" />
            <Text style={styles.countSep}>:</Text>
            <CountdownBlock value={cd.hours} label="HRS" />
            <Text style={styles.countSep}>:</Text>
            <CountdownBlock value={cd.mins} label="MIN" />
          </View>

          {booking.address ? (
            <View style={styles.nextMetaRow}>
              <Ionicons name="location" size={13} color={accent} />
              <Text style={styles.nextMetaText} numberOfLines={1}>{booking.address}</Text>
            </View>
          ) : null}

          <View style={styles.nextActions}>
            <PressScale onPress={() => void startJourney(booking.id)} style={styles.flex1}>
              <View style={styles.primaryBtn}>
                <BlurView intensity={30} tint="dark" style={StyleSheet.absoluteFill} />
                <View style={[StyleSheet.absoluteFill, styles.primaryBtnFill]} />
                <LinearGradient
                  colors={['rgba(255,255,255,0.2)', 'rgba(255,255,255,0)']}
                  style={styles.btnSheen}
                  pointerEvents="none"
                />
                <Ionicons name="navigate" size={15} color="#FFFFFF" />
                <Text style={styles.primaryBtnText}>Start journey</Text>
              </View>
            </PressScale>
            <PressScale
              onPress={() => {
                hapticFeedback('light');
                openTracking(booking.id);
              }}
              style={styles.ghostBtn}
            >
              <Text style={styles.ghostBtnText}>Details</Text>
              <Ionicons name="chevron-forward" size={14} color="#E2E8F0" />
            </PressScale>
          </View>
        </LinearGradient>
      </Animated.View>
    );
  };

  const renderUpcomingRow = (booking: NormalizedCompletion, index: number) => {
    const accent = getServiceAccent(booking);
    const displayName = getServiceDisplayName(booking.service_type, booking.serviceName) ?? booking.serviceName ?? 'Car Wash';
    const cd = splitCountdown(booking.scheduledAt ? new Date(booking.scheduledAt) : null, nowTs);
    return (
      <Animated.View
        key={booking.id}
        entering={FadeInDown.delay(80 + index * 50).springify().damping(18)}
        exiting={FadeOut.duration(180)}
        layout={LinearTransition.springify().damping(18)}
      >
        <PressScale
          onPress={() => {
            hapticFeedback('light');
            openTracking(booking.id);
          }}
          style={styles.rowCard}
        >
          <HubGlassIcon icon={getServiceIconName(accent)} accent={getServiceTone(accent)} size={40} />
          <View style={styles.rowMain}>
            <Text style={styles.rowTitle} numberOfLines={1}>{displayName}</Text>
            <Text style={styles.rowSub} numberOfLines={1}>{formatDayTime(booking.scheduledAt ?? booking.createdAt)}</Text>
          </View>
          <View style={[styles.pill, { backgroundColor: `${accent}29` }]}>
            <Ionicons name="time-outline" size={12} color={accent} />
            <Text style={[styles.pillText, { color: accent }]}>{cd.short}</Text>
          </View>
          <Pressable
            onPress={() => {
              hapticFeedback('light');
              handleCancelUpcoming(booking);
            }}
            hitSlop={10}
            style={styles.rowTrash}
            accessibilityLabel="Cancel booking"
          >
            <Ionicons name="close-circle-outline" size={18} color="#64748B" />
          </Pressable>
        </PressScale>
      </Animated.View>
    );
  };

  const renderCompletedCard = (completion: NormalizedCompletion, index: number) => {
    const expanded = expandedId === completion.id;
    const isHighlighted = highlightId === completion.id;
    const accent = getServiceAccent(completion);
    const displayName = getServiceDisplayName(completion.service_type, completion.serviceName) ?? completion.serviceName ?? 'Car Wash';
    const relativeDate = getRelativeDate(completion.completedAt ?? completion.createdAt);
    const hasMap = completion.location?.latitude != null && completion.location?.longitude != null;

    return (
      <Animated.View
        key={completion.id}
        entering={FadeInDown.delay(Math.min(index, 8) * 45).springify().damping(18)}
        exiting={FadeOut.duration(180)}
        layout={LinearTransition.springify().damping(20)}
        style={[
          styles.doneCard,
          expanded && { backgroundColor: 'rgba(255,255,255,0.09)' },
          isHighlighted && styles.cardHighlight,
        ]}
      >
        <Pressable
          onPress={() => toggleExpanded(completion.id)}
          style={styles.doneHeader}
          accessibilityRole="button"
          accessibilityState={{ expanded }}
          accessibilityLabel={`${displayName}, ${relativeDate}`}
        >
          <View style={[styles.timelineDot, { backgroundColor: accent, shadowColor: accent }]} />
          <HubGlassIcon icon={getServiceIconName(accent)} accent={getServiceTone(accent)} size={42} />
          <View style={styles.rowMain}>
            <Text style={styles.rowTitle} numberOfLines={1}>{displayName}</Text>
            <View style={styles.doneSubRow}>
              <Text style={[styles.doneRelative, { color: accent }]}>{relativeDate}</Text>
              {completion.valeterName ? (
                <Text style={styles.rowSub} numberOfLines={1}> · {completion.valeterName}</Text>
              ) : null}
            </View>
          </View>
          <View style={styles.doneRight}>
            <Text style={styles.donePrice}>{formatCurrency(completion.price)}</Text>
            {completion.rating != null ? (
              <View style={styles.ratingPill}>
                <Ionicons name="star" size={11} color={RATING_GOLD} />
                <Text style={styles.ratingNum}>{completion.rating}</Text>
              </View>
            ) : null}
          </View>
          <Animated.View style={{ transform: [{ rotate: expanded ? '180deg' : '0deg' }], transitionProperty: 'transform', transitionDuration: 220 }}>
            <Ionicons name="chevron-down" size={16} color="rgba(148,163,184,0.8)" />
          </Animated.View>
        </Pressable>

        {expanded ? (
          <Animated.View entering={FadeIn.duration(260).delay(60)} exiting={FadeOut.duration(120)} style={styles.doneBody}>
            {hasMap ? (
              <View style={styles.mapWrap}>
                <SafeMapView
                  style={StyleSheet.absoluteFill}
                  region={{
                    latitude: completion.location!.latitude,
                    longitude: completion.location!.longitude,
                    latitudeDelta: 0.003,
                    longitudeDelta: 0.003,
                  }}
                  scrollEnabled={false}
                  zoomEnabled={false}
                  pitchEnabled={false}
                  rotateEnabled={false}
                  customMapStyle={HISTORY_SNAPSHOT_MAP_STYLE}
                  userInterfaceStyle={MAP_LOCKED_DARK}
                >
                  <Marker coordinate={completion.location!} anchor={{ x: 0.5, y: 0.5 }}>
                    <MapMarkerCustomerVehicle size={34} variant="car" />
                  </Marker>
                </SafeMapView>
                <LinearGradient
                  colors={['transparent', 'rgba(15,23,42,0.75)']}
                  style={StyleSheet.absoluteFill}
                  pointerEvents="none"
                />
              </View>
            ) : null}

            <View style={styles.detailGrid}>
              <View style={styles.detailRow}>
                <Ionicons name="calendar-outline" size={14} color={accent} />
                <Text style={styles.detailText}>{formatDate(completion.completedAt ?? completion.createdAt)}</Text>
              </View>
              {completion.address ? (
                <View style={styles.detailRow}>
                  <Ionicons name="location-outline" size={14} color={accent} />
                  <Text style={styles.detailText} numberOfLines={2}>{completion.address}</Text>
                </View>
              ) : null}
              {completion.tipAmount ? (
                <View style={styles.detailRow}>
                  <Ionicons name="heart-outline" size={14} color={accent} />
                  <Text style={styles.detailText}>Tipped {formatCurrency(completion.tipAmount)}</Text>
                </View>
              ) : null}
              {completion.customerReview ? (
                <View style={styles.reviewBox}>
                  <Ionicons name="chatbubble-ellipses-outline" size={14} color={RATING_GOLD} />
                  <Text style={styles.reviewText} numberOfLines={3}>“{completion.customerReview}”</Text>
                </View>
              ) : null}
            </View>

            <View style={styles.doneActions}>
              <PressScale onPress={() => handleRepeatBooking(completion)} style={styles.flex1}>
                <View style={styles.primaryBtn}>
                  <BlurView intensity={30} tint="dark" style={StyleSheet.absoluteFill} />
                  <View style={[StyleSheet.absoluteFill, styles.primaryBtnFill]} />
                  <LinearGradient
                    colors={['rgba(255,255,255,0.2)', 'rgba(255,255,255,0)']}
                    style={styles.btnSheen}
                    pointerEvents="none"
                  />
                  <Ionicons name="repeat" size={16} color="#FFFFFF" />
                  <Text style={styles.primaryBtnText}>Book again</Text>
                </View>
              </PressScale>
              <PressScale
                onPress={() => {
                  hapticFeedback('light');
                  handleDeleteOne(completion);
                }}
                accessibilityLabel="Remove from activity"
              >
                <HubGlassIcon icon="trash" accent="red" size={46} iconSize={18} />
              </PressScale>
            </View>
          </Animated.View>
        ) : null}
      </Animated.View>
    );
  };

  const renderContent = () => {
    if (loading) return <SkeletonList count={5} />;

    if (historyTab === 'upcoming') {
      if (upcomingBookings.length === 0) {
        return (
          <LivelyEmptyState
            key="empty-upcoming"
            variant="radar"
            icon="calendar"
            title="Nothing scheduled"
            subtitle="Book ahead and your next wash will count down right here."
            tips={['Schedule a wash for later in the week', 'Pros nearby are ready to book']}
            actions={[
              { key: 'book', label: 'Book a wash', icon: 'sparkles', primary: true, onPress: () => router.push('/owner/explore') },
              ...(washCompletions.length > 0
                ? [{ key: 'past', label: 'See past washes', icon: 'time-outline' as const, onPress: () => setHistoryTab('completed') }]
                : []),
            ]}
            style={styles.emptyState}
          />
        );
      }
      const [next, ...rest] = upcomingBookings;
      return (
        <View>
          {renderNextUp(next!)}
          {rest.length > 0 ? (
            <Animated.View entering={FadeIn.delay(120)} style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Later</Text>
              <View style={styles.sectionLine} />
              <Text style={styles.sectionCount}>{rest.length}</Text>
            </Animated.View>
          ) : null}
          <View style={styles.listGap}>{rest.map(renderUpcomingRow)}</View>
        </View>
      );
    }

    if (washCompletions.length === 0) {
      return (
        <LivelyEmptyState
          key="empty-completed"
          variant="search"
          icon="water"
          title="No washes yet"
          subtitle="Your completed washes, receipts and reviews will live here."
          tips={['Book again from any past wash in one tap', 'Pull down to refresh']}
          actions={[
            { key: 'book', label: 'Book a wash', icon: 'sparkles', primary: true, onPress: () => router.push('/owner/explore') },
            ...(upcomingBookings.length > 0
              ? [{ key: 'up', label: 'View upcoming', icon: 'calendar-outline' as const, onPress: () => setHistoryTab('upcoming') }]
              : []),
          ]}
          style={styles.emptyState}
        />
      );
    }

    let runningIndex = 0;
    return (
      <View>
        {groupedBySection.map(({ key, items }) => (
          <View key={key} style={styles.section}>
            <Animated.View entering={FadeIn.delay(60)} style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>{getSectionLabel(key)}</Text>
              <View style={styles.sectionLine} />
              <Text style={styles.sectionCount}>{items.length}</Text>
            </Animated.View>
            <View style={styles.timeline}>
              <View style={styles.timelineRail} />
              <View style={styles.listGap}>{items.map((c) => renderCompletedCard(c, runningIndex++))}</View>
            </View>
          </View>
        ))}
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <AppHeader
        title="My washes"
        subtitle="Your past and upcoming washes"
        variant="dashboard"
        accountType="customer"
        fullWidth
      />
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={{
          paddingHorizontal: CONTENT_PADDING_H,
          paddingTop: (scrollPad.paddingTop ?? 0) + 14,
          paddingBottom: scrollPad.paddingBottom,
        }}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />}
      >
        {!loading && stats.count > 0 ? (
          <View style={styles.statsRow}>
            <StatTile icon="water" label="Washes" value={String(Math.round(animatedCount))} accent="sky" delay={0} />
            <StatTile icon="wallet" label="Spent" value={`£${Math.round(animatedSpent)}`} accent="green" delay={60} />
            <StatTile
              icon="star"
              label="Avg rating"
              value={stats.avg != null ? stats.avg.toFixed(1) : '—'}
              accent="gold"
              delay={120}
            />
            <StatTile icon="flash" label="This month" value={String(stats.thisMonth)} accent="violet" delay={180} />
          </View>
        ) : null}

        {!loading ? (
          <SegmentedTabs
            value={historyTab}
            onChange={setHistoryTab}
            counts={{ upcoming: upcomingBookings.length, completed: washCompletions.length }}
          />
        ) : null}

        <Animated.View key={historyTab} entering={FadeIn.duration(240)}>
          {renderContent()}
        </Animated.View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  scrollView: { flex: 1 },
  flex1: { flex: 1 },
  flexShrink: { flex: 1, minWidth: 0 },

  statsRow: { flexDirection: 'row', gap: 8, marginBottom: 14 },
  statTile: {
    flex: 1,
    borderRadius: 16,
    paddingVertical: 10,
    paddingHorizontal: 8,
    backgroundColor: CARD_BG,
    alignItems: 'flex-start',
    gap: 4,
  },
  statValue: { color: '#F8FAFC', fontSize: 18, fontWeight: '800', letterSpacing: -0.3 },
  statLabel: { color: 'rgba(148,163,184,0.85)', fontSize: 10.5, fontWeight: '700', letterSpacing: 0.2 },

  segment: {
    flexDirection: 'row',
    padding: 4,
    borderRadius: 16,
    backgroundColor: 'rgba(148,163,184,0.12)',
    marginBottom: 16,
  },
  segmentIndicator: {
    position: 'absolute',
    top: 4,
    bottom: 4,
    left: 4,
    borderRadius: 12,
    overflow: 'hidden',
    shadowColor: '#38BDF8',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.35,
    shadowRadius: 12,
  },
  segmentTab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 10,
  },
  segmentText: { color: 'rgba(203,213,225,0.8)', fontSize: 13, fontWeight: '700' },
  segmentTextActive: { color: '#E0F2FE' },
  segmentCount: {
    minWidth: 20,
    paddingHorizontal: 6,
    height: 18,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(148,163,184,0.18)',
  },
  segmentCountActive: { backgroundColor: 'rgba(56,189,248,0.35)' },
  segmentCountText: { color: 'rgba(203,213,225,0.85)', fontSize: 11, fontWeight: '800' },

  nextCard: { borderRadius: 22, padding: 16, gap: 14, overflow: 'hidden' },
  nextHeaderRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  nextKickerRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  nextKicker: { fontSize: 10.5, fontWeight: '800', letterSpacing: 1.2 },
  liveDotWrap: { width: 10, height: 10, alignItems: 'center', justifyContent: 'center' },
  liveDot: { width: 8, height: 8, borderRadius: 4 },
  liveDotRing: { position: 'absolute', width: 8, height: 8, borderRadius: 4 },
  nextTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  nextTitle: { color: '#F8FAFC', fontSize: 18, fontWeight: '800', letterSpacing: -0.3 },
  nextWhen: { color: 'rgba(203,213,225,0.8)', fontSize: 12.5, fontWeight: '600', marginTop: 2 },
  nextPrice: { color: '#F8FAFC', fontSize: 18, fontWeight: '800' },
  countRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 10,
    borderRadius: 16,
    backgroundColor: 'rgba(2,6,23,0.45)',
  },
  countBlock: { alignItems: 'center', minWidth: 58 },
  countValue: { color: '#F8FAFC', fontSize: 28, fontWeight: '800', fontVariant: ['tabular-nums'], letterSpacing: -0.5 },
  countLabel: { color: 'rgba(148,163,184,0.85)', fontSize: 10, fontWeight: '800', letterSpacing: 1 },
  countSep: { color: 'rgba(148,163,184,0.5)', fontSize: 24, fontWeight: '700', marginBottom: 12 },
  nextMetaRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  nextMetaText: { flex: 1, color: 'rgba(226,232,240,0.8)', fontSize: 12.5, fontWeight: '600' },
  nextActions: { flexDirection: 'row', gap: 10 },

  primaryBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    height: 44,
    borderRadius: 22,
    overflow: 'hidden',
  },
  primaryBtnFill: { backgroundColor: 'rgba(56,189,248,0.45)' },
  btnSheen: { position: 'absolute', left: 0, right: 0, top: 0, height: 22 },
  primaryBtnText: { color: '#FFFFFF', fontSize: 14, fontWeight: '700' },
  ghostBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 16,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.1)',
  },
  ghostBtnText: { color: '#E2E8F0', fontSize: 13.5, fontWeight: '700' },
  iconBtn: {
    width: 30,
    height: 30,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(148,163,184,0.16)',
  },
  sectionHeader: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 18, marginBottom: 10 },
  sectionTitle: {
    color: 'rgba(186,230,253,0.92)',
    fontSize: 10.5,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  sectionLine: { flex: 1, height: StyleSheet.hairlineWidth, backgroundColor: 'rgba(255,255,255,0.12)' },
  sectionCount: { color: 'rgba(148,163,184,0.8)', fontSize: 12, fontWeight: '700' },
  section: { marginBottom: 4 },
  listGap: { gap: 10 },

  rowCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 12,
    borderRadius: 18,
    backgroundColor: CARD_BG,
    overflow: 'hidden',
  },
  rowMain: { flex: 1, minWidth: 0 },
  rowTitle: { color: '#F8FAFC', fontSize: 15, fontWeight: '800' },
  rowSub: { color: 'rgba(226,232,240,0.7)', fontSize: 12, fontWeight: '600', marginTop: 2, flexShrink: 1 },
  rowTrash: { padding: 2 },
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    borderRadius: 999,
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  pillText: { fontSize: 11, fontWeight: '800' },

  timeline: { position: 'relative' },
  timelineRail: {
    position: 'absolute',
    left: 4,
    top: 10,
    bottom: 10,
    width: 2,
    borderRadius: 1,
    backgroundColor: 'rgba(148,163,184,0.18)',
  },
  timelineDot: {
    position: 'absolute',
    left: -18,
    top: 26,
    width: 10,
    height: 10,
    borderRadius: 5,
    shadowOpacity: 0.8,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 0 },
  },
  doneCard: {
    marginLeft: 18,
    borderRadius: 18,
    backgroundColor: CARD_BG,
  },
  cardHighlight: {
    backgroundColor: 'rgba(56,189,248,0.16)',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.35,
    shadowRadius: 12,
    elevation: 4,
  },
  doneHeader: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 12 },
  doneSubRow: { flexDirection: 'row', alignItems: 'center', minWidth: 0 },
  doneRelative: { fontSize: 12, fontWeight: '700', marginTop: 2 },
  doneRight: { alignItems: 'flex-end', gap: 4 },
  donePrice: { color: '#F8FAFC', fontSize: 16, fontWeight: '800' },
  ratingPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 8,
    backgroundColor: RATING_GOLD + '22',
  },
  ratingNum: { color: RATING_GOLD, fontSize: 11, fontWeight: '800' },
  doneBody: { paddingHorizontal: 12, paddingBottom: 12, gap: 12 },
  mapWrap: { height: 120, borderRadius: 14, overflow: 'hidden' },
  detailGrid: { gap: 8 },
  detailRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 8 },
  detailText: { flex: 1, color: 'rgba(226,232,240,0.85)', fontSize: 12.5, fontWeight: '600', lineHeight: 17 },
  reviewBox: {
    flexDirection: 'row',
    gap: 8,
    padding: 10,
    borderRadius: 12,
    backgroundColor: 'rgba(251,191,36,0.1)',
  },
  reviewText: { flex: 1, color: 'rgba(254,243,199,0.9)', fontSize: 12.5, fontStyle: 'italic', lineHeight: 17 },
  doneActions: { flexDirection: 'row', gap: 10, alignItems: 'center' },

  emptyState: { marginTop: 24 },
});
