import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Modal,
  Keyboard,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import Animated, { FadeIn, FadeOut, LinearTransition } from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { Marker, Region } from 'react-native-maps';
import type MapView from 'react-native-maps';
import SafeMapView from '../../../src/components/maps/SafeMapView';
import * as Location from 'expo-location';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  CUSTOMER_SAVED_LOCATIONS_KEY,
  SAVED_LOCATION_LABEL_META,
  loadCustomerSavedLocations,
  savedLocationIcon,
  savedLocationTitle,
  type CustomerSavedLocation,
} from '../../../src/utils/customerSavedLocations';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import AppHeader from '../../../src/components/shared/AppHeader';
import LoadingScreen from '../../../src/components/LoadingScreen';
import StaggerIn from '../../../src/components/shared/StaggerIn';
import { colors } from '../../../src/constants/colors';
import { useOwnerScrollContentPadding } from '../../../src/hooks/useOwnerScrollContentPadding';
import { CONTENT_PADDING_H } from '../../../src/constants/pageStyles';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import {
  LOCATION_PICKER_CLOSE_ZOOM_DELTA,
  LOCATION_PICKER_MAP_STYLE,
  MAP_LOCKED_DARK,
} from '../../../src/constants/mapConstants';
import { MapMarkerCustomerVehicle } from '../../../src/components/maps/MapMarkerViews';
import HubGlassIcon from '../../../src/components/shared/HubGlassIcon';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';

const SKY = colors.SKY;
const NAVY = '#0B1220';

type LocationLabelId = CustomerSavedLocation['label'];
type SavedLocation = CustomerSavedLocation;

const EDITOR_LABELS: LocationLabelId[] = ['home', 'work', 'other'];
const PINNED_LABELS: LocationLabelId[] = ['home', 'work'];
const UK_FALLBACK = { latitude: 51.5074, longitude: -0.1278 };
/** How far the editor's bottom panel overlaps the map. */
const EDITOR_PANEL_OVERLAP = 20;

type Draft = {
  id: string | null;
  label: LocationLabelId;
  customLabel: string;
  address: string;
  latitude: number;
  longitude: number;
};

function formatAddress(r?: Location.LocationGeocodedAddress | null, fallback = 'Selected location') {
  if (!r) return fallback;
  const line = [r.name && r.name !== r.street ? r.name : r.street, r.city, r.postalCode]
    .filter(Boolean)
    .join(', ');
  return line || fallback;
}

async function persistLocations(userId: string, locations: SavedLocation[]) {
  await AsyncStorage.setItem(`${CUSTOMER_SAVED_LOCATIONS_KEY}_${userId}`, JSON.stringify(locations));
}

export default function SavedLocations() {
  const scrollPad = useOwnerScrollContentPadding(true);
  const { user } = useAuth();
  const [locations, setLocations] = useState<SavedLocation[]>([]);
  const [loading, setLoading] = useState(true);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [userCoords, setUserCoords] = useState<{ latitude: number; longitude: number } | null>(null);
  const heroMapRef = useRef<MapView>(null);

  useEffect(() => {
    if (!user?.id) return;
    loadCustomerSavedLocations(user.id).then((list) => {
      setLocations(list);
      setLoading(false);
    });
  }, [user?.id]);

  useEffect(() => {
    void (async () => {
      try {
        const { status } = await Location.getForegroundPermissionsAsync();
        if (status !== 'granted') return;
        const pos = await Location.getLastKnownPositionAsync();
        if (pos) setUserCoords({ latitude: pos.coords.latitude, longitude: pos.coords.longitude });
      } catch {}
    })();
  }, []);

  const fitHeroMap = useCallback(() => {
    const coords = locations.map((l) => ({ latitude: l.latitude, longitude: l.longitude }));
    if (coords.length > 1) {
      heroMapRef.current?.fitToCoordinates(coords, {
        edgePadding: { top: 50, right: 50, bottom: 50, left: 50 },
        animated: true,
      });
    } else {
      const c = coords[0] ?? userCoords ?? UK_FALLBACK;
      heroMapRef.current?.animateToRegion({ ...c, latitudeDelta: 0.02, longitudeDelta: 0.02 }, 400);
    }
  }, [locations, userCoords]);

  useEffect(() => {
    const t = setTimeout(fitHeroMap, 300);
    return () => clearTimeout(t);
  }, [fitHeroMap]);

  const openAdd = async (label: LocationLabelId) => {
    void hapticFeedback('light');
    let coords = userCoords ?? UK_FALLBACK;
    let address = '';
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status === 'granted') {
        const pos =
          (await Location.getLastKnownPositionAsync()) ??
          (await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced }));
        coords = { latitude: pos.coords.latitude, longitude: pos.coords.longitude };
        const [rev] = await Location.reverseGeocodeAsync(coords).catch(() => [null]);
        address = formatAddress(rev, '');
      }
    } catch {}
    setDraft({ id: null, label, customLabel: '', address, ...coords });
  };

  const openEdit = (loc: SavedLocation) => {
    void hapticFeedback('light');
    setDraft({
      id: loc.id,
      label: loc.label,
      customLabel: loc.customLabel ?? '',
      address: loc.address,
      latitude: loc.latitude,
      longitude: loc.longitude,
    });
  };

  const removeLocation = (loc: SavedLocation) => {
    Alert.alert(`Remove ${savedLocationTitle(loc)}?`, loc.address, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: async () => {
          if (!user?.id) return;
          void hapticFeedback('medium');
          const next = locations.filter((l) => l.id !== loc.id);
          setLocations(next);
          await persistLocations(user.id, next);
          if (draft?.id === loc.id) setDraft(null);
        },
      },
    ]);
  };

  const commit = async (d: Draft, base: SavedLocation[]) => {
    if (!user?.id) return;
    const previous = d.id ? base.find((l) => l.id === d.id) : undefined;
    const entry: SavedLocation = {
      ...(previous?.details ? { details: previous.details } : {}),
      id: d.id ?? `loc-${Date.now()}`,
      label: d.label,
      address: d.address.trim(),
      latitude: d.latitude,
      longitude: d.longitude,
      ...(d.label === 'other' && d.customLabel.trim() ? { customLabel: d.customLabel.trim() } : {}),
    };
    const exists = base.some((l) => l.id === entry.id);
    const next = exists ? base.map((l) => (l.id === entry.id ? entry : l)) : [...base, entry];
    setLocations(next);
    await persistLocations(user.id, next);
    void hapticFeedback('medium');
    setDraft(null);
  };

  const saveDraft = async (d: Draft) => {
    if (!user?.id) return;
    const clash = d.label !== 'other' && locations.find((l) => l.label === d.label && l.id !== d.id);
    if (clash) {
      Alert.alert(`${SAVED_LOCATION_LABEL_META[d.label].title} already saved`, `Replace ${clash.address}?`, [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Replace',
          style: 'destructive',
          onPress: () => { void commit(d, locations.filter((l) => l.id !== clash.id)); },
        },
      ]);
      return;
    }
    await commit(d, locations);
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LoadingScreen />
      </SafeAreaView>
    );
  }

  const others = locations.filter((l) => !PINNED_LABELS.includes(l.label));
  const heroCenter = locations[0] ?? userCoords ?? UK_FALLBACK;

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <AppHeader title="Saved Locations" accountType="customer" showBack fullWidth onBack={() => router.back()} />

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={{ paddingHorizontal: CONTENT_PADDING_H, ...scrollPad }}
        showsVerticalScrollIndicator={false}
      >
        <StaggerIn index={0} style={styles.hero}>
          <SafeMapView
            ref={heroMapRef}
            style={StyleSheet.absoluteFill}
            initialRegion={{ ...heroCenter, latitudeDelta: 0.02, longitudeDelta: 0.02 }}
            customMapStyle={LOCATION_PICKER_MAP_STYLE}
            userInterfaceStyle={MAP_LOCKED_DARK}
            scrollEnabled={false}
            zoomEnabled={false}
            rotateEnabled={false}
            pitchEnabled={false}
            toolbarEnabled={false}
            showsUserLocation
            onMapReady={fitHeroMap}
          >
            {locations.map((loc) => (
              <Marker
                key={loc.id}
                coordinate={{ latitude: loc.latitude, longitude: loc.longitude }}
                onPress={() => openEdit(loc)}
                tracksViewChanges={false}
              >
                <View style={styles.heroPin}>
                  <Ionicons name={savedLocationIcon(loc)} size={14} color={NAVY} />
                </View>
              </Marker>
            ))}
          </SafeMapView>
          <View style={styles.heroBadge} pointerEvents="none">
            <Text style={styles.heroBadgeText}>
              {locations.length === 0
                ? 'No places yet'
                : `${locations.length} saved place${locations.length === 1 ? '' : 's'}`}
            </Text>
          </View>
        </StaggerIn>

        <StaggerIn index={1}>
          <View style={styles.list}>
            {PINNED_LABELS.map((label, i) => {
              const loc = locations.find((l) => l.label === label);
              const meta = SAVED_LOCATION_LABEL_META[label];
              return (
                <PlaceRow
                  key={label}
                  first={i === 0}
                  icon={meta.icon}
                  title={meta.title}
                  subtitle={loc ? loc.address : `Set your ${meta.title.toLowerCase()} address`}
                  filled={Boolean(loc)}
                  onPress={() => (loc ? openEdit(loc) : void openAdd(label))}
                  {...(loc ? { onRemove: () => removeLocation(loc) } : {})}
                />
              );
            })}
            {others.map((loc) => (
              <Animated.View key={loc.id} layout={LinearTransition.springify()} exiting={FadeOut.duration(160)}>
                <PlaceRow
                  icon={savedLocationIcon(loc)}
                  title={savedLocationTitle(loc)}
                  subtitle={loc.address}
                  filled
                  onPress={() => openEdit(loc)}
                  onRemove={() => removeLocation(loc)}
                />
              </Animated.View>
            ))}
          </View>
        </StaggerIn>

        <StaggerIn index={2}>
          <TouchableOpacity style={styles.addBtn} onPress={() => { void openAdd('other'); }} activeOpacity={0.88}>
            <BlurView intensity={30} tint="dark" style={StyleSheet.absoluteFill} />
            <View style={[StyleSheet.absoluteFill, styles.glassFillPrimary]} />
            <LinearGradient colors={['rgba(255,255,255,0.2)', 'rgba(255,255,255,0)']} style={styles.glassSheen} pointerEvents="none" />
            <Ionicons name="add" size={20} color="#FFFFFF" />
            <Text style={styles.addBtnText}>Add a place</Text>
          </TouchableOpacity>
          <Text style={styles.footnote}>Saved places show up when you book and on your dashboard.</Text>
        </StaggerIn>
      </ScrollView>

      <Modal
        visible={draft != null}
        animationType="slide"
        presentationStyle="fullScreen"
        statusBarTranslucent
        onRequestClose={() => setDraft(null)}
      >
        {draft ? (
          <LocationEditor
            initial={draft}
            onClose={() => setDraft(null)}
            onSave={saveDraft}
            {...(draft.id
              ? {
                  onDelete: () => {
                    const loc = locations.find((l) => l.id === draft.id);
                    if (loc) removeLocation(loc);
                  },
                }
              : {})}
          />
        ) : null}
      </Modal>
    </SafeAreaView>
  );
}

function PlaceRow({
  icon,
  title,
  subtitle,
  filled,
  first,
  onPress,
  onRemove,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  subtitle: string;
  filled: boolean;
  first?: boolean;
  onPress: () => void;
  onRemove?: () => void;
}) {
  return (
    <TouchableOpacity style={[styles.row, !first && styles.rowDivider]} onPress={onPress} activeOpacity={0.7}>
      {filled ? (
        <HubGlassIcon icon={icon} accent="sky" size={40} />
      ) : (
        <View style={[styles.rowTile, styles.rowTileEmpty]}>
          <Ionicons name={icon} size={18} color={SKY} />
        </View>
      )}
      <View style={styles.rowText}>
        <Text style={styles.rowTitle} numberOfLines={1}>{title}</Text>
        <Text style={[styles.rowSubtitle, !filled && styles.rowSubtitleEmpty]} numberOfLines={1}>
          {subtitle}
        </Text>
      </View>
      {onRemove ? (
        <TouchableOpacity onPress={onRemove} hitSlop={10} style={styles.xBtn} accessibilityLabel={`Remove ${title}`}>
          <Ionicons name="close" size={14} color="rgba(203,213,225,0.9)" />
        </TouchableOpacity>
      ) : (
        <Ionicons name="add-circle" size={22} color={SKY} />
      )}
    </TouchableOpacity>
  );
}

function LocationEditor({
  initial,
  onClose,
  onSave,
  onDelete,
}: {
  initial: Draft;
  onClose: () => void;
  onSave: (d: Draft) => Promise<void>;
  onDelete?: () => void;
}) {
  const insets = useSafeAreaInsets();
  const [d, setD] = useState<Draft>(initial);
  const [query, setQuery] = useState(initial.address);
  const [searching, setSearching] = useState(false);
  const [resolving, setResolving] = useState(false);
  const [saving, setSaving] = useState(false);
  const mapRef = useRef<MapView>(null);
  const skipNextRegionRef = useRef(false);
  const userMovingRef = useRef(false);
  const geocodeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const geocodeRequestRef = useRef(0);

  const moveTo = (latitude: number, longitude: number) => {
    skipNextRegionRef.current = true;
    mapRef.current?.animateToRegion(
      { latitude, longitude, latitudeDelta: LOCATION_PICKER_CLOSE_ZOOM_DELTA, longitudeDelta: LOCATION_PICKER_CLOSE_ZOOM_DELTA },
      450
    );
  };

  const onRegionChangeComplete = (r: Region) => {
    const userMoved = userMovingRef.current;
    userMovingRef.current = false;
    if (userMoved) {
      skipNextRegionRef.current = false;
    } else if (skipNextRegionRef.current) {
      skipNextRegionRef.current = false;
      return;
    } else {
      // Initial layout / zoom settling without a drag — pin hasn't moved.
      return;
    }
    // Pin coordinates update immediately; the street name follows once geocoded.
    setD((prev) => ({ ...prev, latitude: r.latitude, longitude: r.longitude }));
    setResolving(true);
    if (geocodeTimer.current) clearTimeout(geocodeTimer.current);
    geocodeTimer.current = setTimeout(async () => {
      const requestId = ++geocodeRequestRef.current;
      try {
        const [rev] = await Location.reverseGeocodeAsync({ latitude: r.latitude, longitude: r.longitude });
        if (geocodeRequestRef.current !== requestId) return;
        const addr = formatAddress(rev);
        setD((prev) => ({ ...prev, address: addr }));
        setQuery(addr);
      } catch {} finally {
        if (geocodeRequestRef.current === requestId) setResolving(false);
      }
    }, 250);
  };

  const search = async (): Promise<Draft | null> => {
    const q = query.trim();
    if (!q) return null;
    setSearching(true);
    try {
      const [hit] = await Location.geocodeAsync(q);
      if (!hit) {
        Alert.alert('Address not found', 'Try a postcode or a more specific street.');
        return null;
      }
      const [rev] = await Location.reverseGeocodeAsync(hit).catch(() => [null]);
      const next = { ...d, latitude: hit.latitude, longitude: hit.longitude, address: formatAddress(rev, q) };
      setD(next);
      setQuery(next.address);
      moveTo(hit.latitude, hit.longitude);
      void hapticFeedback('light');
      return next;
    } catch {
      Alert.alert('Search failed', 'Could not find that address.');
      return null;
    } finally {
      setSearching(false);
    }
  };

  const goToCurrent = async () => {
    void hapticFeedback('light');
    try {
      const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      const coords = { latitude: pos.coords.latitude, longitude: pos.coords.longitude };
      const [rev] = await Location.reverseGeocodeAsync(coords).catch(() => [null]);
      const addr = formatAddress(rev);
      setD((prev) => ({ ...prev, ...coords, address: addr }));
      setQuery(addr);
      moveTo(coords.latitude, coords.longitude);
    } catch {
      Alert.alert('Location unavailable', 'Allow location access to use where you are.');
    }
  };

  const save = async () => {
    Keyboard.dismiss();
    setSaving(true);
    try {
      let next: Draft | null = d;
      // A typed address that hasn't been looked up yet gets geocoded before saving.
      if (query.trim() && query.trim() !== d.address) next = await search();
      if (!next || !next.address.trim()) return;
      await onSave(next);
    } finally {
      setSaving(false);
    }
  };

  const canSave = !saving && !resolving && Boolean(query.trim() || d.address.trim());

  return (
    <KeyboardAvoidingView style={styles.editorRoot} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <View style={styles.editorMap}>
        <SafeMapView
          ref={mapRef}
          style={styles.editorMapView}
          initialRegion={{
            latitude: initial.latitude,
            longitude: initial.longitude,
            latitudeDelta: LOCATION_PICKER_CLOSE_ZOOM_DELTA,
            longitudeDelta: LOCATION_PICKER_CLOSE_ZOOM_DELTA,
          }}
          onTouchStart={() => { userMovingRef.current = true; }}
          onPanDrag={() => { userMovingRef.current = true; }}
          onRegionChangeComplete={onRegionChangeComplete}
          customMapStyle={LOCATION_PICKER_MAP_STYLE}
          userInterfaceStyle={MAP_LOCKED_DARK}
          showsUserLocation
          rotateEnabled={false}
          pitchEnabled={false}
          toolbarEnabled={false}
        />
        <View pointerEvents="none" style={styles.editorPin}>
          <MapMarkerCustomerVehicle size={42} variant="car" />
        </View>

        <View style={[styles.editorTopBar, { top: insets.top + 8 }]}>
          <TouchableOpacity onPress={onClose} style={styles.roundBtn} accessibilityLabel="Close">
            <Ionicons name="close" size={20} color="#F8FAFC" />
          </TouchableOpacity>
          <View style={styles.editorTitlePill}>
            <Text style={styles.editorTitle}>{initial.id ? 'Edit place' : 'New place'}</Text>
          </View>
          {onDelete ? (
            <TouchableOpacity onPress={onDelete} style={styles.roundBtn} accessibilityLabel="Delete place">
              <Ionicons name="trash-outline" size={18} color="#F87171" />
            </TouchableOpacity>
          ) : (
            <View style={styles.roundBtnSpacer} />
          )}
        </View>

        <TouchableOpacity onPress={() => { void goToCurrent(); }} style={styles.locateBtn} accessibilityLabel="Use current location">
          <Ionicons name="locate" size={18} color={SKY} />
        </TouchableOpacity>
        <View pointerEvents="none" style={[styles.mapHint, { top: insets.top + 60 }]}>
          {resolving ? <ActivityIndicator size="small" color={SKY} /> : null}
          <Text style={styles.mapHintText}>{resolving ? 'Finding address…' : 'Drag the map to move the pin'}</Text>
        </View>
      </View>

      <View style={[styles.editorPanel, { paddingBottom: Math.max(insets.bottom, 16) + 4 }]}>
        <View style={styles.searchPill}>
          <Ionicons name="search" size={16} color="rgba(148,163,184,0.9)" />
          <TextInput
            style={styles.searchInput}
            value={query}
            onChangeText={setQuery}
            onSubmitEditing={() => { void search(); }}
            placeholder="Search postcode or address"
            placeholderTextColor="rgba(148,163,184,0.7)"
            returnKeyType="search"
            autoCapitalize="words"
          />
          {searching ? <ActivityIndicator size="small" color={SKY} /> : null}
        </View>

        <View style={styles.labelRow}>
          {EDITOR_LABELS.map((label) => {
            const active = d.label === label || (label === 'other' && d.label === 'gym');
            const meta = SAVED_LOCATION_LABEL_META[label];
            return (
              <TouchableOpacity
                key={label}
                onPress={() => { void hapticFeedback('light'); setD((prev) => ({ ...prev, label })); }}
                style={[styles.labelChip, active && styles.labelChipActive]}
                activeOpacity={0.85}
              >
                <Ionicons name={meta.icon} size={15} color={active ? '#7DD3FC' : 'rgba(148,163,184,0.9)'} />
                <Text style={[styles.labelChipText, active && styles.labelChipTextActive]}>{meta.title}</Text>
              </TouchableOpacity>
            );
          })}
        </View>

        {d.label === 'other' ? (
          <Animated.View entering={FadeIn.duration(160)}>
            <TextInput
              style={styles.nameInput}
              value={d.customLabel}
              onChangeText={(t) => setD((prev) => ({ ...prev, customLabel: t }))}
              placeholder="Name this place (optional)"
              placeholderTextColor="rgba(148,163,184,0.7)"
              maxLength={24}
            />
          </Animated.View>
        ) : null}

        <TouchableOpacity
          onPress={() => { void save(); }}
          disabled={!canSave}
          style={[styles.saveBtn, !canSave && styles.disabled]}
          activeOpacity={0.88}
        >
          <BlurView intensity={30} tint="dark" style={StyleSheet.absoluteFill} />
          <View style={[StyleSheet.absoluteFill, styles.glassFillPrimary]} />
          <LinearGradient colors={['rgba(255,255,255,0.2)', 'rgba(255,255,255,0)']} style={styles.glassSheen} pointerEvents="none" />
          {saving ? (
            <ActivityIndicator size="small" color="#FFFFFF" />
          ) : (
            <Text style={styles.saveText}>
              Save {d.label === 'other' || d.label === 'gym' ? 'place' : SAVED_LOCATION_LABEL_META[d.label].title}
            </Text>
          )}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  scroll: { flex: 1 },

  hero: {
    height: 190,
    borderRadius: 22,
    overflow: 'hidden',
    marginTop: 4,
    marginBottom: 16,
    backgroundColor: '#1E293B',
  },
  heroPin: {
    width: 30,
    height: 30,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: SKY,
    borderWidth: 2,
    borderColor: NAVY,
  },
  heroBadge: {
    position: 'absolute',
    left: 12,
    bottom: 12,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 10,
    backgroundColor: 'rgba(8,20,38,0.82)',
  },
  heroBadgeText: { color: '#E2E8F0', fontSize: 12, fontWeight: '700' },

  list: {
    borderRadius: 20,
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 14, paddingVertical: 12 },
  rowDivider: { borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: 'rgba(255,255,255,0.12)' },
  rowTile: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  rowTileEmpty: { backgroundColor: 'rgba(56,189,248,0.12)' },
  rowText: { flex: 1, minWidth: 0 },
  rowTitle: { color: '#F8FAFC', fontSize: 15, fontWeight: '700' },
  rowSubtitle: { color: 'rgba(226,232,240,0.7)', fontSize: 13, fontWeight: '500', marginTop: 2 },
  rowSubtitleEmpty: { color: SKY, fontWeight: '600' },
  xBtn: {
    width: 26,
    height: 26,
    borderRadius: 13,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(148,163,184,0.16)',
  },

  addBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    height: 52,
    borderRadius: 26,
    overflow: 'hidden',
    marginTop: 16,
  },
  addBtnText: { color: '#FFFFFF', fontSize: 16, fontWeight: '700' },
  glassFillPrimary: { backgroundColor: 'rgba(56,189,248,0.45)' },
  glassSheen: { position: 'absolute', left: 0, right: 0, top: 0, height: 26 },
  footnote: {
    color: 'rgba(226,232,240,0.6)',
    fontSize: 12,
    fontWeight: '500',
    textAlign: 'center',
    marginTop: 10,
  },

  editorRoot: { flex: 1, backgroundColor: colors.BG ?? '#0A1929' },
  editorMap: { flex: 1, backgroundColor: '#0E1626' },
  /** Ends where the panel starts so Apple's logo/legal stay visible and the centre matches the visible area. */
  editorMapView: { ...StyleSheet.absoluteFill, bottom: EDITOR_PANEL_OVERLAP },
  editorPin: {
    ...StyleSheet.absoluteFill,
    bottom: EDITOR_PANEL_OVERLAP,
    alignItems: 'center',
    justifyContent: 'center',
  },
  editorTopBar: {
    position: 'absolute',
    left: 14,
    right: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  roundBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(8,20,38,0.85)',
  },
  roundBtnSpacer: { width: 40, height: 40 },
  editorTitlePill: {
    paddingHorizontal: 16,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    backgroundColor: 'rgba(8,20,38,0.85)',
  },
  editorTitle: { color: '#F8FAFC', fontSize: 15, fontWeight: '800' },
  locateBtn: {
    position: 'absolute',
    right: 14,
    bottom: EDITOR_PANEL_OVERLAP + 36,
    width: 42,
    height: 42,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(8,20,38,0.88)',
  },
  mapHint: {
    position: 'absolute',
    alignSelf: 'center',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    backgroundColor: 'rgba(8,20,38,0.82)',
  },
  mapHintText: { color: 'rgba(226,232,240,0.9)', fontSize: 12, fontWeight: '700' },

  editorPanel: {
    paddingHorizontal: 16,
    paddingTop: 16,
    gap: 12,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    marginTop: -EDITOR_PANEL_OVERLAP,
    backgroundColor: colors.BG ?? '#0A1929',
  },
  searchPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    height: 48,
    paddingHorizontal: 16,
    borderRadius: 24,
    backgroundColor: 'rgba(30,41,59,0.9)',
  },
  searchInput: { flex: 1, color: '#F8FAFC', fontSize: 15, fontWeight: '600', paddingVertical: 0 },
  labelRow: { flexDirection: 'row', gap: 8 },
  labelChip: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(148,163,184,0.12)',
  },
  labelChipActive: {
    backgroundColor: 'rgba(56,189,248,0.16)',
    shadowColor: '#38BDF8',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.35,
    shadowRadius: 12,
  },
  labelChipText: { color: 'rgba(226,232,240,0.7)', fontSize: 14, fontWeight: '700' },
  labelChipTextActive: { color: '#7DD3FC' },
  nameInput: {
    height: 46,
    paddingHorizontal: 16,
    borderRadius: 23,
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '600',
    backgroundColor: 'rgba(30,41,59,0.9)',
  },
  saveBtn: {
    height: 52,
    borderRadius: 26,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  saveText: { color: '#FFFFFF', fontSize: 16, fontWeight: '700' },
  disabled: { opacity: 0.45 },
});
