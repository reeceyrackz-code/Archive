import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Dimensions,
  Switch,
  TouchableOpacity,
  Linking,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from '../../../src/components/shared/AppHeader';
import GradientIconBox from '../../../src/components/shared/GradientIconBox';
import HubGlassIcon from '../../../src/components/shared/HubGlassIcon';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { useOwnerScrollContentPadding } from '../../../src/hooks/useOwnerScrollContentPadding';
import { useTheme } from '../../../src/contexts/ThemeContext';
import { colors } from '../../../src/constants/colors';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const POLICY_URL = 'https://www.instagram.com/wishawash.app/';

export default function AppearanceSettings() {
  const scrollPad = useOwnerScrollContentPadding(true);
  const { isDark, setColorScheme } = useTheme();

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <AppHeader
        title="Appearance"
        accountType="customer"
        showBack
        fullWidth
        onBack={() => {
          hapticFeedback('light');
          router.back();
        }}
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, scrollPad]}
        showsVerticalScrollIndicator={false}
      >
        <Text style={styles.sectionLabel}>Theme</Text>
        <View style={styles.group}>
          <View style={styles.settingRow}>
            <View style={styles.settingIconWrapper}>
              <GradientIconBox icon="moon" preset="sky" boxSize={40} size={20} borderRadius={20} elevated />
            </View>
            <View style={styles.settingContent}>
              <Text style={styles.settingTitle}>Dark mode</Text>
              <Text style={styles.settingSubtitle}>{isDark ? 'On' : 'Off'} — saved on this device</Text>
            </View>
            <Switch
              value={isDark}
              onValueChange={(value) => {
                hapticFeedback('light');
                setColorScheme(value ? 'dark' : 'light');
              }}
              trackColor={{ false: '#374151', true: SKY }}
              thumbColor={isDark ? '#FFFFFF' : '#9CA3AF'}
              accessibilityLabel="Dark mode"
            />
          </View>
        </View>

        <Text style={[styles.sectionLabel, { marginTop: 22 }]}>Legal</Text>
        <View style={styles.group}>
          <TouchableOpacity
            style={styles.linkRow}
            onPress={() => {
              hapticFeedback('light');
              void Linking.openURL(POLICY_URL);
            }}
            activeOpacity={0.85}
            accessibilityRole="button"
            accessibilityLabel="Privacy policy"
          >
            <HubGlassIcon icon="document-text-outline" accent="sky" size={36} />
            <Text style={styles.linkCardText}>Privacy policy</Text>
            <Ionicons name="chevron-forward" size={18} color="rgba(148,163,184,0.75)" />
          </TouchableOpacity>
          <View style={styles.divider} />
          <TouchableOpacity
            style={styles.linkRow}
            onPress={() => {
              hapticFeedback('light');
              void Linking.openURL(POLICY_URL);
            }}
            activeOpacity={0.85}
            accessibilityRole="button"
            accessibilityLabel="Cookie policy"
          >
            <HubGlassIcon icon="shield-checkmark-outline" accent="green" size={36} />
            <Text style={styles.linkCardText}>Cookie policy</Text>
            <Ionicons name="chevron-forward" size={18} color="rgba(148,163,184,0.75)" />
          </TouchableOpacity>
          <View style={styles.divider} />
          <TouchableOpacity
            style={styles.linkRow}
            onPress={() => {
              hapticFeedback('light');
              void Linking.openURL(POLICY_URL);
            }}
            activeOpacity={0.85}
            accessibilityRole="button"
            accessibilityLabel="Terms and conditions"
          >
            <HubGlassIcon icon="reader-outline" accent="violet" size={36} />
            <Text style={styles.linkCardText}>Terms and conditions</Text>
            <Ionicons name="chevron-forward" size={18} color="rgba(148,163,184,0.75)" />
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 120, paddingHorizontal: isSmallScreen ? 12 : 20 },
  sectionLabel: {
    color: 'rgba(186,230,253,0.92)',
    fontSize: 10.5,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
    marginBottom: 10,
  },
  group: {
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 20,
    overflow: 'hidden',
  },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 14,
  },
  settingIconWrapper: { marginRight: 12 },
  settingContent: { flex: 1 },
  settingTitle: {
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '700',
    marginBottom: 3,
  },
  settingSubtitle: {
    color: 'rgba(226,232,240,0.7)',
    fontSize: 13,
    fontWeight: '600',
  },
  linkRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  divider: {
    height: StyleSheet.hairlineWidth,
    backgroundColor: 'rgba(255,255,255,0.12)',
    marginLeft: 64,
  },
  linkCardText: {
    flex: 1,
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '600',
  },
});
