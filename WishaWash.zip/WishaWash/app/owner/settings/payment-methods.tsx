import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from '../../../src/components/shared/AppHeader';
import EmptyState from '../../../src/components/shared/EmptyState';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { useOwnerScrollContentPadding } from '../../../src/hooks/useOwnerScrollContentPadding';
import { CONTENT_PADDING_H } from '../../../src/constants/pageStyles';
import { customerTheme } from '../../../src/constants/customerTheme';
import { colors } from '../../../src/constants/colors';
import HubGlassIcon from '../../../src/components/shared/HubGlassIcon';
import { FONT_SIZES, SPACING } from '../../../src/constants/designTokens';

const SKY = colors.SKY;
const BG = colors.BG;

type PaymentMethod = {
  id: string;
  type: 'card' | 'apple_pay' | 'google_pay';
  brand?: 'visa' | 'mastercard' | 'amex' | 'other';
  name: string;
  last4?: string;
  expiry?: string;
  isDefault: boolean;
};

const CARD_BRAND_COLORS: Record<string, string> = {
  visa: '#1A1F71',
  mastercard: '#EB001B',
  amex: '#006FCF',
  other: SKY,
};

function getCardBrand(name: string): 'visa' | 'mastercard' | 'amex' | 'other' {
  const lower = name.toLowerCase();
  if (lower.includes('visa')) return 'visa';
  if (lower.includes('mastercard') || lower.includes('master')) return 'mastercard';
  if (lower.includes('amex') || lower.includes('american')) return 'amex';
  return 'other';
}

function getPaymentIcon(type: string): keyof typeof Ionicons.glyphMap {
  switch (type) {
    case 'apple_pay': return 'logo-apple';
    case 'google_pay': return 'logo-google';
    default: return 'card';
  }
}

function PaymentMethodCard({
  method,
  onSetDefault,
  onOptions,
}: Readonly<{
  method: PaymentMethod;
  onSetDefault: (id: string) => void;
  onOptions: (method: PaymentMethod) => void;
}>) {
  const brand = method.brand ?? getCardBrand(method.name);
  const accent = CARD_BRAND_COLORS[brand] || SKY;
  return (
    <View style={styles.paymentCard}>
      <View style={styles.paymentIconWrapper}>
        <HubGlassIcon icon={getPaymentIcon(method.type)} accent={accent} size={44} />
      </View>
      <View style={styles.paymentContent}>
        <View style={styles.paymentHeader}>
          <Text style={styles.paymentName} numberOfLines={1}>{method.name}</Text>
          {method.isDefault ? (
            <View style={styles.defaultBadge}>
              <Ionicons name="checkmark-circle" size={12} color="#10B981" />
              <Text style={styles.defaultText}>Default</Text>
            </View>
          ) : (
            <TouchableOpacity
              style={styles.setDefaultBtn}
              onPress={() => onSetDefault(method.id)}
              activeOpacity={0.8}
            >
              <Text style={styles.setDefaultText}>Set default</Text>
            </TouchableOpacity>
          )}
        </View>
        {method.last4 ? <Text style={styles.paymentLast4}>•••• {method.last4}</Text> : null}
        {method.expiry ? <Text style={styles.paymentExpiry}>Expires {method.expiry}</Text> : null}
      </View>
      <TouchableOpacity style={styles.moreButton} onPress={() => onOptions(method)} activeOpacity={0.7}>
        <Ionicons name="ellipsis-vertical" size={20} color="#94A3B8" />
      </TouchableOpacity>
    </View>
  );
}

export default function PaymentMethods() {
  const scrollPad = useOwnerScrollContentPadding(true);
  const params = useLocalSearchParams<{ addedCard?: string }>();
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([
    {
      id: '1',
      type: 'card',
      brand: 'visa',
      name: 'Visa ending in 4242',
      last4: '4242',
      expiry: '12/25',
      isDefault: true,
    },
    {
      id: '2',
      type: 'card',
      brand: 'mastercard',
      name: 'Mastercard ending in 5555',
      last4: '5555',
      expiry: '08/26',
      isDefault: false,
    },
  ]);
  const [loading] = useState(false);

  useEffect(() => {
    const added = params.addedCard;
    if (!added) return;
    try {
      const card = JSON.parse(added) as PaymentMethod;
      if (card.id && card.name) {
        setPaymentMethods((prev) => {
          const next = [...prev, card];
          if (next.length === 1) next[0].isDefault = true;
          return next;
        });
        hapticFeedback('light');
      }
    } catch (e) {
      if (__DEV__) console.warn('Parse addedCard failed', e);
    }
    router.replace('/owner/settings/payment-methods');
  }, [params.addedCard]);

  const setAsDefault = (id: string) => {
    hapticFeedback('light');
    setPaymentMethods((prev) =>
      prev.map((m) => ({ ...m, isDefault: m.id === id }))
    );
  };

  const performRemove = (methodId: string, setNewDefault = false) => {
    setPaymentMethods((prev) => {
      const next = prev.filter((m) => m.id !== methodId);
      if (setNewDefault && next.length > 0) next[0].isDefault = true;
      return next;
    });
    hapticFeedback('light');
  };

  const confirmRemoveMethod = (method: PaymentMethod) => {
    const removeAnyway = () => performRemove(method.id, true);
    const removeOnly = () => performRemove(method.id);
    if (method.isDefault && paymentMethods.length > 1) {
      Alert.alert(
        'Remove default card?',
        'Set another card as default first, or remove this card and the next one will become default.',
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Remove anyway', style: 'destructive', onPress: removeAnyway },
        ]
      );
      return;
    }
    Alert.alert(
      'Remove card',
      `Remove ${method.name} from your payment methods?`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Remove', style: 'destructive', onPress: removeOnly },
      ]
    );
  };

  const showCardOptions = (method: PaymentMethod) => {
    hapticFeedback('light');
    const setDefault = () => setAsDefault(method.id);
    const remove = () => confirmRemoveMethod(method);
    const buttons: Array<{ text: string; onPress?: () => void; style?: 'default' | 'cancel' | 'destructive' }> = [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Remove card', style: 'destructive' as const, onPress: remove },
    ];
    if (method.isDefault === false) {
      buttons.splice(1, 0, { text: 'Set as default', onPress: setDefault });
    }
    Alert.alert(method.name, undefined, buttons);
  };

  const handleAddPaymentMethod = () => {
    hapticFeedback('light');
    router.push('/owner/settings/add-payment-method');
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      <AppHeader
        title="Payment Methods"
        subtitle="Secure cards and preferred payment"
        accountType="customer"
        showBack
        fullWidth
        onBack={() => { hapticFeedback('light'); router.back(); }}
        rightAction={
          <TouchableOpacity
            style={styles.addButton}
            onPress={handleAddPaymentMethod}
            activeOpacity={0.8}
          >
            <Ionicons name="add" size={24} color={SKY} />
          </TouchableOpacity>
        }
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingHorizontal: CONTENT_PADDING_H,
            ...scrollPad,
          },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {loading && (
          <View style={styles.loadingWrap}>
            <ActivityIndicator size="large" color={SKY} />
            <Text style={styles.loadingText}>Loading payment methods…</Text>
          </View>
        )}
        {!loading && paymentMethods.length === 0 && (
          <EmptyState
            icon="card-outline"
            title="No payment methods"
            subtitle="Add a card to pay for washes quickly. You can add one at checkout or tap below."
            actionLabel="Add payment method"
            onAction={handleAddPaymentMethod}
            iconColor={SKY}
            style={styles.emptyState}
          />
        )}
        {!loading && paymentMethods.length > 0 && (
          <>
            <Text style={styles.sectionTitle}>Your cards</Text>
            <View style={styles.cardGroup}>
              {paymentMethods.map((method, index) => (
                <View key={method.id}>
                  {index > 0 ? <View style={styles.divider} /> : null}
                  <PaymentMethodCard
                    method={method}
                    onSetDefault={setAsDefault}
                    onOptions={showCardOptions}
                  />
                </View>
              ))}
            </View>

            <View style={styles.securityNote}>
              <Ionicons name="shield-checkmark" size={18} color={SKY} />
              <Text style={styles.securityText}>
                Payments are secured by Stripe. Your full card number is never stored.
              </Text>
            </View>
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  scrollView: { flex: 1 },
  scrollContent: {},
  loadingWrap: {
    minHeight: 260,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: SKY,
    fontSize: FONT_SIZES.md,
    fontWeight: '600',
  },
  emptyState: { minHeight: 280 },
  sectionTitle: {
    color: 'rgba(186,230,253,0.92)',
    fontSize: 10.5,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
    marginBottom: SPACING.md,
  },
  addButton: {
    width: 44,
    height: 44,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(148,196,220,0.26)',
    backgroundColor: 'rgba(255,255,255,0.05)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardGroup: {
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 20,
    overflow: 'hidden',
  },
  divider: {
    height: StyleSheet.hairlineWidth,
    backgroundColor: 'rgba(255,255,255,0.12)',
    marginLeft: 74,
  },
  paymentCard: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SPACING.lg,
    paddingVertical: 14,
  },
  paymentIconWrapper: {
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 14,
  },
  paymentContent: {
    flex: 1,
    minWidth: 0,
  },
  paymentHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 4,
  },
  paymentName: {
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '700',
    flexShrink: 1,
  },
  defaultBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(16,185,129,0.18)',
    paddingVertical: 3,
    paddingHorizontal: 8,
    borderRadius: 999,
  },
  defaultText: {
    color: '#34D399',
    fontSize: 11,
    fontWeight: '700',
  },
  setDefaultBtn: {
    paddingVertical: SPACING.xs,
    paddingHorizontal: 10,
    borderRadius: 999,
    backgroundColor: 'rgba(56,189,248,0.16)',
  },
  setDefaultText: {
    color: '#7DD3FC',
    fontSize: 12,
    fontWeight: '700',
  },
  paymentLast4: {
    color: 'rgba(226,232,240,0.7)',
    fontSize: 13,
    fontWeight: '500',
    marginBottom: 2,
  },
  paymentExpiry: {
    color: 'rgba(186,230,253,0.8)',
    fontSize: 13,
    fontWeight: '500',
  },
  moreButton: {
    padding: 8,
    margin: -8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  securityNote: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginTop: 20,
    paddingHorizontal: 4,
  },
  securityText: {
    color: 'rgba(226,232,240,0.7)',
    fontSize: 13,
    fontWeight: '500',
    lineHeight: 18,
    flex: 1,
  },
});
