/**
 * Opened from the password reset email (`waw://reset-password#access_token=…&type=recovery`).
 */
import { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Dimensions, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import Animated, { FadeIn, FadeOut } from 'react-native-reanimated';
import { router, useLocalSearchParams } from 'expo-router';
import * as Linking from 'expo-linking';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../src/lib/supabase';
import BubbleBackground from '../src/components/shared/BubbleBackground';
import BookingBottomSheetOverlay from '../src/components/booking/BookingBottomSheetOverlay';
import HubGlassIcon from '../src/components/shared/HubGlassIcon';
import AuthField from '../src/components/auth/AuthField';
import AuthSubmitButton from '../src/components/auth/AuthSubmitButton';
import { hapticFeedback } from '../src/services/HapticFeedbackService';
import { readLinkParams } from '../src/utils/authLinkParams';

const WINDOW_H = Dimensions.get('window').height;
const MIN_LENGTH = 6;
const NO_LINK_FALLBACK_MS = 2000;

type Phase = 'verifying' | 'ready' | 'done' | 'invalid';

function passwordStrength(pw: string): 0 | 1 | 2 | 3 {
  if (pw.length < MIN_LENGTH) return pw.length ? 1 : 0;
  let score = 1;
  if (pw.length >= 10) score += 1;
  if (/\d/.test(pw) && /[A-Za-z]/.test(pw) && (/[^A-Za-z0-9]/.test(pw) || /[A-Z]/.test(pw))) score += 1;
  return Math.min(score, 3) as 1 | 2 | 3;
}

const STRENGTH = [
  { label: '', color: 'transparent' },
  { label: 'Weak', color: '#F87171' },
  { label: 'Good', color: '#FBBF24' },
  { label: 'Strong', color: '#34D399' },
] as const;

function friendlyUpdateError(raw: unknown): string {
  const err = (raw ?? {}) as { code?: string; message?: string };
  const code = String(err.code ?? '').toLowerCase();
  const msg = String(err.message ?? '').toLowerCase();
  if (code === 'same_password' || msg.includes('different from the old')) {
    return 'Your new password must be different from your old one.';
  }
  if (code === 'weak_password' || msg.includes('password should')) {
    return 'That password is too easy to guess. Try a longer one.';
  }
  if (msg.includes('session') || msg.includes('jwt')) {
    return 'This reset link has expired. Request a new one.';
  }
  if (msg.includes('network') || msg.includes('fetch') || msg.includes('timeout')) {
    return 'Connection problem. Check your signal and try again.';
  }
  return 'Could not update your password. Please try again.';
}

export default function ResetPasswordScreen() {
  const params = useLocalSearchParams();
  const url = Linking.useURL();
  const [phase, setPhase] = useState<Phase>('verifying');
  const [invalidReason, setInvalidReason] = useState('This reset link has expired or was already used.');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const handledRef = useRef(false);

  useEffect(() => {
    if (handledRef.current) return;
    let cancelled = false;

    const verify = async () => {
      const link = readLinkParams(url);
      const pick = (key: string) =>
        (typeof params[key] === 'string' ? (params[key] as string) : undefined) ?? link[key];
      const accessToken = pick('access_token');
      const refreshToken = pick('refresh_token');
      const tokenHash = pick('token_hash');
      const code = pick('code');
      const linkError = pick('error_description') ?? pick('error');
      const alreadyVerified = pick('ready') === '1';

      if (!accessToken && !tokenHash && !code && !linkError && !alreadyVerified && url === null) return;
      handledRef.current = true;

      try {
        if (linkError) throw new Error(linkError);
        if (accessToken && refreshToken) {
          const { error: e } = await supabase.auth.setSession({ access_token: accessToken, refresh_token: refreshToken });
          if (e) throw e;
        } else if (tokenHash) {
          const { error: e } = await supabase.auth.verifyOtp({ token_hash: tokenHash, type: 'recovery' });
          if (e) throw e;
        } else if (code) {
          const { error: e } = await supabase.auth.exchangeCodeForSession(code);
          if (e) throw e;
        }
        const { data } = await supabase.auth.getSession();
        if (!data.session) throw new Error('missing session');
        if (!cancelled) setPhase('ready');
      } catch {
        if (!cancelled) {
          setInvalidReason('This reset link has expired or was already used.');
          setPhase('invalid');
        }
      }
    };

    void verify();
    return () => {
      cancelled = true;
    };
  }, [params, url]);

  useEffect(() => {
    const t = setTimeout(() => {
      if (handledRef.current) return;
      handledRef.current = true;
      setInvalidReason("We couldn't read this reset link.");
      setPhase('invalid');
    }, NO_LINK_FALLBACK_MS);
    return () => clearTimeout(t);
  }, []);

  const strength = passwordStrength(password);
  const longEnough = password.length >= MIN_LENGTH;
  const matches = confirm.length > 0 && confirm === password;
  const canSave = longEnough && matches && !saving;

  const save = async () => {
    if (!canSave) return;
    void hapticFeedback('medium');
    setSaving(true);
    setError(null);
    try {
      const { error: e } = await supabase.auth.updateUser({ password });
      if (e) throw e;
      void hapticFeedback('rigid');
      setPhase('done');
    } catch (e) {
      setError(friendlyUpdateError(e));
    } finally {
      setSaving(false);
    }
  };

  const goIn = () => router.replace('/');
  const requestNewLink = async () => {
    await supabase.auth.signOut().catch(() => {});
    router.replace({ pathname: '/auth/login', params: { reset: '1' } } as any);
  };

  const sheetHeight = Math.min(WINDOW_H * (phase === 'ready' ? 0.6 : 0.42), phase === 'ready' ? 500 : 360);

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" />
      <BubbleBackground accountType="customer" />

      {phase === 'verifying' ? (
        <View style={styles.center}>
          <ActivityIndicator color="#87CEEB" />
          <Text style={styles.centerText}>Checking your reset link…</Text>
        </View>
      ) : null}

      <BookingBottomSheetOverlay
        visible={phase !== 'verifying'}
        onClose={phase === 'ready' || phase === 'done' ? goIn : () => void requestNewLink()}
        maxHeightRatio={0.64}
        compact
        translucent
        fillBody
        closeVariant="plain"
        sheetStyle={{ height: sheetHeight, maxHeight: sheetHeight }}
      >
        {phase === 'ready' ? (
          <Animated.View key="ready" entering={FadeIn.duration(260)} style={styles.flex}>
            <View style={styles.header}>
              <HubGlassIcon icon="key" accent="sky" size={46} />
              <View style={styles.headerText}>
                <Text style={styles.title}>Set a new password</Text>
                <Text style={styles.subtitle}>Choose something you haven't used before.</Text>
              </View>
            </View>

            <View style={styles.fields}>
              <AuthField
                icon="lock-closed-outline"
                placeholder="New password"
                value={password}
                onChangeText={(t) => {
                  setPassword(t);
                  setError(null);
                }}
                secureTextEntry={!showPassword}
                autoCapitalize="none"
                autoComplete="password-new"
                textContentType="newPassword"
                returnKeyType="next"
                autoFocus
                accessibilityLabel="New password"
                trailing={
                  <TouchableOpacity
                    onPress={() => {
                      void hapticFeedback('light');
                      setShowPassword((v) => !v);
                    }}
                    accessibilityLabel={showPassword ? 'Hide password' : 'Show password'}
                    hitSlop={10}
                  >
                    <Ionicons
                      name={showPassword ? 'eye-off-outline' : 'eye-outline'}
                      size={19}
                      color="rgba(148,163,184,0.9)"
                    />
                  </TouchableOpacity>
                }
              />
              {password.length > 0 ? (
                <Animated.View entering={FadeIn} exiting={FadeOut} style={styles.strengthRow}>
                  <View style={styles.strengthBars}>
                    {[1, 2, 3].map((n) => (
                      <View
                        key={n}
                        style={[styles.strengthBar, n <= strength && { backgroundColor: STRENGTH[strength].color }]}
                      />
                    ))}
                  </View>
                  <Text style={[styles.strengthLabel, { color: STRENGTH[strength].color }]}>
                    {longEnough ? STRENGTH[strength].label : `${MIN_LENGTH - password.length} more characters`}
                  </Text>
                </Animated.View>
              ) : null}
              <AuthField
                icon="shield-checkmark-outline"
                placeholder="Confirm new password"
                value={confirm}
                onChangeText={(t) => {
                  setConfirm(t);
                  setError(null);
                }}
                secureTextEntry={!showPassword}
                autoCapitalize="none"
                autoComplete="password-new"
                textContentType="newPassword"
                returnKeyType="done"
                onSubmitEditing={() => void save()}
                valid={matches && longEnough}
                accessibilityLabel="Confirm new password"
              />
              {confirm.length > 0 && !matches ? (
                <Text style={styles.mismatch}>Passwords don't match yet</Text>
              ) : null}
            </View>

            {error ? (
              <Animated.View entering={FadeIn} style={styles.errorRow}>
                <Ionicons name="alert-circle" size={16} color="#F87171" />
                <Text style={styles.errorText}>{error}</Text>
              </Animated.View>
            ) : null}

            <View style={styles.spacer} />
            <AuthSubmitButton
              label={saving ? 'Saving…' : 'Save password'}
              icon="checkmark"
              onPress={() => void save()}
              loading={saving}
              disabled={!longEnough || !matches}
            />
          </Animated.View>
        ) : null}

        {phase === 'done' ? (
          <Animated.View key="done" entering={FadeIn.duration(260)} style={styles.flex}>
            <View style={styles.header}>
              <HubGlassIcon icon="checkmark-done" accent="green" size={46} />
              <View style={styles.headerText}>
                <Text style={styles.title}>Password updated</Text>
                <Text style={styles.subtitle}>You're all set. Use your new password next time you sign in.</Text>
              </View>
            </View>
            <View style={styles.spacer} />
            <AuthSubmitButton label="Continue" icon="arrow-forward" onPress={goIn} />
          </Animated.View>
        ) : null}

        {phase === 'invalid' ? (
          <Animated.View key="invalid" entering={FadeIn.duration(260)} style={styles.flex}>
            <View style={styles.header}>
              <HubGlassIcon icon="time" accent="gold" size={46} />
              <View style={styles.headerText}>
                <Text style={styles.title}>Link expired</Text>
                <Text style={styles.subtitle}>{invalidReason} Reset links only work once and expire after a while.</Text>
              </View>
            </View>
            <View style={styles.spacer} />
            <AuthSubmitButton label="Send a new link" icon="send" onPress={() => void requestNewLink()} />
          </Animated.View>
        ) : null}
      </BookingBottomSheetOverlay>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: 'transparent' },
  flex: { flex: 1 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 14 },
  centerText: { color: 'rgba(226,232,240,0.8)', fontSize: 14, fontWeight: '600' },

  header: { flexDirection: 'row', alignItems: 'center', gap: 14, marginBottom: 18, paddingRight: 40 },
  headerText: { flex: 1 },
  title: { color: '#F8FAFC', fontSize: 20, fontWeight: '700', letterSpacing: -0.4 },
  subtitle: { marginTop: 2, color: 'rgba(226,232,240,0.6)', fontSize: 13, fontWeight: '500', lineHeight: 18 },

  fields: { gap: 10 },
  strengthRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 4 },
  strengthBars: { flex: 1, flexDirection: 'row', gap: 6 },
  strengthBar: { flex: 1, height: 4, borderRadius: 2, backgroundColor: 'rgba(148,163,184,0.2)' },
  strengthLabel: { fontSize: 12, fontWeight: '700', minWidth: 110, textAlign: 'right' },
  mismatch: { paddingHorizontal: 4, color: 'rgba(252,165,165,0.85)', fontSize: 12, fontWeight: '600' },

  errorRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 12 },
  errorText: { flex: 1, color: '#FCA5A5', fontSize: 13, fontWeight: '600' },
  spacer: { flex: 1, minHeight: 16 },
});
