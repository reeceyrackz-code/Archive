import React, { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Modal,
  Pressable,
  Image,
  Platform,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { usePathname, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import Animated, {
  Easing,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withSpring,
  withTiming,
  ZoomIn,
  type SharedValue,
} from 'react-native-reanimated';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors } from '../../src/constants/colors';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { getActiveBookingForCustomer } from '../../src/utils/activeBookingGuard';
import { WWSheetCloseButton } from '../../src/components/ui';
import GradientIconBox from '../../src/components/shared/GradientIconBox';
import { accentToGradient } from '../../src/utils/accentGradient';
import {
  BOOKING_GLASS_TOP_SHEEN,
  BOOKING_GLASS_TOP_SHEEN_LOCATIONS,
  BOOKING_SHEET_BLUR_INTENSITY,
  HEADER_STYLE_CARD_BORDER,
  HEADER_STYLE_CARD_GRADIENT,
} from '../../src/constants/bookingCardTheme';
import { useMapChromeColors } from '../../src/hooks/useMapChromeColors';
import { useTabBarInsetSetter } from '../../src/contexts/TabBarInsetContext';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';

const TAB_BAR_HEIGHT = 58;
/** Full-bleed glass footer + raised center book button clearance. */
const TAB_BAR_ROW_BODY_HEIGHT = 72;
const TAB_BAR_TOTAL_HEIGHT = TAB_BAR_HEIGHT;
export { TAB_BAR_TOTAL_HEIGHT };

const HOME_MASCOT = require('../../assets/wish-genie.png');
const HOME_MASCOT_SIZE = 38;

const BOOK_FAB_SIZE = 56;
const BOOK_RING_SIZE = BOOK_FAB_SIZE + 12;

/** Bottom inset for the main Stack so scroll content is clipped above the floating tab (see RootLayout). */
export function computeTabBarBottomReserve(insetsBottom: number, tabVisible: boolean): number {
  if (!tabVisible) return 0;
  const bottomPad = Math.max(insetsBottom, 10) + 8;
  return bottomPad + TAB_BAR_ROW_BODY_HEIGHT;
}

interface Tab {
  name: string;
  icon: keyof typeof Ionicons.glyphMap;
  route: string;
}

/** Set to true when live tracking should appear in the bottom tab bar again. */
const TRACKING_TAB_IN_TAB_BAR = false;

function GlassFill({ intensity = BOOKING_SHEET_BLUR_INTENSITY }: Readonly<{ intensity?: number }>) {
  return (
    <>
      <View style={[StyleSheet.absoluteFill, styles.glassFallback]} pointerEvents="none" />
      <BlurView
        intensity={Platform.OS === 'ios' ? intensity : intensity + 20}
        tint="dark"
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
        {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
      />
      <LinearGradient
        colors={[...HEADER_STYLE_CARD_GRADIENT]}
        locations={[0, 0.45, 1]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={[StyleSheet.absoluteFill, { opacity: 0.88 }]}
        pointerEvents="none"
      />
      <LinearGradient
        colors={[...BOOKING_GLASS_TOP_SHEEN]}
        locations={[...BOOKING_GLASS_TOP_SHEEN_LOCATIONS]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0.4 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <View style={styles.glassRim} pointerEvents="none" />
      <View style={styles.glassTopHighlight} pointerEvents="none" />
    </>
  );
}

const getTabs = (userType?: string): Tab[] => {
  if (userType === 'valeter') {
    return [
      { name: 'Home', icon: 'home', route: '/valeter/valeter-dashboard' },
      { name: 'Jobs', icon: 'car', route: '/valeter/jobs/queue' },
      ...(TRACKING_TAB_IN_TAB_BAR
        ? ([{ name: 'Track', icon: 'navigate' as const, route: '/valeter/jobs/tracking' }] satisfies Tab[])
        : []),
      { name: 'Earnings', icon: 'wallet', route: '/valeter/valeter-wash-history' },
      { name: 'Profile', icon: 'person', route: '/valeter/profile/valeter-profile' },
    ];
  }

  if (userType === 'organization') {
    return [
      { name: 'Home', icon: 'home', route: '/business/dashboard' },
      { name: 'Locations', icon: 'location', route: '/business/locations' },
      { name: 'Bookings', icon: 'calendar', route: '/business/bookings' },
      { name: 'Team', icon: 'people', route: '/business/team' },
      { name: 'Profile', icon: 'person', route: '/business/profile' },
    ];
  }

  return [
    { name: 'Home', icon: 'home', route: '/owner/owner-dashboard' },
    { name: 'Inbox', icon: 'chatbubbles', route: '/owner/inbox' },
    ...(TRACKING_TAB_IN_TAB_BAR
      ? ([{ name: 'Track', icon: 'navigate' as const, route: '/owner/track' }] satisfies Tab[])
      : []),
    { name: 'Washes', icon: 'time', route: '/owner/wash-history' },
    { name: 'Profile', icon: 'person', route: '/owner/owner-profile' },
  ];
};

function findTabIndex(tabs: Tab[], predicate: (t: Tab) => boolean): number {
  const idx = tabs.findIndex(predicate);
  return Math.max(0, idx);
}

const getActiveIndex = (pathname: string, tabs: Tab[]): number => {
  if (pathname.includes('/booking')) {
    return findTabIndex(tabs, (t) => t.route.includes('/booking'));
  }
  if (pathname.includes('/owner/inbox')) {
    return findTabIndex(tabs, (t) => t.route === '/owner/inbox');
  }
  if (pathname.includes('/track')) {
    const trackIdx = tabs.findIndex((t) => t.route === '/owner/track' || t.route === '/valeter/jobs/tracking');
    if (trackIdx >= 0) return trackIdx;
    if (pathname.includes('/valeter/')) {
      return findTabIndex(tabs, (t) => t.route === '/valeter/jobs/queue');
    }
    return findTabIndex(tabs, (t) => t.route === '/owner/owner-dashboard');
  }
  if (pathname.includes('/rewards')) {
    return findTabIndex(tabs, (t) => t.route === '/rewards' || t.route.includes('rewards'));
  }
  if (pathname.includes('/valeter/jobs/')) {
    const isJobTracking =
      pathname.includes('/valeter/jobs/tracking') ||
      pathname.includes('/valeter/jobs/accept') ||
      pathname.includes('/valeter/jobs/complete');
    if (isJobTracking) {
      const ti = tabs.findIndex((t) => t.route === '/valeter/jobs/tracking');
      if (ti >= 0) return ti;
    }
    return findTabIndex(tabs, (t) => t.route === '/valeter/jobs/queue');
  }
  if (pathname.includes('/valeter/valeter-wash-history')) {
    return findTabIndex(tabs, (t) => t.route === '/valeter/valeter-wash-history');
  }
  if (pathname.includes('/valeter/profile/valeter-profile') || pathname.includes('/valeter/valeter-profile')) {
    return findTabIndex(tabs, (t) => t.route === '/valeter/profile/valeter-profile');
  }
  const businessRoutes = ['/business/dashboard', '/business/locations', '/business/bookings', '/business/team', '/business/profile'] as const;
  for (const route of businessRoutes) {
    if (pathname.includes(route)) return findTabIndex(tabs, (t) => t.route === route);
  }

  for (let i = 0; i < tabs.length; i++) {
    if (pathname === tabs[i].route || pathname.startsWith(tabs[i].route + '/')) return i;
  }
  return 0;
};

function TabItem({
  tab,
  isActive,
  glowAnim,
  onPress,
  profilePictureUri,
}: Readonly<{
  tab: Tab;
  isActive: boolean;
  glowAnim: SharedValue<number>;
  onPress: () => void;
  profilePictureUri?: string | null;
}>) {
  const chrome = useMapChromeColors();
  const showProfileImage = false;
  const iconName = isActive ? tab.icon : (`${tab.icon}-outline` as keyof typeof Ionicons.glyphMap);

  const glowStyle = useAnimatedStyle(() => ({
    transform: [{ scale: 1 + glowAnim.value * 0.05 }],
  }));

  const iconPop = useSharedValue(1);
  useEffect(() => {
    if (!isActive) return;
    iconPop.value = withSequence(
      withTiming(1.22, { duration: 120 }),
      withSpring(1, { damping: 7, stiffness: 240 })
    );
  }, [isActive, iconPop]);
  const iconPopStyle = useAnimatedStyle(() => ({
    transform: [{ scale: iconPop.value }],
  }));

  return (
    <TouchableOpacity
      style={styles.tab}
      onPress={onPress}
      activeOpacity={isActive ? 1 : 0.7}
      disabled={isActive}
      accessibilityRole="tab"
      accessibilityLabel={isActive ? `${tab.name}, selected` : tab.name}
      accessibilityState={{ selected: isActive }}
      accessibilityHint={isActive ? undefined : `Switch to ${tab.name}`}
    >
      <Animated.View style={[styles.tabInner, glowStyle]}>
        {showProfileImage && profilePictureUri ? (
          <Image
            source={{ uri: profilePictureUri }}
            style={styles.profileTabImage}
            resizeMode="cover"
          />
        ) : (
          <View style={[styles.tabChip, isActive && styles.tabChipActive]}>
            {isActive ? (
              <Animated.View
                entering={ZoomIn.springify().damping(14).stiffness(220)}
                style={styles.tabChipBg}
                pointerEvents="none"
              >
                <BlurView
                  intensity={Platform.OS === 'ios' ? 28 : 40}
                  tint="dark"
                  style={StyleSheet.absoluteFill}
                  pointerEvents="none"
                  {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
                />
                <LinearGradient
                  colors={['rgba(125,211,252,0.28)', 'rgba(14,165,233,0.12)', 'rgba(8,20,38,0.2)']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={StyleSheet.absoluteFill}
                  pointerEvents="none"
                />
                <View style={[styles.tabChipRim, { borderColor: chrome.border }]} pointerEvents="none" />
              </Animated.View>
            ) : null}
            <Animated.View style={[styles.tabIcon, iconPopStyle]}>
              {tab.name === 'Home' ? (
                <Image
                  source={HOME_MASCOT}
                  resizeMode="contain"
                  style={[styles.homeMascot, !isActive && styles.homeMascotIdle]}
                />
              ) : (
                <Ionicons
                  name={iconName as never}
                  size={20}
                  color={isActive ? chrome.icon : 'rgba(186,230,253,0.55)'}
                />
              )}
            </Animated.View>
            <Text
              style={[
                styles.tabLabel,
                { color: isActive ? '#E0F2FE' : 'rgba(148,163,184,0.62)' },
                isActive && styles.tabLabelActive,
              ]}
              numberOfLines={1}
            >
              {tab.name}
            </Text>
          </View>
        )}
      </Animated.View>
    </TouchableOpacity>
  );
}

function CenterBookButton({ onPress }: Readonly<{ onPress: () => void }>) {
  const scale = useSharedValue(1);
  const halo = useSharedValue(0);

  useEffect(() => {
    halo.value = withRepeat(
      withTiming(1, { duration: 2200, easing: Easing.out(Easing.quad) }),
      -1,
      false
    );
  }, [halo]);

  const pressStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));
  const haloStyle = useAnimatedStyle(() => ({
    opacity: 0.55 * (1 - halo.value),
    transform: [{ scale: 1 + halo.value * 0.45 }],
  }));

  return (
    <View style={styles.bookSlot} pointerEvents="box-none">
      <TouchableOpacity
        activeOpacity={1}
        onPress={onPress}
        onPressIn={() => {
          scale.value = withTiming(0.9, { duration: 90 });
        }}
        onPressOut={() => {
          scale.value = withSpring(1, { damping: 9, stiffness: 260 });
        }}
        accessibilityRole="button"
        accessibilityLabel="Book a wash"
        style={styles.bookTouch}
      >
        <View style={styles.bookFabStage}>
          <Animated.View style={[styles.bookFabHalo, haloStyle]} pointerEvents="none" />
          <Animated.View style={[styles.bookFabRing, pressStyle]}>
            <View style={styles.bookFabOuter}>
              <View style={styles.bookFab}>
                <Image source={HOME_MASCOT} resizeMode="cover" style={styles.bookFabMascot} />
              </View>
            </View>
            <View style={styles.bookFabBadge}>
              <Ionicons name="calendar" size={12} color="#F8FAFC" />
            </View>
          </Animated.View>
        </View>
        <Text style={styles.bookFabLabel}>Book</Text>
      </TouchableOpacity>
    </View>
  );
}

export default function NavigationTab() {
  const pathname = usePathname();
  const router = useRouter();
  const { user } = useAuth();
  const { theme } = useAccountTheme();
  const insets = useSafeAreaInsets();
  const [showProfileOptions, setShowProfileOptions] = useState(false);

  const isBusinessRoute =
    pathname.includes('/business/') ||
    pathname.includes('/Business/') ||
    pathname.includes('/organisation/') ||
    pathname.includes('/Organization/');

  const isCustomerNav = useMemo(() => {
    if (pathname.includes('/owner/') || pathname.includes('/customer')) return true;
    if (pathname.includes('/valeter/') || isBusinessRoute) return false;
    return user?.userType !== 'valeter' && user?.userType !== 'organization' && user?.userType !== 'business';
  }, [pathname, isBusinessRoute, user?.userType]);

  const tabs = useMemo(() => {
    const userType = user?.userType;

    if (pathname.includes('/owner/') || pathname.includes('/customer')) return getTabs('customer');
    if (pathname.includes('/valeter/')) return getTabs('valeter');
    if (isBusinessRoute) return getTabs('organization');

    const safeUserType =
      userType === 'valeter' || userType === 'organization' || userType === 'business' ? userType : 'customer';

    if (userType === 'valeter' && !pathname.includes('/valeter/') && !pathname.includes('/driver/')) {
      return getTabs('customer');
    }

    return getTabs(safeUserType);
  }, [user?.userType, user?.email, pathname, isBusinessRoute]);

  const activeIndex = useMemo(() => getActiveIndex(pathname, tabs), [pathname, tabs]);

  const defaultAccent = theme.primary || colors.navActive || colors.SKY;

  const glowAnim0 = useSharedValue(0);
  const glowAnim1 = useSharedValue(0);
  const glowAnim2 = useSharedValue(0);
  const glowAnim3 = useSharedValue(0);
  const glowAnim4 = useSharedValue(0);
  const glowAnimations = [glowAnim0, glowAnim1, glowAnim2, glowAnim3, glowAnim4];

  const shouldHideTab = useMemo(() => {
    const hideRoutes = [
      '/auth/',
      '/onboarding',
      '/customer-onboarding',
      '/profile-setup',
      '/valeter/valeter-onboarding',
      '/organisation/organization-onboarding',
      '/owner/booking',
      '/owner/explore',
      '/owner/booking-confirm',
      '/owner/track',
      '/valeter/jobs/accept',
      '/valeter/jobs/tracking',
      '/valeter/jobs/complete',
    ];
    return hideRoutes.some((route) => pathname.includes(route));
  }, [pathname]);

  const isProfileTab = (tab: Tab) => tab.name === 'Profile';

  const setTabBarReserve = useTabBarInsetSetter();
  const tabBottomReserve = computeTabBarBottomReserve(insets.bottom, !shouldHideTab);
  useLayoutEffect(() => {
    setTabBarReserve(tabBottomReserve);
  }, [tabBottomReserve, setTabBarReserve]);

  const leftTabs = isCustomerNav ? tabs.slice(0, 2) : tabs.slice(0, Math.ceil(tabs.length / 2));
  const rightTabs = isCustomerNav ? tabs.slice(2) : tabs.slice(Math.ceil(tabs.length / 2));

  const renderTab = (tab: Tab, index: number) => {
    const isActive = index === activeIndex;
    const isProfile = isProfileTab(tab);
    const glowAnim = glowAnimations[index] || glowAnim0;

    const handleTabPress = async () => {
      if (isActive) return;
      glowAnim.value = withTiming(1, { duration: 200 }, () => {
        glowAnim.value = withTiming(0, { duration: 300 });
      });
      if (isProfile && isBusinessRoute) {
        await hapticFeedback('light');
        setShowProfileOptions(true);
      } else {
        await hapticFeedback('light');
        router.push(tab.route as any);
      }
    };

    return (
      <View key={tab.route} style={styles.individualPill}>
        <TabItem
          tab={tab}
          isActive={isActive}
          glowAnim={glowAnim}
          onPress={handleTabPress}
          profilePictureUri={isProfileTab(tab) ? (user?.profilePicture ?? null) : null}
        />
      </View>
    );
  };

  const bookPressBusyRef = useRef(false);
  const handleBookPress = async () => {
    if (bookPressBusyRef.current) return;
    bookPressBusyRef.current = true;
    try {
      void hapticFeedback('medium');
      const active = user?.id ? await getActiveBookingForCustomer(user.id) : null;
      if (active?.id) {
        router.push({ pathname: '/owner/booking/tracking', params: { bookingId: active.id } } as any);
      } else {
        router.push('/owner/booking/create' as any);
      }
    } finally {
      bookPressBusyRef.current = false;
    }
  };

  if (shouldHideTab) {
    return <View style={styles.hidden} />;
  }

  return (
    <View pointerEvents="box-none" style={styles.screenWrap}>
      <View
        style={[
          styles.fullFooter,
          isCustomerNav && styles.fullFooterWithFab,
          { paddingBottom: Math.max(insets.bottom, 10) },
        ]}
      >
        <View style={styles.fullFooterGlass} pointerEvents="none">
          <GlassFill />
        </View>
        <View style={styles.dockContent} pointerEvents="box-none">
          {isCustomerNav ? (
            <>
              <View style={styles.sideCluster}>
                {leftTabs.map((tab) => renderTab(tab, tabs.indexOf(tab)))}
              </View>
              <CenterBookButton onPress={handleBookPress} />
              <View style={styles.sideCluster}>
                {rightTabs.map((tab) => renderTab(tab, tabs.indexOf(tab)))}
              </View>
            </>
          ) : (
            tabs.map((tab, index) => renderTab(tab, index))
          )}
        </View>
      </View>

      <Modal
        visible={showProfileOptions}
        transparent
        animationType="fade"
        onRequestClose={() => setShowProfileOptions(false)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setShowProfileOptions(false)}>
          <Pressable
            style={[
              styles.actionSheet,
              isBusinessRoute && {
                backgroundColor: theme.background?.[0] || 'rgba(15, 23, 42, 0.95)',
                borderColor: `${theme.primary}55`,
              },
            ]}
            onPress={(e) => e.stopPropagation()}
          >
            <View style={styles.actionSheetHeader}>
              <Text style={[styles.actionSheetTitle, isBusinessRoute && { color: theme.primary }]}>
                Profile Options
              </Text>
              <WWSheetCloseButton
                size={34}
                iconSize={22}
                iconColor={defaultAccent}
                onPress={() => setShowProfileOptions(false)}
                accessibilityLabel="Close profile options"
              />
            </View>

            <TouchableOpacity
              style={styles.actionSheetItem}
              onPress={async () => {
                await hapticFeedback('light');
                setShowProfileOptions(false);
                router.push('/business/profile' as any);
              }}
              activeOpacity={0.85}
            >
              <View style={styles.actionSheetIconWrapper}>
                <GradientIconBox
                  icon="person"
                  colors={accentToGradient(String(defaultAccent))}
                  boxSize={38}
                  size={20}
                  elevated
                />
              </View>
              <Text style={styles.actionSheetItemText}>Business Profile</Text>
              <Ionicons name="chevron-forward" size={18} color="rgba(255,255,255,0.55)" />
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.actionSheetItem}
              onPress={async () => {
                await hapticFeedback('light');
                setShowProfileOptions(false);
                router.push('/business/settings' as any);
              }}
              activeOpacity={0.85}
            >
              <View style={styles.actionSheetIconWrapper}>
                <GradientIconBox
                  icon="settings"
                  colors={accentToGradient(String(defaultAccent))}
                  boxSize={38}
                  size={20}
                  elevated
                />
              </View>
              <Text style={styles.actionSheetItemText}>Settings</Text>
              <Ionicons name="chevron-forward" size={18} color="rgba(255,255,255,0.55)" />
            </TouchableOpacity>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  screenWrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: 'stretch',
    justifyContent: 'flex-end',
    zIndex: 9999,
    elevation: 0,
  },
  fullFooter: {
    width: '100%',
    position: 'relative',
    overflow: 'hidden',
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: HEADER_STYLE_CARD_BORDER,
    shadowColor: '#020617',
    shadowOffset: { width: 0, height: -6 },
    shadowOpacity: 0.35,
    shadowRadius: 16,
    elevation: 18,
  },
  fullFooterWithFab: {
    overflow: 'visible',
  },
  fullFooterGlass: {
    ...StyleSheet.absoluteFill,
    overflow: 'hidden',
  },
  glassFallback: {
    backgroundColor: 'rgba(10,25,41,0.62)',
  },
  glassRim: {
    ...StyleSheet.absoluteFill,
    borderTopWidth: 1,
    borderColor: HEADER_STYLE_CARD_BORDER,
  },
  glassTopHighlight: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.28)',
  },
  dockContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 8,
    paddingTop: 8,
    minHeight: 58,
    zIndex: 1,
  },
  sideCluster: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-evenly',
    minHeight: 52,
  },
  individualPill: {
    flex: 1,
    minHeight: 52,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 2,
  },
  tab: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
  },
  tabInner: {
    alignItems: 'center',
    justifyContent: 'center',
    minWidth: 52,
  },
  tabChip: {
    alignItems: 'center',
    justifyContent: 'center',
    gap: 2,
    minWidth: 54,
    paddingHorizontal: 8,
    paddingVertical: 6,
    borderRadius: 16,
  },
  tabChipActive: {
    backgroundColor: 'rgba(14,165,233,0.12)',
  },
  tabChipBg: {
    ...StyleSheet.absoluteFill,
    borderRadius: 16,
    overflow: 'hidden',
  },
  tabChipRim: {
    ...StyleSheet.absoluteFill,
    borderRadius: 16,
    borderWidth: StyleSheet.hairlineWidth,
  },
  tabIcon: {
    zIndex: 1,
  },
  homeMascot: {
    width: HOME_MASCOT_SIZE,
    height: HOME_MASCOT_SIZE,
    marginTop: -12,
    marginBottom: -4,
  },
  homeMascotIdle: {
    opacity: 0.7,
  },
  tabLabel: {
    fontSize: 10,
    fontWeight: '600',
    letterSpacing: 0.15,
    zIndex: 1,
  },
  tabLabelActive: {
    fontWeight: '800',
  },
  bookSlot: {
    width: BOOK_RING_SIZE + 8,
    alignItems: 'center',
    justifyContent: 'flex-start',
    marginTop: -30,
    zIndex: 4,
  },
  bookTouch: { alignItems: 'center' },
  bookFabStage: {
    width: BOOK_RING_SIZE,
    height: BOOK_RING_SIZE,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bookFabHalo: {
    position: 'absolute',
    width: BOOK_FAB_SIZE,
    height: BOOK_FAB_SIZE,
    borderRadius: BOOK_FAB_SIZE / 2,
    backgroundColor: '#38BDF8',
  },
  bookFabRing: {
    width: BOOK_RING_SIZE,
    height: BOOK_RING_SIZE,
    borderRadius: BOOK_RING_SIZE / 2,
    backgroundColor: '#0A1929',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: HEADER_STYLE_CARD_BORDER,
  },
  bookFabOuter: {
    borderRadius: BOOK_FAB_SIZE / 2,
    shadowColor: '#38BDF8',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.55,
    shadowRadius: 14,
    elevation: 16,
  },
  bookFab: {
    width: BOOK_FAB_SIZE,
    height: BOOK_FAB_SIZE,
    borderRadius: BOOK_FAB_SIZE / 2,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(224,242,254,0.75)',
    backgroundColor: '#38BDF8',
  },
  bookFabMascot: {
    width: '100%',
    height: '100%',
  },
  bookFabBadge: {
    position: 'absolute',
    right: 2,
    bottom: 2,
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#0284C7',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#0A1929',
  },
  bookFabLabel: {
    marginTop: 2,
    color: '#7DD3FC',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 0.15,
  },
  profileTabImage: {
    width: 42,
    height: 42,
    borderRadius: 21,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.55)',
    justifyContent: 'flex-end',
  },
  actionSheet: {
    backgroundColor: 'rgba(15, 23, 42, 0.95)',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingTop: 16,
    paddingBottom: 28,
    borderTopWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
  },
  actionSheetHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.08)',
    marginBottom: 8,
  },
  actionSheetTitle: {
    fontSize: 18,
    fontWeight: '900',
    color: '#F9FAFB',
  },
  actionSheetItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingVertical: 14,
    gap: 14,
  },
  actionSheetIconWrapper: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionSheetItemText: {
    flex: 1,
    fontSize: 16,
    fontWeight: '800',
    color: '#F9FAFB',
  },
  hidden: {
    position: 'absolute',
    width: 0,
    height: 0,
  },
});
